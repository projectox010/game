try {
    self["workbox:core:6.5.2"] && _()
} catch (a) {}
const N = (a, ...e) => {
        let t = a;
        return e.length > 0 && (t += ` :: ${JSON.stringify(e)}`), t
    },
    x = N;
class l extends Error {
    constructor(e, t) {
        const s = x(e, t);
        super(s), this.name = e, this.details = t
    }
}
const f = {
        googleAnalytics: "googleAnalytics",
        precache: "precache-v2",
        prefix: "workbox",
        runtime: "runtime",
        suffix: typeof registration < "u" ? registration.scope : ""
    },
    b = a => [f.prefix, a, f.suffix].filter(e => e && e.length > 0).join("-"),
    E = a => {
        for (const e of Object.keys(f)) a(e)
    },
    C = {
        updateDetails: a => {
            E(e => {
                typeof a[e] == "string" && (f[e] = a[e])
            })
        },
        getGoogleAnalyticsName: a => a || b(f.googleAnalytics),
        getPrecacheName: a => a || b(f.precache),
        getPrefix: () => f.prefix,
        getRuntimeName: a => a || b(f.runtime),
        getSuffix: () => f.suffix
    };

function k(a, e) {
    const t = e();
    return a.waitUntil(t), t
}
try {
    self["workbox:precaching:6.5.2"] && _()
} catch (a) {}
const I = "__WB_REVISION__";

function O(a) {
    if (!a) throw new l("add-to-cache-list-unexpected-type", {
        entry: a
    });
    if (typeof a == "string") {
        const r = new URL(a, location.href);
        return {
            cacheKey: r.href,
            url: r.href
        }
    }
    const {
        revision: e,
        url: t
    } = a;
    if (!t) throw new l("add-to-cache-list-unexpected-type", {
        entry: a
    });
    if (!e) {
        const r = new URL(t, location.href);
        return {
            cacheKey: r.href,
            url: r.href
        }
    }
    const s = new URL(t, location.href),
        n = new URL(t, location.href);
    return s.searchParams.set(I, e), {
        cacheKey: s.href,
        url: n.href
    }
}
class v {
    constructor() {
        this.updatedURLs = [], this.notUpdatedURLs = [], this.handlerWillStart = async ({
            request: e,
            state: t
        }) => {
            t && (t.originalRequest = e)
        }, this.cachedResponseWillBeUsed = async ({
            event: e,
            state: t,
            cachedResponse: s
        }) => {
            if (e.type === "install" && t && t.originalRequest && t.originalRequest instanceof Request) {
                const n = t.originalRequest.url;
                s ? this.notUpdatedURLs.push(n) : this.updatedURLs.push(n)
            }
            return s
        }
    }
}
class M {
    constructor({
        precacheController: e
    }) {
        this.cacheKeyWillBeUsed = async ({
            request: t,
            params: s
        }) => {
            const n = (s == null ? void 0 : s.cacheKey) || this._precacheController.getCacheKeyForURL(t.url);
            return n ? new Request(n, {
                headers: t.headers
            }) : t
        }, this._precacheController = e
    }
}
let p;

function W() {
    if (p === void 0) {
        const a = new Response("");
        if ("body" in a) try {
            new Response(a.body), p = !0
        } catch (e) {
            p = !1
        }
        p = !1
    }
    return p
}
async function q(a, e) {
    let t = null;
    if (a.url && (t = new URL(a.url).origin), t !== self.location.origin) throw new l("cross-origin-copy-response", {
        origin: t
    });
    const s = a.clone(),
        n = {
            headers: new Headers(s.headers),
            status: s.status,
            statusText: s.statusText
        },
        r = e ? e(n) : n,
        c = W() ? s.body : await s.blob();
    return new Response(c, r)
}
const D = a => new URL(String(a), location.href).href.replace(new RegExp(`^${location.origin}`), "");

function P(a, e) {
    const t = new URL(a);
    for (const s of e) t.searchParams.delete(s);
    return t.href
}
async function A(a, e, t, s) {
    const n = P(e.url, t);
    if (e.url === n) return a.match(e, s);
    const r = Object.assign(Object.assign({}, s), {
            ignoreSearch: !0
        }),
        c = await a.keys(e, r);
    for (const i of c) {
        const o = P(i.url, t);
        if (n === o) return a.match(i, s)
    }
}
class S {
    constructor() {
        this.promise = new Promise((e, t) => {
            this.resolve = e, this.reject = t
        })
    }
}
const j = new Set;
async function F() {
    for (const a of j) await a()
}

function H(a) {
    return new Promise(e => setTimeout(e, a))
}
try {
    self["workbox:strategies:6.5.2"] && _()
} catch (a) {}

function m(a) {
    return typeof a == "string" ? new Request(a) : a
}
class B {
    constructor(e, t) {
        this._cacheKeys = {}, Object.assign(this, t), this.event = t.event, this._strategy = e, this._handlerDeferred = new S, this._extendLifetimePromises = [], this._plugins = [...e.plugins], this._pluginStateMap = new Map;
        for (const s of this._plugins) this._pluginStateMap.set(s, {});
        this.event.waitUntil(this._handlerDeferred.promise)
    }
    async fetch(e) {
        const {
            event: t
        } = this;
        let s = m(e);
        if (s.mode === "navigate" && t instanceof FetchEvent && t.preloadResponse) {
            const c = await t.preloadResponse;
            if (c) return c
        }
        const n = this.hasCallback("fetchDidFail") ? s.clone() : null;
        try {
            for (const c of this.iterateCallbacks("requestWillFetch")) s = await c({
                request: s.clone(),
                event: t
            })
        } catch (c) {
            if (c instanceof Error) throw new l("plugin-error-request-will-fetch", {
                thrownErrorMessage: c.message
            })
        }
        const r = s.clone();
        try {
            let c;
            c = await fetch(s, s.mode === "navigate" ? void 0 : this._strategy.fetchOptions);
            for (const i of this.iterateCallbacks("fetchDidSucceed")) c = await i({
                event: t,
                request: r,
                response: c
            });
            return c
        } catch (c) {
            throw n && await this.runCallbacks("fetchDidFail", {
                error: c,
                event: t,
                originalRequest: n.clone(),
                request: r.clone()
            }), c
        }
    }
    async fetchAndCachePut(e) {
        const t = await this.fetch(e),
            s = t.clone();
        return this.waitUntil(this.cachePut(e, s)), t
    }
    async cacheMatch(e) {
        const t = m(e);
        let s;
        const {
            cacheName: n,
            matchOptions: r
        } = this._strategy, c = await this.getCacheKey(t, "read"), i = Object.assign(Object.assign({}, r), {
            cacheName: n
        });
        s = await caches.match(c, i);
        for (const o of this.iterateCallbacks("cachedResponseWillBeUsed")) s = await o({
            cacheName: n,
            matchOptions: r,
            cachedResponse: s,
            request: c,
            event: this.event
        }) || void 0;
        return s
    }
    async cachePut(e, t) {
        const s = m(e);
        await H(0);
        const n = await this.getCacheKey(s, "write");
        if (!t) throw new l("cache-put-with-no-response", {
            url: D(n.url)
        });
        const r = await this._ensureResponseSafeToCache(t);
        if (!r) return !1;
        const {
            cacheName: c,
            matchOptions: i
        } = this._strategy, o = await self.caches.open(c), h = this.hasCallback("cacheDidUpdate"), g = h ? await A(o, n.clone(), ["__WB_REVISION__"], i) : null;
        try {
            await o.put(n, h ? r.clone() : r)
        } catch (u) {
            if (u instanceof Error) throw u.name === "QuotaExceededError" && await F(), u
        }
        for (const u of this.iterateCallbacks("cacheDidUpdate")) await u({
            cacheName: c,
            oldResponse: g,
            newResponse: r.clone(),
            request: n,
            event: this.event
        });
        return !0
    }
    async getCacheKey(e, t) {
        const s = `${e.url} | ${t}`;
        if (!this._cacheKeys[s]) {
            let n = e;
            for (const r of this.iterateCallbacks("cacheKeyWillBeUsed")) n = m(await r({
                mode: t,
                request: n,
                event: this.event,
                params: this.params
            }));
            this._cacheKeys[s] = n
        }
        return this._cacheKeys[s]
    }
    hasCallback(e) {
        for (const t of this._strategy.plugins)
            if (e in t) return !0;
        return !1
    }
    async runCallbacks(e, t) {
        for (const s of this.iterateCallbacks(e)) await s(t)
    }* iterateCallbacks(e) {
        for (const t of this._strategy.plugins)
            if (typeof t[e] == "function") {
                const s = this._pluginStateMap.get(t);
                yield r => {
                    const c = Object.assign(Object.assign({}, r), {
                        state: s
                    });
                    return t[e](c)
                }
            }
    }
    waitUntil(e) {
        return this._extendLifetimePromises.push(e), e
    }
    async doneWaiting() {
        let e;
        for (; e = this._extendLifetimePromises.shift();) await e
    }
    destroy() {
        this._handlerDeferred.resolve(null)
    }
    async _ensureResponseSafeToCache(e) {
        let t = e,
            s = !1;
        for (const n of this.iterateCallbacks("cacheWillUpdate"))
            if (t = await n({
                    request: this.request,
                    response: t,
                    event: this.event
                }) || void 0, s = !0, !t) break;
        return s || t && t.status !== 200 && (t = void 0), t
    }
}
class $ {
    constructor(e = {}) {
        this.cacheName = C.getRuntimeName(e.cacheName), this.plugins = e.plugins || [], this.fetchOptions = e.fetchOptions, this.matchOptions = e.matchOptions
    }
    handle(e) {
        const [t] = this.handleAll(e);
        return t
    }
    handleAll(e) {
        e instanceof FetchEvent && (e = {
            event: e,
            request: e.request
        });
        const t = e.event,
            s = typeof e.request == "string" ? new Request(e.request) : e.request,
            n = "params" in e ? e.params : void 0,
            r = new B(this, {
                event: t,
                request: s,
                params: n
            }),
            c = this._getResponse(r, s, t),
            i = this._awaitComplete(c, r, s, t);
        return [c, i]
    }
    async _getResponse(e, t, s) {
        await e.runCallbacks("handlerWillStart", {
            event: s,
            request: t
        });
        let n;
        try {
            if (n = await this._handle(t, e), !n || n.type === "error") throw new l("no-response", {
                url: t.url
            })
        } catch (r) {
            if (r instanceof Error) {
                for (const c of e.iterateCallbacks("handlerDidError"))
                    if (n = await c({
                            error: r,
                            event: s,
                            request: t
                        }), n) break
            }
            if (!n) throw r
        }
        for (const r of e.iterateCallbacks("handlerWillRespond")) n = await r({
            event: s,
            request: t,
            response: n
        });
        return n
    }
    async _awaitComplete(e, t, s, n) {
        let r, c;
        try {
            r = await e
        } catch (i) {}
        try {
            await t.runCallbacks("handlerDidRespond", {
                event: n,
                request: s,
                response: r
            }), await t.doneWaiting()
        } catch (i) {
            i instanceof Error && (c = i)
        }
        if (await t.runCallbacks("handlerDidComplete", {
                event: n,
                request: s,
                response: r,
                error: c
            }), t.destroy(), c) throw c
    }
}
class d extends $ {
    constructor(e = {}) {
        e.cacheName = C.getPrecacheName(e.cacheName), super(e), this._fallbackToNetwork = e.fallbackToNetwork !== !1, this.plugins.push(d.copyRedirectedCacheableResponsesPlugin)
    }
    async _handle(e, t) {
        const s = await t.cacheMatch(e);
        return s || (t.event && t.event.type === "install" ? await this._handleInstall(e, t) : await this._handleFetch(e, t))
    }
    async _handleFetch(e, t) {
        let s;
        const n = t.params || {};
        if (this._fallbackToNetwork) {
            const r = n.integrity,
                c = e.integrity,
                i = !c || c === r;
            s = await t.fetch(new Request(e, {
                integrity: c || r
            })), r && i && (this._useDefaultCacheabilityPluginIfNeeded(), await t.cachePut(e, s.clone()))
        } else throw new l("missing-precache-entry", {
            cacheName: this.cacheName,
            url: e.url
        });
        return s
    }
    async _handleInstall(e, t) {
        this._useDefaultCacheabilityPluginIfNeeded();
        const s = await t.fetch(e);
        if (!await t.cachePut(e, s.clone())) throw new l("bad-precaching-response", {
            url: e.url,
            status: s.status
        });
        return s
    }
    _useDefaultCacheabilityPluginIfNeeded() {
        let e = null,
            t = 0;
        for (const [s, n] of this.plugins.entries()) n !== d.copyRedirectedCacheableResponsesPlugin && (n === d.defaultPrecacheCacheabilityPlugin && (e = s), n.cacheWillUpdate && t++);
        t === 0 ? this.plugins.push(d.defaultPrecacheCacheabilityPlugin) : t > 1 && e !== null && this.plugins.splice(e, 1)
    }
}
d.defaultPrecacheCacheabilityPlugin = {
    async cacheWillUpdate({
        response: a
    }) {
        return !a || a.status >= 400 ? null : a
    }
};
d.copyRedirectedCacheableResponsesPlugin = {
    async cacheWillUpdate({
        response: a
    }) {
        return a.redirected ? await q(a) : a
    }
};
class G {
    constructor({
        cacheName: e,
        plugins: t = [],
        fallbackToNetwork: s = !0
    } = {}) {
        this._urlsToCacheKeys = new Map, this._urlsToCacheModes = new Map, this._cacheKeysToIntegrities = new Map, this._strategy = new d({
            cacheName: C.getPrecacheName(e),
            plugins: [...t, new M({
                precacheController: this
            })],
            fallbackToNetwork: s
        }), this.install = this.install.bind(this), this.activate = this.activate.bind(this)
    }
    get strategy() {
        return this._strategy
    }
    precache(e) {
        this.addToCacheList(e), this._installAndActiveListenersAdded || (self.addEventListener("install", this.install), self.addEventListener("activate", this.activate), this._installAndActiveListenersAdded = !0)
    }
    addToCacheList(e) {
        const t = [];
        for (const s of e) {
            typeof s == "string" ? t.push(s) : s && s.revision === void 0 && t.push(s.url);
            const {
                cacheKey: n,
                url: r
            } = O(s), c = typeof s != "string" && s.revision ? "reload" : "default";
            if (this._urlsToCacheKeys.has(r) && this._urlsToCacheKeys.get(r) !== n) throw new l("add-to-cache-list-conflicting-entries", {
                firstEntry: this._urlsToCacheKeys.get(r),
                secondEntry: n
            });
            if (typeof s != "string" && s.integrity) {
                if (this._cacheKeysToIntegrities.has(n) && this._cacheKeysToIntegrities.get(n) !== s.integrity) throw new l("add-to-cache-list-conflicting-integrities", {
                    url: r
                });
                this._cacheKeysToIntegrities.set(n, s.integrity)
            }
            if (this._urlsToCacheKeys.set(r, n), this._urlsToCacheModes.set(r, c), t.length > 0) {
                const i = `Workbox is precaching URLs without revision info: ${t.join(", ")}
This is generally NOT safe. Learn more at https://bit.ly/wb-precache`;
                console.warn(i)
            }
        }
    }
    install(e) {
        return k(e, async () => {
            const t = new v;
            this.strategy.plugins.push(t);
            for (const [r, c] of this._urlsToCacheKeys) {
                const i = this._cacheKeysToIntegrities.get(c),
                    o = this._urlsToCacheModes.get(r),
                    h = new Request(r, {
                        integrity: i,
                        cache: o,
                        credentials: "same-origin"
                    });
                await Promise.all(this.strategy.handleAll({
                    params: {
                        cacheKey: c
                    },
                    request: h,
                    event: e
                }))
            }
            const {
                updatedURLs: s,
                notUpdatedURLs: n
            } = t;
            return {
                updatedURLs: s,
                notUpdatedURLs: n
            }
        })
    }
    activate(e) {
        return k(e, async () => {
            const t = await self.caches.open(this.strategy.cacheName),
                s = await t.keys(),
                n = new Set(this._urlsToCacheKeys.values()),
                r = [];
            for (const c of s) n.has(c.url) || (await t.delete(c), r.push(c.url));
            return {
                deletedURLs: r
            }
        })
    }
    getURLsToCacheKeys() {
        return this._urlsToCacheKeys
    }
    getCachedURLs() {
        return [...this._urlsToCacheKeys.keys()]
    }
    getCacheKeyForURL(e) {
        const t = new URL(e, location.href);
        return this._urlsToCacheKeys.get(t.href)
    }
    getIntegrityForCacheKey(e) {
        return this._cacheKeysToIntegrities.get(e)
    }
    async matchPrecache(e) {
        const t = e instanceof Request ? e.url : e,
            s = this.getCacheKeyForURL(t);
        if (s) return (await self.caches.open(this.strategy.cacheName)).match(s)
    }
    createHandlerBoundToURL(e) {
        const t = this.getCacheKeyForURL(e);
        if (!t) throw new l("non-precached-url", {
            url: e
        });
        return s => (s.request = new Request(e), s.params = Object.assign({
            cacheKey: t
        }, s.params), this.strategy.handle(s))
    }
}
let U;
const K = () => (U || (U = new G), U);
try {
    self["workbox:routing:6.5.2"] && _()
} catch (a) {}
const T = "GET",
    R = a => a && typeof a == "object" ? a : {
        handle: a
    };
class w {
    constructor(e, t, s = T) {
        this.handler = R(t), this.match = e, this.method = s
    }
    setCatchHandler(e) {
        this.catchHandler = R(e)
    }
}
class V extends w {
    constructor(e, t, s) {
        const n = ({
            url: r
        }) => {
            const c = e.exec(r.href);
            if (!!c && !(r.origin !== location.origin && c.index !== 0)) return c.slice(1)
        };
        super(n, t, s)
    }
}
class Q {
    constructor() {
        this._routes = new Map, this._defaultHandlerMap = new Map
    }
    get routes() {
        return this._routes
    }
    addFetchListener() {
        self.addEventListener("fetch", e => {
            const {
                request: t
            } = e, s = this.handleRequest({
                request: t,
                event: e
            });
            s && e.respondWith(s)
        })
    }
    addCacheListener() {
        self.addEventListener("message", e => {
            if (e.data && e.data.type === "CACHE_URLS") {
                const {
                    payload: t
                } = e.data, s = Promise.all(t.urlsToCache.map(n => {
                    typeof n == "string" && (n = [n]);
                    const r = new Request(...n);
                    return this.handleRequest({
                        request: r,
                        event: e
                    })
                }));
                e.waitUntil(s), e.ports && e.ports[0] && s.then(() => e.ports[0].postMessage(!0))
            }
        })
    }
    handleRequest({
        request: e,
        event: t
    }) {
        const s = new URL(e.url, location.href);
        if (!s.protocol.startsWith("http")) return;
        const n = s.origin === location.origin,
            {
                params: r,
                route: c
            } = this.findMatchingRoute({
                event: t,
                request: e,
                sameOrigin: n,
                url: s
            });
        let i = c && c.handler;
        const o = e.method;
        if (!i && this._defaultHandlerMap.has(o) && (i = this._defaultHandlerMap.get(o)), !i) return;
        let h;
        try {
            h = i.handle({
                url: s,
                request: e,
                event: t,
                params: r
            })
        } catch (u) {
            h = Promise.reject(u)
        }
        const g = c && c.catchHandler;
        return h instanceof Promise && (this._catchHandler || g) && (h = h.catch(async u => {
            if (g) try {
                return await g.handle({
                    url: s,
                    request: e,
                    event: t,
                    params: r
                })
            } catch (L) {
                L instanceof Error && (u = L)
            }
            if (this._catchHandler) return this._catchHandler.handle({
                url: s,
                request: e,
                event: t
            });
            throw u
        })), h
    }
    findMatchingRoute({
        url: e,
        sameOrigin: t,
        request: s,
        event: n
    }) {
        const r = this._routes.get(s.method) || [];
        for (const c of r) {
            let i;
            const o = c.match({
                url: e,
                sameOrigin: t,
                request: s,
                event: n
            });
            if (o) return i = o, (Array.isArray(i) && i.length === 0 || o.constructor === Object && Object.keys(o).length === 0 || typeof o == "boolean") && (i = void 0), {
                route: c,
                params: i
            }
        }
        return {}
    }
    setDefaultHandler(e, t = T) {
        this._defaultHandlerMap.set(t, R(e))
    }
    setCatchHandler(e) {
        this._catchHandler = R(e)
    }
    registerRoute(e) {
        this._routes.has(e.method) || this._routes.set(e.method, []), this._routes.get(e.method).push(e)
    }
    unregisterRoute(e) {
        if (!this._routes.has(e.method)) throw new l("unregister-route-but-not-found-with-method", {
            method: e.method
        });
        const t = this._routes.get(e.method).indexOf(e);
        if (t > -1) this._routes.get(e.method).splice(t, 1);
        else throw new l("unregister-route-route-not-registered")
    }
}
let y;
const z = () => (y || (y = new Q, y.addFetchListener(), y.addCacheListener()), y);

function J(a, e, t) {
    let s;
    if (typeof a == "string") {
        const r = new URL(a, location.href),
            c = ({
                url: i
            }) => i.href === r.href;
        s = new w(c, e, t)
    } else if (a instanceof RegExp) s = new V(a, e, t);
    else if (typeof a == "function") s = new w(a, e, t);
    else if (a instanceof w) s = a;
    else throw new l("unsupported-route-type", {
        moduleName: "workbox-routing",
        funcName: "registerRoute",
        paramName: "capture"
    });
    return z().registerRoute(s), s
}

function X(a, e = []) {
    for (const t of [...a.searchParams.keys()]) e.some(s => s.test(t)) && a.searchParams.delete(t);
    return a
}

function* Y(a, {
    ignoreURLParametersMatching: e = [/^utm_/, /^fbclid$/],
    directoryIndex: t = "index.html",
    cleanURLs: s = !0,
    urlManipulation: n
} = {}) {
    const r = new URL(a, location.href);
    r.hash = "", yield r.href;
    const c = X(r, e);
    if (yield c.href, t && c.pathname.endsWith("/")) {
        const i = new URL(c.href);
        i.pathname += t, yield i.href
    }
    if (s) {
        const i = new URL(c.href);
        i.pathname += ".html", yield i.href
    }
    if (n) {
        const i = n({
            url: r
        });
        for (const o of i) yield o.href
    }
}
class Z extends w {
    constructor(e, t) {
        const s = ({
            request: n
        }) => {
            const r = e.getURLsToCacheKeys();
            for (const c of Y(n.url, t)) {
                const i = r.get(c);
                if (i) {
                    const o = e.getIntegrityForCacheKey(i);
                    return {
                        cacheKey: i,
                        integrity: o
                    }
                }
            }
        };
        super(s, e.strategy)
    }
}

function ee(a) {
    const e = K(),
        t = new Z(e, a);
    J(t)
}
const te = "-precache-",
    se = async (a, e = te) => {
        const s = (await self.caches.keys()).filter(n => n.includes(e) && n.includes(self.registration.scope) && n !== a);
        return await Promise.all(s.map(n => self.caches.delete(n))), s
    };

function ae() {
    self.addEventListener("activate", a => {
        const e = C.getPrecacheName();
        a.waitUntil(se(e).then(t => {}))
    })
}

function ne(a) {
    K().precache(a)
}

function re(a, e) {
    ne(a), ee(e)
}
const ce = [{
    "revision": null,
    "url": "assets/_baseAssignValue-legacy.dee54fe3.js"
}, {
    "revision": null,
    "url": "assets/_baseAssignValue.085da001.js"
}, {
    "revision": null,
    "url": "assets/_baseRandom-legacy.bcb31582.js"
}, {
    "revision": null,
    "url": "assets/_baseRandom.17165484.js"
}, {
    "revision": null,
    "url": "assets/_copyArray-legacy.95c89173.js"
}, {
    "revision": null,
    "url": "assets/_copyArray.2183cf44.js"
}, {
    "revision": null,
    "url": "assets/Achieve-legacy.b746a68c.js"
}, {
    "revision": null,
    "url": "assets/Achieve.d282d362.css"
}, {
    "revision": null,
    "url": "assets/Achieve.e58ebef9.js"
}, {
    "revision": null,
    "url": "assets/AggregateList-legacy.02c6ba38.js"
}, {
    "revision": null,
    "url": "assets/AggregateList.0333c15f.js"
}, {
    "revision": null,
    "url": "assets/AggregateList.850006d5.css"
}, {
    "revision": null,
    "url": "assets/ar-legacy.5f7cb651.js"
}, {
    "revision": null,
    "url": "assets/ar.bbdc932a.js"
}, {
    "revision": null,
    "url": "assets/asyncIndex-legacy.7341f5f9.js"
}, {
    "revision": null,
    "url": "assets/asyncIndex.6a8f427d.css"
}, {
    "revision": null,
    "url": "assets/asyncIndex.9a896f4b.js"
}, {
    "revision": null,
    "url": "assets/browser-legacy.7aefa073.js"
}, {
    "revision": null,
    "url": "assets/browser.3252e340.js"
}, {
    "revision": null,
    "url": "assets/CardAsync-legacy.377dd4fa.js"
}, {
    "revision": null,
    "url": "assets/CardAsync.64db42e7.js"
}, {
    "revision": null,
    "url": "assets/CardAsync.9d05f775.css"
}, {
    "revision": null,
    "url": "assets/CatchCoco-legacy.780ac03a.js"
}, {
    "revision": null,
    "url": "assets/CatchCoco.514f76de.js"
}, {
    "revision": null,
    "url": "assets/CatchCoco.89d3f752.css"
}, {
    "revision": null,
    "url": "assets/CategoryGatePage-legacy.7a0756e0.js"
}, {
    "revision": null,
    "url": "assets/CategoryGatePage.bb82e4fd.js"
}, {
    "revision": null,
    "url": "assets/CheckPassword-legacy.89f8cdb9.js"
}, {
    "revision": null,
    "url": "assets/CheckPassword.2a9dd7fb.js"
}, {
    "revision": null,
    "url": "assets/CheckPassword.d70d6f91.css"
}, {
    "revision": null,
    "url": "assets/ContestMain-legacy.74a2e312.js"
}, {
    "revision": null,
    "url": "assets/ContestMain.3a839aef.js"
}, {
    "revision": null,
    "url": "assets/ContestMain.c44cb563.css"
}, {
    "revision": null,
    "url": "assets/ContestStore-legacy.dedc7a4c.js"
}, {
    "revision": null,
    "url": "assets/ContestStore.f66ac805.js"
}, {
    "revision": null,
    "url": "assets/de-legacy.6cfa13c5.js"
}, {
    "revision": null,
    "url": "assets/de.8f8ad4b2.js"
}, {
    "revision": null,
    "url": "assets/DepositBonus-legacy.08eb960e.js"
}, {
    "revision": null,
    "url": "assets/DepositBonus.4c1965c5.css"
}, {
    "revision": null,
    "url": "assets/DepositBonus.b22efecb.js"
}, {
    "revision": null,
    "url": "assets/DetailArea-legacy.06d6904a.js"
}, {
    "revision": null,
    "url": "assets/DetailArea.cea8ce12.css"
}, {
    "revision": null,
    "url": "assets/DetailArea.f4a79d49.js"
}, {
    "revision": null,
    "url": "assets/dijkstra-legacy.bb67fe84.js"
}, {
    "revision": null,
    "url": "assets/dijkstra.47a9ffea.js"
}, {
    "revision": null,
    "url": "assets/enc-hex-legacy.40f31761.js"
}, {
    "revision": null,
    "url": "assets/enc-hex.c7ceb6cd.js"
}, {
    "revision": null,
    "url": "assets/es-legacy.785bbe7d.js"
}, {
    "revision": null,
    "url": "assets/es.93fb815b.js"
}, {
    "revision": null,
    "url": "assets/fa-legacy.47db3742.js"
}, {
    "revision": null,
    "url": "assets/fa.fbc20e8a.js"
}, {
    "revision": null,
    "url": "assets/fi-legacy.88fa7a48.js"
}, {
    "revision": null,
    "url": "assets/fi.fbdad8eb.js"
}, {
    "revision": null,
    "url": "assets/fil-legacy.cb8c79b1.js"
}, {
    "revision": null,
    "url": "assets/fil.a5fa0635.js"
}, {
    "revision": null,
    "url": "assets/Forget-legacy.99dcbf35.js"
}, {
    "revision": null,
    "url": "assets/Forget.bfd5af0e.js"
}, {
    "revision": null,
    "url": "assets/Forget.d70471d1.css"
}, {
    "revision": null,
    "url": "assets/fr-legacy.14abe38a.js"
}, {
    "revision": null,
    "url": "assets/fr.ab906098.js"
}, {
    "revision": null,
    "url": "assets/GameGridList-legacy.f347a291.js"
}, {
    "revision": null,
    "url": "assets/GameGridList.cdb52a19.js"
}, {
    "revision": null,
    "url": "assets/groupBy-legacy.e27f1efd.js"
}, {
    "revision": null,
    "url": "assets/groupBy.32a78a71.js"
}, {
    "revision": null,
    "url": "assets/Help-legacy.91ca0fb8.js"
}, {
    "revision": null,
    "url": "assets/Help.9e72e430.css"
}, {
    "revision": null,
    "url": "assets/Help.ebbc86b1.js"
}, {
    "revision": null,
    "url": "assets/hi-legacy.da7c0f97.js"
}, {
    "revision": null,
    "url": "assets/hi.9c672c71.js"
}, {
    "revision": null,
    "url": "assets/id-legacy.d1882c86.js"
}, {
    "revision": null,
    "url": "assets/id.1b6b4b06.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.0c378079.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.0da68cd4.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.0e18dd2e.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.0e4c8e70.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.16ecceda.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.1a47b3f8.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.1a7e25ba.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.1b3e8e96.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.1e01579d.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.1f2c31d2.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.1f31f668.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.22f1e06b.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.2ddbcdbf.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.3815d8bc.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.3c8191bd.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.3e1a8ce2.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.4c2f4f60.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.4d8f4b63.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.502af912.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.639b76ea.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.6822fc0a.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.75f4d4a8.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.783d8441.js"
}, {
    "revision": null,
    "url": "assets/Index-legacy.78d7f544.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.7927f6b9.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.83635553.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.85f2a2ac.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.882fdf2c.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.8d14c722.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.933b9f73.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.9f2b3b38.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.b68fa998.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.b934ad34.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.b97da824.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.bc07a1b2.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.be34cd7f.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.c035f732.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.c63816a3.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.cf80189e.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.d36961e4.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.d4d1f001.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.d728565f.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.d793c785.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.d7d7f75c.js"
}, {
    "revision": null,
    "url": "assets/Index-legacy.da162c0a.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.da662b62.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.dad8d349.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.e4afa3fb.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.f5b79b81.js"
}, {
    "revision": null,
    "url": "assets/index-legacy.f78b2113.js"
}, {
    "revision": null,
    "url": "assets/index.00887f8a.js"
}, {
    "revision": null,
    "url": "assets/index.0256f538.js"
}, {
    "revision": null,
    "url": "assets/index.0b6c216e.css"
}, {
    "revision": null,
    "url": "assets/index.0c51eedb.css"
}, {
    "revision": null,
    "url": "assets/index.0c7f8f00.js"
}, {
    "revision": null,
    "url": "assets/index.0c864e2e.js"
}, {
    "revision": null,
    "url": "assets/index.0ca5c56e.js"
}, {
    "revision": null,
    "url": "assets/index.0f905f7c.js"
}, {
    "revision": null,
    "url": "assets/index.124b3a97.css"
}, {
    "revision": null,
    "url": "assets/index.13955eae.js"
}, {
    "revision": null,
    "url": "assets/Index.14ba68f6.js"
}, {
    "revision": null,
    "url": "assets/index.15da5a68.js"
}, {
    "revision": null,
    "url": "assets/index.1dafa7c9.js"
}, {
    "revision": null,
    "url": "assets/index.1e1ba22c.js"
}, {
    "revision": null,
    "url": "assets/index.1e3d119b.css"
}, {
    "revision": null,
    "url": "assets/index.213fb132.js"
}, {
    "revision": null,
    "url": "assets/index.2165d095.js"
}, {
    "revision": null,
    "url": "assets/index.224b076e.js"
}, {
    "revision": null,
    "url": "assets/index.2863ce07.css"
}, {
    "revision": null,
    "url": "assets/index.28d31fd3.js"
}, {
    "revision": null,
    "url": "assets/index.30eaacc6.css"
}, {
    "revision": null,
    "url": "assets/index.311d9cde.css"
}, {
    "revision": null,
    "url": "assets/index.31785ad7.js"
}, {
    "revision": null,
    "url": "assets/index.33e63fac.js"
}, {
    "revision": null,
    "url": "assets/index.353ddb5f.js"
}, {
    "revision": null,
    "url": "assets/index.3587ef8a.js"
}, {
    "revision": null,
    "url": "assets/index.405e445a.css"
}, {
    "revision": null,
    "url": "assets/index.43a62a2d.js"
}, {
    "revision": null,
    "url": "assets/index.4707174a.css"
}, {
    "revision": null,
    "url": "assets/index.4f4c8870.css"
}, {
    "revision": null,
    "url": "assets/Index.546d9396.js"
}, {
    "revision": null,
    "url": "assets/index.5660e014.js"
}, {
    "revision": null,
    "url": "assets/index.5790217d.js"
}, {
    "revision": null,
    "url": "assets/index.580c2c9f.js"
}, {
    "revision": null,
    "url": "assets/index.5b7c9508.js"
}, {
    "revision": null,
    "url": "assets/index.5ea024ac.js"
}, {
    "revision": null,
    "url": "assets/index.5fe2664c.css"
}, {
    "revision": null,
    "url": "assets/index.62fd7def.css"
}, {
    "revision": null,
    "url": "assets/index.63596fe7.js"
}, {
    "revision": null,
    "url": "assets/Index.63af21cd.css"
}, {
    "revision": null,
    "url": "assets/index.65a85ef1.js"
}, {
    "revision": null,
    "url": "assets/index.66bd79f3.css"
}, {
    "revision": null,
    "url": "assets/index.66c2d13f.js"
}, {
    "revision": null,
    "url": "assets/index.748f0435.js"
}, {
    "revision": null,
    "url": "assets/index.813086b6.js"
}, {
    "revision": null,
    "url": "assets/index.8496a0b5.css"
}, {
    "revision": null,
    "url": "assets/index.89450fd0.js"
}, {
    "revision": null,
    "url": "assets/index.8cd9265f.js"
}, {
    "revision": null,
    "url": "assets/index.8fea648a.css"
}, {
    "revision": null,
    "url": "assets/index.93ebc253.css"
}, {
    "revision": null,
    "url": "assets/index.9d1f68c1.js"
}, {
    "revision": null,
    "url": "assets/index.a22bfee5.js"
}, {
    "revision": null,
    "url": "assets/index.a50c6d70.css"
}, {
    "revision": null,
    "url": "assets/index.a7ebdec1.css"
}, {
    "revision": null,
    "url": "assets/index.a9d7f673.js"
}, {
    "revision": null,
    "url": "assets/index.ac972af3.js"
}, {
    "revision": null,
    "url": "assets/index.b0b86985.css"
}, {
    "revision": null,
    "url": "assets/index.b1ecfc75.css"
}, {
    "revision": null,
    "url": "assets/index.b72d17a4.css"
}, {
    "revision": null,
    "url": "assets/index.b7cf7e65.css"
}, {
    "revision": null,
    "url": "assets/index.bf8fee9b.css"
}, {
    "revision": null,
    "url": "assets/index.c2ffbda2.css"
}, {
    "revision": null,
    "url": "assets/index.c4257482.js"
}, {
    "revision": null,
    "url": "assets/index.ca0a6bf5.css"
}, {
    "revision": null,
    "url": "assets/index.cb346d15.css"
}, {
    "revision": null,
    "url": "assets/index.cda2ed4c.js"
}, {
    "revision": null,
    "url": "assets/index.d1cc30fe.js"
}, {
    "revision": null,
    "url": "assets/index.d71e4992.js"
}, {
    "revision": null,
    "url": "assets/index.d98adb84.css"
}, {
    "revision": null,
    "url": "assets/index.db14e1c5.js"
}, {
    "revision": null,
    "url": "assets/index.dbb2a3c3.css"
}, {
    "revision": null,
    "url": "assets/index.df728ac6.js"
}, {
    "revision": null,
    "url": "assets/index.e18e7395.js"
}, {
    "revision": null,
    "url": "assets/Index.e2d736d8.css"
}, {
    "revision": null,
    "url": "assets/index.e425da3e.js"
}, {
    "revision": null,
    "url": "assets/index.e494ce52.js"
}, {
    "revision": null,
    "url": "assets/index.ea2ff7ad.css"
}, {
    "revision": null,
    "url": "assets/index.eb82389b.css"
}, {
    "revision": null,
    "url": "assets/index.f142689d.css"
}, {
    "revision": null,
    "url": "assets/index.f52303f2.css"
}, {
    "revision": null,
    "url": "assets/index.f6f6a9f8.css"
}, {
    "revision": null,
    "url": "assets/index.f7dd6567.css"
}, {
    "revision": null,
    "url": "assets/index.f9020f5f.css"
}, {
    "revision": null,
    "url": "assets/index.f955f396.js"
}, {
    "revision": null,
    "url": "assets/index.f9ac493b.css"
}, {
    "revision": null,
    "url": "assets/index.fba0f852.js"
}, {
    "revision": null,
    "url": "assets/index.fbab6d6e.css"
}, {
    "revision": null,
    "url": "assets/index.fd32d484.js"
}, {
    "revision": null,
    "url": "assets/index.fd4a92cd.js"
}, {
    "revision": null,
    "url": "assets/isNumber-legacy.2173475b.js"
}, {
    "revision": null,
    "url": "assets/isNumber.e6a0b83d.js"
}, {
    "revision": null,
    "url": "assets/ja-legacy.06dfe9ce.js"
}, {
    "revision": null,
    "url": "assets/ja.bc8ad138.js"
}, {
    "revision": null,
    "url": "assets/ko-legacy.5d3e111c.js"
}, {
    "revision": null,
    "url": "assets/ko.ceee8e97.js"
}, {
    "revision": null,
    "url": "assets/LiveStatsContent-legacy.e6562f72.js"
}, {
    "revision": null,
    "url": "assets/LiveStatsContent.4728189e.js"
}, {
    "revision": null,
    "url": "assets/LiveStatsContent.b7e36df9.css"
}, {
    "revision": null,
    "url": "assets/Login-legacy.1d174dc1.js"
}, {
    "revision": null,
    "url": "assets/Login.766089d8.js"
}, {
    "revision": null,
    "url": "assets/Login.f477971e.css"
}, {
    "revision": null,
    "url": "assets/lottie_svg-legacy.f4de75d2.js"
}, {
    "revision": null,
    "url": "assets/lottie_svg.30bb6926.js"
}, {
    "revision": null,
    "url": "assets/metamaskSupport-legacy.299b90e5.js"
}, {
    "revision": null,
    "url": "assets/metamaskSupport.90ef09ac.js"
}, {
    "revision": null,
    "url": "assets/MobileMain-legacy.0f7115fe.js"
}, {
    "revision": null,
    "url": "assets/MobileMain.5e66e77a.css"
}, {
    "revision": null,
    "url": "assets/MobileMain.a52b912f.js"
}, {
    "revision": null,
    "url": "assets/my-legacy.07f19cd5.js"
}, {
    "revision": null,
    "url": "assets/my.8d14c23f.js"
}, {
    "revision": null,
    "url": "assets/Notice-legacy.dfdf82ec.js"
}, {
    "revision": null,
    "url": "assets/Notice.7bf82fea.js"
}, {
    "revision": null,
    "url": "assets/Notice.7d23036f.css"
}, {
    "revision": null,
    "url": "assets/orderBy-legacy.8ec86cd8.js"
}, {
    "revision": null,
    "url": "assets/orderBy.f789bf7c.js"
}, {
    "revision": null,
    "url": "assets/output-legacy.5ee25de5.js"
}, {
    "revision": null,
    "url": "assets/output.02af5cb4.js"
}, {
    "revision": null,
    "url": "assets/output.95298072.css"
}, {
    "revision": null,
    "url": "assets/ParticleLayer-legacy.7d8a2fe7.js"
}, {
    "revision": null,
    "url": "assets/ParticleLayer.c79234af.css"
}, {
    "revision": null,
    "url": "assets/ParticleLayer.cd462544.js"
}, {
    "revision": null,
    "url": "assets/polyfills-legacy.b12e501e.js"
}, {
    "revision": null,
    "url": "assets/polyfills-modern.a2083245.js"
}, {
    "revision": null,
    "url": "assets/PrivacyDialog-legacy.fd615938.js"
}, {
    "revision": null,
    "url": "assets/PrivacyDialog.3e39ed66.js"
}, {
    "revision": null,
    "url": "assets/ProviderGatePage-legacy.f2b5dae1.js"
}, {
    "revision": null,
    "url": "assets/ProviderGatePage.11a99a0d.js"
}, {
    "revision": null,
    "url": "assets/pt-legacy.900c00dc.js"
}, {
    "revision": null,
    "url": "assets/pt.104dc1fc.js"
}, {
    "revision": null,
    "url": "assets/recaptcha-legacy.25b9e06f.js"
}, {
    "revision": null,
    "url": "assets/recaptcha.733974fe.js"
}, {
    "revision": null,
    "url": "assets/Recharge-legacy.9ab1a8b8.js"
}, {
    "revision": null,
    "url": "assets/Recharge.d9231fd2.css"
}, {
    "revision": null,
    "url": "assets/Recharge.dd90f56a.js"
}, {
    "revision": null,
    "url": "assets/ru-legacy.d66554fd.js"
}, {
    "revision": null,
    "url": "assets/ru.904198f7.js"
}, {
    "revision": null,
    "url": "assets/scatterSupport-legacy.4e4c36b2.js"
}, {
    "revision": null,
    "url": "assets/scatterSupport.0b9af2c5.js"
}, {
    "revision": null,
    "url": "assets/SearchMain-legacy.a046a004.js"
}, {
    "revision": null,
    "url": "assets/SearchMain.333b7fe9.css"
}, {
    "revision": null,
    "url": "assets/SearchMain.c2c71d96.js"
}, {
    "revision": null,
    "url": "assets/SlotsILayout-legacy.1806ac34.js"
}, {
    "revision": null,
    "url": "assets/SlotsILayout.6c2e9401.css"
}, {
    "revision": null,
    "url": "assets/SlotsILayout.9efb7986.js"
}, {
    "revision": null,
    "url": "assets/slotsUtils-legacy.7a3241f8.js"
}, {
    "revision": null,
    "url": "assets/slotsUtils.a0534c25.js"
}, {
    "revision": null,
    "url": "assets/sortedIndex-legacy.d589089a.js"
}, {
    "revision": null,
    "url": "assets/sortedIndex.797c00a7.js"
}, {
    "revision": null,
    "url": "assets/Spin-legacy.f30e3032.js"
}, {
    "revision": null,
    "url": "assets/Spin.5600103e.js"
}, {
    "revision": null,
    "url": "assets/Spin.a695ed16.css"
}, {
    "revision": null,
    "url": "assets/SpinBtnParticles-legacy.060ab491.js"
}, {
    "revision": null,
    "url": "assets/SpinBtnParticles.bdfb78ad.js"
}, {
    "revision": null,
    "url": "assets/SpinResultParticles-legacy.28de04b6.js"
}, {
    "revision": null,
    "url": "assets/SpinResultParticles.22db9602.css"
}, {
    "revision": null,
    "url": "assets/SpinResultParticles.34fbe296.js"
}, {
    "revision": null,
    "url": "assets/Starting-legacy.4ad822d7.js"
}, {
    "revision": null,
    "url": "assets/Starting.795e63bd.css"
}, {
    "revision": null,
    "url": "assets/Starting.ffca29ec.js"
}, {
    "revision": null,
    "url": "assets/Status-legacy.2a2ead2f.js"
}, {
    "revision": null,
    "url": "assets/Status.b3f67f4f.js"
}, {
    "revision": null,
    "url": "assets/Status.f93259cc.css"
}, {
    "revision": null,
    "url": "assets/TagList-legacy.67b9f04d.js"
}, {
    "revision": null,
    "url": "assets/TagList.4bc00562.js"
}, {
    "revision": null,
    "url": "assets/th-legacy.4028fd97.js"
}, {
    "revision": null,
    "url": "assets/th.f9e74bfc.js"
}, {
    "revision": null,
    "url": "assets/tr-legacy.ba25361f.js"
}, {
    "revision": null,
    "url": "assets/tr.8ce1ea51.js"
}, {
    "revision": null,
    "url": "assets/trackpoint-async.0b6ee815.js"
}, {
    "revision": null,
    "url": "assets/useLocalStore-legacy.1fead82d.js"
}, {
    "revision": null,
    "url": "assets/useLocalStore.bece1955.js"
}, {
    "revision": null,
    "url": "assets/usePixiGsap-legacy.da7819c2.js"
}, {
    "revision": null,
    "url": "assets/usePixiGsap.e2a036a0.js"
}, {
    "revision": null,
    "url": "assets/vi-legacy.d522aa2a.js"
}, {
    "revision": null,
    "url": "assets/vi.ad59915e.js"
}, {
    "revision": null,
    "url": "assets/walletConnect-legacy.45d7e3ca.js"
}, {
    "revision": null,
    "url": "assets/walletConnect.4d74af93.js"
}, {
    "revision": null,
    "url": "assets/wr_utils.dist-legacy.d1a559a8.js"
}, {
    "revision": null,
    "url": "assets/wr_utils.dist.271197d9.js"
}, {
    "revision": "5d21f28719b1f770e7a83aef3dd7c8d3",
    "url": "index.html"
}, {
    "revision": "88f8513a7b1dd3bcf81c2d44ec8ffa0e",
    "url": "softswiss.html"
}, {
    "revision": "2c75525d29652090ca50495091a8b598",
    "url": "android-chrome-192x192.png"
}, {
    "revision": "4baa61d7e38689a1922193b04476bd91",
    "url": "android-chrome-512x512.png"
}, {
    "revision": "34f2d328564d8408bc8f538c39395b17",
    "url": "manifest.webmanifest"
}].filter(a => !a.url.endsWith(".html"));
ae();
re(ce);
self.addEventListener("message", a => {
    a.data && a.data.type === "SKIP_WAITING" && self.skipWaiting()
});
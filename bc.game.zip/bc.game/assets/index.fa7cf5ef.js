var Me = Object.defineProperty,
    Ae = Object.defineProperties;
var Te = Object.getOwnPropertyDescriptors;
var z = Object.getOwnPropertySymbols;
var te = Object.prototype.hasOwnProperty,
    se = Object.prototype.propertyIsEnumerable;
var le = (t, a, l) => a in t ? Me(t, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: l
    }) : t[a] = l,
    N = (t, a) => {
        for (var l in a || (a = {})) te.call(a, l) && le(t, l, a[l]);
        if (z)
            for (var l of z(a)) se.call(a, l) && le(t, l, a[l]);
        return t
    },
    I = (t, a) => Ae(t, Te(a));
var ie = (t, a) => {
    var l = {};
    for (var s in t) te.call(t, s) && a.indexOf(s) < 0 && (l[s] = t[s]);
    if (t != null && z)
        for (var s of z(t)) a.indexOf(s) < 0 && se.call(t, s) && (l[s] = t[s]);
    return l
};
import {
    cE as ke,
    cF as ne,
    cG as Re,
    o as b,
    u as v,
    r as f,
    cy as Ee,
    j as i,
    a as e,
    bf as T,
    d as u,
    cH as Le,
    ax as Q,
    s as h,
    J as re,
    z as Be,
    t as A,
    q as m,
    D as j,
    ao as L,
    $ as S,
    G as g,
    a3 as $,
    A as O,
    cd as Ge,
    bW as xe,
    F as V,
    ah as oe,
    cI as Oe,
    cA as k,
    b as P,
    _ as pe,
    cJ as We,
    bt as H,
    a0 as ge,
    am as _,
    p as W,
    I as ze,
    bi as Ue,
    cK as ve,
    S as me,
    ar as Ke,
    v as J,
    ba as Ve,
    bb as R,
    cL as He,
    aq as qe,
    a5 as be,
    an as je,
    cM as $e,
    x as D,
    ca as M,
    b2 as Je,
    C as Z,
    e as X,
    az as Ze,
    cN as Ye,
    br as he,
    be as ee
} from "./index.28e31dff.js";
import {
    c as q
} from "./index.65304255.js";
import {
    C as Qe
} from "./CheckPassword.46c08afc.js";

function Xe(t, a, l) {
    var s = t == null ? 0 : t.length;
    return s ? (l && typeof l != "number" && ke(t, a, l) ? (a = 0, l = s) : (a = a == null ? 0 : ne(a), l = l === void 0 ? s : ne(l)), Re(t, a, l)) : []
}
const ea = b(function() {
        const a = v(),
            l = f.exports.useContext(Ee),
            s = Object.values(l.langs).map(n => ({
                label: n.name,
                value: n.code
            }));
        return i("div", {
            className: la,
            children: [i("div", {
                className: "fullname-item",
                children: [e("p", {
                    children: a("page.setting.general.fullname")
                }), e(T, {
                    value: u.settings.currencyFullName,
                    onChange: n => {
                        u.settings.currencyFullName = n
                    }
                })]
            }), i("div", {
                className: "fullname-item",
                children: [i("div", {
                    children: [e("p", {
                        children: a("page.setting.general.currency")
                    }), e(aa, {})]
                }), e(T, {
                    value: u.settings.enableLocaleCurrency,
                    onChange: n => u.settings.enableLocaleCurrency = n
                })]
            }), i("div", {
                children: [e("p", {
                    children: a("page.setting.general.appearance")
                }), e(Le, {})]
            }), i("div", {
                children: [e("p", {
                    children: a("common.language")
                }), e(Q, {
                    value: l.lng,
                    options: s,
                    onChange: l.setLang,
                    top: h.isMobile,
                    className: "language-select"
                })]
            })]
        })
    }),
    aa = b(function() {
        const a = f.exports.useMemo(() => Object.values(re.localCurrencys).map(({
                label: s,
                value: n
            }) => ({
                label: s,
                value: n
            })), []),
            l = f.exports.useCallback(s => i("div", {
                className: "local-option",
                children: [e(Be, {
                    name: s.label
                }), s.label]
            }), []);
        return e(Q, {
            className: "local-select",
            value: re.localCurrency.value,
            onChange: s => u.settings.localeCurrencyName = s,
            options: a,
            renderLabel: l,
            renderOption: l
        })
    });
A({
    cl1: [m("#98a7b5", .15), m("#5f6975", .15)],
    cl2: ["#f5f6f7", "#31373d"],
    cl3: [m("#25272e", .8), "#f5f6fa"],
    cl4: [m("#1e2024", .6), "#f5f6fa"],
    cl5: ["rgba(49,52,60,0.6)", "#fff"],
    gd1: ["linear-gradient(to left, #555966, #555966, #58ae14)", "linear-gradient(to left, #fff, #fff, #7bc514)"]
});
const la = "geuyjf6";
const ta = t => S.get("/user/setting/privacy/" + t + "/"),
    sa = t => S.post("/user/setting/privacy/set/", t),
    fe = function() {
        const a = v(),
            [l, s] = L({
                allowOnlyFriendPrivate: !1,
                hideGameData: !1,
                hideName: !1,
                refuseTip: !1,
                refuseFriendRequest: !1,
                hideOnlineStatus: !1,
                loading: !0
            });
        f.exports.useEffect(() => {
            n()
        }, []);
        const n = async () => {
                await u.inited, ta(u.uid).then(o => {
                    s({
                        allowOnlyFriendPrivate: o.allowOnlyFriendPrivate,
                        hideGameData: o.hideGameData,
                        hideName: o.hideName,
                        refuseTip: o.refuseTip,
                        refuseFriendRequest: o.refuseFriendRequest,
                        hideOnlineStatus: o.hideOnlineStatus,
                        loading: !1
                    })
                }).catch(g)
            },
            r = (o, d) => {
                sa(o).then(w => {
                    s(N({}, o)), g(d)
                }).catch(g)
            };
        return l.loading ? e($, {}) : i("div", {
            className: ia,
            children: [i("div", {
                className: "item",
                children: [i("p", {
                    children: [e("span", {
                        children: a("page.setting.privacy.gamedata")
                    }), e("span", {
                        className: "bottom",
                        children: a("page.setting.privacy.gamedata.intro")
                    })]
                }), e(T, {
                    value: l.hideGameData,
                    onChange: o => {
                        const d = a(o ? "page.setting.privacy.gamedata_enable" : "page.setting.privacy.gamedata_disable");
                        r({
                            hideGameData: o
                        }, d)
                    }
                })]
            }), i("div", {
                className: "item",
                children: [i("p", {
                    children: [e("span", {
                        children: a("page.setting.privacy.username")
                    }), e("span", {
                        className: "bottom",
                        children: a("page.setting.privacy.username.intro")
                    })]
                }), e(T, {
                    value: l.hideName,
                    onChange: o => {
                        const d = a(o ? "page.setting.privacy.username_enable" : "page.setting.privacy.username_disable");
                        r({
                            hideName: o
                        }, d)
                    }
                })]
            }), i("div", {
                className: "item",
                children: [e("p", {
                    children: e("span", {
                        children: a("page.setting.privacy.online")
                    })
                }), e(T, {
                    value: l.hideOnlineStatus,
                    onChange: o => {
                        const d = a(o ? "page.setting.privacy.online_enable" : "page.setting.privacy.online_disable");
                        r({
                            hideOnlineStatus: o
                        }, d)
                    }
                })]
            }), i("div", {
                className: "item",
                children: [e("p", {
                    children: e("span", {
                        children: a("page.setting.privacy.messages")
                    })
                }), e(T, {
                    value: !l.allowOnlyFriendPrivate,
                    onChange: o => {
                        const d = a(o ? "page.setting.privacy.messages_disable" : "page.setting.privacy.messages_enable");
                        r({
                            allowOnlyFriendPrivate: !o
                        }, d)
                    }
                })]
            }), i("div", {
                className: "item",
                children: [e("p", {
                    children: e("span", {
                        children: a("page.setting.privacy.friend")
                    })
                }), e(T, {
                    value: l.refuseFriendRequest,
                    onChange: o => {
                        const d = a(o ? "page.setting.privacy.friend_enable" : "page.setting.privacy.friend_disable");
                        r({
                            refuseFriendRequest: o
                        }, d)
                    }
                })]
            }), i("div", {
                className: "item",
                children: [e("p", {
                    children: e("span", {
                        children: a("page.setting.privacy.tip")
                    })
                }), e(T, {
                    value: l.refuseTip,
                    onChange: o => {
                        const d = a(o ? "page.setting.privacy.tip_enable" : "page.setting.privacy.tip_disable");
                        r({
                            refuseTip: o
                        }, d)
                    }
                })]
            })]
        })
    };

function nl() {
    const t = v();
    return e(j, {
        title: t("page.setting.privacy"),
        children: e(fe, {})
    })
}
A({
    cl1: ["inherit", m("#5f6975", .8)],
    cl2: ["rgba(152, 167, 181, 0.5)", m("#5f6975", .6)]
});
const ia = "phu2m35";
const B = function({
        labelNode: a,
        children: l,
        open: s
    }) {
        const [n, r] = f.exports.useState(s || !1);
        return i("div", {
            className: `${na} toggle-item`,
            children: [i("div", {
                className: "toggle-nav",
                onClick: () => r(!n),
                children: [a, e(O, {
                    className: "open-icon " + (n ? "open" : ""),
                    name: "Arrow"
                })]
            }), e(Ge, {
                visible: n,
                children: l
            })]
        })
    },
    na = "t1n92w9e";
const ra = function() {
        const a = v(),
            l = 10,
            [s, n] = L({
                list: [],
                loading: !0,
                renderList: [],
                total: 0,
                page: 1
            });
        f.exports.useEffect(() => {
            r()
        }, []);
        const r = () => {
                n({
                    loading: !0
                }), S.post("/user/online/status/my/").then(p => {
                    const y = p || [];
                    n({
                        loading: !1,
                        list: xe(y, l),
                        total: y.length,
                        renderList: Xe(y, 0, l)
                    })
                }).catch(g)
            },
            o = p => {
                const y = h.getServerTime().getTime() - p,
                    De = 60 * 1e3,
                    Pe = 60 * De,
                    _e = 24 * Pe;
                return y > _e ? new Date(p).toLocaleDateString() : new Date(p).toLocaleTimeString()
            },
            d = async p => {
                S.post(`/user/online/status/my/${p}/off/`).then(y => {
                    r()
                })
            },
            w = p => p.map((y, Y) => i(B, {
                labelNode: y.device,
                open: Y === 0,
                children: [i("div", {
                    className: "session-toggle",
                    children: [e("span", {
                        children: a("page.setting.sessions.browser")
                    }), e("span", {
                        children: y.device
                    })]
                }), i("div", {
                    className: "session-toggle",
                    children: [e("span", {
                        children: a("page.setting.sessions.near")
                    }), e("span", {
                        children: y.area || "-"
                    })]
                }), i("div", {
                    className: "session-toggle",
                    children: [e("span", {
                        children: a("page.setting.sessions.ipAddress")
                    }), e("span", {
                        children: y.ip || "-"
                    })]
                }), i("div", {
                    className: "session-toggle",
                    children: [e("span", {
                        children: a("page.setting.sessions.lastUsed")
                    }), e("span", {
                        children: y.myself ? a("page.setting.sessions.online") : o(y.lastTime)
                    })]
                }), i("div", {
                    className: "session-toggle",
                    children: [e("span", {
                        children: a("page.setting.sessions.action")
                    }), e("span", {
                        children: y.myself ? a("page.setting.sessions.using") : e("button", {
                            className: "remove-btn",
                            onClick: () => d(y.deviceId),
                            children: a("page.setting.sessions.removeDevice")
                        })
                    })]
                })]
            }, "toggle-" + Y)),
            F = p => {
                n({
                    renderList: s.list[p - 1],
                    page: p
                })
            };
        return s.loading ? e("div", {
            className: `${oa} full-abs`,
            children: e($, {})
        }) : e("div", {
            className: ca,
            children: h.isMobile ? i(V, {
                children: [w(s.renderList), e(oe, {
                    className: ce,
                    type: "pageConic3",
                    page: s.page,
                    total: s.total,
                    onChange: F,
                    limit: 10
                })]
            }) : i(V, {
                children: [e("p", {
                    className: "title",
                    children: a("page.setting.sessions.title")
                }), e("div", {
                    className: "session-table",
                    children: i(Oe, {
                        children: [e("thead", {
                            children: i("tr", {
                                children: [e("th", {
                                    children: a("page.setting.sessions.browser")
                                }), e("th", {
                                    children: a("page.setting.sessions.near")
                                }), e("th", {
                                    children: a("page.setting.sessions.ipAddress")
                                }), e("th", {
                                    children: a("page.setting.sessions.lastUsed")
                                }), e("th", {
                                    children: a("page.setting.sessions.action")
                                })]
                            })
                        }), e("tbody", {
                            children: s.renderList.map((p, y) => i("tr", {
                                children: [e("td", {
                                    className: "white-td",
                                    children: p.device || "-"
                                }), e("td", {
                                    children: p.area || "-"
                                }), e("td", {
                                    className: "white-td",
                                    children: p.ip || "-"
                                }), e("td", {
                                    children: p.myself ? a("page.setting.sessions.online") : o(p.lastTime)
                                }), e("td", {
                                    className: "white-td",
                                    children: p.myself ? a("page.setting.sessions.using") : e("div", {
                                        className: "remove-btn",
                                        onClick: () => d(p.deviceId),
                                        children: a("page.setting.sessions.removeDevice")
                                    })
                                })]
                            }, "tr-" + y))
                        })]
                    })
                }), e(oe, {
                    className: ce,
                    type: "pageConic3",
                    page: s.page,
                    total: s.total,
                    onChange: F,
                    limit: 10
                })]
            })
        })
    },
    oa = "l1itdpae";
A({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [m("#23262a", .5), m("#ffffff", .5)],
    cl3: ["inherit", "#31373d"]
});
const ca = "sqrn934";
A({
    cl1: [m("#18191d", .3), m("#e9eaf2", .3)]
});
const ce = "pga45ru";
const ye = function() {
        const a = v(),
            [l, s] = L({
                oldPassword: "",
                newPassword: "",
                repeatPassword: "",
                googleWord: "",
                loading: !1
            }),
            n = async () => {
                if (!l.oldPassword || !l.newPassword || !l.repeatPassword) return;
                if (l.newPassword !== l.repeatPassword) return g(new Error(a("page.settings.password_seem")));
                if (l.newPassword === l.oldPassword) return g(new Error(a("page.setting.security.samePassword")));
                const r = await pe(!0);
                let o, d;
                r ? (o = r.code, d = r.timestamp) : (o = "", d = h.getServerTime().getTime());
                const w = {
                    oldPassword: String(We(String(H(l.oldPassword)), d.toString())),
                    newPassword: String(H(l.newPassword)),
                    code: o,
                    timestamp: d
                };
                s({
                    loading: !0
                });
                try {
                    await S.post("/user/password/change/", w), s({
                        loading: !1
                    }), u.handleLogout()
                } catch (F) {
                    s({
                        loading: !1
                    }), g(F), F && F.code === ge.TWOFA_ERROR && n()
                }
            };
        return i("div", {
            className: da,
            children: [e(k, {
                label: a("page.settings.password_old"),
                value: l.oldPassword,
                size: "small",
                onChange: r => s({
                    oldPassword: r
                })
            }), e(k, {
                label: a("page.settings.password_new"),
                value: l.newPassword,
                size: "small",
                onChange: r => s({
                    newPassword: r
                })
            }), e(k, {
                label: a("page.setting.security.confirm_password"),
                value: l.repeatPassword,
                size: "small",
                onChange: r => s({
                    repeatPassword: r
                })
            }), i("p", {
                className: "tips",
                children: [e("span", {
                    children: e(O, {
                        name: "Inform"
                    })
                }), a("page.setting.security.modify_tips")]
            }), e(P, {
                type: "conic",
                onClick: n,
                disabled: l.loading,
                children: a("page.setting.security.saveChange")
            })]
        })
    },
    da = "c124enjs";
const Ne = b(function() {
        const a = v(),
            l = async () => {
                if (await W.confirm(a("common.messages.confirm_email"))) try {
                    await S.get("/user/verify/email/send/"), g(a("common.messages.send_success"))
                } catch (n) {
                    g(n)
                }
            };
        return i("div", {
            className: ua,
            children: [e("p", {
                children: "According to the security policy of BC.GAME, the registered email cannot be changed."
            }), e(_, {
                value: u.email,
                readOnly: !0,
                size: "small",
                bold: !0,
                children: u.emailVerified && i("div", {
                    className: "verified",
                    children: [e("span", {
                        className: "icon-wrap",
                        children: e(O, {
                            name: "Check"
                        })
                    }), e("span", {
                        children: a("page.setting.security.verified")
                    })]
                })
            }), !u.emailVerified && e(P, {
                type: "conic",
                onClick: l,
                children: a("common.verify")
            })]
        })
    }),
    ua = "e1g8cfat";
const ae = b(function({
        isDialog: a
    }) {
        const l = v(),
            [s, n] = L({
                qrcode: "",
                googlecode: "",
                password: "",
                secret: "",
                loading: !1
            });
        f.exports.useEffect(() => {
            r()
        }, []);
        const r = () => {
                S.get("/user/google/2-step-auth/key/text/").then(d => {
                    const w = Ke.getApiURL("/user/google/2-step-auth/key/qrcode/320/") + "?t=" + Date.now();
                    n({
                        secret: d,
                        qrcode: w
                    })
                }).catch(g)
            },
            o = () => {
                n({
                    loading: !0
                });
                const w = h.getServerTime().getTime();
                S.post("/user/google/2-step-auth/start/v2/", {
                    code: s.googlecode,
                    timestamp: w,
                    password: String(q.exports.HmacSHA256(String(q.exports.MD5(s.password)), w.toString()))
                }).then(F => {
                    g(l("page.settings.twostep_enable_success")), localStorage.setItem("twoStepWarning", "1"), u.google2StepAuth = !0, n({
                        loading: !1,
                        googlecode: ""
                    }), a && J.back()
                }).catch(F => {
                    g(F), n({
                        loading: !1
                    })
                })
            };
        return i("div", {
            className: pa,
            children: [e("div", {
                className: "google-step-summary-top",
                children: e(ze, {
                    k: "page.settings.twostep_tips1",
                    children: e("a", {
                        target: "_blank",
                        rel: "noopener noreferrer",
                        href: "https://support.google.com/accounts/answer/1066447?hl=en&rd=1",
                        children: l("page.settings.twostep_tips2_google")
                    })
                })
            }), e("div", {
                className: "google-step-summary-top two",
                children: l("page.settings.twostep_tips2")
            }), e("div", {
                className: "qrcode-warp",
                children: e("img", {
                    src: s.qrcode,
                    alt: "qrcode"
                })
            }), e("div", {
                className: "copy-input",
                children: e(Ue, {
                    label: l("page.settings.twostep_secret"),
                    value: s.secret,
                    readOnly: !0,
                    size: "small"
                })
            }), e("p", {
                className: "twofa-alert",
                children: l("page.settings.twostep_tips4")
            }), i("div", {
                className: "codes",
                children: [e("p", {
                    children: l("page.setting.security.code")
                }), e(ve, {
                    value: s.googlecode,
                    onChange: d => n({
                        googlecode: d
                    })
                })]
            }), u.passwordExist && e(k, {
                value: s.password,
                size: "small",
                autoComplete: "new-password",
                onChange: d => n({
                    password: d
                }),
                placeholder: l("page.settings.password")
            }), e(P, {
                type: "conic",
                onClick: o,
                disabled: s.loading,
                children: l("page.setting.security.enable")
            })]
        })
    }),
    pa = "t1v2m6cs",
    rl = function() {
        const a = v();
        return e(j, {
            title: a("title.settings_twostep"),
            size: [464, 720],
            children: e(me, {
                className: ga,
                children: e(ae, {
                    isDialog: !0
                })
            })
        })
    };
A({
    cl1: ["#2d3035", "#e9eaf2"],
    cl2: ["rgba(45, 48, 53, 0.5)", "#f6f7fa"],
    cl3: ["#f5f6f7", "#f6f7fa"],
    cl4: [m("#b0b3bf", .1), "#e9eaf2"],
    cl5: ["#f5f6f7", "#31373d"]
});
const ga = "d1n6yu4f",
    Se = b(function() {
        const a = v(),
            [l, s] = L({
                email: "",
                password: "",
                loading: !1
            }),
            n = async () => {
                if (l.loading || !l.email || !l.password) return !1;
                s({
                    loading: !0
                });
                let r = {};
                u.google2StepAuth && (r = await pe()), (!u.google2StepAuth || u.google2StepAuth && r) && (await S.post("/user/open/user/init/", {
                    code: r.code ? r.code : "",
                    email: l.email,
                    password: String(H(l.password))
                }).then(o => {
                    u.email = l.email, u.passwordExist = !0, g(a("common.messages.modify_success"))
                }).catch(o => {
                    g(o), o && o.code === ge.TWOFA_ERROR && n()
                }), s({
                    loading: !1
                }))
            };
        return i("div", {
            children: [e(_, {
                label: a("page.settings.email"),
                value: l.email,
                onChange: r => s({
                    email: r
                }),
                size: "small",
                bold: !0
            }), e(k, {
                label: a("page.settings.password"),
                value: l.password,
                size: "small",
                onChange: r => s({
                    password: r
                })
            }), e(P, {
                type: "conic",
                disabled: l.loading,
                onClick: n,
                children: a("common.actions.confirm")
            })]
        })
    });
const we = b(function() {
        const a = v(),
            [l, s] = L({
                googlecode: "",
                password: "",
                loading: !1
            }),
            n = () => {
                if (!l.googlecode) return;
                s({
                    loading: !0
                });
                const o = h.getServerTime().getTime();
                S.post("/user/google/2-step-auth/stop/v2/", {
                    code: l.googlecode,
                    timestamp: o,
                    password: String(q.exports.HmacSHA256(String(q.exports.MD5(l.password)), o.toString()))
                }).then(d => {
                    g(a("page.settings.twostep_disable_success")), u.google2StepAuth = !1, s({
                        loading: !1
                    })
                }).catch(d => {
                    g(d), s({
                        loading: !1
                    })
                })
            };
        return i("div", {
            className: va,
            children: [e("p", {
                children: a("page.setting.security.disable_twofa")
            }), u.passwordExist && e(k, {
                value: l.password,
                size: "small",
                onChange: r => s({
                    password: r
                }),
                label: a("page.settings.password")
            }), i("div", {
                className: "codes",
                children: [e("p", {
                    children: a("page.setting.security.code")
                }), e(ve, {
                    value: l.googlecode,
                    onChange: r => s({
                        googlecode: r
                    })
                })]
            }), e(P, {
                type: "conic",
                disabled: l.loading,
                onClick: n,
                children: a("page.setting.security.disable_btn")
            })]
        })
    }),
    va = "d1dawyfe";
const ma = b(function() {
        return h.isMobile ? e(fa, {}) : e(ba, {})
    }),
    ba = b(function() {
        const a = v();
        return i("div", {
            className: ha,
            children: [e("div", {
                className: "wrap",
                children: u.email ? i("div", {
                    className: "box",
                    children: [e("p", {
                        children: a("page.setting.security.changeWord")
                    }), e(ye, {})]
                }) : i("div", {
                    className: "box",
                    children: [e("p", {
                        children: a("page.setting.security.bind_email")
                    }), e(Se, {})]
                })
            }), e("div", {
                className: "wrap",
                children: i("div", {
                    className: "box",
                    children: [e("p", {
                        children: a("page.setting.security.twoFactor")
                    }), u.google2StepAuth ? e(we, {}) : e(ae, {})]
                })
            }), u.email && i(V, {
                children: [e("div", {
                    className: "wrap",
                    children: i("div", {
                        className: "box",
                        children: [e("p", {
                            children: a("page.setting.security.emailVerify")
                        }), e(Ne, {})]
                    })
                }), e("div", {
                    className: "wrap",
                    style: {
                        visibility: "hidden",
                        minHeight: "auto"
                    }
                })]
            })]
        })
    });
A({
    cl1: [m("#98a7b5", .15), m("#5f6975", .15)],
    cl2: ["#f5f6f7", "#31373d"]
});
const ha = "s5do71x",
    fa = b(function() {
        const a = v();
        return i("div", {
            className: ya,
            children: [u.email ? e(B, {
                labelNode: a("page.setting.security.changeWord"),
                open: !0,
                children: e(ye, {})
            }) : e(B, {
                labelNode: a("page.setting.security.bind_email"),
                open: !0,
                children: e(Se, {})
            }), e(B, {
                labelNode: a("page.setting.security.twoFactor"),
                children: u.google2StepAuth ? e(we, {}) : e(ae, {})
            }), u.email && e(B, {
                labelNode: a("page.setting.security.emailVerify"),
                children: e(Ne, {})
            })]
        })
    }),
    ya = "sq2onql";
var Ce = [{
        label: "Afghanistan",
        value: "AF"
    }, {
        label: "\xC5land Islands",
        value: "AX"
    }, {
        label: "Albania",
        value: "AL"
    }, {
        label: "Algeria",
        value: "DZ"
    }, {
        label: "American Samoa",
        value: "AS"
    }, {
        label: "Andorra",
        value: "AD"
    }, {
        label: "Angola",
        value: "AO"
    }, {
        label: "Anguilla",
        value: "AI"
    }, {
        label: "Antarctica",
        value: "AQ"
    }, {
        label: "Antigua and Barbuda",
        value: "AG"
    }, {
        label: "Argentina",
        value: "AR"
    }, {
        label: "Armenia",
        value: "AM"
    }, {
        label: "Aruba",
        value: "AW"
    }, {
        label: "Australia",
        value: "AU"
    }, {
        label: "Austria",
        value: "AT"
    }, {
        label: "Azerbaijan",
        value: "AZ"
    }, {
        label: "Bahamas",
        value: "BS"
    }, {
        label: "Bahrain",
        value: "BH"
    }, {
        label: "Bangladesh",
        value: "BD"
    }, {
        label: "Barbados",
        value: "BB"
    }, {
        label: "Belarus",
        value: "BY"
    }, {
        label: "Belgium",
        value: "BE"
    }, {
        label: "Belize",
        value: "BZ"
    }, {
        label: "Benin",
        value: "BJ"
    }, {
        label: "Bermuda",
        value: "BM"
    }, {
        label: "Bhutan",
        value: "BT"
    }, {
        label: "Bolivia (Plurinational State of)",
        value: "BO"
    }, {
        label: "Bonaire, Sint Eustatius and Saba",
        value: "BQ"
    }, {
        label: "Bosnia and Herzegovina",
        value: "BA"
    }, {
        label: "Botswana",
        value: "BW"
    }, {
        label: "Bouvet Island",
        value: "BV"
    }, {
        label: "Brazil",
        value: "BR"
    }, {
        label: "British Indian Ocean Territory",
        value: "IO"
    }, {
        label: "United States Minor Outlying Islands",
        value: "UM"
    }, {
        label: "Virgin Islands (British)",
        value: "VG"
    }, {
        label: "Virgin Islands (U.S.)",
        value: "VI"
    }, {
        label: "Brunei Darussalam",
        value: "BN"
    }, {
        label: "Bulgaria",
        value: "BG"
    }, {
        label: "Burkina Faso",
        value: "BF"
    }, {
        label: "Burundi",
        value: "BI"
    }, {
        label: "Cambodia",
        value: "KH"
    }, {
        label: "Cameroon",
        value: "CM"
    }, {
        label: "Canada",
        value: "CA"
    }, {
        label: "Cabo Verde",
        value: "CV"
    }, {
        label: "Cayman Islands",
        value: "KY"
    }, {
        label: "Central African Republic",
        value: "CF"
    }, {
        label: "Chad",
        value: "TD"
    }, {
        label: "Chile",
        value: "CL"
    }, {
        label: "China",
        value: "CN"
    }, {
        label: "Christmas Island",
        value: "CX"
    }, {
        label: "Cocos (Keeling) Islands",
        value: "CC"
    }, {
        label: "Colombia",
        value: "CO"
    }, {
        label: "Comoros",
        value: "KM"
    }, {
        label: "Congo",
        value: "CG"
    }, {
        label: "Congo (Democratic Republic of the)",
        value: "CD"
    }, {
        label: "Cook Islands",
        value: "CK"
    }, {
        label: "Costa Rica",
        value: "CR"
    }, {
        label: "Croatia",
        value: "HR"
    }, {
        label: "Cuba",
        value: "CU"
    }, {
        label: "Cura\xE7ao",
        value: "CW"
    }, {
        label: "Cyprus",
        value: "CY"
    }, {
        label: "Czech Republic",
        value: "CZ"
    }, {
        label: "Denmark",
        value: "DK"
    }, {
        label: "Djibouti",
        value: "DJ"
    }, {
        label: "Dominica",
        value: "DM"
    }, {
        label: "Dominican Republic",
        value: "DO"
    }, {
        label: "Ecuador",
        value: "EC"
    }, {
        label: "Egypt",
        value: "EG"
    }, {
        label: "El Salvador",
        value: "SV"
    }, {
        label: "Equatorial Guinea",
        value: "GQ"
    }, {
        label: "Eritrea",
        value: "ER"
    }, {
        label: "Estonia",
        value: "EE"
    }, {
        label: "Ethiopia",
        value: "ET"
    }, {
        label: "Falkland Islands (Malvinas)",
        value: "FK"
    }, {
        label: "Faroe Islands",
        value: "FO"
    }, {
        label: "Fiji",
        value: "FJ"
    }, {
        label: "Finland",
        value: "FI"
    }, {
        label: "France",
        value: "FR"
    }, {
        label: "French Guiana",
        value: "GF"
    }, {
        label: "French Polynesia",
        value: "PF"
    }, {
        label: "French Southern Territories",
        value: "TF"
    }, {
        label: "Gabon",
        value: "GA"
    }, {
        label: "Gambia",
        value: "GM"
    }, {
        label: "Georgia",
        value: "GE"
    }, {
        label: "Germany",
        value: "DE"
    }, {
        label: "Ghana",
        value: "GH"
    }, {
        label: "Gibraltar",
        value: "GI"
    }, {
        label: "Greece",
        value: "GR"
    }, {
        label: "Greenland",
        value: "GL"
    }, {
        label: "Grenada",
        value: "GD"
    }, {
        label: "Guadeloupe",
        value: "GP"
    }, {
        label: "Guam",
        value: "GU"
    }, {
        label: "Guatemala",
        value: "GT"
    }, {
        label: "Guernsey",
        value: "GG"
    }, {
        label: "Guinea",
        value: "GN"
    }, {
        label: "Guinea-Bissau",
        value: "GW"
    }, {
        label: "Guyana",
        value: "GY"
    }, {
        label: "Haiti",
        value: "HT"
    }, {
        label: "Heard Island and McDonald Islands",
        value: "HM"
    }, {
        label: "Holy See",
        value: "VA"
    }, {
        label: "Honduras",
        value: "HN"
    }, {
        label: "Hong Kong",
        value: "HK"
    }, {
        label: "Hungary",
        value: "HU"
    }, {
        label: "Iceland",
        value: "IS"
    }, {
        label: "India",
        value: "IN"
    }, {
        label: "Indonesia",
        value: "ID"
    }, {
        label: "C\xF4te d'Ivoire",
        value: "CI"
    }, {
        label: "Iran (Islamic Republic of)",
        value: "IR"
    }, {
        label: "Iraq",
        value: "IQ"
    }, {
        label: "Ireland",
        value: "IE"
    }, {
        label: "Isle of Man",
        value: "IM"
    }, {
        label: "Israel",
        value: "IL"
    }, {
        label: "Italy",
        value: "IT"
    }, {
        label: "Jamaica",
        value: "JM"
    }, {
        label: "Japan",
        value: "JP"
    }, {
        label: "Jersey",
        value: "JE"
    }, {
        label: "Jordan",
        value: "JO"
    }, {
        label: "Kazakhstan",
        value: "KZ"
    }, {
        label: "Kenya",
        value: "KE"
    }, {
        label: "Kiribati",
        value: "KI"
    }, {
        label: "Kuwait",
        value: "KW"
    }, {
        label: "Kyrgyzstan",
        value: "KG"
    }, {
        label: "Lao People's Democratic Republic",
        value: "LA"
    }, {
        label: "Latvia",
        value: "LV"
    }, {
        label: "Lebanon",
        value: "LB"
    }, {
        label: "Lesotho",
        value: "LS"
    }, {
        label: "Liberia",
        value: "LR"
    }, {
        label: "Libya",
        value: "LY"
    }, {
        label: "Liechtenstein",
        value: "LI"
    }, {
        label: "Lithuania",
        value: "LT"
    }, {
        label: "Luxembourg",
        value: "LU"
    }, {
        label: "Macao",
        value: "MO"
    }, {
        label: "Macedonia (the former Yugoslav Republic of)",
        value: "MK"
    }, {
        label: "Madagascar",
        value: "MG"
    }, {
        label: "Malawi",
        value: "MW"
    }, {
        label: "Malaysia",
        value: "MY"
    }, {
        label: "Maldives",
        value: "MV"
    }, {
        label: "Mali",
        value: "ML"
    }, {
        label: "Malta",
        value: "MT"
    }, {
        label: "Marshall Islands",
        value: "MH"
    }, {
        label: "Martinique",
        value: "MQ"
    }, {
        label: "Mauritania",
        value: "MR"
    }, {
        label: "Mauritius",
        value: "MU"
    }, {
        label: "Mayotte",
        value: "YT"
    }, {
        label: "Mexico",
        value: "MX"
    }, {
        label: "Micronesia (Federated States of)",
        value: "FM"
    }, {
        label: "Moldova (Republic of)",
        value: "MD"
    }, {
        label: "Monaco",
        value: "MC"
    }, {
        label: "Mongolia",
        value: "MN"
    }, {
        label: "Montenegro",
        value: "ME"
    }, {
        label: "Montserrat",
        value: "MS"
    }, {
        label: "Morocco",
        value: "MA"
    }, {
        label: "Mozambique",
        value: "MZ"
    }, {
        label: "Myanmar",
        value: "MM"
    }, {
        label: "Namibia",
        value: "NA"
    }, {
        label: "Nauru",
        value: "NR"
    }, {
        label: "Nepal",
        value: "NP"
    }, {
        label: "Netherlands",
        value: "NL"
    }, {
        label: "New Caledonia",
        value: "NC"
    }, {
        label: "New Zealand",
        value: "NZ"
    }, {
        label: "Nicaragua",
        value: "NI"
    }, {
        label: "Niger",
        value: "NE"
    }, {
        label: "Nigeria",
        value: "NG"
    }, {
        label: "Niue",
        value: "NU"
    }, {
        label: "Norfolk Island",
        value: "NF"
    }, {
        label: "Korea (Democratic People's Republic of)",
        value: "KP"
    }, {
        label: "Northern Mariana Islands",
        value: "MP"
    }, {
        label: "Norway",
        value: "NO"
    }, {
        label: "Oman",
        value: "OM"
    }, {
        label: "Pakistan",
        value: "PK"
    }, {
        label: "Palau",
        value: "PW"
    }, {
        label: "Palestine, State of",
        value: "PS"
    }, {
        label: "Panama",
        value: "PA"
    }, {
        label: "Papua New Guinea",
        value: "PG"
    }, {
        label: "Paraguay",
        value: "PY"
    }, {
        label: "Peru",
        value: "PE"
    }, {
        label: "Philippines",
        value: "PH"
    }, {
        label: "Pitcairn",
        value: "PN"
    }, {
        label: "Poland",
        value: "PL"
    }, {
        label: "Portugal",
        value: "PT"
    }, {
        label: "Puerto Rico",
        value: "PR"
    }, {
        label: "Qatar",
        value: "QA"
    }, {
        label: "Republic of Kosovo",
        value: "XK"
    }, {
        label: "R\xE9union",
        value: "RE"
    }, {
        label: "Romania",
        value: "RO"
    }, {
        label: "Russian Federation",
        value: "RU"
    }, {
        label: "Rwanda",
        value: "RW"
    }, {
        label: "Saint Barth\xE9lemy",
        value: "BL"
    }, {
        label: "Saint Helena, Ascension and Tristan da Cunha",
        value: "SH"
    }, {
        label: "Saint Kitts and Nevis",
        value: "KN"
    }, {
        label: "Saint Lucia",
        value: "LC"
    }, {
        label: "Saint Martin (French part)",
        value: "MF"
    }, {
        label: "Saint Pierre and Miquelon",
        value: "PM"
    }, {
        label: "Saint Vincent and the Grenadines",
        value: "VC"
    }, {
        label: "Samoa",
        value: "WS"
    }, {
        label: "San Marino",
        value: "SM"
    }, {
        label: "Sao Tome and Principe",
        value: "ST"
    }, {
        label: "Saudi Arabia",
        value: "SA"
    }, {
        label: "Senegal",
        value: "SN"
    }, {
        label: "Serbia",
        value: "RS"
    }, {
        label: "Seychelles",
        value: "SC"
    }, {
        label: "Sierra Leone",
        value: "SL"
    }, {
        label: "Singapore",
        value: "SG"
    }, {
        label: "Sint Maarten (Dutch part)",
        value: "SX"
    }, {
        label: "Slovakia",
        value: "SK"
    }, {
        label: "Slovenia",
        value: "SI"
    }, {
        label: "Solomon Islands",
        value: "SB"
    }, {
        label: "Somalia",
        value: "SO"
    }, {
        label: "South Africa",
        value: "ZA"
    }, {
        label: "South Georgia and the South Sandwich Islands",
        value: "GS"
    }, {
        label: "Korea (Republic of)",
        value: "KR"
    }, {
        label: "South Sudan",
        value: "SS"
    }, {
        label: "Spain",
        value: "ES"
    }, {
        label: "Sri Lanka",
        value: "LK"
    }, {
        label: "Sudan",
        value: "SD"
    }, {
        label: "Suriname",
        value: "SR"
    }, {
        label: "Svalbard and Jan Mayen",
        value: "SJ"
    }, {
        label: "Swaziland",
        value: "SZ"
    }, {
        label: "Sweden",
        value: "SE"
    }, {
        label: "Switzerland",
        value: "CH"
    }, {
        label: "Syrian Arab Republic",
        value: "SY"
    }, {
        label: "Taiwan",
        value: "TW"
    }, {
        label: "Tajikistan",
        value: "TJ"
    }, {
        label: "Tanzania, United Republic of",
        value: "TZ"
    }, {
        label: "Thailand",
        value: "TH"
    }, {
        label: "Timor-Leste",
        value: "TL"
    }, {
        label: "Togo",
        value: "TG"
    }, {
        label: "Tokelau",
        value: "TK"
    }, {
        label: "Tonga",
        value: "TO"
    }, {
        label: "Trinidad and Tobago",
        value: "TT"
    }, {
        label: "Tunisia",
        value: "TN"
    }, {
        label: "Turkey",
        value: "TR"
    }, {
        label: "Turkmenistan",
        value: "TM"
    }, {
        label: "Turks and Caicos Islands",
        value: "TC"
    }, {
        label: "Tuvalu",
        value: "TV"
    }, {
        label: "Uganda",
        value: "UG"
    }, {
        label: "Ukraine",
        value: "UA"
    }, {
        label: "United Arab Emirates",
        value: "AE"
    }, {
        label: "United Kingdom of Great Britain and Northern Ireland",
        value: "GB"
    }, {
        label: "United States of America",
        value: "US"
    }, {
        label: "Uruguay",
        value: "UY"
    }, {
        label: "Uzbekistan",
        value: "UZ"
    }, {
        label: "Vanuatu",
        value: "VU"
    }, {
        label: "Venezuela (Bolivarian Republic of)",
        value: "VE"
    }, {
        label: "Viet Nam",
        value: "VN"
    }, {
        label: "Wallis and Futuna",
        value: "WF"
    }, {
        label: "Western Sahara",
        value: "EH"
    }, {
        label: "Yemen",
        value: "YE"
    }, {
        label: "Zambia",
        value: "ZM"
    }, {
        label: "Zimbabwe",
        value: "ZW"
    }],
    G = (t => (t[t.NORMAL = 0] = "NORMAL", t[t.WAITING = 1] = "WAITING", t[t.FAILED = 2] = "FAILED", t[t.SUCCESSED = 3] = "SUCCESSED", t))(G || {});
const Na = {
    address: C(""),
    birthday: C(""),
    city: C(""),
    country: C(Ce[0].value),
    firstName: C(""),
    lastName: C(""),
    gender: C("Male"),
    state: C(""),
    zipCode: C(""),
    idFront: C(""),
    idBack: C(""),
    passport: C(""),
    residence: C(""),
    verification: C("")
};

function C(t) {
    return {
        value: t,
        reason: ""
    }
}
class Sa {
    constructor() {
        this.isInited = !1, this.stepIndex = 0, this.stepField = [
            ["address", "firstName", "lastName", "city", "country", "zipCode", "gender", "birthday"],
            ["idFront", "idBack", "passport"],
            ["residence"],
            ["verification"]
        ], this.isFirstSubmit = !0, this.stepInfo = [0, 0, 0, 0], this.status = 0, this.formData = Na, this.countryData = Ce, Ve(this, {
            isInited: R,
            stepIndex: R,
            isFirstSubmit: R,
            stepInfo: R,
            status: R,
            formData: R
        }), u.waitLogin().then(() => this.init())
    }
    async init() {
        const [a, l] = await Promise.all([S.get("/user/kyc/get/"), S.get("/user/kyc/getItems/")]);
        this.status = a.statusReview, Object.entries(l).forEach(([s, n]) => {
            const r = this.formData[s];
            if (r) {
                if (s === "birthday") {
                    const o = String(n.value || "");
                    o.length === 8 && (n.value = `${o.slice(0,4)}-${o.slice(4,6)}-${o.slice(6)}`)
                }
                r.value = n.value, r.reason = n.reviewFailReason || ""
            }
        }), this.stepInfo.forEach((s, n) => {
            let r = !1;
            n === 1 ? r = this.checkFilled(this.stepField[n].slice(0, 2)) || this.checkFilled(this.stepField[n].slice(2)) : r = this.checkFilled(this.stepField[n]), r ? this.status === 3 ? this.stepInfo[n] = 3 : this.checkError(this.stepField[n]) ? (this.stepInfo[n] = 2, this.stepIndex = Math.min(this.stepIndex, n)) : (this.stepInfo[n] = 1, this.stepIndex = Math.max(this.stepIndex, n + 1)) : this.stepInfo[n] = 0
        }), this.isInited = !0
    }
    checkFilled(a) {
        for (let l of a)
            if (!Boolean(this.formData[l].value)) return !1;
        return !0
    }
    checkError(a) {
        if (this.status !== 2) return !1;
        for (let l of a)
            if (Boolean(this.formData[l].reason)) return !0;
        return !1
    }
    async setKycProfiles() {
        const {
            address: a,
            birthday: l,
            city: s,
            country: n,
            firstName: r,
            gender: o,
            zipCode: d,
            lastName: w
        } = this.formData;
        await S.post("/user/kyc/profiles/", {
            address: a.value,
            birthday: l.value.replace(/\-/g, ""),
            city: s.value,
            country: n.value,
            firstName: r.value,
            lastName: w.value,
            gender: o.value,
            zipCode: d.value
        }), this.filledAndNext(0)
    }
    async uploadIdCard() {
        const a = {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        };
        let [l, s] = await Promise.all([this.getBlobFromUrl(this.formData.idFront.value), this.getBlobFromUrl(this.formData.idBack.value)]);
        if (l && s) {
            const n = new FormData;
            n.append("idFront", l), n.append("idBack", s), await S.post("/user/kyc/upload/id/", n, a)
        }
        this.filledAndNext(1)
    }
    async uploadProof(a) {
        const l = {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        };
        let s = await this.getBlobFromUrl(this.formData[a].value);
        if (s) {
            const n = new FormData;
            n.append("file", s), n.append("type", a), await S.post("/user/kyc/upload/proof/", n, l)
        }
        switch (a) {
            case "passport":
                this.filledAndNext(1);
                break;
            case "residence":
                this.filledAndNext(2);
                break;
            default:
                this.filledAndNext(3), this.status = 1;
                break
        }
    }
    filledAndNext(a) {
        this.stepInfo[a] = 1, this.stepIndex = a + 1
    }
    bindFormData(a) {
        return He(this.formData[a], "value")
    }
    async getBlobFromUrl(a) {
        return a.indexOf("blob:") === 0 ? (await qe({
            method: "get",
            url: a,
            responseType: "blob"
        })).data : null
    }
}
const c = new Sa;

function wa(t) {
    return "step__item flex-center " + ["normal", "filled", "failed", "successed", "current"][t]
}

function Ca() {
    const {
        FAILED: t,
        SUCCESSED: a
    } = G;
    return e("div", {
        className: `${Ia} flex-center`,
        children: c.stepInfo.map((l, s) => i(be.Fragment, {
            children: [i("button", {
                className: wa(c.stepIndex === s ? 4 : l),
                onClick: l > 1 ? () => c.stepIndex = s : void 0,
                children: [h.isMobile ? `0${s+1}` : `Step 0${s+1}`, [t, a].includes(l) && e("div", {
                    className: "status flex-center",
                    children: e(O, {
                        name: l === t ? "Close" : "Check"
                    })
                })]
            }), s !== 3 && e("div", {
                className: "step__line"
            })]
        }, s))
    })
}
var Fa = b(Ca);
A({
    cl1: ["transparent", "#f5f6fa"],
    cl2: ["inhert", "#5f6975"],
    cl3: ["#3b3f4a", "transparent"],
    cl4: ["#f5f6f7", "#31373d"],
    cl5: ["transparent", "#e9eaf2"],
    cl6: [m("#5da000", .5), m("#7bc514", .5)]
});
const Ia = "snxyckq";
const Da = [{
    label: "Male",
    value: "Male"
}, {
    label: "Female",
    value: "Female"
}, {
    label: "Unspecified",
    value: "Unspecified"
}];

function Pa() {
    const t = v(),
        [a, l] = f.exports.useState(c.stepInfo[0] !== G.NORMAL),
        s = a ? [$e.require] : [],
        n = async () => {
            try {
                return l(!0), c.stepField[0].find(o => !c.formData[o].value) ? void 0 : await c.setKycProfiles()
            } catch (r) {
                g(r)
            }
        };
    return i("div", {
        className: `step step1 ${Aa}`,
        children: [e("div", {
            className: "step__tip",
            children: t("page.setting.verify.step_1.tit")
        }), i("div", {
            className: "step1__form",
            children: [i("div", {
                className: "inline",
                children: [e(_, I(N({
                    label: t("page.setting.first_name")
                }, c.bindFormData("firstName")), {
                    size: "small",
                    validates: s
                })), e(_, I(N({
                    label: t("page.setting.last_name")
                }, c.bindFormData("lastName")), {
                    size: "small",
                    validates: s
                }))]
            }), i("div", {
                className: "inline",
                children: [e(de, I(N({
                    label: t("page.setting.verify.gender")
                }, c.bindFormData("gender")), {
                    options: Da
                })), e(_, I(N({
                    label: t("page.setting.verify.birthDate")
                }, c.bindFormData("birthday")), {
                    validates: s,
                    size: "small",
                    type: "date",
                    pattern: "[0-9]{4}-[0-9]{2}-[0-9]{2}"
                }))]
            }), e("div", {
                className: "line"
            }), e(_, I(N({
                label: t("common.address")
            }, c.bindFormData("address")), {
                size: "small",
                validates: s
            })), i("div", {
                className: "inline",
                children: [e(_, I(N({
                    label: t("page.setting.verify.postalcode")
                }, c.bindFormData("zipCode")), {
                    size: "small",
                    validates: s
                })), e(_, I(N({
                    label: t("page.setting.verify.city")
                }, c.bindFormData("city")), {
                    size: "small",
                    validates: s
                }))]
            }), e("div", {
                className: "inline",
                children: e(de, I(N({
                    label: t("page.setting.verify.country")
                }, c.bindFormData("country")), {
                    options: c.countryData
                }))
            })]
        }), e(P, {
            type: "conic",
            className: "submit",
            onClick: n,
            children: t("page.record.next")
        })]
    })
}
var _a = b(Pa);

function de(n) {
    var r = n,
        {
            label: t,
            className: a,
            disabled: l
        } = r,
        s = ie(r, ["label", "className", "disabled"]);
    return e(je, {
        label: t,
        className: a,
        disabled: l,
        size: "small",
        children: e("div", {
            className: "input-control",
            children: e(Q, I(N({
                className: Ma,
                disabled: l
            }, s), {
                disableHover: !0
            }))
        })
    })
}
const Ma = "l17va9s1",
    Aa = "s1s55ghb";
var U = "/assets/id-back.75c38598.svg",
    K = "/assets/id-back-w.0e997eb6.svg";
var E = (t => (t[t.ID_FRONT = 0] = "ID_FRONT", t[t.ID_BACK = 1] = "ID_BACK", t[t.PASSPORT = 2] = "PASSPORT", t[t.PROOF = 3] = "PROOF", t[t.SELF = 4] = "SELF", t))(E || {});
const Ta = [{
    name: "ID_FRONT",
    title: D.t("page.setting.verify.frontside"),
    image: () => h.isDarken ? M.id : M.idWhite,
    tip: D.t("page.setting.verify.config_1")
}, {
    name: "ID_BACK",
    title: D.t("page.setting.verify.backside"),
    image: () => h.isDarken ? U : K,
    tip: D.t("page.setting.verify.config_2")
}, {
    name: "PASSPORT",
    title: D.t("page.setting.verify.passport"),
    image: () => h.isDarken ? U : K,
    tip: D.t("page.setting.verify.config_3")
}, {
    name: "PROOF",
    title: D.t("page.setting.verify.proof"),
    image: () => h.isDarken ? U : K,
    tip: D.t("page.setting.verify.config_3")
}, {
    name: "SELF",
    title: D.t("page.setting.verify.your_photo"),
    image: () => h.isDarken ? U : K,
    tip: D.t("page.setting.verify.config_3")
}];

function ka({
    type: t,
    value: a,
    onChange: l,
    reason: s,
    children: n
}) {
    const r = Ta[t],
        o = f.exports.useRef(null),
        d = f.exports.useRef("");

    function w(F) {
        if (!F.target.files) return;
        const p = F.target.files[0];
        if (p.size > 20971520) return g(new Error("File size is too large"));
        if (!/(jpg|png|jpeg)/.test(p.type)) return g(new Error("Please upload the correct image format(jpg,png)"));
        !p || (d.current && URL.revokeObjectURL(d.current), d.current = URL.createObjectURL(p), l(d.current), F.target.value = "")
    }
    return i("div", {
        className: `${Ra} image-item`,
        children: [i("div", {
            className: "title-wrap",
            children: [e("div", {
                className: "title",
                children: r.title
            }), n]
        }), i("div", {
            className: `image-wrap ${s?"reason":""}`,
            children: [e("img", {
                className: "image",
                src: a || r.image(),
                alt: "img"
            }), s && e("div", {
                className: "reason-tip",
                children: s
            })]
        }), e("div", {
            className: "image-tip",
            children: r.tip
        }), e("div", {
            className: "image-choose",
            children: i("button", {
                className: "choose",
                children: [e("input", {
                    className: "input-file",
                    type: "file",
                    accept: "image/*",
                    ref: o,
                    onChange: w
                }), e("span", {
                    children: "Choose File"
                })]
            })
        })]
    })
}
var x = b(ka);
const Ra = "c1ygo6v8";
const Ea = b(function() {
        const a = v();
        return i("div", {
            children: [e("div", {
                className: "step__tip",
                children: a("page.setting.verify.step_2.tit")
            }), i("div", {
                className: "images flex-between",
                children: [e(x, N({
                    type: E.ID_FRONT
                }, c.bindFormData("idFront"))), e(x, N({
                    type: E.ID_BACK
                }, c.bindFormData("idBack")))]
            })]
        })
    }),
    La = b(function() {
        return i("div", {
            children: [e("div", {
                className: "step__tip",
                children: "Please upload the personal page of your passport, which includes your photo, name, date of birth, passport number and other personal information. Please make sure your passport is within the validity period."
            }), e("div", {
                className: "images flex-center",
                children: e(x, N({
                    type: E.PASSPORT
                }, c.bindFormData("passport")))
            })]
        })
    }),
    Ba = [{
        label: "ID Card",
        value: Ea,
        type: 0
    }, {
        label: "Passport",
        value: La,
        type: 1
    }];

function Ga() {
    const t = v(),
        [a, l] = f.exports.useState(0),
        s = a === 0 ? c.stepField[1].slice(0, 2) : c.stepField[1].slice(2),
        n = Boolean(s.find(o => !c.formData[o].value)),
        r = async () => {
            try {
                return a === 0 ? await c.uploadIdCard() : await c.uploadProof("passport")
            } catch (o) {
                g(o)
            }
        };
    return i("div", {
        className: `${Oa} step step2`,
        children: [e("div", {
            className: "choose-tip",
            children: t("page.setting.verify.choose")
        }), e(Je, {
            value: a,
            tabs: Ba,
            onChange: l
        }), e(P, {
            type: "conic",
            className: "submit",
            disabled: n,
            onClick: r,
            children: t("page.record.next")
        })]
    })
}
var xa = b(Ga);
A({
    cl1: ["#eff0f0", m("#5f6975", .8)],
    cl2: ["#2d3037", "#f5f6fa"]
});
const Oa = "svf6l0f";
var Wa = b(function() {
    const a = v(),
        l = Boolean(c.stepField[2].find(s => !c.formData[s].value));
    return i("div", {
        className: `${za} step step3`,
        children: [e("div", {
            className: "step__tip",
            children: a("page.setting.verify.step_3.tit")
        }), e("div", {
            className: "images flex-center",
            children: e(x, N({
                type: E.PROOF
            }, c.bindFormData("residence")))
        }), e(P, {
            type: "conic",
            className: "submit",
            disabled: l,
            onClick: () => c.uploadProof("residence").catch(g),
            children: a("page.record.next")
        })]
    })
});
const za = "sdsbu73";
c.formData;

function Ua() {
    return h.isMobile ? h.isDarken ? M.exampleMobile : M.exampleMobileWhite : h.isDarken ? M.example : M.exampleWhite
}
var Ka = b(function() {
    const a = v(),
        l = Boolean(c.stepField[3].find(s => !c.formData[s].value));
    return i("div", {
        className: `${Ha} step step4`,
        children: [e("div", {
            className: "step__tip",
            children: a("page.setting.verify.step_4.tit")
        }), e("div", {
            className: "images flex-center",
            children: e(x, I(N({
                type: E.SELF
            }, c.bindFormData("verification")), {
                children: e("a", {
                    className: "ref",
                    onClick: () => W.push(e(Va, {})),
                    children: "References"
                })
            }))
        }), e(P, {
            type: "conic",
            className: "submit",
            disabled: l,
            onClick: () => c.uploadProof("verification").catch(g),
            children: a("page.record.next")
        })]
    })
});

function Va() {
    return i("div", {
        className: qa,
        children: [e(Z, {
            onClick: () => W.close()
        }), i(me, {
            bodyLock: !1,
            children: [e("img", {
                src: Ua(),
                alt: "example",
                className: "example"
            }), e("div", {
                className: "tip",
                children: "The left is the correct case, the right is the wrong case."
            })]
        })]
    })
}
const Ha = "s1hhkj4s",
    qa = "ewvrwgw";
var ue = "/assets/submitted.97e532a2.svg";

function ja() {
    const t = v(),
        a = c.stepIndex;

    function l() {
        switch (a) {
            case 1:
                return M.step_1;
            case 4:
                return M.step_3;
            default:
                return M.step_2
        }
    }
    return c.isInited ? i("div", {
        className: Za,
        children: [i("div", {
            className: "left",
            children: [e("div", {
                className: "title",
                children: t("page.setting.verify.title")
            }), e("div", {
                children: t("page.setting.verify.word_one")
            }), e("div", {
                className: "word",
                children: t("page.setting.verify.word_two")
            }), e("img", {
                className: "bc-img",
                alt: "bc",
                src: l()
            })]
        }), e("div", {
            className: "right",
            children: e(Ja, {})
        })]
    }) : e("div", {
        style: {
            height: 400
        },
        children: e($, {})
    })
}
var $a = b(ja);
const Ja = b(function() {
        const t = v();
        return c.status === G.WAITING ? i("div", {
            className: "complete",
            children: [e("img", {
                className: "submitted",
                src: ue,
                alt: "complete"
            }), e("div", {
                className: "ttu title",
                children: t("page.settings.verify.title1")
            }), e("div", {
                className: "desc",
                children: t("page.settings.verify.desc1")
            })]
        }) : c.status === G.SUCCESSED ? i("div", {
            className: "complete",
            children: [e("img", {
                className: "submitted",
                src: ue,
                alt: "complete"
            }), e("div", {
                className: "ttu title",
                children: t("page.settings.verify.title2")
            }), e("div", {
                className: "desc",
                children: t("page.settings.verify.desc2", h.env.siteName)
            })]
        }) : i(V, {
            children: [e(Fa, {}), i("div", {
                className: "step-main",
                children: [c.stepIndex === 0 && e(_a, {}), c.stepIndex === 1 && e(xa, {}), c.stepIndex === 2 && e(Wa, {}), c.stepIndex === 3 && e(Ka, {})]
            })]
        })
    }),
    Za = "v9qbj21";
const Ya = b(function() {
        const a = v(),
            l = X();
        f.exports.useEffect(() => {
            u.init().then(() => {
                u.userId === 0 && l("/", {
                    replace: !0
                })
            })
        }, []), f.exports.useEffect(() => {
            location.pathname === "/setting" && l("/setting/general", {
                replace: !0
            })
        }, [location.pathname]);
        const s = f.exports.useMemo(() => e(Ze, {
            prex: "/setting/",
            routes: [{
                label: a("page.setting.general"),
                path: "general",
                element: e(ea, {})
            }, {
                label: a("page.setting.privacy"),
                path: "privacy",
                element: e(fe, {})
            }, {
                label: a("page.setting.security"),
                path: "security",
                element: e(ma, {})
            }, {
                label: a("page.setting.session"),
                path: "session",
                element: e(ra, {})
            }, {
                label: a("page.setting.verify"),
                path: "verify",
                element: e($a, {})
            }]
        }), []);
        return u.isInited ? i("div", {
            className: `${el} setting-wrap`,
            id: "settings",
            children: [i(Ye, {
                children: [i("p", {
                    className: "title",
                    children: [e(O, {
                        name: "Setting"
                    }), e("span", {
                        children: h.isMobile ? a("title.settings") : a("page.setting.globalSetting")
                    })]
                }), e(Z, {
                    onClick: () => l(-1)
                })]
            }), s]
        }) : e(Qa, {})
    }),
    Qa = be.memo(function() {
        return e("div", {
            className: Xa,
            children: e($, {})
        })
    }),
    Xa = "srdr7m6";
A({
    cl1: [m("#1e2024", .6), "#f5f6fa"],
    cl2: [m("#1e2024", .6), m("#5f6975", .4)],
    cl3: [m("#23262a", .5), m("#f5f6fa", .5)],
    cl4: ["#f5f6f7", "#31373d"],
    cl5: [m("#1e2024", .6), "#fff"]
});
const el = "s1v641bu";
var ol = Ya;
const cl = function() {
        const t = v(),
            a = X(),
            [l] = he(),
            s = l.get("sign");
        return f.exports.useEffect(() => {
            s || (J.close(), a("/"))
        }, []), s ? e(j, {
            title: t("page.settings.reset_pstitle"),
            children: e(Fe, {
                type: "password",
                sign: s
            })
        }) : null
    },
    dl = function() {
        const t = v(),
            a = X(),
            [l] = he(),
            s = l.get("sign");
        return f.exports.useEffect(() => {
            s || (J.close(), a("/"))
        }, []), s ? e(j, {
            title: t("page.settings.reset_safe"),
            children: e(Fe, {
                type: "withdraw",
                sign: s
            })
        }) : null
    },
    Fe = function({
        type: t,
        sign: a
    }) {
        const l = v(),
            [s, n] = f.exports.useState(""),
            [r, o] = f.exports.useState(""),
            d = () => {
                if (s !== r) return g(l("page.settings.password_seem")), !1;
                if (s.length < 6) return g(l("page.settings.reset_minlen")), !1;
                const w = String(H(s));
                return S.post("/user/password/reset/", {
                    passWord: w,
                    sign: a
                }).then(() => {
                    J.close(), u.init()
                }).catch(g)
            };
        return i("div", {
            className: al,
            children: [e("img", {
                alt: "crocodile",
                src: ee.judge,
                className: "crocodile"
            }), e("p", {
                className: "title",
                children: l(t === "password" ? "page.settings.reset_pstitle" : "page.settings.reset_safe")
            }), e("p", {
                className: "subtitle",
                children: l("page.settings.reset_subtitle")
            }), i("div", {
                className: "input-area",
                children: [e(_, {
                    type: "password",
                    autoComplete: "off",
                    value: s,
                    onChange: n,
                    placeholder: l("page.settings.password_new"),
                    children: e(Qe, {
                        str: s
                    })
                }), e(k, {
                    placeholder: l("page.settings.password_repeat"),
                    value: r,
                    onChange: o
                })]
            }), e(P, {
                type: "conic",
                className: "confirm-btn",
                onClick: d,
                children: l("common.actions.confirm")
            })]
        })
    },
    al = "r1l6yk1a";
const ul = function() {
        const t = v();
        return i("div", {
            className: Ie,
            children: [e(Z, {
                onClick: () => W.close()
            }), e("img", {
                alt: "crocodile",
                src: ee.judge,
                className: "crocodile"
            }), e("p", {
                className: "title",
                children: t("page.settings.reset_expire")
            }), e("p", {
                className: "subtitle",
                children: t("page.settings.reset_error")
            })]
        })
    },
    pl = function() {
        const t = v();
        return i("div", {
            className: Ie,
            children: [e(Z, {
                onClick: () => W.close()
            }), e("img", {
                alt: "crocodile",
                src: ee.judge,
                className: "crocodile"
            }), e("p", {
                className: "title",
                children: t("page.settings.reset_invalid")
            }), e("p", {
                className: "subtitle",
                children: t("page.settings.reset_error")
            })]
        })
    },
    Ie = "i7hahzd";
export {
    ul as PasswordInvalidDialog, nl as PrivacyDialog, cl as ResetPassword, dl as ResetWithdraw, ol as Setting, rl as TwoFactorDialog, pl as WithdrawInvalidDialog
};
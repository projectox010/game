var pt = Object.defineProperty;
var U = Object.getOwnPropertySymbols;
var ut = Object.prototype.hasOwnProperty,
    dt = Object.prototype.propertyIsEnumerable;
var Y = (s, i, t) => i in s ? pt(s, i, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : s[i] = t,
    _ = (s, i) => {
        for (var t in i || (i = {})) ut.call(i, t) && Y(s, t, i[t]);
        if (U)
            for (var t of U(i)) dt.call(i, t) && Y(s, t, i[t]);
        return s
    };
var a = (s, i, t) => (Y(s, typeof i != "symbol" ? i + "" : i, t), t);
import {
    J as mt,
    cR as ft,
    o as A,
    du as C,
    r as z,
    a as n,
    dj as wt,
    j as p,
    F as yt,
    dk as bt,
    dl as gt,
    u as M,
    l as it,
    s as F,
    b as st,
    e9 as vt,
    a5 as W,
    dx as nt,
    dy as At,
    dz as kt,
    dG as xt,
    ed as St,
    dY as Ct,
    eb as Bt,
    dC as Ot,
    dZ as Tt,
    dD as Rt,
    dE as Gt,
    dp as S,
    bN as at,
    d_ as Dt,
    b0 as Mt,
    G as q,
    ba as Pt,
    bb as K,
    bc as It,
    dR as $,
    am as Z
} from "./index.28e31dff.js";
import {
    s as L
} from "./index.dd8128e8.js";
import {
    s as Vt
} from "./index.d71e4992.js";
import {
    C as w,
    c as D,
    E as Nt,
    k as Q,
    T as I,
    j as Et
} from "./usePixiGsap.bf451f35.js";
import {
    G as V
} from "./index.06a59a68.js";
var jt = {
        1: {
            8: [5.6, 2.1, 1.1, 1, .5, 1, 1.1, 2.1, 5.6],
            9: [5.6, 2, 1.6, 1, .7, .7, 1, 1.6, 2, 5.6],
            10: [8.9, 3, 1.4, 1.1, 1, .5, 1, 1.1, 1.4, 3, 8.9],
            11: [8.4, 3, 1.9, 1.3, 1, .7, .7, 1, 1.3, 1.9, 3, 8.4],
            12: [10, 3, 1.6, 1.4, 1.1, 1, .5, 1, 1.1, 1.4, 1.6, 3, 10],
            13: [8.1, 4, 3, 1.9, 1.2, .9, .7, .7, .9, 1.2, 1.9, 3, 4, 8.1],
            14: [7.1, 4, 1.9, 1.4, 1.3, 1.1, 1, .5, 1, 1.1, 1.3, 1.4, 1.9, 4, 7.1],
            15: [15, 8, 3, 2, 1.5, 1.1, 1, .7, .7, 1, 1.1, 1.5, 2, 3, 8, 15],
            16: [16, 9, 2, 1.4, 1.4, 1.2, 1.1, 1, .5, 1, 1.1, 1.2, 1.4, 1.4, 2, 9, 16]
        },
        2: {
            8: [13, 3, 1.3, .7, .4, .7, 1.3, 3, 13],
            9: [18, 4, 1.7, .9, .5, .5, .9, 1.7, 4, 18],
            10: [22, 5, 2, 1.4, .6, .4, .6, 1.4, 2, 5, 22],
            11: [24, 6, 3, 1.8, .7, .5, .5, .7, 1.8, 3, 6, 24],
            12: [33, 11, 4, 2, 1.1, .6, .3, .6, 1.1, 2, 4, 11, 33],
            13: [43, 13, 6, 3, 1.3, .7, .4, .4, .7, 1.3, 3, 6, 13, 43],
            14: [58, 15, 7, 4, 1.9, 1, .5, .2, .5, 1, 1.9, 4, 7, 15, 58],
            15: [88, 18, 11, 5, 3, 1.3, .5, .3, .3, .5, 1.3, 3, 5, 11, 18, 88],
            16: [110, 41, 10, 5, 3, 1.5, 1, .5, .3, .5, 1, 1.5, 3, 5, 10, 41, 110]
        },
        3: {
            8: [29, 4, 1.5, .3, .2, .3, 1.5, 4, 29],
            9: [43, 7, 2, .6, .2, .2, .6, 2, 7, 43],
            10: [76, 10, 3, .9, .3, .2, .3, .9, 3, 10, 76],
            11: [120, 14, 5.2, 1.4, .4, .2, .2, .4, 1.4, 5.2, 14, 120],
            12: [170, 24, 8.1, 2, .7, .2, .2, .2, .7, 2, 8.1, 24, 170],
            13: [260, 37, 11, 4, 1, .2, .2, .2, .2, 1, 4, 11, 37, 260],
            14: [420, 56, 18, 5, 1.9, .3, .2, .2, .2, .3, 1.9, 5, 18, 56, 420],
            15: [620, 83, 27, 8, 3, .5, .2, .2, .2, .2, .5, 3, 8, 27, 83, 620],
            16: [1e3, 130, 26, 9, 4, 2, .2, .2, .2, .2, .2, 2, 4, 9, 26, 130, 1e3]
        }
    },
    zt = "/assets/ball.3981f8e7.png",
    Ft = "/assets/pin.07d34b2f.png",
    Lt = "/assets/pin_active.b1038ad3.png",
    Ht = "/assets/target.f3e8ae2a.png",
    Wt = "/assets/tooltip.772bba85.png",
    Xt = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAeAgMAAAAN9pXcAAAADFBMVEUAAAD////29/v19voM4nzmAAAAA3RSTlMACr4sQLLfAAAAbklEQVQY023MoRGAMBQE0cNQAY5m0g6KVqgImkkTGECs2PwZzp3Yl/Ud1zOXf2S6hvu0ZB/+nRSgJ5lLHgBzAHMAcwDzAJgDmAOYA5gDmAOQC5ALkAuQC5ALkAuQC5ALkAuQC5ALnC1lW+qW/O8D/gHKSpbPJZcAAAAASUVORK5CYII=",
    Yt = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABUAAAAVCAYAAACpF6WWAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAFaADAAQAAAABAAAAFQAAAAAIGxIOAAAB9ElEQVQ4Ea2VT2vUUBTF733mdVRQCiZiM6MiFKq4KLRQN7rwC0jdiDtduhF3bhWX7twJfhiRrkQdcFdBXNhJEGeE0kXrZF5zvDc04XUyzGSkb3P/5HdO7ryXZIgaLpeEDxuizTDXix5kvRAamylmUMByK0uiH2qqUesZEjKzAJfuPSXgWsFJLOoZIp52Hb32BUfD7yBaLDkR7AbUWuZO8qfsjcepkx5y9sI3VLHW2h838uvapEjjsy53qzD5Lc7ptZhYX6C5iEYw9Jxz8zEwwVeO032f4SwN1wW7TTnWhV4TwXWATvnQtJyZDuXG2/ITumT4iyVscZaEn6Uhxie0mLvG0sJ9mfDniViKjyW7WewpknjF0WgLQPS/5szcD8je4Xb6rToopOGaA72X/Tw/r7Hs617AdJfjQVe11SNVNAzdY+K/85gWvOqODI+ZamGXBh/kNq/mMVW+0HmiatKqBz5d5U2SCXzNFIyrTbxKBoQrZV7GminndaiEJ0VGfYiaKYhrk8rp5vKYfNI4bjyJP2YKvDRM6JRCOdkhsXkXgG7YzmBDo9ZF/whSXnWlRmP1nGqB/uV4NDxIpLlLzG8DS2/4Yv+XXvMXfkeX3IieyXf2ibz3i7Z1ps3RTuozVa5fdfnLeIT+yrmqOSVRTvjHwM0FH/sHXD22t71XYMgAAAAASUVORK5CYII=";
const g = {
        ball: zt,
        pin: Ft,
        pin_active: Lt,
        target: Ht,
        tooltip: Wt,
        arrow: Xt,
        star: Yt
    },
    v = {};

function Qt(s) {
    return new Promise(i => {
        s.add(Object.values(g)).load((t, e) => {
            Object.assign(v, e), i(e)
        })
    })
}
const Jt = (s, i) => t => i[0] + (t - s[0]) * (i[0] - i[1]) / (s[0] - s[1]);

function Ut(s) {
    let i = [];
    for (let t = 0; t < s; t++) {
        i[t] = [];
        for (let e = 0; e < t + 1; e++) {
            let o;
            e == 0 || e == t ? o = 1 : o = i[t - 1][e - 1] + i[t - 1][e], i[t][e] = o
        }
    }
    return i
}

function _t(s, i) {
    let t = {};
    i++;
    let e = Ut(i);
    for (let o = s; o < i; o++) {
        let l = e[o].reduce((r, h) => r + h, 0);
        t[o] = [], e[o].forEach(r => t[o].push(r / l))
    }
    return t
}
Vt(0, .9, 1, 1);

function qt(s, i) {
    return t => {
        let e = [s >> 16, s >> 8 & 255, s & 255],
            o = [i >> 16, i >> 8 & 255, i & 255],
            l = [o[0] - e[0], o[1] - e[1], o[2] - e[2]];
        return s + (t * l[0] << 16) + (t * l[1] << 8) + l[2]
    }
}
const ot = qt(16760833, 16000088);
class T extends w {
    constructor(t, e, o) {
        super();
        a(this, "sprite");
        a(this, "activeSprite");
        a(this, "pinTime", 0);
        this.x = t, this.y = e, this.scale.x = this.scale.y = o, this.drawActive(), this.drawSprite()
    }
    drawSprite() {
        this.sprite = new D(v[g.pin].texture), this.sprite.anchor.x = this.sprite.anchor.y = .5, this.sprite.pivot.x = -1.5, this.sprite.pivot.y = -2, this.addChild(this.sprite)
    }
    drawActive() {
        this.activeSprite = new D(v[g.pin_active].texture), this.activeSprite.anchor.x = this.activeSprite.anchor.y = .5, this.activeSprite.visible = !1, this.activeSprite.pivot.y = -1, this.addChild(this.activeSprite)
    }
    update() {
        if (this.pinTime <= 0) return;
        let t = this.pinTime - .0166;
        if (t <= 0) t = 0, this.activeSprite.visible = !1;
        else {
            this.activeSprite.visible = !0;
            let e = 1 - t / .3;
            this.activeSprite.scale.x = this.activeSprite.scale.y = .8 + e * .5, this.activeSprite.alpha = 1 - e
        }
        this.pinTime = t
    }
    pin() {
        this.pinTime = .3
    }
}
a(T, "size", 20);
const Kt = {
    alpha: {
        start: 1,
        end: .5
    },
    scale: {
        start: 1,
        end: .001,
        minimumScaleMultiplier: .5
    },
    color: {
        start: "#ffffff",
        end: "#ffffff"
    },
    speed: {
        start: 20,
        end: 0,
        minimumSpeedMultiplier: 4
    },
    acceleration: {
        x: 0,
        y: -100
    },
    maxSpeed: 0,
    startRotation: {
        min: 0,
        max: 360
    },
    noRotation: !1,
    rotationSpeed: {
        min: 40,
        max: 400
    },
    lifetime: {
        min: .5,
        max: .5
    },
    blendMode: "normal",
    frequency: .01,
    emitterLifetime: .5,
    maxParticles: 10,
    pos: {
        x: 0,
        y: 0
    },
    addAtBack: !1,
    spawnType: "ring",
    spawnCircle: {
        x: 0,
        y: 0,
        r: 10,
        minR: 10
    }
};
class $t extends w {
    constructor() {
        super();
        a(this, "particles");
        this.particles = new Nt(this, v[g.star].texture, Kt), this.particles.emit = !1, this.particles.autoUpdate = !0
    }
    destroy() {
        this.particles.destroy()
    }
}
class j extends w {
    constructor(t, e, o, l) {
        super();
        a(this, "container");
        a(this, "sprite");
        a(this, "text");
        a(this, "payout");
        a(this, "chance");
        a(this, "table");
        a(this, "zoom");
        a(this, "particles");
        a(this, "hitTime", 0);
        a(this, "textStyle");
        this.payout = t, this.chance = e, this.zoom = o, this.table = l, this.interactive = !0, this.textStyle = new Q({
            fontSize: Math.min(110, 60 * l.app.rows / 8),
            fill: 16777215,
            fontWeight: "600",
            fontFamily: "Montserrat"
        }), this.container = new w, this.addChild(this.container), this.drawSprite(), this.drawText(), this.drawParticles()
    }
    drawSprite() {
        this.sprite = new D(v[g.target].texture), this.sprite.anchor.x = this.sprite.anchor.y = .5, this.sprite.scale.x = this.sprite.scale.y = this.zoom, this.container.addChild(this.sprite)
    }
    drawText() {
        let t;
        this.payout < 10 ? t = this.payout.toFixed(1) + "\xD7" : this.payout > 100 ? t = this.payout.toString() : t = this.payout + "\xD7", this.text = new I(t, this.textStyle), this.text.anchor.x = this.text.anchor.y = .5, this.text.scale.x = this.text.scale.y = this.zoom * .5, this.container.addChild(this.text)
    }
    drawParticles() {
        this.particles = new $t, this.addChild(this.particles)
    }
    update() {
        if (this.hitTime <= 0) return;
        this.hitTime -= .0166, this.hitTime < 0 && (this.hitTime = 0);
        let t = 1 - this.hitTime / .2;
        t < .65 ? this.container.y = 30 * t : this.container.y = 30 * (1 - t)
    }
    hit() {
        this.hitTime = .2, this.payout >= 1 ? this.table.playSound("sound_win_mp3") : this.table.playSound("sound_lose_mp3"), this.particles.particles.emit = !0
    }
}
a(j, "width", 109);
const x = class extends w {
    constructor() {
        super();
        a(this, "sprite");
        a(this, "path", []);
        a(this, "state", 0);
        a(this, "table");
        a(this, "appearing", 0);
        a(this, "collisionRadius", 0);
        a(this, "targetIndex");
        a(this, "velocity", {
            x: 0,
            y: 0
        });
        a(this, "pms");
        a(this, "pmsResolve");
        this.drawSprite(), this.on("removed", () => {
            this.pmsResolve && this.pmsResolve()
        })
    }
    init(t) {
        this.table = t, this.table.playSound("sound_start_mp3"), this.appearing = 0, this.x = this.y = 0, this.velocity.x = this.velocity.y = 0;
        let e = (t.pinsDistance - T.size * t.pinScale) / 1.3 / x.size;
        this.collisionRadius = T.size * t.pinScale * .5 + x.size * e * .5, this.sprite.scale.x = this.sprite.scale.y = e
    }
    drawSprite() {
        this.sprite = new D(v[g.ball].texture), this.sprite.anchor.x = this.sprite.anchor.y = .5, this.addChild(this.sprite)
    }
    run(t) {
        this.pms = new Promise(o => this.pmsResolve = o);
        let e = 1;
        return this.path = t.map((o, l) => {
            let r, h = this.table.lines[l],
                u, c;
            return o > 0 ? (u = e, c = e + 1) : (u = e - 1, c = e), r = {
                min: h.children[u].x + T.size / 5,
                max: h.children[c].x - T.size / 5
            }, e += o, r
        }), this.targetIndex = t.reduce((o, l) => o + l, 0), this.state = 1, this.pms
    }
    stop() {
        this.state = 2, this.pmsResolve && this.pmsResolve(), this.table.targets[this.targetIndex].hit(), this.remove()
    }
    remove() {
        this.table.removeBall(this)
    }
    update() {
        this.appearing < 1 ? (this.appearing += .25, this.appearing > 1 && (this.appearing = 1), this.alpha = this.appearing, this.scale.x = this.scale.y = .5 + .5 * this.appearing) : this.state === 1 && this.falling()
    }
    falling() {
        this.updatePosition(), this.correctPosition(), this.pinCollisions(), this.y > this.table.targets[0].y && this.stop()
    }
    updatePosition() {
        this.x += this.velocity.x, this.y += this.velocity.y
    }
    pinCollisions() {
        for (let t = 0; t < this.table.lines.length; t++) {
            let e = this.table.lines[t],
                o = e.y - this.y;
            if (Math.abs(o) < this.collisionRadius)
                for (let l = 0; l < e.children.length; l++) {
                    let r = e.children[l],
                        h = r.x - this.x;
                    if (Math.abs(h) < this.collisionRadius) {
                        let u = Math.sqrt(o * o + h * h);
                        if (u < this.collisionRadius) {
                            let c = Math.atan2(o, h),
                                B = Math.atan2(this.velocity.y, this.velocity.x),
                                d = Math.sqrt(this.velocity.x * this.velocity.x + this.velocity.y * this.velocity.y);
                            d > 5 && r.pin(), d > 1 && this.table.playSound("sound_pin_mp3", d * .07);
                            let N = this.collisionRadius - u;
                            N > 0 && (d -= Math.min(1, N));
                            let J = d * (1 - Math.max(0, Math.abs(Math.cos(c - B))) * x.consume),
                                P = Math.cos(c),
                                X = Math.sin(c);
                            if (this.velocity.x = -P * J, this.velocity.y = -X * J, this.x = r.x - P * this.collisionRadius, this.y = e.y - X * this.collisionRadius, e.y > this.y) {
                                this.velocity.y += P * P, this.velocity.x -= X * P;
                                return
                            }
                        } else {
                            this.velocity.y += x.speed;
                            return
                        }
                    }
                }
        }
        this.velocity.y += x.speed * this.table.speedScale
    }
    correctPosition() {
        let t = null;
        for (let e = 0; e < this.table.lines.length; e++)
            if (this.table.lines[e].y > this.y) {
                t = this.path[e];
                break
            }
        t || (t = this.path[this.path.length - 1]), this.x < t.min ? (this.velocity.x = 0, this.x = t.min) : this.x > t.max && (this.velocity.x = 0, this.x = t.max)
    }
};
let O = x;
a(O, "size", 49), a(O, "speed", 1), a(O, "consume", .5);
class Zt {
    constructor(i) {
        a(this, "elems", []);
        a(this, "freeElems", []);
        a(this, "size", 0);
        for (let t = 0; t < i; t++) this.expand()
    }
    get() {
        this.freeElems.length == 0 && this.expand();
        let i = this.freeElems.pop();
        return this.elems[i]
    }
    put(i) {
        i.removeAllListeners();
        let t = this.elems.indexOf(i);
        t !== -1 && this.freeElems.push(t)
    }
    expand() {
        this.size++, this.freeElems.push(this.elems.push(new O) - 1)
    }
}
const E = 28,
    m = class extends D {
        constructor() {
            super();
            a(this, "profit");
            a(this, "chance");
            a(this, "padding", 20);
            a(this, "arrow");
            a(this, "xArea", [-(y.width - m.width / 2) / 2 - 10, (y.width - m.width / 2) / 2 + 10]);
            a(this, "visibleNum", 0);
            this.width = m.width, this.height = m.height, this.texture = v[g.tooltip].texture, this.visible = !1, this.pivot.x = this.width / 2, this.pivot.y = this.height / 2, this.drawArrow(), this.drawLabel(), this.drawProfit(), this.drawChance(), this.scale.x = this.scale.y = .5
        }
        drawArrow() {
            this.arrow = new D(v[g.arrow].texture), this.arrow.x = this.width / 2, this.arrow.anchor.x = .5, this.arrow.y = this.height, this.addChild(this.arrow)
        }
        drawLabel() {
            let t = new I("Win Amount", m.toolLabelStyle);
            t.x = this.padding * 2, t.y = this.padding * .8;
            let e = new I("Chance", m.toolLabelStyle);
            e.x = this.width / 2 + this.padding, e.y = this.padding * .8, this.addChild(t), this.addChild(e)
        }
        drawProfit() {
            this.profit = new I("2 ETH", m.toolTextStyle), this.profit.x = this.padding * 2 + 10, this.profit.y = this.padding * 2.4 + E, this.addChild(this.profit)
        }
        drawChance() {
            this.chance = new I("34.05%", m.toolTextStyle), this.chance.x = this.width / 2 + this.padding + 10, this.chance.y = this.padding * 2.4 + E, this.addChild(this.chance)
        }
        show(t, e, o, l) {
            this.visibleNum++, this.visible = this.visibleNum > 0;
            let r = this.width / 2;
            t > this.xArea[1] ? (r += t - this.xArea[1], t = this.xArea[1]) : t < this.xArea[0] && (r += t + this.xArea[1], t = this.xArea[0]), this.x = t, this.arrow.x = r * 2, this.y = e - this.height, this.profit.text = o, this.chance.text = (l * 100).toFixed(4) + "%"
        }
        hide() {
            setTimeout(() => {
                this.visibleNum--, this.visible = this.visibleNum > 0
            }, 200)
        }
    };
let k = m;
a(k, "width", 560), a(k, "height", 144), a(k, "toolLabelStyle", new Q({
    fontSize: E,
    fill: 10199467,
    fontFamily: "Montserrat"
})), a(k, "toolTextStyle", new Q({
    fontSize: E,
    fill: 3159869,
    fontWeight: "700",
    fontFamily: "Montserrat"
}));
const R = class extends w {
    constructor(t) {
        super();
        a(this, "app");
        a(this, "ballsContainer");
        a(this, "pinsContainer");
        a(this, "lines", []);
        a(this, "targets", []);
        a(this, "tooltip");
        a(this, "balls", []);
        a(this, "running", !1);
        a(this, "pinsDistance", 1);
        a(this, "pinScale", 1);
        a(this, "ballPool", new Zt(10));
        this.app = t, this.x = this.app.width / 2, this.scale.x = this.scale.y = this.app.width / R.height, this.drawBallsContainer(), this.drawPinsContainer(), this.drawToolTip()
    }
    get speedScale() {
        return this.app.isFast ? 2 : 1
    }
    update() {
        this.balls.forEach(t => t.update()), this.targets.forEach(t => t.update());
        for (let t = 0, e = this.lines.length; t < e; t++)
            for (let o = 0, l = this.lines[t].children.length; o < l; o++) this.lines[t].children[o].update()
    }
    drawPinsContainer() {
        this.pinsDistance = R.width / (this.app.rows + 1), this.pinScale = Math.max(.2, Math.min(1, .01 * this.pinsDistance));
        let t = (R.height - this.pinsDistance) / (this.app.rows + 1);
        this.pinsContainer = new w, this.y = this.pinsDistance * .5 * this.scale.x, this.addChildAt(this.pinsContainer, 0);
        for (let l = 0; l < this.app.rows; l++) {
            let r = new w;
            r.y = this.pinsDistance + l * t;
            let h = -Math.round((l + 2) * this.pinsDistance / 2);
            for (let u = 0, c = l + 3; u < c; u++) {
                let B = new T(h + this.pinsDistance * u, 0, this.pinScale);
                r.addChild(B)
            }
            this.lines.push(r), this.pinsContainer.addChild(r)
        }
        let e = Math.min(.95, this.pinsDistance * .95 / j.width),
            o = -(R.width - j.width * e) / 2;
        for (let l = 0, r = this.app.rows + 1; l < r; l++) {
            let h = this.app.payout[this.app.risk][this.app.rows][l],
                u = this.app.chance[this.app.rows][l],
                c = new j(h, u, e, this);
            c.x = o + l * this.pinsDistance, c.y = this.pinsDistance * .8 + this.app.rows * t;
            const B = () => {
                    let N = G.amount.mul(h).toString().slice(0, 10);
                    this.tooltip.show(c.x, c.y, `${N} ${mt.getAlias(G.currencyName)}`, u)
                },
                d = () => {
                    this.tooltip.hide()
                };
            c.on("pointerover", B), c.on("pointerdown", B), c.on("pointerout", d), c.on("pointerup", d), c.on("pointercancel", d), c.on("pointerupoutside", d), this.pinsContainer.addChild(c), this.targets.push(c)
        }
        for (let l = 0, r = this.targets.length; l < r; l++) {
            let h = 2 * Math.abs(l - (this.targets.length - 1) / 2) / this.targets.length;
            this.targets[l].sprite.tint = ot(h)
        }
    }
    drawBallsContainer() {
        this.ballsContainer = new w, this.addChild(this.ballsContainer)
    }
    drawToolTip() {
        this.tooltip = new k, this.tooltip.y = 120, this.addChild(this.tooltip)
    }
    addBall() {
        let t = this.ballPool.get();
        return t.init(this), this.balls.push(t), this.ballsContainer.addChild(t), this.checkRuning(), t
    }
    removeBall(t) {
        let e = this.balls.indexOf(t);
        this.balls.splice(e, 1), this.ballsContainer.removeChild(t), this.ballPool.put(t), this.checkRuning()
    }
    reset() {
        this.removeChild(this.pinsContainer), this.lines.splice(0, this.lines.length), this.targets.splice(0, this.targets.length), this.drawPinsContainer()
    }
    checkRuning() {
        this.running = this.balls.length !== 0, this.emit("running", this.running)
    }
    playSound(t, e = 1) {
        G.sounds.playSound(t, {
            volume: e
        })
    }
};
let y = R;
a(y, "width", 520), a(y, "height", 580), a(y, "hueScale", Jt([0, 1], [.33, 0]));
class te extends ft.exports.EventEmitter {
    constructor(t = 8, e = 1, o, l, r) {
        super();
        a(this, "app");
        a(this, "width", 700);
        a(this, "height", 700);
        a(this, "payout");
        a(this, "chance", _t(8, 16));
        a(this, "table");
        a(this, "rows");
        a(this, "risk", 1);
        a(this, "isFast");
        a(this, "running", !1);
        this.rows = t, this.risk = e, this.width = r, this.height = r, this.payout = o, this.isFast = l, this.app = new Et, this.app.renderer.resize(this.width, this.height), this.init()
    }
    update() {
        !this.table.running || this.app.ticker.update()
    }
    destroy() {
        this.app.destroy()
    }
    async init() {
        await Qt(this.app.loader), this.table = new y(this), this.table.on("running", t => {
            this.running = t, this.emit("running", t)
        }), this.enableFast(this.isFast), this.app.stage.addChild(this.table), this.app.ticker.add(() => this.table.update())
    }
    addBall() {
        return this.table.addBall()
    }
    enableFast(t) {
        this.isFast = t
    }
    resetTable(t, e = 1) {
        this.rows == t && this.risk == e || this.running || (this.rows = t, this.risk = e, this.table.reset(), this.app.ticker.update())
    }
}
const ee = A(() => {
    const s = C(),
        i = z.exports.useRef(null);
    return z.exports.useEffect(() => {
        var t;
        return s.plinko = new te(s.rows, s.risk, s.payouts, s.settings.fastEnable, ie()), (t = i.current) == null || t.appendChild(s.plinko.app.view), () => {
            s.plinko && (s.plinko.destroy(), s.plinko = null)
        }
    }, []), n("div", {
        className: se,
        ref: i
    })
});

function ie() {
    const s = window.innerHeight,
        i = window.innerWidth;
    return i < 612 ? i * .8 : Math.min(500, s - 360)
}
const se = "wha26ye",
    ne = A(() => {
        const s = C(),
            i = L.useSingleDetail();
        return n(wt, {
            list: s.myBets,
            keyof: "betId",
            onDetail: i
        })
    }),
    ae = () => p(yt, {
        children: [n(ne, {}), p(bt, {
            children: [n(ee, {}), n(gt, {})]
        })]
    });
var oe = A(ae);
const lt = A(() => {
        const s = M(),
            i = C(),
            t = z.exports.useCallback(e => i.risk = e, []);
        return n(V.LabelSelect, {
            label: s("common.risk"),
            disabled: i.isBetting,
            value: i.risk,
            options: i.riskOptions,
            onChange: t
        })
    }),
    rt = A(() => {
        const s = M(),
            i = C(),
            t = z.exports.useCallback(e => i.rows = e, []);
        return n(V.LabelSelect, {
            label: s("common.rows"),
            disabled: i.isBetting,
            value: i.rows,
            options: i.rowsOptions,
            onChange: t
        })
    });

function tt() {
    const s = M(),
        i = C();
    return n(st, {
        className: "bet-button",
        size: "big",
        type: "conic",
        onClick: () => {
            i.betThrottle()
        },
        children: s("common.bet")
    })
}
const le = () => p("div", {
        className: it(re, "bet-control-manual"),
        children: [F.isMobile && n(tt, {}), n(V.CoinInput, {
            checkIncrease: !0
        }), n(lt, {}), n(rt, {}), !F.isMobile && n(tt, {})]
    }),
    re = "mpjw9nc";
var he = A(le),
    ce = A(function() {
        return p("div", {
            className: "bet-control-auto",
            children: [F.isMobile && n(et, {}), n(V.CoinInput, {
                checkIncrease: !0
            }), n(V.TimesInput, {}), n(lt, {}), n(rt, {}), n(vt, {}), !F.isMobile && n(et, {})]
        })
    });
const et = A(() => {
        const s = M(),
            i = C(),
            t = i.autoBet;
        return n(st, {
            type: "conic",
            disabled: !t.isRunning && i.isBetting,
            className: "bet-button",
            onClick: i.toggleAutoBet,
            size: "big",
            children: t.isRunning ? s("common.stop_auto_bet") : s("common.start_auto_bet")
        })
    }),
    pe = W.memo(({
        game: s
    }) => p(nt, {
        children: [p("div", {
            className: "item",
            children: [n("h2", {
                children: "What Is Plinko?"
            }), n("div", {
                className: "help-content",
                children: s.gameInfo.detail.split(`
`).map((i, t) => n("p", {
                    children: i
                }, t.toString()))
            })]
        }), p("div", {
            className: "item",
            children: [n("h2", {
                children: "How To Play It?"
            }), n("p", {
                children: "just enter your bet, choose the Odds, and then choose the bonus line.The number on the bonus line means how much your bet will be multiplied when the ball falls into a hole."
            }), n("p", {
                children: "If your brain doesn't want to think, choose our AUTO BOT."
            })]
        })]
    })),
    ue = W.memo(({
        game: s
    }) => p(At, {
        game: s,
        children: [p("div", {
            className: "item",
            children: [n("h2", {
                children: "What is the bankroll?"
            }), n("p", {
                children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
            }), n("p", {
                children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
            }), p("ul", {
                children: [n("li", {
                    children: "Each player can only win 0.75\u2009% of the bankroll per round"
                }), n("li", {
                    children: "All players can only win 1.125% of the funds per round"
                })]
            }), n("p", {
                children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
            }), n("p", {
                onClick: () => kt(s),
                className: "cl-primary",
                children: "Read more about bankrollers."
            })]
        }), p("div", {
            className: "item",
            children: [n("h2", {
                children: "How does the pool of funds operate? "
            }), n("p", {
                children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
            }), p("p", {
                children: [n("b", {
                    className: "cl-primary",
                    children: "The house edge is 1%."
                }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
            }), n("p", {
                children: "Payouts made to the winning players will be deducted from the bankroll."
            })]
        }), p("div", {
            className: "item",
            children: [n("h2", {
                children: "How does leverage investment work?"
            }), n("p", {
                children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
            }), n("p", {
                children: "Hint: You can also use this feature as an Off-Site investment."
            }), n("p", {
                children: "Let's make an example:"
            }), n("p", {
                children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
            })]
        }), p("div", {
            className: "item",
            children: [n("h2", {
                children: "What is the bankroller dilution fee?"
            }), n("p", {
                children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
            }), n("p", {
                children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
            }), n("p", {
                children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
            }), n("p", {
                children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
            })]
        })]
    }));
var de = ue;
const me = W.memo(() => {
        const s = M(),
            i = C(),
            t = [{
                title: s("common.game_intro"),
                node: n(pe, {
                    game: i
                })
            }, {
                title: s("common.fairness"),
                node: "/plinko_help/fairness"
            }, {
                title: s("common.bankroll"),
                node: n(de, {
                    game: i
                })
            }];
        return n(xt, {
            className: fe,
            manualControl: n(he, {}),
            autoControl: n(ce, {}),
            gameView: n(oe, {}),
            tabs: [{
                label: s("common.all_bet"),
                value: L.AllBet
            }, {
                label: s("common.my_bet"),
                value: L.MyBet
            }],
            actions: [n(St, {}), n(Ct, {}), n(Bt, {}), n(Ot, {}), n(Tt, {}), n(Rt, {}), n(Gt, {
                list: t
            })]
        })
    }),
    fe = "p8bxzj7",
    b = S.Reader,
    ht = S.Writer,
    H = S.util,
    f = S.roots.gamePlinko || (S.roots.gamePlinko = {});
f.BetValue = (() => {
    function s(i) {
        if (i)
            for (let t = Object.keys(i), e = 0; e < t.length; ++e) i[t[e]] != null && (this[t[e]] = i[t[e]])
    }
    return s.prototype.risk = 0, s.prototype.row = 0, s.create = function(t) {
        return new s(t)
    }, s.encode = function(t, e) {
        return e || (e = ht.create()), t.risk != null && Object.hasOwnProperty.call(t, "risk") && e.uint32(8).uint32(t.risk), t.row != null && Object.hasOwnProperty.call(t, "row") && e.uint32(16).uint32(t.row), e
    }, s.encodeDelimited = function(t, e) {
        return this.encode(t, e).ldelim()
    }, s.decode = function(t, e) {
        t instanceof b || (t = b.create(t));
        let o = e === void 0 ? t.len : t.pos + e,
            l = new f.BetValue;
        for (; t.pos < o;) {
            let r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    l.risk = t.uint32();
                    break;
                case 2:
                    l.row = t.uint32();
                    break;
                default:
                    t.skipType(r & 7);
                    break
            }
        }
        return l
    }, s.decodeDelimited = function(t) {
        return t instanceof b || (t = new b(t)), this.decode(t, t.uint32())
    }, s.verify = function(t) {
        return typeof t != "object" || t === null ? "object expected" : t.risk != null && t.hasOwnProperty("risk") && !H.isInteger(t.risk) ? "risk: integer expected" : t.row != null && t.hasOwnProperty("row") && !H.isInteger(t.row) ? "row: integer expected" : null
    }, s.fromObject = function(t) {
        if (t instanceof f.BetValue) return t;
        let e = new f.BetValue;
        return t.risk != null && (e.risk = t.risk >>> 0), t.row != null && (e.row = t.row >>> 0), e
    }, s.toObject = function(t, e) {
        e || (e = {});
        let o = {};
        return e.defaults && (o.risk = 0, o.row = 0), t.risk != null && t.hasOwnProperty("risk") && (o.risk = t.risk), t.row != null && t.hasOwnProperty("row") && (o.row = t.row), o
    }, s.prototype.toJSON = function() {
        return this.constructor.toObject(this, S.util.toJSONOptions)
    }, s
})();
f.GameValue = (() => {
    function s(i) {
        if (i)
            for (let t = Object.keys(i), e = 0; e < t.length; ++e) i[t[e]] != null && (this[t[e]] = i[t[e]])
    }
    return s.prototype.path = "", s.prototype.position = 0, s.create = function(t) {
        return new s(t)
    }, s.encode = function(t, e) {
        return e || (e = ht.create()), t.path != null && Object.hasOwnProperty.call(t, "path") && e.uint32(10).string(t.path), t.position != null && Object.hasOwnProperty.call(t, "position") && e.uint32(16).uint32(t.position), e
    }, s.encodeDelimited = function(t, e) {
        return this.encode(t, e).ldelim()
    }, s.decode = function(t, e) {
        t instanceof b || (t = b.create(t));
        let o = e === void 0 ? t.len : t.pos + e,
            l = new f.GameValue;
        for (; t.pos < o;) {
            let r = t.uint32();
            switch (r >>> 3) {
                case 1:
                    l.path = t.string();
                    break;
                case 2:
                    l.position = t.uint32();
                    break;
                default:
                    t.skipType(r & 7);
                    break
            }
        }
        return l
    }, s.decodeDelimited = function(t) {
        return t instanceof b || (t = new b(t)), this.decode(t, t.uint32())
    }, s.verify = function(t) {
        return typeof t != "object" || t === null ? "object expected" : t.path != null && t.hasOwnProperty("path") && !H.isString(t.path) ? "path: string expected" : t.position != null && t.hasOwnProperty("position") && !H.isInteger(t.position) ? "position: integer expected" : null
    }, s.fromObject = function(t) {
        if (t instanceof f.GameValue) return t;
        let e = new f.GameValue;
        return t.path != null && (e.path = String(t.path)), t.position != null && (e.position = t.position >>> 0), e
    }, s.toObject = function(t, e) {
        e || (e = {});
        let o = {};
        return e.defaults && (o.path = "", o.position = 0), t.path != null && t.hasOwnProperty("path") && (o.path = t.path), t.position != null && t.hasOwnProperty("position") && (o.position = t.position), o
    }, s.prototype.toJSON = function() {
        return this.constructor.toObject(this, S.util.toJSONOptions)
    }, s
})();
var we = "/assets/plinko-bgm-small.feef2f77.mp3",
    ye = "/assets/start.a4a768b9.mp3",
    be = "/assets/pin.b71d97bc.mp3",
    ge = "/assets/win.99963751.mp3",
    ve = "/assets/lose.36dd0b79.mp3";
const Ae = at.encode(f.BetValue);
class ke extends Dt {
    constructor() {
        super({
            name: "Plinko",
            namespace: "/g/p",
            sounds: {
                bg: {
                    src: we,
                    loop: !0,
                    isBackground: !0
                },
                sound_start_mp3: ye,
                sound_pin_mp3: be,
                sound_win_mp3: ge,
                sound_lose_mp3: ve
            },
            fairLink: "/plinko_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/plinko.html"
        }, me);
        a(this, "risk", 1);
        a(this, "rows", 8);
        a(this, "theme", {
            text: "#d9ebf6",
            main: "#6d6fcd",
            light: "#c2c4f5",
            dark: "#5759bb",
            dark2: "#4e51a5"
        });
        a(this, "payouts", jt);
        a(this, "riskOptions", [{
            label: "Low",
            value: 1
        }, {
            label: "Medium",
            value: 2
        }, {
            label: "High",
            value: 3
        }]);
        a(this, "rowsOptions", []);
        a(this, "plinko", null);
        a(this, "onGetBetRequest", () => {});
        a(this, "betThrottle", Mt(() => {
            this.handleBet().catch(q)
        }, 500));
        a(this, "gameValueDecoder", at.decode(f.GameValue));
        Pt(this, {
            risk: K,
            rows: K,
            maxProfit: It
        }), this.toggleAutoBet = this.toggleAutoBet.bind(this), $(() => {
            this.autoBet.interval = this.settings.fastEnable ? 350 : 1e3, this.plinko && this.plinko.enableFast(this.settings.fastEnable)
        }), this.autoBet.bet = async (...e) => new Promise((o, l) => {
            this.onGetBetRequest = r => {
                r.then(h => o(h.odds)), r.catch(l)
            }, this.handleBet(...e)
        }), this.rowsOptions = Object.keys(this.payouts[1]).map(e => ({
            label: e,
            value: Number(e)
        }));
        const t = this.hotkeyList.find(e => e.key == "space");
        t && (t.handler = () => (this.controlIdx === 1 ? this.toggleAutoBet() : this.betThrottle(), !1)), this.syncPlinkoSettings()
    }
    get maxProfit() {
        const t = Math.max(...this.payouts[this.risk][this.rows]);
        return this.amount.mul(t).sub(this.amount)
    }
    syncPlinkoSettings() {
        $(() => {
            const {
                rows: t,
                risk: e
            } = this;
            this.plinko && this.plinko.resetTable(t, e)
        })
    }
    toggleAutoBet() {
        this.autoBet.isRunning ? this.autoBet.stop() : this.isBetting || this.autoBet.start().catch(q)
    }
    setBetStatus(t) {
        this.plinko ? !t && !this.autoBet.isRunning && !this.plinko.running ? this.isBetting = !1 : this.isBetting = !0 : this.isBetting = t
    }
    async onBetRequest(t) {
        if (this.onGetBetRequest(t), this.plinko) {
            const e = this.plinko.addBall();
            try {
                let o = await t;
                const r = o.gameValue.path.split("").map(h => Number(h));
                try {
                    await e.run(r)
                } catch (h) {}
                return o
            } catch (o) {
                throw e.remove(), o
            }
        } else return t
    }
    betValue() {
        return Ae({
            risk: this.risk,
            row: this.rows
        })
    }
    active() {
        this.isBetting = !1, super.active()
    }
}
const ct = new ke;
var G = ct;
window.dg = ct;

function Ve({
    bodyLock: s
}) {
    return n(nt, {
        bodyLock: s,
        children: p("div", {
            className: "item",
            children: [n("h2", {
                children: "Fairness Verification"
            }), n("p", {
                children: "Solving the Trust Issue with Online Gambling"
            }), n("p", {
                children: "The underlying concept of provable fairness is that players have the ability to prove and verify that their results are fair and unmanipulated. This is achieved through the use of a commitment scheme, along with cryptographic hashing."
            }), n("p", {
                children: "The commitment scheme is used to ensure that the player has an influence on all results generated. Cryptographic hashing is used to ensure that the casino also remains honest to this commitment scheme. Both concepts combined creates a trust-less environment when gambling online."
            }), n("p", {
                children: "This is simplified in the following representation:"
            }), p("ul", {
                children: [n("li", {
                    children: "First, hash = HMAC_SHA512(clientSeed:nonce, serverSeed)"
                }), n("li", {
                    children: "Finally, we divide the hash into 16 groups in groups of 8 characters, each group will be converted to a number in the range [0, 1). If it is less than 0.5, the ball will fall to the left, otherwise it will fall to the right."
                })]
            }), n("br", {}), n("p", {
                children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)"
            })]
        })
    })
}
const xe = (s, i) => {
        let t = 2 * Math.abs(s - i / 2) / (i + 1);
        return `#${ot(t).toString(16)}`
    },
    Se = W.memo(({
        bet: s,
        payout: i
    }) => {
        const t = i[s.risk][s.rows];
        return n("div", {
            className: it(Ce, "ten_res"),
            children: t.map((e, o) => p("div", {
                className: `res_t ${o===s.resIndex?"active":""}`,
                children: [n("svg", {
                    fill: xe(o, s.rows),
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "0 0 54 43",
                    children: p("g", {
                        fillRule: "evenodd",
                        children: [n("rect", {
                            width: "54",
                            height: "29",
                            y: "14",
                            rx: "2"
                        }), n("path", {
                            d: "M2.592 0H8c8.745.873 8 5 19 5 10.066.077 10.255-4.127 19-5h5.408A2.592 2.592 0 0154 2.592v34.816A2.592 2.592 0 0151.408 40H2.592A2.592 2.592 0 010 37.408V2.592A2.592 2.592 0 012.592 0z"
                        })]
                    })
                }), p("span", {
                    children: [e, "x"]
                })]
            }, o))
        })
    }),
    Ce = "r1qtapv7";
const Be = (s, i, t, e) => {
        window.open(`${G.config.validateLink}?s=${s}&c=${i}&h=${e}&n=${t}`)
    },
    Oe = L.withSingleDetail({
        onValidate: Be,
        result: ({
            betLog: s
        }) => {
            const {
                risk: i,
                row: t
            } = s.bv, {
                path: e,
                position: o
            } = s.gv, l = e.split("").reduce((h, u) => h += parseInt(u), 0), r = {
                bet: {
                    risk: i,
                    rows: t,
                    resIndex: l
                },
                payout: G.payouts
            };
            return n(Se, _({}, r))
        },
        slot: ({
            betLog: s
        }) => {
            const i = M(),
                {
                    risk: t,
                    row: e
                } = s.bv;
            let o = G.riskOptions.find(l => l.value === t);
            return p("div", {
                className: Te,
                children: [n(Z, {
                    label: i("common.risk"),
                    value: o == null ? void 0 : o.label,
                    readOnly: !0
                }), n(Z, {
                    label: i("common.rows"),
                    value: e,
                    readOnly: !0
                })]
            })
        }
    });
var Ne = Oe;
const Te = "s2o98uv";
export {
    de as Bankroll, Ne as Detail, Ve as Fairness, G as Game
};
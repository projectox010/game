var at = Object.defineProperty,
    lt = Object.defineProperties;
var ot = Object.getOwnPropertyDescriptors;
var Q = Object.getOwnPropertySymbols;
var ge = Object.prototype.hasOwnProperty,
    ke = Object.prototype.propertyIsEnumerable;
var ye = (n, s, e) => s in n ? at(n, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : n[s] = e,
    oe = (n, s) => {
        for (var e in s || (s = {})) ge.call(s, e) && ye(n, e, s[e]);
        if (Q)
            for (var e of Q(s)) ke.call(s, e) && ye(n, e, s[e]);
        return n
    },
    ve = (n, s) => lt(n, ot(s));
var ce = (n, s) => {
    var e = {};
    for (var t in n) ge.call(n, t) && s.indexOf(t) < 0 && (e[t] = n[t]);
    if (n != null && Q)
        for (var t of Q(n)) s.indexOf(t) < 0 && ke.call(n, t) && (e[t] = n[t]);
    return e
};
import {
    cE as ct,
    cF as rt,
    aI as ut,
    a5 as D,
    a as i,
    S as W,
    j as c,
    dy as Oe,
    dz as Be,
    u as C,
    b as x,
    l as F,
    o as I,
    bi as ht,
    du as S,
    r as b,
    aB as mt,
    bh as Te,
    F as H,
    Y as we,
    ea as dt,
    t as V,
    q as v,
    dj as Pe,
    G as B,
    di as Ce,
    y as L,
    dk as Ae,
    dl as Re,
    dG as xe,
    dY as _e,
    dC as Ee,
    dD as je,
    dZ as ft,
    dE as Le,
    dp as E,
    d_ as bt,
    bN as P,
    aH as ee,
    ba as He,
    bb as k,
    bc as A,
    dr as M,
    dx as Ve,
    a2 as Ge,
    bo as Me,
    dH as Y,
    cJ as pt,
    D as ie,
    x as ae,
    am as R,
    e0 as de,
    n as yt,
    $ as J,
    de as U,
    al as gt,
    a3 as fe,
    ah as De,
    a4 as $e,
    a7 as re,
    bM as kt,
    M as vt,
    v as Fe,
    A as le,
    aO as G,
    db as me,
    d as Z,
    eh as Ke,
    s as wt,
    a$ as Nt,
    e as We,
    dJ as It,
    ei as St,
    ds as Ot,
    dt as Bt,
    J as $,
    dn as Tt
} from "./index.28e31dff.js";
import {
    s as te
} from "./index.dd8128e8.js";
import {
    G as N
} from "./index.06a59a68.js";
import {
    c as Pt
} from "./_copyArray.2183cf44.js";
import {
    b as Ct,
    v as At
} from "./_baseRandom.b8a5c2ab.js";
import {
    h as X
} from "./enc-hex.afd532ef.js";
import {
    u as Rt
} from "./useLocalStore.f739c306.js";
import {
    c as xt
} from "./index.65304255.js";

function Je(n, s, e) {
    return n === n && (e !== void 0 && (n = n <= e ? n : e), s !== void 0 && (n = n >= s ? n : s)), n
}

function qe(n, s) {
    var e = -1,
        t = n.length,
        a = t - 1;
    for (s = s === void 0 ? t : s; ++e < s;) {
        var l = Ct(e, a),
            o = n[l];
        n[l] = n[e], n[e] = o
    }
    return n.length = s, n
}

function _t(n, s) {
    return qe(Pt(n), Je(s, 0, n.length))
}

function Et(n, s) {
    var e = At(n);
    return qe(e, Je(s, 0, e.length))
}

function ne(n, s, e) {
    (e ? ct(n, s, e) : s === void 0) ? s = 1: s = rt(s);
    var t = ut(n) ? _t : Et;
    return t(n, s)
}
const jt = D.memo(() => i(W, {
        children: c("div", {
            className: "helpcon",
            children: [i("h2", {
                children: " What Is KenoSingle? "
            }), i("div", {
                className: "help-content",
                children: c("p", {
                    children: ["Keno is a fast-paced, fun game that allows you to choose:", i("br", {}), "\u2022 How many numbers to play with", i("br", {}), "\u2022 How many coins to wager", i("br", {}), "\u2022 Where to play and check your winning numbers -Keno is played by choosing up to 10 numbers from a total set of numbers from 1 to 40."]
                })
            }), i("h2", {
                children: "How to Play KenoSingle? "
            }), c("div", {
                className: "help-content",
                children: [i("p", {
                    children: "1. More the number combinations selected, higher the potential payout."
                }), i("p", {
                    children: "2.The more selections hit successfully, the higher will be the payout multiplier."
                }), i("p", {
                    children: "3.Maximum possible selection and maximum possible successful hits is 10."
                })]
            }), i("h2", {
                children: "What is the House Edge of KenoSingle?"
            }), i("div", {
                className: "help-content",
                children: "1% house edge."
            }), i("h2", {
                children: "Auto Mode Operation Instructions"
            }), c("div", {
                className: "help-content",
                children: [i("p", {
                    children: "[ ON WIN ] when you win, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                }), i("p", {
                    children: "[ ON LOSE ] when you lose, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                }), i("p", {
                    children: "[ STOP ON WIN ] Once the amount winned (from start to this bet) is bigger/equal than _(your set)_ , auto will stop;"
                }), i("p", {
                    children: "[ STOP ON LOSS ] Once the amount lost (from start to next bet) may be bigger/equal than _(your set)_ , auto will stop."
                })]
            })]
        })
    })),
    Lt = D.memo(({
        game: n
    }) => c(Oe, {
        game: n,
        children: [i("h2", {
            children: "What is the bankroll?"
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
            }), i("p", {
                children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
            }), i("p", {
                children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
            }), i("p", {
                onClick: () => Be(n),
                className: "cl-primary",
                children: "Read more about bankrollers."
            })]
        }), i("h2", {
            children: "How does the pool of funds operate? "
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
            }), c("p", {
                children: [i("b", {
                    className: "cl-primary",
                    children: "The house edge is 1%."
                }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
            }), i("p", {
                children: "Payouts made to the winning players will be deducted from the bankroll."
            })]
        }), i("h2", {
            children: "How does leverage investment work?"
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
            }), i("p", {
                children: "Hint: You can also use this feature as an Off-Site investment."
            }), i("p", {
                children: "Let's make an example:"
            }), i("p", {
                children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
            })]
        }), i("h2", {
            children: "What is the bankroller dilution fee?"
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
            }), i("p", {
                children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
            }), i("p", {
                children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
            }), i("p", {
                children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
            })]
        })]
    }));
var Ht = Lt;
const ze = n => {
        const s = C(),
            e = c(x, {
                className: "bet-button",
                disabled: n.canBet,
                loading: n.isBetting && !n.isRuning,
                onClick: () => {
                    n.onClick()
                },
                size: "big",
                type: "conic",
                children: [i("span", {
                    children: n.isRuning ? s("common.stop_auto_bet") : s("common.start_auto_bet")
                }), n.showKey && c("span", {
                    children: ["(", s("common.game.space"), ")"]
                })]
            }),
            t = c("div", {
                className: F(Vt, "btn-wrap"),
                children: [c(x, {
                    type: "gray",
                    className: "hold-btn",
                    disabled: n.isBetting,
                    onClick: n.random,
                    children: [s("common.game.autopick"), n.showKey && i("span", {
                        children: "(Q)"
                    })]
                }), c(x, {
                    type: "gray",
                    className: "hold-btn",
                    disabled: n.isBetting,
                    onClick: n.clear,
                    children: [s("common.game.cleartable"), n.showKey && i("span", {
                        children: "(W)"
                    })]
                })]
            });
        return n.isMulti ? c("div", {
            className: Gt,
            children: [e, c("div", {
                className: ue,
                children: [i(N.CoinInput, {
                    checkIncrease: !0
                }), i(N.TimesInput, {})]
            }), c("div", {
                className: ue,
                children: [i(N.IncreaseInput, {}), i(N.IncreaseInput, {
                    isLose: !0
                })]
            }), c("div", {
                className: ue,
                children: [i(N.StopInput, {}), i(N.StopInput, {
                    isLose: !0
                })]
            }), t]
        }) : c("div", {
            className: Mt,
            children: [i(N.CoinInput, {
                checkIncrease: !0
            }), i(N.TimesInput, {}), i(N.IncreaseInput, {}), i(N.StopInput, {}), i(N.IncreaseInput, {
                isLose: !0
            }), i(N.StopInput, {
                isLose: !0
            }), t, e]
        })
    },
    Vt = "a7fs26w",
    ue = "m1cfgo79",
    Gt = "mr1o0h0",
    Mt = "s1e9fakp";
var Dt = "/assets/banner_a1.44097480.png",
    $t = "/assets/banner_a2.22b44b7a.png",
    Ft = "/assets/bannerm_a1.6ab19596.png",
    Kt = "/assets/bannerm_a2.853af9cb.png",
    Ne = "/assets/icon.593e179a.png",
    Wt = "/assets/iconM.0e83c438.png",
    Jt = "/assets/keno_loading.d3c77d1e.png",
    qt = "/assets/gem_b.e8458fb1.png",
    zt = "/assets/gem_w.1513221d.png",
    Yt = "/assets/keno.87f505a5.png",
    q = {
        banner_a1: Dt,
        banner_a2: $t,
        banner_ma1: Ft,
        banner_ma2: Kt,
        icon: Ne,
        iconm: Wt,
        keno_loading: Jt,
        img_gem: Ne,
        img_gem_b: qt,
        img_gem_w: zt,
        imggem: Yt
    };
const Ut = n => {
    const s = C(),
        e = n.isBetting || n.canBet || n.disabledChoose,
        t = c(x, {
            className: `bet-button ${n.isBetting?" bet-loading":""}`,
            disabled: e,
            size: "big",
            onClick: n.onClick,
            type: "conic",
            children: [n.isMulti && i("img", {
                src: q.keno_loading,
                alt: "img.png"
            }), i("span", {
                children: n.nextBet ? s("common.actions.cancel") : s("common.bet")
            }), n.showKey && c("span", {
                children: ["(", s("common.game.space"), ")"]
            })]
        }),
        a = c("div", {
            className: F(he, "btn-wrap"),
            children: [c(x, {
                type: "gray",
                disabled: n.isBetting,
                onClick: n.random,
                className: "hold-btn",
                children: [s("common.game.autopick"), n.showKey && i("span", {
                    children: "(Q)"
                })]
            }), c(x, {
                type: "gray",
                className: "hold-btn",
                disabled: n.isBetting,
                onClick: n.clear,
                children: [s("common.game.cleartable"), n.showKey && i("span", {
                    children: "(W)"
                })]
            })]
        });
    return n.isMulti ? c("div", {
        className: Qt,
        children: [t, c("div", {
            className: he,
            children: [i(N.CoinInput, {}), i(N.LabelSelect, {
                label: s("common.risk"),
                onChange: n.onChangeRisk,
                options: n.riskOptions,
                value: n.risk,
                disabled: n.isBetting
            })]
        }), c("div", {
            className: F(he, "pick-wrap"),
            children: [i(ht, {
                label: s("common.game.lastgame"),
                value: n.gameHash,
                readOnly: !0
            }), a]
        })]
    }) : c("div", {
        className: Zt,
        children: [i(N.CoinInput, {}), i(N.LabelSelect, {
            label: s("common.risk"),
            onChange: n.onChangeRisk,
            options: n.riskOptions,
            value: n.risk,
            disabled: n.isBetting
        }), a, t]
    })
};
var Ye = I(Ut);
const Qt = "m3emq54",
    Zt = "sg58aq5",
    he = "meyv9fk";
var Xt = "/assets/gem.6b602d5e.json";
const en = ({
        play: n
    }) => {
        const s = b.exports.useRef(null);
        return b.exports.useEffect(() => {
            var e;
            n && s.current && ((e = s.current) == null || e.play(1))
        }, [n]), i(mt, {
            className: "win-img",
            ref: s,
            path: Xt,
            loop: !0
        })
    },
    tn = I(n => {
        const s = S();
        let e = "keno-ritem";
        b.exports.useEffect(() => {
            n.item.select && (console.log(s.sounds), s.sounds.playSound("sound_select"))
        }, [n.item.select]), b.exports.useEffect(() => {
            n.item.active && (n.item.select ? s.sounds.playSound("sound_active") : s.sounds.playSound("sound_noactive"))
        }, [n.item.active]), n.item.select && n.item.active ? e += " select active" : n.item.select ? e += " select" : n.item.active ? e += " active" : n.disabledItem ? e += " disabled" : e += " initial";
        let t = n.beforeResult.indexOf(String(n.item.num)) != -1 && n.item.select;
        return i("button", {
            className: "keno_styles_item",
            onClick: () => n.onAddItem(n.item.num),
            children: c("div", {
                className: e,
                children: [t && i(en, {
                    play: n.item.active && n.item.select
                }), i("span", {
                    className: "keno-num",
                    children: n.item.num
                })]
            }, n.item.num)
        })
    }),
    nn = s => {
        var n = ce(s, []);
        return i("div", {
            className: "keno-list",
            children: n.nums.map(e => i(tn, {
                item: e,
                onAddItem: n.onAddItem,
                disabledItem: n.disabledItem,
                beforeResult: n.beforeResult
            }, e.num))
        })
    },
    Ue = n => i(nn, {
        nums: n.nums,
        onAddItem: n.onAddItem,
        disabledItem: n.disabledItem,
        beforeResult: n.beforeResult
    });
let be = [{
    payouts: [0, 3.96],
    risk: "classic"
}, {
    payouts: [0, 1.9, 4.5],
    risk: "classic"
}, {
    payouts: [0, 1, 3.1, 10.4],
    risk: "classic"
}, {
    payouts: [0, .8, 1.8, 5, 22.5],
    risk: "classic"
}, {
    payouts: [0, .25, 1.4, 4.1, 16.5, 36],
    risk: "classic"
}, {
    payouts: [0, 0, 1, 3.68, 7, 16.5, 40],
    risk: "classic"
}, {
    payouts: [0, 0, .47, 3, 4.5, 14, 31, 60],
    risk: "classic"
}, {
    payouts: [0, 0, 0, 2.2, 4, 13, 22, 55, 70],
    risk: "classic"
}, {
    payouts: [0, 0, 0, 1.55, 3, 8, 15, 44, 60, 85],
    risk: "classic"
}, {
    payouts: [0, 0, 0, 1.4, 2.25, 4.5, 8, 17, 50, 80, 100],
    risk: "classic"
}, {
    payouts: [.7, 1.85],
    risk: "low"
}, {
    payouts: [0, 2, 3.8],
    risk: "low"
}, {
    payouts: [0, 1.1, 1.38, 26],
    risk: "low"
}, {
    payouts: [0, 0, 2.2, 7.9, 90],
    risk: "low"
}, {
    payouts: [0, 0, 1.5, 4.2, 13, 300],
    risk: "low"
}, {
    payouts: [0, 0, 1.1, 2, 6.2, 100, 700],
    risk: "low"
}, {
    payouts: [0, 0, 1.1, 1.6, 3.5, 15, 225, 700],
    risk: "low"
}, {
    payouts: [0, 0, 1.1, 1.5, 2, 5.5, 39, 100, 800],
    risk: "low"
}, {
    payouts: [0, 0, 1.1, 1.3, 1.7, 2.5, 7.5, 50, 250, 1e3],
    risk: "low"
}, {
    payouts: [0, 0, 1.1, 1.2, 1.3, 1.8, 3.5, 13, 50, 250, 1e3],
    risk: "low"
}, {
    payouts: [.4, 2.75],
    risk: "medium"
}, {
    payouts: [0, 1.8, 5.1],
    risk: "medium"
}, {
    payouts: [0, 0, 2.8, 50],
    risk: "medium"
}, {
    payouts: [0, 0, 1.7, 10, 100],
    risk: "medium"
}, {
    payouts: [0, 0, 1.4, 4, 14, 390],
    risk: "medium"
}, {
    payouts: [0, 0, 0, 3, 9, 180, 710],
    risk: "medium"
}, {
    payouts: [0, 0, 0, 2, 7, 30, 400, 800],
    risk: "medium"
}, {
    payouts: [0, 0, 0, 2, 4, 11, 67, 400, 900],
    risk: "medium"
}, {
    payouts: [0, 0, 0, 2, 2.5, 5, 15, 100, 500, 1e3],
    risk: "medium"
}, {
    payouts: [0, 0, 0, 1.6, 2, 4, 7, 26, 100, 500, 1e3],
    risk: "medium"
}, {
    payouts: [0, 3.96],
    risk: "high"
}, {
    payouts: [0, 0, 17.1],
    risk: "high"
}, {
    payouts: [0, 0, 0, 81.5],
    risk: "high"
}, {
    payouts: [0, 0, 0, 10, 259],
    risk: "high"
}, {
    payouts: [0, 0, 0, 4.5, 48, 450],
    risk: "high"
}, {
    payouts: [0, 0, 0, 0, 11, 350, 710],
    risk: "high"
}, {
    payouts: [0, 0, 0, 0, 7, 90, 400, 800],
    risk: "high"
}, {
    payouts: [0, 0, 0, 0, 5, 20, 270, 600, 900],
    risk: "high"
}, {
    payouts: [0, 0, 0, 0, 4, 11, 56, 500, 800, 1e3],
    risk: "high"
}, {
    payouts: [0, 0, 0, 0, 3.5, 8, 13, 63, 500, 800, 1e3],
    risk: "high"
}];
const sn = [
    ["75", "25"],
    ["55.76923", "38.46154", "5.769231"],
    ["41.093117", "44.02834", "13.663967", "1.2145749"],
    ["29.98687", "44.42499", "21.419193", "3.9391618", "0.22978444"],
    ["21.657185", "41.64843", "27.76562", "7.933034", "0.9574352", "0.03829741"],
    ["15.469417", "37.126602", "32.12879", "12.692855", "2.3799102", "0.1969581", "0.00547106"],
    ["10.919588", "31.8488", "34.3967", "17.639334", "4.5731606", "0.5879778", "0.03379183", "0.00064365"],
    ["7.610622", "26.471727", "34.744144", "22.236254", "7.483354", "1.3303741", "0.1187834", "0.00468112", "0.00005851"],
    ["5.2323027", "21.404875", "33.50328", "26.058107", "10.944406", "2.5256321", "0.31180644", "0.01909019", "0.00049371", "0.00000366"],
    ["3.5444632", "16.878397", "31.07159", "28.820028", "14.710222", "4.236544", "0.6789334", "0.05747584", "0.0023093", "0.00003539", "0.0000000012"]
];
const an = n => {
        const s = C(),
            e = n.amount.mul(n.payout).toNumber();
        return c("div", {
            className: rn,
            children: [i(we, {
                label: s("common.payout"),
                value: n.payout,
                onChange: () => {},
                readOnly: !0,
                children: "x"
            }), i(dt, {
                label: s("common.win_amount"),
                currencyName: n.currency,
                value: e,
                onChange: () => {}
            }), i(we, {
                label: s("common.payout"),
                value: Number(n.chance),
                onChange: () => {},
                readOnly: !0,
                children: "%"
            })]
        })
    },
    ln = n => {
        const [s, e] = b.exports.useState(!1), [t, a] = b.exports.useState(0), l = b.exports.useCallback(() => {
            e(!1)
        }, []), o = sn.find(p => p.length === n.s_num + 1), h = (o == null ? void 0 : o[t]) || "";
        return c("div", {
            className: "game_select",
            onMouseLeave: l,
            children: [n.wlist.map((p, m) => c("div", {
                className: `select_num ${n.pindex===m?"active":""}`,
                onMouseEnter: () => {
                    e(!0), a(m)
                },
                children: [p.toFixed(2), "\xD7", c("div", {
                    className: "select_num_mask",
                    children: [c("div", {
                        className: "num_top",
                        children: [m, "\xD7", n.pindex === m && i("img", {
                            className: "img_gem",
                            src: q.img_gem
                        }), n.pindex != m && c(H, {
                            children: [i("img", {
                                className: "img_gem cl_black",
                                src: q.img_gem_b
                            }), i("img", {
                                className: "img_gem cl_white",
                                src: q.img_gem_w
                            })]
                        })]
                    }), c("div", {
                        className: "num_bot",
                        children: [m, " Hits"]
                    })]
                })]
            }, m)), s && i(Te, {
                id: "keno-payout",
                children: i(an, {
                    currency: n.currency,
                    payout: n.wlist[t],
                    amount: n.amount,
                    chance: h
                })
            })]
        })
    },
    Qe = n => {
        let s = be.filter(t => t.risk === n.curRisk),
            e = n.selectNumber === 0 ? null : s[n.selectNumber - 1];
        return c("div", {
            className: on,
            children: [i(Te, {
                id: "keno-payout"
            }), c("div", {
                className: cn,
                children: [i("div", {
                    className: "game_payout",
                    children: e == null ? void 0 : e.payouts.map((t, a) => c("div", {
                        className: `payout_item ${n.winNumber===a?"active":""}`,
                        children: [t.toFixed(2), "\xD7"]
                    }, a))
                }), e && i(ln, {
                    wlist: e.payouts,
                    pindex: n.winNumber,
                    amount: n.amount,
                    currency: n.currencyName,
                    s_num: n.selectNumber
                }), !e && i("div", {
                    className: "no_select",
                    children: "Select 1 - 10 numbers to play"
                })]
            })]
        })
    },
    on = "kz1aw1l",
    cn = "k1mjkcj",
    rn = "p9stvxn";
V({
    cl1: ["#31343c", "#eef1f8"],
    cl2: ["#24262b", "#d9dce5"],
    cl3: ["#99a4b0", "#99a4b0"],
    cl4: ["#24262B", "#E1E3EC"],
    cl5: ["#1E2024", "#D4D5DF"],
    cl6: [v("#99A4B0", .4), v("#99A4B0", .6)],
    cl7: ["#40434c", "#E0E4F9"],
    cl8: ["#24262b", "#CACEDF"],
    cl9: ["#101112", "#5E6682"],
    cl10: ["#000", "#505873"]
});
const un = "ky302xr",
    Ze = D.memo(function(e) {
        var t = e,
            {
                className: n
            } = t,
            s = ce(t, ["className"]);
        return i("div", oe({
            className: F(un, n)
        }, s))
    });
const hn = I(() => {
        const n = S(),
            s = n.nums.filter(t => t.select).length === 0,
            e = async () => {
                if (!n.disabledChoose) try {
                    n.autoBet.isRunning ? await n.autoBet.stop() : await n.autoBet.start()
                } catch (t) {
                    B(t)
                }
            };
        return i(ze, {
            canBet: s,
            isBetting: n.isBetting,
            gameName: n.name,
            isRuning: n.autoBet.isRunning,
            onClick: e,
            showKey: n.settings.hotkeyEnable,
            random: n.random,
            clear: n.clearSelect,
            onChangeRisk: n.changeRisk,
            risk: n.risk,
            riskOptions: n.riskOptions,
            isMulti: !1
        })
    }),
    mn = I(() => {
        const n = S(),
            s = n.nums.filter(t => t.select).length === 0,
            e = async () => {
                try {
                    await n.handleBet()
                } catch (t) {
                    B(t)
                }
            };
        return i(Ye, {
            canBet: s,
            isBetting: n.isBetting,
            gameName: n.name,
            disabledChoose: n.disabledChoose,
            onClick: e,
            showKey: n.settings.hotkeyEnable,
            random: n.random,
            clear: n.clearSelect,
            onChangeRisk: n.changeRisk,
            risk: n.risk,
            riskOptions: n.riskOptions,
            isMulti: !1
        })
    }),
    dn = I(() => {
        const n = S(),
            s = te.useSingleDetail();
        return i(Pe, {
            list: n.myBets,
            keyof: "betId",
            onDetail: s
        })
    }),
    fn = () => {
        const n = S(),
            [s, e] = Ce();
        return b.exports.useEffect(() => {
            if (n.realResultPayout > 0) {
                let t = window.setTimeout(() => {
                    e({
                        profitAmount: new L(n.amount).mul(n.realResultPayout).toNumber(),
                        currencyName: n.currencyName,
                        odds: n.resultPayout,
                        isBigWin: n.bigwin,
                        enableSound: n.settings.soundEnable
                    })
                }, n.delayTime * 17);
                return () => {
                    clearTimeout(t)
                }
            } else e(null)
        }, [n.realResultPayout]), c(H, {
            children: [i(dn, {}), c(Ae, {
                className: yn,
                children: [i(Re, {}), i(Ze, {
                    className: F(pn, "keno-single"),
                    children: c("div", {
                        className: "keno-wrap",
                        children: [c("div", {
                            className: "keno-item-wrap",
                            children: [i(Ue, {
                                nums: n.nums,
                                disabledItem: n.disabledItem,
                                beforeResult: n.beforeResult,
                                resultPayout: n.resultPayout,
                                bigwin: n.bigwin,
                                amount: n.amount,
                                currencyName: n.currencyName,
                                realResultPayout: n.realResultPayout,
                                delayTime: n.delayTime,
                                onAddItem: n.addItem
                            }), s]
                        }), i(Qe, {
                            selectNumber: n.selectList.length,
                            winNumber: n.winNumber,
                            curRisk: n.curRisk,
                            amount: n.amount,
                            currencyName: n.currencyName,
                            riskOptions: n.riskOptions
                        }), i("div", {
                            className: "bottom-line"
                        })]
                    })
                })]
            })]
        })
    };
var bn = I(fn);
const pn = "s137b11",
    yn = "g1rwz6ls",
    gn = D.memo(() => {
        const n = C(),
            s = S(),
            e = [{
                title: n("common.game_intro"),
                node: i(jt, {})
            }, {
                title: n("common.fairness"),
                node: "/kenos_help/fairness"
            }, {
                title: n("common.bankroll"),
                node: i(Ht, {
                    game: s
                })
            }];
        return i(xe, {
            gameView: i(bn, {}),
            manualControl: i(mn, {}),
            autoControl: i(hn, {}),
            tabs: [{
                label: n("common.all_bet"),
                value: () => i(te.AllBet, {})
            }, {
                label: n("common.my_bet"),
                value: () => i(te.MyBet, {})
            }],
            actions: [i(_e, {}), i(Ee, {}), i(je, {}), i(ft, {}), i(Le, {
                list: e
            })]
        })
    }),
    se = E.Reader,
    Xe = E.Writer,
    K = E.roots.kenoSingle || (E.roots.kenoSingle = {});
K.BetValue = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.betNums = "", n.encode = function(e, t) {
        return t || (t = Xe.create()), e.betNums != null && Object.hasOwnProperty.call(e, "betNums") && t.uint32(10).string(e.betNums), t
    }, n.decode = function(e, t) {
        e instanceof se || (e = se.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new K.BetValue;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.betNums = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
K.GameValue = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.result = "", n.encode = function(e, t) {
        return t || (t = Xe.create()), e.result != null && Object.hasOwnProperty.call(e, "result") && t.uint32(10).string(e.result), t
    }, n.decode = function(e, t) {
        e instanceof se || (e = se.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new K.GameValue;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.result = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
var kn = "/assets/active.ac156854.mp3",
    vn = "/assets/bigwin.8542e187.mp3",
    wn = "/assets/hit.f38b3fdb.mp3",
    Nn = "/assets/skip.2122e51f.mp3",
    In = "/assets/play.272ff764.mp3",
    Sn = "/assets/win.1981b036.mp3",
    On = "/assets/select.278ecc75.mp3",
    Bn = "/assets/clear.6d465251.mp3";
const et = {
    sound_active: kn,
    sound_bigwin: vn,
    sound_hit: wn,
    sound_noactive: Nn,
    sound_play: In,
    sound_result: Sn,
    sound_select: On,
    sound_clear: Bn
};
class Tn extends bt {
    constructor() {
        super({
            name: "KenoSingle",
            namespace: "/g/kenos",
            sounds: et,
            fairLink: "/kenos_help/fairness",
            validateLink: "/kenos_help/validate"
        }, gn), this.risk = 1, this.nums = [], this.runing = !1, this.canChoose = !0, this.delayTime = 110, this.disabledChoose = !1, this.resultPayout = 0, this.realResultPayout = 0, this.betLoading = !1, this.hasMask = !1, this.beforeResult = [], this.bigwin = !1, this.timer = -1, this.gameValueDecoder = P.decode(K.GameValue), this.theme = {
            text: "#d9ebf6",
            main: "#373850",
            dark: "#2d2e41",
            dark2: "#303148",
            light: "#2b2a3a"
        }, this.riskOptions = [{
            label: "Low",
            value: 0
        }, {
            label: "Classic",
            value: 1
        }, {
            label: "Medium",
            value: 2
        }, {
            label: "High",
            value: 3
        }], this.onBetRequest = async e => {
            this.sounds.playSound("sound_play"), this.clearActive();
            let t = await e,
                a = t.gameValue;
            this.beforeResult = a.result.split(","), this.setPr(ne(a.result.split(","), 10), o => o.active = !0), t.odds > 0 && (this.realResultPayout = Number(new L(t.winAmount).div(t.betAmount).toFixed(2)), this.resultPayout = t.odds), await ee(this.delayTime * 11), this.bigwin = this.nums.filter(o => o.select && o.active).length === 10;
            let l = this.autoBet.isRunning ? 3e3 : 1500;
            return await ee(l), t
        }, He(this, {
            risk: k,
            nums: k,
            runing: k,
            canChoose: k,
            delayTime: k,
            disabledChoose: k,
            resultPayout: k,
            realResultPayout: k,
            betLoading: k,
            hasMask: k,
            beforeResult: k,
            bigwin: k,
            maxProfit: A,
            disabledItem: A,
            selectList: A,
            winNumber: A,
            curRisk: A,
            clearSelect: M,
            resetStatus: M,
            clearAll: M,
            clearActive: M
        });
        for (let e = 0; e < 40; e++) this.nums.push({
            num: e + 1,
            active: !1,
            select: !1
        });
        this.addItem = this.addItem.bind(this), this.canSelect = this.canSelect.bind(this), this.random = this.random.bind(this), this.clearSelect = this.clearSelect.bind(this), this.addHotkey("q", this.random, "Auto pick tiles"), this.addHotkey("w", this.clearSelect, "Clear table"), this.changeRisk = this.changeRisk.bind(this);
        const s = this.hotkeyList.find(e => e.key == "space");
        s && (s.handler = () => {
            if (this.disabledChoose) return;
            if (this.nums.filter(t => t.select).length === 0) return B(new Error("Please choose 1 - 10 numbers"));
            if (this.controlIdx === 1) this.autoBet.isRunning ? this.autoBet.stop() : this.isBetting || this.autoBet.start();
            else {
                if (this.isBetting) return !1;
                this.handleBet()
            }
            return !1
        })
    }
    get maxProfit() {
        const s = be.find(e => e.risk === this.curRisk && e.payouts.length === this.selectList.length + 1);
        if (s) {
            const e = Math.max(...s.payouts);
            return this.amount.mul(e).sub(this.amount)
        }
        return new L(0)
    }
    clearSelect(s = !0) {
        this.isBetting || this.disabledChoose || (this.clearActive(), s && this.sounds.playSound("sound_clear"), this.hasMask = !1, this.nums.forEach(e => {
            e.select = !1
        }))
    }
    get disabledItem() {
        return this.hasMask || this.autoBet.isRunning || this.isBetting
    }
    get selectList() {
        return this.nums.filter(s => s.select)
    }
    get winNumber() {
        let s = this.nums.filter(t => t.active).length > 0,
            e = this.nums.filter(t => t.active && t.select).length;
        return s ? e : -1
    }
    get curRisk() {
        return this.riskOptions[this.risk].label.toLocaleLowerCase()
    }
    changeRisk(s) {
        this.risk = s
    }
    clearActive() {
        this.runing || this.nums.filter(s => s.active).length !== 0 && (this.resetStatus(), clearTimeout(this.timer), this.nums.forEach(s => {
            s.active = !1
        }))
    }
    resetStatus(s = 0, e = [], t = !1) {
        this.realResultPayout = s, this.resultPayout = s, this.beforeResult = e, this.bigwin = t
    }
    setPr(s, e) {
        return new Promise(t => {
            let a = 0;
            clearInterval(this.timer), this.timer = window.setInterval(() => {
                e(this.nums[Number(s[a]) - 1]), a === 9 ? (clearInterval(this.timer), t(!0)) : a++
            }, this.delayTime)
        })
    }
    async random() {
        this.disabledChoose || this.isBetting || (this.clearSelect(!1), this.disabledChoose = !0, this.hasMask = !0, await this.setPr(ne(this.nums.map(s => s.num), 10), s => s.select = !0), this.disabledChoose = !1)
    }
    addItem(s) {
        if (this.isBetting || this.autoBet.isRunning) return;
        this.nums.filter(t => t.active).length > 0 && this.clearActive();
        const e = this.nums[s - 1];
        e.select == !0 ? e.select = !1 : this.canSelect() && (e.select = !0), this.hasMask = !this.canSelect()
    }
    canSelect() {
        return this.nums.filter(s => s.select).length < 10
    }
    betValue() {
        let s = this.riskOptions[this.risk].label.toLocaleLowerCase(),
            e = this.nums.filter(t => t.select).map(t => t.num).join(",");
        return P.encode(K.BetValue)({
            betNums: s + ":" + e
        })
    }
    deactivate() {
        clearInterval(this.timer), this.clearAll(), super.deactivate()
    }
    clearAll() {
        this.realResultPayout = 0, this.resultPayout = 0, this.hasMask = !1, this.nums.forEach(s => {
            s.active = !1, s.select = !1
        })
    }
}
const tt = new Tn;
var _s = tt;
window.dg = tt;

function Es({
    bodyLock: n
}) {
    return i(Ve, {
        bodyLock: n,
        children: c("div", {
            className: "item",
            children: [i("h2", {
                children: "How Are the Results Calculated? "
            }), i("div", {
                className: "content",
                children: i("p", {
                    children: "To get the results, we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                })
            })]
        })
    })
}
const Pn = () => {
    const n = Ge(),
        s = Me(n),
        e = Rt(() => ({
            serverSeed: s[0] || "",
            clientSeed: s[1] || "",
            nonce: parseInt(s[2]) || 0
        })),
        {
            serverSeed: t,
            clientSeed: a,
            nonce: l
        } = e,
        o = String(Y(t)),
        p = String(pt([a, l].join(":"), t)),
        m = Cn(p).sort((d, f) => d - f);
    return i(ie, {
        title: ae.t("common.fairness"),
        children: c(W, {
            className: An,
            children: [i("h2", {
                children: "Input"
            }), i(R, {
                label: "Server Seed",
                value: t,
                onChange: d => e.serverSeed = d
            }), i(R, {
                label: "Client Seed",
                value: a,
                onChange: d => e.clientSeed = d
            }), i(R, {
                label: "Nonce",
                value: l,
                onChange: d => e.nonce = Number(d)
            }), i("h2", {
                children: "Output"
            }), i(R, {
                label: "Sha256(server_seed)",
                value: o,
                readOnly: !0
            }), i(R, {
                label: "Hmac_sha256(client_seed:nonce, server_seed)",
                value: p,
                readOnly: !0
            }), i("h2", {
                children: "Final Result"
            }), i("div", {
                className: "result-list",
                children: m.map(d => i("div", {
                    className: "keno-range",
                    children: d
                }, d))
            }), i(de, {
                style: {
                    marginBottom: "1.5rem"
                },
                children: `import CryptoJS from "crypto-js";

function createNums(allNums, hash) {
  const nums = [];
  let h = CryptoJS.SHA256(hash).toString(CryptoJS.enc.Hex);
  allNums.forEach((c) => {
    nums.push({ num: c, hash: h });
    h = h.substring(1) + h.charAt(0);
  });
  nums.sort(function (o1, o2) {
    if (o1.hash < o2.hash) {
      return -1;
    } else if (o1.hash === o2.hash) {
      return 0;
    } else {
      return 1;
    }
  });
  return nums;
}
function keno(hash) {
  const allNums = [
    1, 30, 11, 40, 2, 29, 12, 39, 3,
    28, 13, 38, 4, 27, 14, 37, 5, 26,
    15, 36, 6, 25, 16, 35, 7, 24, 17,
    34, 8, 23, 18, 33, 9, 22, 19, 32,
    10, 21, 20, 31
  ];
  const seed = String(CryptoJS.SHA256(hash));
  let finalNums = createNums(allNums, hash);
  finalNums = createNums(finalNums, seed);
  return finalNums.slice(0, 10).map((m) => m.num);
}
let hash = "game hash";
console.log( "result =>", keno(hash).map((item) => item.num).join(","));
`
            })]
        })
    })
};
var js = Pn;

function Ie(n, s) {
    const e = [];
    let t = Y(s).toString(X);
    return n.forEach(a => {
        e.push({
            num: a,
            hash: t
        }), t = t.substring(1) + t.charAt(0)
    }), e.sort(function(a, l) {
        return a.hash < l.hash ? -1 : a.hash === l.hash ? 0 : 1
    }), e
}

function Cn(n) {
    const s = [1, 30, 11, 40, 2, 29, 12, 39, 3, 28, 13, 38, 4, 27, 14, 37, 5, 26, 15, 36, 6, 25, 16, 35, 7, 24, 17, 34, 8, 23, 18, 33, 9, 22, 19, 32, 10, 21, 20, 31];
    let e = n,
        t = Ie(s, e);
    return e = String(Y(e)), t = Ie(t, e), t.slice(0, 10).map(a => a.num.num)
}
V({
    cl1: [v("#99a4b0", .8), v("#5f6975", .8)],
    cl2: ["#31343c", "#f6f6f9"],
    cl3: ["#fff", "#000"]
});
const An = "f15wsse0";
const nt = ({
        list: n
    }) => i("div", {
        className: Rn,
        children: i(xn, {
            list: n
        })
    }),
    Rn = "kboiah8",
    xn = ({
        list: n
    }) => i("div", {
        className: _n,
        children: n.map(s => {
            let e = "keno-ritem";
            return e += s.select ? " select" : "", e += s.active ? " active" : "", c("div", {
                className: e,
                children: [i("div", {
                    className: "keno-win",
                    children: i("img", {
                        className: "win-gem",
                        src: q.imggem,
                        alt: ""
                    })
                }), i("span", {
                    className: "keno-num",
                    children: s.num
                })]
            }, s.num)
        })
    }),
    _n = "k1azlbp3",
    En = (n, s, e) => {
        yt(`/kenos_help/validate/${n}/${s}/${e}`)
    },
    jn = te.withSingleDetail({
        onValidate: En,
        result: ({
            betLog: n
        }) => {
            const s = [];
            for (let a = 0; a < 40; a++) s.push({
                active: !1,
                activeTime: 0,
                num: a + 1,
                select: !1,
                selectTime: 0
            });
            const e = n.bv.betNums.split(":")[1].split(","),
                t = n.gv.result.split(",");
            return e.forEach((a, l) => {
                let o = s[Number(a) - 1];
                o.select = !0, o.selectTime = l * 100
            }), t.forEach((a, l) => {
                let o = s[Number(a) - 1];
                o.active = !0, o.activeTime = l * 100
            }), i(nt, {
                list: s
            })
        }
    });
var Ls = jn;
const g = E.Reader,
    T = E.Writer,
    u = E.util,
    r = E.roots.keno || (E.roots.keno = {});
r.Prepare = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.serverTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.prepareTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.startTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.encode = function(e, t) {
        return t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), e.serverTime != null && Object.hasOwnProperty.call(e, "serverTime") && t.uint32(16).int64(e.serverTime), e.prepareTime != null && Object.hasOwnProperty.call(e, "prepareTime") && t.uint32(24).int64(e.prepareTime), e.startTime != null && Object.hasOwnProperty.call(e, "startTime") && t.uint32(32).int64(e.startTime), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.Prepare;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                case 2:
                    l.serverTime = e.int64();
                    break;
                case 3:
                    l.prepareTime = e.int64();
                    break;
                case 4:
                    l.startTime = e.int64();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.ThrowBetRequest = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.currencyName = "", n.prototype.bet = "", n.prototype.betValue = "", n.prototype.scriptId = 0, n.prototype.frontgroundId = 0, n.encode = function(e, t) {
        return t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), e.currencyName != null && Object.hasOwnProperty.call(e, "currencyName") && t.uint32(18).string(e.currencyName), e.bet != null && Object.hasOwnProperty.call(e, "bet") && t.uint32(26).string(e.bet), e.betValue != null && Object.hasOwnProperty.call(e, "betValue") && t.uint32(34).string(e.betValue), e.scriptId != null && Object.hasOwnProperty.call(e, "scriptId") && t.uint32(40).int32(e.scriptId), e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && t.uint32(48).int32(e.frontgroundId), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.ThrowBetRequest;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                case 2:
                    l.currencyName = e.string();
                    break;
                case 3:
                    l.bet = e.string();
                    break;
                case 4:
                    l.betValue = e.string();
                    break;
                case 5:
                    l.scriptId = e.int32();
                    break;
                case 6:
                    l.frontgroundId = e.int32();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.PlayerInfo = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.userId = 0, n.prototype.name = "", n.prototype.avatar = "", n.encode = function(e, t) {
        return t || (t = T.create()), e.userId != null && Object.hasOwnProperty.call(e, "userId") && t.uint32(8).int32(e.userId), e.name != null && Object.hasOwnProperty.call(e, "name") && t.uint32(18).string(e.name), e.avatar != null && Object.hasOwnProperty.call(e, "avatar") && t.uint32(26).string(e.avatar), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.PlayerInfo;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.userId = e.int32();
                    break;
                case 2:
                    l.name = e.string();
                    break;
                case 3:
                    l.avatar = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.Bet = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.userId = 0, n.prototype.chips = 0, n.prototype.betValue = "", n.prototype.name = "", n.prototype.currencyName = "", n.prototype.amount = "", n.prototype.betTimes = 0, n.prototype.chipsAmount = "", n.prototype.betId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.encode = function(e, t) {
        return t || (t = T.create()), e.userId != null && Object.hasOwnProperty.call(e, "userId") && t.uint32(8).int32(e.userId), e.chips != null && Object.hasOwnProperty.call(e, "chips") && t.uint32(16).int32(e.chips), e.betValue != null && Object.hasOwnProperty.call(e, "betValue") && t.uint32(26).string(e.betValue), e.name != null && Object.hasOwnProperty.call(e, "name") && t.uint32(34).string(e.name), e.currencyName != null && Object.hasOwnProperty.call(e, "currencyName") && t.uint32(42).string(e.currencyName), e.amount != null && Object.hasOwnProperty.call(e, "amount") && t.uint32(50).string(e.amount), e.betTimes != null && Object.hasOwnProperty.call(e, "betTimes") && t.uint32(56).int32(e.betTimes), e.chipsAmount != null && Object.hasOwnProperty.call(e, "chipsAmount") && t.uint32(66).string(e.chipsAmount), e.betId != null && Object.hasOwnProperty.call(e, "betId") && t.uint32(72).int64(e.betId), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.Bet;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.userId = e.int32();
                    break;
                case 2:
                    l.chips = e.int32();
                    break;
                case 3:
                    l.betValue = e.string();
                    break;
                case 4:
                    l.name = e.string();
                    break;
                case 5:
                    l.currencyName = e.string();
                    break;
                case 6:
                    l.amount = e.string();
                    break;
                case 7:
                    l.betTimes = e.int32();
                    break;
                case 8:
                    l.chipsAmount = e.string();
                    break;
                case 9:
                    l.betId = e.int64();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.Begin = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.startTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.encode = function(e, t) {
        return t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), e.startTime != null && Object.hasOwnProperty.call(e, "startTime") && t.uint32(16).int64(e.startTime), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.Begin;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                case 2:
                    l.startTime = e.int64();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.End = (() => {
    function n(s) {
        if (this.list = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.resultCards = "", n.prototype.betValue = "", n.prototype.hash = "", n.prototype.list = u.emptyArray, n.encode = function(e, t) {
        if (t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), e.resultCards != null && Object.hasOwnProperty.call(e, "resultCards") && t.uint32(18).string(e.resultCards), e.betValue != null && Object.hasOwnProperty.call(e, "betValue") && t.uint32(26).string(e.betValue), e.hash != null && Object.hasOwnProperty.call(e, "hash") && t.uint32(34).string(e.hash), e.list != null && e.list.length)
            for (let a = 0; a < e.list.length; ++a) r.EndWin.encode(e.list[a], t.uint32(42).fork()).ldelim();
        return t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.End;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                case 2:
                    l.resultCards = e.string();
                    break;
                case 3:
                    l.betValue = e.string();
                    break;
                case 4:
                    l.hash = e.string();
                    break;
                case 5:
                    l.list && l.list.length || (l.list = []), l.list.push(r.EndWin.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.EndWin = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.userId = 0, n.prototype.winAmount = "", n.prototype.payout = 0, n.encode = function(e, t) {
        return t || (t = T.create()), e.userId != null && Object.hasOwnProperty.call(e, "userId") && t.uint32(8).int32(e.userId), e.winAmount != null && Object.hasOwnProperty.call(e, "winAmount") && t.uint32(18).string(e.winAmount), e.payout != null && Object.hasOwnProperty.call(e, "payout") && t.uint32(24).int32(e.payout), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.EndWin;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.userId = e.int32();
                    break;
                case 2:
                    l.winAmount = e.string();
                    break;
                case 3:
                    l.payout = e.int32();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.Settle = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.encode = function(e, t) {
        return t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.Settle;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.GameInfo = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.hash = "", n.prototype.betValue = "", n.encode = function(e, t) {
        return t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), e.hash != null && Object.hasOwnProperty.call(e, "hash") && t.uint32(42).string(e.hash), e.betValue != null && Object.hasOwnProperty.call(e, "betValue") && t.uint32(50).string(e.betValue), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.GameInfo;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                case 5:
                    l.hash = e.string();
                    break;
                case 6:
                    l.betValue = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.GameHistory = (() => {
    function n(s) {
        if (this.list = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.page = 0, n.prototype.pageSize = 0, n.prototype.total = 0, n.prototype.totalPage = 0, n.prototype.list = u.emptyArray, n.encode = function(e, t) {
        if (t || (t = T.create()), e.page != null && Object.hasOwnProperty.call(e, "page") && t.uint32(8).int32(e.page), e.pageSize != null && Object.hasOwnProperty.call(e, "pageSize") && t.uint32(16).int32(e.pageSize), e.total != null && Object.hasOwnProperty.call(e, "total") && t.uint32(24).int32(e.total), e.totalPage != null && Object.hasOwnProperty.call(e, "totalPage") && t.uint32(32).int32(e.totalPage), e.list != null && e.list.length)
            for (let a = 0; a < e.list.length; ++a) r.GameInfo.encode(e.list[a], t.uint32(42).fork()).ldelim();
        return t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.GameHistory;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.page = e.int32();
                    break;
                case 2:
                    l.pageSize = e.int32();
                    break;
                case 3:
                    l.total = e.int32();
                    break;
                case 4:
                    l.totalPage = e.int32();
                    break;
                case 5:
                    l.list && l.list.length || (l.list = []), l.list.push(r.GameInfo.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.GameInit = (() => {
    function n(s) {
        if (this.bets = [], this.players = [], this.history = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.gameId = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.status = 0, n.prototype.prepareTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.startTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.prototype.hash = "", n.prototype.betValue = "", n.prototype.bets = u.emptyArray, n.prototype.players = u.emptyArray, n.prototype.history = u.emptyArray, n.prototype.serverTime = u.Long ? u.Long.fromBits(0, 0, !1) : 0, n.encode = function(e, t) {
        if (t || (t = T.create()), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && t.uint32(8).int64(e.gameId), e.status != null && Object.hasOwnProperty.call(e, "status") && t.uint32(16).int32(e.status), e.prepareTime != null && Object.hasOwnProperty.call(e, "prepareTime") && t.uint32(24).int64(e.prepareTime), e.startTime != null && Object.hasOwnProperty.call(e, "startTime") && t.uint32(32).int64(e.startTime), e.hash != null && Object.hasOwnProperty.call(e, "hash") && t.uint32(42).string(e.hash), e.betValue != null && Object.hasOwnProperty.call(e, "betValue") && t.uint32(50).string(e.betValue), e.bets != null && e.bets.length)
            for (let a = 0; a < e.bets.length; ++a) r.Bet.encode(e.bets[a], t.uint32(58).fork()).ldelim();
        if (e.players != null && e.players.length)
            for (let a = 0; a < e.players.length; ++a) r.PlayerInfo.encode(e.players[a], t.uint32(66).fork()).ldelim();
        if (e.history != null && e.history.length)
            for (let a = 0; a < e.history.length; ++a) r.GameInfo.encode(e.history[a], t.uint32(74).fork()).ldelim();
        return e.serverTime != null && Object.hasOwnProperty.call(e, "serverTime") && t.uint32(80).int64(e.serverTime), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.GameInit;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.gameId = e.int64();
                    break;
                case 2:
                    l.status = e.int32();
                    break;
                case 3:
                    l.prepareTime = e.int64();
                    break;
                case 4:
                    l.startTime = e.int64();
                    break;
                case 5:
                    l.hash = e.string();
                    break;
                case 6:
                    l.betValue = e.string();
                    break;
                case 7:
                    l.bets && l.bets.length || (l.bets = []), l.bets.push(r.Bet.decode(e, e.uint32()));
                    break;
                case 8:
                    l.players && l.players.length || (l.players = []), l.players.push(r.PlayerInfo.decode(e, e.uint32()));
                    break;
                case 9:
                    l.history && l.history.length || (l.history = []), l.history.push(r.GameInfo.decode(e, e.uint32()));
                    break;
                case 10:
                    l.serverTime = e.int64();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.Jackpot = (() => {
    function n(s) {
        if (this.infos = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.infos = u.emptyArray, n.encode = function(e, t) {
        if (t || (t = T.create()), e.infos != null && e.infos.length)
            for (let a = 0; a < e.infos.length; ++a) r.Jackpot.Info.encode(e.infos[a], t.uint32(10).fork()).ldelim();
        return t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.Jackpot;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.infos && l.infos.length || (l.infos = []), l.infos.push(r.Jackpot.Info.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n.Info = function() {
        function s(e) {
            if (e)
                for (let t = Object.keys(e), a = 0; a < t.length; ++a) e[t[a]] != null && (this[t[a]] = e[t[a]])
        }
        return s.prototype.currencyName = "", s.prototype.jackpotAmount = u.Long ? u.Long.fromBits(0, 0, !1) : 0, s.prototype.maxBetAmount = u.Long ? u.Long.fromBits(0, 0, !1) : 0, s.prototype.minBetAmount = u.Long ? u.Long.fromBits(0, 0, !1) : 0, s.prototype.maxProfitAmount = u.Long ? u.Long.fromBits(0, 0, !1) : 0, s.encode = function(t, a) {
            return a || (a = T.create()), t.currencyName != null && Object.hasOwnProperty.call(t, "currencyName") && a.uint32(10).string(t.currencyName), t.jackpotAmount != null && Object.hasOwnProperty.call(t, "jackpotAmount") && a.uint32(16).sint64(t.jackpotAmount), t.maxBetAmount != null && Object.hasOwnProperty.call(t, "maxBetAmount") && a.uint32(24).sint64(t.maxBetAmount), t.minBetAmount != null && Object.hasOwnProperty.call(t, "minBetAmount") && a.uint32(32).sint64(t.minBetAmount), t.maxProfitAmount != null && Object.hasOwnProperty.call(t, "maxProfitAmount") && a.uint32(40).sint64(t.maxProfitAmount), a
        }, s.decode = function(t, a) {
            t instanceof g || (t = g.create(t));
            let l = a === void 0 ? t.len : t.pos + a,
                o = new r.Jackpot.Info;
            for (; t.pos < l;) {
                let h = t.uint32();
                switch (h >>> 3) {
                    case 1:
                        o.currencyName = t.string();
                        break;
                    case 2:
                        o.jackpotAmount = t.sint64();
                        break;
                    case 3:
                        o.maxBetAmount = t.sint64();
                        break;
                    case 4:
                        o.minBetAmount = t.sint64();
                        break;
                    case 5:
                        o.maxProfitAmount = t.sint64();
                        break;
                    default:
                        t.skipType(h & 7);
                        break
                }
            }
            return o
        }, s
    }(), n
})();
r.Init = (() => {
    function n(s) {
        if (this.jackpot = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.jackpot = u.emptyArray, n.encode = function(e, t) {
        if (t || (t = T.create()), e.jackpot != null && e.jackpot.length)
            for (let a = 0; a < e.jackpot.length; ++a) r.Jackpot.Info.encode(e.jackpot[a], t.uint32(10).fork()).ldelim();
        return t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.Init;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.jackpot && l.jackpot.length || (l.jackpot = []), l.jackpot.push(r.Jackpot.Info.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
r.CommonEvent = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.eventName = "", n.prototype.dataString = "", n.encode = function(e, t) {
        return t || (t = T.create()), e.eventName != null && Object.hasOwnProperty.call(e, "eventName") && t.uint32(10).string(e.eventName), e.dataString != null && Object.hasOwnProperty.call(e, "dataString") && t.uint32(18).string(e.dataString), t
    }, n.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let a = t === void 0 ? e.len : e.pos + t,
            l = new r.CommonEvent;
        for (; e.pos < a;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    l.eventName = e.string();
                    break;
                case 2:
                    l.dataString = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return l
    }, n
})();
var z = {
    KENO_CURRENCY: "/keno/currency/",
    KENO_PLAY: "/keno/play/",
    KENO_RANDOM: "/keno/randomize/",
    KENO_MYBET: "/game/support/bet-log/my-bet/",
    KENO_HISTORY: "/keno/history/",
    KENO_PAYOUTS: "/keno/odds/",
    KENO_ADDFAVORITE: "/keno/addFavorite/",
    KENO_GETFAVORITE: "/keno/getFavorite/",
    KENO_DETAIL: n => `/keno/${n}/detail/`,
    KENO_MYDETAIL: n => `/keno/${n}/myDetail/`,
    KENO_DETAIL_AMOUNT: n => `/keno/game/${n}/detail-amount/`,
    KENO_DELETFAVORITE: n => `/keno/deleteFavorite/${n}/`,
    KENO_HASH: (n, s) => `/single/game/bet/${n}/${s}/`
};

function st(n) {
    return J.post(z.KENO_HISTORY, n)
}

function Ln() {
    S();
    const [n, s] = b.exports.useState({
        page: 1,
        pageSize: 20
    }), e = b.exports.useMemo(() => st(n), [n.page]);
    return i("div", {
        className: Gn,
        children: i(fe, {
            pms: e,
            children: t => t.list.length ? c(H, {
                children: [i(Hn, {
                    list: t.list,
                    params: n
                }), i(De, {
                    page: t.page,
                    total: t.total,
                    limit: t.pageSize,
                    onChange: a => s(ve(oe({}, n), {
                        page: a
                    })),
                    type: "pageConic2"
                })]
            }) : i($e, {})
        })
    })
}
const Hn = I(function(s) {
    const e = C(),
        t = S(),
        [a, l] = b.exports.useState(s.list);
    return b.exports.useEffect(() => {
        let o = !1,
            h = setInterval(() => {
                o || st(s.params).then(p => {
                    o || l(p.list)
                }).catch(p => {
                    console.error(p)
                })
            }, 2e4);
        return () => {
            o = !0, window.clearInterval(h)
        }
    }, []), c("div", {
        className: Mn,
        children: [c("div", {
            className: "head flex",
            children: [i("div", {
                className: "col",
                children: e("common.game_number")
            }), i("div", {
                className: "col",
                children: e("common.result")
            }), i("div", {
                className: "col-2",
                children: e("common.hash")
            })]
        }), i("ul", {
            className: "list",
            children: a.map(o => c("li", {
                className: "item flex",
                children: [i("div", {
                    className: "col hover",
                    onClick: () => U.openAllPlayers({
                        gameName: t.name,
                        gameId: o.gameId
                    }),
                    children: o.gameId
                }), i("div", {
                    className: "col",
                    children: i("div", {
                        children: o.resultCards
                    })
                }), c("div", {
                    className: "seed-box col-2",
                    children: [i("input", {
                        type: "text",
                        className: "seed",
                        value: o.hash,
                        readOnly: !0
                    }), i(gt, {
                        className: "cl-primary",
                        to: `/keno_help/validate/${o.hash}`,
                        children: e("common.verify")
                    })]
                })]
            }, o.gameId))
        })]
    })
});
var Vn = I(Ln);
V({
    cl1: [v("#2d3035", .6), v("#dadde6", .6)],
    cl2: [v("#2d3035", .4), v("#dadde6", .3)]
});
const Gn = "h1qwbfva";
V({
    cl1: ["#99a4b0", "#5f6975"],
    cl2: ["#2d3035", v("#e9eaf2", .6)],
    cl3: [v("#99a4b0", .6), "#5f6975"]
});
const Mn = "lflyk2e",
    Dn = D.memo(() => i(W, {
        children: c("div", {
            className: "helpcon",
            children: [i("h2", {
                children: " What Is Keno? "
            }), i("div", {
                className: "help-content",
                children: c("p", {
                    children: ["Keno is a fast-paced, fun game that allows you to choose:", i("br", {}), "\u2022 How many numbers to play with", i("br", {}), "\u2022 How many coins to wager", i("br", {}), "\u2022 Where to play and check your winning numbers -Keno is played by choosing up to 10 numbers from a total set of numbers from 1 to 40."]
                })
            }), i("h2", {
                children: "How to Play Keno? "
            }), c("div", {
                className: "help-content",
                children: [i("p", {
                    children: "1. More the number combinations selected, higher the potential payout."
                }), i("p", {
                    children: "2.The more selections hit successfully, the higher will be the payout multiplier."
                }), i("p", {
                    children: "3.Maximum possible selection and maximum possible successful hits is 10."
                })]
            }), i("h2", {
                children: "What is the House Edge of Keno?"
            }), i("div", {
                className: "help-content",
                children: "1% house edge."
            }), i("h2", {
                children: "Auto Mode Operation Instructions"
            }), c("div", {
                className: "help-content",
                children: [i("p", {
                    children: "[ ON WIN ] when you win, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                }), i("p", {
                    children: "[ ON LOSE ] when you lose, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                }), i("p", {
                    children: "[ STOP ON WIN ] Once the amount winned (from start to this bet) is bigger/equal than _(your set)_ , auto will stop;"
                }), i("p", {
                    children: "[ STOP ON LOSS ] Once the amount lost (from start to next bet) may be bigger/equal than _(your set)_ , auto will stop."
                })]
            })]
        })
    }));

function $n({
    bodyLock: n
}) {
    return i(Ve, {
        className: Fn,
        bodyLock: n,
        children: c("div", {
            className: "item",
            children: [c("p", {
                style: {
                    wordBreak: "break-word"
                },
                children: ["Starting with a secret I've generated a chain of 10,000,000 SHA256 hashes. ", i("br", {}), "Each element is the hash of the lowercase, hexadecimal string representation of the previous hash. The hash of the chain's last element is 54fe30623823224ef8379e00f3d88a02ed3333937862ee0383b9cbb3d1e43763", " ", i("br", {}), "Every game maps to a hash in the chain: The 10,000,000th element of the chain is the hash of game #1 and the first element in the chain is the hash of game #10,000,000. ", i("br", {}), "To verify that a hash belongs to a game #n, simply hash it n times and compare the result with the terminating hash."]
            }), c("p", {
                children: ["To calculate a game's result from its hash: ", i("br", {}), "Code:"]
            }), i(de, {
                children: `const crypto = require("crypto");
  function seedGenerator(hash, salt) {
    const hmac = CryptoJS.HmacSHA256(CryptoJS.enc.Hex.parse(hash), salt);
    return hmac.toString(CryptoJS.enc.Hex);
  }
  function createNums(allNums, hash) {
    const nums = [];
    let h = CryptoJS.SHA256(hash).toString(CryptoJS.enc.Hex);
    allNums.forEach((c) => {
      nums.push({ num: c, hash: h });
      h = h.substring(1) + h.charAt(0);
    });
    nums.sort(function (o1, o2) {
      if (o1.hash < o2.hash) {
        return -1;
      } else if (o1.hash === o2.hash) {
        return 0;
      } else {
        return 1;
      }
    });
    return nums;
  }
  function keno(hash) {
    const allNums = [
      1, 30, 11, 40, 2, 29, 12, 39, 3,
      28, 13, 38, 4, 27, 14, 37, 5, 26,
      15, 36, 6, 25, 16, 35, 7, 24, 17,
      34, 8, 23, 18, 33, 9, 22, 19, 32,
      10, 21, 20, 31
    ];
    let seed = hash;
    let finalNums = createNums(allNums, seed);
    seed = String(CryptoJS.SHA256(seed));
    finalNums = createNums(finalNums, seed);
    return finalNums.slice(0, 10).map((m) => m.num);
  }
  let hash = "game hash";
  console.log( "result =>", keno(hash).map((item) => item.num).join(","));
`
            }), c("p", {
                children: ["This is our multiplayer keno seed event in", " ", i("a", {
                    href: "https://bitcointalk.org/index.php?topic=5255968.msg54629415#msg54629415",
                    target: "_blank",
                    className: "cl-primary",
                    children: "bitcointalk"
                })]
            }), c("p", {
                style: {
                    wordBreak: "break-all"
                },
                children: ["So our salt will be ", i("br", {}), "000000000000000000076973be291d219d283d4af9135601ff37df46491cca7e"]
            })]
        })
    })
}
const Fn = "f1t51ob9",
    Kn = D.memo(({
        game: n
    }) => c(Oe, {
        game: n,
        showMaxProfit: !1,
        children: [i("h2", {
            children: "What is the bankroll?"
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
            }), i("p", {
                children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
            }), i("p", {
                children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
            }), i("p", {
                onClick: () => Be(n),
                className: "cl-primary",
                children: "Read more about bankrollers."
            })]
        }), i("h2", {
            children: "How does the pool of funds operate? "
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
            }), c("p", {
                children: [i("b", {
                    className: "cl-primary",
                    children: "The house edge is 1%."
                }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
            }), i("p", {
                children: "Payouts made to the winning players will be deducted from the bankroll."
            })]
        }), i("h2", {
            children: "How does leverage investment work?"
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
            }), i("p", {
                children: "Hint: You can also use this feature as an Off-Site investment."
            }), i("p", {
                children: "Let's make an example:"
            }), i("p", {
                children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
            })]
        }), i("h2", {
            children: "What is the bankroller dilution fee?"
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
            }), i("p", {
                children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
            }), i("p", {
                children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
            }), i("p", {
                children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
            })]
        }), i("h2", {
            children: "How does the pool of funds operate? "
        }), c("div", {
            className: "help-content",
            children: [i("p", {
                children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
            }), c("ul", {
                children: [i("li", {
                    children: "Each player can only win 1% of the bankroll per round"
                }), i("li", {
                    children: "All players can only win 2% of the funds per round"
                })]
            })]
        })]
    }));
var Wn = Kn;
const Jn = ({
        listString: n,
        draw: s,
        resultList: e
    }) => {
        let t = n.split(":")[1].split(","),
            a = b.exports.useCallback(l => s ? e.length > 0 && e.split(",").indexOf(l) != -1 ? "ball-green" : "ball-red" : "", [s]);
        return i("div", {
            className: qn,
            children: t.map(l => i("div", {
                className: `${zn} ball ${a(l)}`,
                children: l
            }, l))
        })
    },
    qn = "l1b37lzr";
V({
    cl1: [v("#31343c", .4), v("#e9eaf2", .6)]
});
const zn = "i33rqjj",
    Se = I(() => {
        const n = C();
        let [s, e] = b.exports.useState(!1);
        const t = S();
        let a = t.allUserBets,
            l = t.gameResultNumber;
        return b.exports.useEffect(() => {
            if (t.gameStatus === _.END) {
                let o = setTimeout(() => {
                    t.orderAllUserBets(), e(!0)
                }, (t.delayTime + 100) * 10);
                return () => {
                    clearTimeout(o)
                }
            } else(t.gameStatus === _.PREPER || t.gameStatus === _.START) && e(!1)
        }, [t.gameStatus]), i("div", {
            className: Yn,
            children: c("table", {
                children: [i("thead", {
                    children: c("tr", {
                        children: [c("th", {
                            className: "th-w1",
                            children: [n("common.player"), "(", a.length, ")"]
                        }), i("th", {
                            className: "th-w2",
                            children: n("common.result")
                        }), i("th", {
                            className: "th-w3",
                            children: n("common.payout")
                        }), i("th", {
                            className: "th-w4",
                            children: n("common.profit")
                        })]
                    })
                }), i("tbody", {
                    children: a.map(o => c("tr", {
                        className: `
              ${s&&o.payout>=1?"tr-green":""} 
              ${s&&o.payout<1?"tr-red":""}
            `,
                        children: [i("td", {
                            children: i(re, {
                                title: o.name,
                                children: i(kt, {
                                    userId: o.userId,
                                    name: o.name,
                                    avatar: !1
                                })
                            })
                        }), i("td", {
                            children: i(re, {
                                title: o.betValue,
                                children: i(Jn, {
                                    listString: o.betValue,
                                    draw: s,
                                    resultList: l
                                })
                            })
                        }), c("td", {
                            children: [s ? o.payout.toFixed(2) : "0.00", " \xD7"]
                        }), i("td", {
                            children: s ? i(re, {
                                title: `${o.profit} ${o.currencyName}`,
                                children: i(vt, {
                                    name: o.currencyName,
                                    amount: Number(o.profit),
                                    icon: !0,
                                    sign: !0,
                                    className: "monospace bold"
                                })
                            }) : "-"
                        })]
                    }, o.userId))
                })]
            })
        })
    }),
    Yn = "b1i5dy2w";
const Un = 10,
    Qn = ({
        gameName: n
    }) => {
        let s = ae.t("common.history");
        return c("div", {
            className: "history",
            onClick: () => Fe.push(i(Zn, {
                gameName: n
            })),
            children: [i(le, {
                name: "History"
            }), s]
        })
    },
    Zn = ({
        gameName: n
    }) => {
        const [s, e] = b.exports.useState(!0), [t, a] = b.exports.useState(1), [l, o] = b.exports.useState({
            list: [],
            total: 1
        });
        let h = !1;
        b.exports.useEffect(() => (p(), () => {
            h = !0
        }), []);
        const p = m => {
            s || e(!0), J.post(z.KENO_HISTORY, {
                page: m || t,
                pageSize: Un
            }).then(d => {
                h || o({
                    list: d.list,
                    total: d.total
                }), m && a(m), e(!1)
            }).catch(B)
        };
        return i(ie, {
            title: ae.t("common.history"),
            children: c(W, {
                className: Xn,
                children: [s ? i(fe, {}) : l.list.map(m => c("div", {
                    className: "h-it",
                    children: [c("div", {
                        className: "h-num",
                        onClick: () => {
                            U.openAllPlayers({
                                gameName: n,
                                gameId: m.gameId
                            })
                        },
                        children: [m.gameId, ":", " "]
                    }), m.betValue.split(",").map(d => i("div", {
                        className: "h-ball",
                        children: d
                    }, d))]
                }, m.gameId)), l.total > 10 && i(De, {
                    page: t,
                    onChange: m => {
                        p(m)
                    },
                    total: l.total,
                    limit: 10,
                    type: "pageConic2"
                })]
            })
        })
    };
V({
    cl1: ["#99a4b0", v("#5f6975", .8)],
    cl2: ["#31343c", "#f6f6f9"],
    cl3: ["#99a4b0", "#131415"],
    cl4: [v("#2d3035", .6), v("#dadde6", .6)],
    cl5: [v("#2d3035", .4), v("#dadde6", .3)]
});
const Xn = "h2b82nw";
const es = ({
        game: n
    }) => {
        const s = b.exports.useRef(null),
            e = b.exports.useRef(null),
            t = C();
        return b.exports.useEffect(() => {
            if (n.gameStatus === _.PREPER) {
                let a = n.startTime - n.serverTime > 0 ? (n.startTime - n.serverTime + 500) / 1e3 : 0,
                    l = {
                        t: a
                    };
                return G.set(e.current, {
                    clearProps: "transform"
                }), G.to(e.current, {
                    duration: a,
                    x: "-100%",
                    ease: me.easeNone
                }), G.to(l, {
                    t: 0,
                    duration: a,
                    onUpdate() {
                        s.current && (s.current.innerText = l.t.toFixed(2))
                    },
                    ease: me.easeNone
                }), () => {
                    G.killTweensOf(e.current), G.killTweensOf(l)
                }
            }
        }, []), c(H, {
            children: [c("div", {
                className: "title",
                children: [t("common.game.next_round"), i("span", {
                    ref: s,
                    className: "time",
                    children: "5.50"
                }), " ", "s"]
            }), i("div", {
                className: "wrap propgress",
                children: i("div", {
                    className: "line",
                    ref: e
                })
            })]
        })
    },
    ts = ({
        game: n
    }) => {
        let s = n.gameResultNumber.split(",");
        const e = C();
        return c(H, {
            children: [i("div", {
                className: "title",
                children: e("common.result")
            }), i("div", {
                className: "wrap ball-wrap",
                children: s.map((t, a) => i(ns, {
                    delay: (a + 1) * n.delayTime,
                    numbs: t
                }, t))
            })]
        })
    },
    ns = ({
        delay: n,
        numbs: s
    }) => {
        const e = b.exports.useRef(null);
        return b.exports.useEffect(() => (G.fromTo(e.current, .3, {
            y: "-=30px",
            opacity: 0
        }, {
            y: 0,
            ease: me.easeNone,
            opacity: 1
        }).delay(n / 1e3), () => {
            G.killTweensOf(e)
        }), []), i("div", {
            className: "range-item",
            ref: e,
            children: s
        })
    },
    it = I(n => {
        const s = S();
        return c("div", {
            className: F(ss, n.className),
            children: [i(Qn, {
                gameName: s.name
            }), s.gameStatus >= _.END && i(ts, {
                game: s
            }), s.gameStatus < _.END && i(es, {
                game: s
            })]
        })
    });
V({
    cl1: ["rgba(49, 52, 60, 0.6)", v("#cccfd9", .4)],
    cl2: ["#fff", "#31373d"],
    cl3: ["#f5f6f7", "#5f6975"],
    cl4: ["#31343C", "#e9eaf2"],
    cl5: [v("#99a4b0", .8), v("#5f6975", .8)],
    cl6: [v("#31343c", .4), v("#e9eaf2", .6)],
    cl7: ["#1e2024", "#f5f6fc"]
});
const ss = "c9jcze5";
const is = I(() => {
        const n = S(),
            s = n.nums.filter(t => t.select).length === 0,
            e = b.exports.useCallback(async () => {
                try {
                    n.autoBet.isRunning ? await n.autoBet.stop() : await n.autoBet.start()
                } catch (t) {
                    B(t)
                }
            }, []);
        return i(ze, {
            canBet: s,
            isBetting: n.isBetting,
            gameName: n.name,
            isRuning: n.autoBet.isRunning,
            onClick: e,
            showKey: n.settings.hotkeyEnable,
            random: n.random,
            clear: n.clearSelect,
            onChangeRisk: n.changeRisk,
            risk: n.risk,
            riskOptions: n.riskOptions,
            gameHash: n.gameHash,
            isMulti: !0
        })
    }),
    as = I(() => {
        const [n, s] = b.exports.useState(!1), e = S(), t = e.nums.filter(l => l.select).length === 0;
        b.exports.useEffect(() => {
            n && e.gameStatus === _.PREPER && (s(!1), e.nextbet = !1, a())
        }, [e.gameStatus]);
        const a = async () => {
            if (e.gameStatus >= _.END) return s(!n), e.nextbet = !n, !1;
            try {
                await e.handleBet()
            } catch (l) {
                B(l)
            }
        };
        return i(Ye, {
            canBet: t,
            isBetting: e.isBetting,
            gameName: e.name,
            disabledChoose: e.disabledChoose,
            onClick: a,
            showKey: e.settings.hotkeyEnable,
            random: e.random,
            clear: e.clearSelect,
            onChangeRisk: e.changeRisk,
            risk: e.risk,
            riskOptions: e.riskOptions,
            gameHash: e.gameHash,
            isMulti: !0,
            nextBet: n
        })
    }),
    ls = I(() => {
        const n = S(),
            s = b.exports.useCallback(e => {
                U.openMultipleDetail({
                    gameName: n.name,
                    gameId: e.gameId,
                    userId: e.userId,
                    betId: e.betId
                })
            }, []);
        return i(Pe, {
            list: n.myBets,
            keyof: "betId",
            onDetail: s
        })
    }),
    os = I(({
        mobileStyle: n
    }) => {
        const s = S(),
            [e, t] = Ce();
        return b.exports.useEffect(() => {
            if (s.realResultPayout > 0) {
                let a = window.setTimeout(() => {
                    t({
                        profitAmount: new L(s.amount).mul(s.realResultPayout).toNumber(),
                        currencyName: s.currencyName,
                        odds: s.resultPayout,
                        isBigWin: s.bigwin,
                        enableSound: s.settings.soundEnable
                    })
                }, s.delayTime * 17);
                return () => {
                    clearTimeout(a)
                }
            } else t(null)
        }, [s.realResultPayout]), c(H, {
            children: [i(ls, {}), c(Ae, {
                className: cs,
                children: [c(Ze, {
                    children: [n && i(it, {
                        className: "mobile-cutTime"
                    }), c("div", {
                        className: "keno-wrap",
                        children: [c("div", {
                            className: "keno-item-wrap",
                            children: [i(Ue, {
                                nums: s.nums,
                                disabledItem: s.disabledItem,
                                beforeResult: s.beforeResult,
                                resultPayout: s.resultPayout,
                                bigwin: s.bigwin,
                                amount: s.amount,
                                currencyName: s.currencyName,
                                delayTime: s.delayTime,
                                onAddItem: s.addItem,
                                realResultPayout: s.realResultPayout
                            }), e]
                        }), i(Qe, {
                            selectNumber: s.selectList.length,
                            winNumber: s.winNumber,
                            curRisk: s.curRisk,
                            amount: s.amount,
                            currencyName: s.currencyName,
                            riskOptions: s.riskOptions
                        }), i("div", {
                            className: "bottom-line"
                        })]
                    })]
                }), i(Re, {
                    className: "house-edge"
                })]
            })]
        })
    }),
    cs = "g1r9xzuf";
const rs = () => {
        const n = Z.withLogin(() => Fe.push(i(us, {
            game: ks
        })));
        return i(Ke, {
            title: "Favorite",
            icon: i(le, {
                name: "Management"
            }),
            onClick: n,
            active: !1
        })
    },
    us = I(({
        game: n
    }) => {
        let [s, e] = b.exports.useState(!0), [t, a] = b.exports.useState([]);
        const l = n.nums.filter(f => f.select),
            o = l.map(f => f.num).join(","),
            h = b.exports.useCallback(() => {
                if (t.filter(y => y.using).length > 0) return B(new Error("The same number exists")), !1;
                if (l.length === 0) return B(new Error("Please choose first")), !1;
                J.post(z.KENO_ADDFAVORITE, {
                    numbers: o
                }).then(y => {
                    let w = [...t];
                    w.unshift({
                        favId: y.favId,
                        numbers: o,
                        using: !0
                    }), a(w), B("Added to favorite successfully!")
                }).catch(B)
            }, [t]),
            p = b.exports.useCallback(f => {
                if (n.isBetting) return B(new Error("Please pause the game first")), !1;
                let y = [...t],
                    w = y.find(O => O.favId === f);
                y.map(O => {
                    O.using = O.favId === f
                }), a(y), n.random(w.numbers.split(","))
            }, [t]),
            m = b.exports.useCallback(f => {
                J.get(z.KENO_DELETFAVORITE(f)).then(y => {
                    let w = [...t],
                        O = w.findIndex(j => j.favId === f);
                    w.splice(O, 1), a(w), B("successfully deleted")
                }).catch(B)
            }, [t]);
        b.exports.useEffect(() => {
            J.get(z.KENO_GETFAVORITE).then(f => {
                a(f.map(y => (y.using = y.numbers === o, y))), e(!1)
            }).catch(B)
        }, []);
        const d = C();
        return i(ie, {
            title: "Favorite",
            children: i(W, {
                className: hs,
                children: s ? i(fe, {}) : c(H, {
                    children: [i("div", {
                        className: "btn-wrap",
                        children: c(x, {
                            type: "conic",
                            className: "fa-btn",
                            onClick: h,
                            children: [i("b", {
                                children: "+"
                            }), " ", d("common.game.favorite")]
                        })
                    }), c("div", {
                        className: "fa-list",
                        children: [i("div", {
                            className: "title",
                            children: d("common.game.collection")
                        }), t.length > 0 ? t.map((f, y) => c("div", {
                            className: "fa-item",
                            children: [i("div", {
                                className: "fa-nums",
                                children: f.numbers.split(",").map(w => i("div", {
                                    className: "fa-ball",
                                    children: w
                                }, w))
                            }), i(x, {
                                disabled: n.disabledChoose,
                                className: "btn-use",
                                type: "conic3",
                                onClick: () => {
                                    p(f.favId)
                                },
                                children: f.using ? "In use" : "Use"
                            }), i("button", {
                                className: "btn-close",
                                onClick: () => {
                                    m(f.favId)
                                },
                                children: i(le, {
                                    name: "Delete"
                                })
                            })]
                        }, y)) : i($e, {})]
                    })]
                })
            })
        })
    }),
    hs = "fwnil3k";
const ms = D.memo(() => {
        const n = C(),
            s = S(),
            [e, t] = b.exports.useState(() => wt.isMobile),
            a = Nt(({
                width: h
            }) => t(h < 900)),
            l = [{
                label: n("common.my_bet"),
                value: U.Mybet
            }, {
                label: n("common.history"),
                value: Vn
            }];
        e && l.unshift({
            label: n("common.all_bet"),
            value: () => i(Se, {})
        });
        const o = [{
            title: n("common.game_intro"),
            node: i(Dn, {})
        }, {
            title: n("common.fairness"),
            node: i($n, {})
        }, {
            title: n("common.bankroll"),
            node: i(Wn, {
                game: s
            })
        }];
        return i(xe, {
            className: fs,
            type: 1,
            ref: a,
            gameView: i(os, {
                mobileStyle: e
            }),
            manualControl: i(as, {}),
            autoControl: i(is, {}),
            tabs: l,
            right: e ? i(H, {}) : c("div", {
                className: bs,
                children: [i(it, {}), i(Se, {})]
            }),
            actions: [i(_e, {}), i(Ee, {}), i(je, {}), i(ds, {}), i(rs, {}), i(Le, {
                list: o
            })]
        })
    }),
    ds = I(() => {
        const n = S(),
            s = We();
        return i(Ke, {
            title: "Fairness",
            icon: i(le, {
                name: "Fairness"
            }),
            onClick: () => s(`/keno_help/validate/${n.gameHash}`),
            active: !1
        })
    }),
    fs = "s1yih09f",
    bs = "b194kmqe",
    ps = P.decode(r.Init);
var _ = (n => (n[n.PREPER = 0] = "PREPER", n[n.START = 1] = "START", n[n.END = 2] = "END", n[n.STOP = 3] = "STOP", n))(_ || {});
class ys extends It {
    constructor() {
        super({
            name: "Keno",
            namespace: "/g/keno",
            sounds: et,
            fairLink: "/keno_help/fairness",
            validateLink: "/keno_help/validate"
        }, ms), this.risk = 1, this.nums = [], this.runing = !1, this.canChoose = !0, this.delayTime = 110, this.disabledChoose = !1, this.resultPayout = 0, this.realResultPayout = 0, this.betLoading = !1, this.hasMask = !1, this.beforeResult = [], this.bigwin = !1, this.gameHash = "", this.timer = -1, this.allUserBets = [], this.gameStatus = 0, this.gameResultNumber = "", this.gameId = 0, this.nextbet = !1, this.oddsScale = 1e4, this.riskOptions = [{
            label: "Low",
            value: 0
        }, {
            label: "Classic",
            value: 1
        }, {
            label: "Medium",
            value: 2
        }, {
            label: "High",
            value: 3
        }], He(this, {
            risk: k,
            nums: k,
            runing: k,
            canChoose: k,
            delayTime: k,
            disabledChoose: k,
            resultPayout: k,
            realResultPayout: k,
            betLoading: k,
            hasMask: k,
            beforeResult: k,
            bigwin: k,
            gameHash: k,
            gameStatus: k,
            gameResultNumber: k,
            allUserBets: k,
            maxProfit: A,
            disabledItem: A,
            selectList: A,
            winNumber: A,
            curRisk: A,
            clearSelect: M,
            resetStatus: M,
            clearActive: M
        });
        for (let e = 0; e < 40; e++) this.nums.push({
            num: e + 1,
            active: !1,
            select: !1
        });
        this.setJackpot = this.setJackpot.bind(this), this.addItem = this.addItem.bind(this), this.canSelect = this.canSelect.bind(this), this.random = this.random.bind(this), this.clearSelect = this.clearSelect.bind(this), this.changeRisk = this.changeRisk.bind(this), this.orderAllUserBets = this.orderAllUserBets.bind(this), this.setPr = this.setPr.bind(this), this.addHotkey("q", this.random, "Auto pick tiles"), this.addHotkey("w", this.clearSelect, "Clear table");
        const s = this.hotkeyList.find(e => e.key == "space");
        s && (s.handler = () => {
            if (this.disabledChoose) return;
            if (this.nums.filter(t => t.select).length === 0) return B(new Error("Please choose 1 - 10 numbers"));
            if (this.controlIdx === 1) this.autoBet.isRunning ? this.autoBet.stop() : this.isBetting || this.autoBet.start();
            else {
                if (this.isBetting) return !1;
                this.handleBet()
            }
            return !1
        }), this.socket.on("j-change", P.decodeBind(e => e.infos.forEach(this.setJackpot), St)), this.autoBet = new Ot(this), this.autoBet.on("start", () => this.setBetStatus(!0)), this.autoBet.on("stop", () => this.setBetStatus(!1))
    }
    get maxProfit() {
        const s = be.find(e => e.risk === this.curRisk && e.payouts.length === this.selectList.length + 1);
        if (s) {
            const e = Math.max(...s.payouts);
            return this.amount.mul(e).sub(this.amount)
        }
        return new L(0)
    }
    get disabledItem() {
        return this.hasMask || this.autoBet.isRunning || this.isBetting
    }
    get selectList() {
        return this.nums.filter(s => s.select)
    }
    get winNumber() {
        let s = this.nums.filter(t => t.active).length > 0,
            e = this.nums.filter(t => t.active && t.select).length;
        return s ? e : -1
    }
    get curRisk() {
        return this.riskOptions[this.risk].label.toLocaleLowerCase()
    }
    async betRequest(s, e = 0) {
        let t = this.riskOptions[this.risk].label.toLocaleLowerCase(),
            a = this.nums.filter(p => p.select).map(p => p.num).join(","),
            l = t + ":" + a,
            o = P.encode(r.ThrowBetRequest)({
                gameId: Bt.fromNumber(this.gameId),
                currencyName: this.currencyName,
                bet: s.toFixed($.getPrecision(this.currencyName)),
                betValue: l,
                scriptId: e,
                frontgroundId: this.txId
            });
        return await this.socketRequest("throw-bet", o).then(P.decode(r.Bet))
    }
    async bet(s, e = 0) {
        this.sounds.playSound("sound_play"), this.clearActive(), this.gameStatus !== 0 && await this.waitGamePr();
        try {
            let t = await this.betRequest(s, e);
            return this.curgameId = this.gameId, {
                odds: await this.twoStepBet(t, String(this.amount))
            }
        } catch (t) {
            throw t
        }
    }
    async twoStepBet(s, e) {
        let t = await this.waitGameEnd();
        const a = t.gameId.toNumber();
        if (a !== this.curgameId) throw new Error;
        this.beforeResult = t.betValue.split(","), this.setPr(ne(this.beforeResult, 10), m => m.active = !0);
        let l = t.list.filter(m => m.userId === this.userId)[0],
            o = l && l.winAmount ? l.winAmount : "0",
            h = l && l.payout ? l.payout : 0;
        this.realResultPayout = Number(new L(o).div(e || s.amount).toFixed(2)), this.resultPayout = h / this.oddsScale, await ee(this.delayTime * 11), this.bigwin = this.nums.filter(m => m.select && m.active).length === 10;
        let p = this.autoBet.isRunning ? 3e3 : 1500;
        return await ee(p), this.mybetItem(o, h, a, this.userId, s.betId.toString(), this.currencyName, this.userName, new Date().getTime(), e || s.amount), this.resultPayout
    }
    waitGamePr() {
        return new Promise(s => this.socket.once("pr", P.decodeBind(e => {
            s(e)
        }, r.Prepare)))
    }
    waitGameEnd() {
        return new Promise(s => this.socket.once("ed", P.decodeBind(e => {
            s(e)
        }, r.End)))
    }
    setBetStatus(s) {
        !this.autoBet.isRunning && !this.script.isRunning && (this.isBetting = s)
    }
    async init() {
        const s = super.init();
        let [e] = await Promise.all([this.socketRequest("init").then(ps), s]), {
            jackpot: t
        } = e;
        this.jackpot = t.reduce((a, l) => {
            let {
                currencyName: o,
                jackpotAmount: h,
                minBetAmount: p,
                maxBetAmount: m,
                maxProfitAmount: d
            } = l;
            return a[o] = {
                currencyName: o,
                jackpotAmount: $.bn2amount(h, o),
                minBetAmount: $.bn2amount(p, o),
                maxBetAmount: $.bn2amount(m, o),
                maxProfitAmount: $.bn2amount(d, o)
            }, a
        }, {}), this.socket.on("pr", P.decodeBind(a => {
            this.gameId = a.gameId.toNumber(), this.gameStatus = 0, this.prepareTime = a.prepareTime.toNumber(), this.serverTime = a.serverTime.toNumber(), this.startTime = a.startTime.toNumber(), this.allUserBets = []
        }, r.Prepare)), this.socket.on("bg", P.decodeBind(a => {
            this.gameId = a.gameId.toNumber(), this.gameStatus = 1
        }, r.Begin)), this.socket.on("ed", P.decodeBind(a => {
            this.gameId = a.gameId.toNumber(), this.gameResultNumber = a.resultCards;
            let l = a.list.reduce((o, h) => (o[h.userId] = h, o), {});
            this.allUserBets.forEach(o => {
                let h = l[o.userId],
                    p = h && h.winAmount ? h.winAmount : "0";
                return o.profit = new L(p).sub(o.amount).toString(), o.payout = (h && h.payout ? h.payout : 0) / this.oddsScale, o
            }), this.gameHash = a.hash, this.gameStatus = 2
        }, r.End)), this.socket.on("st", P.decodeBind(a => {
            this.gameId = a.gameId.toNumber(), this.gameStatus = 3
        }, r.Settle)), this.socket.on("b", P.decodeBind(a => {
            const {
                amount: l,
                betTimes: o,
                betValue: h,
                currencyName: p,
                name: m,
                userId: d
            } = a;
            this.allUserBets.push({
                amount: l,
                betTimes: o,
                betValue: h,
                currencyName: p,
                name: m,
                userId: d,
                payout: 0,
                profit: "-"
            })
        }, r.Bet)), Z.waitLogin().then(() => {
            this.userId = Z.userId, this.userName = Z.name
        })
    }
    async syncStatus() {
        try {
            let s = await this.socketRequest("status").then(P.decode(r.GameInit)),
                e = s.bets.filter(t => t.userId === this.userId);
            switch (s.status) {
                case 10:
                    this.gameStatus = 0;
                    break;
                case 20:
                    this.gameStatus = 1;
                    break;
                case 30:
                    this.gameStatus = 2;
                    break;
                default:
                    this.gameStatus = 3
            }
            if (this.gameId = s.gameId.toNumber(), this.prepareTime = s.prepareTime.toNumber(), this.serverTime = s.serverTime.toNumber(), this.startTime = s.startTime.toNumber(), s.bets.map(t => {
                    const {
                        amount: a,
                        betTimes: l,
                        betValue: o,
                        currencyName: h,
                        name: p,
                        userId: m
                    } = t, d = s.players.find(y => y.userId === t.userId), f = d != null && d.name ? d.name : p;
                    this.allUserBets.push({
                        amount: a,
                        betTimes: l,
                        betValue: o,
                        currencyName: h,
                        name: f,
                        userId: m,
                        payout: 0,
                        profit: "0"
                    })
                }), s.gameId.toNumber() === this.curgameId && e.length > 0) {
                let t = e[0];
                if (this.gameStatus === 0 || this.gameStatus === 1) {
                    let a = t.betValue.split(":");
                    switch (this.isBetting = !0, a[0]) {
                        case "low":
                            this.risk = 0;
                            break;
                        case "classic":
                            this.risk = 1;
                            break;
                        case "medium":
                            this.risk = 2;
                            break;
                        default:
                            this.risk = 3;
                            break
                    }
                    this.nums.filter(o => o.select).length === 0 && (a[1].split(",").forEach(o => {
                        let h = this.nums[Number(o) - 1];
                        h.select = !0
                    }), await this.twoStepBet(t)), this.isBetting = !1
                }
            }
        } catch (s) {
            this.gameStatus = 2
        }
    }
    setJackpot(s) {
        let {
            currencyName: e,
            jackpotAmount: t
        } = s;
        !this.jackpot[e] || (this.jackpot[e].jackpotAmount = $.bn2amount(t, e))
    }
    canSelect() {
        return this.nums.filter(s => s.select).length < 10
    }
    addItem(s) {
        if (this.isBetting || this.autoBet.isRunning) return;
        this.nums.filter(t => t.active).length > 0 && this.clearActive();
        const e = this.nums[s - 1];
        e.select == !0 ? e.select = !1 : this.canSelect() && (e.select = !0), this.hasMask = !this.canSelect()
    }
    changeRisk(s) {
        this.risk = s
    }
    clearSelect(s = !0) {
        this.nextbet || this.runing || this.autoBet.isRunning || this.isBetting || (this.clearActive(), s && this.sounds.playSound("sound_clear"), this.hasMask = !1, this.nums.forEach(e => {
            e.select = !1
        }))
    }
    clearActive() {
        this.runing || this.nums.filter(s => s.active).length !== 0 && (this.resetStatus(), clearTimeout(this.timer), this.nums.forEach(s => {
            s.active = !1
        }))
    }
    resetStatus(s = 0, e = [], t = !1) {
        this.realResultPayout = 0, this.resultPayout = s, this.beforeResult = e, this.bigwin = t
    }
    setPr(s, e, t = 9) {
        return new Promise(a => {
            let l = 0;
            this.timer = window.setInterval(() => {
                e(this.nums[Number(s[l]) - 1]), l === t ? (a(!0), clearInterval(this.timer)) : l++
            }, this.delayTime)
        })
    }
    async random(s) {
        if (this.nextbet || this.runing || this.disabledChoose || this.isBetting) return;
        this.disabledChoose = !0, this.clearSelect(!1), this.hasMask = !0;
        let e = s && s.length > 0 ? s : ne(this.nums.map(a => a.num), 10),
            t = e.length - 1;
        await this.setPr(e, a => a.select = !0, t), this.disabledChoose = !1
    }
    async orderAllUserBets() {
        this.allUserBets = Tt(this.allUserBets, ["payout"], ["desc"])
    }
    mybetItem(s, e, t, a, l, o, h, p, m) {
        return {
            winAmount: new L(s).sub(m).toNumber(),
            profitAmount: parseFloat(s),
            betId: l,
            gameId: t,
            odds: e / this.oddsScale,
            betTime: p,
            currencyName: o,
            nonce: t,
            userId: a,
            nickName: h,
            betAmount: parseFloat(m)
        }
    }
    deactivate() {
        this.allUserBets = [], this.realResultPayout = 0, this.resultPayout = 0, super.deactivate(), this.autoBet.isRunning && this.autoBet.stop()
    }
    active() {
        this.isActived || (this.syncStatus(), super.active())
    }
}
let gs = new ys;
var ks = gs;
const vs = () => {
    const n = Ge(),
        e = Me(n)[0] || "";
    let [t, a] = b.exports.useState(e);
    const l = String("000000000000000000076973be291d219d283d4af9135601ff37df46491cca7e");

    function o(f, y) {
        return xt.exports.HmacSHA256(X.parse(f), y).toString(X)
    }

    function h(f, y) {
        let w = [],
            O = Y(y).toString(X);
        return f.forEach(j => {
            w.push({
                num: j,
                hash: O
            }), O = O.substring(1) + O.charAt(0)
        }), w.sort(function(j, pe) {
            return j.hash < pe.hash ? -1 : j.hash === pe.hash ? 0 : 1
        }), w
    }

    function p(f) {
        const y = [1, 30, 11, 40, 2, 29, 12, 39, 3, 28, 13, 38, 4, 27, 14, 37, 5, 26, 15, 36, 6, 25, 16, 35, 7, 24, 17, 34, 8, 23, 18, 33, 9, 22, 19, 32, 10, 21, 20, 31];
        let w = o(f, l),
            O = h(y, w);
        return w = String(Y(w)), O = h(O, w), O.slice(0, 10).map(j => j.num.num)
    }
    let m = p(t).sort((f, y) => f - y);
    const d = C();
    return i(ie, {
        title: ae.t("common.fairness"),
        children: c(W, {
            className: ws,
            children: [i("h2", {
                children: d("common.input")
            }), i(R, {
                label: "Game Hash",
                value: t,
                onChange: f => a(f)
            }), i(R, {
                label: "Salt",
                value: l,
                readOnly: !0
            }), i("h2", {
                children: d("common.final_result")
            }), i("div", {
                className: "result-list",
                children: m.map(f => i("div", {
                    className: "keno-range",
                    children: f
                }, f))
            }), i("div", {
                className: "label",
                children: d("common.code")
            }), i(de, {
                style: {
                    marginBottom: "1.5rem"
                },
                children: `import CryptoJS from "crypto-js";
          
const salt = "000000000000000000076973be291d219d283d4af9135601ff37df46491cca7e";
function seedGenerator(hash, salt) {
  const hmac = CryptoJS.HmacSHA256(CryptoJS.enc.Hex.parse(hash), salt);
  return hmac.toString(CryptoJS.enc.Hex);
}
function createNums(allNums, hash) {
  const nums = [];
  let h = CryptoJS.SHA256(hash).toString(CryptoJS.enc.Hex);
  allNums.forEach((c) => {
    nums.push({ num: c, hash: h });
    h = h.substring(1) + h.charAt(0);
  });
  nums.sort(function (o1, o2) {
    if (o1.hash < o2.hash) {
      return -1;
    } else if (o1.hash === o2.hash) {
      return 0;
    } else {
      return 1;
    }
  });
  return nums;
}
function keno(hash) {
  const allNums = [
    1, 30, 11, 40, 2, 29, 12, 39, 3,
    28, 13, 38, 4, 27, 14, 37, 5, 26,
    15, 36, 6, 25, 16, 35, 7, 24, 17,
    34, 8, 23, 18, 33, 9, 22, 19, 32,
    10, 21, 20, 31
  ];
  let seed = seedGenerator(hash, salt);
  seed = String(CryptoJS.SHA256(seed));
  let finalNums = createNums(allNums, seed);
  finalNums = createNums(finalNums, seed);
  return finalNums.slice(0, 10).map((m) => m.num);
}
const hash = "game hash";
console.log( "result =>", keno(hash).map((item) => item.num).join(","));
`
            })]
        })
    })
};
var Hs = vs;
V({
    cl1: [v("#99a4b0", .8), v("#5f6975", .8)],
    cl2: ["#31343c", "#f6f6f9"],
    cl3: ["#99a4b0", "#5f6975"]
});
const ws = "f1ve64er";
const Ns = U.withMultipleDetail(({
    gb: n,
    gv: s
}) => {
    const e = C(),
        t = We(),
        a = [];
    for (let d = 0; d < 40; d++) a.push({
        active: !1,
        activeTime: 0,
        num: d + 1,
        select: !1,
        selectTime: 0
    });
    const {
        resultValue: l,
        hash: o
    } = n.extend, {
        betValue: h
    } = s[0].bets[0].extend, p = l.split(",");
    return h.split(":")[1].split(",").forEach((d, f) => {
        let y = a[Number(d) - 1];
        y.select = !0, y.selectTime = f * 100
    }), p.forEach((d, f) => {
        let y = a[Number(d) - 1];
        y.active = !0, y.activeTime = f * 100
    }), c("div", {
        className: Is,
        children: [i(nt, {
            list: a
        }), i(R, {
            label: e("common.game_number"),
            value: n.gameId,
            readOnly: !0
        }), i(R, {
            label: e("common.hash"),
            value: o,
            readOnly: !0
        }), i(x, {
            type: "conic",
            onClick: () => t(`/keno_help/validate/${o}`),
            children: e("common.verify")
        })]
    })
});
var Vs = Ns;
const Is = "kolr5kl";
export {
    Wn as MultiBankroll, Vs as MultiDetail, $n as MultiFairness, ks as MultiGame, Hs as MultiValidate, Ht as SingleBankroll, Ls as SingleDetail, Es as SingleFairness, _s as SingleGame, js as SingleValidate
};
import {
    r as s,
    bb as t,
    ej as u
} from "./index.28e31dff.js";

function n(r, e) {
    var o = e && u(e);
    return s.exports.useState(function() {
        return t(r(o), void 0, {
            autoBind: !0
        })
    })[0]
}
export {
    n as u
};
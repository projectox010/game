import {
    o as C,
    u as k,
    r as c,
    e as L,
    cz as j,
    d as g,
    j as o,
    a as e,
    am as _,
    bf as F,
    I as $,
    b as S,
    A as M,
    t as E,
    q as x,
    G as m,
    p as q,
    v as y,
    cA as O,
    F as A,
    al as G,
    ar as V,
    cB as W,
    $ as H,
    bn as K,
    aG as R,
    P as J,
    s as D,
    at as Q,
    a5 as X,
    cC as Y,
    ca as Z,
    cD as ee,
    D as U,
    ak as te,
    T as ae,
    S as se,
    a3 as ne,
    br as oe
} from "./index.28e31dff.js";
import {
    r as le
} from "./recaptcha.94966f3c.js";
import {
    C as ie
} from "./CheckPassword.46c08afc.js";
import {
    s as ce
} from "./metamaskSupport.1f1c5eb7.js";
const re = t => {
        const [a, s] = c.exports.useState(!1), l = k();
        return c.exports.useEffect(() => {
            t.onSetSize(a ? 864 : 800)
        }, [a]), a ? e(_, {
            label: `${l("user.casino_code")} (${l("common.optional")})`,
            autoComplete: "off",
            tabIndex: 3,
            value: t.code,
            onChange: t.onChange,
            placeholder: l("user.casino_code"),
            onKeyDown: i => {
                i.keyCode === 13 && t.handleSubmit()
            }
        }) : o("div", {
            className: "casino-code hover",
            onClick: () => s(!0),
            children: [`${l("user.casino_code")} (${l("common.optional")})`, e(M, {
                name: "Arrow"
            })]
        })
    },
    de = C(t => {
        const a = k(),
            s = c.exports.useRef(null),
            l = L(),
            i = t.data;
        c.exports.useEffect(() => {
            j("retargeting")
        }, []);
        const [f, v] = c.exports.useState(g.currentInvitationCode || ""), [n, d] = c.exports.useState(!0), r = async function() {
            if (!n) return m(new Error(a("page.login.agreement_tips"))), !1;
            if (!i.password || i.password.length < 6) return m(new Error(a("page.settings.reset_minlen"))), !1;
            const u = await le("login");
            try {
                let p = await g.handleRegist(i.email, i.password, f, u);
                t.onEnd && t.onEnd()
            } catch (p) {
                p.code === 5801 ? await q.confirm("Looks like you've already registered, sign in now?") && (t.data.autoLogin = !0, l("/login", {
                    replace: !0
                })) : p && m(p)
            }
        }, w = function() {
            const u = s.current;
            u && u.click()
        }, b = () => {
            y.close(), l("/help/terms-service")
        };
        return o("div", {
            className: ge,
            id: "regist",
            style: t.style,
            children: [o("div", {
                className: "box",
                children: [e(_, {
                    label: a("user.email_title"),
                    tabIndex: 1,
                    autoComplete: "off",
                    value: i.email,
                    onChange: u => i.email = u,
                    placeholder: a("page.forget.email")
                }), e(_, {
                    label: a("page.settings.password"),
                    tabIndex: 2,
                    type: "password",
                    autoComplete: "off",
                    value: i.password,
                    onChange: u => i.password = u,
                    placeholder: a("page.settings.password"),
                    onKeyDown: u => {
                        u.keyCode === 13 && w()
                    },
                    children: e(ie, {
                        str: i.password
                    })
                }), e(re, {
                    code: f,
                    onChange: v,
                    handleSubmit: w,
                    onSetSize: t.onSetSize
                })]
            }), e("hr", {}), o("div", {
                className: "box",
                children: [o("div", {
                    className: "argument-check",
                    onClick: () => d(!n),
                    children: [e(F, {
                        type: "checkbox",
                        value: n
                    }), e("div", {
                        className: "label",
                        children: e($, {
                            k: "page.login.check",
                            children: e("a", {
                                className: "argument",
                                onClick: b,
                                children: a("title.help_agreement").toLocaleLowerCase()
                            })
                        })
                    })]
                }), o("div", {
                    className: "buttons",
                    children: [o(S, {
                        className: "signin",
                        size: "big",
                        type: "gray",
                        onClick: () => l("/login", {
                            replace: !0
                        }),
                        children: [e(M, {
                            name: "Arrow"
                        }), e("span", {
                            children: a("title.login")
                        })]
                    }), o("div", {
                        className: "regist-btn-wrap",
                        children: [o("div", {
                            className: "regist-bonus",
                            children: [e(M, {
                                name: "Reward"
                            }), a("common.registbonus").toLocaleUpperCase()]
                        }), e(S, {
                            ref: s,
                            type: "conic",
                            size: "big",
                            disabled: !n,
                            onClick: r,
                            children: a("title.regist")
                        })]
                    })]
                })]
            })]
        })
    });
E({
    cl1: ["#1e2024", "#fff"],
    cl2: [x("#3e484f", .3), "#e9eaf2"],
    cl3: ["#31343c", "#6b7180"]
});
const ge = "sw44aal";
const he = t => `${V.getApiURL("/user/verify/image/")}?t=${t}`;

function ue(t) {
    return H.post("/user/google/2-step-auth/code-2verify/", {
        code: t
    })
}
const pe = C(({
    data: t,
    onEnd: a
}) => {
    const s = k(),
        l = L(),
        [i, f] = c.exports.useState(!1),
        [v, n] = c.exports.useState(!1),
        [d, r] = c.exports.useState(""),
        [w, b] = c.exports.useState(Date.now()),
        u = () => he(w),
        p = async function() {
            if (i || !t.email || !t.password) return !1;
            f(!0);
            try {
                if ((await g.handleLogin(t.email, t.password, d)).google2StepAuth) {
                    let z = !0;
                    for (; z;) {
                        const B = await W();
                        if (B) try {
                            await ue(B), z = !1
                        } catch (N) {
                            if (N && N.code === 6005) throw new Error("");
                            m(N)
                        } else throw new Error("")
                    }
                }
                f(!1), await g.init(), a()
            } catch (h) {
                if (f(!1), !h) return;
                b(Date.now()), r(""), m(h), h.code === 6004 && n(!0)
            }
        };
    return c.exports.useEffect(() => {
        t.autoLogin && t.email && t.password && (p(), t.autoLogin = !1)
    }, []), o("div", {
        className: fe,
        id: "login",
        children: [o("div", {
            className: "box",
            children: [e(_, {
                label: s("user.email_title"),
                type: "text",
                tabIndex: 1,
                autoComplete: "off",
                value: t.email,
                onChange: h => t.email = h,
                placeholder: s("page.settings.email")
            }), e(O, {
                label: o(A, {
                    children: [e("div", {
                        style: {
                            flex: 1
                        },
                        children: s("page.settings.password")
                    }), e(G, {
                        className: "forget",
                        to: "/forget",
                        children: s("page.settings.forget_password")
                    })]
                }),
                tabIndex: 2,
                value: t.password,
                onChange: h => t.password = h,
                placeholder: s("page.settings.password"),
                onKeyDown: h => {
                    h.keyCode === 13 && p()
                }
            }), v && e(_, {
                label: s("page.login.captcha"),
                tabIndex: 3,
                className: "captcha",
                placeholder: s("page.login.captcha"),
                value: d,
                onChange: r,
                focus: !0,
                onKeyDown: h => {
                    h.keyCode === 13 && p()
                },
                type: "text",
                children: e("img", {
                    className: "verify-img",
                    src: u(),
                    onClick: () => b(Date.now())
                })
            })]
        }), e("hr", {}), o("div", {
            className: "buttons",
            children: [e(S, {
                loading: i,
                size: "big",
                onClick: p,
                type: "conic2",
                children: s("title.login")
            }), o(S, {
                className: "signup",
                size: "big",
                type: "gray",
                onClick: () => l("/login/regist", {
                    replace: !0
                }),
                children: [e("span", {
                    children: s("title.regist")
                }), e(M, {
                    name: "Arrow"
                })]
            })]
        })]
    })
});
E({
    cl1: ["#1e2024", "#fff"],
    cl2: [x("#3e484f", .3), "#e9eaf2"],
    cl3: ["#31343c", "#6b7180"]
});
const fe = "s1x8lvhu",
    me = () => R("https://connect.facebook.net/en_US/sdk.js", "FB");
let we = K.isDev ? "2247726542166448" : "363146184450773";
const T = async () => {
        if (window.FB) return window.FB;
        let t = await me();
        return t.init({
            appId: we,
            cookie: !0,
            xfbml: !0,
            version: "v2.8"
        }), t
    },
    ve = () => R("https://apis.google.com/js/api:client.js", "gapi"),
    be = async () => {
        let t = await ve();
        return await new Promise(s => {
            t.load("auth2", () => {
                s(t.auth2.init({
                    client_id: "36897522347-eotiq46nvilc5p10653s4mtbs8405sbn.apps.googleusercontent.com",
                    cookiepolicy: "single_host_origin",
                    scope: "profile email"
                }))
            })
        })
    },
    ye = () => Q(() =>
        import ("./walletConnect.fba9f012.js"), ["assets/walletConnect.fba9f012.js", "assets/index.28e31dff.js", "assets/index.3647d14f.css", "assets/index.21cf2e94.js", "assets/dijkstra.47a9ffea.js"]),
    Ce = C(() => {
        const t = J(),
            a = c.exports.useRef(null),
            s = c.exports.useRef(null),
            l = async function() {
                try {
                    const n = await be();
                    if (!t()) return;
                    n.attachClickHandler(a.current, {}, d => {
                        const r = n.currentUser.get().getBasicProfile(),
                            {
                                id_token: w
                            } = d.getAuthResponse();
                        g.handleLoginOpen({
                            fullName: r.getName(),
                            idToken: w,
                            openUserId: r.getId(),
                            userType: "google",
                            picture: r.Paa
                        }).then(y.close).catch(m)
                    }, d => {
                        d instanceof Error && m(new Error(String(d)))
                    })
                } catch (n) {}
            },
            i = () => {
                var r;
                const n = document.createElement("script");
                n.async = !0, n.src = "https://telegram.org/js/telegram-widget.js?5";
                let d = "BC_GAME_Bot";
                /8848/.test(location.href) && (d = "Bcg_Login_Bot"), n.setAttribute("data-telegram-login", d), n.setAttribute("data-size", "large"), n.setAttribute("data-onauth", "onTelegramAuth(user)"), n.setAttribute("data-request-access", "write"), (r = s.current) == null || r.appendChild(n)
            },
            f = n => {
                let d = [];
                for (let r in n) d.push(r + "=" + n[r]);
                g.handleLoginOpen({
                    fullName: n.first_name,
                    idToken: d.join(","),
                    openUserId: n.id,
                    userType: "telegram"
                }).then(y.close).catch(m)
            },
            v = async function() {
                const n = await T();
                n.login(d => {
                    if (d.status === "connected") {
                        const {
                            accessToken: r,
                            userID: w
                        } = d.authResponse;
                        n.api("/me", function(b) {
                            g.handleLoginOpen({
                                fullName: b.name,
                                idToken: r,
                                openUserId: w,
                                userType: "facebook"
                            }).then(y.close).catch(m)
                        })
                    }
                })
            };
        return c.exports.useEffect(() => {
            l(), window.onTelegramAuth = f, i(), T()
        }, []), o("div", {
            className: "other-group",
            children: [e("button", {
                id: "gg_login",
                type: "button",
                title: "google",
                ref: a,
                children: Se
            }), e("button", {
                id: "fb_login",
                type: "button",
                title: "facebook",
                onClick: v,
                children: ze
            }), e("button", {
                id: "tg_login",
                type: "button",
                title: "telegram",
                ref: s,
                children: Me
            }), e("div", {
                className: "line"
            }), !D.isMobile && e("button", {
                type: "button",
                onClick: xe,
                children: Ne
            }), e("button", {
                type: "button",
                onClick: ke,
                children: _e
            })]
        })
    }),
    ke = async () => {
        try {
            let [t, a] = await Promise.all([g.getSignMsg(), ye()]), {
                signature: s,
                publicAddress: l
            } = await a.signPersonalMessage(t);
            await g.handleLoginSign({
                signStr: s,
                walletName: "metamask",
                walletUnique: l
            }), y.back()
        } catch (t) {
            m(t)
        }
    },
    xe = async function() {
        try {
            let t = await g.getSignMsg(),
                {
                    signature: a,
                    publicAddress: s
                } = await ce(t);
            await g.handleLoginSign({
                signStr: a,
                walletName: "metamask",
                walletUnique: s
            }), g.init(), y.back()
        } catch (t) {
            m(new Error(t.message.split(`
`)[0]))
        }
    },
    _e = o("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 32 32",
        children: [e("path", {
            fill: "#3d96fc",
            d: "M32 16a16 16 0 11-32 0 16 16 0 0132 0z"
        }), e("path", {
            fill: "#fff",
            d: "M16 14.4l5 5.2 5.1-5.1 2.2 2.1L21 24l-5-5.1-5.2 5.1-7.2-7.3 2.1-2.1 5.1 5 5.1-5zm7.9-2.4l.1.1-2.3 2.4c-4-3.8-7.5-3.9-11.5 0H10l-2.3-2.4c5.2-5 10.8-5 16-.1z"
        })]
    }),
    Se = o("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 32 32",
        children: [e("path", {
            fill: "#fa455e",
            d: "M16 0a16 16 0 110 32 16 16 0 010-32z"
        }), e("path", {
            fill: "#fff",
            d: "M19.5 12.3c-.5-.5-1.1-.9-1.8-1a4.8 4.8 0 00-2-.2c-.9 0-1.7.4-2.3 1a5 5 0 00-2 4 5 5 0 004 4.8 5 5 0 001.6 0c.8 0 1.6-.3 2.2-.7.5-.4 1-.9 1.2-1.4l.3-.9v-.2h-4.4v-3.2h7.5l.2.1.1 1v1.2c0 .5 0 1-.2 1.6v-.1a7.4 7.4 0 01-1.4 3 7 7 0 01-3 2.4h-.1c-.6.2-1.2.4-1.9.4a8.8 8.8 0 01-1.9 0c-.8 0-1.5-.1-2.2-.4-.9-.4-1.6-.8-2.3-1.4-1-.8-1.9-2-2.4-3.2l-.5-1.9v-1.4-.1c0-.9.2-1.7.4-2.5.3-.7.7-1.4 1.2-2 1-1.4 2.5-2.5 4.3-3l1.5-.3a11.1 11.1 0 011.3 0 7.7 7.7 0 014.8 2l-.1.3-2 2h-.1z"
        })]
    }),
    ze = o("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 32 32",
        children: [e("path", {
            fill: "#fff",
            d: "M31.7 16.3a15.7 15.7 0 11-31.4 0 15.7 15.7 0 0131.4 0z"
        }), e("path", {
            fill: "#227aee",
            d: "M0 16a16 16 0 0013.4 15.8V20.6h-4v-4.7h4v-4.4c0-2.7 2.3-5.7 6.5-5.6 1.5 0 3.4.5 3.4.5v4s-1.9-.2-3 0c-1.6.2-2 1.4-2 2v3.3h4.9l-1 4.9h-3.8v11.2A16 16 0 100 16z"
        })]
    }),
    Me = o("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 32 32",
        children: [e("path", {
            fill: "#4bb2dd",
            d: "M16 0a16 16 0 110 32 16 16 0 010-32z"
        }), e("path", {
            fill: "#fff",
            d: "M15 20.6l3.5 2.6.9.5.3.1c.4 0 .7-.2.7-.6l.3-1.2 1.2-5.4 1.3-6.4V10a1 1 0 00-.3-.8.8.8 0 00-.9 0l-5.6 2.1-8.8 3.4-1.5.7a.5.5 0 00-.4.5c0 .3.3.4.5.4l4 1.2a.5.5 0 00.3 0l8-5 1.1-.7c.2-.1.4-.3.6 0l-.2.2-1.4 1.3q-3 2.6-5.8 5.3l-.2.3-.3 3.1v.9c.4 0 .7-.2 1-.5l1.8-1.8z"
        })]
    }),
    Ne = o("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 32 32",
        children: [e("path", {
            fill: "#f3f8fa",
            d: "M16 0a16 16 0 110 32 16 16 0 010-32z"
        }), e("path", {
            fill: "#f6851b",
            d: "M13.4 10.5l5.5.1 4.6 6.2 1.1 3.7-1.2 3.7-3.8-.8-2 2.2H15l-2.6-2-4 1-1.2-4 1.2-3.9z"
        }), e("path", {
            fill: "#e2761b",
            d: "M13.5 10.5l-5.7-2-1 2.8.6 2.7-.3.4.5.5-.3.3.4.5-.2.3.8.9 3.6-1.1 2.8-2.2z"
        }), e("path", {
            fill: "#763d16",
            d: "M7.8 8.5l-1 2.8.6 2.7-.3.4.5.5-.3.3.4.5-.2.3.8.9 3.6-1.1 2.8-2.2z"
        }), e("path", {
            fill: "#e4761b",
            d: "M17.3 13.6l-.1 4.2v4.7l.4-2.6 2-.7 1.4-1.6-1.3-2z"
        }), e("path", {
            fill: "#e4751f",
            d: "M19.5 19V21l1.6-3.3zM17.2 17.8v4.7l.5-3.5z"
        }), e("path", {
            fill: "#cd6116",
            d: "M17.2 17.8l3.9-.2-1.6 1.6-2 .7z"
        }), e("path", {
            fill: "#233447",
            d: "M17.6 19.9l.5-1.3 1.4.6z"
        }), e("path", {
            fill: "#e4761b",
            d: "M19.4 20.9l5.2-.4-1.2 3.8-3.8-.9-1.9-.6z"
        }), e("path", {
            fill: "#cd6116",
            d: "M19.4 20.9l.2 2.5 1.9-2.7z"
        }), e("path", {
            fill: "#e2761b",
            d: "M18.2 10.6l6-2 .8 2.7-.7 2.8.4.3-.5.4.3.4-.4.5.2.2-.7 1-3.8-1.2-2.5-2.1z"
        }), e("path", {
            fill: "#763d16",
            d: "M24.3 8.7l.7 2.6-.7 2.8.4.3-.5.4.3.4-.4.5.2.2-.7 1-3.8-1.2-2.5-2.1z"
        }), e("path", {
            fill: "#e4761b",
            d: "M14.8 13.6v4.2l.2 4.6-.6-2.5-2-.7-1.4-1.6 1.3-2z"
        }), e("path", {
            fill: "#e4751f",
            d: "M12.5 19l.1 1.9-1.6-3.3z"
        }), e("path", {
            fill: "#cd6116",
            d: "M14.8 17.8l-3.8-.2 1.5 1.6 2 .7z"
        }), e("path", {
            fill: "#233447",
            d: "M14.4 19.9l-.5-1.3-1.4.6z"
        }), e("path", {
            fill: "#e4761b",
            d: "M12.6 20.9l-5.5-.2 1.2 3.9 4.1-1.2 1.9-.6z"
        }), e("path", {
            fill: "#cd6116",
            d: "M12.6 20.9l-.2 2.5-1.9-2.6z"
        }), e("path", {
            fill: "#d7c1b3",
            d: "M12.3 23.5l2.5-.8h2.8l2 .7-2 1.7h-3.1z"
        }), e("path", {
            fill: "#c1ae9f",
            d: "M12.2 23.5l2.5 1.2v-.4h3v.4l2-1.3-2 2.2h-3z"
        }), e("path", {
            fill: "#233447",
            d: "M15.2 22.5l2-.1.4.3.1 1.6h-3l.1-1.6z"
        })]
    });
const Ie = X.memo(() => {
    const t = k();
    return o("div", {
        className: Le,
        id: "other-login",
        children: [o("div", {
            className: "box-title",
            children: [" ", t("page.user.other_login"), " "]
        }), e(Ce, {})]
    })
});
E({
    cl1: [x("#99a4b0", .6), x("#5f6975", .6)],
    cl2: [x("#31343c", .5), "#fff"],
    cl3: ["#2d3137", "#e9eaf2"]
});
const Le = "s1i8fy8p";
var Ee = "/assets/ccpay.4a5b4ab6.png";
const I = {
    logo: Y.logo2,
    ccpay: Ee,
    login_coco: Z.login
};
const Ae = C(t => {
        const {
            path: a
        } = t, s = k(), l = ee(() => ({
            email: "",
            password: "",
            autoLogin: !1,
            height: 720
        })), i = c.exports.useCallback(v => {
            l.height = v
        }, []);
        c.exports.useEffect(() => {
            i(a == "regist" ? 800 : 710)
        }, [a]);
        const f = c.exports.useMemo(() => {
            switch (a) {
                case "regist":
                    return e(de, {
                        data: l,
                        onSetSize: i,
                        onEnd: t.onEnd
                    });
                default:
                    return e(pe, {
                        onEnd: t.onEnd,
                        data: l
                    })
            }
        }, [a]);
        return e(U, {
            className: Te,
            nostyle: !0,
            size: [464, l.height],
            children: o(A, {
                children: [e(te, {
                    children: e("img", {
                        className: Be,
                        src: I.logo
                    })
                }), o("div", {
                    className: "welcome",
                    children: [e("div", {
                        className: "msg1",
                        children: s("user.login_welcome")
                    }), e("img", {
                        src: I.login_coco
                    })]
                }), e(ae, {
                    from: P.from,
                    enter: P.to,
                    children: o(se, {
                        className: Pe,
                        hideBar: !0,
                        children: [f, e(Ie, {})]
                    }, a)
                })]
            })
        })
    }),
    P = {
        from: {
            y: "100%"
        },
        to: {
            y: "0%"
        }
    },
    Be = "l1oi4fhy",
    Te = "s1fxj4vq",
    Pe = "c1rg0pmn";
const Re = C(t => {
        const {
            source: a
        } = t, s = k(), [l, i] = c.exports.useState(!0), [f, v] = c.exports.useState({
            sys_id: "",
            access_token: "",
            expire_at: ""
        }), [n, d] = c.exports.useState({
            nickname: "",
            avatar: ""
        }), r = {
            resolve: () => {},
            reject: () => {}
        }, w = new Promise((p, h) => {
            r.resolve = p, r.reject = h
        });
        c.exports.useEffect(() => {
            a !== "CCTIP" && b()
        }, []);
        const b = async () => {
                if (i(!0), !(await g.getPlatform()).find(z => z.openName === a)) return g.channel = "";
                i(!1)
            },
            u = async () => {
                try {
                    await g.handleLoginOpen({
                        openUserId: f.sys_id,
                        fullName: n.nickname,
                        email: "",
                        userType: "CCTIP",
                        idToken: f.access_token,
                        picture: n.avatar
                    }), y.close()
                } catch (p) {
                    m(p)
                }
            };
        return e(U, {
            title: s("title.login"),
            children: o("div", {
                className: `${De} login__oauth`,
                children: [!l && r.resolve(), e(ne, {
                    pms: w,
                    children: () => o(A, {
                        children: [e("img", {
                            src: I.ccpay
                        }), e(S, {
                            className: "button",
                            type: "conic",
                            onClick: u,
                            children: s("page.login.auth_login")
                        })]
                    })
                })]
            })
        })
    }),
    De = "wg23lqg",
    Oe = C(({
        path: t
    }) => {
        const a = L(),
            s = Ue(),
            l = () => {
                setTimeout(() => {
                    D.settings.lastEmail = g.email
                }, 3e3), s && (/http(s?)/.test(s) ? location.href = decodeURIComponent(s) : a(s, {
                    replace: !0
                })), y.back()
            };
        return g.channel ? e(Re, {
            source: g.channel
        }) : e(Ae, {
            path: t,
            onEnd: l
        })
    });

function Ue() {
    const [t] = oe();
    return c.exports.useMemo(() => t.get("redirect"), [])
}
export {
    Oe as
    default
};
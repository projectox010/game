import {
    a5 as l,
    u as E,
    e as N,
    ao as O,
    d as o,
    j as a,
    l as T,
    a as e,
    am as L,
    b as u,
    bf as I,
    I as R,
    v as B,
    G as v,
    p as A,
    r as d,
    cy as U,
    s as f,
    cC as _,
    o as j,
    dc as W,
    dd as q
} from "./index.28e31dff.js";
import {
    r as F
} from "./recaptcha.94966f3c.js";
const w = l.memo(function({
        titleOne: s,
        titleTwo: i,
        titleThree: g,
        className: p,
        registBtn: P,
        agreetext: k,
        emailPlaceholder: y = "Email:",
        passwordPlaceholder: C = "Password:"
    }) {
        const c = E(),
            m = N(),
            [t, h] = O({
                checked: !0,
                invitcode: o.currentInvitationCode || "",
                email: "",
                password: ""
            }),
            D = () => {
                B.close(), m("/help/terms-service")
            },
            S = async function() {
                if (!t.checked) return v(new Error(c("page.login.agreement_tips"))), !1;
                if (!t.password || t.password.length < 6) return v(new Error(c("page.settings.reset_minlen"))), !1;
                try {
                    const n = await F("login");
                    await o.handleRegist(t.email, t.password, t.invitcode, n), m("/")
                } catch (n) {
                    n.code === 5801 ? await A.confirm("Looks like you've already registered, sign in now?") && m("/login", {
                        replace: !0
                    }) : n && v(n)
                }
            };
        return a("div", {
            className: T(z, p, "signup-mode"),
            children: [e("div", {
                className: "bg"
            }), a("div", {
                className: "signup-wrap",
                children: [e("h4", {
                    className: "one-p",
                    children: s
                }), i, e("h2", {
                    className: "three-p",
                    children: g
                }), e(L, {
                    placeholder: y,
                    value: t.email,
                    onChange: n => h({
                        email: n
                    })
                }), e(L, {
                    type: "password",
                    placeholder: C,
                    value: t.password,
                    onChange: n => h({
                        password: n
                    }),
                    onKeyDown: n => {
                        n.keyCode === 13 && S()
                    }
                }), e(u, {
                    className: "regist-btn",
                    type: "conic",
                    onClick: S,
                    children: P || c("title.regist")
                }), a("div", {
                    className: "argument-check",
                    onClick: () => h({
                        checked: !t.checked
                    }),
                    children: [e(I, {
                        type: "checkbox",
                        value: t.checked
                    }), e("div", {
                        className: "label",
                        children: k || e(R, {
                            k: "page.login.check",
                            children: e("a", {
                                className: "argument",
                                onClick: D,
                                children: c("title.help_agreement").toLocaleLowerCase()
                            })
                        })
                    })]
                })]
            })]
        })
    }),
    z = "s1ujkxvb";
var H = "/assets/a.2b86da63.png",
    M = "/assets/b.fadf5ce0.png",
    K = "/assets/c.e71a21bd.png",
    Y = "/assets/d.0b057c1f.png",
    G = "/assets/e.6fe34401.png",
    J = "/assets/f.0c73e022.png",
    V = "/assets/a.fce71b5f.png",
    X = "/assets/b.b6dbcd42.png",
    $ = "/assets/c.1f468318.png",
    Q = "/assets/d.96fe2582.png",
    Z = "/assets/e.2a5346c2.png",
    ee = "/assets/f.1a54b892.png",
    se = "/assets/g.6072576d.png",
    ae = "/assets/h.ce4d8d94.png",
    ne = "/assets/i.f405df81.png",
    te = "/assets/j.f7162d0e.png",
    ie = "/assets/k.1ea1bdd8.png",
    re = "/assets/l.7e8682e6.png",
    le = "/assets/m.468f1b0d.png",
    ce = "/assets/n.74d7dc88.png",
    oe = "/assets/o.19fe54e9.png";
const de = [
        [H, M, K],
        [Y, G, J]
    ],
    ge = [V, X, $, Q, Z, ee, se, ae, ne, te, ie, re, le, ce, oe],
    x = {
        landingLeftList: ge,
        landingRightList: de
    };
const b = l.memo(function() {
        return e("div", {
            className: T(pe, "producer-list"),
            children: a("div", {
                className: "inner",
                children: [e("div", {
                    className: "left-list",
                    children: e("div", {
                        className: "img-wrap",
                        children: x.landingLeftList.map((s, i) => e("img", {
                            src: s,
                            alt: "img"
                        }, "leftimg-" + i))
                    })
                }), e("div", {
                    className: "right-list",
                    children: x.landingRightList.map((s, i) => e("div", {
                        className: "right-wrap-item",
                        children: s.map((g, p) => e("img", {
                            src: g,
                            alt: "img"
                        }, "rightimg-" + p))
                    }, "rightwrap-" + i))
                })]
            })
        })
    }),
    pe = "p100c8nx";
const me = l.memo(function() {
        return a("div", {
            className: he,
            children: [e("div", {
                className: "spin-view",
                children: e("div", {
                    className: "inner",
                    children: e(w, {
                        titleOne: "FREE LUCKY SPIN UP TO",
                        titleThree: "DEPOSIT BONUS",
                        titleTwo: a("p", {
                            className: "two-p",
                            children: [e("span", {
                                children: "5 BTC+"
                            }), e("span", {
                                className: "y",
                                children: "240%"
                            })]
                        })
                    })
                })
            }), e("p", {
                style: {
                    margin: 0,
                    padding: 0,
                    border: 0,
                    display: "none"
                },
                children: e("img", {
                    src: "https://a2.adform.net/Serving/TrackPoint/?pm=2635697&ADFPageName=Spin%20Landing%20Page&ADFdivider=|",
                    width: "1",
                    height: "1",
                    alt: ""
                })
            }), e(b, {})]
        })
    }),
    he = "sp9h5d8";
const ve = l.memo(function() {
        return a("div", {
            className: ue,
            children: [e("div", {
                className: "sports-view",
                children: e("div", {
                    className: "inner",
                    children: e(w, {
                        titleOne: "EXPERIENCE SPORTS AT BC ENJOY",
                        titleThree: "WELCOME BONUS!",
                        titleTwo: a("h1", {
                            className: "two-p",
                            children: [e("span", {
                                children: "UP TO"
                            }), e("span", {
                                className: "y",
                                children: " 5 BTC"
                            })]
                        })
                    })
                })
            }), e("p", {
                style: {
                    margin: 0,
                    padding: 0,
                    border: 0,
                    display: "none"
                },
                children: e("img", {
                    src: "https://a2.adform.net/Serving/TrackPoint/?pm=2635697&ADFPageName=Sports%20Landing%20Page&ADFdivider=|",
                    width: "1",
                    height: "1",
                    alt: ""
                })
            }), e(b, {})]
        })
    }),
    ue = "sbqfd86";
var fe = "/assets/pix.2d090f33.png";
const Ne = l.memo(function() {
        const r = e("h1", {
                className: "two-p",
                children: e("span", {
                    className: "y",
                    children: "AT\xC9 300%"
                })
            }),
            s = d.exports.useContext(U);
        return d.exports.useEffect(() => {
            s.setLang("pt-BR")
        }, []), a("div", {
            className: we,
            children: [e("div", {
                className: "sports-view",
                children: e("div", {
                    className: "inner",
                    children: e(w, {
                        titleOne: "B\xD4NUS DE BOAS-VINDAS",
                        titleThree: "NO SEU PRIMEIRO DEP\xD3SITO",
                        titleTwo: r,
                        className: "sports-sp-title",
                        emailPlaceholder: "Digite seu e-mail",
                        passwordPlaceholder: "Digite sua senha",
                        registBtn: "Registrar",
                        agreetext: "voc\xEA aceita nosso contrato e confirma que tem mais de 18 anos!"
                    })
                })
            }), e(b, {}), e("div", {
                className: "pix",
                children: e("img", {
                    alt: "pixlogo",
                    src: fe
                })
            })]
        })
    }),
    we = "bdiu820";
const be = l.memo(function() {
        const s = E(),
            i = N();
        return e("div", {
            className: Pe,
            children: a("div", {
                className: "header-inner",
                children: [e("img", {
                    onClick: () => i("/"),
                    alt: "logo",
                    src: f.isMobile ? _.small : _.logo
                }), a("div", {
                    className: "login-btns",
                    children: [e(u, {
                        onClick: () => i("/login"),
                        children: s("title.login")
                    }), e(u, {
                        type: "conic",
                        onClick: () => i("/login/regist"),
                        children: s("title.regist")
                    })]
                })]
            })
        })
    }),
    Pe = "lwty68a";
const ke = j(function() {
        const r = N();
        d.exports.useEffect(() => {
            f.isDarken || (f.isDarken = !0)
        }, []), d.exports.useEffect(() => {
            o.login && r("/")
        }, [o.login]);
        const s = W([{
            path: "spin",
            element: e(me, {})
        }, {
            path: "sports",
            element: e(ve, {})
        }, {
            path: "sports-br",
            element: e(Ne, {})
        }]);
        return a("div", {
            className: Se,
            children: [e(be, {}), e("div", {
                className: "landing-main-page",
                children: s
            }), e(q, {})]
        })
    }),
    Se = "l1mr39j3";
var xe = ke;
export {
    xe as LandingPageEnter
};
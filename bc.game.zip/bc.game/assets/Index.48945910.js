var F = Object.defineProperty,
    j = Object.defineProperties;
var z = Object.getOwnPropertyDescriptors;
var R = Object.getOwnPropertySymbols;
var Q = Object.prototype.hasOwnProperty,
    W = Object.prototype.propertyIsEnumerable;
var B = (a, t, s) => t in a ? F(a, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : a[t] = s,
    D = (a, t) => {
        for (var s in t || (t = {})) Q.call(t, s) && B(a, s, t[s]);
        if (R)
            for (var s of R(t)) W.call(t, s) && B(a, s, t[s]);
        return a
    },
    E = (a, t) => j(a, z(t));
import {
    s as l,
    u,
    aP as c,
    a as e,
    D as _,
    j as n,
    S as w,
    I as A,
    l as P,
    o as h,
    r as p,
    aB as I,
    a5 as N,
    F as x,
    t as y,
    q as d,
    v as $,
    A as V,
    b as M,
    m as U,
    a4 as S,
    z as K,
    J as L,
    M as T,
    am as Y,
    aQ as J,
    a3 as O
} from "./index.28e31dff.js";
import {
    P as X,
    a as C
} from "./usePixiGsap.bf451f35.js";
var q = "/assets/boosting.a8002ae7.png",
    G = "/assets/effect.8130471c.png",
    H = "/assets/mask.fe45148d.png",
    Z = "/assets/p_5.5a00dc96.png",
    ee = "/assets/p_7.4b854a9d.png",
    ae = "/assets/p_10.eaf1f705.png",
    te = "/assets/p_15.9b0ee520.png",
    se = "/assets/ring.d1a874ac.png",
    ne = "/assets/light.dcd7d316.png",
    ce = "/assets/30mins.969f937d.png",
    re = "/assets/item.963a5e3d.png",
    ie = "/assets/boosting.9e61461f.png",
    oe = "/assets/effect.e06faab8.png",
    le = "/assets/mask.0ac4d677.png",
    de = "/assets/p_5.2d29ff85.png",
    me = "/assets/p_7.e42951cd.png",
    pe = "/assets/p_10.c8549c69.png",
    ge = "/assets/p_15.11da1ce7.png",
    ue = "/assets/ring.e8c9ba52.png",
    fe = "/assets/light.dcd7d316.png",
    he = "/assets/30mins.9f38b3d2.png",
    ke = "/assets/item.48c6068c.png";
const m = {
    get boostring() {
        return l.isDarken ? ie : q
    },
    get effect() {
        return l.isDarken ? oe : G
    },
    get mask() {
        return l.isDarken ? le : H
    },
    get p_5() {
        return l.isDarken ? de : Z
    },
    get p_7() {
        return l.isDarken ? me : ee
    },
    get p_10() {
        return l.isDarken ? pe : ae
    },
    get p_15() {
        return l.isDarken ? ge : te
    },
    get ring() {
        return l.isDarken ? ue : se
    },
    get light() {
        return l.isDarken ? fe : ne
    },
    get mins() {
        return l.isDarken ? he : ce
    },
    get item() {
        return l.isDarken ? ke : re
    }
};

function ve(a) {
    if (a === 5) return m.p_5;
    if (a === 7) return m.p_7;
    if (a === 10) return m.p_10;
    if (a === 15) return m.p_15
}
const be = () => {
        const a = u();
        let t = c.ptagList,
            s = c.boostPercent;
        return e(_, {
            title: "About Rakeback",
            size: [464, 830],
            nostyle: !0,
            children: n(w, {
                className: Ae,
                children: [n("div", {
                    className: "a_rake_title",
                    children: [e("img", {
                        className: "ths_img",
                        src: m.mins,
                        alt: "ths.png"
                    }), n("div", {
                        className: "title-word",
                        children: [e("div", {
                            children: a("page.rekeback.ready_time")
                        }), e("div", {
                            children: a("page.rekeback.ready_detail")
                        })]
                    })]
                }), n("div", {
                    className: "about_rake_wrap",
                    children: [e("div", {
                        className: "a_rake_progress",
                        children: t.map(r => n("div", {
                            className: `a_progress_item ${r.percent>s?"not_reached":"achieved"} ${r.active?"a_active":""}`,
                            children: [e("div", {
                                className: "a_text",
                                children: r.txt
                            }), e("div", {
                                className: "a_progress",
                                children: e("div", {
                                    className: "a_progress_bar",
                                    style: {
                                        width: `${r.percent*5}%`
                                    }
                                })
                            }), n("div", {
                                className: "a_percent",
                                children: [r.percent, "%"]
                            })]
                        }, r.percent))
                    }), n("div", {
                        className: "a_rake_bottom",
                        children: [e("div", {
                            className: "rake_item",
                            children: e(A, {
                                k: "page.rakeback.des_one",
                                children: e("span", {
                                    children: "VIP14"
                                })
                            })
                        }), e("div", {
                            className: "rake_item",
                            children: a("page.rakeback.des_two")
                        }), e("div", {
                            className: "rake_item",
                            children: e(A, {
                                k: "page.rakeback.des_three",
                                children: n("span", {
                                    children: [s, "%"]
                                })
                            })
                        }), e("div", {
                            className: "rake_item",
                            children: a("page.rakeback.des_four")
                        })]
                    })]
                })]
            })
        })
    },
    Ae = "r1v1gxe9";
const _e = ({
        percent: a,
        cutPercent: t,
        showPercent: s
    }) => {
        let r = "pr-" + a;
        return n("div", {
            className: P(we, r, t < a && "is-active"),
            children: [a, " %", a === t && n("div", {
                className: "tag",
                children: [s, " ", e("span", {
                    children: "%"
                })]
            })]
        })
    },
    we = "i1wfv99x";
const Ne = ({
        boosting: a,
        deg: t
    }) => n("div", {
        className: xe,
        style: {
            transform: `rotate(${t}deg)`
        },
        children: [e("img", {
            src: m.boostring,
            className: `img_boost ${a?"active":""}`
        }), e("img", {
            src: m.light,
            className: `img_light ${a?"active":""}`
        })]
    }),
    xe = "bu99b84";
var ye = "/assets/flower.7d3cc7b4.png",
    Re = "/assets/pig.2ff496f8.json";
const Be = ({
    className: a
}) => {
    const t = p.exports.useRef(null),
        s = c.playAnimate,
        r = c.receiveTime > 0;
    return p.exports.useEffect(() => {
        var o, i;
        s ? (o = t.current) == null || o.play(1) : r && ((i = t.current) == null || i.stop(1))
    }, [s, r]), e(I, {
        ref: t,
        className: a,
        path: Re
    })
};
var De = h(Be),
    Ee = "/assets/rocket.7c6ed763.json";
const Se = ({
    className: a
}) => {
    const t = p.exports.useRef(null);
    return p.exports.useEffect(() => {
        var s;
        (s = t.current) == null || s.play(15)
    }, []), e(I, {
        ref: t,
        className: a,
        path: Ee
    })
};
var Le = N.memo(Se);
const Te = h(() => {
        const a = c.ptagList.map(i => ({
                percent: i.percent,
                showPercent: i.showPercent
            })),
            t = c.boostPercent,
            s = c.boostTime > 0;
        a.unshift({
            percent: 0,
            showPercent: 0
        });
        const r = 360 / 20 * t + 90,
            o = t === 0 ? e(x, {}) : e("img", {
                className: "full abs",
                src: ve(t)
            });
        return n("div", {
            className: Ce,
            children: [n("div", {
                className: "wrap full",
                children: [e("img", {
                    src: m.ring,
                    className: "full abs"
                }), e("img", {
                    src: ye,
                    className: "full abs"
                }), e(De, {
                    className: "lottie-pig"
                }), e("img", {
                    src: m.mask,
                    className: "full"
                }), s && e(Le, {
                    className: "lottie-rocket"
                }), e(Ne, {
                    boosting: s,
                    deg: r
                }), o, e("img", {
                    src: m.item,
                    className: "full abs"
                })]
            }), a.map(i => e(_e, {
                percent: i.percent,
                showPercent: i.showPercent,
                cutPercent: t
            }, i.percent))]
        })
    }),
    Ce = "c1knxx6a",
    Pe = () => e("div", {
        className: Ie,
        children: n("div", {
            className: $e,
            children: [e("img", {
                src: m.effect,
                className: "img_effect"
            }), e(Te, {})]
        })
    }),
    Ie = "at1ondx",
    $e = "r1q4goyk";
var Ve = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAASBAMAAACk4JNkAAAAG1BMVEX/pWQAAAD/pmT/pmX/pGP/pGX/qmT/oWv/qmbEa3+QAAAACXRSTlN9AHZqX0whEx6dsZm3AAAAVElEQVQI12MQFBQLVjJNFBRkEBR3YGBgYCkEspoYQEBDkEFcAcxiKmQQYYAAR4YEKIuNIQDKYmUwgLKYGRSgLCYECyGL0IEwBWEywjaECxCuQrgUAKk1Cl2y5CTsAAAAAElFTkSuQmCC",
    Me = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHgAAAB4BAMAAADLSivhAAAAD1BMVEX/gCMAAAD/hCn/iTD/jzp2F9WvAAAABXRSTlMWAA4IBOjhB4gAAAIESURBVFjD1dlRkqowFATQJriACWEBBDdAdBZg3tv/nkZrKLtmGEj65sOy/0/dSxsUSvi9/L/MADCfP/1edvB4AZhzVjApeSUOEzZxqQ7/w585FzBtnca+LWuULdMf4wGHiUc4oJB0gKcSdnkX31BMv4cDKhK3mEsri6Oyaeb0Fx5RmUS8aUvoDPJgIBFzsDwaHKyOJv5Q8OkXnqAk/8ADpMQfeNGwI2ZdYmXg1nplYF363uDW+t7g1lK6J1507J4YhuQVDxYcV3yz4H7FkwW7FQPGiwYvWb9o8FbWTyj4KesXDfal5oFHGJPuOADWxsC+9HsDPF/6GQPL1usGy5ZzxzAnY7TjhGDHEcOLcIcPOz614B63FrzYsXshnt4R4z1xa2HvecJacNMt+bJvkg7Di3BEaMHejlPTr2QDdi0/7n3LM8npjgcr7lofpbwV5weeWp49b8ayW563uwe2NhZbXhP8N14aXlBsZ+y04tDwUmb7pP2KLZ903/IKHJ/Y6zgTL/rWxIO8NbHetyeW++6J9XOSiOXKnCeWK4vEcmUuE8ujO08sj/bE8ui4wRxdU/UWh+rBxMwiHK4NHmsWzzvYD8LSxFxcWJqYjVc1TVx/2ekQ+zDVW2LqsiWu07RbXL5ulyv/KbuU/zEi3g7/xefky5gJl+fy7kxawhx/vc7z9frpd/MFP2d9a8TUxOEAAAAASUVORK5CYII=";
const Ue = {
        list: [{
            value: 0,
            time: 0
        }, {
            value: 1,
            time: .5
        }, {
            value: 0,
            time: 1
        }],
        isStepped: !1
    },
    Fe = {
        list: [{
            value: .3,
            time: 0
        }, {
            value: .5,
            time: 1
        }],
        isStepped: !1,
        minimumScaleMultiplier: 2
    },
    je = {
        start: 10,
        end: 20,
        minimumSpeedMultiplier: 1.3
    },
    ze = {
        x: 0,
        y: 0
    },
    Qe = 0,
    We = {
        min: 0,
        max: 260
    },
    Ke = !1,
    Ye = {
        min: 0,
        max: 0
    },
    Je = {
        min: 8,
        max: 12
    },
    Oe = "normal",
    Xe = 1,
    qe = -1,
    Ge = 500,
    He = {
        x: 0,
        y: 0
    },
    Ze = !1,
    ea = "rect",
    aa = {
        x: 0,
        y: 0,
        w: 464,
        h: 300
    },
    ta = !0,
    sa = !0;
var na = {
    alpha: Ue,
    scale: Fe,
    speed: je,
    acceleration: ze,
    maxSpeed: Qe,
    startRotation: We,
    noRotation: Ke,
    rotationSpeed: Ye,
    lifetime: Je,
    blendMode: Oe,
    frequency: Xe,
    emitterLifetime: qe,
    maxParticles: Ge,
    pos: He,
    addAtBack: Ze,
    spawnType: ea,
    spawnRect: aa,
    emit: ta,
    autoUpdate: sa
};
const ca = {
        start: 1,
        end: .23
    },
    ra = {
        start: .4,
        end: .3,
        minimumScaleMultiplier: 2
    },
    ia = {
        start: 30,
        end: 0,
        minimumSpeedMultiplier: 1
    },
    oa = {
        x: 0,
        y: 2
    },
    la = 0,
    da = {
        min: 260,
        max: 280
    },
    ma = !0,
    pa = {
        min: 3,
        max: 0
    },
    ga = {
        min: 5,
        max: 8
    },
    ua = "normal",
    fa = .4,
    ha = 100,
    ka = 30,
    va = {
        x: 0,
        y: 0
    },
    ba = !1,
    Aa = "rect",
    _a = {
        x: 225,
        y: 40,
        w: 50,
        h: 30
    },
    wa = !0;
var Na = {
    alpha: ca,
    scale: ra,
    speed: ia,
    acceleration: oa,
    maxSpeed: la,
    startRotation: da,
    noRotation: ma,
    rotationSpeed: pa,
    lifetime: ga,
    blendMode: ua,
    frequency: fa,
    emitterLifetime: ha,
    maxParticles: ka,
    pos: va,
    addAtBack: ba,
    spawnType: Aa,
    spawnRect: _a,
    autoUpdate: wa
};
const xa = ({
        boostTime: a,
        update: t,
        boost: s
    }) => {
        const [r, o] = p.exports.useState(!1), i = u(), g = a === 0, f = new Date().getTime() + a, k = p.exports.useCallback(async () => {
            !g || (o(!0), await s(), o(!1))
        }, [s, g]);
        return e(M, {
            type: "gray",
            loading: r,
            className: g ? "" : "gray",
            onClick: k,
            children: g ? i("page.rekeback.rakeback_boost") : e(U, {
                endTime: f,
                onEnd: t,
                children: ({
                    minutes: v,
                    seconds: b
                }) => n(x, {
                    children: [i("page.rekeback.boosting"), " ", c.completion(v), " :", " ", c.completion(b)]
                })
            })
        })
    },
    ya = function() {
        const t = u();
        return n("div", {
            className: Da,
            children: [e(Ba, {
                boosting: c.boostTime > 0
            }), n("div", {
                className: "wrap",
                children: [n("div", {
                    className: "tit",
                    children: [e("span", {
                        children: t("page.rekeback.percentage")
                    }), e("div", {
                        className: "rules",
                        onClick: () => $.push(e(be, {})),
                        children: e(V, {
                            name: "Help"
                        })
                    })]
                }), e(Pe, {}), n("div", {
                    className: "cost",
                    children: [e("div", {
                        children: e(A, {
                            k: "page.rekeback.cost_boost",
                            children: e("b", {
                                children: "20,000 JB"
                            })
                        })
                    }), e("div", {
                        className: "tag",
                        children: "+5%"
                    })]
                }), n("div", {
                    className: "btn-wrap",
                    children: [e("div", {
                        className: "btn-tit",
                        children: t("game.rakeback.percent", "+5%")
                    }), e(xa, {
                        boostTime: c.boostTime,
                        update: c.syncdata,
                        boost: c.Boost
                    })]
                })]
            })]
        })
    };
var Ra = h(ya);
const Ba = N.memo(function({
    boosting: t
}) {
    return e("div", {
        className: "bg",
        children: n(X, {
            width: 500,
            height: 500,
            fps: 30,
            children: [e(C, {
                textures: Me,
                config: na
            }), e(C, {
                emit: t,
                textures: Ve,
                config: Na
            })]
        })
    })
});
y({
    gd1: ["linear-gradient(165deg, #fb9013 -50%, #8c581b -5%, #1e2024 50%)", "linear-gradient(165deg, #ff8a01 -50%, #f18f20 -5%, #e9eaf2 50%)"],
    cl1: ["#2d3035", "#dadde6"],
    cl2: ["inherit", "#31373d"],
    cl3: [d("#2d3035", .4), d("#cccfd9", .5)],
    cl4: ["inherit", d("#5f6975", .8)],
    cl5: ["#31343c", d("#6b7180", .4)]
});
const Da = "t12n959l";
const Ea = N.memo(() => {
    const a = c.list;
    return a.length === 0 ? e(S, {}) : e(_, {
        children: e(w, {
            className: La,
            children: a.length > 0 ? a.map(t => p.exports.createElement(Sa, E(D({}, t), {
                key: t.currencyName
            }))) : e(S, {})
        })
    })
});

function Sa(a) {
    return n("div", {
        className: "item",
        children: [e("div", {
            className: "coin-wrap",
            children: e(K, {
                name: a.currencyName
            })
        }), n("div", {
            className: "name-wrap",
            children: [e("div", {
                className: "currency-name",
                children: L.getAlias(a.currencyName)
            }), e("div", {
                className: "full-name",
                children: L.getFullName(a.currencyName)
            })]
        }), n("div", {
            className: "amount-wrap",
            children: [e(T, {
                name: a.currencyName,
                amount: a.amount,
                className: "monospace"
            }), e(T, {
                className: "weaken monospace",
                name: a.currencyName,
                disableLocal: !0,
                amount: a.amount
            })]
        })]
    })
}
y({
    cl1: ["#fff", "#31373d"],
    cl2: [d("#000000", .1), "#E1E1EE"],
    cl3: [d("#99a4b0", .5), d("#99a4b0", .8)]
});
const La = "s1mxc860";
const Ta = ({
        canReciveList: a,
        canReciveTime: t,
        cutTime: s,
        onRevice: r
    }) => {
        const o = u(),
            [i, g] = p.exports.useState(!1),
            f = !a || !t,
            k = p.exports.useCallback(async () => {
                f || (g(!0), l.playSound("claim"), await r(), g(!1))
            }, [f, r]);
        return e(M, {
            type: "conic",
            loading: i,
            className: f ? "gray" : "",
            onClick: k,
            children: t ? o("page.task.receive") : e(U, {
                endTime: s,
                children: ({
                    minutes: v,
                    seconds: b
                }) => n(x, {
                    children: [o("game.rakeback.ready"), " ", c.completion(v), " :", " ", c.completion(b)]
                })
            })
        })
    },
    Ca = function() {
        const t = c.receiveTime <= 0,
            s = c.list.length > 0,
            r = u(),
            o = Date.now() + c.receiveTime;
        return n("div", {
            className: P(Pa, t && s && "light"),
            children: [e("div", {
                className: "tit",
                children: r("game.rakeback.curt")
            }), e(Y, {
                value: c.getUsdtAmount,
                readOnly: !0,
                onClick: () => $.push(e(Ea, {})),
                children: e("div", {
                    className: "claimed-wrap",
                    children: e(V, {
                        name: "Arrow"
                    })
                })
            }), n("div", {
                className: "btn-wrap",
                children: [n("div", {
                    className: "minutes",
                    children: [r("game.rakeback.refreash_tip", "2"), e(J, {
                        endTime: c.nextCalcTime + 2e3,
                        startTime: Date.now(),
                        onComplete: c.getList
                    })]
                }), e(Ta, {
                    canReciveTime: t,
                    canReciveList: s,
                    cutTime: o,
                    onRevice: c.receiveAward
                })]
            })]
        })
    };
y({
    cl1: ["transparent", "#e9eaf2"],
    cl2: ["inherit", d("#5f6975", .8)],
    cl3: [d("#99a4b0", .6), d("#5f6975", .6)],
    cl4: ["#906b41", "#fbb768"],
    cl5: ["#f5f6f7", "#31373d"],
    cl6: ["#31343c", "#fff"],
    cl7: ["#31343c", d("#6b7180", .4)],
    gd1: ["linear-gradient( to right, #fb9013 -30%, #2d3035 20%, #2d3035 35%)", "linear-gradient(to right, #fb9013 -30%, #f5f6fa 20%, #f5f6fa 35%)"]
});
const Pa = "rszfbau";
var Ia = h(Ca);
const $a = function() {
    const t = u();
    return p.exports.useEffect(() => (c.syncdata(), () => c.desactive()), []), c.loading ? e(O, {}) : e(_, {
        title: t("page.rekeback.title"),
        className: "dialog-rakeback",
        size: [464, 830],
        nostyle: !0,
        children: n(w, {
            className: Va,
            id: "reckback",
            children: [e(Ra, {}), e(Ia, {})]
        })
    })
};
var ja = h($a);
const Va = "r10rqzy0";
export {
    ja as
    default
};
var _e = Object.defineProperty,
    De = Object.defineProperties;
var Oe = Object.getOwnPropertyDescriptors;
var Z = Object.getOwnPropertySymbols;
var ye = Object.prototype.hasOwnProperty,
    ve = Object.prototype.propertyIsEnumerable;
var ie = (t, s, e) => s in t ? _e(t, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : t[s] = e,
    S = (t, s) => {
        for (var e in s || (s = {})) ye.call(s, e) && ie(t, e, s[e]);
        if (Z)
            for (var e of Z(s)) ve.call(s, e) && ie(t, e, s[e]);
        return t
    },
    le = (t, s) => De(t, Oe(s));
var Ne = (t, s) => {
    var e = {};
    for (var n in t) ye.call(t, n) && s.indexOf(n) < 0 && (e[n] = t[n]);
    if (t != null && Z)
        for (var n of Z(t)) s.indexOf(n) < 0 && ve.call(t, n) && (e[n] = t[n]);
    return e
};
var v = (t, s, e) => (ie(t, typeof s != "symbol" ? s + "" : s, e), e);
import {
    a,
    dx as Be,
    j as u,
    dy as He,
    a5 as _,
    f8 as me,
    T as he,
    k as pe,
    l as P,
    o as w,
    r as N,
    e as Fe,
    s as k,
    d as F,
    F as ce,
    as as $e,
    at as ze,
    ao as je,
    ef as E,
    dk as We,
    b as j,
    A as re,
    dl as Ye,
    y as A,
    J as U,
    M as Ke,
    ea as qe,
    t as fe,
    q as M,
    u as $,
    G as ee,
    e9 as Ue,
    f9 as Je,
    H as Xe,
    S as xe,
    dG as Ze,
    dY as Qe,
    eb as et,
    dC as tt,
    dD as st,
    dZ as nt,
    dE as at,
    dp as J,
    du as it,
    bN as Pe,
    d_ as lt,
    eu as te,
    ba as ot,
    bb as O,
    dR as ct,
    dh as Ce,
    d4 as Q,
    D as Re,
    df as rt,
    n as ut,
    a2 as dt,
    bo as mt,
    dH as be,
    cJ as ht,
    x as pt,
    am as Y
} from "./index.28e31dff.js";
import {
    l as oe
} from "./lodash.f3c7da90.js";
import {
    s as ue
} from "./index.dd8128e8.js";
import {
    G as z
} from "./index.06a59a68.js";
import {
    u as ft
} from "./useLocalStore.f739c306.js";
const bt = function({
        game: s
    }) {
        return a(Be, {
            children: u("div", {
                className: "item",
                children: [a("h2", {
                    children: "What Is Baccarat?"
                }), a("div", {
                    className: "content",
                    children: s.gameInfo.detail.split(`
`).map((e, n) => a("p", {
                        children: `${e}`
                    }, n.toString()))
                })]
            })
        })
    },
    gt = function({
        game: s
    }) {
        return a(He, {
            title: "Max Profits",
            game: s
        })
    };
var f = (t => (t[t.UNSESECT = -1] = "UNSESECT", t[t.PLAYER = 0] = "PLAYER", t[t.BANKER = 1] = "BANKER", t[t.TIE = 2] = "TIE", t[t.PPAIR = 3] = "PPAIR", t[t.BPAIR = 4] = "BPAIR", t))(f || {});
const Ae = {
        resolve: () => {},
        reject: () => {}
    },
    I = {
        [-1]: 1,
        [0]: 2,
        [1]: 1.95,
        [2]: 9,
        [4]: 12,
        [3]: 12
    };

function Se() {
    const t = R(),
        s = t.lastGameValue,
        e = s && s.playerPoint || 0,
        n = s && s.bankerPoint || 0,
        l = e > n,
        i = n > e,
        o = e == n;
    return {
        isPlayerWin: l,
        isBankerWin: i,
        isTie: o,
        isAnimEnd: t.isAnimEnd,
        sounds: t.sounds,
        backCardFlag: t.backCardFlag,
        settings: t.settings
    }
}

function Ee(t) {
    return t.toFixed(2)
}

function yt(t) {
    let s = [];
    return t.length <= 0 ? [] : (t.forEach(e => {
        for (let n = 0; n < e.chipNum; n++) s.push({
            chip: e.chip,
            chipNum: 1
        })
    }), s)
}
const vt = _.memo(function({
    haveAnim: s,
    chipList: e
}) {
    if (e.length <= 0) return null;
    const n = yt(e),
        l = n.length > 100 ? n.slice(0, 100) : n,
        i = s ? Ct : Nt;
    return a("div", {
        className: At,
        children: a("div", {
            className: "random-inner",
            children: l.map((o, c) => a(i, {
                chip: o.chip
            }, o.chip.value.mul(o.chipNum).toString() + c))
        })
    })
});

function Ie() {
    const t = Math.floor(Math.random() * 50),
        s = Math.floor(Math.random() * 50),
        e = t >= 25 ? t + 100 : -t,
        n = s >= 25 ? s + 100 : -s,
        l = Math.floor(Math.random() * 80) + 10,
        i = Math.floor(Math.random() * 80) + 10;
    return {
        startX: e,
        startY: n,
        endX: l,
        endY: i
    }
}
const Nt = _.memo(function({
        chip: t
    }) {
        const {
            endX: s,
            endY: e
        } = Ie();
        return a("div", {
            className: "amimation-chip-img",
            style: {
                left: `${s}%`,
                top: `${e}%`
            },
            children: a(me, {
                chip: t
            })
        })
    }),
    Ct = _.memo(function({
        chip: t
    }) {
        const {
            startX: s,
            startY: e,
            endX: n,
            endY: l
        } = Ie();
        return a(he, {
            from: {
                left: `${s}%`,
                top: `${e}%`,
                opacity: 0
            },
            enter: {
                left: `${n}%`,
                top: `${l}%`,
                opacity: 1
            },
            children: a(pe.div, {
                className: "amimation-chip-img",
                children: a(me, {
                    chip: t
                })
            })
        })
    }),
    At = "r1n80gx3",
    V = _.memo(function({
        title: t,
        odds: s,
        className: e,
        chipList: n,
        haveAnim: l = !0
    }) {
        return a("div", {
            className: P("type-area", e),
            title: "0.0008",
            children: u("div", {
                className: "type-inner",
                children: [a("p", {
                    className: "t",
                    children: t
                }), u("p", {
                    className: "d",
                    children: ["x", Ee(s)]
                }), a(vt, {
                    haveAnim: l,
                    chipList: n
                })]
            })
        })
    });
var kt = w(function() {
    const s = R(),
        [e, n] = N.exports.useState({});
    return N.exports.useEffect(() => {
        if (s.guessList.length > 0 && s.amount.gt(0)) {
            const l = s.guessList.slice(-1)[0];
            n(l.guessChipList)
        } else n({})
    }, [s.amount]), u("div", {
        className: Lt,
        children: [a(wt, {}), a(V, {
            title: "TIE",
            odds: I[f.TIE],
            className: "type-t",
            chipList: e[f.TIE] || []
        }), a(V, {
            title: "P PAIR",
            odds: I[f.PPAIR],
            className: "type-pp",
            chipList: e[f.PPAIR] || []
        }), a(V, {
            title: "B PAIR",
            odds: I[f.BPAIR],
            className: "type-bp",
            chipList: e[f.BPAIR] || []
        }), a(V, {
            title: "PLAYER",
            odds: I[f.PLAYER],
            className: "type-p",
            chipList: e[f.PLAYER] || []
        }), a(V, {
            title: "BANKER",
            odds: I[f.BANKER],
            className: "type-b",
            chipList: e[f.BANKER] || []
        })]
    })
});
const wt = w(function() {
        const t = Fe(),
            s = R(),
            e = k.isMobile ? "M5.6,0C2.5,0,0,2.5,0,5.6v54h194V0H5.6z" : "M10,0C4.5,0,0,4.5,0,10v113.1c0,4.2,2.6,7.9,6.5,9.4c61,22.8,123.1,39.3,186.5,49.4V0H10z",
            n = k.isMobile ? "M388,5.6c0-3.1-2.5-5.6-5.6-5.6H194v59.6h194V5.6z" : "M682,0H499.6v181.9c63.3-10.1,125.3-26.6,185.9-49.5c3.9-1.5,6.5-5.2,6.5-9.4V10C692,4.5,687.5,0,682,0z",
            l = k.isMobile ? "M0,59.6v29.6c0,2.3,1.4,4.4,3.6,5.2c41,15.4,82.9,25.6,125.7,30.7V59.6H0z" : "M193,91v90.9c50.4,8,101.5,12.1,153.3,12.1V91H193z",
            i = k.isMobile ? "M258.3,59.6v65.6c43.1-5.1,85.1-15.4,126-30.8c2.2-0.8,3.6-2.9,3.6-5.2V59.6H258.3z" : "M346.3,91v103c0.1,0,0.1,0,0.2,0c51.8,0,102.9-4,153.1-12V91H346.3z";
        return u("svg", {
            viewBox: k.isMobile ? "0 0 388 129" : "0 0 692 194",
            children: [a("path", {
                className: "btn",
                onClick: () => {
                    F.login || t("/login"), s.addChips(f.PLAYER, s.chip, 1)
                },
                d: e
            }), a("path", {
                className: "btn",
                onClick: () => {
                    F.login || t("/login"), s.addChips(f.BANKER, s.chip, 1)
                },
                d: n
            }), a("path", {
                className: "btn",
                onClick: () => {
                    F.login || t("/login"), s.addChips(f.PPAIR, s.chip, 1)
                },
                d: l
            }), a("path", {
                className: "btn",
                onClick: () => {
                    F.login || t("/login"), s.addChips(f.BPAIR, s.chip, 1)
                },
                d: i
            }), k.isMobile ? a("path", {
                className: "btn",
                onClick: () => {
                    F.login || t("/login"), s.addChips(f.TIE, s.chip, 1)
                },
                d: "M129.4,59.6v65.5c21.4,2.6,43,3.8,64.9,3.8c21.6,0,43-1.3,64-3.7V59.6H129.4z"
            }) : a("polygon", {
                className: "btn",
                onClick: () => {
                    F.login || t("/login"), s.addChips(f.TIE, s.chip, 1)
                },
                points: "346.3,0 193,0 193,91 346.3,91 499.6,91 499.6,0"
            }), k.isMobile ? u(ce, {
                children: [a("line", {
                    id: "Line-Copy-3",
                    className: "line",
                    x1: "193.5",
                    y1: "0.2",
                    x2: "193.5",
                    y2: "59.4"
                }), a("line", {
                    id: "Line-Copy-4",
                    className: "line",
                    x1: "257.8",
                    y1: "59.8",
                    x2: "257.8",
                    y2: "123.8"
                }), a("line", {
                    id: "Line-Copy-5",
                    className: "line",
                    x1: "128.8",
                    y1: "59.8",
                    x2: "128.8",
                    y2: "123.8"
                }), a("line", {
                    id: "Line-Copy-2",
                    className: "line",
                    x1: "0.8",
                    y1: "59.4",
                    x2: "387.8",
                    y2: "59.4"
                })]
            }) : u(ce, {
                children: [a("line", {
                    id: "Line-Copy",
                    className: "line",
                    x1: "193",
                    y1: "0.8",
                    x2: "193",
                    y2: "181.8"
                }), a("line", {
                    id: "Line-Copy-4",
                    className: "line",
                    x1: "499.6",
                    y1: "0.8",
                    x2: "499.6",
                    y2: "181.8"
                }), a("line", {
                    id: "Line-Copy-3",
                    className: "line",
                    x1: "346.4",
                    y1: "91.8",
                    x2: "346.4",
                    y2: "193.8"
                }), a("line", {
                    id: "Line-Copy-2",
                    className: "line",
                    x1: "193.9",
                    y1: "91.4",
                    x2: "499",
                    y2: "90.9"
                })]
            })]
        })
    }),
    Lt = "s14aawzf";
const Bt = $e(() => ze(() =>
        import ("./CardAsync.32fe6361.js"), ["assets/CardAsync.32fe6361.js", "assets/CardAsync.a6da7656.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    xt = _.forwardRef(function(i, l) {
        var o = i,
            {
                style: s,
                className: e = ""
            } = o,
            n = Ne(o, ["style", "className"]);
        return a("div", {
            className: `${e} ${Pt} card-wrap`,
            ref: l,
            style: s,
            children: a(Bt, S({}, n))
        })
    });
var X = w(xt);
const Pt = "c1b7432r";
var Rt = "/assets/baccarat.8ca4c44c.png",
    St = "/assets/baccarat_w.ed064de0.png",
    Et = "/assets/poker_bg.b80c0e35.png",
    It = "/assets/poker_three.1f9121bf.svg";
const de = {
    baccarat: Rt,
    baccarat_w: St,
    poker_bg: Et,
    poker_three: It
};
var Vt = w(() => {
    const t = R(),
        s = t.lastGameValue,
        e = s && s.odds ? s.odds : 0,
        n = s ? e < 1 : !1,
        l = N.exports.useRef(null),
        i = t.settings.fastEnable ? 0 : 500,
        {
            bankers: o,
            players: c
        } = N.exports.useMemo(() => _t(s ? s.playerCards : [], s ? s.bankerCards : [], i), [s]),
        r = N.exports.useMemo(() => a("div", {
            ref: l,
            className: "dealer",
            children: a("img", {
                className: "dealer-svg",
                src: de.poker_three
            })
        }), []);
    return u("div", {
        className: P(Dt, t.isAnimEnd && "anim-end", n && "anim-lose"),
        children: [a(ke, {
            promiseFn: () => t.playerPromise.resolve(!0),
            cards: c,
            dealerRef: l,
            isPlayer: !0,
            fastEnable: t.settings.fastEnable
        }), a(ke, {
            promiseFn: () => t.bankerPromise.resolve(!0),
            cards: o,
            dealerRef: l,
            isPlayer: !1,
            fastEnable: t.settings.fastEnable
        }), r]
    })
});
const ne = class extends E {
    constructor(e, n) {
        super(e);
        v(this, "idx");
        v(this, "dealerTime");
        this.idx = ne.idx, this.dealerTime = n, ne.idx++
    }
};
let q = ne;
v(q, "idx", 0);
const ke = _.memo(({
        cards: t,
        dealerRef: s,
        isPlayer: e,
        fastEnable: n,
        promiseFn: l
    }) => {
        const [i, o] = N.exports.useState([]), [c, r] = N.exports.useState(!0), m = i.reduce((p, h) => (p + h) % 10, 0);
        N.exports.useEffect(() => {
            if (o([]), t) {
                const p = n ? 0 : 500,
                    h = n ? 700 : 500;
                let g = null;
                const C = t.map((y, L) => setTimeout(() => {
                    const B = y.point > 10 ? 10 : y.point;
                    o(T => T.concat(B)), L === 0 && r(!0), L === t.length - 1 && (g = setTimeout(() => {
                        l()
                    }, h))
                }, y.dealerTime + p));
                return () => {
                    C.forEach(y => clearTimeout(y)), clearTimeout(g)
                }
            }
        }, [t]);
        const d = N.exports.useMemo(() => a(ce, {
                children: t.map((p, h) => a(Tt, {
                    idx: h,
                    isPlayer: e,
                    card: p,
                    dealerRef: s
                }, p.idx))
            }), [t]),
            b = t.length === 0 || i.length >= 3;
        return a("div", {
            className: "cards-group-wrap",
            children: u("div", {
                className: P("cards-group", b && "clen-3"),
                children: [d, a(Gt, {
                    isPlayer: e,
                    show: c,
                    hiddenFn: () => r(!1),
                    totalValue: t.length === 0 ? "?" : String(m)
                }), a(Mt, {
                    visible: t.length === 0
                })]
            })
        })
    }),
    Gt = w(function({
        isPlayer: t,
        totalValue: s,
        show: e,
        hiddenFn: n
    }) {
        const {
            isPlayerWin: l,
            isBankerWin: i,
            isTie: o,
            isAnimEnd: c,
            settings: r,
            backCardFlag: m
        } = Se();
        let d = "";
        t ? d = o ? "tie" : l ? "win" : "" : d = o ? "tie" : i ? "win" : "";
        const b = r.fastEnable ? c ? s : "?" : s,
            p = c && s != "?",
            h = s === "?" || r.fastEnable ? !1 : !e;
        return N.exports.useEffect(() => {
            m && n()
        }, [m]), u("div", {
            className: P("tip", h && "hidden"),
            children: [a("div", {
                children: t ? "PLAYER" : "BANKER"
            }), a("div", {
                className: P(p ? d : "", "result"),
                children: b
            })]
        })
    }),
    Tt = w(({
        idx: t,
        isPlayer: s,
        card: e,
        dealerRef: n
    }) => {
        const {
            isPlayerWin: l,
            isBankerWin: i,
            isTie: o,
            isAnimEnd: c,
            sounds: r,
            backCardFlag: m,
            settings: d
        } = Se(), b = N.exports.useRef(null), [p, h] = je({
            style: void 0,
            active: !1
        });
        N.exports.useLayoutEffect(() => {
            const C = n.current,
                y = b.current;
            if (!C || !y) return;
            const L = y.getBoundingClientRect(),
                B = C.getBoundingClientRect();
            d.fastEnable || h({
                style: {
                    transform: `translate(${B.x-L.x}px, ${B.y-L.y}px)`,
                    visibility: "hidden"
                }
            });
            const T = d.fastEnable ? 0 : e.dealerTime,
                x = setTimeout(() => {
                    d.fastEnable ? t === 0 && s && r.playSound("pokerSound") : r.playSound("pokerSound"), h({
                        style: {
                            transform: "translate(0px, 0px)",
                            transition: "transform .5s cubic-bezier(0.22, 0.61, 0.36, 1)",
                            visibility: "visible"
                        }
                    })
                }, T),
                D = setTimeout(() => {
                    h({
                        active: !0
                    })
                }, T + 500);
            return () => {
                clearTimeout(x), clearTimeout(D)
            }
        }, []), N.exports.useEffect(() => {
            if (m && !d.fastEnable) {
                const C = n.current,
                    y = b.current;
                if (!C || !y) return;
                const L = y.getBoundingClientRect(),
                    B = C.getBoundingClientRect();
                r.playSound("newtableSound"), h({
                    style: {
                        transform: `translate(${B.x-L.x}px, ${B.y-L.y}px)`,
                        transition: `all ${k.isMobile?.3:.5}s cubic-bezier(0.22, 0.61, 0.36, 1)`,
                        opacity: 0
                    }
                })
            }
        }, [m, d]);
        let g = "";
        return o ? g = "tie" : s ? g = l ? "win" : "" : s || (g = i ? "win" : ""), a(X, {
            ref: b,
            className: c ? g : "",
            card: e,
            active: p.active,
            style: p.style
        })
    }),
    Mt = ({
        visible: t
    }) => u("div", {
        className: P("placehold", t && "is-visible"),
        children: [a("div", {
            className: "one"
        }), a("div", {
            className: "two"
        }), a("div", {
            className: "three"
        })]
    });

function _t(t, s, e) {
    const n = [...t],
        l = [...s];
    let i = [],
        o = [],
        c = 100;
    for (;;) {
        let r = n.shift(),
            m = l.shift();
        if (r && (i.push(new q(r, c)), c += e), m && (o.push(new q(m, c)), c += e), !r && !m) break
    }
    return {
        players: i,
        bankers: o
    }
}
const Dt = "s14u5vmi";
const Ot = _.memo(() => {
        const t = R();
        return N.exports.useEffect(() => {
            t.resetBetAmount()
        }, []), a(Ht, {})
    }),
    Ht = w(function() {
        const t = R();
        let s = t.isAnimEnd && t.showResult && !t.backCardFlag;
        return t.controlIdx != 1 && (s = s && !t.isBetting), u(We, {
            className: $t,
            children: [u("div", {
                className: "table-stylewrap",
                children: [a(Vt, {}), a("div", {
                    className: "baccarat-logo",
                    children: a("img", {
                        alt: "baccarat",
                        src: k.isDarken ? de.baccarat : de.baccarat_w
                    })
                }), u("div", {
                    className: "table-wrap",
                    children: [u("div", {
                        className: "actionlist-wrap",
                        children: [u(j, {
                            className: "action",
                            onClick: () => t.undoAction(),
                            children: [a(re, {
                                name: "Undo"
                            }), a("span", {
                                children: "Undo"
                            })]
                        }), u(j, {
                            className: "action clear",
                            onClick: () => t.clearBetList(),
                            children: [a("span", {
                                children: "Clear"
                            }), a(re, {
                                name: "Refresh"
                            })]
                        })]
                    }), a(kt, {})]
                })]
            }), a(Ye, {}), s && a(Ft, {})]
        })
    }),
    Ft = w(function() {
        const t = R();
        if (N.exports.useEffect(() => {
                if (t.lastGameValue) {
                    const i = t.lastGameValue.odds || -1;
                    i > 1 && t.settings.soundEnable && k.playSound("win"), t.lastGameValue.playerPoint === t.lastGameValue.bankerPoint && t.sounds.playSound("tieSound"), i < 1 && t.settings.soundEnable && t.sounds.playSound("loseSound")
                }
            }, []), !t.lastGameValue) return null;
        const s = t.lastGameValue.odds || -1;
        if (s < 1) return null;
        const e = new A(s).mul(t.resultInfo.amount),
            n = U.dict[t.resultInfo.currencyName].precision || 8,
            l = t.lastGameValue.playerPoint === t.lastGameValue.bankerPoint;
        return a("div", {
            className: "result-wrap",
            children: a(he, {
                children: u(pe.div, {
                    className: P("animated-div", l && "tie"),
                    children: [a("div", {
                        className: "bg"
                    }), a("div", {
                        className: "bgc"
                    }), u("div", {
                        className: "odds-coin",
                        children: [u("p", {
                            className: "o",
                            children: [Ee(s), "\xD7"]
                        }), a("div", {
                            className: "c-w",
                            children: a(Ke, {
                                name: t.resultInfo.currencyName,
                                amount: e.toDP(n),
                                icon: !0
                            })
                        })]
                    })]
                })
            })
        })
    }),
    $t = "gf72cqk";
const Ve = w(function() {
    const s = R(),
        e = U.getPrecision(s.currencyName),
        n = s.currencyName === "JB" ? 0 : e;
    return a(qe, {
        label: "Total Bet",
        size: "small",
        currencyName: s.currencyName,
        value: s.amount.toNumber(),
        onChange: () => {},
        formatter: l => new A(l).toFixed(n, A.ROUND_DOWN),
        className: "total-bet-input",
        readOnly: !0,
        children: u("div", {
            className: P(zt, "change-action-min-max"),
            children: [a(j, {
                className: "min",
                disabled: !s.canPlay,
                onClick: () => {
                    s.halfAction()
                },
                children: a("span", {
                    children: "/2"
                })
            }), a(j, {
                className: "max",
                disabled: !s.canPlay,
                onClick: () => {
                    s.doubleAction()
                },
                children: a("span", {
                    children: "x2"
                })
            })]
        })
    })
});
fe({
    cl1: ["#31343c", M("#dadde6", .4)],
    cl2: ["#99a4b0", M("#5f6975", .8)],
    cl3: ["#3c404a", M("#dadde6", .2)]
});
const zt = "m1b4w3o2",
    Ge = w(() => {
        const t = R();
        return a(z.ChipInput, {
            value: t.chip,
            chips: t.chips,
            onChange: s => t.chip = s
        })
    });
var jt = w(function() {
    const s = R(),
        e = s.autoBet,
        n = $(),
        l = s.amount.lte(0) || s.guessList.length <= 0,
        i = () => a(j, {
            className: "bet-button",
            size: "big",
            type: "conic",
            disabled: l,
            onClick: () => {
                e.isRunning ? e.stop() : s.isAnimEnd && (s.showResult = !1, e.start().catch(ee))
            },
            children: s.autoBet.isRunning ? n("common.stop_auto_bet") : n("common.start_auto_bet")
        });
    return u("div", {
        className: Wt,
        children: [k.isMobile && i(), a(Ge, {}), a(Ve, {}), a(z.TimesInput, {}), a(z.IncreaseInput, {}), a(z.StopInput, {}), a(z.IncreaseInput, {
            isLose: !0
        }), a(z.StopInput, {
            isLose: !0
        }), a(Ue, {}), !k.isMobile && i()]
    })
});
const Wt = "a1lkmi7y";
const we = {
        from: {
            y: -10,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1
        }
    },
    Yt = w(function({
        label: s,
        className: e = "",
        top: n = !1
    }) {
        const l = R(),
            i = $(),
            o = Je(),
            [c, r] = N.exports.useState(!1),
            m = N.exports.useRef(null),
            d = Xe(() => r(!1)),
            b = l.getLastGuessList().guessList;
        return u("div", {
            ref: d,
            className: P(Ut, "detail-select", e, c && "is-open"),
            children: [u("div", {
                className: "detail-trigger",
                onClick: () => r(!c),
                children: [a("p", {
                    children: s
                }), a("div", {
                    className: "arrow " + (n ? "top" : ""),
                    children: a(re, {
                        name: "Arrow"
                    })
                })]
            }), a(he, {
                from: we.from,
                enter: we.enter,
                children: c && a(pe.div, {
                    className: "detail-options-wrap",
                    style: n ? Kt : qt,
                    children: a(xe, {
                        ref: m,
                        bodyLock: o,
                        className: "detail-options",
                        children: b.length > 0 ? b.map((p, h) => {
                            const g = p.amount.div(l.chip.unit).floor().toNumber();
                            return u("div", {
                                className: "detail-options-item",
                                children: [a("p", {
                                    className: "options-label",
                                    children: f[p.guess]
                                }), u("div", {
                                    className: "options-coin",
                                    children: [a("p", {
                                        children: g
                                    }), a(me, {
                                        chip: p.maxChip,
                                        showNum: !1
                                    })]
                                })]
                            }, "item-" + h)
                        }) : a("div", {
                            className: "none-t",
                            children: i("page.inviteBonus.table.none")
                        })
                    })
                })
            })]
        })
    }),
    Kt = {
        bottom: "100%"
    },
    qt = {
        top: "100%"
    };
fe({
    cl1: ["#222328", "#f5f6fa"],
    cl2: [M("#2D3035", .4), "#f5f6fa"],
    cl3: [M("#99a4b0", .6), M("#5f6975", .8)]
});
const Ut = "b1m0taef";
const Jt = w(function() {
        const s = $();
        return u("div", {
            className: Xt,
            children: [k.isMobile && a(Le, {}), a(Ge, {}), a(Ve, {}), a(Yt, {
                label: s("game.bettinginfo")
            }), !k.isMobile && a(Le, {})]
        })
    }),
    Le = w(function() {
        const s = R(),
            e = $(),
            n = s.isBetting || s.amount.lte(0) || s.guessList.length <= 0;
        return a(j, {
            className: "bet-button",
            type: "conic",
            disabled: n,
            size: "big",
            onClick: () => s.handGameBet(),
            children: e("common.playnow")
        })
    }),
    Xt = "m1y0082r",
    Zt = _.memo(() => {
        const t = R(),
            s = $(),
            e = [{
                title: s("common.game_intro"),
                node: a(bt, {
                    game: t
                })
            }, {
                title: s("common.fairness"),
                node: "/baccarats_help/fairness"
            }, {
                title: "Max Profits",
                node: a(gt, {
                    game: t
                })
            }];
        return a(Ze, {
            manualControl: a(Jt, {}),
            autoControl: a(jt, {}),
            gameView: a(Ot, {}),
            tabs: [{
                label: s("common.all_bet"),
                value: ue.AllBet
            }, {
                label: s("common.my_bet"),
                value: ue.MyBet
            }],
            actions: [a(Qe, {}), a(et, {}), a(tt, {}), a(st, {}), a(nt, {}), a(at, {
                list: e
            })]
        })
    }),
    W = J.Reader,
    ge = J.Writer,
    se = J.util,
    G = J.roots.gameBaccaratSingle || (J.roots.gameBaccaratSingle = {});
G.GameValue = (() => {
    function t(s) {
        if (this.playerCards = [], this.bankerCards = [], this.winTypes = [], s)
            for (let e = Object.keys(s), n = 0; n < e.length; ++n) s[e[n]] != null && (this[e[n]] = s[e[n]])
    }
    return t.prototype.playerCards = se.emptyArray, t.prototype.bankerCards = se.emptyArray, t.prototype.playerPoint = 0, t.prototype.bankerPoint = 0, t.prototype.odds = 0, t.prototype.winTypes = se.emptyArray, t.prototype.cardResult = 0, t.prototype.winAmount = "", t.encode = function(e, n) {
        if (n || (n = ge.create()), e.playerCards != null && e.playerCards.length) {
            n.uint32(10).fork();
            for (let l = 0; l < e.playerCards.length; ++l) n.sint32(e.playerCards[l]);
            n.ldelim()
        }
        if (e.bankerCards != null && e.bankerCards.length) {
            n.uint32(18).fork();
            for (let l = 0; l < e.bankerCards.length; ++l) n.sint32(e.bankerCards[l]);
            n.ldelim()
        }
        if (e.playerPoint != null && Object.hasOwnProperty.call(e, "playerPoint") && n.uint32(24).sint32(e.playerPoint), e.bankerPoint != null && Object.hasOwnProperty.call(e, "bankerPoint") && n.uint32(32).sint32(e.bankerPoint), e.odds != null && Object.hasOwnProperty.call(e, "odds") && n.uint32(41).double(e.odds), e.winTypes != null && e.winTypes.length) {
            n.uint32(50).fork();
            for (let l = 0; l < e.winTypes.length; ++l) n.sint32(e.winTypes[l]);
            n.ldelim()
        }
        return e.cardResult != null && Object.hasOwnProperty.call(e, "cardResult") && n.uint32(56).sint32(e.cardResult), e.winAmount != null && Object.hasOwnProperty.call(e, "winAmount") && n.uint32(66).string(e.winAmount), n
    }, t.decode = function(e, n) {
        e instanceof W || (e = W.create(e));
        let l = n === void 0 ? e.len : e.pos + n,
            i = new G.GameValue;
        for (; e.pos < l;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    if (i.playerCards && i.playerCards.length || (i.playerCards = []), (o & 7) === 2) {
                        let c = e.uint32() + e.pos;
                        for (; e.pos < c;) i.playerCards.push(e.sint32())
                    } else i.playerCards.push(e.sint32());
                    break;
                case 2:
                    if (i.bankerCards && i.bankerCards.length || (i.bankerCards = []), (o & 7) === 2) {
                        let c = e.uint32() + e.pos;
                        for (; e.pos < c;) i.bankerCards.push(e.sint32())
                    } else i.bankerCards.push(e.sint32());
                    break;
                case 3:
                    i.playerPoint = e.sint32();
                    break;
                case 4:
                    i.bankerPoint = e.sint32();
                    break;
                case 5:
                    i.odds = e.double();
                    break;
                case 6:
                    if (i.winTypes && i.winTypes.length || (i.winTypes = []), (o & 7) === 2) {
                        let c = e.uint32() + e.pos;
                        for (; e.pos < c;) i.winTypes.push(e.sint32())
                    } else i.winTypes.push(e.sint32());
                    break;
                case 7:
                    i.cardResult = e.sint32();
                    break;
                case 8:
                    i.winAmount = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return i
    }, t
})();
G.BetValue = (() => {
    function t(s) {
        if (this.bets = [], s)
            for (let e = Object.keys(s), n = 0; n < e.length; ++n) s[e[n]] != null && (this[e[n]] = s[e[n]])
    }
    return t.prototype.bets = se.emptyArray, t.encode = function(e, n) {
        if (n || (n = ge.create()), e.bets != null && e.bets.length)
            for (let l = 0; l < e.bets.length; ++l) G.BetData.encode(e.bets[l], n.uint32(10).fork()).ldelim();
        return n
    }, t.decode = function(e, n) {
        e instanceof W || (e = W.create(e));
        let l = n === void 0 ? e.len : e.pos + n,
            i = new G.BetValue;
        for (; e.pos < l;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    i.bets && i.bets.length || (i.bets = []), i.bets.push(G.BetData.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return i
    }, t
})();
G.BetData = (() => {
    function t(s) {
        if (s)
            for (let e = Object.keys(s), n = 0; n < e.length; ++n) s[e[n]] != null && (this[e[n]] = s[e[n]])
    }
    return t.prototype.type = 0, t.prototype.betAmount = "", t.encode = function(e, n) {
        return n || (n = ge.create()), e.type != null && Object.hasOwnProperty.call(e, "type") && n.uint32(8).sint32(e.type), e.betAmount != null && Object.hasOwnProperty.call(e, "betAmount") && n.uint32(18).string(e.betAmount), n
    }, t.decode = function(e, n) {
        e instanceof W || (e = W.create(e));
        let l = n === void 0 ? e.len : e.pos + n,
            i = new G.BetData;
        for (; e.pos < l;) {
            let o = e.uint32();
            switch (o >>> 3) {
                case 1:
                    i.type = e.sint32();
                    break;
                case 2:
                    i.betAmount = e.string();
                    break;
                default:
                    e.skipType(o & 7);
                    break
            }
        }
        return i
    }, t
})();
var Qt = "/assets/chip_click.1b74d725.mp3",
    es = "/assets/chip_change.af52ffb4.mp3",
    ts = "/assets/newtable.ab8443c5.mp3",
    ss = "/assets/poker.061a7615.mp3",
    ns = "/assets/tie.2dcf96f4.mp3",
    as = "/assets/lose.f61ace17.mp3";
const is = Pe.encode(G.BetValue),
    ls = Pe.decode(G.GameValue),
    H = new A(0);
class os extends lt {
    constructor() {
        super({
            name: "BaccaratSingle",
            namespace: "/g/baccarat-single",
            fairLink: "/baccarats_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/baccarat-single.html",
            sounds: {
                chipBetSound: Qt,
                handBetSound: es,
                pokerSound: ss,
                newtableSound: ts,
                tieSound: ns,
                loseSound: as
            }
        }, Zt);
        v(this, "lastGameValue", null);
        v(this, "chip", new te(new A(1), new A(8)));
        v(this, "chips", []);
        v(this, "guessList", []);
        v(this, "playerPromise", Ae);
        v(this, "bankerPromise", Ae);
        v(this, "backCardFlag", !1);
        v(this, "showResult", !1);
        v(this, "isAnimEnd", !0);
        v(this, "resultInfo", {
            currencyName: this.currencyName,
            amount: this.amount
        });
        v(this, "lastCurrencyInfo", {
            currencyName: "",
            minAmount: H,
            maxAmount: H
        });
        v(this, "handGameBet", async () => {
            this.isBetting || (this.sounds.playSound("handBetSound"), this.showResult = !1, this.lastGameValue && !this.settings.fastEnable && (this.backCardFlag = !0, await Q(500), this.backCardFlag = !1), this.handleBet().catch(ee))
        });
        v(this, "onBetRequest", async e => {
            let n = await e;
            return this.isAnimEnd = !1, this.lastGameValue = S({}, n.gameValue), await Promise.all([new Promise((l, i) => {
                this.playerPromise = {
                    resolve: () => l(!0),
                    reject: () => i(!1)
                }
            }), new Promise((l, i) => {
                this.bankerPromise = {
                    resolve: () => l(!0),
                    reject: () => i(!1)
                }
            })]), this.isAnimEnd = !0, this.showResult = !0, this.autoBet.isRunning && (n.odds >= 1 ? await Q(1e3) : await Q(400), this.settings.fastEnable || (this.backCardFlag = !0, this.showResult = !1, await Q(500), this.autoBet.isRunning || (this.lastGameValue = null), this.backCardFlag = !1)), n
        });
        ot(this, {
            lastGameValue: O.ref,
            guessList: O.ref,
            chips: O,
            chip: O,
            backCardFlag: O,
            isAnimEnd: O,
            showResult: O
        }), ct(() => {
            const {
                currencyName: i,
                minAmount: o
            } = this.lastCurrencyInfo;
            if (i != this.currencyName || !o.eq(this.minAmount)) {
                const c = this.minAmount.eq(0) ? new A(.01) : this.minAmount,
                    r = this.maxAmount.eq(0) ? new A(1e6) : this.maxAmount;
                let m = new A(1).div(10 ** U.dict[this.currencyName].precision);
                this.currencyName === "JB" && (m = new A(1));
                const d = te.chipList(c, r, m);
                d.length > 0 && (this.chip = this.getDefaultChip(d)), this.chips = [...d], this.lastCurrencyInfo = {
                    currencyName: this.currencyName,
                    minAmount: c,
                    maxAmount: r
                }
            }
        }), Ce(() => this.currencyName, () => {
            this.resetBetAmount()
        }), Ce(() => this.amount, () => {
            this.updateGuesAmount(this.amount)
        }), this.addHotkey("q", () => this.undoAction(), "Undo"), this.addHotkey("w", () => this.clearBetList(), "Clear"), this.addHotkey("e", () => this.randomAction(), "Random");
        const e = this.hotkeyList.find(i => i.key == "a");
        e && (e.handler = () => {
            this.halfAction()
        });
        const n = this.hotkeyList.find(i => i.key == "s");
        n && (n.handler = () => {
            this.doubleAction()
        });
        const l = this.hotkeyList.find(i => i.key == "space");
        l && (l.handler = () => {
            if (this.amount.gt(0) && this.guessList.length > 0)
                if (this.controlIdx === 1) {
                    if (this.autoBet.isRunning) this.autoBet.stop();
                    else if (this.isAnimEnd) {
                        if (this.amount.lt(this.minAmount)) return ee("Bet Amount Invalid. Minimum amount " + this.minAmount.toNumber() + "."), !1;
                        this.showResult = !1, this.autoBet.start().catch(i => {
                            ee(i), this.guessList = [], this.amount = new A(0)
                        })
                    }
                } else this.handGameBet();
            return !1
        })
    }
    get canPlay() {
        return !(this.isBetting || this.guessList.length <= 0 || this.amount.lte(0))
    }
    getChipsByAmount(e, n) {
        let l = [];
        const i = e.div(n.value).floor().toNumber();
        let o = e.sub(n.value.mul(i)),
            c = S({}, n);
        for (l.push({
                chip: n,
                chipNum: i
            }); o.gt(0) && c.amount.gte(1);) {
            const r = new te(c.amount.div(10), c.unit),
                m = o.div(r.value).floor().toNumber();
            m > 0 && (l.push({
                chip: r,
                chipNum: m
            }), o = o.sub(r.value.mul(m))), c = S({}, r)
        }
        return l
    }
    updateGuesAmount(e) {
        if (this.guessList.length === 0 || e.lte(0) || e.eq(this.guessList.slice(-1)[0].guessAmount)) return;
        const l = U.dict[this.currencyName].precision,
            i = oe.exports.cloneDeep(this.guessList.slice(-1)[0]),
            o = [];
        i.guessList.forEach((r, m) => {
            if (m === i.guessList.length - 1) {
                const d = o.reduce((h, g) => h.add(g.amount), H),
                    p = this.amount.sub(d).toDP(l);
                o.push(le(S({}, r), {
                    amount: p
                }))
            } else {
                const b = this.amount.mul(r.percent).toDP(l);
                o.push(le(S({}, r), {
                    amount: b
                }))
            }
        });
        const c = this.groupbyGuessList(o);
        this.addMaxLengthChips({
            guessList: o,
            guessChipList: c,
            guessAmount: e
        }, !1)
    }
    addMaxLengthChips(e, n = !0) {
        this.guessList.length >= 100 && this.guessList.slice(1, 1), this.guessList.push(S({}, e)), n && (this.amount = e.guessAmount)
    }
    halfAction() {
        if (this.amount.lte(0) || this.isBetting) return;
        this.amount.div(2).gte(this.minAmount) && (this.amount = this.amount.div(2))
    }
    doubleAction() {
        if (this.amount.lte(0) || this.isBetting) return;
        this.amount.mul(2).lte(this.maxAmount) && (this.amount = this.amount.mul(2))
    }
    undoAction() {
        this.amount.lte(0) || this.isBetting || (this.guessList.pop(), this.amount = this.guessList.length > 0 ? this.guessList.slice(-1)[0].guessAmount : H)
    }
    clearBetList() {
        this.isBetting || (this.amount = H, this.guessList = [])
    }
    randomAction() {
        if (this.isBetting) return;
        const e = Math.floor(Math.random() * 5);
        this.addChips(e, this.chip, 1)
    }
    getLastGuessList() {
        const e = this.guessList.length;
        return e === 0 ? {
            guessList: [],
            guessChipList: [],
            guessAmount: H
        } : this.guessList[e - 1]
    }
    addChips(e, n, l) {
        if (this.isBetting || !F.login) return;
        const i = oe.exports.cloneDeep(this.getLastGuessList()),
            o = n.value.mul(l),
            c = {
                guess: e,
                maxChip: n,
                percent: new A(1),
                amount: o
            },
            r = {};
        if (r[e] = [{
                chip: n,
                chipNum: l
            }], i.guessList.length === 0) this.addMaxLengthChips({
            guessList: [c],
            guessChipList: r,
            guessAmount: o
        });
        else {
            const m = this.amount.add(o);
            let d = [...i.guessList];
            const b = S({}, i.guessChipList),
                p = d.findIndex(h => h.guess === e);
            p >= 0 ? (d[p].amount = d[p].amount.add(o), n.amount.gt(d[p].maxChip.amount) && (d[p].maxChip = S({}, n))) : d = i.guessList.concat(c);
            for (let h = 0; h < d.length; h++) d[h].percent = d[h].amount.div(m);
            b[e] ? b[e] = b[e].concat({
                chip: n,
                chipNum: l
            }) : b[e] = [{
                chip: n,
                chipNum: l
            }], this.addMaxLengthChips({
                guessList: d,
                guessChipList: b,
                guessAmount: m
            })
        }
        this.sounds.playSound("chipBetSound")
    }
    groupbyGuessList(e) {
        const n = oe.exports.cloneDeep(e),
            l = {};
        if (n.length > 0)
            for (let i = 0; i < n.length; i++) {
                const o = n[i];
                l[o.guess] = this.getChipsByAmount(o.amount, o.maxChip)
            }
        return l
    }
    resetBetAmount() {
        this.amount = H, this.guessList = [], this.lastGameValue = null, this.isAnimEnd = !0
    }
    getDefaultChip(e) {
        return e.length < 3 ? e[0] : e[2]
    }
    betValue() {
        this.resultInfo = {
            currencyName: this.currencyName,
            amount: this.amount
        };
        const e = this.getLastGuessList();
        return is({
            bets: this.getBetAmount(e)
        })
    }
    getBetAmount(e) {
        return e.guessList.map(n => ({
            type: n.guess,
            betAmount: n.amount.toNumber().toString()
        }))
    }
    gameValueDecoder(e) {
        return ls(e)
    }
}

function R() {
    return it()
}
const Te = new os;
var Ls = Te;
window.baccaratGame = Te;

function Bs({
    bodyLock: t
}) {
    const s = $();
    return a(Re, {
        title: s("common.fairness"),
        children: a(Be, {
            bodyLock: t,
            children: u("div", {
                className: "item",
                children: [a("h2", {
                    children: "How are results calculated?"
                }), u("div", {
                    className: "help-content",
                    children: [a("p", {
                        children: "To get the results."
                    }), a("ul", {
                        children: a("li", {
                            children: "We calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                        })
                    })]
                })]
            })
        })
    })
}
const cs = (t, s, e) => {
        ut(`/baccarats_help/validate/${t}/${s}/${e}`)
    },
    rs = ue.withSingleDetail({
        onValidate: cs,
        result: ({
            betLog: t
        }) => {
            const s = $(),
                e = t.gv || {},
                n = t.bv.betData || [],
                l = t.currencyName || "BTC";
            let i = U.dict[l].precision || 8;
            l === "JB" && (i = 0);
            const o = e.playerPoint || 0,
                c = e.bankerPoint || 0,
                r = o == c,
                m = o > c,
                d = r ? "tie" : m ? "win" : "",
                b = r ? "tie" : m ? "" : "win",
                p = e.bankers || [],
                h = e.players || [],
                g = us(n, i);
            return u(rt, {
                className: ds,
                children: [a("p", {
                    className: "result-title",
                    children: s("common.result")
                }), u("div", {
                    className: "result-card-wrap",
                    children: [u("div", {
                        className: "cards-item left",
                        children: [u("div", {
                            className: "cards-title",
                            children: [a("p", {
                                className: "t",
                                children: "PLAYER"
                            }), a("div", {
                                className: P("rw", d),
                                children: a("span", {
                                    children: o
                                })
                            })]
                        }), a("div", {
                            className: "cards-list",
                            children: h.map((C, y) => {
                                const L = new E(C),
                                    B = "bd-card-item" + (y + 1);
                                return a(X, {
                                    className: P(B, r ? "tie" : m ? "win" : ""),
                                    active: !0,
                                    card: L
                                }, C + "-" + y)
                            })
                        })]
                    }), u("div", {
                        className: "cards-item left",
                        children: [u("div", {
                            className: "cards-title",
                            children: [a("p", {
                                className: "t",
                                children: "BANKER"
                            }), a("div", {
                                className: P("rw", b),
                                children: a("span", {
                                    children: c
                                })
                            })]
                        }), a("div", {
                            className: "cards-list",
                            children: p.map((C, y) => {
                                const L = "bd-card-item" + (y + 1),
                                    B = r ? "tie" : m ? "" : "win",
                                    T = new E(C);
                                return a(X, {
                                    className: P(L, B),
                                    active: !0,
                                    card: T
                                }, C + "-" + y)
                            })
                        })]
                    })]
                }), u("div", {
                    className: "svg-area",
                    children: [u("svg", {
                        viewBox: "0 0 388 129",
                        children: [a("path", {
                            className: "st0",
                            d: "M5.6,0C2.5,0,0,2.5,0,5.6v54h194V0H5.6z"
                        }), a("path", {
                            className: "st0",
                            d: "M388,5.6c0-3.1-2.5-5.6-5.6-5.6H194v59.6h194V5.6z"
                        }), a("path", {
                            className: "st0",
                            d: "M0,59.6v29.6c0,2.3,1.4,4.4,3.6,5.2c41,15.4,82.9,25.6,125.7,30.7V59.6H0z"
                        }), a("path", {
                            className: "st0",
                            d: "M129.4,59.6v65.5c21.4,2.6,43,3.8,64.9,3.8c21.6,0,43-1.3,64-3.7V59.6H129.4z"
                        }), a("path", {
                            className: "st0",
                            d: "M258.3,59.6v65.6c43.1-5.1,85.1-15.4,126-30.8c2.2-0.8,3.6-2.9,3.6-5.2V59.6H258.3z"
                        }), a("line", {
                            id: "Line-Copy-3",
                            className: "st1",
                            x1: "193.5",
                            y1: "0.2",
                            x2: "193.5",
                            y2: "59.4"
                        }), a("line", {
                            id: "Line-Copy-4",
                            className: "st1",
                            x1: "257.8",
                            y1: "59.8",
                            x2: "257.8",
                            y2: "123.8"
                        }), a("line", {
                            id: "Line-Copy-5",
                            className: "st1",
                            x1: "128.8",
                            y1: "59.8",
                            x2: "128.8",
                            y2: "123.8"
                        }), a("line", {
                            id: "Line-Copy-2",
                            className: "st1",
                            x1: "0.8",
                            y1: "59.4",
                            x2: "387.8",
                            y2: "59.4"
                        })]
                    }), a(V, {
                        haveAnim: !1,
                        title: "TIE",
                        odds: I[f.TIE],
                        className: "type-t",
                        chipList: g[f.TIE] || []
                    }), a(V, {
                        haveAnim: !1,
                        title: "P PAIR",
                        odds: I[f.PPAIR],
                        className: "type-pp",
                        chipList: g[f.PPAIR] || []
                    }), a(V, {
                        haveAnim: !1,
                        title: "B PAIR",
                        odds: I[f.BPAIR],
                        className: "type-bp",
                        chipList: g[f.BPAIR] || []
                    }), a(V, {
                        haveAnim: !1,
                        title: "PLAYER",
                        odds: I[f.PLAYER],
                        className: "type-p",
                        chipList: g[f.PLAYER] || []
                    }), a(V, {
                        haveAnim: !1,
                        title: "BANKER",
                        odds: I[f.BANKER],
                        className: "type-b",
                        chipList: g[f.BANKER] || []
                    })]
                })]
            })
        }
    });

function us(t, s) {
    const e = new A(1).div(10 ** s);
    let n = {};
    for (let l = 0; l < t.length; l++) {
        let i = [];
        const o = new A(t[l].betAmount).div(e).round().toNumber(),
            c = String(o).split(""),
            r = c.length - 1;
        c.map((m, d) => {
            Number(m) > 0 && i.push({
                chip: new te(new A(10).pow(r - d), e),
                chipNum: Number(m)
            })
        }), n[t[l].type] = [...i]
    }
    return n
}
const ds = "du2tkr2";
var xs = rs;
const ms = "https://bcgame-project.github.io/verify/baccaratsingle.html",
    hs = () => {
        const t = dt(),
            s = mt(t),
            e = ft(() => ({
                serverSeed: s[0] || "",
                clientSeed: s[1] || "",
                nonce: parseInt(s[2]) || 0
            })),
            {
                serverSeed: n,
                clientSeed: l,
                nonce: i
            } = e,
            o = String(be(n)),
            r = String(ht([l, i].join(":"), n)),
            m = bs(r),
            d = [new E(m[0]), new E(m[2])],
            b = [new E(m[1]), new E(m[3])],
            p = K(d),
            h = K(b),
            g = p % 10 < 6,
            C = h % 10 >= 8;
        g && !C && d.push(new E(m[4]));
        const y = d[2] ? K([d[2]]) % 10 : -1;
        fs(h % 10, p, y) && b.push(g ? new E(m[5]) : new E(m[4]));
        const B = K(d),
            T = K(b);
        return a(Re, {
            title: pt.t("common.fairness"),
            children: u(xe, {
                className: ys,
                children: [a("h2", {
                    children: "Input"
                }), a(Y, {
                    label: "Server Seed",
                    value: n,
                    onChange: x => e.serverSeed = x
                }), a(Y, {
                    label: "Client Seed",
                    value: l,
                    onChange: x => e.clientSeed = x
                }), a(Y, {
                    label: "Nonce",
                    value: i,
                    onChange: x => e.nonce = Number(x)
                }), a("h2", {
                    children: "Output"
                }), a(Y, {
                    label: "Sha256(server_seed)",
                    value: o,
                    readOnly: !0
                }), a(Y, {
                    label: "Hmac_sha256(client_seed:nonce, server_seed)",
                    value: r,
                    readOnly: !0
                }), a("h2", {
                    children: "Final Result"
                }), u("div", {
                    className: "result-list",
                    children: [u("div", {
                        className: "player-cards",
                        children: [u("p", {
                            children: ["Player: ", B % 10]
                        }), a("div", {
                            className: "cards-list",
                            children: d.map((x, D) => {
                                const ae = "result-card-item" + (D + 1);
                                return a(X, {
                                    className: ae,
                                    active: !0,
                                    card: x
                                }, x.cardId + "-" + D)
                            })
                        })]
                    }), u("div", {
                        className: "banker-cards",
                        children: [u("p", {
                            children: ["Banker: ", T % 10]
                        }), a("div", {
                            className: "cards-list",
                            children: b.map((x, D) => {
                                const ae = "result-card-item" + (D + 1);
                                return a(X, {
                                    className: ae,
                                    active: !0,
                                    card: x
                                }, x.cardId + "-" + D)
                            })
                        })]
                    })]
                }), a("p", {
                    className: "githubverify",
                    children: a("a", {
                        href: `${ms}?s=${e.serverSeed}&c=${e.clientSeed}&n=${e.nonce}`,
                        target: "_blank",
                        children: "Verify on Github"
                    })
                })]
            })
        })
    };
var Ps = hs;
const ps = [161, 180, 199, 218, 162, 205, 181, 200, 219, 163, 182, 220, 201, 177, 196, 215, 170, 178, 221, 197, 216, 171, 179, 198, 172, 217, 193, 212, 167, 186, 194, 173, 213, 168, 187, 195, 214, 188, 169, 209, 164, 183, 202, 210, 189, 165, 184, 203, 211, 166, 204, 185];

function fs(t, s, e) {
    return s >= 8 ? !1 : t <= 2 ? !0 : t === 3 ? e != 8 : t === 4 ? [0, 1, 8, 9].indexOf(e) < 0 : t === 5 ? [0, 1, 2, 3, 8, 9].indexOf(e) < 0 : t === 6 ? [6, 7].indexOf(e) >= 0 : !1
}

function K(t) {
    return t.reduce((e, n) => {
        const l = n.point > 10 ? 10 : n.point;
        return e + l
    }, 0) % 10
}

function bs(t) {
    let s = String(be(t));
    return gs(s, 2).map(n => n.card)
}

function Me(t, s, e, n) {
    if (n.push(t), s <= 0) return;
    let l = t;
    ps.forEach(i => {
        e.push({
            card: i,
            hash: l
        }), l = l.substring(1) + l.charAt(0)
    }), t = String(be(t)), s--, Me(t, s, e, n)
}

function gs(t, s) {
    s = s || 2;
    let e = [];
    return Me(t, s, e, []), e.sort(function(l, i) {
        return l.hash < i.hash ? -1 : l.hash == i.hash ? 0 : 1
    }), e
}
fe({
    cl1: [M("#99a4b0", .8), M("#5f6975", .8)],
    cl2: ["#31343c", "#f6f6f9"]
});
const ys = "f2kcuzz";
export {
    xs as Detail, Bs as Fairness, Ls as Game, Ps as Validate
};
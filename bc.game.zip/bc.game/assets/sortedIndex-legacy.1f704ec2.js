System.register(["./index-legacy.1416f96c.js"], (function(n) {
    "use strict";
    var e, r, t;
    return {
        setters: [function(n) {
            e = n.ch, r = n.ci, t = n.bE
        }],
        execute: function() {
            n("s", (function(n, c) {
                return function(n, c, i) {
                    var f = 0,
                        s = null == n ? f : n.length;
                    if ("number" == typeof c && c == c && s <= u) {
                        for (; f < s;) {
                            var o = f + s >>> 1,
                                l = n[o];
                            null !== l && !e(l) && (i ? l <= c : l < c) ? f = o + 1 : s = o
                        }
                        return s
                    }
                    return r(n, c, t, i)
                }(n, c)
            }));
            var u = 2147483647
        }
    }
}));
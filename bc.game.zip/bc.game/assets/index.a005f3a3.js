var ee = Object.defineProperty;
var te = (o, n, e) => n in o ? ee(o, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : o[n] = e;
var c = (o, n, e) => (te(o, typeof n != "symbol" ? n + "" : n, e), e);
import {
    a as t,
    dx as F,
    j as r,
    dy as ne,
    dz as oe,
    s as y,
    o as h,
    g as E,
    h as W,
    ao as ae,
    r as v,
    F as O,
    l as k,
    k as S,
    M as D,
    t as T,
    q as R,
    du as d,
    aV as se,
    f6 as ie,
    dk as re,
    dl as le,
    di as ce,
    y as w,
    u as N,
    A as ue,
    f7 as he,
    z as me,
    J as _,
    an as de,
    d as pe,
    b as q,
    G as z,
    e9 as fe,
    a5 as ye,
    dG as be,
    e2 as ge,
    e1 as ve,
    dY as ke,
    eb as we,
    dC as Ne,
    dD as Ce,
    dZ as Ie,
    dE as Be,
    dp as A,
    bN as Y,
    d_ as Re,
    dR as Ae,
    ba as xe,
    bc as Ge,
    bb as P,
    dr as Pe,
    e6 as Se,
    bs as _e
} from "./index.28e31dff.js";
import {
    G as f
} from "./index.06a59a68.js";
const Le = function() {
        return t(F, {
            children: r("div", {
                className: "item",
                children: [t("h2", {
                    children: " What Is Ring of Fortune? "
                }), t("div", {
                    className: "help-content",
                    children: t("p", {
                        children: "Ring of Fortune is a wheel based 'roulette style' game. When Coco takes a break from his work at the shitcode factory, he can often be found in a trance, watching the colorful wheel spinning around and around, hoping it lands in the lucky green area!."
                    })
                }), t("h2", {
                    children: "How to play Ring of Fortune? "
                }), r("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "1. Place your bets on one or more colors and then press Bet button."
                    }), t("p", {
                        children: "2. The wheel then starts spinning. "
                    }), t("p", {
                        children: "3. If the wheel stops at the color/s that you placed a bet, you win!"
                    })]
                }), t("h2", {
                    children: "What is the House Edge of Ring of Fortune? "
                }), t("div", {
                    className: "help-content",
                    children: "1% HouseEdge."
                }), t("h2", {
                    children: "Auto Mode Operation Instructions"
                }), r("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "[ ON WIN ] when you win, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                    }), r("p", {
                        children: ["[ ON LOSE ] when you lose, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'.", " "]
                    }), t("p", {
                        children: "[ STOP ON WIN ] Once the amount winned (from start to this bet) is bigger/equal than _(your set)_ , auto will stop;"
                    }), t("p", {
                        children: "[ STOP ON LOSS ] Once the amount lost (from start to next bet) may be bigger/equal than _(your set)_ , auto will stop."
                    })]
                })]
            })
        })
    },
    Oe = function({
        game: n
    }) {
        return t(ne, {
            game: n,
            children: r("div", {
                className: "item",
                children: [t("h2", {
                    children: "What is the bankroll?"
                }), r("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                    }), t("p", {
                        children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                    }), t("p", {
                        children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                    }), t("p", {
                        onClick: () => oe(n, 1),
                        className: "cl-primary pointer",
                        children: "Read more about bankrollers."
                    })]
                }), t("h2", {
                    children: "How does the pool of funds operate? "
                }), r("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                    }), r("p", {
                        children: [t("b", {
                            className: "cl-primary",
                            children: "The house edge is 1%."
                        }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                    }), t("p", {
                        children: "Payouts made to the winning players will be deducted from the bankroll."
                    })]
                }), t("h2", {
                    children: "How does leverage investment work?"
                }), r("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                    }), t("p", {
                        children: "Hint: You can also use this feature as an Off-Site investment."
                    }), t("p", {
                        children: "Let's make an example:"
                    }), t("p", {
                        children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to Bc.game, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                    })]
                }), t("h2", {
                    children: "What is the bankroller dilution fee?"
                }), r("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                    }), t("p", {
                        children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                    }), t("p", {
                        children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                    }), t("p", {
                        children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                    })]
                })]
            })
        })
    };

function Te({
    bodyLock: o
}) {
    return t(F, {
        bodyLock: o,
        children: r("div", {
            className: "item",
            children: [t("h2", {
                children: "How are results calculated?"
            }), t("div", {
                className: "help-content",
                children: t("p", {
                    children: "To get the results,we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                })
            })]
        })
    })
}
var $e = "/assets/ring.c270b9dc.svg",
    He = "/assets/ring_drak.52db209e.svg",
    Ve = "/assets/green.313eff77.svg",
    je = "/assets/gray.2f22930b.svg",
    Ee = "/assets/orange.61a6641c.svg",
    Me = "/assets/purple.10a1b451.svg",
    Fe = "/assets/white.139c608c.svg",
    We = "/assets/pointer.31f035ef.svg";
const M = {
        ring_drak: He,
        ring: $e,
        pointer: We,
        item_green: Ve,
        item_gray: je,
        item_orange: Ee,
        item_purple: Me,
        item_white: Fe
    },
    De = ["#99a4b0", "#7625fe", "#ed6300", "#7bc514"],
    qe = ["#cce0f8", "#a956ff", "#ff9237", "#21fc79"],
    $ = [1, 2, 1, 2, 1, 3, 1, 3, 1, 2, 1, 2, 1, 2, 1, 3, 4, 3, 1, 2, 1, 2, 1, 2, 1, 3, 1, 3, 1, 2, 1, 2],
    L = $.length;

function ze(o, n = 10, e) {
    let a = 0;
    const s = [];
    $.forEach((p, m) => {
        e[p - 1] === o && (a++, s.push(m))
    });
    const i = Math.floor(Math.random() * a),
        l = s[i] * (360 / L);
    return n * 360 + l
}

function Ye(o) {
    const n = Math.ceil(o / (360 / L)) % L;
    return $[n] - 1
}

function Ue(o) {
    return (y.isDarken ? De : qe)[Ye(o)]
}
const Je = function({
    game: n
}) {
    const [e, a] = E(() => ({
        rotate: 0,
        immediate: !0,
        config: {
            duration: 700,
            mass: 10,
            tension: 700,
            friction: 400,
            precision: .001
        },
        reset: !0
    })), [s, i] = E(() => ({
        fill: "#D43600",
        config: W.stiff
    })), [l, g] = ae({
        winItem: !1,
        totalRotate: 0
    }), p = n.myBets.length === 0;
    return v.exports.useEffect(() => {
        a.start({
            config: {
                tension: n.settings.fastEnable ? 2500 : 500
            }
        })
    }, [n.settings.fastEnable]), v.exports.useEffect(() => {
        if (n.gameResult === 0) return;
        const m = ze(n.gameResult, 4, n.payouts);
        g({
            winItem: !1,
            totalRotate: m
        });
        const C = e.rotate.get() % 360;
        a.set({
            rotate: C
        });
        let H = 0;
        a.start({
            rotate: m,
            onChange: () => {
                const G = e.rotate.get(),
                    Q = G - 5.6,
                    V = Math.floor(Q / 11.25),
                    j = m - G;
                if (j < .4 && (g({
                        winItem: !0
                    }), j < .2 && n.Unlock && n.Unlock(!0)), V != H) {
                    const X = Ue(G);
                    i.start({
                        fill: X
                    }), n.sounds.playSound("tickSound")
                }
                H = V
            }
        })
    }, [n.gameResult]), t(O, {
        children: r("div", {
            className: k(Ze, "ring-view", p && "center"),
            children: [t(S.img, {
                style: e,
                className: "image-ring",
                src: M.ring
            }), r("div", {
                className: "amount-box",
                children: [t("div", {
                    className: "tit",
                    children: "BET TOTAL"
                }), t(D, {
                    name: n.currencyName,
                    amount: n.amount,
                    icon: !0
                })]
            }), t("div", {
                className: "image-pointer",
                children: t(S.svg, {
                    style: s,
                    viewBox: "0 0 28 38",
                    children: r("g", {
                        children: [t("path", {
                            opacity: ".8",
                            d: "M14 38V10.006L0 0z"
                        }), t("path", {
                            d: "M14 38V10.006L28 0z"
                        })]
                    })
                })
            }), t("img", {
                className: `image-result ${l.winItem?"active":""}`,
                src: M.item_white,
                alt: ""
            })]
        })
    })
};
var Ke = h(Je);
const Ze = "s4m2h1k";
const Qe = function() {
    const o = ["gray", "purple", "orange", "green"],
        n = d();
    return t("div", {
        className: Xe,
        children: t("div", {
            className: "recent-list-wrap",
            children: n.payouts.map((e, a) => r("div", {
                className: `item ${o[a]}`,
                children: [e.toFixed(2), "x"]
            }, e))
        })
    })
};
T({
    cl1: [R("#31343c", .4), "#f5f6fa"],
    cl2: ["#ffffff", "#000000"],
    cl3: ["#99a4b0", "#d2def8"]
});
const Xe = "s11d7prl";
const et = h(function() {
        const n = d(),
            e = n.myBets.slice(0, y.isMobile ? 12 : 26),
            a = se(e, {
                config: W.default,
                initial: {
                    opacity: 0,
                    x: 10,
                    height: 12
                },
                from: {
                    opacity: 0,
                    x: 20,
                    height: 0
                },
                enter: {
                    opacity: 1,
                    x: 0,
                    height: 18
                },
                leave: {
                    opacity: 0,
                    x: 20,
                    height: 0
                },
                keys: i => i.betId
            }),
            s = v.exports.useCallback(i => {
                ie({
                    betId: i.betId,
                    userName: i.nickName,
                    gameName: n.name,
                    userId: i.userId
                })
            }, []);
        return t("div", {
            className: k(tt, "ring-result"),
            children: a((i, l) => t(S.div, {
                className: nt,
                style: i,
                onClick: () => s(l),
                children: t("div", {
                    className: `${n.getPayoutColor(l.gameValue.payout)} cont`
                })
            }, l.betId))
        })
    }),
    tt = "sea11sc",
    nt = "ie3ha9u";
const ot = h(function() {
        const n = d();
        return v.exports.useEffect(() => {
            n.resetAmount()
        }, [n.currencyName]), r(O, {
            children: [t(Qe, {}), r(re, {
                className: st,
                children: [t(le, {}), t(Ke, {
                    game: n
                }), n.myBets.length > 0 && t(et, {}), t(at, {
                    game: n
                })]
            })]
        })
    }),
    at = h(function({
        game: o
    }) {
        const [n, e] = ce();
        return v.exports.useEffect(() => {
            if (o.gamePayout > 0) {
                const a = o.jackpot[o.currencyName].maxProfitAmount,
                    s = new w(o.amount).mul(o.gamePayout).toNumber(),
                    i = o.gamePayout >= o.payouts[o.payouts.length - 1];
                e({
                    profitAmount: s > a ? a : s,
                    currencyName: o.currencyName,
                    odds: o.gamePayout,
                    isBigWin: i,
                    enableSound: o.settings.soundEnable
                });
                const l = setTimeout(() => {
                    i || e(null)
                }, 3e3);
                return () => clearTimeout(l)
            } else e(null)
        }, [o.gamePayout]), n
    }),
    st = "s1t5eb29";

function it(o) {
    N();
    const n = d(),
        {
            disabled: e = n.isBetting,
            checkIncrease: a,
            onJackpotHelp: s
        } = o;
    return a && n.autoBet && n.autoBet.isAutoIncrease, t("div", {
        children: t(rt, {
            jackpot: n.jackpot[n.currencyName],
            onJackpotHelp: s
        })
    })
}
const rt = h(({
    jackpot: o,
    onJackpotHelp: n
}) => {
    const e = N();
    return r("div", {
        className: k(lt, "label"),
        children: [t("div", {
            children: e("common.amount")
        }), o && o.maxProfitAmount !== 1 / 0 && r("div", {
            className: "max-profit",
            children: [t(ue, {
                onClick: n,
                name: "Inform"
            }), r("div", {
                className: "tip",
                children: [t("span", {
                    className: "tit",
                    children: "Max Profit:\xA0"
                }), t(D, {
                    name: o.currencyName,
                    amount: o.maxProfitAmount
                })]
            })]
        })]
    })
});
T({
    cl1: [R("#99a4b0", .8), "#31343c"],
    cl2: ["#25272b", "#fff"],
    cl3: [R("#000000", .14)]
});
const lt = "s1rb13s2";
const ct = function({
    onReset: o
}) {
    return t("button", {
        className: mt,
        onClick: o,
        children: "Reset"
    })
};
var U = h(function() {
    const n = K(),
        e = he(n.amount.toNumber(), n.currencyName),
        a = r(O, {
            children: [t(me, {
                name: e.name
            }), t(it, {}), t("div", {
                className: "total-amount",
                style: {
                    marginLeft: "9px"
                },
                children: `${_.getValidAmount(e.tipsAmount,e.tipsName)} ${_.getAlias(e.tipsName)}`
            }), t(ct, {
                onReset: n.resetAmount
            })]
        });
    return t(de, {
        className: ht,
        label: a,
        disabled: n.isBetting,
        children: r("div", {
            className: "input-control",
            children: [t(I, {
                idx: 0
            }), t(I, {
                idx: 1
            }), t(I, {
                idx: 2
            }), t(I, {
                idx: 3
            })]
        })
    })
});
const ut = new w(0),
    I = h(function({
        idx: n
    }) {
        const e = K(),
            a = e.betPrecent[n],
            s = e.amounts[n],
            i = p => {
                const m = e.jackpot[e.currencyName].minBetAmount,
                    C = e.amounts.concat();
                C[n] = p.toNumber() < m && p.toNumber() > 0 ? new w(m) : p, e.amounts = C
            },
            l = e.maxAmount.sub(e.amount.mul(a.neg().add(1))),
            g = pe.settings.enableLocaleCurrency && _.isValuable(e.currencyName);
        return t(f.CoinInput, {
            label: null,
            currencyName: e.currencyName,
            className: k(`type-${n}`, g && "show-local"),
            value: s,
            max: l,
            min: ut,
            checkIncrease: !1,
            onChange: i
        })
    }),
    ht = "s11ufsdc",
    mt = "b19mi5bg";
const dt = h(function() {
        const n = d(),
            e = N(),
            a = n.jackpot[n.currencyName].minBetAmount,
            s = () => t(q, {
                className: "bet-button",
                type: "conic",
                size: "big",
                disabled: n.amount.toNumber() < a,
                onClick: () => {
                    n.autoBet.isRunning ? n.autoBet.stop() : n.autoBet.start().catch(z)
                },
                children: n.autoBet.isRunning ? e("common.stop_auto_bet") : e("common.start_auto_bet")
            });
        return r("div", {
            className: k(pt, "game-form"),
            children: [y.isMobile && s(), t(U, {}), t(f.TimesInput, {}), t(f.IncreaseInput, {}), t(f.StopInput, {}), t(f.IncreaseInput, {
                isLose: !0
            }), t(f.StopInput, {
                isLose: !0
            }), t(fe, {}), !y.isMobile && s()]
        })
    }),
    pt = "shwlw85";
const ft = h(function() {
        const n = N(),
            e = d(),
            a = e.jackpot[e.currencyName].minBetAmount,
            s = () => t(q, {
                className: "bet-button",
                type: "conic",
                size: "big",
                disabled: e.isBetting || e.amount.toNumber() < a,
                onClick: e.handGameBet,
                children: n("common.bet")
            });
        return r("div", {
            className: yt,
            children: [y.isMobile && s(), t(U, {}), !y.isMobile && s()]
        })
    }),
    yt = "sla47qo";
const bt = ye.memo(() => {
        const o = N(),
            n = d(),
            e = [{
                title: o("common.game_intro"),
                node: t(Le, {})
            }, {
                title: o("common.fairness"),
                node: t(Te, {})
            }, {
                title: o("common.bankroll"),
                node: t(Oe, {
                    game: n
                })
            }];
        return t(be, {
            className: gt,
            manualControl: t(ft, {}),
            autoControl: t(dt, {}),
            gameView: t(ot, {}),
            tabs: [{
                label: o("common.all_bet"),
                value: ge
            }, {
                label: o("common.my_bet"),
                value: ve
            }],
            actions: [t(ke, {}), t(we, {}), t(Ne, {}), t(Ce, {}), t(Ie, {}), t(Be, {
                list: e
            })]
        })
    }),
    gt = "sbsrzat",
    x = A.Reader,
    J = A.Writer,
    b = A.roots.coloring || (A.roots.coloring = {});
b.BetValue = (() => {
    function o(n) {
        if (n)
            for (let e = Object.keys(n), a = 0; a < e.length; ++a) n[e[a]] != null && (this[e[a]] = n[e[a]])
    }
    return o.prototype.p1 = "", o.prototype.p2 = "", o.prototype.p3 = "", o.prototype.p4 = "", o.encode = function(e, a) {
        return a || (a = J.create()), e.p1 != null && Object.hasOwnProperty.call(e, "p1") && a.uint32(10).string(e.p1), e.p2 != null && Object.hasOwnProperty.call(e, "p2") && a.uint32(18).string(e.p2), e.p3 != null && Object.hasOwnProperty.call(e, "p3") && a.uint32(26).string(e.p3), e.p4 != null && Object.hasOwnProperty.call(e, "p4") && a.uint32(34).string(e.p4), a
    }, o.decode = function(e, a) {
        e instanceof x || (e = x.create(e));
        let s = a === void 0 ? e.len : e.pos + a,
            i = new b.BetValue;
        for (; e.pos < s;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    i.p1 = e.string();
                    break;
                case 2:
                    i.p2 = e.string();
                    break;
                case 3:
                    i.p3 = e.string();
                    break;
                case 4:
                    i.p4 = e.string();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return i
    }, o
})();
b.GameValue = (() => {
    function o(n) {
        if (n)
            for (let e = Object.keys(n), a = 0; a < e.length; ++a) n[e[a]] != null && (this[e[a]] = n[e[a]])
    }
    return o.prototype.area = 0, o.prototype.payout = 0, o.encode = function(e, a) {
        return a || (a = J.create()), e.area != null && Object.hasOwnProperty.call(e, "area") && a.uint32(8).sint32(e.area), e.payout != null && Object.hasOwnProperty.call(e, "payout") && a.uint32(16).sint32(e.payout), a
    }, o.decode = function(e, a) {
        e instanceof x || (e = x.create(e));
        let s = a === void 0 ? e.len : e.pos + a,
            i = new b.GameValue;
        for (; e.pos < s;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    i.area = e.sint32();
                    break;
                case 2:
                    i.payout = e.sint32();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return i
    }, o
})();
var vt = "/assets/tick.a46884f7.mp3",
    kt = "/assets/lose.f61ace17.mp3";
const wt = Y.decode(b.GameValue),
    Nt = Y.encode(b.BetValue),
    Ct = {
        tickSound: vt,
        loseSound: kt
    },
    It = [2, 3, 6, 99],
    u = new w(0);
class Bt extends Re {
    constructor() {
        super({
            name: "Coloring",
            namespace: "/g/coloring",
            sounds: Ct,
            fairLink: "/colorring/fairness",
            validateLink: "https://bcgame-project.github.io/verify/ringOfFortune.html"
        }, bt);
        c(this, "betInterval", 350);
        c(this, "payouts", It);
        c(this, "betPrecent", [u, u, u, u]);
        c(this, "gamePayout", 0);
        c(this, "gameResult", 0);
        c(this, "myBetLimit", 26);
        c(this, "Unlock");
        c(this, "handGameBet", () => {
            this.isBetting || this.handleBet().catch(z)
        });
        c(this, "onBetRequest", async e => {
            let a = await e;
            this.reset();
            const s = wt(a.gameValue);
            return a.gameValue = s, await new Promise(i => {
                this.Unlock = i, this.gameResult = s.payout
            }), this.gamePayout = a.odds, this.gamePayout === 0 && this.sounds.playSound("loseSound"), a
        });
        this.resetAmount = this.resetAmount.bind(this), Ae(() => {
            this.autoBet.interval = this.settings.fastEnable ? 2e3 : 8e3
        }), xe(this, {
            amounts: Ge,
            gamePayout: P,
            gameResult: P,
            betPrecent: P,
            reset: Pe
        }), this.removeHotKey("a"), this.removeHotKey("s");
        const e = this.hotkeyList.find(a => a.key == "space");
        e && (e.handler = () => (this.amount.toNumber() === 0 || (this.controlIdx === 1 ? this.autoBet.isRunning ? this.autoBet.stop() : this.autoBet.start() : this.handGameBet()), !1))
    }
    get amounts() {
        return this.betPrecent.map(e => this.amount.mul(e))
    }
    set amounts(e) {
        this.amount = w.sum(...e), this.betPrecent = e.map(a => this.amount.toNumber() === 0 ? u : a.div(this.amount))
    }
    getPayoutColor(e) {
        const a = ["gray", "purple", "orange", "green"],
            s = this.payouts.indexOf(e);
        return s > -1 ? a[s] : a[0]
    }
    betValue() {
        return Nt({
            p1: this.amounts[0].toNumber().toString(),
            p2: this.amounts[1].toNumber().toString(),
            p3: this.amounts[2].toNumber().toString(),
            p4: this.amounts[3].toNumber().toString()
        })
    }
    resetAmount() {
        this.amount = u, this.betPrecent = [u, u, u, u]
    }
    reset() {
        this.gameResult = 0, this.gamePayout = 0
    }
    active() {
        this.reset(), super.active()
    }
    deactivate() {
        this.Unlock && this.Unlock(!0), super.deactivate()
    }
}
const K = d,
    Z = new Bt;
var B = Z;
window.lbg = Z;
const Rt = (o, n, e) => {
        let a = `${B.config.validateLink}?s=${o}&c=${n}&n=${e}`;
        window.open(a)
    },
    At = ({
        betLog: o
    }) => {
        const n = Object.values(o.bv),
            e = o.gv.payout,
            a = B.payouts;
        return r("div", {
            className: Gt,
            children: [t("div", {
                className: "rt_tit",
                children: "Initial Bet"
            }), t("div", {
                className: "pr-cont",
                children: a.map((s, i) => t("div", {
                    className: `color-item ${B.getPayoutColor(s)}`,
                    children: _e(n[i])
                }, s))
            }), t("div", {
                className: "rl_tit",
                children: "Final Result"
            }), r("div", {
                className: `res ${B.getPayoutColor(e)}`,
                children: [e.toFixed(2), " x"]
            })]
        })
    },
    xt = Se({
        onValidate: Rt,
        result: At
    });
var Lt = xt;
T({
    cl1: ["#99a4b0", "#d2def8"],
    cl2: ["#17181b", "#f5f6fa"],
    cl3: ["#fff", "#000"],
    cl4: [R("#31343c", .4), "#f5f6fa"]
});
const Gt = "sb7ar9o";
export {
    Lt as Detail, Te as Fairness, B as Game
};
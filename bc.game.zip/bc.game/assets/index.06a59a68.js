var x = Object.defineProperty,
    N = Object.defineProperties;
var b = Object.getOwnPropertyDescriptors;
var n = Object.getOwnPropertySymbols;
var d = Object.prototype.hasOwnProperty,
    l = Object.prototype.propertyIsEnumerable;
var p = (s, a, t) => a in s ? x(s, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : s[a] = t,
    o = (s, a) => {
        for (var t in a || (a = {})) d.call(a, t) && p(s, t, a[t]);
        if (n)
            for (var t of n(a)) l.call(a, t) && p(s, t, a[t]);
        return s
    },
    r = (s, a) => N(s, b(a));
var c = (s, a) => {
    var t = {};
    for (var e in s) d.call(s, e) && a.indexOf(e) < 0 && (t[e] = s[e]);
    if (s != null && n)
        for (var e of n(s)) a.indexOf(e) < 0 && l.call(s, e) && (t[e] = s[e]);
    return t
};
import {
    du as h,
    a as i,
    Y as y,
    l as G,
    dL as P,
    dM as f,
    dN as g,
    dO as j,
    dP as v,
    dQ as C
} from "./index.28e31dff.js";

function L(s) {
    const a = h(),
        u = s,
        {
            disabled: t = a.isBetting,
            size: e = "small",
            className: m
        } = u,
        I = c(u, ["disabled", "size", "className"]);
    return i(y, r(o({
        className: G(S, m),
        disabled: t,
        size: e
    }, I), {
        bold: !0,
        children: i("div", {
            className: "payout-txt",
            children: "\xD7"
        })
    }))
}
const S = "s73jled";
var D = {
    CoinInput: P,
    IncreaseInput: f,
    TimesInput: g,
    StopInput: j,
    LabelSelect: v,
    PayoutInput: L,
    ChipInput: C
};
export {
    D as G
};
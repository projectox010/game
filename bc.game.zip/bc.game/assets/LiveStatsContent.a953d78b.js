import {
    aM as $n,
    a5 as A,
    bz as r5,
    o as Mt,
    u as rr,
    r as Ct,
    j as U,
    a as D,
    cO as Ae,
    A as Dr,
    M as Bt,
    t as la,
    q as fe,
    s as Ji,
    l as a5,
    B as za,
    F as Nr,
    H as i5,
    T as o5,
    k as u5,
    e as l5,
    y as c5,
    c as We,
    z as du,
    aQ as f5,
    b as s5,
    b2 as h5,
    m as d5,
    b1 as yr,
    ag as v5
} from "./index.28e31dff.js";
import {
    c as Ue
} from "./ContestStore.ee2a7e20.js";
import {
    P as s
} from "./index.65a85ef1.js";
import {
    B as g5
} from "./Status.3214655e.js";

function y5(e) {
    return +e
}

function m5(e) {
    return e * e
}

function b5(e) {
    return e * (2 - e)
}

function vu(e) {
    return ((e *= 2) <= 1 ? e * e : --e * (2 - e) + 1) / 2
}

function p5(e) {
    return e * e * e
}

function _5(e) {
    return --e * e * e + 1
}

function gu(e) {
    return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2
}
var eo = 3,
    x5 = function e(t) {
        t = +t;

        function n(r) {
            return Math.pow(r, t)
        }
        return n.exponent = e, n
    }(eo),
    w5 = function e(t) {
        t = +t;

        function n(r) {
            return 1 - Math.pow(1 - r, t)
        }
        return n.exponent = e, n
    }(eo),
    yu = function e(t) {
        t = +t;

        function n(r) {
            return ((r *= 2) <= 1 ? Math.pow(r, t) : 2 - Math.pow(2 - r, t)) / 2
        }
        return n.exponent = e, n
    }(eo),
    F0 = Math.PI,
    W0 = F0 / 2;

function A5(e) {
    return +e == 1 ? 1 : 1 - Math.cos(e * W0)
}

function O5(e) {
    return Math.sin(e * W0)
}

function mu(e) {
    return (1 - Math.cos(F0 * e)) / 2
}

function ht(e) {
    return (Math.pow(2, -10 * e) - .0009765625) * 1.0009775171065494
}

function T5(e) {
    return ht(1 - +e)
}

function S5(e) {
    return 1 - ht(e)
}

function bu(e) {
    return ((e *= 2) <= 1 ? ht(1 - e) : 2 - ht(e - 1)) / 2
}

function E5(e) {
    return 1 - Math.sqrt(1 - e * e)
}

function M5(e) {
    return Math.sqrt(1 - --e * e)
}

function pu(e) {
    return ((e *= 2) <= 1 ? 1 - Math.sqrt(1 - e * e) : Math.sqrt(1 - (e -= 2) * e) + 1) / 2
}
var hi = 4 / 11,
    C5 = 6 / 11,
    $5 = 8 / 11,
    P5 = 3 / 4,
    k5 = 9 / 11,
    I5 = 10 / 11,
    D5 = 15 / 16,
    N5 = 21 / 22,
    L5 = 63 / 64,
    mr = 1 / hi / hi;

function j5(e) {
    return 1 - Un(1 - e)
}

function Un(e) {
    return (e = +e) < hi ? mr * e * e : e < $5 ? mr * (e -= C5) * e + P5 : e < I5 ? mr * (e -= k5) * e + D5 : mr * (e -= N5) * e + L5
}

function R5(e) {
    return ((e *= 2) <= 1 ? 1 - Un(1 - e) : Un(e - 1) + 1) / 2
}
var to = 1.70158,
    F5 = function e(t) {
        t = +t;

        function n(r) {
            return (r = +r) * r * (t * (r - 1) + r)
        }
        return n.overshoot = e, n
    }(to),
    W5 = function e(t) {
        t = +t;

        function n(r) {
            return --r * r * ((r + 1) * t + r) + 1
        }
        return n.overshoot = e, n
    }(to),
    _u = function e(t) {
        t = +t;

        function n(r) {
            return ((r *= 2) < 1 ? r * r * ((t + 1) * r - t) : (r -= 2) * r * ((t + 1) * r + t) + 2) / 2
        }
        return n.overshoot = e, n
    }(to),
    Yt = 2 * Math.PI,
    no = 1,
    ro = .3,
    z5 = function e(t, n) {
        var r = Math.asin(1 / (t = Math.max(1, t))) * (n /= Yt);

        function a(i) {
            return t * ht(- --i) * Math.sin((r - i) / n)
        }
        return a.amplitude = function(i) {
            return e(i, n * Yt)
        }, a.period = function(i) {
            return e(t, i)
        }, a
    }(no, ro),
    xu = function e(t, n) {
        var r = Math.asin(1 / (t = Math.max(1, t))) * (n /= Yt);

        function a(i) {
            return 1 - t * ht(i = +i) * Math.sin((i + r) / n)
        }
        return a.amplitude = function(i) {
            return e(i, n * Yt)
        }, a.period = function(i) {
            return e(t, i)
        }, a
    }(no, ro),
    U5 = function e(t, n) {
        var r = Math.asin(1 / (t = Math.max(1, t))) * (n /= Yt);

        function a(i) {
            return ((i = i * 2 - 1) < 0 ? t * ht(-i) * Math.sin((r - i) / n) : 2 - t * ht(i) * Math.sin((r + i) / n)) / 2
        }
        return a.amplitude = function(i) {
            return e(i, n * Yt)
        }, a.period = function(i) {
            return e(t, i)
        }, a
    }(no, ro),
    H5 = Object.freeze(Object.defineProperty({
        __proto__: null,
        easeLinear: y5,
        easeQuad: vu,
        easeQuadIn: m5,
        easeQuadOut: b5,
        easeQuadInOut: vu,
        easeCubic: gu,
        easeCubicIn: p5,
        easeCubicOut: _5,
        easeCubicInOut: gu,
        easePoly: yu,
        easePolyIn: x5,
        easePolyOut: w5,
        easePolyInOut: yu,
        easeSin: mu,
        easeSinIn: A5,
        easeSinOut: O5,
        easeSinInOut: mu,
        easeExp: bu,
        easeExpIn: T5,
        easeExpOut: S5,
        easeExpInOut: bu,
        easeCircle: pu,
        easeCircleIn: E5,
        easeCircleOut: M5,
        easeCircleInOut: pu,
        easeBounce: Un,
        easeBounceIn: j5,
        easeBounceOut: Un,
        easeBounceInOut: R5,
        easeBack: _u,
        easeBackIn: F5,
        easeBackOut: W5,
        easeBackInOut: _u,
        easeElastic: xu,
        easeElasticIn: z5,
        easeElasticOut: xu,
        easeElasticInOut: U5
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function B5(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length, a = Array(r); ++n < r;) a[n] = t(e[n], n, e);
    return a
}
var ar = B5,
    G5 = Array.isArray,
    _e = G5,
    q5 = typeof $n == "object" && $n && $n.Object === Object && $n,
    z0 = q5,
    V5 = z0,
    Y5 = typeof self == "object" && self && self.Object === Object && self,
    K5 = V5 || Y5 || Function("return this")(),
    Je = K5,
    X5 = Je,
    Z5 = X5.Symbol,
    ir = Z5,
    wu = ir,
    U0 = Object.prototype,
    Q5 = U0.hasOwnProperty,
    J5 = U0.toString,
    On = wu ? wu.toStringTag : void 0;

function eh(e) {
    var t = Q5.call(e, On),
        n = e[On];
    try {
        e[On] = void 0;
        var r = !0
    } catch (i) {}
    var a = J5.call(e);
    return r && (t ? e[On] = n : delete e[On]), a
}
var th = eh,
    nh = Object.prototype,
    rh = nh.toString;

function ah(e) {
    return rh.call(e)
}
var ih = ah,
    Au = ir,
    oh = th,
    uh = ih,
    lh = "[object Null]",
    ch = "[object Undefined]",
    Ou = Au ? Au.toStringTag : void 0;

function fh(e) {
    return e == null ? e === void 0 ? ch : lh : Ou && Ou in Object(e) ? oh(e) : uh(e)
}
var lt = fh;

function sh(e) {
    return e != null && typeof e == "object"
}
var et = sh,
    hh = lt,
    dh = et,
    vh = "[object Symbol]";

function gh(e) {
    return typeof e == "symbol" || dh(e) && hh(e) == vh
}
var or = gh,
    yh = _e,
    mh = or,
    bh = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
    ph = /^\w*$/;

function _h(e, t) {
    if (yh(e)) return !1;
    var n = typeof e;
    return n == "number" || n == "symbol" || n == "boolean" || e == null || mh(e) ? !0 : ph.test(e) || !bh.test(e) || t != null && e in Object(t)
}
var ao = _h;

function xh(e) {
    var t = typeof e;
    return e != null && (t == "object" || t == "function")
}
var Te = xh,
    wh = lt,
    Ah = Te,
    Oh = "[object AsyncFunction]",
    Th = "[object Function]",
    Sh = "[object GeneratorFunction]",
    Eh = "[object Proxy]";

function Mh(e) {
    if (!Ah(e)) return !1;
    var t = wh(e);
    return t == Th || t == Sh || t == Oh || t == Eh
}
var io = Mh,
    H = io,
    Ch = Je,
    $h = Ch["__core-js_shared__"],
    Ph = $h,
    Ua = Ph,
    Tu = function() {
        var e = /[^.]+$/.exec(Ua && Ua.keys && Ua.keys.IE_PROTO || "");
        return e ? "Symbol(src)_1." + e : ""
    }();

function kh(e) {
    return !!Tu && Tu in e
}
var Ih = kh,
    Dh = Function.prototype,
    Nh = Dh.toString;

function Lh(e) {
    if (e != null) {
        try {
            return Nh.call(e)
        } catch (t) {}
        try {
            return e + ""
        } catch (t) {}
    }
    return ""
}
var H0 = Lh,
    jh = io,
    Rh = Ih,
    Fh = Te,
    Wh = H0,
    zh = /[\\^$.*+?()[\]{}|]/g,
    Uh = /^\[object .+?Constructor\]$/,
    Hh = Function.prototype,
    Bh = Object.prototype,
    Gh = Hh.toString,
    qh = Bh.hasOwnProperty,
    Vh = RegExp("^" + Gh.call(qh).replace(zh, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");

function Yh(e) {
    if (!Fh(e) || Rh(e)) return !1;
    var t = jh(e) ? Vh : Uh;
    return t.test(Wh(e))
}
var Kh = Yh;

function Xh(e, t) {
    return e == null ? void 0 : e[t]
}
var Zh = Xh,
    Qh = Kh,
    Jh = Zh;

function ed(e, t) {
    var n = Jh(e, t);
    return Qh(n) ? n : void 0
}
var Dt = ed,
    td = Dt,
    nd = td(Object, "create"),
    ca = nd,
    Su = ca;

function rd() {
    this.__data__ = Su ? Su(null) : {}, this.size = 0
}
var ad = rd;

function id(e) {
    var t = this.has(e) && delete this.__data__[e];
    return this.size -= t ? 1 : 0, t
}
var od = id,
    ud = ca,
    ld = "__lodash_hash_undefined__",
    cd = Object.prototype,
    fd = cd.hasOwnProperty;

function sd(e) {
    var t = this.__data__;
    if (ud) {
        var n = t[e];
        return n === ld ? void 0 : n
    }
    return fd.call(t, e) ? t[e] : void 0
}
var hd = sd,
    dd = ca,
    vd = Object.prototype,
    gd = vd.hasOwnProperty;

function yd(e) {
    var t = this.__data__;
    return dd ? t[e] !== void 0 : gd.call(t, e)
}
var md = yd,
    bd = ca,
    pd = "__lodash_hash_undefined__";

function _d(e, t) {
    var n = this.__data__;
    return this.size += this.has(e) ? 0 : 1, n[e] = bd && t === void 0 ? pd : t, this
}
var xd = _d,
    wd = ad,
    Ad = od,
    Od = hd,
    Td = md,
    Sd = xd;

function an(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
    }
}
an.prototype.clear = wd;
an.prototype.delete = Ad;
an.prototype.get = Od;
an.prototype.has = Td;
an.prototype.set = Sd;
var Ed = an;

function Md() {
    this.__data__ = [], this.size = 0
}
var Cd = Md;

function $d(e, t) {
    return e === t || e !== e && t !== t
}
var on = $d,
    Pd = on;

function kd(e, t) {
    for (var n = e.length; n--;)
        if (Pd(e[n][0], t)) return n;
    return -1
}
var fa = kd,
    Id = fa,
    Dd = Array.prototype,
    Nd = Dd.splice;

function Ld(e) {
    var t = this.__data__,
        n = Id(t, e);
    if (n < 0) return !1;
    var r = t.length - 1;
    return n == r ? t.pop() : Nd.call(t, n, 1), --this.size, !0
}
var jd = Ld,
    Rd = fa;

function Fd(e) {
    var t = this.__data__,
        n = Rd(t, e);
    return n < 0 ? void 0 : t[n][1]
}
var Wd = Fd,
    zd = fa;

function Ud(e) {
    return zd(this.__data__, e) > -1
}
var Hd = Ud,
    Bd = fa;

function Gd(e, t) {
    var n = this.__data__,
        r = Bd(n, e);
    return r < 0 ? (++this.size, n.push([e, t])) : n[r][1] = t, this
}
var qd = Gd,
    Vd = Cd,
    Yd = jd,
    Kd = Wd,
    Xd = Hd,
    Zd = qd;

function un(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
    }
}
un.prototype.clear = Vd;
un.prototype.delete = Yd;
un.prototype.get = Kd;
un.prototype.has = Xd;
un.prototype.set = Zd;
var sa = un,
    Qd = Dt,
    Jd = Je,
    ev = Qd(Jd, "Map"),
    oo = ev,
    Eu = Ed,
    tv = sa,
    nv = oo;

function rv() {
    this.size = 0, this.__data__ = {
        hash: new Eu,
        map: new(nv || tv),
        string: new Eu
    }
}
var av = rv;

function iv(e) {
    var t = typeof e;
    return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null
}
var ov = iv,
    uv = ov;

function lv(e, t) {
    var n = e.__data__;
    return uv(t) ? n[typeof t == "string" ? "string" : "hash"] : n.map
}
var ha = lv,
    cv = ha;

function fv(e) {
    var t = cv(this, e).delete(e);
    return this.size -= t ? 1 : 0, t
}
var sv = fv,
    hv = ha;

function dv(e) {
    return hv(this, e).get(e)
}
var vv = dv,
    gv = ha;

function yv(e) {
    return gv(this, e).has(e)
}
var mv = yv,
    bv = ha;

function pv(e, t) {
    var n = bv(this, e),
        r = n.size;
    return n.set(e, t), this.size += n.size == r ? 0 : 1, this
}
var _v = pv,
    xv = av,
    wv = sv,
    Av = vv,
    Ov = mv,
    Tv = _v;

function ln(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.clear(); ++t < n;) {
        var r = e[t];
        this.set(r[0], r[1])
    }
}
ln.prototype.clear = xv;
ln.prototype.delete = wv;
ln.prototype.get = Av;
ln.prototype.has = Ov;
ln.prototype.set = Tv;
var uo = ln,
    B0 = uo,
    Sv = "Expected a function";

function lo(e, t) {
    if (typeof e != "function" || t != null && typeof t != "function") throw new TypeError(Sv);
    var n = function() {
        var r = arguments,
            a = t ? t.apply(this, r) : r[0],
            i = n.cache;
        if (i.has(a)) return i.get(a);
        var o = e.apply(this, r);
        return n.cache = i.set(a, o) || i, o
    };
    return n.cache = new(lo.Cache || B0), n
}
lo.Cache = B0;
var Ev = lo,
    Mv = Ev,
    Cv = 500;

function $v(e) {
    var t = Mv(e, function(r) {
            return n.size === Cv && n.clear(), r
        }),
        n = t.cache;
    return t
}
var Pv = $v,
    kv = Pv,
    Iv = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
    Dv = /\\(\\)?/g,
    Nv = kv(function(e) {
        var t = [];
        return e.charCodeAt(0) === 46 && t.push(""), e.replace(Iv, function(n, r, a, i) {
            t.push(a ? i.replace(Dv, "$1") : r || n)
        }), t
    }),
    Lv = Nv,
    Mu = ir,
    jv = ar,
    Rv = _e,
    Fv = or,
    Wv = 1 / 0,
    Cu = Mu ? Mu.prototype : void 0,
    $u = Cu ? Cu.toString : void 0;

function G0(e) {
    if (typeof e == "string") return e;
    if (Rv(e)) return jv(e, G0) + "";
    if (Fv(e)) return $u ? $u.call(e) : "";
    var t = e + "";
    return t == "0" && 1 / e == -Wv ? "-0" : t
}
var zv = G0,
    Uv = zv;

function Hv(e) {
    return e == null ? "" : Uv(e)
}
var q0 = Hv,
    Bv = _e,
    Gv = ao,
    qv = Lv,
    Vv = q0;

function Yv(e, t) {
    return Bv(e) ? e : Gv(e, t) ? [e] : qv(Vv(e))
}
var da = Yv,
    Kv = or,
    Xv = 1 / 0;

function Zv(e) {
    if (typeof e == "string" || Kv(e)) return e;
    var t = e + "";
    return t == "0" && 1 / e == -Xv ? "-0" : t
}
var ur = Zv,
    Qv = da,
    Jv = ur;

function e1(e, t) {
    t = Qv(t, e);
    for (var n = 0, r = t.length; e != null && n < r;) e = e[Jv(t[n++])];
    return n && n == r ? e : void 0
}
var va = e1,
    t1 = sa;

function n1() {
    this.__data__ = new t1, this.size = 0
}
var r1 = n1;

function a1(e) {
    var t = this.__data__,
        n = t.delete(e);
    return this.size = t.size, n
}
var i1 = a1;

function o1(e) {
    return this.__data__.get(e)
}
var u1 = o1;

function l1(e) {
    return this.__data__.has(e)
}
var c1 = l1,
    f1 = sa,
    s1 = oo,
    h1 = uo,
    d1 = 200;

function v1(e, t) {
    var n = this.__data__;
    if (n instanceof f1) {
        var r = n.__data__;
        if (!s1 || r.length < d1 - 1) return r.push([e, t]), this.size = ++n.size, this;
        n = this.__data__ = new h1(r)
    }
    return n.set(e, t), this.size = n.size, this
}
var g1 = v1,
    y1 = sa,
    m1 = r1,
    b1 = i1,
    p1 = u1,
    _1 = c1,
    x1 = g1;

function cn(e) {
    var t = this.__data__ = new y1(e);
    this.size = t.size
}
cn.prototype.clear = m1;
cn.prototype.delete = b1;
cn.prototype.get = p1;
cn.prototype.has = _1;
cn.prototype.set = x1;
var V0 = cn,
    w1 = "__lodash_hash_undefined__";

function A1(e) {
    return this.__data__.set(e, w1), this
}
var O1 = A1;

function T1(e) {
    return this.__data__.has(e)
}
var S1 = T1,
    E1 = uo,
    M1 = O1,
    C1 = S1;

function Lr(e) {
    var t = -1,
        n = e == null ? 0 : e.length;
    for (this.__data__ = new E1; ++t < n;) this.add(e[t])
}
Lr.prototype.add = Lr.prototype.push = M1;
Lr.prototype.has = C1;
var co = Lr;

function $1(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length; ++n < r;)
        if (t(e[n], n, e)) return !0;
    return !1
}
var Y0 = $1;

function P1(e, t) {
    return e.has(t)
}
var fo = P1,
    k1 = co,
    I1 = Y0,
    D1 = fo,
    N1 = 1,
    L1 = 2;

function j1(e, t, n, r, a, i) {
    var o = n & N1,
        u = e.length,
        l = t.length;
    if (u != l && !(o && l > u)) return !1;
    var c = i.get(e),
        f = i.get(t);
    if (c && f) return c == t && f == e;
    var h = -1,
        d = !0,
        y = n & L1 ? new k1 : void 0;
    for (i.set(e, t), i.set(t, e); ++h < u;) {
        var v = e[h],
            b = t[h];
        if (r) var g = o ? r(b, v, h, t, e, i) : r(v, b, h, e, t, i);
        if (g !== void 0) {
            if (g) continue;
            d = !1;
            break
        }
        if (y) {
            if (!I1(t, function(p, m) {
                    if (!D1(y, m) && (v === p || a(v, p, n, r, i))) return y.push(m)
                })) {
                d = !1;
                break
            }
        } else if (!(v === b || a(v, b, n, r, i))) {
            d = !1;
            break
        }
    }
    return i.delete(e), i.delete(t), d
}
var K0 = j1,
    R1 = Je,
    F1 = R1.Uint8Array,
    W1 = F1;

function z1(e) {
    var t = -1,
        n = Array(e.size);
    return e.forEach(function(r, a) {
        n[++t] = [a, r]
    }), n
}
var U1 = z1;

function H1(e) {
    var t = -1,
        n = Array(e.size);
    return e.forEach(function(r) {
        n[++t] = r
    }), n
}
var so = H1,
    Pu = ir,
    ku = W1,
    B1 = on,
    G1 = K0,
    q1 = U1,
    V1 = so,
    Y1 = 1,
    K1 = 2,
    X1 = "[object Boolean]",
    Z1 = "[object Date]",
    Q1 = "[object Error]",
    J1 = "[object Map]",
    e2 = "[object Number]",
    t2 = "[object RegExp]",
    n2 = "[object Set]",
    r2 = "[object String]",
    a2 = "[object Symbol]",
    i2 = "[object ArrayBuffer]",
    o2 = "[object DataView]",
    Iu = Pu ? Pu.prototype : void 0,
    Ha = Iu ? Iu.valueOf : void 0;

function u2(e, t, n, r, a, i, o) {
    switch (n) {
        case o2:
            if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset) return !1;
            e = e.buffer, t = t.buffer;
        case i2:
            return !(e.byteLength != t.byteLength || !i(new ku(e), new ku(t)));
        case X1:
        case Z1:
        case e2:
            return B1(+e, +t);
        case Q1:
            return e.name == t.name && e.message == t.message;
        case t2:
        case r2:
            return e == t + "";
        case J1:
            var u = q1;
        case n2:
            var l = r & Y1;
            if (u || (u = V1), e.size != t.size && !l) return !1;
            var c = o.get(e);
            if (c) return c == t;
            r |= K1, o.set(e, t);
            var f = G1(u(e), u(t), r, a, i, o);
            return o.delete(e), f;
        case a2:
            if (Ha) return Ha.call(e) == Ha.call(t)
    }
    return !1
}
var l2 = u2;

function c2(e, t) {
    for (var n = -1, r = t.length, a = e.length; ++n < r;) e[a + n] = t[n];
    return e
}
var ho = c2,
    f2 = ho,
    s2 = _e;

function h2(e, t, n) {
    var r = t(e);
    return s2(e) ? r : f2(r, n(e))
}
var X0 = h2;

function d2(e, t) {
    for (var n = -1, r = e == null ? 0 : e.length, a = 0, i = []; ++n < r;) {
        var o = e[n];
        t(o, n, e) && (i[a++] = o)
    }
    return i
}
var v2 = d2;

function g2() {
    return []
}
var Z0 = g2,
    y2 = v2,
    m2 = Z0,
    b2 = Object.prototype,
    p2 = b2.propertyIsEnumerable,
    Du = Object.getOwnPropertySymbols,
    _2 = Du ? function(e) {
        return e == null ? [] : (e = Object(e), y2(Du(e), function(t) {
            return p2.call(e, t)
        }))
    } : m2,
    Q0 = _2;

function x2(e, t) {
    for (var n = -1, r = Array(e); ++n < e;) r[n] = t(n);
    return r
}
var w2 = x2,
    A2 = lt,
    O2 = et,
    T2 = "[object Arguments]";

function S2(e) {
    return O2(e) && A2(e) == T2
}
var E2 = S2,
    Nu = E2,
    M2 = et,
    J0 = Object.prototype,
    C2 = J0.hasOwnProperty,
    $2 = J0.propertyIsEnumerable,
    P2 = Nu(function() {
        return arguments
    }()) ? Nu : function(e) {
        return M2(e) && C2.call(e, "callee") && !$2.call(e, "callee")
    },
    ga = P2,
    Hn = {
        exports: {}
    };

function k2() {
    return !1
}
var I2 = k2;
(function(e, t) {
    var n = Je,
        r = I2,
        a = t && !t.nodeType && t,
        i = a && !0 && e && !e.nodeType && e,
        o = i && i.exports === a,
        u = o ? n.Buffer : void 0,
        l = u ? u.isBuffer : void 0,
        c = l || r;
    e.exports = c
})(Hn, Hn.exports);
var D2 = 9007199254740991,
    N2 = /^(?:0|[1-9]\d*)$/;

function L2(e, t) {
    var n = typeof e;
    return t = t == null ? D2 : t, !!t && (n == "number" || n != "symbol" && N2.test(e)) && e > -1 && e % 1 == 0 && e < t
}
var ya = L2,
    j2 = 9007199254740991;

function R2(e) {
    return typeof e == "number" && e > -1 && e % 1 == 0 && e <= j2
}
var vo = R2,
    F2 = lt,
    W2 = vo,
    z2 = et,
    U2 = "[object Arguments]",
    H2 = "[object Array]",
    B2 = "[object Boolean]",
    G2 = "[object Date]",
    q2 = "[object Error]",
    V2 = "[object Function]",
    Y2 = "[object Map]",
    K2 = "[object Number]",
    X2 = "[object Object]",
    Z2 = "[object RegExp]",
    Q2 = "[object Set]",
    J2 = "[object String]",
    eg = "[object WeakMap]",
    tg = "[object ArrayBuffer]",
    ng = "[object DataView]",
    rg = "[object Float32Array]",
    ag = "[object Float64Array]",
    ig = "[object Int8Array]",
    og = "[object Int16Array]",
    ug = "[object Int32Array]",
    lg = "[object Uint8Array]",
    cg = "[object Uint8ClampedArray]",
    fg = "[object Uint16Array]",
    sg = "[object Uint32Array]",
    J = {};
J[rg] = J[ag] = J[ig] = J[og] = J[ug] = J[lg] = J[cg] = J[fg] = J[sg] = !0;
J[U2] = J[H2] = J[tg] = J[B2] = J[ng] = J[G2] = J[q2] = J[V2] = J[Y2] = J[K2] = J[X2] = J[Z2] = J[Q2] = J[J2] = J[eg] = !1;

function hg(e) {
    return z2(e) && W2(e.length) && !!J[F2(e)]
}
var dg = hg;

function vg(e) {
    return function(t) {
        return e(t)
    }
}
var lr = vg,
    Bn = {
        exports: {}
    };
(function(e, t) {
    var n = z0,
        r = t && !t.nodeType && t,
        a = r && !0 && e && !e.nodeType && e,
        i = a && a.exports === r,
        o = i && n.process,
        u = function() {
            try {
                var l = a && a.require && a.require("util").types;
                return l || o && o.binding && o.binding("util")
            } catch (c) {}
        }();
    e.exports = u
})(Bn, Bn.exports);
var gg = dg,
    yg = lr,
    Lu = Bn.exports,
    ju = Lu && Lu.isTypedArray,
    mg = ju ? yg(ju) : gg,
    go = mg,
    bg = w2,
    pg = ga,
    _g = _e,
    xg = Hn.exports,
    wg = ya,
    Ag = go,
    Og = Object.prototype,
    Tg = Og.hasOwnProperty;

function Sg(e, t) {
    var n = _g(e),
        r = !n && pg(e),
        a = !n && !r && xg(e),
        i = !n && !r && !a && Ag(e),
        o = n || r || a || i,
        u = o ? bg(e.length, String) : [],
        l = u.length;
    for (var c in e)(t || Tg.call(e, c)) && !(o && (c == "length" || a && (c == "offset" || c == "parent") || i && (c == "buffer" || c == "byteLength" || c == "byteOffset") || wg(c, l))) && u.push(c);
    return u
}
var ec = Sg,
    Eg = Object.prototype;

function Mg(e) {
    var t = e && e.constructor,
        n = typeof t == "function" && t.prototype || Eg;
    return e === n
}
var ma = Mg;

function Cg(e, t) {
    return function(n) {
        return e(t(n))
    }
}
var tc = Cg,
    $g = tc,
    Pg = $g(Object.keys, Object),
    kg = Pg,
    Ig = ma,
    Dg = kg,
    Ng = Object.prototype,
    Lg = Ng.hasOwnProperty;

function jg(e) {
    if (!Ig(e)) return Dg(e);
    var t = [];
    for (var n in Object(e)) Lg.call(e, n) && n != "constructor" && t.push(n);
    return t
}
var nc = jg,
    Rg = io,
    Fg = vo;

function Wg(e) {
    return e != null && Fg(e.length) && !Rg(e)
}
var tt = Wg,
    zg = ec,
    Ug = nc,
    Hg = tt;

function Bg(e) {
    return Hg(e) ? zg(e) : Ug(e)
}
var Nt = Bg,
    ee = Nt,
    Gg = X0,
    qg = Q0,
    Vg = Nt;

function Yg(e) {
    return Gg(e, Vg, qg)
}
var Kg = Yg,
    Ru = Kg,
    Xg = 1,
    Zg = Object.prototype,
    Qg = Zg.hasOwnProperty;

function Jg(e, t, n, r, a, i) {
    var o = n & Xg,
        u = Ru(e),
        l = u.length,
        c = Ru(t),
        f = c.length;
    if (l != f && !o) return !1;
    for (var h = l; h--;) {
        var d = u[h];
        if (!(o ? d in t : Qg.call(t, d))) return !1
    }
    var y = i.get(e),
        v = i.get(t);
    if (y && v) return y == t && v == e;
    var b = !0;
    i.set(e, t), i.set(t, e);
    for (var g = o; ++h < l;) {
        d = u[h];
        var p = e[d],
            m = t[d];
        if (r) var _ = o ? r(m, p, d, t, e, i) : r(p, m, d, e, t, i);
        if (!(_ === void 0 ? p === m || a(p, m, n, r, i) : _)) {
            b = !1;
            break
        }
        g || (g = d == "constructor")
    }
    if (b && !g) {
        var w = e.constructor,
            O = t.constructor;
        w != O && "constructor" in e && "constructor" in t && !(typeof w == "function" && w instanceof w && typeof O == "function" && O instanceof O) && (b = !1)
    }
    return i.delete(e), i.delete(t), b
}
var ey = Jg,
    ty = Dt,
    ny = Je,
    ry = ty(ny, "DataView"),
    ay = ry,
    iy = Dt,
    oy = Je,
    uy = iy(oy, "Promise"),
    ly = uy,
    cy = Dt,
    fy = Je,
    sy = cy(fy, "Set"),
    rc = sy,
    hy = Dt,
    dy = Je,
    vy = hy(dy, "WeakMap"),
    gy = vy,
    di = ay,
    vi = oo,
    gi = ly,
    yi = rc,
    mi = gy,
    ac = lt,
    fn = H0,
    Fu = "[object Map]",
    yy = "[object Object]",
    Wu = "[object Promise]",
    zu = "[object Set]",
    Uu = "[object WeakMap]",
    Hu = "[object DataView]",
    my = fn(di),
    by = fn(vi),
    py = fn(gi),
    _y = fn(yi),
    xy = fn(mi),
    Ot = ac;
(di && Ot(new di(new ArrayBuffer(1))) != Hu || vi && Ot(new vi) != Fu || gi && Ot(gi.resolve()) != Wu || yi && Ot(new yi) != zu || mi && Ot(new mi) != Uu) && (Ot = function(e) {
    var t = ac(e),
        n = t == yy ? e.constructor : void 0,
        r = n ? fn(n) : "";
    if (r) switch (r) {
        case my:
            return Hu;
        case by:
            return Fu;
        case py:
            return Wu;
        case _y:
            return zu;
        case xy:
            return Uu
    }
    return t
});
var ic = Ot,
    Ba = V0,
    wy = K0,
    Ay = l2,
    Oy = ey,
    Bu = ic,
    Gu = _e,
    qu = Hn.exports,
    Ty = go,
    Sy = 1,
    Vu = "[object Arguments]",
    Yu = "[object Array]",
    br = "[object Object]",
    Ey = Object.prototype,
    Ku = Ey.hasOwnProperty;

function My(e, t, n, r, a, i) {
    var o = Gu(e),
        u = Gu(t),
        l = o ? Yu : Bu(e),
        c = u ? Yu : Bu(t);
    l = l == Vu ? br : l, c = c == Vu ? br : c;
    var f = l == br,
        h = c == br,
        d = l == c;
    if (d && qu(e)) {
        if (!qu(t)) return !1;
        o = !0, f = !1
    }
    if (d && !f) return i || (i = new Ba), o || Ty(e) ? wy(e, t, n, r, a, i) : Ay(e, t, l, n, r, a, i);
    if (!(n & Sy)) {
        var y = f && Ku.call(e, "__wrapped__"),
            v = h && Ku.call(t, "__wrapped__");
        if (y || v) {
            var b = y ? e.value() : e,
                g = v ? t.value() : t;
            return i || (i = new Ba), a(b, g, n, r, i)
        }
    }
    return d ? (i || (i = new Ba), Oy(e, t, n, r, a, i)) : !1
}
var Cy = My,
    $y = Cy,
    Xu = et;

function oc(e, t, n, r, a) {
    return e === t ? !0 : e == null || t == null || !Xu(e) && !Xu(t) ? e !== e && t !== t : $y(e, t, n, r, oc, a)
}
var yo = oc,
    Py = V0,
    ky = yo,
    Iy = 1,
    Dy = 2;

function Ny(e, t, n, r) {
    var a = n.length,
        i = a,
        o = !r;
    if (e == null) return !i;
    for (e = Object(e); a--;) {
        var u = n[a];
        if (o && u[2] ? u[1] !== e[u[0]] : !(u[0] in e)) return !1
    }
    for (; ++a < i;) {
        u = n[a];
        var l = u[0],
            c = e[l],
            f = u[1];
        if (o && u[2]) {
            if (c === void 0 && !(l in e)) return !1
        } else {
            var h = new Py;
            if (r) var d = r(c, f, l, e, t, h);
            if (!(d === void 0 ? ky(f, c, Iy | Dy, r, h) : d)) return !1
        }
    }
    return !0
}
var Ly = Ny,
    jy = Te;

function Ry(e) {
    return e === e && !jy(e)
}
var uc = Ry,
    Fy = uc,
    Wy = Nt;

function zy(e) {
    for (var t = Wy(e), n = t.length; n--;) {
        var r = t[n],
            a = e[r];
        t[n] = [r, a, Fy(a)]
    }
    return t
}
var Uy = zy;

function Hy(e, t) {
    return function(n) {
        return n == null ? !1 : n[e] === t && (t !== void 0 || e in Object(n))
    }
}
var lc = Hy,
    By = Ly,
    Gy = Uy,
    qy = lc;

function Vy(e) {
    var t = Gy(e);
    return t.length == 1 && t[0][2] ? qy(t[0][0], t[0][1]) : function(n) {
        return n === e || By(n, e, t)
    }
}
var Yy = Vy,
    Ky = va;

function Xy(e, t, n) {
    var r = e == null ? void 0 : Ky(e, t);
    return r === void 0 ? n : r
}
var Zy = Xy;

function Qy(e, t) {
    return e != null && t in Object(e)
}
var Jy = Qy,
    e6 = da,
    t6 = ga,
    n6 = _e,
    r6 = ya,
    a6 = vo,
    i6 = ur;

function o6(e, t, n) {
    t = e6(t, e);
    for (var r = -1, a = t.length, i = !1; ++r < a;) {
        var o = i6(t[r]);
        if (!(i = e != null && n(e, o))) break;
        e = e[o]
    }
    return i || ++r != a ? i : (a = e == null ? 0 : e.length, !!a && a6(a) && r6(o, a) && (n6(e) || t6(e)))
}
var u6 = o6,
    l6 = Jy,
    c6 = u6;

function f6(e, t) {
    return e != null && c6(e, t, l6)
}
var cc = f6,
    s6 = yo,
    h6 = Zy,
    d6 = cc,
    v6 = ao,
    g6 = uc,
    y6 = lc,
    m6 = ur,
    b6 = 1,
    p6 = 2;

function _6(e, t) {
    return v6(e) && g6(t) ? y6(m6(e), t) : function(n) {
        var r = h6(n, e);
        return r === void 0 && r === t ? d6(n, e) : s6(t, r, b6 | p6)
    }
}
var x6 = _6;

function w6(e) {
    return e
}
var Re = w6;

function A6(e) {
    return function(t) {
        return t == null ? void 0 : t[e]
    }
}
var O6 = A6,
    T6 = va;

function S6(e) {
    return function(t) {
        return T6(t, e)
    }
}
var E6 = S6,
    M6 = O6,
    C6 = E6,
    $6 = ao,
    P6 = ur;

function k6(e) {
    return $6(e) ? M6(P6(e)) : C6(e)
}
var mo = k6,
    I6 = Yy,
    D6 = x6,
    N6 = Re,
    L6 = _e,
    j6 = mo;

function R6(e) {
    return typeof e == "function" ? e : e == null ? N6 : typeof e == "object" ? L6(e) ? D6(e[0], e[1]) : I6(e) : j6(e)
}
var mt = R6;

function F6(e) {
    return function(t, n, r) {
        for (var a = -1, i = Object(t), o = r(t), u = o.length; u--;) {
            var l = o[e ? u : ++a];
            if (n(i[l], l, i) === !1) break
        }
        return t
    }
}
var W6 = F6,
    z6 = W6,
    U6 = z6(),
    H6 = U6,
    B6 = H6,
    G6 = Nt;

function q6(e, t) {
    return e && B6(e, t, G6)
}
var V6 = q6,
    Y6 = tt;

function K6(e, t) {
    return function(n, r) {
        if (n == null) return n;
        if (!Y6(n)) return e(n, r);
        for (var a = n.length, i = t ? a : -1, o = Object(n);
            (t ? i-- : ++i < a) && r(o[i], i, o) !== !1;);
        return n
    }
}
var X6 = K6,
    Z6 = V6,
    Q6 = X6,
    J6 = Q6(Z6),
    bo = J6,
    em = bo,
    tm = tt;

function nm(e, t) {
    var n = -1,
        r = tm(e) ? Array(e.length) : [];
    return em(e, function(a, i, o) {
        r[++n] = t(a, i, o)
    }), r
}
var rm = nm;

function am(e, t) {
    var n = e.length;
    for (e.sort(t); n--;) e[n] = e[n].value;
    return e
}
var im = am,
    Zu = or;

function om(e, t) {
    if (e !== t) {
        var n = e !== void 0,
            r = e === null,
            a = e === e,
            i = Zu(e),
            o = t !== void 0,
            u = t === null,
            l = t === t,
            c = Zu(t);
        if (!u && !c && !i && e > t || i && o && l && !u && !c || r && o && l || !n && l || !a) return 1;
        if (!r && !i && !c && e < t || c && n && a && !r && !i || u && n && a || !o && a || !l) return -1
    }
    return 0
}
var um = om,
    lm = um;

function cm(e, t, n) {
    for (var r = -1, a = e.criteria, i = t.criteria, o = a.length, u = n.length; ++r < o;) {
        var l = lm(a[r], i[r]);
        if (l) {
            if (r >= u) return l;
            var c = n[r];
            return l * (c == "desc" ? -1 : 1)
        }
    }
    return e.index - t.index
}
var fm = cm,
    Ga = ar,
    sm = va,
    hm = mt,
    dm = rm,
    vm = im,
    gm = lr,
    ym = fm,
    mm = Re,
    bm = _e;

function pm(e, t, n) {
    t.length ? t = Ga(t, function(i) {
        return bm(i) ? function(o) {
            return sm(o, i.length === 1 ? i[0] : i)
        } : i
    }) : t = [mm];
    var r = -1;
    t = Ga(t, gm(hm));
    var a = dm(e, function(i, o, u) {
        var l = Ga(t, function(c) {
            return c(i)
        });
        return {
            criteria: l,
            index: ++r,
            value: i
        }
    });
    return vm(a, function(i, o) {
        return ym(i, o, n)
    })
}
var _m = pm,
    xm = _m,
    Qu = _e;

function wm(e, t, n, r) {
    return e == null ? [] : (Qu(t) || (t = t == null ? [] : [t]), n = r ? void 0 : n, Qu(n) || (n = n == null ? [] : [n]), xm(e, t, n))
}
var po = wm,
    Am = tc,
    Om = Am(Object.getPrototypeOf, Object),
    fc = Om,
    Tm = lt,
    Sm = fc,
    Em = et,
    Mm = "[object Object]",
    Cm = Function.prototype,
    $m = Object.prototype,
    sc = Cm.toString,
    Pm = $m.hasOwnProperty,
    km = sc.call(Object);

function Im(e) {
    if (!Em(e) || Tm(e) != Mm) return !1;
    var t = Sm(e);
    if (t === null) return !0;
    var n = Pm.call(t, "constructor") && t.constructor;
    return typeof n == "function" && n instanceof n && sc.call(n) == km
}
var ne = Im;

function ba(e, t, n) {
    e.prototype = t.prototype = n, n.constructor = e
}

function _o(e, t) {
    var n = Object.create(e.prototype);
    for (var r in t) n[r] = t[r];
    return n
}

function sn() {}
var $t = .7,
    Kt = 1 / $t,
    Gt = "\\s*([+-]?\\d+)\\s*",
    Gn = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
    Ge = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
    Dm = /^#([0-9a-f]{3,8})$/,
    Nm = new RegExp("^rgb\\(" + [Gt, Gt, Gt] + "\\)$"),
    Lm = new RegExp("^rgb\\(" + [Ge, Ge, Ge] + "\\)$"),
    jm = new RegExp("^rgba\\(" + [Gt, Gt, Gt, Gn] + "\\)$"),
    Rm = new RegExp("^rgba\\(" + [Ge, Ge, Ge, Gn] + "\\)$"),
    Fm = new RegExp("^hsl\\(" + [Gn, Ge, Ge] + "\\)$"),
    Wm = new RegExp("^hsla\\(" + [Gn, Ge, Ge, Gn] + "\\)$"),
    Ju = {
        aliceblue: 15792383,
        antiquewhite: 16444375,
        aqua: 65535,
        aquamarine: 8388564,
        azure: 15794175,
        beige: 16119260,
        bisque: 16770244,
        black: 0,
        blanchedalmond: 16772045,
        blue: 255,
        blueviolet: 9055202,
        brown: 10824234,
        burlywood: 14596231,
        cadetblue: 6266528,
        chartreuse: 8388352,
        chocolate: 13789470,
        coral: 16744272,
        cornflowerblue: 6591981,
        cornsilk: 16775388,
        crimson: 14423100,
        cyan: 65535,
        darkblue: 139,
        darkcyan: 35723,
        darkgoldenrod: 12092939,
        darkgray: 11119017,
        darkgreen: 25600,
        darkgrey: 11119017,
        darkkhaki: 12433259,
        darkmagenta: 9109643,
        darkolivegreen: 5597999,
        darkorange: 16747520,
        darkorchid: 10040012,
        darkred: 9109504,
        darksalmon: 15308410,
        darkseagreen: 9419919,
        darkslateblue: 4734347,
        darkslategray: 3100495,
        darkslategrey: 3100495,
        darkturquoise: 52945,
        darkviolet: 9699539,
        deeppink: 16716947,
        deepskyblue: 49151,
        dimgray: 6908265,
        dimgrey: 6908265,
        dodgerblue: 2003199,
        firebrick: 11674146,
        floralwhite: 16775920,
        forestgreen: 2263842,
        fuchsia: 16711935,
        gainsboro: 14474460,
        ghostwhite: 16316671,
        gold: 16766720,
        goldenrod: 14329120,
        gray: 8421504,
        green: 32768,
        greenyellow: 11403055,
        grey: 8421504,
        honeydew: 15794160,
        hotpink: 16738740,
        indianred: 13458524,
        indigo: 4915330,
        ivory: 16777200,
        khaki: 15787660,
        lavender: 15132410,
        lavenderblush: 16773365,
        lawngreen: 8190976,
        lemonchiffon: 16775885,
        lightblue: 11393254,
        lightcoral: 15761536,
        lightcyan: 14745599,
        lightgoldenrodyellow: 16448210,
        lightgray: 13882323,
        lightgreen: 9498256,
        lightgrey: 13882323,
        lightpink: 16758465,
        lightsalmon: 16752762,
        lightseagreen: 2142890,
        lightskyblue: 8900346,
        lightslategray: 7833753,
        lightslategrey: 7833753,
        lightsteelblue: 11584734,
        lightyellow: 16777184,
        lime: 65280,
        limegreen: 3329330,
        linen: 16445670,
        magenta: 16711935,
        maroon: 8388608,
        mediumaquamarine: 6737322,
        mediumblue: 205,
        mediumorchid: 12211667,
        mediumpurple: 9662683,
        mediumseagreen: 3978097,
        mediumslateblue: 8087790,
        mediumspringgreen: 64154,
        mediumturquoise: 4772300,
        mediumvioletred: 13047173,
        midnightblue: 1644912,
        mintcream: 16121850,
        mistyrose: 16770273,
        moccasin: 16770229,
        navajowhite: 16768685,
        navy: 128,
        oldlace: 16643558,
        olive: 8421376,
        olivedrab: 7048739,
        orange: 16753920,
        orangered: 16729344,
        orchid: 14315734,
        palegoldenrod: 15657130,
        palegreen: 10025880,
        paleturquoise: 11529966,
        palevioletred: 14381203,
        papayawhip: 16773077,
        peachpuff: 16767673,
        peru: 13468991,
        pink: 16761035,
        plum: 14524637,
        powderblue: 11591910,
        purple: 8388736,
        rebeccapurple: 6697881,
        red: 16711680,
        rosybrown: 12357519,
        royalblue: 4286945,
        saddlebrown: 9127187,
        salmon: 16416882,
        sandybrown: 16032864,
        seagreen: 3050327,
        seashell: 16774638,
        sienna: 10506797,
        silver: 12632256,
        skyblue: 8900331,
        slateblue: 6970061,
        slategray: 7372944,
        slategrey: 7372944,
        snow: 16775930,
        springgreen: 65407,
        steelblue: 4620980,
        tan: 13808780,
        teal: 32896,
        thistle: 14204888,
        tomato: 16737095,
        turquoise: 4251856,
        violet: 15631086,
        wheat: 16113331,
        white: 16777215,
        whitesmoke: 16119285,
        yellow: 16776960,
        yellowgreen: 10145074
    };
ba(sn, qn, {
    copy: function(e) {
        return Object.assign(new this.constructor, this, e)
    },
    displayable: function() {
        return this.rgb().displayable()
    },
    hex: el,
    formatHex: el,
    formatHsl: zm,
    formatRgb: tl,
    toString: tl
});

function el() {
    return this.rgb().formatHex()
}

function zm() {
    return dc(this).formatHsl()
}

function tl() {
    return this.rgb().formatRgb()
}

function qn(e) {
    var t, n;
    return e = (e + "").trim().toLowerCase(), (t = Dm.exec(e)) ? (n = t[1].length, t = parseInt(t[1], 16), n === 6 ? nl(t) : n === 3 ? new pe(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : n === 8 ? pr(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : n === 4 ? pr(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = Nm.exec(e)) ? new pe(t[1], t[2], t[3], 1) : (t = Lm.exec(e)) ? new pe(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = jm.exec(e)) ? pr(t[1], t[2], t[3], t[4]) : (t = Rm.exec(e)) ? pr(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = Fm.exec(e)) ? il(t[1], t[2] / 100, t[3] / 100, 1) : (t = Wm.exec(e)) ? il(t[1], t[2] / 100, t[3] / 100, t[4]) : Ju.hasOwnProperty(e) ? nl(Ju[e]) : e === "transparent" ? new pe(NaN, NaN, NaN, 0) : null
}

function nl(e) {
    return new pe(e >> 16 & 255, e >> 8 & 255, e & 255, 1)
}

function pr(e, t, n, r) {
    return r <= 0 && (e = t = n = NaN), new pe(e, t, n, r)
}

function hc(e) {
    return e instanceof sn || (e = qn(e)), e ? (e = e.rgb(), new pe(e.r, e.g, e.b, e.opacity)) : new pe
}

function bi(e, t, n, r) {
    return arguments.length === 1 ? hc(e) : new pe(e, t, n, r == null ? 1 : r)
}

function pe(e, t, n, r) {
    this.r = +e, this.g = +t, this.b = +n, this.opacity = +r
}
ba(pe, bi, _o(sn, {
    brighter: function(e) {
        return e = e == null ? Kt : Math.pow(Kt, e), new pe(this.r * e, this.g * e, this.b * e, this.opacity)
    },
    darker: function(e) {
        return e = e == null ? $t : Math.pow($t, e), new pe(this.r * e, this.g * e, this.b * e, this.opacity)
    },
    rgb: function() {
        return this
    },
    displayable: function() {
        return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1
    },
    hex: rl,
    formatHex: rl,
    formatRgb: al,
    toString: al
}));

function rl() {
    return "#" + qa(this.r) + qa(this.g) + qa(this.b)
}

function al() {
    var e = this.opacity;
    return e = isNaN(e) ? 1 : Math.max(0, Math.min(1, e)), (e === 1 ? "rgb(" : "rgba(") + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.b) || 0)) + (e === 1 ? ")" : ", " + e + ")")
}

function qa(e) {
    return e = Math.max(0, Math.min(255, Math.round(e) || 0)), (e < 16 ? "0" : "") + e.toString(16)
}

function il(e, t, n, r) {
    return r <= 0 ? e = t = n = NaN : n <= 0 || n >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new He(e, t, n, r)
}

function dc(e) {
    if (e instanceof He) return new He(e.h, e.s, e.l, e.opacity);
    if (e instanceof sn || (e = qn(e)), !e) return new He;
    if (e instanceof He) return e;
    e = e.rgb();
    var t = e.r / 255,
        n = e.g / 255,
        r = e.b / 255,
        a = Math.min(t, n, r),
        i = Math.max(t, n, r),
        o = NaN,
        u = i - a,
        l = (i + a) / 2;
    return u ? (t === i ? o = (n - r) / u + (n < r) * 6 : n === i ? o = (r - t) / u + 2 : o = (t - n) / u + 4, u /= l < .5 ? i + a : 2 - i - a, o *= 60) : u = l > 0 && l < 1 ? 0 : o, new He(o, u, l, e.opacity)
}

function Um(e, t, n, r) {
    return arguments.length === 1 ? dc(e) : new He(e, t, n, r == null ? 1 : r)
}

function He(e, t, n, r) {
    this.h = +e, this.s = +t, this.l = +n, this.opacity = +r
}
ba(He, Um, _o(sn, {
    brighter: function(e) {
        return e = e == null ? Kt : Math.pow(Kt, e), new He(this.h, this.s, this.l * e, this.opacity)
    },
    darker: function(e) {
        return e = e == null ? $t : Math.pow($t, e), new He(this.h, this.s, this.l * e, this.opacity)
    },
    rgb: function() {
        var e = this.h % 360 + (this.h < 0) * 360,
            t = isNaN(e) || isNaN(this.s) ? 0 : this.s,
            n = this.l,
            r = n + (n < .5 ? n : 1 - n) * t,
            a = 2 * n - r;
        return new pe(Va(e >= 240 ? e - 240 : e + 120, a, r), Va(e, a, r), Va(e < 120 ? e + 240 : e - 120, a, r), this.opacity)
    },
    displayable: function() {
        return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
    },
    formatHsl: function() {
        var e = this.opacity;
        return e = isNaN(e) ? 1 : Math.max(0, Math.min(1, e)), (e === 1 ? "hsl(" : "hsla(") + (this.h || 0) + ", " + (this.s || 0) * 100 + "%, " + (this.l || 0) * 100 + "%" + (e === 1 ? ")" : ", " + e + ")")
    }
}));

function Va(e, t, n) {
    return (e < 60 ? t + (n - t) * e / 60 : e < 180 ? n : e < 240 ? t + (n - t) * (240 - e) / 60 : t) * 255
}
var Hm = Math.PI / 180,
    Bm = 180 / Math.PI,
    vc = -.14861,
    xo = 1.78277,
    wo = -.29227,
    pa = -.90649,
    Vn = 1.97294,
    ol = Vn * pa,
    ul = Vn * xo,
    ll = xo * wo - pa * vc;

function Gm(e) {
    if (e instanceof St) return new St(e.h, e.s, e.l, e.opacity);
    e instanceof pe || (e = hc(e));
    var t = e.r / 255,
        n = e.g / 255,
        r = e.b / 255,
        a = (ll * r + ol * t - ul * n) / (ll + ol - ul),
        i = r - a,
        o = (Vn * (n - a) - wo * i) / pa,
        u = Math.sqrt(o * o + i * i) / (Vn * a * (1 - a)),
        l = u ? Math.atan2(o, i) * Bm - 120 : NaN;
    return new St(l < 0 ? l + 360 : l, u, a, e.opacity)
}

function Ke(e, t, n, r) {
    return arguments.length === 1 ? Gm(e) : new St(e, t, n, r == null ? 1 : r)
}

function St(e, t, n, r) {
    this.h = +e, this.s = +t, this.l = +n, this.opacity = +r
}
ba(St, Ke, _o(sn, {
    brighter: function(e) {
        return e = e == null ? Kt : Math.pow(Kt, e), new St(this.h, this.s, this.l * e, this.opacity)
    },
    darker: function(e) {
        return e = e == null ? $t : Math.pow($t, e), new St(this.h, this.s, this.l * e, this.opacity)
    },
    rgb: function() {
        var e = isNaN(this.h) ? 0 : (this.h + 120) * Hm,
            t = +this.l,
            n = isNaN(this.s) ? 0 : this.s * t * (1 - t),
            r = Math.cos(e),
            a = Math.sin(e);
        return new pe(255 * (t + n * (vc * r + xo * a)), 255 * (t + n * (wo * r + pa * a)), 255 * (t + n * (Vn * r)), this.opacity)
    }
}));

function _a(e) {
    return function() {
        return e
    }
}

function gc(e, t) {
    return function(n) {
        return e + n * t
    }
}

function qm(e, t, n) {
    return e = Math.pow(e, n), t = Math.pow(t, n) - e, n = 1 / n,
        function(r) {
            return Math.pow(e + r * t, n)
        }
}

function Vm(e, t) {
    var n = t - e;
    return n ? gc(e, n > 180 || n < -180 ? n - 360 * Math.round(n / 360) : n) : _a(isNaN(e) ? t : e)
}

function Ym(e) {
    return (e = +e) == 1 ? qt : function(t, n) {
        return n - t ? qm(t, n, e) : _a(isNaN(t) ? n : t)
    }
}

function qt(e, t) {
    var n = t - e;
    return n ? gc(e, n) : _a(isNaN(e) ? t : e)
}
var cl = function e(t) {
    var n = Ym(t);

    function r(a, i) {
        var o = n((a = bi(a)).r, (i = bi(i)).r),
            u = n(a.g, i.g),
            l = n(a.b, i.b),
            c = qt(a.opacity, i.opacity);
        return function(f) {
            return a.r = o(f), a.g = u(f), a.b = l(f), a.opacity = c(f), a + ""
        }
    }
    return r.gamma = e, r
}(1);

function Km(e, t) {
    t || (t = []);
    var n = e ? Math.min(t.length, e.length) : 0,
        r = t.slice(),
        a;
    return function(i) {
        for (a = 0; a < n; ++a) r[a] = e[a] * (1 - i) + t[a] * i;
        return r
    }
}

function Xm(e) {
    return ArrayBuffer.isView(e) && !(e instanceof DataView)
}

function Zm(e, t) {
    var n = t ? t.length : 0,
        r = e ? Math.min(n, e.length) : 0,
        a = new Array(r),
        i = new Array(n),
        o;
    for (o = 0; o < r; ++o) a[o] = Lt(e[o], t[o]);
    for (; o < n; ++o) i[o] = t[o];
    return function(u) {
        for (o = 0; o < r; ++o) i[o] = a[o](u);
        return i
    }
}

function Qm(e, t) {
    var n = new Date;
    return e = +e, t = +t,
        function(r) {
            return n.setTime(e * (1 - r) + t * r), n
        }
}

function Yn(e, t) {
    return e = +e, t = +t,
        function(n) {
            return e * (1 - n) + t * n
        }
}

function Jm(e, t) {
    var n = {},
        r = {},
        a;
    (e === null || typeof e != "object") && (e = {}), (t === null || typeof t != "object") && (t = {});
    for (a in t) a in e ? n[a] = Lt(e[a], t[a]) : r[a] = t[a];
    return function(i) {
        for (a in n) r[a] = n[a](i);
        return r
    }
}
var pi = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
    Ya = new RegExp(pi.source, "g");

function eb(e) {
    return function() {
        return e
    }
}

function tb(e) {
    return function(t) {
        return e(t) + ""
    }
}

function nb(e, t) {
    var n = pi.lastIndex = Ya.lastIndex = 0,
        r, a, i, o = -1,
        u = [],
        l = [];
    for (e = e + "", t = t + "";
        (r = pi.exec(e)) && (a = Ya.exec(t));)(i = a.index) > n && (i = t.slice(n, i), u[o] ? u[o] += i : u[++o] = i), (r = r[0]) === (a = a[0]) ? u[o] ? u[o] += a : u[++o] = a : (u[++o] = null, l.push({
        i: o,
        x: Yn(r, a)
    })), n = Ya.lastIndex;
    return n < t.length && (i = t.slice(n), u[o] ? u[o] += i : u[++o] = i), u.length < 2 ? l[0] ? tb(l[0].x) : eb(t) : (t = l.length, function(c) {
        for (var f = 0, h; f < t; ++f) u[(h = l[f]).i] = h.x(c);
        return u.join("")
    })
}

function Lt(e, t) {
    var n = typeof t,
        r;
    return t == null || n === "boolean" ? _a(t) : (n === "number" ? Yn : n === "string" ? (r = qn(t)) ? (t = r, cl) : nb : t instanceof qn ? cl : t instanceof Date ? Qm : Xm(t) ? Km : Array.isArray(t) ? Zm : typeof t.valueOf != "function" && typeof t.toString != "function" || isNaN(t) ? Jm : Yn)(e, t)
}

function rb(e, t) {
    return e = +e, t = +t,
        function(n) {
            return Math.round(e * (1 - n) + t * n)
        }
}

function yc(e) {
    return function t(n) {
        n = +n;

        function r(a, i) {
            var o = e((a = Ke(a)).h, (i = Ke(i)).h),
                u = qt(a.s, i.s),
                l = qt(a.l, i.l),
                c = qt(a.opacity, i.opacity);
            return function(f) {
                return a.h = o(f), a.s = u(f), a.l = l(Math.pow(f, n)), a.opacity = c(f), a + ""
            }
        }
        return r.gamma = t, r
    }(1)
}
yc(Vm);
var Ao = yc(qt),
    jr = function(e) {
        if (e !== null) switch (typeof e) {
            case "undefined":
                return !1;
            case "number":
                return !isNaN(e) && e !== Number.POSITIVE_INFINITY && e !== Number.NEGATIVE_INFINITY;
            case "string":
                return !0;
            case "boolean":
                return !1;
            case "object":
                return e instanceof Date || Array.isArray(e) || ne(e);
            case "function":
                return !0
        }
        return !1
    },
    mc = function(e, t) {
        var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 0;
        return function(r) {
            return r < n ? e : t
        }
    },
    bc = function(e, t) {
        return function(n) {
            return n >= 1 ? t : function() {
                var r = typeof e == "function" ? e.apply(this, arguments) : e,
                    a = typeof t == "function" ? t.apply(this, arguments) : t;
                return Lt(r, a)(n)
            }
        }
    },
    pc = function(e, t) {
        var n = function(u, l) {
                return u === l || !jr(u) || !jr(l) ? mc(u, l) : typeof u == "function" || typeof l == "function" ? bc(u, l) : typeof u == "object" && ne(u) || typeof l == "object" && ne(l) ? pc(u, l) : Lt(u, l)
            },
            r = function(u) {
                return Array.isArray(u) ? po(u, "key") : u
            },
            a = {},
            i = {},
            o;
        (e === null || typeof e != "object") && (e = {}), (t === null || typeof t != "object") && (t = {});
        for (o in t) o in e ? a[o] = n(r(e[o]), r(t[o])) : i[o] = t[o];
        return function(u) {
            for (o in a) i[o] = a[o](u);
            return i
        }
    },
    ab = function(e, t) {
        var n = function(r) {
            return typeof r == "string" ? r.replace(/,/g, "") : r
        };
        return Lt(n(e), n(t))
    },
    ib = function(e, t) {
        return e === t || !jr(e) || !jr(t) ? mc(e, t) : typeof e == "function" || typeof t == "function" ? bc(e, t) : ne(e) || ne(t) ? pc(e, t) : typeof e == "string" || typeof t == "string" ? ab(e, t) : Lt(e, t)
    },
    Xt = 0,
    Pn = 0,
    Tn = 0,
    _c = 1e3,
    Rr, kn, Fr = 0,
    Pt = 0,
    xa = 0,
    Kn = typeof performance == "object" && performance.now ? performance : Date,
    xc = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
        setTimeout(e, 17)
    };

function Wr() {
    return Pt || (xc(ob), Pt = Kn.now() + xa)
}

function ob() {
    Pt = 0
}

function _i() {
    this._call = this._time = this._next = null
}
_i.prototype = wc.prototype = {
    constructor: _i,
    restart: function(e, t, n) {
        if (typeof e != "function") throw new TypeError("callback is not a function");
        n = (n == null ? Wr() : +n) + (t == null ? 0 : +t), !this._next && kn !== this && (kn ? kn._next = this : Rr = this, kn = this), this._call = e, this._time = n, xi()
    },
    stop: function() {
        this._call && (this._call = null, this._time = 1 / 0, xi())
    }
};

function wc(e, t, n) {
    var r = new _i;
    return r.restart(e, t, n), r
}

function ub() {
    Wr(), ++Xt;
    for (var e = Rr, t; e;)(t = Pt - e._time) >= 0 && e._call.call(null, t), e = e._next;
    --Xt
}

function fl() {
    Pt = (Fr = Kn.now()) + xa, Xt = Pn = 0;
    try {
        ub()
    } finally {
        Xt = 0, cb(), Pt = 0
    }
}

function lb() {
    var e = Kn.now(),
        t = e - Fr;
    t > _c && (xa -= t, Fr = e)
}

function cb() {
    for (var e, t = Rr, n, r = 1 / 0; t;) t._call ? (r > t._time && (r = t._time), e = t, t = t._next) : (n = t._next, t._next = null, t = e ? e._next = n : Rr = n);
    kn = e, xi(r)
}

function xi(e) {
    if (!Xt) {
        Pn && (Pn = clearTimeout(Pn));
        var t = e - Pt;
        t > 24 ? (e < 1 / 0 && (Pn = setTimeout(fl, e - Kn.now() - xa)), Tn && (Tn = clearInterval(Tn))) : (Tn || (Fr = Kn.now(), Tn = setInterval(lb, _c)), Xt = 1, xc(fl))
    }
}

function fb(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function sl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function sb(e, t, n) {
    return t && sl(e.prototype, t), n && sl(e, n), e
}
var hl = function() {
        function e() {
            fb(this, e), this.shouldAnimate = !0, this.subscribers = [], this.loop = this.loop.bind(this), this.timer = null, this.activeSubscriptions = 0
        }
        return sb(e, [{
            key: "bypassAnimation",
            value: function() {
                this.shouldAnimate = !1
            }
        }, {
            key: "resumeAnimation",
            value: function() {
                this.shouldAnimate = !0
            }
        }, {
            key: "loop",
            value: function() {
                this.subscribers.forEach(function(n) {
                    n.callback(Wr() - n.startTime, n.duration)
                })
            }
        }, {
            key: "start",
            value: function() {
                this.timer || (this.timer = wc(this.loop))
            }
        }, {
            key: "stop",
            value: function() {
                this.timer && (this.timer.stop(), this.timer = null)
            }
        }, {
            key: "subscribe",
            value: function(n, r) {
                r = this.shouldAnimate ? r : 0;
                var a = this.subscribers.push({
                    startTime: Wr(),
                    callback: n,
                    duration: r
                });
                return this.activeSubscriptions++, this.start(), a
            }
        }, {
            key: "unsubscribe",
            value: function(n) {
                n !== null && this.subscribers[n - 1] && (delete this.subscribers[n - 1], this.activeSubscriptions--), this.activeSubscriptions === 0 && this.stop()
            }
        }]), e
    }(),
    Ac = A.createContext({
        transitionTimer: new hl,
        animationTimer: new hl
    });
Ac.displayName = "TimerContext";
var wa = Ac,
    dl = Array.isArray,
    vl = Object.keys,
    hb = Object.prototype.hasOwnProperty,
    db = typeof Element < "u";

function wi(e, t) {
    if (e === t) return !0;
    if (e && t && typeof e == "object" && typeof t == "object") {
        var n = dl(e),
            r = dl(t),
            a, i, o;
        if (n && r) {
            if (i = e.length, i != t.length) return !1;
            for (a = i; a-- !== 0;)
                if (!wi(e[a], t[a])) return !1;
            return !0
        }
        if (n != r) return !1;
        var u = e instanceof Date,
            l = t instanceof Date;
        if (u != l) return !1;
        if (u && l) return e.getTime() == t.getTime();
        var c = e instanceof RegExp,
            f = t instanceof RegExp;
        if (c != f) return !1;
        if (c && f) return e.toString() == t.toString();
        var h = vl(e);
        if (i = h.length, i !== vl(t).length) return !1;
        for (a = i; a-- !== 0;)
            if (!hb.call(t, h[a])) return !1;
        if (db && e instanceof Element && t instanceof Element) return e === t;
        for (a = i; a-- !== 0;)
            if (o = h[a], !(o === "_owner" && e.$$typeof) && !wi(e[o], t[o])) return !1;
        return !0
    }
    return e !== e && t !== t
}
var qe = function(t, n) {
    try {
        return wi(t, n)
    } catch (r) {
        if (r.message && r.message.match(/stack|recursion/i) || r.number === -2146828260) return console.warn("Warning: react-fast-compare does not handle circular references.", r.name, r.message), !1;
        throw r
    }
};

function vb(e) {
    return mb(e) || yb(e) || gb()
}

function gb() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function yb(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function mb(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function bb(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function gl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function pb(e, t, n) {
    return t && gl(e.prototype, t), n && gl(e, n), e
}

function _b(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : Oc(e)
}

function xb(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function Oc(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}
var cr = function(e) {
    xb(t, e);

    function t(n, r) {
        var a;
        return bb(this, t), a = _b(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n, r)), a.state = {
            data: Array.isArray(a.props.data) ? a.props.data[0] : a.props.data,
            animationInfo: {
                progress: 0,
                animating: !1
            }
        }, a.interpolator = null, a.queue = Array.isArray(a.props.data) ? a.props.data.slice(1) : [], a.ease = H5[a.toNewName(a.props.easing)], a.functionToBeRunEachFrame = a.functionToBeRunEachFrame.bind(Oc(a)), a.timer = a.context.animationTimer, a
    }
    return pb(t, [{
        key: "componentDidMount",
        value: function() {
            this.queue.length && this.traverseQueue()
        }
    }, {
        key: "componentDidUpdate",
        value: function(r) {
            var a = qe(this.props, r);
            if (!a)
                if (this.interpolator && this.state.animationInfo && this.state.animationInfo.progress < 1) this.setState({
                    data: this.interpolator(1),
                    animationInfo: {
                        progress: 1,
                        animating: !1,
                        terminating: !0
                    }
                });
                else {
                    if (this.timer.unsubscribe(this.loopID), !Array.isArray(this.props.data)) this.queue.length = 0, this.queue.push(this.props.data);
                    else {
                        var i;
                        (i = this.queue).push.apply(i, vb(this.props.data))
                    }
                    this.traverseQueue()
                }
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            this.loopID ? this.timer.unsubscribe(this.loopID) : this.timer.stop()
        }
    }, {
        key: "toNewName",
        value: function(r) {
            var a = function(i) {
                return i && i[0].toUpperCase() + i.slice(1)
            };
            return "ease".concat(a(r))
        }
    }, {
        key: "traverseQueue",
        value: function() {
            var r = this;
            if (this.queue.length) {
                var a = this.queue[0];
                this.interpolator = ib(this.state.data, a), this.props.delay ? setTimeout(function() {
                    r.loopID = r.timer.subscribe(r.functionToBeRunEachFrame, r.props.duration)
                }, this.props.delay) : this.loopID = this.timer.subscribe(this.functionToBeRunEachFrame, this.props.duration)
            } else this.props.onEnd && this.props.onEnd()
        }
    }, {
        key: "functionToBeRunEachFrame",
        value: function(r, a) {
            a = a !== void 0 ? a : this.props.duration;
            var i = a ? r / a : 1;
            if (i >= 1) {
                this.setState({
                    data: this.interpolator(1),
                    animationInfo: {
                        progress: 1,
                        animating: !1,
                        terminating: !0
                    }
                }), this.loopID && this.timer.unsubscribe(this.loopID), this.queue.shift(), this.traverseQueue();
                return
            }
            this.setState({
                data: this.interpolator(this.ease(i)),
                animationInfo: {
                    progress: i,
                    animating: i < 1
                }
            })
        }
    }, {
        key: "render",
        value: function() {
            return this.props.children(this.state.data, this.state.animationInfo)
        }
    }]), t
}(A.Component);
Object.defineProperty(cr, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryAnimation"
});
Object.defineProperty(cr, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        children: s.func,
        data: s.oneOfType([s.object, s.array]),
        delay: s.number,
        duration: s.number,
        easing: s.oneOf(["back", "backIn", "backOut", "backInOut", "bounce", "bounceIn", "bounceOut", "bounceInOut", "circle", "circleIn", "circleOut", "circleInOut", "linear", "linearIn", "linearOut", "linearInOut", "cubic", "cubicIn", "cubicOut", "cubicInOut", "elastic", "elasticIn", "elasticOut", "elasticInOut", "exp", "expIn", "expOut", "expInOut", "poly", "polyIn", "polyOut", "polyInOut", "quad", "quadIn", "quadOut", "quadInOut", "sin", "sinIn", "sinOut", "sinInOut"]),
        onEnd: s.func
    }
});
Object.defineProperty(cr, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        data: {},
        delay: 0,
        duration: 1e3,
        easing: "quadInOut"
    }
});
Object.defineProperty(cr, "contextType", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: wa
});
var wb = q0,
    Ab = 0;

function Ob(e) {
    var t = ++Ab;
    return wb(e) + t
}
var Oo = Ob;

function Tb(e, t, n) {
    switch (n.length) {
        case 0:
            return e.call(t);
        case 1:
            return e.call(t, n[0]);
        case 2:
            return e.call(t, n[0], n[1]);
        case 3:
            return e.call(t, n[0], n[1], n[2])
    }
    return e.apply(t, n)
}
var Sb = Tb,
    Eb = Sb,
    yl = Math.max;

function Mb(e, t, n) {
    return t = yl(t === void 0 ? e.length - 1 : t, 0),
        function() {
            for (var r = arguments, a = -1, i = yl(r.length - t, 0), o = Array(i); ++a < i;) o[a] = r[t + a];
            a = -1;
            for (var u = Array(t + 1); ++a < t;) u[a] = r[a];
            return u[t] = n(o), Eb(e, this, u)
        }
}
var Tc = Mb;

function Cb(e) {
    return function() {
        return e
    }
}
var $b = Cb,
    Pb = Dt,
    kb = function() {
        try {
            var e = Pb(Object, "defineProperty");
            return e({}, "", {}), e
        } catch (t) {}
    }(),
    Sc = kb,
    Ib = $b,
    ml = Sc,
    Db = Re,
    Nb = ml ? function(e, t) {
        return ml(e, "toString", {
            configurable: !0,
            enumerable: !1,
            value: Ib(t),
            writable: !0
        })
    } : Db,
    Lb = Nb,
    jb = 800,
    Rb = 16,
    Fb = Date.now;

function Wb(e) {
    var t = 0,
        n = 0;
    return function() {
        var r = Fb(),
            a = Rb - (r - n);
        if (n = r, a > 0) {
            if (++t >= jb) return arguments[0]
        } else t = 0;
        return e.apply(void 0, arguments)
    }
}
var zb = Wb,
    Ub = Lb,
    Hb = zb,
    Bb = Hb(Ub),
    Ec = Bb,
    Gb = Re,
    qb = Tc,
    Vb = Ec;

function Yb(e, t) {
    return Vb(qb(e, t, Gb), e + "")
}
var Aa = Yb,
    Kb = on,
    Xb = tt,
    Zb = ya,
    Qb = Te;

function Jb(e, t, n) {
    if (!Qb(n)) return !1;
    var r = typeof t;
    return (r == "number" ? Xb(n) && Zb(t, n.length) : r == "string" && t in n) ? Kb(n[t], e) : !1
}
var Oa = Jb;

function e7(e) {
    var t = [];
    if (e != null)
        for (var n in Object(e)) t.push(n);
    return t
}
var t7 = e7,
    n7 = Te,
    r7 = ma,
    a7 = t7,
    i7 = Object.prototype,
    o7 = i7.hasOwnProperty;

function u7(e) {
    if (!n7(e)) return a7(e);
    var t = r7(e),
        n = [];
    for (var r in e) r == "constructor" && (t || !o7.call(e, r)) || n.push(r);
    return n
}
var l7 = u7,
    c7 = ec,
    f7 = l7,
    s7 = tt;

function h7(e) {
    return s7(e) ? c7(e, !0) : f7(e)
}
var Mc = h7,
    d7 = Aa,
    v7 = on,
    g7 = Oa,
    y7 = Mc,
    Cc = Object.prototype,
    m7 = Cc.hasOwnProperty,
    b7 = d7(function(e, t) {
        e = Object(e);
        var n = -1,
            r = t.length,
            a = r > 2 ? t[2] : void 0;
        for (a && g7(t[0], t[1], a) && (r = 1); ++n < r;)
            for (var i = t[n], o = y7(i), u = -1, l = o.length; ++u < l;) {
                var c = o[u],
                    f = e[c];
                (f === void 0 || v7(f, Cc[c]) && !m7.call(e, c)) && (e[c] = i[c])
            }
        return e
    }),
    p7 = b7,
    L = p7,
    bl = Sc;

function _7(e, t, n) {
    t == "__proto__" && bl ? bl(e, t, {
        configurable: !0,
        enumerable: !0,
        value: n,
        writable: !0
    }) : e[t] = n
}
var To = _7,
    x7 = To,
    w7 = on,
    A7 = Object.prototype,
    O7 = A7.hasOwnProperty;

function T7(e, t, n) {
    var r = e[t];
    (!(O7.call(e, t) && w7(r, n)) || n === void 0 && !(t in e)) && x7(e, t, n)
}
var So = T7,
    S7 = So,
    E7 = To;

function M7(e, t, n, r) {
    var a = !n;
    n || (n = {});
    for (var i = -1, o = t.length; ++i < o;) {
        var u = t[i],
            l = r ? r(n[u], e[u], u, n, e) : void 0;
        l === void 0 && (l = e[u]), a ? E7(n, u, l) : S7(n, u, l)
    }
    return n
}
var C7 = M7,
    $7 = Aa,
    P7 = Oa;

function k7(e) {
    return $7(function(t, n) {
        var r = -1,
            a = n.length,
            i = a > 1 ? n[a - 1] : void 0,
            o = a > 2 ? n[2] : void 0;
        for (i = e.length > 3 && typeof i == "function" ? (a--, i) : void 0, o && P7(n[0], n[1], o) && (i = a < 3 ? void 0 : i, a = 1), t = Object(t); ++r < a;) {
            var u = n[r];
            u && e(t, u, r, i)
        }
        return t
    })
}
var I7 = k7,
    D7 = So,
    N7 = C7,
    L7 = I7,
    j7 = tt,
    R7 = ma,
    F7 = Nt,
    W7 = Object.prototype,
    z7 = W7.hasOwnProperty,
    U7 = L7(function(e, t) {
        if (R7(t) || j7(t)) {
            N7(t, F7(t), e);
            return
        }
        for (var n in t) z7.call(t, n) && D7(e, n, t[n])
    }),
    H7 = U7,
    S = H7,
    B7 = lt,
    G7 = et,
    q7 = "[object RegExp]";

function V7(e) {
    return G7(e) && B7(e) == q7
}
var Y7 = V7,
    K7 = Y7,
    X7 = lr,
    pl = Bn.exports,
    _l = pl && pl.isRegExp,
    Z7 = _l ? X7(_l) : K7,
    $c = Z7,
    Q7 = mt,
    J7 = tt,
    e3 = Nt;

function t3(e) {
    return function(t, n, r) {
        var a = Object(t);
        if (!J7(t)) {
            var i = Q7(n);
            t = e3(t), n = function(u) {
                return i(a[u], u, a)
            }
        }
        var o = e(t, n, r);
        return o > -1 ? a[i ? t[o] : o] : void 0
    }
}
var n3 = t3;

function r3(e, t, n, r) {
    for (var a = e.length, i = n + (r ? 1 : -1); r ? i-- : ++i < a;)
        if (t(e[i], i, e)) return i;
    return -1
}
var Pc = r3,
    a3 = /\s/;

function i3(e) {
    for (var t = e.length; t-- && a3.test(e.charAt(t)););
    return t
}
var o3 = i3,
    u3 = o3,
    l3 = /^\s+/;

function c3(e) {
    return e && e.slice(0, u3(e) + 1).replace(l3, "")
}
var f3 = c3,
    s3 = f3,
    xl = Te,
    h3 = or,
    wl = 0 / 0,
    d3 = /^[-+]0x[0-9a-f]+$/i,
    v3 = /^0b[01]+$/i,
    g3 = /^0o[0-7]+$/i,
    y3 = parseInt;

function m3(e) {
    if (typeof e == "number") return e;
    if (h3(e)) return wl;
    if (xl(e)) {
        var t = typeof e.valueOf == "function" ? e.valueOf() : e;
        e = xl(t) ? t + "" : t
    }
    if (typeof e != "string") return e === 0 ? e : +e;
    e = s3(e);
    var n = v3.test(e);
    return n || g3.test(e) ? y3(e.slice(2), n ? 2 : 8) : d3.test(e) ? wl : +e
}
var kc = m3,
    b3 = kc,
    Al = 1 / 0,
    p3 = 17976931348623157e292;

function _3(e) {
    if (!e) return e === 0 ? e : 0;
    if (e = b3(e), e === Al || e === -Al) {
        var t = e < 0 ? -1 : 1;
        return t * p3
    }
    return e === e ? e : 0
}
var Ic = _3,
    x3 = Ic;

function w3(e) {
    var t = x3(e),
        n = t % 1;
    return t === t ? n ? t - n : t : 0
}
var Dc = w3,
    A3 = Pc,
    O3 = mt,
    T3 = Dc,
    S3 = Math.max;

function E3(e, t, n) {
    var r = e == null ? 0 : e.length;
    if (!r) return -1;
    var a = n == null ? 0 : T3(n);
    return a < 0 && (a = S3(r + a, 0)), A3(e, O3(t), a)
}
var M3 = E3,
    C3 = n3,
    $3 = M3,
    P3 = C3($3),
    k3 = P3;

function I3(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
var ct = function(e) {
        var t = function(r, a, i, o) {
                var u = a[i];
                if (u == null) return r ? new Error("Required `".concat(i, "` was not specified in `").concat(o, "`.")) : null;
                for (var l = arguments.length, c = new Array(l > 4 ? l - 4 : 0), f = 4; f < l; f++) c[f - 4] = arguments[f];
                return e.apply(void 0, [a, i, o].concat(c))
            },
            n = t.bind(null, !1);
        return n.isRequired = t.bind(null, !0), n
    },
    D3 = function() {
        return null
    },
    N3 = function() {},
    Ol = function(e) {
        return e === void 0 ? N3 : e === null ? D3 : e.constructor
    },
    Tl = function(e) {
        return e === void 0 ? "undefined" : e === null ? "null" : Object.prototype.toString.call(e).slice(8, -1)
    };

function L3(e, t) {
    return function(n, r, a) {
        return n[r], s.checkPropTypes(I3({}, r, e), n, r, a)
    }
}

function Be(e) {
    return ct(function(t, n, r) {
        for (var a = arguments.length, i = new Array(a > 3 ? a - 3 : 0), o = 3; o < a; o++) i[o - 3] = arguments[o];
        return e.reduce(function(u, l) {
            return u || l.apply(void 0, [t, n, r].concat(i))
        }, void 0)
    })
}
var G = ct(function(e, t, n) {
        var r = e[t];
        if (typeof r != "number" || r < 0) return new Error("`".concat(t, "` in `").concat(n, "` must be a non-negative number."))
    }),
    Le = ct(function(e, t, n) {
        var r = e[t];
        if (typeof r != "number" || r % 1 !== 0) return new Error("`".concat(t, "` in `").concat(n, "` must be an integer."))
    });
ct(function(e, t, n) {
    var r = e[t];
    if (typeof r != "number" || r <= 0) return new Error("`".concat(t, "` in `").concat(n, "` must be a number greater than zero."))
});
var zt = ct(function(e, t, n) {
        var r = e[t];
        if (!Array.isArray(r) || r.length !== 2 || r[1] === r[0]) return new Error("`".concat(t, "` in `").concat(n, "` must be an array of two unique numeric values."))
    }),
    Ve = ct(function(e, t, n) {
        var r = ["linear", "time", "log", "sqrt"],
            a = function(o) {
                return H(o) ? H(o.copy) && H(o.domain) && H(o.range) : typeof o == "string" ? r.indexOf(o) !== -1 : !1
            },
            i = e[t];
        if (!a(i)) return new Error("`".concat(t, "` in `").concat(n, "` must be a d3 scale."))
    });
ct(function(e, t, n) {
    var r = e[t];
    if (!Array.isArray(r)) return new Error("`".concat(t, "` in `").concat(n, "` must be an array."));
    if (!(r.length < 2)) {
        var a = Ol(r[0]),
            i = k3(r, function(l) {
                return a !== Ol(l)
            });
        if (i) {
            var o = Tl(r[0]),
                u = Tl(i);
            return new Error("Expected `".concat(t, "` in `").concat(n, "` to be a ") + "homogeneous array, but found types `".concat(o, "` and ") + "`".concat(u, "`."))
        }
    }
});
ct(function(e, t) {
    if (e[t] && Array.isArray(e[t]) && e[t].length !== e.data.length) return new Error("Length of data and ".concat(t, " arrays must match."))
});
var j3 = ct(function(e, t, n) {
    if (e[t] && !$c(e[t])) return new Error("`".concat(t, "` in `").concat(n, "` must be a regular expression."))
});

function R3(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function Sl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function F3(e, t, n) {
    return t && Sl(e.prototype, t), n && Sl(e, n), e
}

function W3(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : $r(e)
}

function z3(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function $r(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}
var Eo = function(e) {
    z3(t, e);

    function t(n) {
        var r;
        return R3(this, t), r = W3(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n)), r.map = {}, r.index = 1, r.portalUpdate = r.portalUpdate.bind($r(r)), r.portalRegister = r.portalRegister.bind($r(r)), r.portalDeregister = r.portalDeregister.bind($r(r)), r
    }
    return F3(t, [{
        key: "portalRegister",
        value: function() {
            return ++this.index
        }
    }, {
        key: "portalUpdate",
        value: function(r, a) {
            this.map[r] = a, this.forceUpdate()
        }
    }, {
        key: "portalDeregister",
        value: function(r) {
            delete this.map[r], this.forceUpdate()
        }
    }, {
        key: "getChildren",
        value: function() {
            var r = this;
            return ee(this.map).map(function(a) {
                var i = r.map[a];
                return i && A.cloneElement(i, {
                    key: a
                })
            })
        }
    }, {
        key: "render",
        value: function() {
            return A.createElement("svg", this.props, this.getChildren())
        }
    }]), t
}(A.Component);
Object.defineProperty(Eo, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "Portal"
});
Object.defineProperty(Eo, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        className: s.string,
        height: G,
        style: s.object,
        viewBox: s.string,
        width: G
    }
});
var Nc = A.createContext({});
Nc.displayName = "PortalContext";
var Lc = Nc,
    U3 = So,
    H3 = da,
    B3 = ya,
    El = Te,
    G3 = ur;

function q3(e, t, n, r) {
    if (!El(e)) return e;
    t = H3(t, e);
    for (var a = -1, i = t.length, o = i - 1, u = e; u != null && ++a < i;) {
        var l = G3(t[a]),
            c = n;
        if (l === "__proto__" || l === "constructor" || l === "prototype") return e;
        if (a != o) {
            var f = u[l];
            c = r ? r(f, l, u) : void 0, c === void 0 && (c = El(f) ? f : B3(t[a + 1]) ? [] : {})
        }
        U3(u, l, c), u = u[l]
    }
    return e
}
var V3 = q3,
    Y3 = va,
    K3 = V3,
    X3 = da;

function Z3(e, t, n) {
    for (var r = -1, a = t.length, i = {}; ++r < a;) {
        var o = t[r],
            u = Y3(e, o);
        n(u, o) && K3(i, X3(o, e), u)
    }
    return i
}
var jc = Z3,
    Q3 = jc,
    J3 = cc;

function ep(e, t) {
    return Q3(e, t, function(n, r) {
        return J3(e, r)
    })
}
var tp = ep,
    Ml = ir,
    np = ga,
    rp = _e,
    Cl = Ml ? Ml.isConcatSpreadable : void 0;

function ap(e) {
    return rp(e) || np(e) || !!(Cl && e && e[Cl])
}
var ip = ap,
    op = ho,
    up = ip;

function Rc(e, t, n, r, a) {
    var i = -1,
        o = e.length;
    for (n || (n = up), a || (a = []); ++i < o;) {
        var u = e[i];
        t > 0 && n(u) ? t > 1 ? Rc(u, t - 1, n, r, a) : op(a, u) : r || (a[a.length] = u)
    }
    return a
}
var Fc = Rc,
    lp = Fc;

function cp(e) {
    var t = e == null ? 0 : e.length;
    return t ? lp(e, 1) : []
}
var Zt = cp,
    fp = Zt,
    sp = Tc,
    hp = Ec;

function dp(e) {
    return hp(sp(e, void 0, fp), e + "")
}
var vp = dp,
    gp = tp,
    yp = vp,
    mp = yp(function(e, t) {
        return e == null ? {} : gp(e, t)
    }),
    Xn = mp;

function bp(e, t) {
    var n = t !== "x",
        r = Xe(e);
    return n ? [e.height - r.bottom, r.top] : [r.left, e.width - r.right]
}

function pp(e, t) {
    if (t === "x") {
        var n = Ai(e.startAngle || 0),
            r = Ai(e.endAngle || 360);
        return [n, r]
    }
    return [e.innerRadius || 0, Oi(e)]
}

function fr(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [],
        n = {};
    for (var r in e) t.indexOf(r) >= 0 || !Object.prototype.hasOwnProperty.call(e, r) || (n[r] = e[r]);
    return n
}

function Mo(e) {
    var t = function(y) {
            return y !== void 0
        },
        n = e._x,
        r = e._x1,
        a = e._x0,
        i = e._voronoiX,
        o = e._y,
        u = e._y1,
        l = e._y0,
        c = e._voronoiY,
        f = t(r) ? r : n,
        h = t(u) ? u : o,
        d = {
            x: t(i) ? i : f,
            x0: t(a) ? a : n,
            y: t(c) ? c : h,
            y0: t(l) ? l : o
        };
    return L({}, d, e)
}

function Ta(e, t) {
    var n = e.scale,
        r = e.polar,
        a = e.horizontal,
        i = Mo(t),
        o = e.origin || {
            x: 0,
            y: 0
        },
        u = a ? n.y(i.y) : n.x(i.x),
        l = a ? n.y(i.y0) : n.x(i.x0),
        c = a ? n.x(i.x) : n.y(i.y),
        f = a ? n.x(i.x0) : n.y(i.y0);
    return {
        x: r ? c * Math.cos(u) + o.x : u,
        x0: r ? f * Math.cos(l) + o.x : l,
        y: r ? -c * Math.sin(u) + o.y : c,
        y0: r ? -f * Math.sin(l) + o.x : f
    }
}

function Xe(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "padding",
        n = e[t],
        r = typeof n == "number" ? n : 0,
        a = typeof n == "object" ? n : {};
    return {
        top: a.top || r,
        bottom: a.bottom || r,
        left: a.left || r,
        right: a.right || r
    }
}

function Wc(e) {
    var t = e && e.type && e.type.role;
    return t === "tooltip"
}

function _p(e, t) {
    var n = e.theme,
        r = n === void 0 ? {} : n,
        a = e.labelComponent,
        i = r[t] && r[t].style || {};
    if (!Wc(a)) return i;
    var o = r.tooltip && r.tooltip.style || {},
        u = L({}, o, i.labels);
    return L({}, {
        labels: u
    }, i)
}

function zc(e, t) {
    var n = "100%",
        r = "100%";
    if (!e) return L({
        parent: {
            height: r,
            width: n
        }
    }, t);
    var a = e.data,
        i = e.labels,
        o = e.parent,
        u = t && t.parent || {},
        l = t && t.labels || {},
        c = t && t.data || {};
    return {
        parent: L({}, o, u, {
            width: n,
            height: r
        }),
        labels: L({}, i, l),
        data: L({}, a, c)
    }
}

function R(e, t) {
    return H(e) ? e(t) : e
}

function Ye(e, t) {
    return t.disableInlineStyles ? {} : !e || !ee(e).some(function(n) {
        return H(e[n])
    }) ? e : ee(e).reduce(function(n, r) {
        return n[r] = R(e[r], t), n
    }, {})
}

function Ai(e) {
    return typeof e == "number" ? e * (Math.PI / 180) : e
}

function xp(e) {
    return typeof e == "number" ? e / (Math.PI / 180) : e
}

function Oi(e) {
    var t = Xe(e),
        n = t.left,
        r = t.right,
        a = t.top,
        i = t.bottom,
        o = e.width,
        u = e.height;
    return Math.min(o - n - r, u - a - i) / 2
}

function Uc(e) {
    var t = e.width,
        n = e.height,
        r = Xe(e),
        a = r.top,
        i = r.bottom,
        o = r.left,
        u = r.right,
        l = Math.min(t - o - u, n - a - i) / 2,
        c = t / 2 + o - u,
        f = n / 2 + a - i;
    return {
        x: c + l > t ? l + o - u : c,
        y: f + l > n ? l + a - i : f
    }
}

function Ze(e, t) {
    return e.range && e.range[t] ? e.range[t] : e.range && Array.isArray(e.range) ? e.range : e.polar ? pp(e, t) : bp(e, t)
}

function Sa(e) {
    return H(e) ? e : e == null ? function(t) {
        return t
    } : mo(e)
}

function hn(e, t, n) {
    var r = e.theme && e.theme[n] ? e.theme[n] : {},
        a = fr(r, ["style"]),
        i = wp(e),
        o = i === void 0 ? {} : {
            horizontal: i
        };
    return L(o, e, a, t)
}

function Hc(e, t) {
    var n = e === "x" ? "y" : "x";
    return t ? n : e
}

function jt(e, t) {
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {},
        r = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : [],
        a = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : function(l, c) {
            return l.concat(c)
        },
        i = ["data", "domain", "categories", "polar", "startAngle", "endAngle", "minDomain", "maxDomain", "horizontal"],
        o = function(l, c, f) {
            return l.reduce(function(h, d, y) {
                var v = d.type && d.type.role,
                    b = d.props.name || "".concat(v, "-").concat(c[y]);
                if (d.props && d.props.children) {
                    var g = S({}, d.props, Xn(n, i)),
                        p = d.type && d.type.role === "stack" && H(d.type.getChildren) ? d.type.getChildren(g) : A.Children.toArray(d.props.children).map(function(O) {
                            var T = S({}, O.props, Xn(g, i));
                            return A.cloneElement(O, T)
                        }),
                        m = p.map(function(O, T) {
                            return "".concat(b, "-").concat(T)
                        }),
                        _ = o(p, m, d);
                    h = a(h, _)
                } else {
                    var w = t(d, b, f);
                    w && (h = a(h, w))
                }
                return h
            }, r)
        },
        u = e.map(function(l, c) {
            return c
        });
    return o(e, u)
}

function wp(e) {
    if (e.horizontal !== void 0 || !e.children) return e.horizontal;
    var t = function(n) {
        return n.reduce(function(r, a) {
            var i = a.props || {};
            return r || i.horizontal || !i.children ? (r = r || i.horizontal, r) : t(A.Children.toArray(i.children))
        }, !1)
    };
    return t(A.Children.toArray(e.children))
}

function Ap(e, t) {
    return Sp(e) || Tp(e, t) || Op()
}

function Op() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function Tp(e, t) {
    var n = [],
        r = !0,
        a = !1,
        i = void 0;
    try {
        for (var o = e[Symbol.iterator](), u; !(r = (u = o.next()).done) && (n.push(u.value), !(t && n.length === t)); r = !0);
    } catch (l) {
        a = !0, i = l
    } finally {
        try {
            !r && o.return != null && o.return()
        } finally {
            if (a) throw i
        }
    }
    return n
}

function Sp(e) {
    if (Array.isArray(e)) return e
}

function Ep(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            Mp(e, a, n[a])
        })
    }
    return e
}

function Mp(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
var Bc = {
        startsWith: ["data-", "aria-"],
        exactMatch: []
    },
    Cp = function(e) {
        var t = !1;
        return Bc.startsWith.forEach(function(n) {
            var r = new RegExp("\\b(".concat(n, ")(\\w|-)+"), "g");
            r.test(e) && (t = !0)
        }), t
    },
    $p = function(e) {
        return Bc.exactMatch.includes(e)
    },
    Pp = function(e) {
        return !!(Cp(e) || $p(e))
    },
    Ea = function(e) {
        var t = Ep({}, e);
        return Object.fromEntries(Object.entries(t).filter(function(n) {
            var r = Ap(n, 1),
                a = r[0];
            return Pp(a)
        }))
    };

function zr() {
    return zr = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, zr.apply(this, arguments)
}

function Ka(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            kp(e, a, n[a])
        })
    }
    return e
}

function kp(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function Ip(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function $l(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function Dp(e, t, n) {
    return t && $l(e.prototype, t), n && $l(e, n), e
}

function Np(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : Lp(e)
}

function Lp(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function jp(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var Qe = function(e) {
    jp(t, e);

    function t(n) {
        var r;
        return Ip(this, t), r = Np(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n)), r.containerId = !Te(n) || n.containerId === void 0 ? Oo("victory-container-") : n.containerId, r.savePortalRef = function(a) {
            return r.portalRef = a, a
        }, r.portalUpdate = function(a, i) {
            return r.portalRef.portalUpdate(a, i)
        }, r.portalRegister = function() {
            return r.portalRef.portalRegister()
        }, r.portalDeregister = function(a) {
            return r.portalRef.portalDeregister(a)
        }, r.saveContainerRef = n && H(n.containerRef) ? n.containerRef : function(a) {
            return r.containerRef = a, a
        }, r.shouldHandleWheel = n && n.events && n.events.onWheel, r.shouldHandleWheel && (r.handleWheel = function(a) {
            return a.preventDefault()
        }), r
    }
    return Dp(t, [{
        key: "componentDidMount",
        value: function() {
            this.shouldHandleWheel && this.containerRef && this.containerRef.addEventListener("wheel", this.handleWheel)
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            this.shouldHandleWheel && this.containerRef && this.containerRef.removeEventListener("wheel", this.handleWheel)
        }
    }, {
        key: "getIdForElement",
        value: function(r) {
            return "".concat(this.containerId, "-").concat(r)
        }
    }, {
        key: "getChildren",
        value: function(r) {
            return r.children
        }
    }, {
        key: "getOUIAProps",
        value: function(r) {
            var a = r.ouiaId,
                i = r.ouiaSafe,
                o = r.ouiaType;
            return Ka({}, a && {
                "data-ouia-component-id": a
            }, o && {
                "data-ouia-component-type": o
            }, i !== void 0 && {
                "data-ouia-safe": i
            })
        }
    }, {
        key: "renderContainer",
        value: function(r, a, i) {
            var o = r.title,
                u = r.desc,
                l = r.portalComponent,
                c = r.className,
                f = r.width,
                h = r.height,
                d = r.portalZIndex,
                y = r.responsive,
                v = this.getChildren(r),
                b = y ? {
                    width: "100%",
                    height: "100%"
                } : {
                    width: f,
                    height: h
                },
                g = S({
                    pointerEvents: "none",
                    touchAction: "none",
                    position: "relative"
                }, b),
                p = S({
                    zIndex: d,
                    position: "absolute",
                    top: 0,
                    left: 0
                }, b),
                m = S({
                    pointerEvents: "all"
                }, b),
                _ = S({
                    overflow: "visible"
                }, b),
                w = {
                    width: f,
                    height: h,
                    viewBox: a.viewBox,
                    preserveAspectRatio: a.preserveAspectRatio,
                    style: _
                };
            return A.createElement(Lc.Provider, {
                value: {
                    portalUpdate: this.portalUpdate,
                    portalRegister: this.portalRegister,
                    portalDeregister: this.portalDeregister
                }
            }, A.createElement("div", zr({
                style: L({}, i, g),
                className: c,
                ref: this.saveContainerRef
            }, this.getOUIAProps(r)), A.createElement("svg", zr({}, a, {
                style: m
            }), o ? A.createElement("title", {
                id: this.getIdForElement("title")
            }, o) : null, u ? A.createElement("desc", {
                id: this.getIdForElement("desc")
            }, u) : null, v), A.createElement("div", {
                style: p
            }, A.cloneElement(l, Ka({}, w, {
                ref: this.savePortalRef
            })))))
        }
    }, {
        key: "render",
        value: function() {
            var r = this.props,
                a = r.width,
                i = r.height,
                o = r.responsive,
                u = r.events,
                l = r.title,
                c = r.desc,
                f = r.tabIndex,
                h = r.preserveAspectRatio,
                d = r.role,
                y = o ? this.props.style : fr(this.props.style, ["height", "width"]),
                v = Ea(this.props),
                b = S(Ka({
                    width: a,
                    height: i,
                    tabIndex: f,
                    role: d,
                    "aria-labelledby": [l && this.getIdForElement("title"), this.props["aria-labelledby"]].filter(Boolean).join(" ") || void 0,
                    "aria-describedby": [c && this.getIdForElement("desc"), this.props["aria-describedby"]].filter(Boolean).join(" ") || void 0,
                    viewBox: o ? "0 0 ".concat(a, " ").concat(i) : void 0,
                    preserveAspectRatio: o ? h : void 0
                }, v), u);
            return this.renderContainer(this.props, b, y)
        }
    }]), t
}(A.Component);
Object.defineProperty(Qe, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryContainer"
});
Object.defineProperty(Qe, "role", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "container"
});
Object.defineProperty(Qe, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        "aria-describedby": s.string,
        "aria-labelledby": s.string,
        children: s.oneOfType([s.arrayOf(s.node), s.node]),
        className: s.string,
        containerId: s.oneOfType([s.number, s.string]),
        containerRef: s.func,
        desc: s.string,
        events: s.object,
        height: G,
        name: s.string,
        origin: s.shape({
            x: G,
            y: G
        }),
        ouiaId: s.oneOfType([s.number, s.string]),
        ouiaSafe: s.bool,
        ouiaType: s.string,
        polar: s.bool,
        portalComponent: s.element,
        portalZIndex: Le,
        preserveAspectRatio: s.string,
        responsive: s.bool,
        role: s.string,
        style: s.object,
        tabIndex: s.number,
        theme: s.object,
        title: s.string,
        width: G
    }
});
Object.defineProperty(Qe, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        className: "VictoryContainer",
        portalComponent: A.createElement(Eo, null),
        portalZIndex: 99,
        responsive: !0,
        role: "img"
    }
});
Object.defineProperty(Qe, "contextType", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: wa
});
var Rp = nc,
    Fp = ic,
    Wp = ga,
    zp = _e,
    Up = tt,
    Hp = Hn.exports,
    Bp = ma,
    Gp = go,
    qp = "[object Map]",
    Vp = "[object Set]",
    Yp = Object.prototype,
    Kp = Yp.hasOwnProperty;

function Xp(e) {
    if (e == null) return !0;
    if (Up(e) && (zp(e) || typeof e == "string" || typeof e.splice == "function" || Hp(e) || Gp(e) || Wp(e))) return !e.length;
    var t = Fp(e);
    if (t == qp || t == Vp) return !e.size;
    if (Bp(e)) return !Rp(e).length;
    for (var n in e)
        if (Kp.call(e, n)) return !1;
    return !0
}
var Zp = Xp,
    re = Zp;

function Qp(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function Pl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function Jp(e, t, n) {
    return t && Pl(e.prototype, t), n && Pl(e, n), e
}

function e_(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : t_(e)
}

function t_(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function n_(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var ot = function(e) {
    n_(t, e);

    function t() {
        return Qp(this, t), e_(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
    }
    return Jp(t, [{
        key: "componentDidMount",
        value: function() {
            this.checkedContext || (typeof this.context.portalUpdate != "function" && (this.renderInPlace = !0), this.checkedContext = !0), this.forceUpdate()
        }
    }, {
        key: "componentDidUpdate",
        value: function() {
            this.renderInPlace || (this.portalKey = this.portalKey || this.context.portalRegister(), this.context.portalUpdate(this.portalKey, this.element))
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            this.context && this.context.portalDeregister && this.context.portalDeregister(this.portalKey)
        }
    }, {
        key: "renderPortal",
        value: function(r) {
            return this.renderInPlace ? r : (this.element = r, null)
        }
    }, {
        key: "render",
        value: function() {
            var r = Array.isArray(this.props.children) ? this.props.children[0] : this.props.children,
                a = this.props.groupComponent,
                i = r && r.props || {},
                o = i.groupComponent ? {
                    groupComponent: a,
                    standalone: !1
                } : {},
                u = L(o, i, fr(this.props, ["children", "groupComponent"])),
                l = r && A.cloneElement(r, u);
            return this.renderPortal(l)
        }
    }]), t
}(A.Component);
Object.defineProperty(ot, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryPortal"
});
Object.defineProperty(ot, "role", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "portal"
});
Object.defineProperty(ot, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        children: s.node,
        groupComponent: s.element
    }
});
Object.defineProperty(ot, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        groupComponent: A.createElement("g", null)
    }
});
Object.defineProperty(ot, "contextType", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: Lc
});

function Ur() {
    return Ur = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Ur.apply(this, arguments)
}

function r_(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        a, i;
    for (i = 0; i < r.length; i++) a = r[i], !(t.indexOf(a) >= 0) && (n[a] = e[a]);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for (i = 0; i < o.length; i++) a = o[i], !(t.indexOf(a) >= 0) && (!Object.prototype.propertyIsEnumerable.call(e, a) || (n[a] = e[a]))
    }
    return n
}
var a_ = function(e) {
        var t = e.desc,
            n = r_(e, ["desc"]);
        return t ? A.createElement("rect", Ur({
            vectorEffect: "non-scaling-stroke"
        }, n), A.createElement("desc", null, t)) : A.createElement("rect", Ur({
            vectorEffect: "non-scaling-stroke"
        }, n))
    },
    Gc = a_;

function i_(e, t) {
    t = t || {};
    var n = t._y >= 0 ? 1 : -1,
        r = e.style && e.style.labels || {};
    return t.verticalAnchor || r.verticalAnchor ? t.verticalAnchor || r.verticalAnchor : e.horizontal ? "middle" : n >= 0 ? "end" : "start"
}

function o_(e, t) {
    t = t || {};
    var n = e.style,
        r = e.horizontal,
        a = t._y >= 0 ? 1 : -1,
        i = n && n.labels || {};
    return t.verticalAnchor || i.verticalAnchor ? t.verticalAnchor || i.verticalAnchor : r ? a >= 0 ? "start" : "end" : "middle"
}

function u_(e, t) {
    t = t || {};
    var n = e.style && e.style.labels || {};
    return t.angle === void 0 ? n.angle : t.angle
}

function l_(e, t) {
    t = t || {};
    var n = e.horizontal,
        r = e.style,
        a = r.labels || {},
        i = R(a.padding, e) || 0,
        o = t._y < 0 ? -1 : 1;
    return {
        x: n ? o * i : 0,
        y: n ? 0 : -1 * o * i
    }
}

function c_(e, t) {
    if (e.polar) return {};
    var n = l_(e, t);
    return {
        dx: n.x,
        dy: n.y
    }
}

function f_(e, t) {
    var n = e.polar,
        r = Ta(e, t),
        a = r.x,
        i = r.y;
    if (n) {
        var o = s_(e, t);
        return {
            x: a + o.x,
            y: i + o.y
        }
    } else return {
        x: a,
        y: i
    }
}

function s_(e, t) {
    var n = e.style,
        r = Zn(e, t),
        a = n.labels || {},
        i = R(a.padding, e) || 0,
        o = Ai(r);
    return {
        x: i * Math.cos(o),
        y: -i * Math.sin(o)
    }
}

function Co(e) {
    var t = e.labelComponent,
        n = e.labelPlacement,
        r = e.polar,
        a = r ? "perpendicular" : "vertical";
    return n || t.props && t.props.labelPlacement || a
}

function h_(e) {
    return e < 45 || e > 315 ? "right" : e >= 45 && e <= 135 ? "top" : e > 135 && e < 225 ? "left" : "bottom"
}

function qc(e, t, n) {
    return t = t || {}, t.label !== void 0 ? t.label : Array.isArray(e.labels) ? e.labels[n] : e.labels
}

function d_(e, t) {
    var n = Co(e);
    return n === "perpendicular" || n === "vertical" && (t === 90 || t === 270) ? "middle" : t <= 90 || t > 270 ? "start" : "end"
}

function v_(e, t) {
    var n = Co(e),
        r = h_(t);
    return n === "parallel" || r === "left" || r === "right" ? "middle" : r === "top" ? "end" : "start"
}

function g_(e, t) {
    var n = e.labelPlacement,
        r = e.datum;
    if (!n || n === "vertical") return 0;
    var a = t !== void 0 ? t % 360 : Zn(e, r),
        i = a > 90 && a < 180 || a > 270 ? 1 : -1,
        o = 0;
    a === 0 || a === 180 ? o = 90 : a > 0 && a < 180 ? o = 90 - a : a > 180 && a < 360 && (o = 270 - a);
    var u = n === "perpendicular" ? 0 : 90;
    return o + i * u
}

function Zn(e, t) {
    var n = Mo(t),
        r = n.x;
    return xp(e.scale.x(r)) % 360
}

function y_(e, t) {
    var n = e.scale,
        r = e.data,
        a = e.style,
        i = e.horizontal,
        o = e.polar,
        u = e.width,
        l = e.height,
        c = e.theme,
        f = e.labelComponent,
        h = e.disableInlineStyles,
        d = r[t],
        y = Zn(e, d),
        v = o ? d_(e, y) : o_(e, d),
        b = o ? v_(e, y) : i_(e, d),
        g = u_(e, d),
        p = qc(e, d, t),
        m = Co(e),
        _ = f_(e, d),
        w = _.x,
        O = _.y,
        T = c_(e, d),
        x = T.dx,
        M = T.dy,
        C = {
            angle: g,
            data: r,
            datum: d,
            disableInlineStyles: h,
            horizontal: i,
            index: t,
            polar: o,
            scale: n,
            labelPlacement: m,
            text: p,
            textAnchor: v,
            verticalAnchor: b,
            x: w,
            y: O,
            dx: x,
            dy: M,
            width: u,
            height: l,
            style: a.labels
        };
    if (!Wc(f)) return C;
    var I = c && c.tooltip || {};
    return L({}, C, fr(I, ["style"]))
}
var Ti = function(e) {
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
    if (n.length > 0) return n.reduce(function(u, l) {
        return [u, Ti(l)].join(" ")
    }, Ti(e)).trim();
    if (e == null || typeof e == "string") return e;
    var a = [];
    for (var i in e)
        if (e.hasOwnProperty(i)) {
            var o = e[i];
            a.push("".concat(i, "(").concat(o, ")"))
        }
    return a.join(" ").trim()
};

function m_(e) {
    var t = {
        grayscale: ["#cccccc", "#969696", "#636363", "#252525"],
        qualitative: ["#334D5C", "#45B29D", "#EFC94C", "#E27A3F", "#DF5A49", "#4F7DA1", "#55DBC1", "#EFDA97", "#E2A37F", "#DF948A"],
        heatmap: ["#428517", "#77D200", "#D6D305", "#EC8E19", "#C92B05"],
        warm: ["#940031", "#C43343", "#DC5429", "#FF821D", "#FFAF55"],
        cool: ["#2746B9", "#0B69D4", "#2794DB", "#31BB76", "#60E83B"],
        red: ["#FCAE91", "#FB6A4A", "#DE2D26", "#A50F15", "#750B0E"],
        blue: ["#002C61", "#004B8F", "#006BC9", "#3795E5", "#65B4F4"],
        green: ["#354722", "#466631", "#649146", "#8AB25C", "#A9C97E"]
    };
    return e ? t[e] : t.grayscale
}

function b_(e) {
    return x_(e) || __(e) || p_()
}

function p_() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function __(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function x_(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}
var kl = {
        "American Typewriter": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .25, .4203125, .3296875, .6, .6375, .8015625, .8203125, .1875, .45625, .45625, .6375, .5, .2734375, .309375, .2734375, .4390625, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .2734375, .2734375, .5, .5, .5, .6, .6921875, .7640625, .6921875, .6375, .728125, .6734375, .6203125, .7109375, .784375, .3828125, .6421875, .7859375, .6375, .9484375, .7640625, .65625, .6375, .65625, .7296875, .6203125, .6375, .7109375, .740625, .940625, .784375, .7578125, .6203125, .4375, .5, .4375, .5, .5, .4921875, .5734375, .5890625, .5109375, .6, .528125, .43125, .5578125, .6375, .3109375, .40625, .6234375, .309375, .928125, .6375, .546875, .6, .58125, .4921875, .4921875, .4, .6203125, .625, .825, .6375, .640625, .528125, .5, .5, .5, .6671875],
            avg: .5793421052631578
        },
        Arial: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .278125, .278125, .35625, .55625, .55625, .890625, .6671875, .1921875, .334375, .334375, .390625, .584375, .278125, .334375, .278125, .278125, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .278125, .278125, .584375, .584375, .584375, .55625, 1.015625, .6703125, .6671875, .7234375, .7234375, .6671875, .6109375, .778125, .7234375, .278125, .5, .6671875, .55625, .834375, .7234375, .778125, .6671875, .778125, .7234375, .6671875, .6109375, .7234375, .6671875, .9453125, .6671875, .6671875, .6109375, .278125, .278125, .278125, .4703125, .584375, .334375, .55625, .55625, .5, .55625, .55625, .3125, .55625, .55625, .2234375, .2703125, .5, .2234375, .834375, .55625, .55625, .55625, .55625, .346875, .5, .278125, .55625, .5, .7234375, .5, .5, .5, .334375, .2609375, .334375, .584375],
            avg: .528733552631579
        },
        "Arial Black": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .33125, .334375, .5, .6609375, .6671875, 1, .890625, .278125, .390625, .390625, .55625, .6609375, .334375, .334375, .334375, .28125, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .334375, .334375, .6609375, .6609375, .6609375, .6109375, .7453125, .78125, .778125, .778125, .778125, .7234375, .6671875, .834375, .834375, .390625, .6671875, .834375, .6671875, .9453125, .834375, .834375, .7234375, .834375, .78125, .7234375, .7234375, .834375, .7796875, 1.003125, .78125, .78125, .7234375, .390625, .28125, .390625, .6609375, .5125, .334375, .6671875, .6671875, .6671875, .6671875, .6671875, .41875, .6671875, .6671875, .334375, .384375, .6671875, .334375, 1, .6671875, .6671875, .6671875, .6671875, .4703125, .6109375, .4453125, .6671875, .6140625, .946875, .6671875, .615625, .55625, .390625, .278125, .390625, .6609375],
            avg: .6213157894736842
        },
        Baskerville: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .25, .25, .40625, .6671875, .490625, .875, .7015625, .178125, .2453125, .246875, .4171875, .6671875, .25, .3125, .25, .521875, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .25, .25, .6671875, .6671875, .6671875, .396875, .9171875, .684375, .615625, .71875, .7609375, .625, .553125, .771875, .803125, .3546875, .515625, .78125, .6046875, .928125, .75, .8234375, .5625, .96875, .7296875, .5421875, .6984375, .771875, .7296875, .9484375, .771875, .678125, .6359375, .3640625, .521875, .3640625, .46875, .5125, .334375, .46875, .521875, .428125, .521875, .4375, .3890625, .4765625, .53125, .25, .359375, .4640625, .240625, .803125, .53125, .5, .521875, .521875, .365625, .334375, .2921875, .521875, .4640625, .678125, .4796875, .465625, .428125, .4796875, .5109375, .4796875, .6671875],
            avg: .5323519736842108
        },
        Courier: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .5984375, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6078125, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .61875, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .615625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6140625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625],
            avg: .6020559210526316
        },
        "Courier New": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .5984375, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625],
            avg: .6015296052631579
        },
        cursive: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .1921875, .24375, .40625, .5671875, .3984375, .721875, .909375, .2328125, .434375, .365625, .4734375, .5578125, .19375, .3484375, .19375, .7734375, .503125, .4171875, .5453125, .45, .6046875, .4703125, .5984375, .55625, .503125, .5546875, .20625, .2, .5625, .5546875, .546875, .403125, .70625, .734375, .7078125, .64375, .85, .753125, .75, .6484375, 1.0765625, .44375, .5359375, .8359375, .653125, 1.0109375, 1.1515625, .6796875, .6984375, 1.0625, .8234375, .5125, .9234375, .8546875, .70625, .9109375, .7421875, .715625, .6015625, .4640625, .3359375, .4109375, .5421875, .5421875, .4328125, .5125, .5, .3859375, .7375, .359375, .75625, .540625, .5328125, .3203125, .5296875, .5015625, .484375, .7890625, .5640625, .4203125, .703125, .471875, .4734375, .35, .4125, .5640625, .471875, .6484375, .5296875, .575, .4140625, .415625, .20625, .3796875, .5421875],
            avg: .5604440789473684
        },
        fantasy: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .215625, .2625, .3265625, .6109375, .534375, .7625, .7828125, .2, .4359375, .4359375, .3765625, .5109375, .2796875, .4609375, .2796875, .5296875, .6640625, .253125, .521875, .4765625, .6640625, .490625, .528125, .5546875, .496875, .5421875, .2796875, .2796875, .5625, .4609375, .5625, .4828125, .609375, .740625, .7234375, .740625, .8265625, .7234375, .6171875, .7359375, .765625, .240625, .5453125, .715625, .6078125, .8640625, .653125, .9125, .6484375, .946875, .6921875, .653125, .6953125, .8015625, .58125, .784375, .671875, .6265625, .690625, .4359375, .5296875, .4359375, .53125, .5, .2875, .5375, .603125, .4984375, .60625, .53125, .434375, .6421875, .56875, .209375, .4671875, .5484375, .2203125, .709375, .55, .5984375, .6140625, .5765625, .40625, .4734375, .3734375, .559375, .4421875, .6421875, .4890625, .578125, .4484375, .2546875, .2203125, .2546875, .55],
            avg: .536496710526316
        },
        Geneva: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .3328125, .3046875, .5, .6671875, .6671875, .90625, .728125, .3046875, .446875, .446875, .5078125, .6671875, .3046875, .3796875, .3046875, .5390625, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .3046875, .3046875, .6671875, .6671875, .6671875, .56875, .871875, .728125, .6375, .6515625, .7015625, .5765625, .5546875, .675, .690625, .2421875, .4921875, .6640625, .584375, .7890625, .709375, .7359375, .584375, .78125, .60625, .60625, .640625, .6671875, .728125, .946875, .6109375, .6109375, .5765625, .446875, .5390625, .446875, .6671875, .6671875, .5921875, .5546875, .6109375, .546875, .603125, .5765625, .390625, .6109375, .584375, .2359375, .334375, .5390625, .2359375, .8953125, .584375, .60625, .603125, .603125, .3875, .509375, .44375, .584375, .565625, .78125, .53125, .571875, .5546875, .4515625, .246875, .4515625, .6671875],
            avg: .5762664473684211
        },
        Georgia: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2421875, .33125, .4125, .64375, .6109375, .81875, .7109375, .215625, .375, .375, .4734375, .64375, .2703125, .375, .2703125, .46875, .6140625, .4296875, .559375, .553125, .565625, .5296875, .5671875, .503125, .596875, .5671875, .3125, .3125, .64375, .64375, .64375, .4796875, .9296875, .715625, .6546875, .6421875, .75, .6546875, .6, .7265625, .815625, .390625, .51875, .7203125, .6046875, .928125, .7671875, .7453125, .6109375, .7453125, .7234375, .5625, .61875, .7578125, .70625, .99375, .7125, .6640625, .6015625, .375, .46875, .375, .64375, .65, .5, .5046875, .56875, .4546875, .575, .484375, .39375, .509375, .5828125, .29375, .3671875, .546875, .2875, .88125, .5921875, .5390625, .571875, .5640625, .4109375, .4328125, .3453125, .5765625, .5203125, .75625, .50625, .5171875, .4453125, .43125, .375, .43125, .64375],
            avg: .5551809210526316
        },
        "Gill Sans": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2765625, .271875, .3546875, .584375, .5421875, .6765625, .625, .1890625, .3234375, .3234375, .4171875, .584375, .2203125, .3234375, .2203125, .28125, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .2203125, .2296875, .584375, .584375, .584375, .334375, 1.0109375, .6671875, .5640625, .709375, .75, .5, .4703125, .740625, .7296875, .25, .3125, .65625, .490625, .78125, .78125, .8234375, .5109375, .8234375, .6046875, .459375, .6046875, .709375, .6046875, 1.0421875, .709375, .6046875, .646875, .334375, .28125, .334375, .4703125, .5828125, .334375, .428125, .5, .4390625, .5109375, .4796875, .296875, .428125, .5, .2203125, .2265625, .5, .2203125, .771875, .5, .553125, .5, .5, .3984375, .3859375, .334375, .5, .4390625, .7203125, .5, .4390625, .4171875, .334375, .2609375, .334375, .584375],
            avg: .4933717105263159
        },
        Helvetica: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2796875, .2765625, .3546875, .5546875, .5546875, .8890625, .665625, .190625, .3328125, .3328125, .3890625, .5828125, .2765625, .3328125, .2765625, .3015625, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .2765625, .2765625, .584375, .5828125, .584375, .5546875, 1.0140625, .665625, .665625, .721875, .721875, .665625, .609375, .7765625, .721875, .2765625, .5, .665625, .5546875, .8328125, .721875, .7765625, .665625, .7765625, .721875, .665625, .609375, .721875, .665625, .94375, .665625, .665625, .609375, .2765625, .3546875, .2765625, .4765625, .5546875, .3328125, .5546875, .5546875, .5, .5546875, .5546875, .2765625, .5546875, .5546875, .221875, .240625, .5, .221875, .8328125, .5546875, .5546875, .5546875, .5546875, .3328125, .5, .2765625, .5546875, .5, .721875, .5, .5, .5, .3546875, .259375, .353125, .5890625],
            avg: .5279276315789471
        },
        "Helvetica Neue": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .278125, .259375, .4265625, .55625, .55625, 1, .6453125, .278125, .2703125, .26875, .353125, .6, .278125, .3890625, .278125, .36875, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .278125, .278125, .6, .6, .6, .55625, .8, .6625, .6859375, .7234375, .7046875, .6125, .575, .759375, .7234375, .259375, .5203125, .6703125, .55625, .871875, .7234375, .7609375, .6484375, .7609375, .6859375, .6484375, .575, .7234375, .6140625, .9265625, .6125, .6484375, .6125, .259375, .36875, .259375, .6, .5, .25625, .5375, .59375, .5375, .59375, .5375, .2984375, .575, .55625, .2234375, .2375, .5203125, .2234375, .853125, .55625, .575, .59375, .59375, .334375, .5, .315625, .55625, .5, .759375, .51875, .5, .48125, .334375, .2234375, .334375, .6],
            avg: .5279440789473684
        },
        "Hoefler Text": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2359375, .2234375, .3921875, .7125, .49375, .8859375, .771875, .2125, .3078125, .309375, .375, .4234375, .234375, .3125, .234375, .3, .5828125, .365625, .434375, .3921875, .5234375, .3984375, .5125, .4328125, .46875, .5125, .234375, .234375, .515625, .4234375, .515625, .340625, .7609375, .7359375, .6359375, .721875, .8125, .6375, .5875, .8078125, .853125, .4296875, .503125, .78125, .609375, .9609375, .8515625, .8140625, .6125, .8140625, .71875, .49375, .7125, .76875, .771875, 1.125, .7765625, .7734375, .65625, .321875, .3078125, .321875, .3546875, .5, .3375, .446875, .5359375, .45, .5296875, .4546875, .425, .4921875, .54375, .2671875, .240625, .5390625, .25, .815625, .5375, .5234375, .5390625, .5421875, .365625, .36875, .35625, .5171875, .5015625, .75, .5, .509375, .44375, .2421875, .14375, .2421875, .35],
            avg: .5116447368421051
        },
        Montserrat: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2625, .2609375, .3734375, .696875, .615625, .8296875, .6703125, .203125, .3296875, .3296875, .3875, .575, .2125, .3828125, .2125, .3953125, .6625, .3625, .56875, .5640625, .6625, .5671875, .609375, .5890625, .6390625, .609375, .2125, .2125, .575, .575, .575, .5671875, 1.034375, .7171875, .7546875, .7203125, .8265625, .6703125, .634375, .7734375, .8140625, .303125, .5078125, .7125, .5890625, .95625, .8140625, .8390625, .71875, .8390625, .7234375, .615625, .575, .7921875, .6984375, 1.1125, .65625, .6359375, .6515625, .31875, .396875, .31875, .5765625, .5, .6, .590625, .678125, .5640625, .678125, .6046875, .375, .6875, .678125, .2703125, .365625, .6015625, .2703125, 1.0625, .678125, .628125, .678125, .678125, .4015625, .4890625, .40625, .6734375, .5421875, .8796875, .534375, .5671875, .5125, .334375, .2953125, .334375, .575],
            avg: .571792763157895
        },
        monospace: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .5984375, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6078125, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .61875, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .615625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6140625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625],
            avg: .6020559210526316
        },
        Overpass: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2296875, .2765625, .4203125, .68125, .584375, .8515625, .7015625, .2203125, .3453125, .3453125, .53125, .63125, .2234375, .3953125, .2234375, .509375, .65, .4046875, .6171875, .60625, .6484375, .60625, .6015625, .5375, .615625, .6015625, .2234375, .2234375, .63125, .63125, .63125, .5015625, .8203125, .696875, .6671875, .65, .6859375, .6015625, .559375, .690625, .7078125, .2953125, .565625, .678125, .58125, .8046875, .7109375, .740625, .6421875, .740625, .6765625, .6046875, .590625, .696875, .6640625, .853125, .65, .6671875, .6625, .3734375, .509375, .3734375, .63125, .5125, .4, .5328125, .5625, .51875, .5625, .546875, .3359375, .5625, .565625, .25625, .3203125, .55, .265625, .85, .565625, .5671875, .5625, .5625, .4046875, .4765625, .3796875, .565625, .521875, .7265625, .53125, .5390625, .5125, .3671875, .275, .3671875, .63125],
            avg: .5430756578947369
        },
        Palatino: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .25, .278125, .371875, .60625, .5, .840625, .778125, .209375, .334375, .334375, .390625, .60625, .2578125, .334375, .25, .60625, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .25, .25, .60625, .60625, .60625, .4453125, .7484375, .778125, .6109375, .709375, .775, .6109375, .55625, .7640625, .8328125, .3375, .346875, .7265625, .6109375, .946875, .83125, .7875, .6046875, .7875, .66875, .525, .6140625, .778125, .7234375, 1, .6671875, .6671875, .6671875, .334375, .60625, .334375, .60625, .5, .334375, .5, .565625, .4453125, .6109375, .4796875, .340625, .55625, .5828125, .2921875, .2671875, .5640625, .2921875, .8828125, .5828125, .546875, .6015625, .5609375, .3953125, .425, .3265625, .603125, .565625, .834375, .5171875, .55625, .5, .334375, .60625, .334375, .60625],
            avg: .5408552631578947
        },
        RedHatText: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2328125, .2203125, .35625, .6890625, .55, .7390625, .6703125, .2140625, .4015625, .4015625, .4546875, .53125, .2203125, .45625, .2203125, .515625, .6609375, .3078125, .5484375, .5875, .61875, .5703125, .6203125, .559375, .6140625, .6203125, .2203125, .2234375, .465625, .534375, .465625, .5125, .7671875, .6609375, .6703125, .7265625, .728125, .6203125, .6109375, .8, .73125, .253125, .6, .6125, .6078125, .8625, .7390625, .8109375, .6546875, .809375, .6484375, .6234375, .6171875, .7125, .6609375, .8984375, .6546875, .646875, .60625, .3625, .5203125, .3625, .540625, .4609375, .5234375, .5265625, .584375, .509375, .5828125, .5578125, .3703125, .5828125, .553125, .2234375, .24375, .4890625, .2234375, .8453125, .553125, .58125, .584375, .5828125, .353125, .453125, .378125, .553125, .5015625, .6984375, .4875, .4984375, .459375, .3953125, .2921875, .3953125, .58125],
            avg: .5341940789473685
        },
        "sans-serif": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .278125, .278125, .35625, .55625, .55625, .890625, .6671875, .1921875, .334375, .334375, .390625, .584375, .278125, .334375, .278125, .303125, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .278125, .278125, .5859375, .584375, .5859375, .55625, 1.015625, .6671875, .6671875, .7234375, .7234375, .6671875, .6109375, .778125, .7234375, .278125, .5, .6671875, .55625, .834375, .7234375, .778125, .6671875, .778125, .7234375, .6671875, .6109375, .7234375, .6671875, .9453125, .6671875, .6671875, .6109375, .278125, .35625, .278125, .478125, .55625, .334375, .55625, .55625, .5, .55625, .55625, .278125, .55625, .55625, .2234375, .2421875, .5, .2234375, .834375, .55625, .55625, .55625, .55625, .334375, .5, .278125, .55625, .5, .7234375, .5, .5, .5, .35625, .2609375, .3546875, .590625],
            avg: .5293256578947368
        },
        Seravek: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .215625, .296875, .4171875, .6734375, .4953125, .9125, .740625, .2421875, .3375, .3375, .409375, .60625, .2609375, .35625, .25625, .41875, .5921875, .3515625, .475, .4875, .5375, .509375, .5484375, .4546875, .5421875, .5484375, .25625, .2546875, .5875, .6171875, .5875, .4578125, .8140625, .6765625, .5703125, .6109375, .684375, .5109375, .4953125, .678125, .6859375, .2625, .2625, .5859375, .4734375, .846875, .709375, .740625, .509375, .740625, .584375, .5015625, .528125, .675, .5953125, .9453125, .596875, .540625, .540625, .359375, .4203125, .359375, .5109375, .421875, .4046875, .5015625, .5421875, .446875, .5453125, .484375, .38125, .5140625, .5546875, .240625, .2640625, .490625, .2765625, .8625, .5546875, .546875, .5453125, .5453125, .3625, .41875, .3890625, .5453125, .4703125, .7546875, .4921875, .4609375, .453125, .4015625, .2640625, .4015625, .58125],
            avg: .5044078947368421
        },
        serif: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2484375, .334375, .409375, .5, .5, .834375, .778125, .18125, .334375, .334375, .5, .5640625, .25, .334375, .25, .278125, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .278125, .278125, .5640625, .5640625, .5640625, .4453125, .921875, .7234375, .6671875, .6671875, .7234375, .6109375, .55625, .7234375, .7234375, .334375, .390625, .7234375, .6109375, .890625, .7234375, .7234375, .55625, .7234375, .6671875, .55625, .6109375, .7234375, .7234375, .9453125, .7234375, .7234375, .6109375, .334375, .340625, .334375, .4703125, .5, .3453125, .4453125, .5, .4453125, .5, .4453125, .3828125, .5, .5, .278125, .3359375, .5, .278125, .778125, .5, .5, .5, .5, .3375, .390625, .2796875, .5, .5, .7234375, .5, .5, .4453125, .48125, .2015625, .48125, .5421875],
            avg: .5126315789473684
        },
        Tahoma: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .3109375, .3328125, .4015625, .728125, .546875, .9765625, .70625, .2109375, .3828125, .3828125, .546875, .728125, .303125, .3640625, .303125, .3953125, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .3546875, .3546875, .728125, .728125, .728125, .475, .909375, .6109375, .590625, .6015625, .6796875, .5625, .521875, .66875, .6765625, .3734375, .4171875, .6046875, .4984375, .771875, .66875, .7078125, .5515625, .7078125, .6375, .5578125, .5875, .65625, .60625, .903125, .58125, .5890625, .559375, .3828125, .39375, .3828125, .728125, .5625, .546875, .525, .553125, .4625, .553125, .5265625, .3546875, .553125, .5578125, .2296875, .328125, .51875, .2296875, .840625, .5578125, .54375, .553125, .553125, .3609375, .446875, .3359375, .5578125, .4984375, .7421875, .4953125, .4984375, .4453125, .48125, .3828125, .48125, .728125],
            avg: .5384374999999998
        },
        "Times New Roman": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2484375, .334375, .409375, .5, .5, .834375, .778125, .18125, .334375, .334375, .5, .5640625, .25, .334375, .25, .28125, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .278125, .278125, .5640625, .5640625, .5640625, .4453125, .921875, .7234375, .6671875, .6671875, .7234375, .6109375, .55625, .7234375, .7234375, .334375, .390625, .73125, .6109375, .890625, .7375, .7234375, .55625, .7234375, .6765625, .55625, .6109375, .7234375, .7234375, .9453125, .7234375, .7234375, .6109375, .334375, .28125, .334375, .4703125, .51875, .334375, .4453125, .503125, .4453125, .503125, .4453125, .4359375, .5, .5, .278125, .35625, .50625, .278125, .778125, .5, .5, .5046875, .5, .340625, .390625, .2796875, .5, .5, .7234375, .5, .5, .4453125, .48125, .2015625, .48125, .5421875],
            avg: .5134375
        },
        "Trebuchet MS": {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .3015625, .3671875, .325, .53125, .525, .6015625, .70625, .1609375, .3671875, .3671875, .3671875, .525, .3671875, .3671875, .3671875, .525, .525, .525, .525, .525, .525, .525, .525, .525, .525, .525, .3671875, .3671875, .525, .525, .525, .3671875, .771875, .590625, .5671875, .5984375, .6140625, .5359375, .525, .6765625, .6546875, .2796875, .4765625, .5765625, .5078125, .7109375, .6390625, .675, .5578125, .7421875, .5828125, .48125, .58125, .6484375, .5875, .853125, .5578125, .5703125, .5515625, .3671875, .3578125, .3671875, .525, .53125, .525, .5265625, .5578125, .4953125, .5578125, .546875, .375, .503125, .546875, .2859375, .3671875, .5046875, .2953125, .83125, .546875, .5375, .5578125, .5578125, .3890625, .40625, .396875, .546875, .490625, .7453125, .5015625, .49375, .475, .3671875, .525, .3671875, .525],
            avg: .5085197368421052
        },
        Verdana: {
            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .35, .39375, .459375, .81875, .6359375, 1.0765625, .759375, .26875, .4546875, .4546875, .6359375, .81875, .3640625, .4546875, .3640625, .4703125, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .4546875, .4546875, .81875, .81875, .81875, .546875, 1, .684375, .6859375, .6984375, .771875, .6328125, .575, .7765625, .7515625, .421875, .4546875, .69375, .5578125, .84375, .7484375, .7875, .603125, .7875, .7, .684375, .6171875, .7328125, .684375, .9890625, .6859375, .615625, .6859375, .4546875, .46875, .4546875, .81875, .6421875, .6359375, .6015625, .6234375, .521875, .6234375, .596875, .384375, .6234375, .6328125, .275, .3765625, .5921875, .275, .9734375, .6328125, .6078125, .6234375, .6234375, .43125, .521875, .3953125, .6328125, .5921875, .81875, .5921875, .5921875, .5265625, .6359375, .4546875, .6359375, .81875],
            avg: .6171875000000003
        }
    },
    Il = {
        mm: 3.8,
        sm: 38,
        pt: 1.33,
        pc: 16,
        in: 96,
        px: 1
    },
    Dl = {
        em: 1,
        ex: .5
    },
    Vc = {
        heightOverlapCoef: 1.05,
        lineCapitalCoef: 1.15
    },
    Yc = {
        lineHeight: 1,
        letterSpacing: "0px",
        fontSize: 0,
        angle: 0,
        fontFamily: ""
    },
    w_ = function(e) {
        return e * Math.PI / 180
    },
    A_ = function(e) {
        var t = e.split(",").map(function(r) {
                return r.replace(/'|"/g, "")
            }),
            n = t.find(function(r) {
                return kl[r]
            }) || "Helvetica";
        return kl[n]
    },
    Kc = function(e) {
        return Array.isArray(e) ? e : e.toString().split(/\r\n|\r|\n/g)
    },
    Nl = function(e, t, n) {
        var r = w_(n);
        return Math.abs(Math.cos(r) * e) + Math.abs(Math.sin(r) * t)
    },
    Si = function(e, t) {
        var n = e.match(/[a-zA-Z%]+/) && e.match(/[a-zA-Z%]+/)[0],
            r = e.match(/[0-9.,]+/),
            a;
        return n ? Il.hasOwnProperty(n) ? a = r * Il[n] : Dl.hasOwnProperty(n) ? a = (t ? r * t : r * Yc.fontSize) * Dl[n] : a = r : a = r || 0, a
    },
    Xc = function(e, t) {
        var n = Array.isArray(e) ? e[t] : e,
            r = L({}, n, Yc);
        return S({}, r, {
            fontFamily: r.fontFamily,
            letterSpacing: typeof r.letterSpacing == "number" ? r.letterSpacing : Si(String(r.letterSpacing), r.fontSize),
            fontSize: typeof r.fontSize == "number" ? r.fontSize : Si(String(r.fontSize))
        })
    },
    O_ = function(e, t) {
        if (e === void 0 || e === "" || e === null) return 0;
        var n = Kc(e).map(function(r, a) {
            var i = r.toString().length,
                o = Xc(t, a),
                u = o.fontSize,
                l = o.letterSpacing,
                c = o.fontFamily,
                f = A_(c),
                h = r.toString().split("").map(function(d) {
                    return d.charCodeAt(0) < f.widths.length ? f.widths[d.charCodeAt(0)] : f.avg
                }).reduce(function(d, y) {
                    return y + d
                }, 0) * u;
            return h + l * Math.max(i - 1, 0)
        });
        return Math.max.apply(Math, b_(n))
    },
    T_ = function(e, t) {
        return e === void 0 || e === "" || e === null ? 0 : Kc(e).reduce(function(n, r, a) {
            var i = Xc(t, a),
                o = r.toString().match(/[(A-Z)(0-9)]/),
                u = o ? i.fontSize * Vc.lineCapitalCoef : i.fontSize;
            return n + i.lineHeight * u
        }, 0)
    },
    S_ = {
        impl: function(e, t) {
            var n = Array.isArray(t) ? t[0] && t[0].angle : t && t.angle,
                r = T_(e, t),
                a = O_(e, t),
                i = n ? Nl(a, r, n) : a,
                o = n ? Nl(r, a, n) : r;
            return {
                width: i,
                height: o * Vc.heightOverlapCoef
            }
        }
    },
    Ei = function(e, t) {
        return S_.impl(e, t)
    },
    E_ = function(e) {
        return A.createElement("tspan", e)
    },
    M_ = E_;

function C_(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        a, i;
    for (i = 0; i < r.length; i++) a = r[i], !(t.indexOf(a) >= 0) && (n[a] = e[a]);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for (i = 0; i < o.length; i++) a = o[i], !(t.indexOf(a) >= 0) && (!Object.prototype.propertyIsEnumerable.call(e, a) || (n[a] = e[a]))
    }
    return n
}
var Zc = function(e) {
    var t = e.children,
        n = e.title,
        r = e.desc,
        a = C_(e, ["children", "title", "desc"]);
    return A.createElement("text", a, n && A.createElement("title", null, n), r && A.createElement("desc", null, r), t)
};
Zc.propTypes = {
    children: s.node,
    desc: s.string,
    title: s.string
};
var $_ = Zc;

function P_(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            k_(e, a, n[a])
        })
    }
    return e
}

function k_(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function Wn(e) {
    return N_(e) || D_(e) || I_()
}

function I_() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function D_(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function N_(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}
var Et = {
        fill: "#252525",
        fontSize: 14,
        fontFamily: "'Gill Sans', 'Gill Sans MT', 'Ser\xADavek', 'Trebuchet MS', sans-serif",
        stroke: "transparent"
    },
    Ll = function(e, t) {
        if (!e.datum) return 0;
        var n = Ta(e, e.datum);
        return n[t]
    },
    jl = function(e) {
        var t = e && e.fontSize;
        if (typeof t == "number") return t;
        if (t == null) return Et.fontSize;
        if (typeof t == "string") {
            var n = +t.replace("px", "");
            return isNaN(n) ? Et.fontSize : n
        }
        return Et.fontSize
    },
    be = function(e) {
        var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
        return Array.isArray(e) ? e[t] || e[0] : e
    },
    Qc = function(e) {
        var t = e.backgroundStyle,
            n = e.backgroundPadding;
        return Array.isArray(t) && !re(t) || Array.isArray(n) && !re(n)
    },
    L_ = function(e, t) {
        if (t.disableInlineStyles) {
            var n = Ye(e, t);
            return {
                fontSize: jl(n)
            }
        }
        var r = function(a) {
            a = a ? L({}, a, Et) : Et;
            var i = Ye(a, t);
            return S({}, i, {
                fontSize: jl(i)
            })
        };
        return Array.isArray(e) && !re(e) ? e.map(function(a) {
            return r(a)
        }) : r(e)
    },
    j_ = function(e, t) {
        if (!!e) return Array.isArray(e) && !re(e) ? e.map(function(n) {
            return Ye(n, t)
        }) : Ye(e, t)
    },
    R_ = function(e) {
        if (e.backgroundPadding && Array.isArray(e.backgroundPadding)) return e.backgroundPadding.map(function(n) {
            var r = R(n, e);
            return Xe({
                padding: r
            })
        });
        var t = R(e.backgroundPadding, e);
        return Xe({
            padding: t
        })
    },
    F_ = function(e) {
        var t = R(e.lineHeight, e);
        return Array.isArray(t) && re(t) ? [1] : t
    },
    W_ = function(e, t) {
        if (e != null) {
            if (Array.isArray(e)) return e.map(function(r) {
                return R(r, t)
            });
            var n = R(e, t);
            if (n != null) return Array.isArray(n) ? n : "".concat(n).split(`
`)
        }
    },
    z_ = function(e, t, n) {
        var r = e.dy ? R(e.dy, e) : 0,
            a = e.inline ? 1 : e.text.length,
            i = R(e.capHeight, e),
            o = t ? R(t, e) : "middle",
            u = Wn(Array(a).keys()).map(function(f) {
                return be(e.style, f).fontSize
            }),
            l = Wn(Array(a).keys()).map(function(f) {
                return be(n, f)
            });
        if (o === "start") return r + (i / 2 + l[0] / 2) * u[0];
        if (e.inline) return o === "end" ? r + (i / 2 - l[0] / 2) * u[0] : r + i / 2 * u[0];
        if (a === 1) return o === "end" ? r + (i / 2 + (.5 - a) * l[0]) * u[0] : r + (i / 2 + (.5 - a / 2) * l[0]) * u[0];
        var c = Wn(Array(a).keys()).reduce(function(f, h) {
            return f + (i / 2 + (.5 - a) * l[h]) * u[h] / a
        }, 0);
        return o === "end" ? r + c : r + c / 2 + i / 2 * l[a - 1] * u[a - 1]
    },
    U_ = function(e, t, n) {
        var r = e.polar,
            a = be(e.style),
            i = r ? g_(e) : 0,
            o = a.angle === void 0 ? R(e.angle, e) : a.angle,
            u = o === void 0 ? i : o,
            l = e.transform || a.transform,
            c = l && R(l, e),
            f = u && {
                rotate: [u, t, n]
            };
        return c || u ? Ti(c, f) : void 0
    },
    Jc = function(e, t) {
        var n = e.direction,
            r = e.textAnchor,
            a = e.x,
            i = e.dx;
        if (n === "rtl") return a - t;
        switch (r) {
            case "middle":
                return Math.round(a - t / 2);
            case "end":
                return Math.round(a - t);
            default:
                return a + (i || 0)
        }
    },
    ef = function(e, t) {
        var n = e.verticalAnchor,
            r = e.y,
            a = e.originalDy,
            i = a === void 0 ? 0 : a,
            o = r + i;
        switch (n) {
            case "start":
                return Math.floor(o);
            case "end":
                return Math.ceil(o - t);
            default:
                return Math.floor(o - t / 2)
        }
    },
    H_ = function(e, t) {
        var n = e.dx,
            r = n === void 0 ? 0 : n,
            a = e.transform,
            i = e.backgroundComponent,
            o = e.backgroundStyle,
            u = e.inline,
            l = e.backgroundPadding,
            c = e.capHeight,
            f = t.map(function(g) {
                return g.textSize
            }),
            h = u ? Math.max.apply(Math, Wn(f.map(function(g) {
                return g.height
            }))) : f.reduce(function(g, p, m) {
                var _ = m ? 0 : c / 2;
                return g + p.height * (t[m].lineHeight - _)
            }, 0),
            d = u ? f.reduce(function(g, p, m) {
                var _ = m ? r : 0;
                return g + p.width + _
            }, 0) : Math.max.apply(Math, Wn(f.map(function(g) {
                return g.width
            }))),
            y = Jc(e, d),
            v = ef(e, h),
            b = {
                key: "background",
                height: h + l.top + l.bottom,
                style: o,
                transform: a,
                width: d + l.left + l.right,
                x: u ? y - l.left : y + r - l.left,
                y: v
            };
        return A.cloneElement(i, L({}, i.props, b))
    },
    B_ = function(e, t, n) {
        var r = e.textAnchor,
            a = t.map(function(u) {
                return u.widthWithPadding
            }),
            i = a.reduce(function(u, l) {
                return u + l
            }, 0),
            o = -i / 2;
        switch (r) {
            case "start":
                return a.reduce(function(u, l, c) {
                    return u = c < n ? u + l : u, u
                }, 0);
            case "end":
                return a.reduce(function(u, l, c) {
                    return u = c > n ? u - l : u, u
                }, 0);
            default:
                return a.reduce(function(u, l, c) {
                    var f = c < n ? l : 0;
                    return u = c === n ? u + l / 2 : u + f, u
                }, o)
        }
    },
    G_ = function(e, t) {
        var n = e.dy,
            r = e.dx,
            a = e.transform,
            i = e.backgroundStyle,
            o = e.backgroundPadding,
            u = e.backgroundComponent,
            l = e.inline,
            c = e.y,
            f = t.map(function(h, d) {
                var y = be(t, d - 1),
                    v = h.textSize,
                    b = h.fontSize * h.lineHeight,
                    g = Math.ceil(b),
                    p = be(o, d),
                    m = be(o, d - 1),
                    _ = l && r || 0,
                    w = d && !l ? y.fontSize * y.lineHeight + m.top + m.bottom : n - b * .5 - (h.fontSize - h.capHeight);
                return {
                    textHeight: g,
                    labelSize: v,
                    heightWithPadding: g + p.top + p.bottom,
                    widthWithPadding: v.width + p.left + p.right + _,
                    y: c,
                    fontSize: h.fontSize,
                    dy: w
                }
            });
        return f.map(function(h, d) {
            var y = Jc(e, h.labelSize.width),
                v = f.slice(0, d + 1).reduce(function(w, O) {
                    return w + O.dy
                }, c),
                b = be(o, d),
                g = h.heightWithPadding,
                p = l ? B_(e, f, d) + y - b.left : y,
                m = l ? ef(e, g) - b.top : v,
                _ = {
                    key: "tspan-background-".concat(d),
                    height: g,
                    style: be(i, d),
                    width: h.widthWithPadding,
                    transform: a,
                    x: p - b.left,
                    y: m
                };
            return A.cloneElement(u, L({}, u.props, _))
        })
    },
    q_ = function(e, t) {
        return Qc(e) ? G_(e, t) : H_(e, t)
    },
    V_ = function(e, t, n) {
        var r = be(e, t),
            a = be(e, t - 1),
            i = a.fontSize * a.lineHeight,
            o = r.fontSize * r.lineHeight,
            u = a.fontSize - a.capHeight,
            l = r.fontSize - r.capHeight,
            c = i - a.fontSize / 2 + r.fontSize / 2 - i / 2 + o / 2 - l / 2 + u / 2;
        return Qc(n) ? c + r.backgroundPadding.top + a.backgroundPadding.bottom : c
    },
    Y_ = function(e, t, n) {
        var r = t.inline,
            a = be(e, n);
        return n && !r ? V_(e, n, t) : r ? n === 0 ? a.backgroundPadding.top : void 0 : a.backgroundPadding.top
    },
    K_ = function(e) {
        var t = W_(e.text, e),
            n = L_(e.style, S({}, e, {
                text: t
            })),
            r = j_(e.backgroundStyle, S({}, e, {
                text: t,
                style: n
            })),
            a = R_(S({}, e, {
                text: t,
                style: n,
                backgroundStyle: r
            })),
            i = R(e.id, e);
        return S({}, e, {
            backgroundStyle: r,
            backgroundPadding: a,
            style: n,
            text: t,
            id: i
        })
    },
    X_ = function(e) {
        var t = R(e.ariaLabel, e),
            n = be(e.style),
            r = F_(e),
            a = e.direction ? R(e.direction, e) : "inherit",
            i = e.textAnchor ? R(e.textAnchor, e) : n.textAnchor || "start",
            o = e.verticalAnchor ? R(e.verticalAnchor, e) : n.verticalAnchor || "middle",
            u = e.dx ? R(e.dx, e) : 0,
            l = z_(e, o, r),
            c = e.x !== void 0 ? e.x : Ll(e, "x"),
            f = e.y !== void 0 ? e.y : Ll(e, "y"),
            h = U_(e, c, f);
        return S({}, e, {
            ariaLabel: t,
            lineHeight: r,
            direction: a,
            textAnchor: i,
            verticalAnchor: o,
            dx: u,
            dy: l,
            originalDy: e.dy,
            transform: h,
            x: c,
            y: f
        })
    },
    Z_ = function(e, t) {
        var n = e.ariaLabel,
            r = e.inline,
            a = e.className,
            i = e.title,
            o = e.events,
            u = e.direction,
            l = e.text,
            c = e.textAnchor,
            f = e.dx,
            h = e.dy,
            d = e.transform,
            y = e.x,
            v = e.y,
            b = e.desc,
            g = e.id,
            p = e.tabIndex,
            m = e.tspanComponent,
            _ = e.textComponent,
            w = P_({
                "aria-label": n,
                key: "text"
            }, o, {
                direction: u,
                dx: f,
                x: y,
                y: v + h,
                transform: d,
                className: a,
                title: i,
                desc: R(b, e),
                tabIndex: R(p, e),
                id: g
            }),
            O = l.map(function(T, x) {
                var M = t[x].style,
                    C = {
                        key: "".concat(g, "-key-").concat(x),
                        x: r ? void 0 : y,
                        dx: r ? f + t[x].backgroundPadding.left : f,
                        dy: Y_(t, e, x),
                        textAnchor: M.textAnchor || c,
                        style: M,
                        children: T
                    };
                return A.cloneElement(m, C)
            });
        return A.cloneElement(_, w, O)
    },
    dn = function(e) {
        if (e = K_(e), e.text === null || e.text === void 0) return null;
        var t = X_(e),
            n = t.text,
            r = t.style,
            a = t.capHeight,
            i = t.backgroundPadding,
            o = t.lineHeight,
            u = n.map(function(d, y) {
                var v = be(r, y),
                    b = Si("".concat(a, "em"), v.fontSize),
                    g = be(o, y);
                return {
                    style: v,
                    fontSize: v.fontSize || Et.fontSize,
                    capHeight: b,
                    text: d,
                    textSize: Ei(d, v),
                    lineHeight: g,
                    backgroundPadding: be(i, y)
                }
            }),
            l = Z_(t, u);
        if (e.backgroundStyle) {
            var c = q_(t, u),
                f = [c, l],
                h = A.cloneElement(e.groupComponent, {}, f);
            return e.renderInPortal ? A.createElement(ot, null, h) : h
        }
        return e.renderInPortal ? A.createElement(ot, null, l) : l
    };
dn.displayName = "VictoryLabel";
dn.role = "label";
dn.defaultStyles = Et;
dn.propTypes = {
    active: s.bool,
    angle: s.oneOfType([s.string, s.number, s.func]),
    ariaLabel: s.oneOfType([s.string, s.func]),
    backgroundComponent: s.element,
    backgroundPadding: s.oneOfType([s.number, s.object, s.array]),
    backgroundStyle: s.oneOfType([s.object, s.array]),
    capHeight: s.oneOfType([s.string, G, s.func]),
    className: s.string,
    data: s.array,
    datum: s.any,
    desc: s.oneOfType([s.string, s.func]),
    direction: s.oneOf(["rtl", "ltr", "inherit"]),
    dx: s.oneOfType([s.number, s.string, s.func]),
    dy: s.oneOfType([s.number, s.string, s.func]),
    events: s.object,
    groupComponent: s.element,
    id: s.oneOfType([s.number, s.string, s.func]),
    index: s.oneOfType([s.number, s.string]),
    inline: s.bool,
    labelPlacement: s.oneOf(["parallel", "perpendicular", "vertical"]),
    lineHeight: s.oneOfType([s.string, G, s.func, s.array]),
    origin: s.shape({
        x: G,
        y: G
    }),
    polar: s.bool,
    renderInPortal: s.bool,
    scale: s.shape({
        x: Ve,
        y: Ve
    }),
    style: s.oneOfType([s.object, s.array]),
    tabIndex: s.oneOfType([s.number, s.func]),
    text: s.oneOfType([s.string, s.number, s.func, s.array]),
    textAnchor: s.oneOfType([s.oneOf(["start", "middle", "end", "inherit"]), s.func]),
    textComponent: s.element,
    title: s.string,
    transform: s.oneOfType([s.string, s.object, s.func]),
    tspanComponent: s.element,
    verticalAnchor: s.oneOfType([s.oneOf(["start", "middle", "end"]), s.func]),
    x: s.oneOfType([s.number, s.string]),
    y: s.oneOfType([s.number, s.string])
};
dn.defaultProps = {
    backgroundComponent: A.createElement(Gc, null),
    groupComponent: A.createElement("g", null),
    direction: "inherit",
    textComponent: A.createElement($_, null),
    tspanComponent: A.createElement(M_, null),
    capHeight: .71,
    lineHeight: 1
};
var tf = dn;

function Hr(e) {
    return e8(e) || J_(e) || Q_()
}

function Q_() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function J_(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function e8(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function t8(e) {
    return Array.isArray(e) && e.length > 0
}

function n8(e) {
    return Array.isArray(e) && e.some(function(t) {
        return typeof t == "string"
    })
}

function sr(e) {
    return Array.isArray(e) && e.some(function(t) {
        return t instanceof Date
    })
}

function Rl(e) {
    return t8(e) && e.every(Array.isArray)
}

function nf(e) {
    return e.filter(function(t) {
        return t !== void 0
    })
}

function Rt(e) {
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
    var a = e.concat(n);
    return sr(a) ? new Date(Math.max.apply(Math, Hr(a))) : Math.max.apply(Math, Hr(a))
}

function ut(e) {
    for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
    var a = e.concat(n);
    return sr(a) ? new Date(Math.min.apply(Math, Hr(a))) : Math.min.apply(Math, Hr(a))
}

function rf(e, t) {
    return (e.key || t).toString()
}

function Fl(e) {
    return e.reduce(function(t, n, r) {
        var a = rf(n, r);
        return t[a] = n, t
    }, {})
}

function Wl(e, t) {
    var n = !1,
        r = ee(e).reduce(function(a, i) {
            return i in t || (n = !0, a[i] = !0), a
        }, {});
    return n && r
}

function r8(e, t) {
    var n = e && Fl(e),
        r = t && Fl(t);
    return {
        entering: n && Wl(r, n),
        exiting: r && Wl(n, r)
    }
}

function Mi(e) {
    return e.type && e.type.getData ? e.type.getData(e.props) : e.props && e.props.data || !1
}

function af(e, t) {
    var n = !1,
        r = !1,
        a = function(u, l) {
            if (!l || u.type !== l.type) return {};
            var c = r8(Mi(u), Mi(l)) || {},
                f = c.entering,
                h = c.exiting;
            return n = n || !!h, r = r || !!f, {
                entering: f || !1,
                exiting: h || !1
            }
        },
        i = function(u, l) {
            return u.map(function(c, f) {
                return c && c.props && c.props.children && l[f] ? i(A.Children.toArray(u[f].props.children), A.Children.toArray(l[f].props.children)) : a(c, l[f])
            })
        },
        o = i(A.Children.toArray(e), A.Children.toArray(t));
    return {
        nodesWillExit: n,
        nodesWillEnter: r,
        childrenTransitions: o,
        nodesShouldEnter: !1
    }
}

function a8(e, t) {
    var n = e.onEnter && e.onEnter.after ? e.onEnter.after : Re;
    return {
        data: t.map(function(r, a) {
            return S({}, r, n(r, a, t))
        })
    }
}

function i8(e, t, n, r) {
    if (e = S({}, e, {
            onEnd: r
        }), e && e.onLoad && !e.onLoad.duration) return {
        animate: e,
        data: n
    };
    var a = e.onLoad && e.onLoad.before ? e.onLoad.before : Re;
    return n = n.map(function(i, o) {
        return S({}, i, a(i, o, n))
    }), {
        animate: e,
        data: n,
        clipWidth: 0
    }
}

function o8(e, t, n) {
    if (e = S({}, e, {
            onEnd: n
        }), e && e.onLoad && !e.onLoad.duration) return {
        animate: e,
        data: t
    };
    var r = e.onLoad && e.onLoad.after ? e.onLoad.after : Re;
    return t = t.map(function(a, i) {
        return S({}, a, r(a, i, t))
    }), {
        animate: e,
        data: t
    }
}

function u8(e, t, n, r, a) {
    var i = e && e.onExit;
    if (e = S({}, e, i), r) {
        e.onEnd = a;
        var o = e.onExit && e.onExit.before ? e.onExit.before : Re;
        n = n.map(function(u, l) {
            var c = (u.key || l).toString();
            return r[c] ? S({}, u, o(u, l, n)) : u
        })
    }
    return {
        animate: e,
        data: n
    }
}

function l8(e, t, n, r, a) {
    if (r) {
        e = S({}, e, {
            onEnd: a
        });
        var i = e.onEnter && e.onEnter.before ? e.onEnter.before : Re;
        n = n.map(function(o, u) {
            var l = (o.key || u).toString();
            return r[l] ? S({}, o, i(o, u, n)) : o
        })
    }
    return {
        animate: e,
        data: n
    }
}

function c8(e, t, n, r) {
    var a = e && e.onEnter;
    if (e = S({}, e, a), n) {
        e.onEnd = r;
        var i = e.onEnter && e.onEnter.after ? e.onEnter.after : Re;
        t = t.map(function(o, u) {
            var l = rf(o, u);
            return n[l] ? S({}, o, i(o, u, t)) : o
        })
    }
    return {
        animate: e,
        data: t
    }
}

function of (e, t, n) {
    var r = t && t.nodesWillExit,
        a = t && t.nodesWillEnter,
        i = t && t.nodesShouldEnter,
        o = t && t.nodesShouldLoad,
        u = t && t.nodesDoneLoad,
        l = t && t.childrenTransitions || [],
        c = {
            enter: e.animate && e.animate.onEnter && e.animate.onEnter.duration,
            exit: e.animate && e.animate.onExit && e.animate.onExit.duration,
            load: e.animate && e.animate.onLoad && e.animate.onLoad.duration,
            move: e.animate && e.animate.duration
        },
        f = function(v, b, g) {
            return o ? o8(g, b, function() {
                n({
                    nodesShouldLoad: !1,
                    nodesDoneLoad: !0
                })
            }) : i8(g, v, b, function() {
                n({
                    nodesDoneLoad: !0
                })
            })
        },
        h = function(v, b, g, p) {
            return u8(p, b, g, v, function() {
                n({
                    nodesWillExit: !1
                })
            })
        },
        d = function(v, b, g, p) {
            return i ? c8(p, g, v, function() {
                n({
                    nodesWillEnter: !1
                })
            }) : l8(p, b, g, v, function() {
                n({
                    nodesShouldEnter: !0
                })
            })
        },
        y = function(v, b) {
            var g = v.props.animate;
            if (!v.type) return {};
            var p = v.props && v.props.polar && v.type.defaultPolarTransitions || v.type.defaultTransitions;
            if (p) {
                var m = g[b] && g[b].duration;
                return m !== void 0 ? m : p[b] && p[b].duration
            } else return {}
        };
    return function(b, g) {
        var p = Mi(b) || [],
            m = L({}, e.animate, b.props.animate),
            _ = b.props.polar && b.type.defaultPolarTransitions || b.type.defaultTransitions;
        m.onExit = L({}, m.onExit, _ && _.onExit), m.onEnter = L({}, m.onEnter, _ && _.onEnter), m.onLoad = L({}, m.onLoad, _ && _.onLoad);
        var w = l[g] || l[0];
        if (u) {
            if (r) {
                var x = w && w.exiting,
                    M = c.exit !== void 0 ? c.exit : y(b, "onExit"),
                    C = x ? {
                        duration: M
                    } : {
                        delay: M
                    };
                return h(x, b, p, S({}, m, C))
            } else if (a) {
                var I = w && w.entering,
                    $ = c.enter !== void 0 ? c.enter : y(b, "onEnter"),
                    E = c.move !== void 0 ? c.move : b.props.animate && b.props.animate.duration,
                    k = {
                        duration: i && I ? $ : E
                    };
                return d(I, b, p, S({}, m, k))
            } else if (!t && m && m.onExit) return a8(m, p)
        } else {
            var O = c.load !== void 0 ? c.load : y(b, "onLoad"),
                T = {
                    duration: O
                };
            return f(b, p, S({}, m, T))
        }
        return {
            animate: m,
            data: p
        }
    }
}

function Ci() {
    return Ci = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Ci.apply(this, arguments)
}

function f8(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function zl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function s8(e, t, n) {
    return t && zl(e.prototype, t), n && zl(e, n), e
}

function h8(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : uf(e)
}

function d8(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function uf(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}
var Ma = function(e) {
    d8(t, e);

    function t(n, r) {
        var a;
        f8(this, t), a = h8(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n, r)), a.state = {
            nodesShouldLoad: !1,
            nodesDoneLoad: !1
        };
        var i = a.props.children,
            o = i.props.polar;
        return a.continuous = !o && i.type && i.type.continuous === !0, a.getTransitionState = a.getTransitionState.bind(uf(a)), a.timer = a.context.transitionTimer, a
    }
    return s8(t, [{
        key: "componentDidMount",
        value: function() {
            this.setState({
                nodesShouldLoad: !0
            })
        }
    }, {
        key: "shouldComponentUpdate",
        value: function(r) {
            var a = this;
            return qe(this.props, r) || (this.timer.bypassAnimation(), this.setState(this.getTransitionState(this.props, r), function() {
                return a.timer.resumeAnimation()
            })), !0
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            this.timer.stop()
        }
    }, {
        key: "getTransitionState",
        value: function(r, a) {
            var i = r.animate;
            if (i)
                if (i.parentState) {
                    var o = i.parentState,
                        u = o.nodesWillExit ? r : null;
                    return {
                        oldProps: u,
                        nextProps: a
                    }
                } else {
                    var l = A.Children.toArray(r.children),
                        c = A.Children.toArray(a.children),
                        f = af(l, c),
                        h = f.nodesWillExit,
                        d = f.nodesWillEnter,
                        y = f.childrenTransitions,
                        v = f.nodesShouldEnter;
                    return {
                        nodesWillExit: h,
                        nodesWillEnter: d,
                        childrenTransitions: y,
                        nodesShouldEnter: v,
                        oldProps: h ? r : null,
                        nextProps: a
                    }
                }
            else return {}
        }
    }, {
        key: "getDomainFromChildren",
        value: function(r, a) {
            var i = function(f) {
                    return f.reduce(function(h, d) {
                        if (d.type && H(d.type.getDomain)) {
                            var y = d.props && d.type.getDomain(d.props, a);
                            return y ? h.concat(y) : h
                        } else if (d.props && d.props.children) return h.concat(i(A.Children.toArray(d.props.children)));
                        return h
                    }, [])
                },
                o = A.Children.toArray(r.children)[0],
                u = o.props || {},
                l = Array.isArray(u.domain) ? u.domain : u.domain && u.domain[a];
            if (!u.children && l) return l;
            var c = i([o]);
            return c.length === 0 ? [0, 1] : [ut(c), Rt(c)]
        }
    }, {
        key: "pickProps",
        value: function() {
            return this.state ? this.state.nodesWillExit ? this.state.oldProps || this.props : this.props : this.props
        }
    }, {
        key: "pickDomainProps",
        value: function(r) {
            var a = Te(r.animate) && r.animate.parentState;
            return a && a.nodesWillExit ? (this.continous || a.continuous) && (a.nextProps || this.state.nextProps) || r : this.continuous && this.state.nodesWillExit && this.state.nextProps || r
        }
    }, {
        key: "getClipWidth",
        value: function(r, a) {
            var i = function() {
                    var u = Ze(a.props, "x");
                    return u ? Math.abs(u[1] - u[0]) : r.width
                },
                o = this.transitionProps ? this.transitionProps.clipWidth : void 0;
            return o !== void 0 ? o : i()
        }
    }, {
        key: "render",
        value: function() {
            var r = this,
                a = this.pickProps(),
                i = Te(this.props.animate) && this.props.animate.getTransitions ? this.props.animate.getTransitions : of (a, this.state, function(v) {
                    return r.setState(v)
                }),
                o = A.Children.toArray(a.children)[0],
                u = i(o);
            this.transitionProps = u;
            var l = {
                    x: this.getDomainFromChildren(this.pickDomainProps(a), "x"),
                    y: this.getDomainFromChildren(a, "y")
                },
                c = this.getClipWidth(a, o),
                f = L({
                    domain: l,
                    clipWidth: c
                }, u, o.props),
                h = a.animationWhitelist || [],
                d = h.concat(["clipWidth"]),
                y = d.length ? Xn(f, d) : f;
            return A.createElement(cr, Ci({}, f.animate, {
                data: y
            }), function(v) {
                if (o.props.groupComponent) {
                    var b = r.continuous ? A.cloneElement(o.props.groupComponent, {
                        clipWidth: v.clipWidth || 0
                    }) : o.props.groupComponent;
                    return A.cloneElement(o, L({
                        animate: null,
                        animating: !0,
                        groupComponent: b
                    }, v, f))
                }
                return A.cloneElement(o, L({
                    animate: null,
                    animating: !0
                }, v, f))
            })
        }
    }]), t
}(A.Component);
Object.defineProperty(Ma, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryTransition"
});
Object.defineProperty(Ma, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        animate: s.oneOfType([s.bool, s.object]),
        animationWhitelist: s.array,
        children: s.node
    }
});
Object.defineProperty(Ma, "contextType", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: wa
});
var lf = function(e) {
    return A.createElement("defs", null, A.createElement("clipPath", {
        id: e.clipId
    }, e.children))
};
lf.propTypes = {
    children: s.oneOfType([s.arrayOf(s.node), s.node]),
    clipId: s.oneOfType([s.number, s.string])
};
var v8 = lf;

function Br() {
    return Br = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, Br.apply(this, arguments)
}

function g8(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        a, i;
    for (i = 0; i < r.length; i++) a = r[i], !(t.indexOf(a) >= 0) && (n[a] = e[a]);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for (i = 0; i < o.length; i++) a = o[i], !(t.indexOf(a) >= 0) && (!Object.prototype.propertyIsEnumerable.call(e, a) || (n[a] = e[a]))
    }
    return n
}
var y8 = function(e) {
        var t = e.desc,
            n = g8(e, ["desc"]);
        return t ? A.createElement("circle", Br({
            vectorEffect: "non-scaling-stroke"
        }, n), A.createElement("desc", null, t)) : A.createElement("circle", Br({
            vectorEffect: "non-scaling-stroke"
        }, n))
    },
    m8 = y8;

function Ul(e) {
    return _8(e) || p8(e) || b8()
}

function b8() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function p8(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function _8(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function x8(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            w8(e, a, n[a])
        })
    }
    return e
}

function w8(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function A8(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function Hl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function O8(e, t, n) {
    return t && Hl(e.prototype, t), n && Hl(e, n), e
}

function T8(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : S8(e)
}

function S8(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function E8(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var kt = function(e) {
    E8(t, e);

    function t(n) {
        var r;
        return A8(this, t), r = T8(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n)), r.clipId = !Te(n) || n.clipId === void 0 ? Oo("victory-clip-") : n.clipId, r
    }
    return O8(t, [{
        key: "calculateAttributes",
        value: function(r) {
            var a = r.polar,
                i = r.origin,
                o = r.clipWidth,
                u = o === void 0 ? 0 : o,
                l = r.clipHeight,
                c = l === void 0 ? 0 : l,
                f = r.translateX,
                h = f === void 0 ? 0 : f,
                d = r.translateY,
                y = d === void 0 ? 0 : d,
                v = Xe({
                    padding: r.clipPadding
                }),
                b = r.radius || Oi(r);
            return {
                x: (a ? i.x : h) - v.left,
                y: (a ? i.y : y) - v.top,
                width: Math.max((a ? b : u) + v.left + v.right, 0),
                height: Math.max((a ? b : c) + v.top + v.bottom, 0)
            }
        }
    }, {
        key: "renderClippedGroup",
        value: function(r, a) {
            var i = r.style,
                o = r.events,
                u = r.transform,
                l = r.children,
                c = r.className,
                f = r.groupComponent,
                h = r.tabIndex,
                d = this.renderClipComponent(r, a),
                y = S({
                    className: c,
                    style: i,
                    transform: u,
                    key: "clipped-group-".concat(a),
                    clipPath: "url(#".concat(a, ")")
                }, o);
            return A.cloneElement(f, x8({}, y, {
                "aria-label": r["aria-label"],
                tabIndex: h
            }), [d].concat(Ul(A.Children.toArray(l))))
        }
    }, {
        key: "renderGroup",
        value: function(r) {
            var a = r.style,
                i = r.events,
                o = r.transform,
                u = r.children,
                l = r.className,
                c = r.groupComponent,
                f = r.tabIndex;
            return A.cloneElement(c, S({
                className: l,
                style: a,
                transform: o,
                "aria-label": r["aria-label"],
                tabIndex: f
            }, i), u)
        }
    }, {
        key: "renderClipComponent",
        value: function(r, a) {
            var i = r.polar,
                o = r.origin,
                u = r.clipWidth,
                l = u === void 0 ? 0 : u,
                c = r.clipHeight,
                f = c === void 0 ? 0 : c,
                h = r.translateX,
                d = h === void 0 ? 0 : h,
                y = r.translateY,
                v = y === void 0 ? 0 : y,
                b = r.circleComponent,
                g = r.rectComponent,
                p = r.clipPathComponent,
                m = Xe({
                    padding: r.clipPadding
                }),
                _ = m.top,
                w = m.bottom,
                O = m.left,
                T = m.right,
                x;
            if (i) {
                var M = r.radius || Oi(r),
                    C = {
                        r: Math.max(M + O + T, M + _ + w, 0),
                        cx: o.x - O,
                        cy: o.y - _
                    };
                x = A.cloneElement(b, C)
            } else {
                var I = {
                    x: d - O,
                    y: v - _,
                    width: Math.max(l + O + T, 0),
                    height: Math.max(f + _ + w, 0)
                };
                x = A.cloneElement(g, I)
            }
            return A.cloneElement(p, S({
                key: "clip-path-".concat(a)
            }, r, {
                clipId: a
            }), x)
        }
    }, {
        key: "getClipValue",
        value: function(r, a) {
            var i = {
                x: r.clipWidth,
                y: r.clipHeight
            };
            if (i[a] !== void 0) return i[a];
            var o = Ze(r, a);
            return o && Math.abs(o[0] - o[1]) || void 0
        }
    }, {
        key: "getTranslateValue",
        value: function(r, a) {
            var i = {
                x: r.translateX,
                y: r.translateY
            };
            if (i[a] !== void 0) return i[a];
            var o = Ze(r, a);
            return o ? Math.min.apply(Math, Ul(o)) : void 0
        }
    }, {
        key: "render",
        value: function() {
            var r = this.getClipValue(this.props, "y"),
                a = this.getClipValue(this.props, "x");
            if (a === void 0 || r === void 0) return this.renderGroup(this.props);
            var i = this.getTranslateValue(this.props, "x"),
                o = this.getTranslateValue(this.props, "y"),
                u = L({}, this.props, {
                    clipHeight: r,
                    clipWidth: a,
                    translateX: i,
                    translateY: o
                });
            return this.renderClippedGroup(u, this.clipId)
        }
    }]), t
}(A.Component);
Object.defineProperty(kt, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryClipContainer"
});
Object.defineProperty(kt, "role", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "container"
});
Object.defineProperty(kt, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        "aria-label": s.string,
        children: s.oneOfType([s.arrayOf(s.node), s.node]),
        circleComponent: s.element,
        className: s.string,
        clipHeight: G,
        clipId: s.oneOfType([s.number, s.string]),
        clipPadding: s.shape({
            top: s.number,
            bottom: s.number,
            left: s.number,
            right: s.number
        }),
        clipPathComponent: s.element,
        clipWidth: G,
        events: s.object,
        groupComponent: s.element,
        origin: s.shape({
            x: G,
            y: G
        }),
        polar: s.bool,
        radius: G,
        style: s.object,
        tabIndex: s.number,
        transform: s.string,
        translateX: s.number,
        translateY: s.number
    }
});
Object.defineProperty(kt, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        circleComponent: A.createElement(m8, null),
        rectComponent: A.createElement(Gc, null),
        clipPathComponent: A.createElement(v8, null),
        groupComponent: A.createElement("g", null)
    }
});
var M8 = "#FFF59D",
    C8 = "#F4511E",
    $8 = "#DCE775",
    P8 = "#8BC34A",
    k8 = "#00796B",
    I8 = "#006064",
    _r = [C8, M8, $8, P8, k8, I8],
    Bl = "#ECEFF1",
    Gl = "#90A4AE",
    we = "#455A64",
    xr = "#212121",
    D8 = "'Helvetica Neue', 'Helvetica', sans-serif",
    N8 = "normal",
    L8 = 12,
    it = 8,
    xe = {
        width: 350,
        height: 350,
        padding: 50
    },
    ie = {
        fontFamily: D8,
        fontSize: L8,
        letterSpacing: N8,
        padding: it,
        fill: we,
        stroke: "transparent",
        strokeWidth: 0
    },
    j8 = S({
        textAnchor: "middle"
    }, ie),
    R8 = "10, 5",
    Xa = "round",
    Za = "round",
    F8 = {
        area: S({
            style: {
                data: {
                    fill: xr
                },
                labels: ie
            }
        }, xe),
        axis: S({
            style: {
                axis: {
                    fill: "transparent",
                    stroke: Gl,
                    strokeWidth: 2,
                    strokeLinecap: Xa,
                    strokeLinejoin: Za
                },
                axisLabel: S({}, j8, {
                    padding: it,
                    stroke: "transparent"
                }),
                grid: {
                    fill: "none",
                    stroke: Bl,
                    strokeDasharray: R8,
                    strokeLinecap: Xa,
                    strokeLinejoin: Za,
                    pointerEvents: "painted"
                },
                ticks: {
                    fill: "transparent",
                    size: 5,
                    stroke: Gl,
                    strokeWidth: 1,
                    strokeLinecap: Xa,
                    strokeLinejoin: Za
                },
                tickLabels: S({}, ie, {
                    fill: we
                })
            }
        }, xe),
        polarDependentAxis: S({
            style: {
                ticks: {
                    fill: "transparent",
                    size: 1,
                    stroke: "transparent"
                }
            }
        }),
        bar: S({
            style: {
                data: {
                    fill: we,
                    padding: it,
                    strokeWidth: 0
                },
                labels: ie
            }
        }, xe),
        boxplot: S({
            style: {
                max: {
                    padding: it,
                    stroke: we,
                    strokeWidth: 1
                },
                maxLabels: S({}, ie, {
                    padding: 3
                }),
                median: {
                    padding: it,
                    stroke: we,
                    strokeWidth: 1
                },
                medianLabels: S({}, ie, {
                    padding: 3
                }),
                min: {
                    padding: it,
                    stroke: we,
                    strokeWidth: 1
                },
                minLabels: S({}, ie, {
                    padding: 3
                }),
                q1: {
                    padding: it,
                    fill: we
                },
                q1Labels: S({}, ie, {
                    padding: 3
                }),
                q3: {
                    padding: it,
                    fill: we
                },
                q3Labels: S({}, ie, {
                    padding: 3
                })
            },
            boxWidth: 20
        }, xe),
        candlestick: S({
            style: {
                data: {
                    stroke: we
                },
                labels: S({}, ie, {
                    padding: 5
                })
            },
            candleColors: {
                positive: "#ffffff",
                negative: we
            }
        }, xe),
        chart: xe,
        errorbar: S({
            borderWidth: 8,
            style: {
                data: {
                    fill: "transparent",
                    opacity: 1,
                    stroke: we,
                    strokeWidth: 2
                },
                labels: ie
            }
        }, xe),
        group: S({
            colorScale: _r
        }, xe),
        histogram: S({
            style: {
                data: {
                    fill: we,
                    stroke: xr,
                    strokeWidth: 2
                },
                labels: ie
            }
        }, xe),
        legend: {
            colorScale: _r,
            gutter: 10,
            orientation: "vertical",
            titleOrientation: "top",
            style: {
                data: {
                    type: "circle"
                },
                labels: ie,
                title: S({}, ie, {
                    padding: 5
                })
            }
        },
        line: S({
            style: {
                data: {
                    fill: "transparent",
                    opacity: 1,
                    stroke: we,
                    strokeWidth: 2
                },
                labels: ie
            }
        }, xe),
        pie: S({
            colorScale: _r,
            style: {
                data: {
                    padding: it,
                    stroke: Bl,
                    strokeWidth: 1
                },
                labels: S({}, ie, {
                    padding: 20
                })
            }
        }, xe),
        scatter: S({
            style: {
                data: {
                    fill: we,
                    opacity: 1,
                    stroke: "transparent",
                    strokeWidth: 0
                },
                labels: ie
            }
        }, xe),
        stack: S({
            colorScale: _r
        }, xe),
        tooltip: {
            style: S({}, ie, {
                padding: 0,
                pointerEvents: "none"
            }),
            flyoutStyle: {
                stroke: xr,
                strokeWidth: 1,
                fill: "#f0f0f0",
                pointerEvents: "none"
            },
            flyoutPadding: 5,
            cornerRadius: 5,
            pointerLength: 10
        },
        voronoi: S({
            style: {
                data: {
                    fill: "transparent",
                    stroke: "transparent",
                    strokeWidth: 0
                },
                labels: S({}, ie, {
                    padding: 5,
                    pointerEvents: "none"
                }),
                flyout: {
                    stroke: xr,
                    strokeWidth: 1,
                    fill: "#f0f0f0",
                    pointerEvents: "none"
                }
            }
        }, xe)
    },
    In = ["#252525", "#525252", "#737373", "#969696", "#bdbdbd", "#d9d9d9", "#f0f0f0"],
    me = "#252525",
    Qa = "#969696",
    W8 = "'Gill Sans', 'Seravek', 'Trebuchet MS', sans-serif",
    z8 = "normal",
    U8 = 14,
    Oe = {
        width: 450,
        height: 300,
        padding: 50,
        colorScale: In
    },
    oe = {
        fontFamily: W8,
        fontSize: U8,
        letterSpacing: z8,
        padding: 10,
        fill: me,
        stroke: "transparent"
    },
    H8 = S({
        textAnchor: "middle"
    }, oe),
    B8 = "round",
    G8 = "round",
    q8 = {
        area: S({
            style: {
                data: {
                    fill: me
                },
                labels: oe
            }
        }, Oe),
        axis: S({
            style: {
                axis: {
                    fill: "transparent",
                    stroke: me,
                    strokeWidth: 1,
                    strokeLinecap: B8,
                    strokeLinejoin: G8
                },
                axisLabel: S({}, H8, {
                    padding: 25
                }),
                grid: {
                    fill: "none",
                    stroke: "none",
                    pointerEvents: "painted"
                },
                ticks: {
                    fill: "transparent",
                    size: 1,
                    stroke: "transparent"
                },
                tickLabels: oe
            }
        }, Oe),
        bar: S({
            style: {
                data: {
                    fill: me,
                    padding: 8,
                    strokeWidth: 0
                },
                labels: oe
            }
        }, Oe),
        boxplot: S({
            style: {
                max: {
                    padding: 8,
                    stroke: me,
                    strokeWidth: 1
                },
                maxLabels: S({}, oe, {
                    padding: 3
                }),
                median: {
                    padding: 8,
                    stroke: me,
                    strokeWidth: 1
                },
                medianLabels: S({}, oe, {
                    padding: 3
                }),
                min: {
                    padding: 8,
                    stroke: me,
                    strokeWidth: 1
                },
                minLabels: S({}, oe, {
                    padding: 3
                }),
                q1: {
                    padding: 8,
                    fill: Qa
                },
                q1Labels: S({}, oe, {
                    padding: 3
                }),
                q3: {
                    padding: 8,
                    fill: Qa
                },
                q3Labels: S({}, oe, {
                    padding: 3
                })
            },
            boxWidth: 20
        }, Oe),
        candlestick: S({
            style: {
                data: {
                    stroke: me,
                    strokeWidth: 1
                },
                labels: S({}, oe, {
                    padding: 5
                })
            },
            candleColors: {
                positive: "#ffffff",
                negative: me
            }
        }, Oe),
        chart: Oe,
        errorbar: S({
            borderWidth: 8,
            style: {
                data: {
                    fill: "transparent",
                    stroke: me,
                    strokeWidth: 2
                },
                labels: oe
            }
        }, Oe),
        group: S({
            colorScale: In
        }, Oe),
        histogram: S({
            style: {
                data: {
                    fill: Qa,
                    stroke: me,
                    strokeWidth: 2
                },
                labels: oe
            }
        }, Oe),
        legend: {
            colorScale: In,
            gutter: 10,
            orientation: "vertical",
            titleOrientation: "top",
            style: {
                data: {
                    type: "circle"
                },
                labels: oe,
                title: S({}, oe, {
                    padding: 5
                })
            }
        },
        line: S({
            style: {
                data: {
                    fill: "transparent",
                    stroke: me,
                    strokeWidth: 2
                },
                labels: oe
            }
        }, Oe),
        pie: {
            style: {
                data: {
                    padding: 10,
                    stroke: "transparent",
                    strokeWidth: 1
                },
                labels: S({}, oe, {
                    padding: 20
                })
            },
            colorScale: In,
            width: 400,
            height: 400,
            padding: 50
        },
        scatter: S({
            style: {
                data: {
                    fill: me,
                    stroke: "transparent",
                    strokeWidth: 0
                },
                labels: oe
            }
        }, Oe),
        stack: S({
            colorScale: In
        }, Oe),
        tooltip: {
            style: S({}, oe, {
                padding: 0,
                pointerEvents: "none"
            }),
            flyoutStyle: {
                stroke: me,
                strokeWidth: 1,
                fill: "#f0f0f0",
                pointerEvents: "none"
            },
            flyoutPadding: 5,
            cornerRadius: 5,
            pointerLength: 10
        },
        voronoi: S({
            style: {
                data: {
                    fill: "transparent",
                    stroke: "transparent",
                    strokeWidth: 0
                },
                labels: S({}, oe, {
                    padding: 5,
                    pointerEvents: "none"
                }),
                flyout: {
                    stroke: me,
                    strokeWidth: 1,
                    fill: "#f0f0f0",
                    pointerEvents: "none"
                }
            }
        }, Oe)
    },
    $o = {
        material: F8,
        grayscale: q8
    },
    cf = {
        categories: s.oneOfType([s.arrayOf(s.string), s.shape({
            x: s.arrayOf(s.string),
            y: s.arrayOf(s.string)
        })]),
        data: s.oneOfType([s.array, s.object]),
        dataComponent: s.element,
        disableInlineStyles: s.bool,
        labelComponent: s.element,
        labels: s.oneOfType([s.func, s.array]),
        samples: G,
        sortKey: s.oneOfType([s.func, Be([Le, G]), s.string, s.arrayOf(s.string)]),
        sortOrder: s.oneOf(["ascending", "descending"]),
        style: s.shape({
            parent: s.object,
            data: s.object,
            labels: s.object
        }),
        x: s.oneOfType([s.func, Be([Le, G]), s.string, s.arrayOf(s.string)]),
        y: s.oneOfType([s.func, Be([Le, G]), s.string, s.arrayOf(s.string)]),
        y0: s.oneOfType([s.func, Be([Le, G]), s.string, s.arrayOf(s.string)])
    },
    ff = {
        animate: s.oneOfType([s.bool, s.object]),
        containerComponent: s.element,
        domain: s.oneOfType([zt, s.shape({
            x: zt,
            y: zt
        })]),
        maxDomain: s.oneOfType([s.number, s.instanceOf(Date), s.shape({
            x: s.oneOfType([s.number, s.instanceOf(Date)]),
            y: s.oneOfType([s.number, s.instanceOf(Date)])
        })]),
        minDomain: s.oneOfType([s.number, s.instanceOf(Date), s.shape({
            x: s.oneOfType([s.number, s.instanceOf(Date)]),
            y: s.oneOfType([s.number, s.instanceOf(Date)])
        })]),
        domainPadding: s.oneOfType([s.shape({
            x: s.oneOfType([s.number, s.arrayOf(s.number)]),
            y: s.oneOfType([s.number, s.arrayOf(s.number)])
        }), s.number, s.arrayOf(s.number)]),
        eventKey: s.oneOfType([s.func, Be([Le, G]), s.string]),
        events: s.arrayOf(s.shape({
            target: s.oneOf(["data", "labels", "parent"]),
            eventKey: s.oneOfType([s.array, Be([Le, G]), s.string]),
            eventHandlers: s.object
        })),
        externalEventMutations: s.arrayOf(s.shape({
            callback: s.function,
            childName: s.oneOfType([s.string, s.array]),
            eventKey: s.oneOfType([s.array, Be([Le, G]), s.string]),
            mutation: s.function,
            target: s.oneOfType([s.string, s.array])
        })),
        groupComponent: s.element,
        height: G,
        name: s.string,
        origin: s.shape({
            x: s.number,
            y: s.number
        }),
        padding: s.oneOfType([s.number, s.shape({
            top: s.number,
            bottom: s.number,
            left: s.number,
            right: s.number
        })]),
        polar: s.bool,
        range: s.oneOfType([zt, s.shape({
            x: zt,
            y: zt
        })]),
        scale: s.oneOfType([Ve, s.shape({
            x: Ve,
            y: Ve
        })]),
        sharedEvents: s.shape({
            events: s.array,
            getEventState: s.func
        }),
        singleQuadrantDomainPadding: s.oneOfType([s.bool, s.shape({
            x: s.oneOfType([s.bool]),
            y: s.oneOfType([s.bool])
        })]),
        standalone: s.bool,
        theme: s.object,
        width: G
    },
    sf = {
        active: s.bool,
        ariaLabel: s.oneOfType([s.string, s.func]),
        className: s.string,
        clipPath: s.string,
        data: s.oneOfType([s.array, s.object]),
        desc: s.oneOfType([s.string, s.func]),
        disableInlineStyles: s.bool,
        events: s.object,
        id: s.oneOfType([s.number, s.string, s.func]),
        index: s.oneOfType([s.number, s.string]),
        origin: s.shape({
            x: s.number,
            y: s.number
        }),
        polar: s.bool,
        role: s.string,
        scale: s.oneOfType([Ve, s.shape({
            x: Ve,
            y: Ve
        })]),
        shapeRendering: s.string,
        style: s.object,
        tabIndex: s.oneOfType([s.number, s.func]),
        transform: s.string
    };

function V8(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        a, i;
    for (i = 0; i < r.length; i++) a = r[i], !(t.indexOf(a) >= 0) && (n[a] = e[a]);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for (i = 0; i < o.length; i++) a = o[i], !(t.indexOf(a) >= 0) && (!Object.prototype.propertyIsEnumerable.call(e, a) || (n[a] = e[a]))
    }
    return n
}
var Y8 = function(e) {
        var t = e.desc,
            n = V8(e, ["desc"]);
        return t ? A.createElement("path", n, A.createElement("desc", null, t)) : A.createElement("path", n)
    },
    hf = Y8,
    K8 = Math.ceil,
    X8 = Math.max;

function Z8(e, t, n, r) {
    for (var a = -1, i = X8(K8((t - e) / (n || 1)), 0), o = Array(i); i--;) o[r ? i : ++a] = e, e += n;
    return o
}
var Q8 = Z8,
    J8 = Q8,
    e4 = Oa,
    Ja = Ic;

function t4(e) {
    return function(t, n, r) {
        return r && typeof r != "number" && e4(t, n, r) && (n = r = void 0), t = Ja(t), n === void 0 ? (n = t, t = 0) : n = Ja(n), r = r === void 0 ? t < n ? 1 : -1 : Ja(r), J8(t, n, r, e)
    }
}
var n4 = t4,
    r4 = n4,
    a4 = r4(),
    i4 = a4;

function o4(e) {
    return e !== e
}
var u4 = o4;

function l4(e, t, n) {
    for (var r = n - 1, a = e.length; ++r < a;)
        if (e[r] === t) return r;
    return -1
}
var c4 = l4,
    f4 = Pc,
    s4 = u4,
    h4 = c4;

function d4(e, t, n) {
    return t === t ? h4(e, t, n) : f4(e, s4, n)
}
var df = d4,
    v4 = df;

function g4(e, t) {
    var n = e == null ? 0 : e.length;
    return !!n && v4(e, t, 0) > -1
}
var vf = g4;

function y4(e, t, n) {
    for (var r = -1, a = e == null ? 0 : e.length; ++r < a;)
        if (n(t, e[r])) return !0;
    return !1
}
var gf = y4,
    m4 = co,
    b4 = vf,
    p4 = gf,
    _4 = ar,
    x4 = lr,
    w4 = fo,
    A4 = 200;

function O4(e, t, n, r) {
    var a = -1,
        i = b4,
        o = !0,
        u = e.length,
        l = [],
        c = t.length;
    if (!u) return l;
    n && (t = _4(t, x4(n))), r ? (i = p4, o = !1) : t.length >= A4 && (i = w4, o = !1, t = new m4(t));
    e: for (; ++a < u;) {
        var f = e[a],
            h = n == null ? f : n(f);
        if (f = r || f !== 0 ? f : 0, o && h === h) {
            for (var d = c; d--;)
                if (t[d] === h) continue e;
            l.push(f)
        } else i(t, h, r) || l.push(f)
    }
    return l
}
var yf = O4,
    T4 = tt,
    S4 = et;

function E4(e) {
    return S4(e) && T4(e)
}
var mf = E4,
    M4 = yf,
    C4 = Fc,
    $4 = Aa,
    ql = mf,
    P4 = $4(function(e, t) {
        return ql(e) ? M4(e, C4(t, 1, ql, !0)) : []
    }),
    Gr = P4;

function k4(e) {
    return e == null
}
var $i = k4,
    I4 = yf,
    D4 = Aa,
    N4 = mf,
    L4 = D4(function(e, t) {
        return N4(e) ? I4(e, t) : []
    }),
    Pr = L4,
    j4 = lt,
    R4 = _e,
    F4 = et,
    W4 = "[object String]";

function z4(e) {
    return typeof e == "string" || !R4(e) && F4(e) && j4(e) == W4
}
var bf = z4,
    U4 = ar;

function H4(e, t) {
    return U4(t, function(n) {
        return e[n]
    })
}
var B4 = H4,
    G4 = B4,
    q4 = Nt;

function V4(e) {
    return e == null ? [] : G4(e, q4(e))
}
var pf = V4,
    Y4 = df,
    K4 = tt,
    X4 = bf,
    Z4 = Dc,
    Q4 = pf,
    J4 = Math.max;

function ex(e, t, n, r) {
    e = K4(e) ? e : Q4(e), n = n && !r ? Z4(n) : 0;
    var a = e.length;
    return n < 0 && (n = J4(a + n, 0)), X4(e) ? n <= a && e.indexOf(t, n) > -1 : !!a && Y4(e, t, n) > -1
}
var vn = ex;

function tx() {}
var nx = tx,
    ei = rc,
    rx = nx,
    ax = so,
    ix = 1 / 0,
    ox = ei && 1 / ax(new ei([, -0]))[1] == ix ? function(e) {
        return new ei(e)
    } : rx,
    ux = ox,
    lx = co,
    cx = vf,
    fx = gf,
    sx = fo,
    hx = ux,
    dx = so,
    vx = 200;

function gx(e, t, n) {
    var r = -1,
        a = cx,
        i = e.length,
        o = !0,
        u = [],
        l = u;
    if (n) o = !1, a = fx;
    else if (i >= vx) {
        var c = t ? null : hx(e);
        if (c) return dx(c);
        o = !1, a = sx, l = new lx
    } else l = t ? [] : u;
    e: for (; ++r < i;) {
        var f = e[r],
            h = t ? t(f) : f;
        if (f = n || f !== 0 ? f : 0, o && h === h) {
            for (var d = l.length; d--;)
                if (l[d] === h) continue e;
            t && l.push(h), u.push(f)
        } else a(l, h, n) || (l !== u && l.push(h), u.push(f))
    }
    return u
}
var _f = gx,
    yx = _f;

function mx(e) {
    return e && e.length ? yx(e) : []
}
var bx = mx,
    Qt = bx,
    px = "Expected a function";

function _x(e) {
    if (typeof e != "function") throw new TypeError(px);
    return function() {
        var t = arguments;
        switch (t.length) {
            case 0:
                return !e.call(this);
            case 1:
                return !e.call(this, t[0]);
            case 2:
                return !e.call(this, t[0], t[1]);
            case 3:
                return !e.call(this, t[0], t[1], t[2])
        }
        return !e.apply(this, t)
    }
}
var xx = _x,
    wx = ho,
    Ax = fc,
    Ox = Q0,
    Tx = Z0,
    Sx = Object.getOwnPropertySymbols,
    Ex = Sx ? function(e) {
        for (var t = []; e;) wx(t, Ox(e)), e = Ax(e);
        return t
    } : Tx,
    Mx = Ex,
    Cx = X0,
    $x = Mx,
    Px = Mc;

function kx(e) {
    return Cx(e, Px, $x)
}
var Ix = kx,
    Dx = ar,
    Nx = mt,
    Lx = jc,
    jx = Ix;

function Rx(e, t) {
    if (e == null) return {};
    var n = Dx(jx(e), function(r) {
        return [r]
    });
    return t = Nx(t), Lx(e, n, function(r, a) {
        return t(r, a[0])
    })
}
var xf = Rx,
    qr = xf,
    Fx = mt,
    Wx = xx,
    zx = xf;

function Ux(e, t) {
    return zx(e, Wx(Fx(t)))
}
var Hx = Ux,
    Bx = Hx;

function wr(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function wf(e) {
    return Vx(e) || qx(e) || Gx()
}

function Gx() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function qx(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function Vx(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}
var Po = /^onGlobal(.*)$/;

function Af(e, t, n, r) {
    var a = this,
        i = function(h) {
            var d = function() {
                    var v = h.reduce(function(b, g) {
                        if (g.target !== void 0) {
                            var p = Array.isArray(g.target) ? vn(g.target, t) : "".concat(g.target) === "".concat(t);
                            return p ? b.concat(g) : b
                        }
                        return b.concat(g)
                    }, []);
                    return n !== void 0 && t !== "parent" ? v.filter(function(b) {
                        var g = b.eventKey,
                            p = function(m) {
                                return m ? "".concat(m) === "".concat(n) : !0
                            };
                        return Array.isArray(g) ? g.some(function(m) {
                            return p(m)
                        }) : p(g)
                    }) : v
                },
                y = d();
            return Array.isArray(y) && y.reduce(function(v, b) {
                return b ? S(v, b.eventHandlers) : v
            }, {})
        },
        o = function() {
            if (Array.isArray(a.componentEvents)) {
                var h;
                return Array.isArray(e.events) ? (h = a.componentEvents).concat.apply(h, wf(e.events)) : a.componentEvents
            }
            return e.events
        },
        u = o(),
        l = u && H(r) ? r(i(u), t) : void 0;
    if (!e.sharedEvents) return l;
    var c = e.sharedEvents.getEvents,
        f = e.sharedEvents.events && c(i(e.sharedEvents.events), t);
    return S({}, f, l)
}

function Of(e, t, n, r) {
    var a = this;
    if (re(e)) return {};
    r = r || this.baseProps;
    var i = function(f, h) {
            var d = f.childName,
                y = f.target,
                v = f.key,
                b = h === "props" ? r : a.state || {},
                g = d == null || !b[d] ? b : b[d];
            return v === "parent" ? g.parent : g[v] && g[v][y]
        },
        o = function(f, h) {
            var d = t === "parent" ? f.childName : f.childName || n,
                y = f.target || t,
                v = function(m) {
                    return y === "parent" ? "parent" : f.eventKey === "all" ? r[m] ? Pr(ee(r[m]), "parent") : Pr(ee(r), "parent") : f.eventKey === void 0 && h === "parent" ? r[m] ? ee(r[m]) : ee(r) : f.eventKey !== void 0 ? f.eventKey : h
                },
                b = function(m, _) {
                    var w = a.state || {};
                    if (!H(f.mutation)) return w;
                    var O = i({
                            childName: _,
                            key: m,
                            target: y
                        }, "props"),
                        T = i({
                            childName: _,
                            key: m,
                            target: y
                        }, "state"),
                        x = f.mutation(S({}, O, T), r),
                        M = w[_] || {},
                        C = function(E) {
                            return E[m] && E[m][y] && delete E[m][y], E[m] && !ee(E[m]).length && delete E[m], E
                        },
                        I = function(E) {
                            return y === "parent" ? S(E, wr({}, m, S(E[m], x))) : S(E, wr({}, m, S(E[m], wr({}, y, x))))
                        },
                        $ = function(E) {
                            return x ? I(E) : C(E)
                        };
                    return _ != null ? S(w, wr({}, _, $(M))) : $(w)
                },
                g = function(m) {
                    var _ = v(m);
                    return Array.isArray(_) ? _.reduce(function(w, O) {
                        return S(w, b(O, m))
                    }, {}) : b(_, m)
                },
                p = d === "all" ? Pr(ee(r), "parent") : d;
            return Array.isArray(p) ? p.reduce(function(m, _) {
                return S(m, g(_))
            }, {}) : g(p)
        },
        u = function(f, h) {
            return Array.isArray(f) ? f.reduce(function(d, y) {
                return d = S({}, d, o(y, h)), d
            }, {}) : o(f, h)
        },
        l = function(f) {
            var h = function(v) {
                    return H(v.callback) && v.callback
                },
                d = Array.isArray(f) ? f.map(function(v) {
                    return h(v)
                }) : [h(f)],
                y = d.filter(function(v) {
                    return v !== !1
                });
            return y.length ? function() {
                return y.forEach(function(v) {
                    return v()
                })
            } : void 0
        },
        c = function(f, h, d, y) {
            var v = e[y](f, h, d, a);
            if (!re(v)) {
                var b = l(v);
                a.setState(u(v, d), b)
            }
        };
    return ee(e).reduce(function(f, h) {
        return f[h] = c, f
    }, {})
}

function Tf(e, t, n) {
    return e ? ee(e).reduce(function(r, a) {
        var i = function(o) {
            return e[a](o, n, t, a)
        };
        return r[a] = i, r
    }, {}) : {}
}

function Sf(e, t, n) {
    var r = this.state || {};
    return n ? r[n] && r[n][e] && r[n][e][t] : e === "parent" ? r[e] && r[e][t] || r[e] : r[e] && r[e][t]
}

function Yx(e, t, n, r) {
    return t = t || {}, n = n || {}, r.reduce(function(a, i) {
        var o = n[i],
            u = Ef(e, t[i], n[i], i);
        return a[i] = u || o, qr(a, function(l) {
            return !re(l)
        })
    }, {})
}

function Ef(e, t, n, r) {
    t = t || {}, n = n || {};
    var a = ee(t);
    return a.reduce(function(i, o) {
        var u = n[o] || {},
            l = t[o] || {};
        if (o === "parent") {
            var c = {
                    eventKey: o,
                    target: "parent"
                },
                f = Vl(e, l, u, c);
            i[o] = f !== void 0 ? S({}, u, f) : u
        } else {
            var h = Qt(ee(l).concat(ee(u)));
            i[o] = h.reduce(function(d, y) {
                var v = {
                        eventKey: o,
                        target: y,
                        childName: r
                    },
                    b = Vl(e, l[y], u[y], v);
                return d[y] = b !== void 0 ? S({}, u[y], b) : u[y], qr(d, function(g) {
                    return !re(g)
                })
            }, {})
        }
        return qr(i, function(d) {
            return !re(d)
        })
    }, {})
}

function Vl(e, t, n, r) {
    var a = function(l, c) {
        if (typeof l[c] == "string") return l[c] === "all" || l[c] === r[c];
        if (Array.isArray(l[c])) {
            var f = l[c].map(function(h) {
                return "".concat(h)
            });
            return vn(f, r[c])
        } else return !1
    };
    e = Array.isArray(e) ? e : [e];
    var i = e;
    r.childName && (i = e.filter(function(l) {
        return a(l, "childName")
    }));
    var o = i.filter(function(l) {
        return a(l, "target")
    });
    if (!re(o)) {
        var u = o.filter(function(l) {
            return a(l, "eventKey")
        });
        if (!re(u)) return u.reduce(function(l, c) {
            var f = c && H(c.mutation) ? c.mutation : function() {},
                h = f(S({}, t, n));
            return S({}, l, h)
        }, {})
    }
}

function ko(e, t) {
    var n = Array.isArray(t) && t.reduce(function(r, a) {
        var i, o = e[a],
            u = o && o.type && o.type.defaultEvents,
            l = H(u) ? u(o.props) : u;
        return r = Array.isArray(l) ? (i = r).concat.apply(i, wf(l)) : r, r
    }, []);
    return n && n.length ? n : void 0
}

function Vr(e) {
    var t = e.match(Po);
    return t && t[1] && t[1].toLowerCase()
}
var Mf = function(e) {
        return qr(e, function(t, n) {
            return Po.test(n)
        })
    },
    Cf = function(e) {
        return Bx(e, function(t, n) {
            return Po.test(n)
        })
    },
    $f = function(e) {
        return S(e, {
            nativeEvent: e
        })
    };

function Ar(e) {
    return Zx(e) || Xx(e) || Kx()
}

function Kx() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function Xx(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function Zx(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function Qx(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function Yl(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function Jx(e, t, n) {
    return t && Yl(e.prototype, t), n && Yl(e, n), e
}

function e9(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : kr(e)
}

function t9(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function kr(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}
var n9 = function(e) {
        return !$i(e._x) && !$i(e._y)
    },
    r9 = [{
        name: "parent",
        index: "parent"
    }, {
        name: "data"
    }, {
        name: "labels"
    }],
    a9 = function(e, t) {
        return function(n) {
            t9(r, n);

            function r(a) {
                var i;
                Qx(this, r), i = e9(this, (r.__proto__ || Object.getPrototypeOf(r)).call(this, a));
                var o = Of.bind(kr(i)),
                    u = Af.bind(kr(i));
                i.state = {}, i.getEvents = function(c, f, h) {
                    return u(c, f, h, o)
                }, i.getEventState = Sf.bind(kr(i));
                var l = i.getCalculatedValues(a);
                return i.cacheValues(l), i.externalMutations = i.getExternalMutations(a), i.calculatedState = i.getStateChanges(a), i.globalEvents = {}, i.prevGlobalEventKeys = [], i.boundGlobalEvents = {}, i
            }
            return Jx(r, [{
                key: "shouldComponentUpdate",
                value: function(i) {
                    var o = this.getExternalMutations(i),
                        u = this.props.animating || this.props.animate,
                        l = !qe(o, this.externalMutations);
                    if (u || l) return this.cacheValues(this.getCalculatedValues(i)), this.externalMutations = o, this.applyExternalMutations(i, o), !0;
                    var c = this.getStateChanges(i);
                    return qe(this.calculatedState, c) ? qe(this.props, i) ? !1 : (this.cacheValues(this.getCalculatedValues(i)), !0) : (this.cacheValues(this.getCalculatedValues(i)), !0)
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    var i = this,
                        o = ee(this.globalEvents);
                    o.forEach(function(u) {
                        return i.addGlobalListener(u)
                    }), this.prevGlobalEventKeys = o
                }
            }, {
                key: "componentDidUpdate",
                value: function(i) {
                    var o = this,
                        u = this.getStateChanges(i);
                    this.calculatedState = u;
                    var l = ee(this.globalEvents),
                        c = Gr(this.prevGlobalEventKeys, l);
                    c.forEach(function(h) {
                        return o.removeGlobalListener(h)
                    });
                    var f = Gr(l, this.prevGlobalEventKeys);
                    f.forEach(function(h) {
                        return o.addGlobalListener(h)
                    }), this.prevGlobalEventKeys = l
                }
            }, {
                key: "componentWillUnmount",
                value: function() {
                    var i = this;
                    this.prevGlobalEventKeys.forEach(function(o) {
                        return i.removeGlobalListener(o)
                    })
                }
            }, {
                key: "addGlobalListener",
                value: function(i) {
                    var o = this,
                        u = function(l) {
                            var c = o.globalEvents[i];
                            return c && c($f(l))
                        };
                    this.boundGlobalEvents[i] = u, window.addEventListener(Vr(i), u)
                }
            }, {
                key: "removeGlobalListener",
                value: function(i) {
                    window.removeEventListener(Vr(i), this.boundGlobalEvents[i])
                }
            }, {
                key: "getStateChanges",
                value: function(i) {
                    var o = this;
                    if (!this.hasEvents) return {};
                    var u = function(f, h) {
                        var d = L({}, o.getEventState(f, h), o.getSharedEventState(f, h));
                        return re(d) ? void 0 : d
                    };
                    t = t || {};
                    var l = t.components || r9,
                        c = l.map(function(f) {
                            if (!(!i.standalone && f.name === "parent")) return f.index !== void 0 ? u(f.index, f.name) : o.dataKeys.map(function(h) {
                                return u(h, f.name)
                            }).filter(Boolean)
                        }).filter(Boolean);
                    return c
                }
            }, {
                key: "applyExternalMutations",
                value: function(i, o) {
                    if (!re(o)) {
                        var u = i.externalEventMutations.reduce(function(c, f) {
                                return c = H(f.callback) ? c.concat(f.callback) : c, c
                            }, []),
                            l = u.length ? function() {
                                u.forEach(function(c) {
                                    return c()
                                })
                            } : void 0;
                        this.setState(o, l)
                    }
                }
            }, {
                key: "getCalculatedValues",
                value: function(i) {
                    var o = i.sharedEvents,
                        u = e.expectedComponents,
                        l = ko(i, u),
                        c = o && H(o.getEventState) ? o.getEventState : function() {},
                        f = this.getBaseProps(i, c),
                        h = ee(f).filter(function(v) {
                            return v !== "parent"
                        }),
                        d = i.events || i.sharedEvents || l,
                        y = this.getAllEvents(i);
                    return {
                        componentEvents: l,
                        getSharedEventState: c,
                        baseProps: f,
                        dataKeys: h,
                        hasEvents: d,
                        events: y
                    }
                }
            }, {
                key: "getExternalMutations",
                value: function(i) {
                    var o = i.sharedEvents,
                        u = i.externalEventMutations;
                    return re(u) || o ? void 0 : Ef(u, this.baseProps, this.state)
                }
            }, {
                key: "cacheValues",
                value: function(i) {
                    var o = this;
                    ee(i).forEach(function(u) {
                        o[u] = i[u]
                    })
                }
            }, {
                key: "getBaseProps",
                value: function(i, o) {
                    o = o || this.getSharedEventState;
                    var u = o("parent", "parent"),
                        l = this.getEventState("parent", "parent"),
                        c = L({}, l, u),
                        f = c.parentControlledProps,
                        h = f ? Xn(c, f) : {},
                        d = L({}, h, i);
                    return H(e.getBaseProps) ? e.getBaseProps(d) : {}
                }
            }, {
                key: "getAllEvents",
                value: function(i) {
                    if (Array.isArray(this.componentEvents)) {
                        var o;
                        return Array.isArray(i.events) ? (o = this.componentEvents).concat.apply(o, Ar(i.events)) : this.componentEvents
                    }
                    return i.events
                }
            }, {
                key: "getComponentProps",
                value: function(i, o, u) {
                    var l = this.props.name || e.role,
                        c = this.dataKeys && this.dataKeys[u] || u,
                        f = "".concat(l, "-").concat(o, "-").concat(c),
                        h = this.baseProps[c] && this.baseProps[c][o] || this.baseProps[c];
                    if (!(!h && !this.hasEvents)) {
                        if (this.hasEvents) {
                            var d = this.getEvents(this.props, o, c),
                                y = L({
                                    index: u,
                                    key: f
                                }, this.getEventState(c, o), this.getSharedEventState(c, o), i.props, h, {
                                    id: f
                                }),
                                v = L({}, Tf(d, c, y), y.events);
                            return S({}, y, {
                                events: v
                            })
                        }
                        return L({
                            index: u,
                            key: f
                        }, i.props, h, {
                            id: f
                        })
                    }
                }
            }, {
                key: "renderContainer",
                value: function(i, o) {
                    var u = i.type && i.type.role === "container",
                        l = u ? this.getComponentProps(i, "parent", "parent") : {};
                    return l.events && (this.globalEvents = Mf(l.events), l.events = Cf(l.events)), A.cloneElement(i, l, o)
                }
            }, {
                key: "animateComponent",
                value: function(i, o) {
                    var u = i.animate && i.animate.animationWhitelist ? i.animate.animationWhitelist : o;
                    return A.createElement(Ma, {
                        animate: i.animate,
                        animationWhitelist: u
                    }, A.createElement(this.constructor, i))
                }
            }, {
                key: "renderContinuousData",
                value: function(i) {
                    var o = this,
                        u = i.dataComponent,
                        l = i.labelComponent,
                        c = i.groupComponent,
                        f = Pr(this.dataKeys, "all"),
                        h = f.reduce(function(v, b) {
                            var g = o.getComponentProps(l, "labels", b);
                            return g && g.text !== void 0 && g.text !== null && (v = v.concat(A.cloneElement(l, g))), v
                        }, []),
                        d = this.getComponentProps(u, "data", "all"),
                        y = [A.cloneElement(u, d)].concat(Ar(h));
                    return this.renderContainer(c, y)
                }
            }, {
                key: "renderData",
                value: function(i) {
                    var o = this,
                        u = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : n9,
                        l = i.dataComponent,
                        c = i.labelComponent,
                        f = i.groupComponent,
                        h = Ea(i),
                        d = this.dataKeys.reduce(function(g, p, m) {
                            var _ = o.getComponentProps(l, "data", m);
                            return u(_.datum) && g.push(A.cloneElement(l, _)), g
                        }, []),
                        y = this.dataKeys.map(function(g, p) {
                            var m = o.getComponentProps(c, "labels", p);
                            if (m.text !== void 0 && m.text !== null) return A.cloneElement(c, m)
                        }).filter(Boolean),
                        v = Ar(d).concat(Ar(y)),
                        b = A.cloneElement(f, h, v);
                    return this.renderContainer(b, v)
                }
            }]), r
        }(e)
    },
    i9 = yo;

function o9(e, t) {
    return i9(e, t)
}
var u9 = o9;

function l9(e) {
    var t = e == null ? 0 : e.length;
    return t ? e[t - 1] : void 0
}
var c9 = l9;

function Io(e, t) {
    return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN
}

function Pf(e) {
    return e.length === 1 && (e = f9(e)), {
        left: function(t, n, r, a) {
            for (r == null && (r = 0), a == null && (a = t.length); r < a;) {
                var i = r + a >>> 1;
                e(t[i], n) < 0 ? r = i + 1 : a = i
            }
            return r
        },
        right: function(t, n, r, a) {
            for (r == null && (r = 0), a == null && (a = t.length); r < a;) {
                var i = r + a >>> 1;
                e(t[i], n) > 0 ? a = i : r = i + 1
            }
            return r
        }
    }
}

function f9(e) {
    return function(t, n) {
        return Io(e(t), n)
    }
}
var s9 = Pf(Io),
    Ca = s9.right;

function h9(e) {
    return e === null ? NaN : +e
}

function d9(e, t, n) {
    e = +e, t = +t, n = (a = arguments.length) < 2 ? (t = e, e = 0, 1) : a < 3 ? 1 : +n;
    for (var r = -1, a = Math.max(0, Math.ceil((t - e) / n)) | 0, i = new Array(a); ++r < a;) i[r] = e + r * n;
    return i
}
var Pi = Math.sqrt(50),
    ki = Math.sqrt(10),
    Ii = Math.sqrt(2);

function kf(e, t, n) {
    var r, a = -1,
        i, o, u;
    if (t = +t, e = +e, n = +n, e === t && n > 0) return [e];
    if ((r = t < e) && (i = e, e = t, t = i), (u = Ir(e, t, n)) === 0 || !isFinite(u)) return [];
    if (u > 0)
        for (e = Math.ceil(e / u), t = Math.floor(t / u), o = new Array(i = Math.ceil(t - e + 1)); ++a < i;) o[a] = (e + a) * u;
    else
        for (e = Math.floor(e * u), t = Math.ceil(t * u), o = new Array(i = Math.ceil(e - t + 1)); ++a < i;) o[a] = (e - a) / u;
    return r && o.reverse(), o
}

function Ir(e, t, n) {
    var r = (t - e) / Math.max(0, n),
        a = Math.floor(Math.log(r) / Math.LN10),
        i = r / Math.pow(10, a);
    return a >= 0 ? (i >= Pi ? 10 : i >= ki ? 5 : i >= Ii ? 2 : 1) * Math.pow(10, a) : -Math.pow(10, -a) / (i >= Pi ? 10 : i >= ki ? 5 : i >= Ii ? 2 : 1)
}

function Di(e, t, n) {
    var r = Math.abs(t - e) / Math.max(0, n),
        a = Math.pow(10, Math.floor(Math.log(r) / Math.LN10)),
        i = r / a;
    return i >= Pi ? a *= 10 : i >= ki ? a *= 5 : i >= Ii && (a *= 2), t < e ? -a : a
}

function v9(e, t, n) {
    if (n == null && (n = h9), !!(r = e.length)) {
        if ((t = +t) <= 0 || r < 2) return +n(e[0], 0, e);
        if (t >= 1) return +n(e[r - 1], r - 1, e);
        var r, a = (r - 1) * t,
            i = Math.floor(a),
            o = +n(e[i], i, e),
            u = +n(e[i + 1], i + 1, e);
        return o + (u - o) * (a - i)
    }
}
var Ie = "$";

function Yr() {}
Yr.prototype = Kr.prototype = {
    constructor: Yr,
    has: function(e) {
        return Ie + e in this
    },
    get: function(e) {
        return this[Ie + e]
    },
    set: function(e, t) {
        return this[Ie + e] = t, this
    },
    remove: function(e) {
        var t = Ie + e;
        return t in this && delete this[t]
    },
    clear: function() {
        for (var e in this) e[0] === Ie && delete this[e]
    },
    keys: function() {
        var e = [];
        for (var t in this) t[0] === Ie && e.push(t.slice(1));
        return e
    },
    values: function() {
        var e = [];
        for (var t in this) t[0] === Ie && e.push(this[t]);
        return e
    },
    entries: function() {
        var e = [];
        for (var t in this) t[0] === Ie && e.push({
            key: t.slice(1),
            value: this[t]
        });
        return e
    },
    size: function() {
        var e = 0;
        for (var t in this) t[0] === Ie && ++e;
        return e
    },
    empty: function() {
        for (var e in this)
            if (e[0] === Ie) return !1;
        return !0
    },
    each: function(e) {
        for (var t in this) t[0] === Ie && e(this[t], t.slice(1), this)
    }
};

function Kr(e, t) {
    var n = new Yr;
    if (e instanceof Yr) e.each(function(u, l) {
        n.set(l, u)
    });
    else if (Array.isArray(e)) {
        var r = -1,
            a = e.length,
            i;
        if (t == null)
            for (; ++r < a;) n.set(r, e[r]);
        else
            for (; ++r < a;) n.set(t(i = e[r], r, e), i)
    } else if (e)
        for (var o in e) n.set(o, e[o]);
    return n
}

function Kl() {}
var wt = Kr.prototype;
Kl.prototype = {
    constructor: Kl,
    has: wt.has,
    add: function(e) {
        return e += "", this[Ie + e] = e, this
    },
    remove: wt.remove,
    clear: wt.clear,
    values: wt.keys,
    size: wt.size,
    empty: wt.empty,
    each: wt.each
};
var If = Array.prototype,
    Do = If.map,
    dt = If.slice,
    Ni = {
        name: "implicit"
    };

function No(e) {
    var t = Kr(),
        n = [],
        r = Ni;
    e = e == null ? [] : dt.call(e);

    function a(i) {
        var o = i + "",
            u = t.get(o);
        if (!u) {
            if (r !== Ni) return r;
            t.set(o, u = n.push(i))
        }
        return e[(u - 1) % e.length]
    }
    return a.domain = function(i) {
        if (!arguments.length) return n.slice();
        n = [], t = Kr();
        for (var o = -1, u = i.length, l, c; ++o < u;) t.has(c = (l = i[o]) + "") || t.set(c, n.push(l));
        return a
    }, a.range = function(i) {
        return arguments.length ? (e = dt.call(i), a) : e.slice()
    }, a.unknown = function(i) {
        return arguments.length ? (r = i, a) : r
    }, a.copy = function() {
        return No().domain(n).range(e).unknown(r)
    }, a
}

function Lo() {
    var e = No().unknown(void 0),
        t = e.domain,
        n = e.range,
        r = [0, 1],
        a, i, o = !1,
        u = 0,
        l = 0,
        c = .5;
    delete e.unknown;

    function f() {
        var h = t().length,
            d = r[1] < r[0],
            y = r[d - 0],
            v = r[1 - d];
        a = (v - y) / Math.max(1, h - u + l * 2), o && (a = Math.floor(a)), y += (v - y - a * (h - u)) * c, i = a * (1 - u), o && (y = Math.round(y), i = Math.round(i));
        var b = d9(h).map(function(g) {
            return y + a * g
        });
        return n(d ? b.reverse() : b)
    }
    return e.domain = function(h) {
        return arguments.length ? (t(h), f()) : t()
    }, e.range = function(h) {
        return arguments.length ? (r = [+h[0], +h[1]], f()) : r.slice()
    }, e.rangeRound = function(h) {
        return r = [+h[0], +h[1]], o = !0, f()
    }, e.bandwidth = function() {
        return i
    }, e.step = function() {
        return a
    }, e.round = function(h) {
        return arguments.length ? (o = !!h, f()) : o
    }, e.padding = function(h) {
        return arguments.length ? (u = l = Math.max(0, Math.min(1, h)), f()) : u
    }, e.paddingInner = function(h) {
        return arguments.length ? (u = Math.max(0, Math.min(1, h)), f()) : u
    }, e.paddingOuter = function(h) {
        return arguments.length ? (l = Math.max(0, Math.min(1, h)), f()) : l
    }, e.align = function(h) {
        return arguments.length ? (c = Math.max(0, Math.min(1, h)), f()) : c
    }, e.copy = function() {
        return Lo().domain(t()).range(r).round(o).paddingInner(u).paddingOuter(l).align(c)
    }, f()
}

function Df(e) {
    var t = e.copy;
    return e.padding = e.paddingOuter, delete e.paddingInner, delete e.paddingOuter, e.copy = function() {
        return Df(t())
    }, e
}

function g9() {
    return Df(Lo().paddingInner(1))
}

function jo(e) {
    return function() {
        return e
    }
}

function Nf(e) {
    return +e
}
var Xl = [0, 1];

function Ro(e, t) {
    return (t -= e = +e) ? function(n) {
        return (n - e) / t
    } : jo(t)
}

function y9(e) {
    return function(t, n) {
        var r = e(t = +t, n = +n);
        return function(a) {
            return a <= t ? 0 : a >= n ? 1 : r(a)
        }
    }
}

function m9(e) {
    return function(t, n) {
        var r = e(t = +t, n = +n);
        return function(a) {
            return a <= 0 ? t : a >= 1 ? n : r(a)
        }
    }
}

function b9(e, t, n, r) {
    var a = e[0],
        i = e[1],
        o = t[0],
        u = t[1];
    return i < a ? (a = n(i, a), o = r(u, o)) : (a = n(a, i), o = r(o, u)),
        function(l) {
            return o(a(l))
        }
}

function p9(e, t, n, r) {
    var a = Math.min(e.length, t.length) - 1,
        i = new Array(a),
        o = new Array(a),
        u = -1;
    for (e[a] < e[0] && (e = e.slice().reverse(), t = t.slice().reverse()); ++u < a;) i[u] = n(e[u], e[u + 1]), o[u] = r(t[u], t[u + 1]);
    return function(l) {
        var c = Ca(e, l, 1, a) - 1;
        return o[c](i[c](l))
    }
}

function $a(e, t) {
    return t.domain(e.domain()).range(e.range()).interpolate(e.interpolate()).clamp(e.clamp())
}

function Pa(e, t) {
    var n = Xl,
        r = Xl,
        a = Lt,
        i = !1,
        o, u, l;

    function c() {
        return o = Math.min(n.length, r.length) > 2 ? p9 : b9, u = l = null, f
    }

    function f(h) {
        return (u || (u = o(n, r, i ? y9(e) : e, a)))(+h)
    }
    return f.invert = function(h) {
        return (l || (l = o(r, n, Ro, i ? m9(t) : t)))(+h)
    }, f.domain = function(h) {
        return arguments.length ? (n = Do.call(h, Nf), c()) : n.slice()
    }, f.range = function(h) {
        return arguments.length ? (r = dt.call(h), c()) : r.slice()
    }, f.rangeRound = function(h) {
        return r = dt.call(h), a = rb, c()
    }, f.clamp = function(h) {
        return arguments.length ? (i = !!h, c()) : i
    }, f.interpolate = function(h) {
        return arguments.length ? (a = h, c()) : a
    }, c()
}

function _9(e) {
    return Math.abs(e = Math.round(e)) >= 1e21 ? e.toLocaleString("en").replace(/,/g, "") : e.toString(10)
}

function Xr(e, t) {
    if ((n = (e = t ? e.toExponential(t - 1) : e.toExponential()).indexOf("e")) < 0) return null;
    var n, r = e.slice(0, n);
    return [r.length > 1 ? r[0] + r.slice(2) : r, +e.slice(n + 1)]
}

function Jt(e) {
    return e = Xr(Math.abs(e)), e ? e[1] : NaN
}

function x9(e, t) {
    return function(n, r) {
        for (var a = n.length, i = [], o = 0, u = e[0], l = 0; a > 0 && u > 0 && (l + u + 1 > r && (u = Math.max(1, r - l)), i.push(n.substring(a -= u, a + u)), !((l += u + 1) > r));) u = e[o = (o + 1) % e.length];
        return i.reverse().join(t)
    }
}

function w9(e) {
    return function(t) {
        return t.replace(/[0-9]/g, function(n) {
            return e[+n]
        })
    }
}
var A9 = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;

function Zr(e) {
    if (!(t = A9.exec(e))) throw new Error("invalid format: " + e);
    var t;
    return new Fo({
        fill: t[1],
        align: t[2],
        sign: t[3],
        symbol: t[4],
        zero: t[5],
        width: t[6],
        comma: t[7],
        precision: t[8] && t[8].slice(1),
        trim: t[9],
        type: t[10]
    })
}
Zr.prototype = Fo.prototype;

function Fo(e) {
    this.fill = e.fill === void 0 ? " " : e.fill + "", this.align = e.align === void 0 ? ">" : e.align + "", this.sign = e.sign === void 0 ? "-" : e.sign + "", this.symbol = e.symbol === void 0 ? "" : e.symbol + "", this.zero = !!e.zero, this.width = e.width === void 0 ? void 0 : +e.width, this.comma = !!e.comma, this.precision = e.precision === void 0 ? void 0 : +e.precision, this.trim = !!e.trim, this.type = e.type === void 0 ? "" : e.type + ""
}
Fo.prototype.toString = function() {
    return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type
};

function O9(e) {
    e: for (var t = e.length, n = 1, r = -1, a; n < t; ++n) switch (e[n]) {
        case ".":
            r = a = n;
            break;
        case "0":
            r === 0 && (r = n), a = n;
            break;
        default:
            if (!+e[n]) break e;
            r > 0 && (r = 0);
            break
    }
    return r > 0 ? e.slice(0, r) + e.slice(a + 1) : e
}
var Lf;

function T9(e, t) {
    var n = Xr(e, t);
    if (!n) return e + "";
    var r = n[0],
        a = n[1],
        i = a - (Lf = Math.max(-8, Math.min(8, Math.floor(a / 3))) * 3) + 1,
        o = r.length;
    return i === o ? r : i > o ? r + new Array(i - o + 1).join("0") : i > 0 ? r.slice(0, i) + "." + r.slice(i) : "0." + new Array(1 - i).join("0") + Xr(e, Math.max(0, t + i - 1))[0]
}

function Zl(e, t) {
    var n = Xr(e, t);
    if (!n) return e + "";
    var r = n[0],
        a = n[1];
    return a < 0 ? "0." + new Array(-a).join("0") + r : r.length > a + 1 ? r.slice(0, a + 1) + "." + r.slice(a + 1) : r + new Array(a - r.length + 2).join("0")
}
var Ql = {
    "%": function(e, t) {
        return (e * 100).toFixed(t)
    },
    b: function(e) {
        return Math.round(e).toString(2)
    },
    c: function(e) {
        return e + ""
    },
    d: _9,
    e: function(e, t) {
        return e.toExponential(t)
    },
    f: function(e, t) {
        return e.toFixed(t)
    },
    g: function(e, t) {
        return e.toPrecision(t)
    },
    o: function(e) {
        return Math.round(e).toString(8)
    },
    p: function(e, t) {
        return Zl(e * 100, t)
    },
    r: Zl,
    s: T9,
    X: function(e) {
        return Math.round(e).toString(16).toUpperCase()
    },
    x: function(e) {
        return Math.round(e).toString(16)
    }
};

function Jl(e) {
    return e
}
var e0 = Array.prototype.map,
    t0 = ["y", "z", "a", "f", "p", "n", "\xB5", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];

function S9(e) {
    var t = e.grouping === void 0 || e.thousands === void 0 ? Jl : x9(e0.call(e.grouping, Number), e.thousands + ""),
        n = e.currency === void 0 ? "" : e.currency[0] + "",
        r = e.currency === void 0 ? "" : e.currency[1] + "",
        a = e.decimal === void 0 ? "." : e.decimal + "",
        i = e.numerals === void 0 ? Jl : w9(e0.call(e.numerals, String)),
        o = e.percent === void 0 ? "%" : e.percent + "",
        u = e.minus === void 0 ? "-" : e.minus + "",
        l = e.nan === void 0 ? "NaN" : e.nan + "";

    function c(h) {
        h = Zr(h);
        var d = h.fill,
            y = h.align,
            v = h.sign,
            b = h.symbol,
            g = h.zero,
            p = h.width,
            m = h.comma,
            _ = h.precision,
            w = h.trim,
            O = h.type;
        O === "n" ? (m = !0, O = "g") : Ql[O] || (_ === void 0 && (_ = 12), w = !0, O = "g"), (g || d === "0" && y === "=") && (g = !0, d = "0", y = "=");
        var T = b === "$" ? n : b === "#" && /[boxX]/.test(O) ? "0" + O.toLowerCase() : "",
            x = b === "$" ? r : /[%p]/.test(O) ? o : "",
            M = Ql[O],
            C = /[defgprs%]/.test(O);
        _ = _ === void 0 ? 6 : /[gprs]/.test(O) ? Math.max(1, Math.min(21, _)) : Math.max(0, Math.min(20, _));

        function I($) {
            var E = T,
                k = x,
                F, Z, Y;
            if (O === "c") k = M($) + k, $ = "";
            else {
                $ = +$;
                var X = $ < 0 || 1 / $ < 0;
                if ($ = isNaN($) ? l : M(Math.abs($), _), w && ($ = O9($)), X && +$ == 0 && v !== "+" && (X = !1), E = (X ? v === "(" ? v : u : v === "-" || v === "(" ? "" : v) + E, k = (O === "s" ? t0[8 + Lf / 3] : "") + k + (X && v === "(" ? ")" : ""), C) {
                    for (F = -1, Z = $.length; ++F < Z;)
                        if (Y = $.charCodeAt(F), 48 > Y || Y > 57) {
                            k = (Y === 46 ? a + $.slice(F + 1) : $.slice(F)) + k, $ = $.slice(0, F);
                            break
                        }
                }
            }
            m && !g && ($ = t($, 1 / 0));
            var K = E.length + $.length + k.length,
                z = K < p ? new Array(p - K + 1).join(d) : "";
            switch (m && g && ($ = t(z + $, z.length ? p - k.length : 1 / 0), z = ""), y) {
                case "<":
                    $ = E + $ + k + z;
                    break;
                case "=":
                    $ = E + z + $ + k;
                    break;
                case "^":
                    $ = z.slice(0, K = z.length >> 1) + E + $ + k + z.slice(K);
                    break;
                default:
                    $ = z + E + $ + k;
                    break
            }
            return i($)
        }
        return I.toString = function() {
            return h + ""
        }, I
    }

    function f(h, d) {
        var y = c((h = Zr(h), h.type = "f", h)),
            v = Math.max(-8, Math.min(8, Math.floor(Jt(d) / 3))) * 3,
            b = Math.pow(10, -v),
            g = t0[8 + v / 3];
        return function(p) {
            return y(b * p) + g
        }
    }
    return {
        format: c,
        formatPrefix: f
    }
}
var Or, Wo, jf;
E9({
    decimal: ".",
    thousands: ",",
    grouping: [3],
    currency: ["$", ""],
    minus: "-"
});

function E9(e) {
    return Or = S9(e), Wo = Or.format, jf = Or.formatPrefix, Or
}

function M9(e) {
    return Math.max(0, -Jt(Math.abs(e)))
}

function C9(e, t) {
    return Math.max(0, Math.max(-8, Math.min(8, Math.floor(Jt(t) / 3))) * 3 - Jt(Math.abs(e)))
}

function $9(e, t) {
    return e = Math.abs(e), t = Math.abs(t) - e, Math.max(0, Jt(t) - Jt(e)) + 1
}

function P9(e, t, n) {
    var r = e[0],
        a = e[e.length - 1],
        i = Di(r, a, t == null ? 10 : t),
        o;
    switch (n = Zr(n == null ? ",f" : n), n.type) {
        case "s":
            {
                var u = Math.max(Math.abs(r), Math.abs(a));
                return n.precision == null && !isNaN(o = C9(i, u)) && (n.precision = o),
                jf(n, u)
            }
        case "":
        case "e":
        case "g":
        case "p":
        case "r":
            {
                n.precision == null && !isNaN(o = $9(i, Math.max(Math.abs(r), Math.abs(a)))) && (n.precision = o - (n.type === "e"));
                break
            }
        case "f":
        case "%":
            {
                n.precision == null && !isNaN(o = M9(i)) && (n.precision = o - (n.type === "%") * 2);
                break
            }
    }
    return Wo(n)
}

function hr(e) {
    var t = e.domain;
    return e.ticks = function(n) {
        var r = t();
        return kf(r[0], r[r.length - 1], n == null ? 10 : n)
    }, e.tickFormat = function(n, r) {
        return P9(t(), n, r)
    }, e.nice = function(n) {
        n == null && (n = 10);
        var r = t(),
            a = 0,
            i = r.length - 1,
            o = r[a],
            u = r[i],
            l;
        return u < o && (l = o, o = u, u = l, l = a, a = i, i = l), l = Ir(o, u, n), l > 0 ? (o = Math.floor(o / l) * l, u = Math.ceil(u / l) * l, l = Ir(o, u, n)) : l < 0 && (o = Math.ceil(o * l) / l, u = Math.floor(u * l) / l, l = Ir(o, u, n)), l > 0 ? (r[a] = Math.floor(o / l) * l, r[i] = Math.ceil(u / l) * l, t(r)) : l < 0 && (r[a] = Math.ceil(o * l) / l, r[i] = Math.floor(u * l) / l, t(r)), e
    }, e
}

function zo() {
    var e = Pa(Ro, Yn);
    return e.copy = function() {
        return $a(e, zo())
    }, hr(e)
}

function Rf() {
    var e = [0, 1];

    function t(n) {
        return +n
    }
    return t.invert = t, t.domain = t.range = function(n) {
        return arguments.length ? (e = Do.call(n, Nf), t) : e.slice()
    }, t.copy = function() {
        return Rf().domain(e)
    }, hr(t)
}

function Ff(e, t) {
    e = e.slice();
    var n = 0,
        r = e.length - 1,
        a = e[n],
        i = e[r],
        o;
    return i < a && (o = n, n = r, r = o, o = a, a = i, i = o), e[n] = t.floor(a), e[r] = t.ceil(i), e
}

function k9(e, t) {
    return (t = Math.log(t / e)) ? function(n) {
        return Math.log(n / e) / t
    } : jo(t)
}

function I9(e, t) {
    return e < 0 ? function(n) {
        return -Math.pow(-t, n) * Math.pow(-e, 1 - n)
    } : function(n) {
        return Math.pow(t, n) * Math.pow(e, 1 - n)
    }
}

function D9(e) {
    return isFinite(e) ? +("1e" + e) : e < 0 ? 0 : e
}

function n0(e) {
    return e === 10 ? D9 : e === Math.E ? Math.exp : function(t) {
        return Math.pow(e, t)
    }
}

function r0(e) {
    return e === Math.E ? Math.log : e === 10 && Math.log10 || e === 2 && Math.log2 || (e = Math.log(e), function(t) {
        return Math.log(t) / e
    })
}

function a0(e) {
    return function(t) {
        return -e(-t)
    }
}

function Wf() {
    var e = Pa(k9, I9).domain([1, 10]),
        t = e.domain,
        n = 10,
        r = r0(10),
        a = n0(10);

    function i() {
        return r = r0(n), a = n0(n), t()[0] < 0 && (r = a0(r), a = a0(a)), e
    }
    return e.base = function(o) {
        return arguments.length ? (n = +o, i()) : n
    }, e.domain = function(o) {
        return arguments.length ? (t(o), i()) : t()
    }, e.ticks = function(o) {
        var u = t(),
            l = u[0],
            c = u[u.length - 1],
            f;
        (f = c < l) && (h = l, l = c, c = h);
        var h = r(l),
            d = r(c),
            y, v, b, g = o == null ? 10 : +o,
            p = [];
        if (!(n % 1) && d - h < g) {
            if (h = Math.round(h) - 1, d = Math.round(d) + 1, l > 0) {
                for (; h < d; ++h)
                    for (v = 1, y = a(h); v < n; ++v)
                        if (b = y * v, !(b < l)) {
                            if (b > c) break;
                            p.push(b)
                        }
            } else
                for (; h < d; ++h)
                    for (v = n - 1, y = a(h); v >= 1; --v)
                        if (b = y * v, !(b < l)) {
                            if (b > c) break;
                            p.push(b)
                        }
        } else p = kf(h, d, Math.min(d - h, g)).map(a);
        return f ? p.reverse() : p
    }, e.tickFormat = function(o, u) {
        if (u == null && (u = n === 10 ? ".0e" : ","), typeof u != "function" && (u = Wo(u)), o === 1 / 0) return u;
        o == null && (o = 10);
        var l = Math.max(1, n * o / e.ticks().length);
        return function(c) {
            var f = c / a(Math.round(r(c)));
            return f * n < n - .5 && (f *= n), f <= l ? u(c) : ""
        }
    }, e.nice = function() {
        return t(Ff(t(), {
            floor: function(o) {
                return a(Math.floor(r(o)))
            },
            ceil: function(o) {
                return a(Math.ceil(r(o)))
            }
        }))
    }, e.copy = function() {
        return $a(e, Wf().base(n))
    }, e
}

function Ut(e, t) {
    return e < 0 ? -Math.pow(-e, t) : Math.pow(e, t)
}

function Uo() {
    var e = 1,
        t = Pa(r, a),
        n = t.domain;

    function r(i, o) {
        return (o = Ut(o, e) - (i = Ut(i, e))) ? function(u) {
            return (Ut(u, e) - i) / o
        } : jo(o)
    }

    function a(i, o) {
        return o = Ut(o, e) - (i = Ut(i, e)),
            function(u) {
                return Ut(i + o * u, 1 / e)
            }
    }
    return t.exponent = function(i) {
        return arguments.length ? (e = +i, n(n())) : e
    }, t.copy = function() {
        return $a(t, Uo().exponent(e))
    }, hr(t)
}

function N9() {
    return Uo().exponent(.5)
}

function zf() {
    var e = [],
        t = [],
        n = [];

    function r() {
        var i = 0,
            o = Math.max(1, t.length);
        for (n = new Array(o - 1); ++i < o;) n[i - 1] = v9(e, i / o);
        return a
    }

    function a(i) {
        if (!isNaN(i = +i)) return t[Ca(n, i)]
    }
    return a.invertExtent = function(i) {
        var o = t.indexOf(i);
        return o < 0 ? [NaN, NaN] : [o > 0 ? n[o - 1] : e[0], o < n.length ? n[o] : e[e.length - 1]]
    }, a.domain = function(i) {
        if (!arguments.length) return e.slice();
        e = [];
        for (var o = 0, u = i.length, l; o < u; ++o) l = i[o], l != null && !isNaN(l = +l) && e.push(l);
        return e.sort(Io), r()
    }, a.range = function(i) {
        return arguments.length ? (t = dt.call(i), r()) : t.slice()
    }, a.quantiles = function() {
        return n.slice()
    }, a.copy = function() {
        return zf().domain(e).range(t)
    }, a
}

function Uf() {
    var e = 0,
        t = 1,
        n = 1,
        r = [.5],
        a = [0, 1];

    function i(u) {
        if (u <= u) return a[Ca(r, u, 0, n)]
    }

    function o() {
        var u = -1;
        for (r = new Array(n); ++u < n;) r[u] = ((u + 1) * t - (u - n) * e) / (n + 1);
        return i
    }
    return i.domain = function(u) {
        return arguments.length ? (e = +u[0], t = +u[1], o()) : [e, t]
    }, i.range = function(u) {
        return arguments.length ? (n = (a = dt.call(u)).length - 1, o()) : a.slice()
    }, i.invertExtent = function(u) {
        var l = a.indexOf(u);
        return l < 0 ? [NaN, NaN] : l < 1 ? [e, r[0]] : l >= n ? [r[n - 1], t] : [r[l - 1], r[l]]
    }, i.copy = function() {
        return Uf().domain([e, t]).range(a)
    }, hr(i)
}

function Hf() {
    var e = [.5],
        t = [0, 1],
        n = 1;

    function r(a) {
        if (a <= a) return t[Ca(e, a, 0, n)]
    }
    return r.domain = function(a) {
        return arguments.length ? (e = dt.call(a), n = Math.min(e.length, t.length - 1), r) : e.slice()
    }, r.range = function(a) {
        return arguments.length ? (t = dt.call(a), n = Math.min(e.length, t.length - 1), r) : t.slice()
    }, r.invertExtent = function(a) {
        var i = t.indexOf(a);
        return [e[i - 1], e[i]]
    }, r.copy = function() {
        return Hf().domain(e).range(t)
    }, r
}
var ti = new Date,
    ni = new Date;

function ue(e, t, n, r) {
    function a(i) {
        return e(i = arguments.length === 0 ? new Date : new Date(+i)), i
    }
    return a.floor = function(i) {
        return e(i = new Date(+i)), i
    }, a.ceil = function(i) {
        return e(i = new Date(i - 1)), t(i, 1), e(i), i
    }, a.round = function(i) {
        var o = a(i),
            u = a.ceil(i);
        return i - o < u - i ? o : u
    }, a.offset = function(i, o) {
        return t(i = new Date(+i), o == null ? 1 : Math.floor(o)), i
    }, a.range = function(i, o, u) {
        var l = [],
            c;
        if (i = a.ceil(i), u = u == null ? 1 : Math.floor(u), !(i < o) || !(u > 0)) return l;
        do l.push(c = new Date(+i)), t(i, u), e(i); while (c < i && i < o);
        return l
    }, a.filter = function(i) {
        return ue(function(o) {
            if (o >= o)
                for (; e(o), !i(o);) o.setTime(o - 1)
        }, function(o, u) {
            if (o >= o)
                if (u < 0)
                    for (; ++u <= 0;)
                        for (; t(o, -1), !i(o););
                else
                    for (; --u >= 0;)
                        for (; t(o, 1), !i(o););
        })
    }, n && (a.count = function(i, o) {
        return ti.setTime(+i), ni.setTime(+o), e(ti), e(ni), Math.floor(n(ti, ni))
    }, a.every = function(i) {
        return i = Math.floor(i), !isFinite(i) || !(i > 0) ? null : i > 1 ? a.filter(r ? function(o) {
            return r(o) % i === 0
        } : function(o) {
            return a.count(0, o) % i === 0
        }) : a
    }), a
}
var Li = ue(function() {}, function(e, t) {
    e.setTime(+e + t)
}, function(e, t) {
    return t - e
});
Li.every = function(e) {
    return e = Math.floor(e), !isFinite(e) || !(e > 0) ? null : e > 1 ? ue(function(t) {
        t.setTime(Math.floor(t / e) * e)
    }, function(t, n) {
        t.setTime(+t + n * e)
    }, function(t, n) {
        return (n - t) / e
    }) : Li
};
var Bf = Li,
    Qr = 1e3,
    It = 6e4,
    Jr = 36e5,
    Gf = 864e5,
    qf = 6048e5,
    L9 = ue(function(e) {
        e.setTime(e - e.getMilliseconds())
    }, function(e, t) {
        e.setTime(+e + t * Qr)
    }, function(e, t) {
        return (t - e) / Qr
    }, function(e) {
        return e.getUTCSeconds()
    }),
    Vf = L9,
    j9 = ue(function(e) {
        e.setTime(e - e.getMilliseconds() - e.getSeconds() * Qr)
    }, function(e, t) {
        e.setTime(+e + t * It)
    }, function(e, t) {
        return (t - e) / It
    }, function(e) {
        return e.getMinutes()
    }),
    R9 = j9,
    F9 = ue(function(e) {
        e.setTime(e - e.getMilliseconds() - e.getSeconds() * Qr - e.getMinutes() * It)
    }, function(e, t) {
        e.setTime(+e + t * Jr)
    }, function(e, t) {
        return (t - e) / Jr
    }, function(e) {
        return e.getHours()
    }),
    W9 = F9,
    z9 = ue(function(e) {
        e.setHours(0, 0, 0, 0)
    }, function(e, t) {
        e.setDate(e.getDate() + t)
    }, function(e, t) {
        return (t - e - (t.getTimezoneOffset() - e.getTimezoneOffset()) * It) / Gf
    }, function(e) {
        return e.getDate() - 1
    }),
    Ho = z9;

function Ft(e) {
    return ue(function(t) {
        t.setDate(t.getDate() - (t.getDay() + 7 - e) % 7), t.setHours(0, 0, 0, 0)
    }, function(t, n) {
        t.setDate(t.getDate() + n * 7)
    }, function(t, n) {
        return (n - t - (n.getTimezoneOffset() - t.getTimezoneOffset()) * It) / qf
    })
}
var Yf = Ft(0),
    ji = Ft(1);
Ft(2);
Ft(3);
var Qn = Ft(4);
Ft(5);
Ft(6);
var U9 = ue(function(e) {
        e.setDate(1), e.setHours(0, 0, 0, 0)
    }, function(e, t) {
        e.setMonth(e.getMonth() + t)
    }, function(e, t) {
        return t.getMonth() - e.getMonth() + (t.getFullYear() - e.getFullYear()) * 12
    }, function(e) {
        return e.getMonth()
    }),
    H9 = U9,
    Kf = ue(function(e) {
        e.setMonth(0, 1), e.setHours(0, 0, 0, 0)
    }, function(e, t) {
        e.setFullYear(e.getFullYear() + t)
    }, function(e, t) {
        return t.getFullYear() - e.getFullYear()
    }, function(e) {
        return e.getFullYear()
    });
Kf.every = function(e) {
    return !isFinite(e = Math.floor(e)) || !(e > 0) ? null : ue(function(t) {
        t.setFullYear(Math.floor(t.getFullYear() / e) * e), t.setMonth(0, 1), t.setHours(0, 0, 0, 0)
    }, function(t, n) {
        t.setFullYear(t.getFullYear() + n * e)
    })
};
var en = Kf,
    B9 = ue(function(e) {
        e.setUTCSeconds(0, 0)
    }, function(e, t) {
        e.setTime(+e + t * It)
    }, function(e, t) {
        return (t - e) / It
    }, function(e) {
        return e.getUTCMinutes()
    }),
    G9 = B9,
    q9 = ue(function(e) {
        e.setUTCMinutes(0, 0, 0)
    }, function(e, t) {
        e.setTime(+e + t * Jr)
    }, function(e, t) {
        return (t - e) / Jr
    }, function(e) {
        return e.getUTCHours()
    }),
    V9 = q9,
    Y9 = ue(function(e) {
        e.setUTCHours(0, 0, 0, 0)
    }, function(e, t) {
        e.setUTCDate(e.getUTCDate() + t)
    }, function(e, t) {
        return (t - e) / Gf
    }, function(e) {
        return e.getUTCDate() - 1
    }),
    Bo = Y9;

function Wt(e) {
    return ue(function(t) {
        t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 7 - e) % 7), t.setUTCHours(0, 0, 0, 0)
    }, function(t, n) {
        t.setUTCDate(t.getUTCDate() + n * 7)
    }, function(t, n) {
        return (n - t) / qf
    })
}
var Xf = Wt(0),
    Ri = Wt(1);
Wt(2);
Wt(3);
var Jn = Wt(4);
Wt(5);
Wt(6);
var K9 = ue(function(e) {
        e.setUTCDate(1), e.setUTCHours(0, 0, 0, 0)
    }, function(e, t) {
        e.setUTCMonth(e.getUTCMonth() + t)
    }, function(e, t) {
        return t.getUTCMonth() - e.getUTCMonth() + (t.getUTCFullYear() - e.getUTCFullYear()) * 12
    }, function(e) {
        return e.getUTCMonth()
    }),
    X9 = K9,
    Zf = ue(function(e) {
        e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0)
    }, function(e, t) {
        e.setUTCFullYear(e.getUTCFullYear() + t)
    }, function(e, t) {
        return t.getUTCFullYear() - e.getUTCFullYear()
    }, function(e) {
        return e.getUTCFullYear()
    });
Zf.every = function(e) {
    return !isFinite(e = Math.floor(e)) || !(e > 0) ? null : ue(function(t) {
        t.setUTCFullYear(Math.floor(t.getUTCFullYear() / e) * e), t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0)
    }, function(t, n) {
        t.setUTCFullYear(t.getUTCFullYear() + n * e)
    })
};
var tn = Zf;

function ri(e) {
    if (0 <= e.y && e.y < 100) {
        var t = new Date(-1, e.m, e.d, e.H, e.M, e.S, e.L);
        return t.setFullYear(e.y), t
    }
    return new Date(e.y, e.m, e.d, e.H, e.M, e.S, e.L)
}

function ai(e) {
    if (0 <= e.y && e.y < 100) {
        var t = new Date(Date.UTC(-1, e.m, e.d, e.H, e.M, e.S, e.L));
        return t.setUTCFullYear(e.y), t
    }
    return new Date(Date.UTC(e.y, e.m, e.d, e.H, e.M, e.S, e.L))
}

function Sn(e, t, n) {
    return {
        y: e,
        m: t,
        d: n,
        H: 0,
        M: 0,
        S: 0,
        L: 0
    }
}

function Z9(e) {
    var t = e.dateTime,
        n = e.date,
        r = e.time,
        a = e.periods,
        i = e.days,
        o = e.shortDays,
        u = e.months,
        l = e.shortMonths,
        c = En(a),
        f = Mn(a),
        h = En(i),
        d = Mn(i),
        y = En(o),
        v = Mn(o),
        b = En(u),
        g = Mn(u),
        p = En(l),
        m = Mn(l),
        _ = {
            a: X,
            A: K,
            b: z,
            B: te,
            c: null,
            d: f0,
            e: f0,
            f: _w,
            g: $w,
            G: kw,
            H: mw,
            I: bw,
            j: pw,
            L: Qf,
            m: xw,
            M: ww,
            p: Ee,
            q: ft,
            Q: d0,
            s: v0,
            S: Aw,
            u: Ow,
            U: Tw,
            V: Sw,
            w: Ew,
            W: Mw,
            x: null,
            X: null,
            y: Cw,
            Y: Pw,
            Z: Iw,
            "%": h0
        },
        w = {
            a: De,
            A: ce,
            b: Me,
            B: rt,
            c: null,
            d: s0,
            e: s0,
            f: jw,
            g: Vw,
            G: Kw,
            H: Dw,
            I: Nw,
            j: Lw,
            L: es,
            m: Rw,
            M: Fw,
            p: Ce,
            q: $e,
            Q: d0,
            s: v0,
            S: Ww,
            u: zw,
            U: Uw,
            V: Hw,
            w: Bw,
            W: Gw,
            x: null,
            X: null,
            y: qw,
            Y: Yw,
            Z: Xw,
            "%": h0
        },
        O = {
            a: I,
            A: $,
            b: E,
            B: k,
            c: F,
            d: l0,
            e: l0,
            f: dw,
            g: u0,
            G: o0,
            H: c0,
            I: c0,
            j: cw,
            L: hw,
            m: lw,
            M: fw,
            p: C,
            q: uw,
            Q: gw,
            s: yw,
            S: sw,
            u: nw,
            U: rw,
            V: aw,
            w: tw,
            W: iw,
            x: Z,
            X: Y,
            y: u0,
            Y: o0,
            Z: ow,
            "%": vw
        };
    _.x = T(n, _), _.X = T(r, _), _.c = T(t, _), w.x = T(n, w), w.X = T(r, w), w.c = T(t, w);

    function T(N, j) {
        return function(B) {
            var P = [],
                ae = -1,
                q = 0,
                se = N.length,
                he, Ne, xn;
            for (B instanceof Date || (B = new Date(+B)); ++ae < se;) N.charCodeAt(ae) === 37 && (P.push(N.slice(q, ae)), (Ne = i0[he = N.charAt(++ae)]) != null ? he = N.charAt(++ae) : Ne = he === "e" ? " " : "0", (xn = j[he]) && (he = xn(B, Ne)), P.push(he), q = ae + 1);
            return P.push(N.slice(q, ae)), P.join("")
        }
    }

    function x(N, j) {
        return function(B) {
            var P = Sn(1900, void 0, 1),
                ae = M(P, N, B += "", 0),
                q, se;
            if (ae != B.length) return null;
            if ("Q" in P) return new Date(P.Q);
            if ("s" in P) return new Date(P.s * 1e3 + ("L" in P ? P.L : 0));
            if (j && !("Z" in P) && (P.Z = 0), "p" in P && (P.H = P.H % 12 + P.p * 12), P.m === void 0 && (P.m = "q" in P ? P.q : 0), "V" in P) {
                if (P.V < 1 || P.V > 53) return null;
                "w" in P || (P.w = 1), "Z" in P ? (q = ai(Sn(P.y, 0, 1)), se = q.getUTCDay(), q = se > 4 || se === 0 ? Ri.ceil(q) : Ri(q), q = Bo.offset(q, (P.V - 1) * 7), P.y = q.getUTCFullYear(), P.m = q.getUTCMonth(), P.d = q.getUTCDate() + (P.w + 6) % 7) : (q = ri(Sn(P.y, 0, 1)), se = q.getDay(), q = se > 4 || se === 0 ? ji.ceil(q) : ji(q), q = Ho.offset(q, (P.V - 1) * 7), P.y = q.getFullYear(), P.m = q.getMonth(), P.d = q.getDate() + (P.w + 6) % 7)
            } else("W" in P || "U" in P) && ("w" in P || (P.w = "u" in P ? P.u % 7 : "W" in P ? 1 : 0), se = "Z" in P ? ai(Sn(P.y, 0, 1)).getUTCDay() : ri(Sn(P.y, 0, 1)).getDay(), P.m = 0, P.d = "W" in P ? (P.w + 6) % 7 + P.W * 7 - (se + 5) % 7 : P.w + P.U * 7 - (se + 6) % 7);
            return "Z" in P ? (P.H += P.Z / 100 | 0, P.M += P.Z % 100, ai(P)) : ri(P)
        }
    }

    function M(N, j, B, P) {
        for (var ae = 0, q = j.length, se = B.length, he, Ne; ae < q;) {
            if (P >= se) return -1;
            if (he = j.charCodeAt(ae++), he === 37) {
                if (he = j.charAt(ae++), Ne = O[he in i0 ? j.charAt(ae++) : he], !Ne || (P = Ne(N, B, P)) < 0) return -1
            } else if (he != B.charCodeAt(P++)) return -1
        }
        return P
    }

    function C(N, j, B) {
        var P = c.exec(j.slice(B));
        return P ? (N.p = f[P[0].toLowerCase()], B + P[0].length) : -1
    }

    function I(N, j, B) {
        var P = y.exec(j.slice(B));
        return P ? (N.w = v[P[0].toLowerCase()], B + P[0].length) : -1
    }

    function $(N, j, B) {
        var P = h.exec(j.slice(B));
        return P ? (N.w = d[P[0].toLowerCase()], B + P[0].length) : -1
    }

    function E(N, j, B) {
        var P = p.exec(j.slice(B));
        return P ? (N.m = m[P[0].toLowerCase()], B + P[0].length) : -1
    }

    function k(N, j, B) {
        var P = b.exec(j.slice(B));
        return P ? (N.m = g[P[0].toLowerCase()], B + P[0].length) : -1
    }

    function F(N, j, B) {
        return M(N, t, j, B)
    }

    function Z(N, j, B) {
        return M(N, n, j, B)
    }

    function Y(N, j, B) {
        return M(N, r, j, B)
    }

    function X(N) {
        return o[N.getDay()]
    }

    function K(N) {
        return i[N.getDay()]
    }

    function z(N) {
        return l[N.getMonth()]
    }

    function te(N) {
        return u[N.getMonth()]
    }

    function Ee(N) {
        return a[+(N.getHours() >= 12)]
    }

    function ft(N) {
        return 1 + ~~(N.getMonth() / 3)
    }

    function De(N) {
        return o[N.getUTCDay()]
    }

    function ce(N) {
        return i[N.getUTCDay()]
    }

    function Me(N) {
        return l[N.getUTCMonth()]
    }

    function rt(N) {
        return u[N.getUTCMonth()]
    }

    function Ce(N) {
        return a[+(N.getUTCHours() >= 12)]
    }

    function $e(N) {
        return 1 + ~~(N.getUTCMonth() / 3)
    }
    return {
        format: function(N) {
            var j = T(N += "", _);
            return j.toString = function() {
                return N
            }, j
        },
        parse: function(N) {
            var j = x(N += "", !1);
            return j.toString = function() {
                return N
            }, j
        },
        utcFormat: function(N) {
            var j = T(N += "", w);
            return j.toString = function() {
                return N
            }, j
        },
        utcParse: function(N) {
            var j = x(N += "", !0);
            return j.toString = function() {
                return N
            }, j
        }
    }
}
var i0 = {
        "-": "",
        _: " ",
        "0": "0"
    },
    le = /^\s*\d+/,
    Q9 = /^%/,
    J9 = /[\\^$*+?|[\]().{}]/g;

function V(e, t, n) {
    var r = e < 0 ? "-" : "",
        a = (r ? -e : e) + "",
        i = a.length;
    return r + (i < n ? new Array(n - i + 1).join(t) + a : a)
}

function ew(e) {
    return e.replace(J9, "\\$&")
}

function En(e) {
    return new RegExp("^(?:" + e.map(ew).join("|") + ")", "i")
}

function Mn(e) {
    for (var t = {}, n = -1, r = e.length; ++n < r;) t[e[n].toLowerCase()] = n;
    return t
}

function tw(e, t, n) {
    var r = le.exec(t.slice(n, n + 1));
    return r ? (e.w = +r[0], n + r[0].length) : -1
}

function nw(e, t, n) {
    var r = le.exec(t.slice(n, n + 1));
    return r ? (e.u = +r[0], n + r[0].length) : -1
}

function rw(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.U = +r[0], n + r[0].length) : -1
}

function aw(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.V = +r[0], n + r[0].length) : -1
}

function iw(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.W = +r[0], n + r[0].length) : -1
}

function o0(e, t, n) {
    var r = le.exec(t.slice(n, n + 4));
    return r ? (e.y = +r[0], n + r[0].length) : -1
}

function u0(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1
}

function ow(e, t, n) {
    var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(t.slice(n, n + 6));
    return r ? (e.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1
}

function uw(e, t, n) {
    var r = le.exec(t.slice(n, n + 1));
    return r ? (e.q = r[0] * 3 - 3, n + r[0].length) : -1
}

function lw(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.m = r[0] - 1, n + r[0].length) : -1
}

function l0(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.d = +r[0], n + r[0].length) : -1
}

function cw(e, t, n) {
    var r = le.exec(t.slice(n, n + 3));
    return r ? (e.m = 0, e.d = +r[0], n + r[0].length) : -1
}

function c0(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.H = +r[0], n + r[0].length) : -1
}

function fw(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.M = +r[0], n + r[0].length) : -1
}

function sw(e, t, n) {
    var r = le.exec(t.slice(n, n + 2));
    return r ? (e.S = +r[0], n + r[0].length) : -1
}

function hw(e, t, n) {
    var r = le.exec(t.slice(n, n + 3));
    return r ? (e.L = +r[0], n + r[0].length) : -1
}

function dw(e, t, n) {
    var r = le.exec(t.slice(n, n + 6));
    return r ? (e.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1
}

function vw(e, t, n) {
    var r = Q9.exec(t.slice(n, n + 1));
    return r ? n + r[0].length : -1
}

function gw(e, t, n) {
    var r = le.exec(t.slice(n));
    return r ? (e.Q = +r[0], n + r[0].length) : -1
}

function yw(e, t, n) {
    var r = le.exec(t.slice(n));
    return r ? (e.s = +r[0], n + r[0].length) : -1
}

function f0(e, t) {
    return V(e.getDate(), t, 2)
}

function mw(e, t) {
    return V(e.getHours(), t, 2)
}

function bw(e, t) {
    return V(e.getHours() % 12 || 12, t, 2)
}

function pw(e, t) {
    return V(1 + Ho.count(en(e), e), t, 3)
}

function Qf(e, t) {
    return V(e.getMilliseconds(), t, 3)
}

function _w(e, t) {
    return Qf(e, t) + "000"
}

function xw(e, t) {
    return V(e.getMonth() + 1, t, 2)
}

function ww(e, t) {
    return V(e.getMinutes(), t, 2)
}

function Aw(e, t) {
    return V(e.getSeconds(), t, 2)
}

function Ow(e) {
    var t = e.getDay();
    return t === 0 ? 7 : t
}

function Tw(e, t) {
    return V(Yf.count(en(e) - 1, e), t, 2)
}

function Jf(e) {
    var t = e.getDay();
    return t >= 4 || t === 0 ? Qn(e) : Qn.ceil(e)
}

function Sw(e, t) {
    return e = Jf(e), V(Qn.count(en(e), e) + (en(e).getDay() === 4), t, 2)
}

function Ew(e) {
    return e.getDay()
}

function Mw(e, t) {
    return V(ji.count(en(e) - 1, e), t, 2)
}

function Cw(e, t) {
    return V(e.getFullYear() % 100, t, 2)
}

function $w(e, t) {
    return e = Jf(e), V(e.getFullYear() % 100, t, 2)
}

function Pw(e, t) {
    return V(e.getFullYear() % 1e4, t, 4)
}

function kw(e, t) {
    var n = e.getDay();
    return e = n >= 4 || n === 0 ? Qn(e) : Qn.ceil(e), V(e.getFullYear() % 1e4, t, 4)
}

function Iw(e) {
    var t = e.getTimezoneOffset();
    return (t > 0 ? "-" : (t *= -1, "+")) + V(t / 60 | 0, "0", 2) + V(t % 60, "0", 2)
}

function s0(e, t) {
    return V(e.getUTCDate(), t, 2)
}

function Dw(e, t) {
    return V(e.getUTCHours(), t, 2)
}

function Nw(e, t) {
    return V(e.getUTCHours() % 12 || 12, t, 2)
}

function Lw(e, t) {
    return V(1 + Bo.count(tn(e), e), t, 3)
}

function es(e, t) {
    return V(e.getUTCMilliseconds(), t, 3)
}

function jw(e, t) {
    return es(e, t) + "000"
}

function Rw(e, t) {
    return V(e.getUTCMonth() + 1, t, 2)
}

function Fw(e, t) {
    return V(e.getUTCMinutes(), t, 2)
}

function Ww(e, t) {
    return V(e.getUTCSeconds(), t, 2)
}

function zw(e) {
    var t = e.getUTCDay();
    return t === 0 ? 7 : t
}

function Uw(e, t) {
    return V(Xf.count(tn(e) - 1, e), t, 2)
}

function ts(e) {
    var t = e.getUTCDay();
    return t >= 4 || t === 0 ? Jn(e) : Jn.ceil(e)
}

function Hw(e, t) {
    return e = ts(e), V(Jn.count(tn(e), e) + (tn(e).getUTCDay() === 4), t, 2)
}

function Bw(e) {
    return e.getUTCDay()
}

function Gw(e, t) {
    return V(Ri.count(tn(e) - 1, e), t, 2)
}

function qw(e, t) {
    return V(e.getUTCFullYear() % 100, t, 2)
}

function Vw(e, t) {
    return e = ts(e), V(e.getUTCFullYear() % 100, t, 2)
}

function Yw(e, t) {
    return V(e.getUTCFullYear() % 1e4, t, 4)
}

function Kw(e, t) {
    var n = e.getUTCDay();
    return e = n >= 4 || n === 0 ? Jn(e) : Jn.ceil(e), V(e.getUTCFullYear() % 1e4, t, 4)
}

function Xw() {
    return "+0000"
}

function h0() {
    return "%"
}

function d0(e) {
    return +e
}

function v0(e) {
    return Math.floor(+e / 1e3)
}
var Tr, ns, rs;
Zw({
    dateTime: "%x, %X",
    date: "%-m/%-d/%Y",
    time: "%-I:%M:%S %p",
    periods: ["AM", "PM"],
    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
});

function Zw(e) {
    return Tr = Z9(e), ns = Tr.format, rs = Tr.utcFormat, Tr
}
var Dn = 1e3,
    Nn = Dn * 60,
    Ln = Nn * 60,
    er = Ln * 24,
    Qw = er * 7,
    g0 = er * 30,
    ii = er * 365;

function Jw(e) {
    return new Date(e)
}

function eA(e) {
    return e instanceof Date ? +e : +new Date(+e)
}

function Go(e, t, n, r, a, i, o, u, l) {
    var c = Pa(Ro, Yn),
        f = c.invert,
        h = c.domain,
        d = l(".%L"),
        y = l(":%S"),
        v = l("%I:%M"),
        b = l("%I %p"),
        g = l("%a %d"),
        p = l("%b %d"),
        m = l("%B"),
        _ = l("%Y"),
        w = [
            [o, 1, Dn],
            [o, 5, 5 * Dn],
            [o, 15, 15 * Dn],
            [o, 30, 30 * Dn],
            [i, 1, Nn],
            [i, 5, 5 * Nn],
            [i, 15, 15 * Nn],
            [i, 30, 30 * Nn],
            [a, 1, Ln],
            [a, 3, 3 * Ln],
            [a, 6, 6 * Ln],
            [a, 12, 12 * Ln],
            [r, 1, er],
            [r, 2, 2 * er],
            [n, 1, Qw],
            [t, 1, g0],
            [t, 3, 3 * g0],
            [e, 1, ii]
        ];

    function O(x) {
        return (o(x) < x ? d : i(x) < x ? y : a(x) < x ? v : r(x) < x ? b : t(x) < x ? n(x) < x ? g : p : e(x) < x ? m : _)(x)
    }

    function T(x, M, C, I) {
        if (x == null && (x = 10), typeof x == "number") {
            var $ = Math.abs(C - M) / x,
                E = Pf(function(k) {
                    return k[2]
                }).right(w, $);
            E === w.length ? (I = Di(M / ii, C / ii, x), x = e) : E ? (E = w[$ / w[E - 1][2] < w[E][2] / $ ? E - 1 : E], I = E[1], x = E[0]) : (I = Math.max(Di(M, C, x), 1), x = u)
        }
        return I == null ? x : x.every(I)
    }
    return c.invert = function(x) {
        return new Date(f(x))
    }, c.domain = function(x) {
        return arguments.length ? h(Do.call(x, eA)) : h().map(Jw)
    }, c.ticks = function(x, M) {
        var C = h(),
            I = C[0],
            $ = C[C.length - 1],
            E = $ < I,
            k;
        return E && (k = I, I = $, $ = k), k = T(x, I, $, M), k = k ? k.range(I, $ + 1) : [], E ? k.reverse() : k
    }, c.tickFormat = function(x, M) {
        return M == null ? O : l(M)
    }, c.nice = function(x, M) {
        var C = h();
        return (x = T(x, C[0], C[C.length - 1], M)) ? h(Ff(C, x)) : c
    }, c.copy = function() {
        return $a(c, Go(e, t, n, r, a, i, o, u, l))
    }, c
}

function tA() {
    return Go(en, H9, Yf, Ho, W9, R9, Vf, Bf, ns).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)])
}

function nA() {
    return Go(tn, X9, Xf, Bo, V9, G9, Vf, Bf, rs).domain([Date.UTC(2e3, 0, 1), Date.UTC(2e3, 0, 2)])
}

function bt(e) {
    return e.match(/.{6}/g).map(function(t) {
        return "#" + t
    })
}
var rA = bt("1f77b4ff7f0e2ca02cd627289467bd8c564be377c27f7f7fbcbd2217becf"),
    aA = bt("393b795254a36b6ecf9c9ede6379398ca252b5cf6bcedb9c8c6d31bd9e39e7ba52e7cb94843c39ad494ad6616be7969c7b4173a55194ce6dbdde9ed6"),
    iA = bt("3182bd6baed69ecae1c6dbefe6550dfd8d3cfdae6bfdd0a231a35474c476a1d99bc7e9c0756bb19e9ac8bcbddcdadaeb636363969696bdbdbdd9d9d9"),
    oA = bt("1f77b4aec7e8ff7f0effbb782ca02c98df8ad62728ff98969467bdc5b0d58c564bc49c94e377c2f7b6d27f7f7fc7c7c7bcbd22dbdb8d17becf9edae5"),
    uA = Ao(Ke(300, .5, 0), Ke(-240, .5, 1)),
    lA = Ao(Ke(-100, .75, .35), Ke(80, 1.5, .8)),
    cA = Ao(Ke(260, .75, .35), Ke(80, 1.5, .8)),
    Sr = Ke();

function fA(e) {
    (e < 0 || e > 1) && (e -= Math.floor(e));
    var t = Math.abs(e - .5);
    return Sr.h = 360 * e - 100, Sr.s = 1.5 - 1.5 * t, Sr.l = .8 - .9 * t, Sr + ""
}

function ka(e) {
    var t = e.length;
    return function(n) {
        return e[Math.max(0, Math.min(t - 1, Math.floor(n * t)))]
    }
}
var sA = ka(bt("44015444025645045745055946075a46085c460a5d460b5e470d60470e6147106347116447136548146748166848176948186a481a6c481b6d481c6e481d6f481f70482071482173482374482475482576482677482878482979472a7a472c7a472d7b472e7c472f7d46307e46327e46337f463480453581453781453882443983443a83443b84433d84433e85423f854240864241864142874144874045884046883f47883f48893e49893e4a893e4c8a3d4d8a3d4e8a3c4f8a3c508b3b518b3b528b3a538b3a548c39558c39568c38588c38598c375a8c375b8d365c8d365d8d355e8d355f8d34608d34618d33628d33638d32648e32658e31668e31678e31688e30698e306a8e2f6b8e2f6c8e2e6d8e2e6e8e2e6f8e2d708e2d718e2c718e2c728e2c738e2b748e2b758e2a768e2a778e2a788e29798e297a8e297b8e287c8e287d8e277e8e277f8e27808e26818e26828e26828e25838e25848e25858e24868e24878e23888e23898e238a8d228b8d228c8d228d8d218e8d218f8d21908d21918c20928c20928c20938c1f948c1f958b1f968b1f978b1f988b1f998a1f9a8a1e9b8a1e9c891e9d891f9e891f9f881fa0881fa1881fa1871fa28720a38620a48621a58521a68522a78522a88423a98324aa8325ab8225ac8226ad8127ad8128ae8029af7f2ab07f2cb17e2db27d2eb37c2fb47c31b57b32b67a34b67935b77937b87838b9773aba763bbb753dbc743fbc7340bd7242be7144bf7046c06f48c16e4ac16d4cc26c4ec36b50c46a52c56954c56856c66758c7655ac8645cc8635ec96260ca6063cb5f65cb5e67cc5c69cd5b6ccd5a6ece5870cf5773d05675d05477d1537ad1517cd2507fd34e81d34d84d44b86d54989d5488bd6468ed64590d74393d74195d84098d83e9bd93c9dd93ba0da39a2da37a5db36a8db34aadc32addc30b0dd2fb2dd2db5de2bb8de29bade28bddf26c0df25c2df23c5e021c8e020cae11fcde11dd0e11cd2e21bd5e21ad8e219dae319dde318dfe318e2e418e5e419e7e419eae51aece51befe51cf1e51df4e61ef6e620f8e621fbe723fde725")),
    hA = ka(bt("00000401000501010601010802010902020b02020d03030f03031204041405041606051806051a07061c08071e0907200a08220b09240c09260d0a290e0b2b100b2d110c2f120d31130d34140e36150e38160f3b180f3d19103f1a10421c10441d11471e114920114b21114e22115024125325125527125829115a2a115c2c115f2d11612f116331116533106734106936106b38106c390f6e3b0f703d0f713f0f72400f74420f75440f764510774710784910784a10794c117a4e117b4f127b51127c52137c54137d56147d57157e59157e5a167e5c167f5d177f5f187f601880621980641a80651a80671b80681c816a1c816b1d816d1d816e1e81701f81721f817320817521817621817822817922827b23827c23827e24828025828125818326818426818627818827818928818b29818c29818e2a81902a81912b81932b80942c80962c80982d80992d809b2e7f9c2e7f9e2f7fa02f7fa1307ea3307ea5317ea6317da8327daa337dab337cad347cae347bb0357bb2357bb3367ab5367ab73779b83779ba3878bc3978bd3977bf3a77c03a76c23b75c43c75c53c74c73d73c83e73ca3e72cc3f71cd4071cf4070d0416fd2426fd3436ed5446dd6456cd8456cd9466bdb476adc4869de4968df4a68e04c67e24d66e34e65e44f64e55064e75263e85362e95462ea5661eb5760ec5860ed5a5fee5b5eef5d5ef05f5ef1605df2625df2645cf3655cf4675cf4695cf56b5cf66c5cf66e5cf7705cf7725cf8745cf8765cf9785df9795df97b5dfa7d5efa7f5efa815ffb835ffb8560fb8761fc8961fc8a62fc8c63fc8e64fc9065fd9266fd9467fd9668fd9869fd9a6afd9b6bfe9d6cfe9f6dfea16efea36ffea571fea772fea973feaa74feac76feae77feb078feb27afeb47bfeb67cfeb77efeb97ffebb81febd82febf84fec185fec287fec488fec68afec88cfeca8dfecc8ffecd90fecf92fed194fed395fed597fed799fed89afdda9cfddc9efddea0fde0a1fde2a3fde3a5fde5a7fde7a9fde9aafdebacfcecaefceeb0fcf0b2fcf2b4fcf4b6fcf6b8fcf7b9fcf9bbfcfbbdfcfdbf")),
    dA = ka(bt("00000401000501010601010802010a02020c02020e03021004031204031405041706041907051b08051d09061f0a07220b07240c08260d08290e092b10092d110a30120a32140b34150b37160b39180c3c190c3e1b0c411c0c431e0c451f0c48210c4a230c4c240c4f260c51280b53290b552b0b572d0b592f0a5b310a5c320a5e340a5f3609613809623909633b09643d09653e0966400a67420a68440a68450a69470b6a490b6a4a0c6b4c0c6b4d0d6c4f0d6c510e6c520e6d540f6d550f6d57106e59106e5a116e5c126e5d126e5f136e61136e62146e64156e65156e67166e69166e6a176e6c186e6d186e6f196e71196e721a6e741a6e751b6e771c6d781c6d7a1d6d7c1d6d7d1e6d7f1e6c801f6c82206c84206b85216b87216b88226a8a226a8c23698d23698f24699025689225689326679526679727669827669a28659b29649d29649f2a63a02a63a22b62a32c61a52c60a62d60a82e5fa92e5eab2f5ead305dae305cb0315bb1325ab3325ab43359b63458b73557b93556ba3655bc3754bd3853bf3952c03a51c13a50c33b4fc43c4ec63d4dc73e4cc83f4bca404acb4149cc4248ce4347cf4446d04545d24644d34743d44842d54a41d74b3fd84c3ed94d3dda4e3cdb503bdd513ade5238df5337e05536e15635e25734e35933e45a31e55c30e65d2fe75e2ee8602de9612bea632aeb6429eb6628ec6726ed6925ee6a24ef6c23ef6e21f06f20f1711ff1731df2741cf3761bf37819f47918f57b17f57d15f67e14f68013f78212f78410f8850ff8870ef8890cf98b0bf98c0af98e09fa9008fa9207fa9407fb9606fb9706fb9906fb9b06fb9d07fc9f07fca108fca309fca50afca60cfca80dfcaa0ffcac11fcae12fcb014fcb216fcb418fbb61afbb81dfbba1ffbbc21fbbe23fac026fac228fac42afac62df9c72ff9c932f9cb35f8cd37f8cf3af7d13df7d340f6d543f6d746f5d949f5db4cf4dd4ff4df53f4e156f3e35af3e55df2e661f2e865f2ea69f1ec6df1ed71f1ef75f1f179f2f27df2f482f3f586f3f68af4f88ef5f992f6fa96f8fb9af9fc9dfafda1fcffa4")),
    vA = ka(bt("0d088710078813078916078a19068c1b068d1d068e20068f2206902406912605912805922a05932c05942e05952f059631059733059735049837049938049a3a049a3c049b3e049c3f049c41049d43039e44039e46039f48039f4903a04b03a14c02a14e02a25002a25102a35302a35502a45601a45801a45901a55b01a55c01a65e01a66001a66100a76300a76400a76600a76700a86900a86a00a86c00a86e00a86f00a87100a87201a87401a87501a87701a87801a87a02a87b02a87d03a87e03a88004a88104a78305a78405a78606a68707a68808a68a09a58b0aa58d0ba58e0ca48f0da4910ea3920fa39410a29511a19613a19814a099159f9a169f9c179e9d189d9e199da01a9ca11b9ba21d9aa31e9aa51f99a62098a72197a82296aa2395ab2494ac2694ad2793ae2892b02991b12a90b22b8fb32c8eb42e8db52f8cb6308bb7318ab83289ba3388bb3488bc3587bd3786be3885bf3984c03a83c13b82c23c81c33d80c43e7fc5407ec6417dc7427cc8437bc9447aca457acb4679cc4778cc4977cd4a76ce4b75cf4c74d04d73d14e72d24f71d35171d45270d5536fd5546ed6556dd7566cd8576bd9586ada5a6ada5b69db5c68dc5d67dd5e66de5f65de6164df6263e06363e16462e26561e26660e3685fe4695ee56a5de56b5de66c5ce76e5be76f5ae87059e97158e97257ea7457eb7556eb7655ec7754ed7953ed7a52ee7b51ef7c51ef7e50f07f4ff0804ef1814df1834cf2844bf3854bf3874af48849f48948f58b47f58c46f68d45f68f44f79044f79143f79342f89441f89540f9973ff9983ef99a3efa9b3dfa9c3cfa9e3bfb9f3afba139fba238fca338fca537fca636fca835fca934fdab33fdac33fdae32fdaf31fdb130fdb22ffdb42ffdb52efeb72dfeb82cfeba2cfebb2bfebd2afebe2afec029fdc229fdc328fdc527fdc627fdc827fdca26fdcb26fccd25fcce25fcd025fcd225fbd324fbd524fbd724fad824fada24f9dc24f9dd25f8df25f8e125f7e225f7e425f6e626f6e826f5e926f5eb27f4ed27f3ee27f3f027f2f227f1f426f1f525f0f724f0f921"));

function as(e) {
    var t = 0,
        n = 1,
        r = !1;

    function a(i) {
        var o = (i - t) / (n - t);
        return e(r ? Math.max(0, Math.min(1, o)) : o)
    }
    return a.domain = function(i) {
        return arguments.length ? (t = +i[0], n = +i[1], a) : [t, n]
    }, a.clamp = function(i) {
        return arguments.length ? (r = !!i, a) : r
    }, a.interpolator = function(i) {
        return arguments.length ? (e = i, a) : e
    }, a.copy = function() {
        return as(e).domain([t, n]).clamp(r)
    }, hr(a)
}
var qo = Object.freeze(Object.defineProperty({
        __proto__: null,
        scaleBand: Lo,
        scalePoint: g9,
        scaleIdentity: Rf,
        scaleLinear: zo,
        scaleLog: Wf,
        scaleOrdinal: No,
        scaleImplicit: Ni,
        scalePow: Uo,
        scaleSqrt: N9,
        scaleQuantile: zf,
        scaleQuantize: Uf,
        scaleThreshold: Hf,
        scaleTime: tA,
        scaleUtc: nA,
        schemeCategory10: rA,
        schemeCategory20b: aA,
        schemeCategory20c: iA,
        schemeCategory20: oA,
        interpolateCubehelixDefault: uA,
        interpolateRainbow: fA,
        interpolateWarm: lA,
        interpolateCool: cA,
        interpolateViridis: sA,
        interpolateMagma: hA,
        interpolateInferno: dA,
        interpolatePlasma: vA,
        scaleSequential: as
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    gA = ["linear", "time", "log", "sqrt"];

function Vo(e) {
    var t = function(n) {
        return n && n[0].toUpperCase() + n.slice(1)
    };
    return "scale".concat(t(e))
}

function is(e) {
    return typeof e == "function" ? H(e.copy) && H(e.domain) && H(e.range) : typeof e == "string" ? vn(gA, e) : !1
}

function os(e, t) {
    if (e.scale) {
        if (e.scale.x || e.scale.y) return !!e.scale[t]
    } else return !1;
    return !0
}

function yA(e, t) {
    if (!!os(e, t)) {
        var n = e.scale[t] || e.scale;
        return typeof n == "string" ? n : ls(n)
    }
}

function mA(e, t) {
    var n;
    if (e.domain && e.domain[t] ? n = e.domain[t] : e.domain && Array.isArray(e.domain) && (n = e.domain), !!n) return sr(n) ? "time" : "linear"
}

function us(e, t) {
    if (!e.data) return "linear";
    var n = Sa(e[t]),
        r = e.data.map(function(a) {
            var i = ne(n(a)) ? n(a)[t] : n(a);
            return i !== void 0 ? i : a[t]
        });
    return sr(r) ? "time" : "linear"
}

function Fi(e) {
    return is(e) ? qo[Vo(e)]() : zo()
}

function ea(e, t) {
    var n = Wi(e, t);
    if (n) return typeof n == "string" ? Fi(n) : n;
    var r = mA(e, t) || us(e, t);
    return qo[Vo(r)]()
}

function Wi(e, t) {
    if (!!os(e, t)) {
        var n = e.scale[t] || e.scale;
        if (is(n)) return H(n) ? n : qo[Vo(n)]()
    }
}

function ta(e, t) {
    return yA(e, t) || us(e, t)
}

function ls(e) {
    if (typeof e == "string") return e;
    var t = [{
            name: "log",
            method: "base"
        }, {
            name: "ordinal",
            method: "unknown"
        }, {
            name: "pow-sqrt",
            method: "exponent"
        }, {
            name: "quantile",
            method: "quantiles"
        }, {
            name: "quantize-threshold",
            method: "invertExtent"
        }],
        n = t.filter(function(r) {
            return e[r.method] !== void 0
        })[0];
    return n ? n.name : void 0
}
var bA = "@@__IMMUTABLE_ITERABLE__@@",
    pA = "@@__IMMUTABLE_RECORD__@@",
    _A = "@@__IMMUTABLE_LIST__@@";

function dr(e) {
    return !!(e && e[bA])
}

function xA(e) {
    return !!(e && e[pA])
}

function wA(e) {
    return dr(e) || xA(e)
}

function AA(e) {
    return !!(e && e[_A])
}

function cs(e, t) {
    return dr(e) ? e.reduce(function(n, r, a) {
        return t && t[a] && (r = cs(r)), n[a] = r, n
    }, AA(e) ? [] : {}) : e
}

function zn(e) {
    return SA(e) || TA(e) || OA()
}

function OA() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function TA(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function SA(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function zi(e) {
    var t = {
        errorX: !0,
        errorY: !0
    };
    return wA(e) ? cs(e, t) : e
}

function EA(e) {
    return dr(e) ? e.size : e.length
}

function y0(e, t) {
    var n = ne(e.domain) ? e.domain[t] : e.domain,
        r = n || ea(e, t).domain(),
        a = e.samples || 1,
        i = Math.max.apply(Math, zn(r)),
        o = Math.min.apply(Math, zn(r)),
        u = (i - o) / a,
        l = i4(o, i, u);
    return c9(l) === i ? l : l.concat(i)
}

function fs(e, t) {
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "ascending";
    if (!t) return e;
    (t === "x" || t === "y") && (t = "_".concat(t));
    var r = n === "ascending" ? "asc" : "desc";
    return po(e, t, r)
}

function MA(e, t) {
    var n = 1 / Number.MAX_SAFE_INTEGER,
        r = {
            x: ta(t, "x"),
            y: ta(t, "y")
        };
    if (r.x !== "log" && r.y !== "log") return e;
    var a = function(o, u) {
            return r[u] === "log" ? o["_".concat(u)] !== 0 : !0
        },
        i = function(o) {
            var u = a(o, "x") ? o._x : n,
                l = a(o, "y") ? o._y : n,
                c = a(o, "y0") ? o._y0 : n;
            return S({}, o, {
                _x: u,
                _y: l,
                _y0: c
            })
        };
    return e.map(function(o) {
        return a(o, "x") && a(o, "y") && a(o, "y0") ? o : i(o)
    })
}

function CA(e) {
    return H(e) ? e : e == null ? function() {} : mo(e)
}

function $A(e, t) {
    var n = !!e.eventKey,
        r = CA(e.eventKey);
    return t.map(function(a, i) {
        if (a.eventKey !== void 0) return a;
        if (n) {
            var o = r(a, i);
            return o !== void 0 ? S({
                eventKey: o
            }, a) : a
        } else return a
    })
}

function oi(e, t) {
    var n = ss(e, t),
        r = hs(e, t),
        a = kA(e, t),
        i = Qt(zn(n).concat(zn(r), zn(a)));
    return i.length === 0 ? null : i.reduce(function(o, u, l) {
        return o[u] = l + 1, o
    }, {})
}

function m0(e, t, n) {
    var r = Array.isArray(e) || dr(e);
    if (!r || EA(e) < 1) return [];
    var a = ["x", "y", "y0"];
    n = Array.isArray(n) ? n : a;
    var i = function(d) {
            return Sa(t[d] !== void 0 ? t[d] : d)
        },
        o = n.reduce(function(d, y) {
            return d[y] = i(y), d
        }, {}),
        u = u9(n, a) && t.x === "_x" && t.y === "_y" && t.y0 === "_y0",
        l;
    u === !1 && (l = {
        x: n.indexOf("x") !== -1 ? oi(t, "x") : void 0,
        y: n.indexOf("y") !== -1 ? oi(t, "y") : void 0,
        y0: n.indexOf("y0") !== -1 ? oi(t, "y") : void 0
    });
    var c = u ? e : e.reduce(function(d, y, v) {
            y = zi(y);
            var b = {
                    x: v,
                    y
                },
                g = n.reduce(function(m, _) {
                    var w = o[_](y),
                        O = w !== void 0 ? w : b[_];
                    return O !== void 0 && (typeof O == "string" && l[_] ? (m["".concat(_, "Name")] = O, m["_".concat(_)] = l[_][O]) : m["_".concat(_)] = O), m
                }, {}),
                p = S({}, g, y);
            return re(p) || d.push(p), d
        }, []),
        f = fs(c, t.sortKey, t.sortOrder),
        h = MA(f, t);
    return $A(t, h)
}

function PA(e) {
    var t = y0(e, "x"),
        n = y0(e, "y"),
        r = t.map(function(a, i) {
            return {
                x: a,
                y: n[i]
            }
        });
    return r
}

function Yo(e, t) {
    return e.categories && !Array.isArray(e.categories) ? e.categories[t] : e.categories
}

function nt(e) {
    return e.data ? m0(e.data, e) : m0(PA(e), e)
}

function ss(e, t) {
    var n = e.tickValues,
        r = e.tickFormat,
        a;
    return !n || !Array.isArray(n) && !n[t] ? a = r && Array.isArray(r) ? r : [] : a = n[t] || n, a.filter(function(i) {
        return typeof i == "string"
    })
}

function hs(e, t) {
    if (!e.categories) return [];
    var n = Yo(e, t),
        r = n && n.filter(function(a) {
            return typeof a == "string"
        });
    return r ? nf(r) : []
}

function kA(e, t) {
    var n = Array.isArray(e.data) || dr(e.data);
    if (!n) return [];
    var r = e[t] === void 0 ? t : e[t],
        a = Sa(r),
        i = e.data.reduce(function(l, c) {
            return l.push(zi(c)), l
        }, []),
        o = fs(i, e.sortKey, e.sortOrder),
        u = o.reduce(function(l, c) {
            return c = zi(c), l.push(a(c)), l
        }, []).filter(function(l) {
            return typeof l == "string"
        });
    return u.reduce(function(l, c) {
        return c != null && l.indexOf(c) === -1 && l.push(c), l
    }, [])
}

function Ko(e) {
    var t = function(i) {
            return i && i.type ? i.type.role : ""
        },
        n = t(e);
    if (n === "portal") {
        var r = A.Children.toArray(e.props.children);
        n = r.length ? t(r[0]) : ""
    }
    var a = ["area", "bar", "boxplot", "candlestick", "errorbar", "group", "histogram", "line", "pie", "scatter", "stack", "voronoi"];
    return vn(a, n)
}

function IA() {
    return {
        onLoad: {
            duration: 2e3
        },
        onExit: {
            duration: 500
        },
        onEnter: {
            duration: 500
        }
    }
}

function DA() {
    return {
        onLoad: {
            duration: 2e3,
            before: function() {
                return {
                    _y: 0,
                    _y1: 0,
                    _y0: 0
                }
            },
            after: function(e) {
                return {
                    _y: e._y,
                    _y1: e._y1,
                    _y0: e._y0
                }
            }
        },
        onExit: {
            duration: 500,
            before: function(e, t, n) {
                var r = function(a) {
                    var i = t === 0 ? n[t + 1] : n[t - 1];
                    return i[a]
                };
                return {
                    _x: r("_x"),
                    _y: r("_y"),
                    _y0: r("_y0")
                }
            }
        },
        onEnter: {
            duration: 500,
            before: function(e, t, n) {
                var r = function(a) {
                    var i = t === 0 ? n[t + 1] : n[t - 1];
                    return i[a]
                };
                return {
                    _x: r("_x"),
                    _y: r("_y"),
                    _y0: r("_y0")
                }
            },
            after: function(e) {
                return {
                    _x: e._x,
                    _y: e._y,
                    _y1: e._y1,
                    _y0: e._y0
                }
            }
        }
    }
}
var NA = lt,
    LA = et,
    jA = "[object Date]";

function RA(e) {
    return LA(e) && NA(e) == jA
}
var FA = RA,
    WA = FA,
    zA = lr,
    b0 = Bn.exports,
    p0 = b0 && b0.isDate,
    UA = p0 ? zA(p0) : WA,
    ds = UA,
    HA = on;

function BA(e, t) {
    for (var n = -1, r = e.length, a = 0, i = []; ++n < r;) {
        var o = e[n],
            u = t ? t(o) : o;
        if (!n || !HA(u, l)) {
            var l = u;
            i[a++] = o === 0 ? 0 : o
        }
    }
    return i
}
var GA = BA,
    qA = GA;

function VA(e) {
    return e && e.length ? qA(e) : []
}
var YA = VA;

function _0(e) {
    return ZA(e) || XA(e) || KA()
}

function KA() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function XA(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function ZA(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function QA(e, t, n) {
    var r = ta(t, n);
    if (r !== "log") return e;
    var a = function(i) {
        var o = i[0] < 0 || i[1] < 0 ? -1 / Number.MAX_SAFE_INTEGER : 1 / Number.MAX_SAFE_INTEGER,
            u = i[0] === 0 ? o : i[0],
            l = i[1] === 0 ? o : i[1];
        return [u, l]
    };
    return a(e)
}

function JA(e, t) {
    var n = function(r) {
        return Array.isArray(r) ? {
            left: r[0],
            right: r[1]
        } : {
            left: r,
            right: r
        }
    };
    return ne(e.domainPadding) ? n(e.domainPadding[t]) : n(e.domainPadding)
}

function eO(e, t) {
    return Zt(e).map(function(n) {
        return n["_".concat(t)] && n["_".concat(t)][1] !== void 0 ? n["_".concat(t)][1] : n["_".concat(t)]
    })
}

function x0(e, t) {
    var n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "min",
        r = function(u) {
            return n === "max" ? Math.max.apply(Math, _0(u)) : Math.min.apply(Math, _0(u))
        },
        a = n === "max" ? -1 / 0 : 1 / 0,
        i = !1,
        o = Zt(e).reduce(function(u, l) {
            var c = l["_".concat(t, "0")] !== void 0 ? l["_".concat(t, "0")] : l["_".concat(t)],
                f = l["_".concat(t, "1")] !== void 0 ? l["_".concat(t, "1")] : l["_".concat(t)],
                h = r([c, f]);
            return i = i || c instanceof Date || f instanceof Date, r([u, h])
        }, a);
    return i ? new Date(o) : o
}

function tO(e, t, n) {
    if (!t.domainPadding) return e;
    var r = yn(t, n),
        a = gn(t, n),
        i = JA(t, n);
    if (!i.left && !i.right) return e;
    var o = ut(e),
        u = Rt(e),
        l = Hc(n, t.horizontal),
        c = Ze(t, l),
        f = Math.abs(c[0] - c[1]),
        h = Math.max(f - i.left - i.right, 1),
        d = Math.abs(u.valueOf() - o.valueOf()) / h * f,
        y = {
            left: d * i.left / f,
            right: d * i.right / f
        },
        v = {
            min: o.valueOf() - y.left,
            max: u.valueOf() + y.right
        },
        b = ne(t.singleQuadrantDomainPadding) ? t.singleQuadrantDomainPadding[n] : t.singleQuadrantDomainPadding,
        g = o >= 0 && v.min <= 0 || u <= 0 && v.max >= 0,
        p = function(T, x) {
            var M = x === "min" && o >= 0 && T <= 0 || x === "max" && u <= 0 && T >= 0;
            return M ? 0 : T
        };
    if (g && b !== !1) {
        var m = {
                left: Math.abs(u - o) * i.left / f,
                right: Math.abs(u - o) * i.right / f
            },
            _ = {
                min: p(o.valueOf() - m.left, "min"),
                max: p(u.valueOf() + m.right, "max")
            },
            w = {
                left: Math.abs(_.max - _.min) * i.left / f,
                right: Math.abs(_.max - _.min) * i.right / f
            };
        v = {
            min: p(o.valueOf() - w.left, "min"),
            max: p(u.valueOf() + w.right, "max")
        }
    }
    var O = {
        min: r !== void 0 ? r : v.min,
        max: a !== void 0 ? a : v.max
    };
    return o instanceof Date || u instanceof Date ? vt(new Date(O.min), new Date(O.max)) : vt(O.min, O.max)
}

function vs(e, t) {
    return e = H(e) ? e : Zo, t = H(t) ? t : Xo,
        function(n, r) {
            var a = Qo(n, r);
            if (a) return t(a, n, r);
            var i = Yo(n, r),
                o = i ? rO(n, r, i) : e(n, r);
            return o ? t(o, n, r) : void 0
        }
}

function Xo(e, t, n) {
    return QA(tO(e, t, n), t, n)
}

function nO(e, t) {
    return vs()(e, t)
}

function rO(e, t, n) {
    n = n || Yo(e, t);
    var r = e.polar,
        a = e.startAngle,
        i = a === void 0 ? 0 : a,
        o = e.endAngle,
        u = o === void 0 ? 360 : o;
    if (!!n) {
        var l = yn(e, t),
            c = gn(e, t),
            f = n8(n) ? hs(e, t) : [],
            h = f.length === 0 ? null : f.reduce(function(g, p, m) {
                return g[p] = m + 1, g
            }, {}),
            d = h ? n.map(function(g) {
                return h[g]
            }) : n,
            y = l !== void 0 ? l : ut(d),
            v = c !== void 0 ? c : Rt(d),
            b = vt(y, v);
        return r && t === "x" && Math.abs(i - u) === 360 ? gs(b, d) : b
    }
}

function Zo(e, t, n) {
    n = n || nt(e);
    var r = e.polar,
        a = e.startAngle,
        i = a === void 0 ? 0 : a,
        o = e.endAngle,
        u = o === void 0 ? 360 : o,
        l = yn(e, t),
        c = gn(e, t);
    if (n.length < 1) return l !== void 0 && c !== void 0 ? vt(l, c) : void 0;
    var f = l !== void 0 ? l : x0(n, t, "min"),
        h = c !== void 0 ? c : x0(n, t, "max"),
        d = vt(f, h);
    return r && t === "x" && Math.abs(i - u) === 360 ? gs(d, eO(n, t)) : d
}

function vt(e, t) {
    var n = function(r) {
        var a = r === 0 ? 2 * Math.pow(10, -10) : Math.pow(10, -10),
            i = 1,
            o = r instanceof Date ? new Date(+r - i) : +r - a,
            u = r instanceof Date ? new Date(+r + i) : +r + a;
        return r === 0 ? [0, u] : [o, u]
    };
    return +e == +t ? n(t) : [e, t]
}

function Qo(e, t) {
    var n = yn(e, t),
        r = gn(e, t);
    if (ne(e.domain) && e.domain[t]) return e.domain[t];
    if (Array.isArray(e.domain)) return e.domain;
    if (n !== void 0 && r !== void 0) return vt(n, r)
}

function Ui(e, t) {
    var n = Qo(e, t);
    if (n) return n;
    var r = nt(e),
        a = r.reduce(function(l, c) {
            return c._y0 < l ? c._y0 : l
        }, 1 / 0),
        i = function(l) {
            if (t === "x") return l;
            var c = a !== 1 / 0 ? a : 0,
                f = gn(e, t),
                h = yn(e, t),
                d = f !== void 0 ? f : Rt(l, c),
                y = h !== void 0 ? h : ut(l, c);
            return vt(y, d)
        },
        o = function() {
            return Zo(e, t, r)
        },
        u = function(l) {
            return Xo(i(l), e, t)
        };
    return vs(o, u)(e, t)
}

function gn(e, t) {
    return ne(e.maxDomain) && e.maxDomain[t] !== void 0 ? e.maxDomain[t] : typeof e.maxDomain == "number" || ds(e.maxDomain) ? e.maxDomain : void 0
}

function yn(e, t) {
    return ne(e.minDomain) && e.minDomain[t] !== void 0 ? e.minDomain[t] : typeof e.minDomain == "number" || ds(e.minDomain) ? e.minDomain : void 0
}

function gs(e, t) {
    var n = YA(t.sort(function(a, i) {
            return a - i
        })),
        r = n[1] - n[0];
    return [e[0], e[1] + r]
}

function ys(e) {
    var t = function(i) {
            return i && i.type ? i.type.role : ""
        },
        n = t(e);
    if (n === "portal") {
        var r = A.Children.toArray(e.props.children);
        n = r.length ? t(r[0]) : ""
    }
    var a = ["area", "axis", "bar", "boxplot", "candlestick", "errorbar", "group", "histogram", "line", "pie", "scatter", "stack", "voronoi"];
    return vn(a, n)
}

function w0(e, t, n) {
    var r = t.a,
        a = t.d,
        i = t.e,
        o = t.f;
    return n === "y" ? a * e + o : r * e + i
}

function aO(e) {
    return e.getScreenCTM().inverse()
}

function ms(e) {
    if (!(e.nativeEvent && e.nativeEvent.identifier !== void 0)) {
        var t = function(n) {
            return n.nodeName === "svg" ? n : n.parentNode ? t(n.parentNode) : n
        };
        return t(e.target)
    }
}

function iO(e, t) {
    if (e.nativeEvent && e.nativeEvent.identifier !== void 0) return {
        x: e.nativeEvent.locationX,
        y: e.nativeEvent.locationY
    };
    e = e.changedTouches && e.changedTouches.length ? e.changedTouches[0] : e, t = t || ms(e);
    var n = aO(t);
    return {
        x: w0(e.clientX, n, "x"),
        y: w0(e.clientY, n, "y")
    }
}
var oO = mt,
    uO = _f;

function lO(e, t) {
    return e && e.length ? uO(e, oO(t)) : []
}
var cO = lO;

function fO(e, t, n, r) {
    for (var a = -1, i = e == null ? 0 : e.length; ++a < i;) {
        var o = e[a];
        t(r, o, n(o), e)
    }
    return r
}
var sO = fO,
    hO = bo;

function dO(e, t, n, r) {
    return hO(e, function(a, i, o) {
        t(r, a, n(a), o)
    }), r
}
var vO = dO,
    gO = sO,
    yO = vO,
    mO = mt,
    bO = _e;

function pO(e, t) {
    return function(n, r) {
        var a = bO(n) ? gO : yO,
            i = t ? t() : {};
        return a(n, e, mO(r), i)
    }
}
var _O = pO,
    xO = To,
    wO = _O,
    AO = Object.prototype,
    OO = AO.hasOwnProperty,
    TO = wO(function(e, t, n) {
        OO.call(e, n) ? e[n].push(t) : xO(e, n, [t])
    }),
    SO = TO;

function EO(e, t) {
    t = t || Re;
    var n = function(r) {
        return r.reduce(function(a, i) {
            return i.type && i.type.role === "axis" && t(i) ? a.concat(i) : i.props && i.props.children ? a.concat(n(A.Children.toArray(i.props.children))) : a
        }, [])
    };
    return n(e)
}

function MO(e, t) {
    var n = function(r) {
        var a = r.type.getAxis(r.props);
        return a === t
    };
    return EO(e, n)[0]
}

function je(e) {
    return PO(e) || $O(e) || CO()
}

function CO() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function $O(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function PO(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function kO(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            IO(e, a, n[a])
        })
    }
    return e
}

function IO(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function DO(e) {
    var t = e.children,
        n = e.props,
        r = e.childComponents,
        a = e.parentProps,
        i = t.some(function(f) {
            return f.type && f.type.role === "histogram"
        }),
        o = i && t.length && t.every(function(f) {
            return f.type && f.type.role === "histogram"
        });
    if (!o) return a;
    var u = n.bins || r[0].props.bins;
    if (!Array.isArray(u)) {
        var l = t.reduce(function(f, h) {
                var d = Sa(h.props.x || "x");
                return f.concat(h.props.data.map(function(y) {
                    return {
                        x: d(y)
                    }
                }))
            }, []),
            c = t[0].type.getFormattedData;
        u = c({
            data: l,
            bins: u
        }).reduce(function(f, h, d) {
            var y = h.x0,
                v = h.x1;
            return d === 0 ? f.concat([y, v]) : f.concat(v)
        }, [])
    }
    return kO({}, a, {
        bins: u
    })
}

function NO(e, t) {
    var n = e.polar,
        r = e.startAngle,
        a = e.endAngle,
        i = e.categories,
        o = e.minDomain,
        u = e.maxDomain,
        l = {
            polar: n,
            startAngle: r,
            endAngle: a,
            categories: i,
            minDomain: o,
            maxDomain: u
        },
        c = 0,
        f = t ? t.slice(0) : A.Children.toArray(e.children);
    l = DO({
        children: f,
        props: e,
        childComponents: t,
        parentProps: l
    });
    var h = function(g, p, m) {
            var _ = S({}, g.props, l),
                w;
            if (Ko(g)) g.type && H(g.type.getData) ? (g = m ? A.cloneElement(g, m.props) : g, w = g.type.getData(_)) : w = nt(_);
            else return null;
            return c += 1, w.map(function(O, T) {
                return S({
                    _stack: c,
                    _group: T
                }, O)
            })
        },
        d = f.filter(function(g) {
            return g.type && g.type.role === "stack"
        }).length,
        y = function(g, p) {
            return g.concat(cO(p, "_group"))
        },
        v = jt(f, h, e, [], y),
        b = d ? "_group" : "_stack";
    return pf(SO(v, b))
}

function bs(e, t, n) {
    var r = e.datasets,
        a = e.horizontal,
        i = a ? Ze(e, "y") : Ze(e, "x"),
        o = Math.abs(i[1] - i[0]);
    n = n !== void 0 ? n : Array.isArray(r[0]) && r[0].length || 1, t = t || r.length;
    var u = t * n,
        l = .5;
    return Math.round(l * o / u)
}

function LO(e, t, n) {
    if (!(e.polar || t !== "x")) {
        var r = n.filter(function(d) {
            return d.type && d.type.role && d.type.role === "group"
        });
        if (!(r.length < 1)) {
            var a = r[0].props,
                i = a.offset,
                o = a.children;
            if (!!i) {
                var u = Array.isArray(o) && o[0];
                if (!!u) {
                    var l = u.props.barWidth,
                        c = u.props.data && u.props.data.length || 1;
                    if (u && u.type.role === "stack") {
                        var f = u.props.children && u.props.children[0];
                        if (!f) return;
                        l = f.props.barWidth, c = u.props.children.length
                    }
                    var h = l || bs(e, o.length, c);
                    return {
                        x: h * o.length / 2 + (i - h * ((o.length - 1) / 2))
                    }
                }
            }
        }
    }
}

function jO(e, t, n) {
    var r = n ? n.slice(0) : A.Children.toArray(e.children),
        a = e.data ? nt(e) : void 0,
        i = e.polar,
        o = e.startAngle,
        u = e.endAngle,
        l = e.categories,
        c = e.minDomain,
        f = e.maxDomain,
        h = e.horizontal,
        d = {
            horizontal: h,
            polar: i,
            startAngle: o,
            endAngle: u,
            minDomain: c,
            maxDomain: f,
            categories: l
        },
        y = a ? S(d, {
            data: a
        }) : d,
        v = function(m) {
            var _ = S({}, m.props, y);
            return ys(m) ? m.type && H(m.type.getDomain) ? m.props && m.type.getDomain(_, t) : nO(_, t) : null
        },
        b = jt(r, v, e),
        g = b.length === 0 ? 0 : ut(b),
        p = b.length === 0 ? 1 : Rt(b);
    return [g, p]
}

function A0(e, t, n) {
    n = n || A.Children.toArray(e.children);
    var r = Qo(e, t),
        a = LO(e, t, n),
        i;
    if (r) i = r;
    else {
        var o = yn(e, t),
            u = gn(e, t),
            l = (e.data || e.y) && nt(e),
            c = l ? Zo(e, t, l) : [],
            f = jO(e, t, n),
            h = o || ut(je(c).concat(je(f))),
            d = u || Rt(je(c).concat(je(f)));
        i = vt(h, d)
    }
    return Xo(i, S({
        domainPadding: a
    }, e), t)
}

function O0(e, t, n) {
    if (e.data) return ea(e, t);
    var r = n ? n.slice(0) : A.Children.toArray(e.children),
        a = function(o) {
            var u = S({}, o.props, {
                horizontal: e.horizontal
            });
            return ta(u, t)
        },
        i = Qt(jt(r, a, e));
    return i.length > 1 ? Fi("linear") : Fi(i[0])
}

function RO(e) {
    var t = ["groupComponent", "containerComponent", "labelComponent"],
        n = ko(e, t),
        r = e.events;
    return Array.isArray(n) && (r = Array.isArray(e.events) ? n.concat.apply(n, je(e.events)) : n), r || []
}

function FO(e, t, n) {
    var r = e.style,
        a = e.colorScale,
        i = e.color;
    if (r && r.data && r.data.fill) return r.data.fill;
    if (a = t.props && t.props.colorScale ? t.props.colorScale : a, i = t.props && t.props.color ? t.props.color : i, !(!a && !i)) {
        var o = Array.isArray(a) ? a : m_(a);
        return i || o[n % o.length]
    }
}

function WO(e, t, n) {
    var r = e && e[n] && e[n].style ? e[n].style : {};
    return zc(t, r)
}

function zO(e, t, n) {
    var r = n.style,
        a = n.role,
        i = e.props.style || {};
    if (Array.isArray(i)) return i;
    var o = e.type && e.type.role,
        u = o === "stack" ? void 0 : FO(n, e, t),
        l = o === "line" ? {
            fill: "none",
            stroke: u
        } : {
            fill: u
        },
        c = a === "stack" ? {} : {
            width: bs(n)
        },
        f = L({}, i.data, S({}, c, r.data, l)),
        h = L({}, i.labels, r.labels);
    return {
        parent: r.parent,
        data: f,
        labels: h
    }
}

function UO(e, t) {
    var n = function(r) {
        var a = r.props || {};
        if (!ys(r) || !a.categories) return null;
        var i = a.categories && !Array.isArray(a.categories) ? a.categories[t] : a.props.categories,
            o = i && i.filter(function(u) {
                return typeof u == "string"
            });
        return o ? nf(o) : []
    };
    return jt(e.slice(0), n)
}

function HO(e) {
    var t = function(a) {
            var i = a.props || {},
                o;
            if (Ko(a)) a.type && H(a.type.getData) ? o = a.type.getData(i) : o = nt(i);
            else return null;
            return o.map(function(u) {
                return {
                    x: u.xName,
                    y: u.yName
                }
            })
        },
        n = {
            x: [],
            y: []
        },
        r = function(a, i) {
            var o = Array.isArray(i) ? i.map(function(l) {
                    return l.x
                }).filter(Boolean) : i.x,
                u = Array.isArray(i) ? i.map(function(l) {
                    return l.y
                }).filter(Boolean) : i.y;
            return {
                x: o !== void 0 ? a.x.concat(o) : a.x,
                y: u !== void 0 ? a.y.concat(u) : a.y
            }
        };
    return jt(e.slice(0), t, {}, n, r)
}

function T0(e, t, n) {
    var r = ne(e.categories) ? e.categories[t] : e.categories,
        a = MO(n, t),
        i = a ? ss(a.props, t) : [],
        o = r || UO(n, t);
    return Qt(Zt(je(o).concat(je(i))))
}

function BO(e, t) {
    t = t || A.Children.toArray(e.children);
    var n = T0(e, "x", t),
        r = T0(e, "y", t),
        a = HO(t);
    return {
        x: Qt(Zt(je(n).concat(je(a.x)))),
        y: Qt(Zt(je(r).concat(je(a.y))))
    }
}

function GO(e, t, n) {
    var r = e.categories && !Array.isArray(e.categories) ? e.categories.x : e.categories,
        a = e.categories && !Array.isArray(e.categories) ? e.categories.y : e.categories,
        i = !r || !a,
        o = i ? n || BO(e, t) : {},
        u = r || o.x,
        l = a || o.y;
    return {
        x: u.length > 0 ? u : void 0,
        y: l.length > 0 ? l : void 0
    }
}
var qO = function(e) {
        var t = A.useRef();
        return A.useEffect(function() {
            t.current = e
        }), t.current || {}
    },
    VO = bo;

function YO(e, t) {
    var n;
    return VO(e, function(r, a, i) {
        return n = t(r, a, i), !n
    }), !!n
}
var KO = YO,
    XO = Y0,
    ZO = mt,
    QO = KO,
    JO = _e,
    eT = Oa;

function tT(e, t, n) {
    var r = JO(e) ? XO : QO;
    return n && eT(e, t, n) && (t = void 0), r(e, ZO(t))
}
var S0 = tT;

function nT(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            rT(e, a, n[a])
        })
    }
    return e
}

function rT(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function aT(e, t) {
    return uT(e) || oT(e, t) || iT()
}

function iT() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function oT(e, t) {
    var n = [],
        r = !0,
        a = !1,
        i = void 0;
    try {
        for (var o = e[Symbol.iterator](), u; !(r = (u = o.next()).done) && (n.push(u.value), !(t && n.length === t)); r = !0);
    } catch (l) {
        a = !0, i = l
    } finally {
        try {
            !r && o.return != null && o.return()
        } finally {
            if (a) throw i
        }
    }
    return n
}

function uT(e) {
    if (Array.isArray(e)) return e
}
var lT = {
        nodesShouldLoad: !1,
        nodesDoneLoad: !1,
        animating: !0
    },
    cT = function() {
        var e = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : lT,
            t = A.useState(e),
            n = aT(t, 2),
            r = n[0],
            a = n[1],
            i = A.useCallback(function(c) {
                a(function(f) {
                    return nT({}, f, c)
                })
            }, [a]),
            o = A.useCallback(function(c, f, h) {
                if (!c.animate) return f.props.animate;
                var d = function() {
                        var p = r && r.childrenTransitions;
                        return p = Rl(p) ? p[h] : p, L({
                            childrenTransitions: p
                        }, r)
                    },
                    y = c.animate && c.animate.getTransitions,
                    v = d(),
                    b = c.animate && c.animate.parentState || v;
                if (!y) {
                    var g = of (c, v, function(p) {
                        return i(p)
                    });
                    y = function(p) {
                        return g(p, h)
                    }
                }
                return L({
                    getTransitions: y,
                    parentState: b
                }, c.animate, f.props.animate)
            }, [r, i]),
            u = A.useCallback(function(c, f) {
                if (!!c.animate)
                    if (c.animate.parentState) {
                        var h = c.animate.parentState.nodesWillExit,
                            d = h ? c : null,
                            y = L({
                                oldProps: d,
                                nextProps: f
                            }, c.animate.parentState);
                        i(y)
                    } else {
                        var v = A.Children.toArray(c.children),
                            b = A.Children.toArray(f.children),
                            g = function(x) {
                                var M = function(C) {
                                    return C.type && C.type.continuous
                                };
                                return Array.isArray(x) ? S0(x, M) : M(x)
                            },
                            p = !c.polar && S0(v, function(x) {
                                return g(x) || x.props.children && g(x.props.children)
                            }),
                            m = af(v, b),
                            _ = m.nodesWillExit,
                            w = m.nodesWillEnter,
                            O = m.childrenTransitions,
                            T = m.nodesShouldEnter;
                        i({
                            nodesWillExit: _,
                            nodesWillEnter: w,
                            nodesShouldEnter: T,
                            childrenTransitions: Rl(O) ? O[0] : O,
                            oldProps: _ ? c : null,
                            nextProps: f,
                            continuous: p
                        })
                    }
            }, [i]),
            l = A.useCallback(function(c) {
                return r && r.nodesWillExit && r.oldProps || c
            }, [r]);
        return {
            state: r,
            setState: i,
            getAnimationProps: o,
            setAnimationState: u,
            getProps: l
        }
    },
    Hi = Math.PI,
    Bi = 2 * Hi,
    Tt = 1e-6,
    fT = Bi - Tt;

function Gi() {
    this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = ""
}

function mn() {
    return new Gi
}
Gi.prototype = mn.prototype = {
    constructor: Gi,
    moveTo: function(e, t) {
        this._ += "M" + (this._x0 = this._x1 = +e) + "," + (this._y0 = this._y1 = +t)
    },
    closePath: function() {
        this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z")
    },
    lineTo: function(e, t) {
        this._ += "L" + (this._x1 = +e) + "," + (this._y1 = +t)
    },
    quadraticCurveTo: function(e, t, n, r) {
        this._ += "Q" + +e + "," + +t + "," + (this._x1 = +n) + "," + (this._y1 = +r)
    },
    bezierCurveTo: function(e, t, n, r, a, i) {
        this._ += "C" + +e + "," + +t + "," + +n + "," + +r + "," + (this._x1 = +a) + "," + (this._y1 = +i)
    },
    arcTo: function(e, t, n, r, a) {
        e = +e, t = +t, n = +n, r = +r, a = +a;
        var i = this._x1,
            o = this._y1,
            u = n - e,
            l = r - t,
            c = i - e,
            f = o - t,
            h = c * c + f * f;
        if (a < 0) throw new Error("negative radius: " + a);
        if (this._x1 === null) this._ += "M" + (this._x1 = e) + "," + (this._y1 = t);
        else if (h > Tt)
            if (!(Math.abs(f * u - l * c) > Tt) || !a) this._ += "L" + (this._x1 = e) + "," + (this._y1 = t);
            else {
                var d = n - i,
                    y = r - o,
                    v = u * u + l * l,
                    b = d * d + y * y,
                    g = Math.sqrt(v),
                    p = Math.sqrt(h),
                    m = a * Math.tan((Hi - Math.acos((v + h - b) / (2 * g * p))) / 2),
                    _ = m / p,
                    w = m / g;
                Math.abs(_ - 1) > Tt && (this._ += "L" + (e + _ * c) + "," + (t + _ * f)), this._ += "A" + a + "," + a + ",0,0," + +(f * d > c * y) + "," + (this._x1 = e + w * u) + "," + (this._y1 = t + w * l)
            }
    },
    arc: function(e, t, n, r, a, i) {
        e = +e, t = +t, n = +n, i = !!i;
        var o = n * Math.cos(r),
            u = n * Math.sin(r),
            l = e + o,
            c = t + u,
            f = 1 ^ i,
            h = i ? r - a : a - r;
        if (n < 0) throw new Error("negative radius: " + n);
        this._x1 === null ? this._ += "M" + l + "," + c : (Math.abs(this._x1 - l) > Tt || Math.abs(this._y1 - c) > Tt) && (this._ += "L" + l + "," + c), n && (h < 0 && (h = h % Bi + Bi), h > fT ? this._ += "A" + n + "," + n + ",0,1," + f + "," + (e - o) + "," + (t - u) + "A" + n + "," + n + ",0,1," + f + "," + (this._x1 = l) + "," + (this._y1 = c) : h > Tt && (this._ += "A" + n + "," + n + ",0," + +(h >= Hi) + "," + f + "," + (this._x1 = e + n * Math.cos(a)) + "," + (this._y1 = t + n * Math.sin(a))))
    },
    rect: function(e, t, n, r) {
        this._ += "M" + (this._x0 = this._x1 = +e) + "," + (this._y0 = this._y1 = +t) + "h" + +n + "v" + +r + "h" + -n + "Z"
    },
    toString: function() {
        return this._
    }
};

function W(e) {
    return function() {
        return e
    }
}
var E0 = Math.abs,
    ve = Math.atan2,
    At = Math.cos,
    sT = Math.max,
    ui = Math.min,
    ze = Math.sin,
    Ht = Math.sqrt,
    ge = 1e-12,
    gt = Math.PI,
    na = gt / 2,
    st = 2 * gt;

function hT(e) {
    return e > 1 ? 0 : e < -1 ? gt : Math.acos(e)
}

function M0(e) {
    return e >= 1 ? na : e <= -1 ? -na : Math.asin(e)
}

function dT(e) {
    return e.innerRadius
}

function vT(e) {
    return e.outerRadius
}

function gT(e) {
    return e.startAngle
}

function yT(e) {
    return e.endAngle
}

function mT(e) {
    return e && e.padAngle
}

function bT(e, t, n, r, a, i, o, u) {
    var l = n - e,
        c = r - t,
        f = o - a,
        h = u - i,
        d = h * l - f * c;
    if (!(d * d < ge)) return d = (f * (t - i) - h * (e - a)) / d, [e + d * l, t + d * c]
}

function Er(e, t, n, r, a, i, o) {
    var u = e - n,
        l = t - r,
        c = (o ? i : -i) / Ht(u * u + l * l),
        f = c * l,
        h = -c * u,
        d = e + f,
        y = t + h,
        v = n + f,
        b = r + h,
        g = (d + v) / 2,
        p = (y + b) / 2,
        m = v - d,
        _ = b - y,
        w = m * m + _ * _,
        O = a - i,
        T = d * b - v * y,
        x = (_ < 0 ? -1 : 1) * Ht(sT(0, O * O * w - T * T)),
        M = (T * _ - m * x) / w,
        C = (-T * m - _ * x) / w,
        I = (T * _ + m * x) / w,
        $ = (-T * m + _ * x) / w,
        E = M - g,
        k = C - p,
        F = I - g,
        Z = $ - p;
    return E * E + k * k > F * F + Z * Z && (M = I, C = $), {
        cx: M,
        cy: C,
        x01: -f,
        y01: -h,
        x11: M * (a / O - 1),
        y11: C * (a / O - 1)
    }
}

function pT() {
    var e = dT,
        t = vT,
        n = W(0),
        r = null,
        a = gT,
        i = yT,
        o = mT,
        u = null;

    function l() {
        var c, f, h = +e.apply(this, arguments),
            d = +t.apply(this, arguments),
            y = a.apply(this, arguments) - na,
            v = i.apply(this, arguments) - na,
            b = E0(v - y),
            g = v > y;
        if (u || (u = c = mn()), d < h && (f = d, d = h, h = f), !(d > ge)) u.moveTo(0, 0);
        else if (b > st - ge) u.moveTo(d * At(y), d * ze(y)), u.arc(0, 0, d, y, v, !g), h > ge && (u.moveTo(h * At(v), h * ze(v)), u.arc(0, 0, h, v, y, g));
        else {
            var p = y,
                m = v,
                _ = y,
                w = v,
                O = b,
                T = b,
                x = o.apply(this, arguments) / 2,
                M = x > ge && (r ? +r.apply(this, arguments) : Ht(h * h + d * d)),
                C = ui(E0(d - h) / 2, +n.apply(this, arguments)),
                I = C,
                $ = C,
                E, k;
            if (M > ge) {
                var F = M0(M / h * ze(x)),
                    Z = M0(M / d * ze(x));
                (O -= F * 2) > ge ? (F *= g ? 1 : -1, _ += F, w -= F) : (O = 0, _ = w = (y + v) / 2), (T -= Z * 2) > ge ? (Z *= g ? 1 : -1, p += Z, m -= Z) : (T = 0, p = m = (y + v) / 2)
            }
            var Y = d * At(p),
                X = d * ze(p),
                K = h * At(w),
                z = h * ze(w);
            if (C > ge) {
                var te = d * At(m),
                    Ee = d * ze(m),
                    ft = h * At(_),
                    De = h * ze(_),
                    ce;
                if (b < gt && (ce = bT(Y, X, ft, De, te, Ee, K, z))) {
                    var Me = Y - ce[0],
                        rt = X - ce[1],
                        Ce = te - ce[0],
                        $e = Ee - ce[1],
                        N = 1 / ze(hT((Me * Ce + rt * $e) / (Ht(Me * Me + rt * rt) * Ht(Ce * Ce + $e * $e))) / 2),
                        j = Ht(ce[0] * ce[0] + ce[1] * ce[1]);
                    I = ui(C, (h - j) / (N - 1)), $ = ui(C, (d - j) / (N + 1))
                }
            }
            T > ge ? $ > ge ? (E = Er(ft, De, Y, X, d, $, g), k = Er(te, Ee, K, z, d, $, g), u.moveTo(E.cx + E.x01, E.cy + E.y01), $ < C ? u.arc(E.cx, E.cy, $, ve(E.y01, E.x01), ve(k.y01, k.x01), !g) : (u.arc(E.cx, E.cy, $, ve(E.y01, E.x01), ve(E.y11, E.x11), !g), u.arc(0, 0, d, ve(E.cy + E.y11, E.cx + E.x11), ve(k.cy + k.y11, k.cx + k.x11), !g), u.arc(k.cx, k.cy, $, ve(k.y11, k.x11), ve(k.y01, k.x01), !g))) : (u.moveTo(Y, X), u.arc(0, 0, d, p, m, !g)) : u.moveTo(Y, X), !(h > ge) || !(O > ge) ? u.lineTo(K, z) : I > ge ? (E = Er(K, z, te, Ee, h, -I, g), k = Er(Y, X, ft, De, h, -I, g), u.lineTo(E.cx + E.x01, E.cy + E.y01), I < C ? u.arc(E.cx, E.cy, I, ve(E.y01, E.x01), ve(k.y01, k.x01), !g) : (u.arc(E.cx, E.cy, I, ve(E.y01, E.x01), ve(E.y11, E.x11), !g), u.arc(0, 0, h, ve(E.cy + E.y11, E.cx + E.x11), ve(k.cy + k.y11, k.cx + k.x11), g), u.arc(k.cx, k.cy, I, ve(k.y11, k.x11), ve(k.y01, k.x01), !g))) : u.arc(0, 0, h, w, _, g)
        }
        if (u.closePath(), c) return u = null, c + "" || null
    }
    return l.centroid = function() {
        var c = (+e.apply(this, arguments) + +t.apply(this, arguments)) / 2,
            f = (+a.apply(this, arguments) + +i.apply(this, arguments)) / 2 - gt / 2;
        return [At(f) * c, ze(f) * c]
    }, l.innerRadius = function(c) {
        return arguments.length ? (e = typeof c == "function" ? c : W(+c), l) : e
    }, l.outerRadius = function(c) {
        return arguments.length ? (t = typeof c == "function" ? c : W(+c), l) : t
    }, l.cornerRadius = function(c) {
        return arguments.length ? (n = typeof c == "function" ? c : W(+c), l) : n
    }, l.padRadius = function(c) {
        return arguments.length ? (r = c == null ? null : typeof c == "function" ? c : W(+c), l) : r
    }, l.startAngle = function(c) {
        return arguments.length ? (a = typeof c == "function" ? c : W(+c), l) : a
    }, l.endAngle = function(c) {
        return arguments.length ? (i = typeof c == "function" ? c : W(+c), l) : i
    }, l.padAngle = function(c) {
        return arguments.length ? (o = typeof c == "function" ? c : W(+c), l) : o
    }, l.context = function(c) {
        return arguments.length ? (u = c == null ? null : c, l) : u
    }, l
}

function ps(e) {
    this._context = e
}
ps.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._point = 0
    },
    lineEnd: function() {
        (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
                break;
            case 1:
                this._point = 2;
            default:
                this._context.lineTo(e, t);
                break
        }
    }
};

function Ia(e) {
    return new ps(e)
}

function Jo(e) {
    return e[0]
}

function eu(e) {
    return e[1]
}

function Da() {
    var e = Jo,
        t = eu,
        n = W(!0),
        r = null,
        a = Ia,
        i = null;

    function o(u) {
        var l, c = u.length,
            f, h = !1,
            d;
        for (r == null && (i = a(d = mn())), l = 0; l <= c; ++l) !(l < c && n(f = u[l], l, u)) === h && ((h = !h) ? i.lineStart() : i.lineEnd()), h && i.point(+e(f, l, u), +t(f, l, u));
        if (d) return i = null, d + "" || null
    }
    return o.x = function(u) {
        return arguments.length ? (e = typeof u == "function" ? u : W(+u), o) : e
    }, o.y = function(u) {
        return arguments.length ? (t = typeof u == "function" ? u : W(+u), o) : t
    }, o.defined = function(u) {
        return arguments.length ? (n = typeof u == "function" ? u : W(!!u), o) : n
    }, o.curve = function(u) {
        return arguments.length ? (a = u, r != null && (i = a(r)), o) : a
    }, o.context = function(u) {
        return arguments.length ? (u == null ? r = i = null : i = a(r = u), o) : r
    }, o
}

function ra() {
    var e = Jo,
        t = null,
        n = W(0),
        r = eu,
        a = W(!0),
        i = null,
        o = Ia,
        u = null;

    function l(f) {
        var h, d, y, v = f.length,
            b, g = !1,
            p, m = new Array(v),
            _ = new Array(v);
        for (i == null && (u = o(p = mn())), h = 0; h <= v; ++h) {
            if (!(h < v && a(b = f[h], h, f)) === g)
                if (g = !g) d = h, u.areaStart(), u.lineStart();
                else {
                    for (u.lineEnd(), u.lineStart(), y = h - 1; y >= d; --y) u.point(m[y], _[y]);
                    u.lineEnd(), u.areaEnd()
                }
            g && (m[h] = +e(b, h, f), _[h] = +n(b, h, f), u.point(t ? +t(b, h, f) : m[h], r ? +r(b, h, f) : _[h]))
        }
        if (p) return u = null, p + "" || null
    }

    function c() {
        return Da().defined(a).curve(o).context(i)
    }
    return l.x = function(f) {
        return arguments.length ? (e = typeof f == "function" ? f : W(+f), t = null, l) : e
    }, l.x0 = function(f) {
        return arguments.length ? (e = typeof f == "function" ? f : W(+f), l) : e
    }, l.x1 = function(f) {
        return arguments.length ? (t = f == null ? null : typeof f == "function" ? f : W(+f), l) : t
    }, l.y = function(f) {
        return arguments.length ? (n = typeof f == "function" ? f : W(+f), r = null, l) : n
    }, l.y0 = function(f) {
        return arguments.length ? (n = typeof f == "function" ? f : W(+f), l) : n
    }, l.y1 = function(f) {
        return arguments.length ? (r = f == null ? null : typeof f == "function" ? f : W(+f), l) : r
    }, l.lineX0 = l.lineY0 = function() {
        return c().x(e).y(n)
    }, l.lineY1 = function() {
        return c().x(e).y(r)
    }, l.lineX1 = function() {
        return c().x(t).y(n)
    }, l.defined = function(f) {
        return arguments.length ? (a = typeof f == "function" ? f : W(!!f), l) : a
    }, l.curve = function(f) {
        return arguments.length ? (o = f, i != null && (u = o(i)), l) : o
    }, l.context = function(f) {
        return arguments.length ? (f == null ? i = u = null : u = o(i = f), l) : i
    }, l
}

function _T(e, t) {
    return t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN
}

function xT(e) {
    return e
}

function wT() {
    var e = xT,
        t = _T,
        n = null,
        r = W(0),
        a = W(st),
        i = W(0);

    function o(u) {
        var l, c = u.length,
            f, h, d = 0,
            y = new Array(c),
            v = new Array(c),
            b = +r.apply(this, arguments),
            g = Math.min(st, Math.max(-st, a.apply(this, arguments) - b)),
            p, m = Math.min(Math.abs(g) / c, i.apply(this, arguments)),
            _ = m * (g < 0 ? -1 : 1),
            w;
        for (l = 0; l < c; ++l)(w = v[y[l] = l] = +e(u[l], l, u)) > 0 && (d += w);
        for (t != null ? y.sort(function(O, T) {
                return t(v[O], v[T])
            }) : n != null && y.sort(function(O, T) {
                return n(u[O], u[T])
            }), l = 0, h = d ? (g - c * _) / d : 0; l < c; ++l, b = p) f = y[l], w = v[f], p = b + (w > 0 ? w * h : 0) + _, v[f] = {
            data: u[f],
            index: l,
            value: w,
            startAngle: b,
            endAngle: p,
            padAngle: m
        };
        return v
    }
    return o.value = function(u) {
        return arguments.length ? (e = typeof u == "function" ? u : W(+u), o) : e
    }, o.sortValues = function(u) {
        return arguments.length ? (t = u, n = null, o) : t
    }, o.sort = function(u) {
        return arguments.length ? (n = u, t = null, o) : n
    }, o.startAngle = function(u) {
        return arguments.length ? (r = typeof u == "function" ? u : W(+u), o) : r
    }, o.endAngle = function(u) {
        return arguments.length ? (a = typeof u == "function" ? u : W(+u), o) : a
    }, o.padAngle = function(u) {
        return arguments.length ? (i = typeof u == "function" ? u : W(+u), o) : i
    }, o
}
var _s = tu(Ia);

function xs(e) {
    this._curve = e
}
xs.prototype = {
    areaStart: function() {
        this._curve.areaStart()
    },
    areaEnd: function() {
        this._curve.areaEnd()
    },
    lineStart: function() {
        this._curve.lineStart()
    },
    lineEnd: function() {
        this._curve.lineEnd()
    },
    point: function(e, t) {
        this._curve.point(t * Math.sin(e), t * -Math.cos(e))
    }
};

function tu(e) {
    function t(n) {
        return new xs(e(n))
    }
    return t._curve = e, t
}

function jn(e) {
    var t = e.curve;
    return e.angle = e.x, delete e.x, e.radius = e.y, delete e.y, e.curve = function(n) {
        return arguments.length ? t(tu(n)) : t()._curve
    }, e
}

function qi() {
    return jn(Da().curve(_s))
}

function Vi() {
    var e = ra().curve(_s),
        t = e.curve,
        n = e.lineX0,
        r = e.lineX1,
        a = e.lineY0,
        i = e.lineY1;
    return e.angle = e.x, delete e.x, e.startAngle = e.x0, delete e.x0, e.endAngle = e.x1, delete e.x1, e.radius = e.y, delete e.y, e.innerRadius = e.y0, delete e.y0, e.outerRadius = e.y1, delete e.y1, e.lineStartAngle = function() {
        return jn(n())
    }, delete e.lineX0, e.lineEndAngle = function() {
        return jn(r())
    }, delete e.lineX1, e.lineInnerRadius = function() {
        return jn(a())
    }, delete e.lineY0, e.lineOuterRadius = function() {
        return jn(i())
    }, delete e.lineY1, e.curve = function(o) {
        return arguments.length ? t(tu(o)) : t()._curve
    }, e
}

function Rn(e, t) {
    return [(t = +t) * Math.cos(e -= Math.PI / 2), t * Math.sin(e)]
}
var Yi = Array.prototype.slice;

function AT(e) {
    return e.source
}

function OT(e) {
    return e.target
}

function nu(e) {
    var t = AT,
        n = OT,
        r = Jo,
        a = eu,
        i = null;

    function o() {
        var u, l = Yi.call(arguments),
            c = t.apply(this, l),
            f = n.apply(this, l);
        if (i || (i = u = mn()), e(i, +r.apply(this, (l[0] = c, l)), +a.apply(this, l), +r.apply(this, (l[0] = f, l)), +a.apply(this, l)), u) return i = null, u + "" || null
    }
    return o.source = function(u) {
        return arguments.length ? (t = u, o) : t
    }, o.target = function(u) {
        return arguments.length ? (n = u, o) : n
    }, o.x = function(u) {
        return arguments.length ? (r = typeof u == "function" ? u : W(+u), o) : r
    }, o.y = function(u) {
        return arguments.length ? (a = typeof u == "function" ? u : W(+u), o) : a
    }, o.context = function(u) {
        return arguments.length ? (i = u == null ? null : u, o) : i
    }, o
}

function TT(e, t, n, r, a) {
    e.moveTo(t, n), e.bezierCurveTo(t = (t + r) / 2, n, t, a, r, a)
}

function ST(e, t, n, r, a) {
    e.moveTo(t, n), e.bezierCurveTo(t, n = (n + a) / 2, r, n, r, a)
}

function ET(e, t, n, r, a) {
    var i = Rn(t, n),
        o = Rn(t, n = (n + a) / 2),
        u = Rn(r, n),
        l = Rn(r, a);
    e.moveTo(i[0], i[1]), e.bezierCurveTo(o[0], o[1], u[0], u[1], l[0], l[1])
}

function MT() {
    return nu(TT)
}

function CT() {
    return nu(ST)
}

function $T() {
    var e = nu(ET);
    return e.angle = e.x, delete e.x, e.radius = e.y, delete e.y, e
}
var ru = {
        draw: function(e, t) {
            var n = Math.sqrt(t / gt);
            e.moveTo(n, 0), e.arc(0, 0, n, 0, st)
        }
    },
    ws = {
        draw: function(e, t) {
            var n = Math.sqrt(t / 5) / 2;
            e.moveTo(-3 * n, -n), e.lineTo(-n, -n), e.lineTo(-n, -3 * n), e.lineTo(n, -3 * n), e.lineTo(n, -n), e.lineTo(3 * n, -n), e.lineTo(3 * n, n), e.lineTo(n, n), e.lineTo(n, 3 * n), e.lineTo(-n, 3 * n), e.lineTo(-n, n), e.lineTo(-3 * n, n), e.closePath()
        }
    },
    As = Math.sqrt(1 / 3),
    PT = As * 2,
    Os = {
        draw: function(e, t) {
            var n = Math.sqrt(t / PT),
                r = n * As;
            e.moveTo(0, -n), e.lineTo(r, 0), e.lineTo(0, n), e.lineTo(-r, 0), e.closePath()
        }
    },
    kT = .8908130915292852,
    Ts = Math.sin(gt / 10) / Math.sin(7 * gt / 10),
    IT = Math.sin(st / 10) * Ts,
    DT = -Math.cos(st / 10) * Ts,
    Ss = {
        draw: function(e, t) {
            var n = Math.sqrt(t * kT),
                r = IT * n,
                a = DT * n;
            e.moveTo(0, -n), e.lineTo(r, a);
            for (var i = 1; i < 5; ++i) {
                var o = st * i / 5,
                    u = Math.cos(o),
                    l = Math.sin(o);
                e.lineTo(l * n, -u * n), e.lineTo(u * r - l * a, l * r + u * a)
            }
            e.closePath()
        }
    },
    Es = {
        draw: function(e, t) {
            var n = Math.sqrt(t),
                r = -n / 2;
            e.rect(r, r, n, n)
        }
    },
    li = Math.sqrt(3),
    Ms = {
        draw: function(e, t) {
            var n = -Math.sqrt(t / (li * 3));
            e.moveTo(0, n * 2), e.lineTo(-li * n, -n), e.lineTo(li * n, -n), e.closePath()
        }
    },
    Pe = -.5,
    ke = Math.sqrt(3) / 2,
    Ki = 1 / Math.sqrt(12),
    NT = (Ki / 2 + 1) * 3,
    Cs = {
        draw: function(e, t) {
            var n = Math.sqrt(t / NT),
                r = n / 2,
                a = n * Ki,
                i = r,
                o = n * Ki + n,
                u = -i,
                l = o;
            e.moveTo(r, a), e.lineTo(i, o), e.lineTo(u, l), e.lineTo(Pe * r - ke * a, ke * r + Pe * a), e.lineTo(Pe * i - ke * o, ke * i + Pe * o), e.lineTo(Pe * u - ke * l, ke * u + Pe * l), e.lineTo(Pe * r + ke * a, Pe * a - ke * r), e.lineTo(Pe * i + ke * o, Pe * o - ke * i), e.lineTo(Pe * u + ke * l, Pe * l - ke * u), e.closePath()
        }
    },
    LT = [ru, ws, Os, Es, Ss, Ms, Cs];

function jT() {
    var e = W(ru),
        t = W(64),
        n = null;

    function r() {
        var a;
        if (n || (n = a = mn()), e.apply(this, arguments).draw(n, +t.apply(this, arguments)), a) return n = null, a + "" || null
    }
    return r.type = function(a) {
        return arguments.length ? (e = typeof a == "function" ? a : W(a), r) : e
    }, r.size = function(a) {
        return arguments.length ? (t = typeof a == "function" ? a : W(+a), r) : t
    }, r.context = function(a) {
        return arguments.length ? (n = a == null ? null : a, r) : n
    }, r
}

function yt() {}

function aa(e, t, n) {
    e._context.bezierCurveTo((2 * e._x0 + e._x1) / 3, (2 * e._y0 + e._y1) / 3, (e._x0 + 2 * e._x1) / 3, (e._y0 + 2 * e._y1) / 3, (e._x0 + 4 * e._x1 + t) / 6, (e._y0 + 4 * e._y1 + n) / 6)
}

function Na(e) {
    this._context = e
}
Na.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 3:
                aa(this, this._x1, this._y1);
            case 2:
                this._context.lineTo(this._x1, this._y1);
                break
        }(this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
            default:
                aa(this, e, t);
                break
        }
        this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t
    }
};

function RT(e) {
    return new Na(e)
}

function $s(e) {
    this._context = e
}
$s.prototype = {
    areaStart: yt,
    areaEnd: yt,
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 1:
                {
                    this._context.moveTo(this._x2, this._y2),
                    this._context.closePath();
                    break
                }
            case 2:
                {
                    this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3),
                    this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3),
                    this._context.closePath();
                    break
                }
            case 3:
                {
                    this.point(this._x2, this._y2),
                    this.point(this._x3, this._y3),
                    this.point(this._x4, this._y4);
                    break
                }
        }
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1, this._x2 = e, this._y2 = t;
                break;
            case 1:
                this._point = 2, this._x3 = e, this._y3 = t;
                break;
            case 2:
                this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
                break;
            default:
                aa(this, e, t);
                break
        }
        this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t
    }
};

function FT(e) {
    return new $s(e)
}

function Ps(e) {
    this._context = e
}
Ps.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
    },
    lineEnd: function() {
        (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1;
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3;
                var n = (this._x0 + 4 * this._x1 + e) / 6,
                    r = (this._y0 + 4 * this._y1 + t) / 6;
                this._line ? this._context.lineTo(n, r) : this._context.moveTo(n, r);
                break;
            case 3:
                this._point = 4;
            default:
                aa(this, e, t);
                break
        }
        this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t
    }
};

function WT(e) {
    return new Ps(e)
}

function ks(e, t) {
    this._basis = new Na(e), this._beta = t
}
ks.prototype = {
    lineStart: function() {
        this._x = [], this._y = [], this._basis.lineStart()
    },
    lineEnd: function() {
        var e = this._x,
            t = this._y,
            n = e.length - 1;
        if (n > 0)
            for (var r = e[0], a = t[0], i = e[n] - r, o = t[n] - a, u = -1, l; ++u <= n;) l = u / n, this._basis.point(this._beta * e[u] + (1 - this._beta) * (r + l * i), this._beta * t[u] + (1 - this._beta) * (a + l * o));
        this._x = this._y = null, this._basis.lineEnd()
    },
    point: function(e, t) {
        this._x.push(+e), this._y.push(+t)
    }
};
var zT = function e(t) {
    function n(r) {
        return t === 1 ? new Na(r) : new ks(r, t)
    }
    return n.beta = function(r) {
        return e(+r)
    }, n
}(.85);

function ia(e, t, n) {
    e._context.bezierCurveTo(e._x1 + e._k * (e._x2 - e._x0), e._y1 + e._k * (e._y2 - e._y0), e._x2 + e._k * (e._x1 - t), e._y2 + e._k * (e._y1 - n), e._x2, e._y2)
}

function au(e, t) {
    this._context = e, this._k = (1 - t) / 6
}
au.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 2:
                this._context.lineTo(this._x2, this._y2);
                break;
            case 3:
                ia(this, this._x1, this._y1);
                break
        }(this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
                break;
            case 1:
                this._point = 2, this._x1 = e, this._y1 = t;
                break;
            case 2:
                this._point = 3;
            default:
                ia(this, e, t);
                break
        }
        this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t
    }
};
var UT = function e(t) {
    function n(r) {
        return new au(r, t)
    }
    return n.tension = function(r) {
        return e(+r)
    }, n
}(0);

function iu(e, t) {
    this._context = e, this._k = (1 - t) / 6
}
iu.prototype = {
    areaStart: yt,
    areaEnd: yt,
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 1:
                {
                    this._context.moveTo(this._x3, this._y3),
                    this._context.closePath();
                    break
                }
            case 2:
                {
                    this._context.lineTo(this._x3, this._y3),
                    this._context.closePath();
                    break
                }
            case 3:
                {
                    this.point(this._x3, this._y3),
                    this.point(this._x4, this._y4),
                    this.point(this._x5, this._y5);
                    break
                }
        }
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1, this._x3 = e, this._y3 = t;
                break;
            case 1:
                this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
                break;
            case 2:
                this._point = 3, this._x5 = e, this._y5 = t;
                break;
            default:
                ia(this, e, t);
                break
        }
        this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t
    }
};
var HT = function e(t) {
    function n(r) {
        return new iu(r, t)
    }
    return n.tension = function(r) {
        return e(+r)
    }, n
}(0);

function ou(e, t) {
    this._context = e, this._k = (1 - t) / 6
}
ou.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0
    },
    lineEnd: function() {
        (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1;
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
                break;
            case 3:
                this._point = 4;
            default:
                ia(this, e, t);
                break
        }
        this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t
    }
};
var BT = function e(t) {
    function n(r) {
        return new ou(r, t)
    }
    return n.tension = function(r) {
        return e(+r)
    }, n
}(0);

function uu(e, t, n) {
    var r = e._x1,
        a = e._y1,
        i = e._x2,
        o = e._y2;
    if (e._l01_a > ge) {
        var u = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a,
            l = 3 * e._l01_a * (e._l01_a + e._l12_a);
        r = (r * u - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, a = (a * u - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l
    }
    if (e._l23_a > ge) {
        var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a,
            f = 3 * e._l23_a * (e._l23_a + e._l12_a);
        i = (i * c + e._x1 * e._l23_2a - t * e._l12_2a) / f, o = (o * c + e._y1 * e._l23_2a - n * e._l12_2a) / f
    }
    e._context.bezierCurveTo(r, a, i, o, e._x2, e._y2)
}

function Is(e, t) {
    this._context = e, this._alpha = t
}
Is.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 2:
                this._context.lineTo(this._x2, this._y2);
                break;
            case 3:
                this.point(this._x2, this._y2);
                break
        }(this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        if (e = +e, t = +t, this._point) {
            var n = this._x2 - e,
                r = this._y2 - t;
            this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha))
        }
        switch (this._point) {
            case 0:
                this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3;
            default:
                uu(this, e, t);
                break
        }
        this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t
    }
};
var GT = function e(t) {
    function n(r) {
        return t ? new Is(r, t) : new au(r, 0)
    }
    return n.alpha = function(r) {
        return e(+r)
    }, n
}(.5);

function Ds(e, t) {
    this._context = e, this._alpha = t
}
Ds.prototype = {
    areaStart: yt,
    areaEnd: yt,
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 1:
                {
                    this._context.moveTo(this._x3, this._y3),
                    this._context.closePath();
                    break
                }
            case 2:
                {
                    this._context.lineTo(this._x3, this._y3),
                    this._context.closePath();
                    break
                }
            case 3:
                {
                    this.point(this._x3, this._y3),
                    this.point(this._x4, this._y4),
                    this.point(this._x5, this._y5);
                    break
                }
        }
    },
    point: function(e, t) {
        if (e = +e, t = +t, this._point) {
            var n = this._x2 - e,
                r = this._y2 - t;
            this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha))
        }
        switch (this._point) {
            case 0:
                this._point = 1, this._x3 = e, this._y3 = t;
                break;
            case 1:
                this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
                break;
            case 2:
                this._point = 3, this._x5 = e, this._y5 = t;
                break;
            default:
                uu(this, e, t);
                break
        }
        this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t
    }
};
var qT = function e(t) {
    function n(r) {
        return t ? new Ds(r, t) : new iu(r, 0)
    }
    return n.alpha = function(r) {
        return e(+r)
    }, n
}(.5);

function Ns(e, t) {
    this._context = e, this._alpha = t
}
Ns.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
    },
    lineEnd: function() {
        (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        if (e = +e, t = +t, this._point) {
            var n = this._x2 - e,
                r = this._y2 - t;
            this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha))
        }
        switch (this._point) {
            case 0:
                this._point = 1;
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
                break;
            case 3:
                this._point = 4;
            default:
                uu(this, e, t);
                break
        }
        this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t
    }
};
var VT = function e(t) {
    function n(r) {
        return t ? new Ns(r, t) : new ou(r, 0)
    }
    return n.alpha = function(r) {
        return e(+r)
    }, n
}(.5);

function Ls(e) {
    this._context = e
}
Ls.prototype = {
    areaStart: yt,
    areaEnd: yt,
    lineStart: function() {
        this._point = 0
    },
    lineEnd: function() {
        this._point && this._context.closePath()
    },
    point: function(e, t) {
        e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t))
    }
};

function YT(e) {
    return new Ls(e)
}

function C0(e) {
    return e < 0 ? -1 : 1
}

function $0(e, t, n) {
    var r = e._x1 - e._x0,
        a = t - e._x1,
        i = (e._y1 - e._y0) / (r || a < 0 && -0),
        o = (n - e._y1) / (a || r < 0 && -0),
        u = (i * a + o * r) / (r + a);
    return (C0(i) + C0(o)) * Math.min(Math.abs(i), Math.abs(o), .5 * Math.abs(u)) || 0
}

function P0(e, t) {
    var n = e._x1 - e._x0;
    return n ? (3 * (e._y1 - e._y0) / n - t) / 2 : t
}

function ci(e, t, n) {
    var r = e._x0,
        a = e._y0,
        i = e._x1,
        o = e._y1,
        u = (i - r) / 3;
    e._context.bezierCurveTo(r + u, a + u * t, i - u, o - u * n, i, o)
}

function oa(e) {
    this._context = e
}
oa.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0
    },
    lineEnd: function() {
        switch (this._point) {
            case 2:
                this._context.lineTo(this._x1, this._y1);
                break;
            case 3:
                ci(this, this._t0, P0(this, this._t0));
                break
        }(this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line
    },
    point: function(e, t) {
        var n = NaN;
        if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
            switch (this._point) {
                case 0:
                    this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
                    break;
                case 1:
                    this._point = 2;
                    break;
                case 2:
                    this._point = 3, ci(this, P0(this, n = $0(this, e, t)), n);
                    break;
                default:
                    ci(this, this._t0, n = $0(this, e, t));
                    break
            }
            this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = n
        }
    }
};

function js(e) {
    this._context = new Rs(e)
}(js.prototype = Object.create(oa.prototype)).point = function(e, t) {
    oa.prototype.point.call(this, t, e)
};

function Rs(e) {
    this._context = e
}
Rs.prototype = {
    moveTo: function(e, t) {
        this._context.moveTo(t, e)
    },
    closePath: function() {
        this._context.closePath()
    },
    lineTo: function(e, t) {
        this._context.lineTo(t, e)
    },
    bezierCurveTo: function(e, t, n, r, a, i) {
        this._context.bezierCurveTo(t, e, r, n, i, a)
    }
};

function KT(e) {
    return new oa(e)
}

function XT(e) {
    return new js(e)
}

function Fs(e) {
    this._context = e
}
Fs.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x = [], this._y = []
    },
    lineEnd: function() {
        var e = this._x,
            t = this._y,
            n = e.length;
        if (n)
            if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), n === 2) this._context.lineTo(e[1], t[1]);
            else
                for (var r = k0(e), a = k0(t), i = 0, o = 1; o < n; ++i, ++o) this._context.bezierCurveTo(r[0][i], a[0][i], r[1][i], a[1][i], e[o], t[o]);
        (this._line || this._line !== 0 && n === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null
    },
    point: function(e, t) {
        this._x.push(+e), this._y.push(+t)
    }
};

function k0(e) {
    var t, n = e.length - 1,
        r, a = new Array(n),
        i = new Array(n),
        o = new Array(n);
    for (a[0] = 0, i[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < n - 1; ++t) a[t] = 1, i[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
    for (a[n - 1] = 2, i[n - 1] = 7, o[n - 1] = 8 * e[n - 1] + e[n], t = 1; t < n; ++t) r = a[t] / i[t - 1], i[t] -= r, o[t] -= r * o[t - 1];
    for (a[n - 1] = o[n - 1] / i[n - 1], t = n - 2; t >= 0; --t) a[t] = (o[t] - a[t + 1]) / i[t];
    for (i[n - 1] = (e[n] + a[n - 1]) / 2, t = 0; t < n - 1; ++t) i[t] = 2 * e[t + 1] - a[t + 1];
    return [a, i]
}

function ZT(e) {
    return new Fs(e)
}

function La(e, t) {
    this._context = e, this._t = t
}
La.prototype = {
    areaStart: function() {
        this._line = 0
    },
    areaEnd: function() {
        this._line = NaN
    },
    lineStart: function() {
        this._x = this._y = NaN, this._point = 0
    },
    lineEnd: function() {
        0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line)
    },
    point: function(e, t) {
        switch (e = +e, t = +t, this._point) {
            case 0:
                this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
                break;
            case 1:
                this._point = 2;
            default:
                {
                    if (this._t <= 0) this._context.lineTo(this._x, t),
                    this._context.lineTo(e, t);
                    else {
                        var n = this._x * (1 - this._t) + e * this._t;
                        this._context.lineTo(n, this._y), this._context.lineTo(n, t)
                    }
                    break
                }
        }
        this._x = e, this._y = t
    }
};

function QT(e) {
    return new La(e, .5)
}

function JT(e) {
    return new La(e, 0)
}

function eS(e) {
    return new La(e, 1)
}

function nn(e, t) {
    if ((o = e.length) > 1)
        for (var n = 1, r, a, i = e[t[0]], o, u = i.length; n < o; ++n)
            for (a = i, i = e[t[n]], r = 0; r < u; ++r) i[r][1] += i[r][0] = isNaN(a[r][1]) ? a[r][0] : a[r][1]
}

function rn(e) {
    for (var t = e.length, n = new Array(t); --t >= 0;) n[t] = t;
    return n
}

function tS(e, t) {
    return e[t]
}

function nS() {
    var e = W([]),
        t = rn,
        n = nn,
        r = tS;

    function a(i) {
        var o = e.apply(this, arguments),
            u, l = i.length,
            c = o.length,
            f = new Array(c),
            h;
        for (u = 0; u < c; ++u) {
            for (var d = o[u], y = f[u] = new Array(l), v = 0, b; v < l; ++v) y[v] = b = [0, +r(i[v], d, v, i)], b.data = i[v];
            y.key = d
        }
        for (u = 0, h = t(f); u < c; ++u) f[h[u]].index = u;
        return n(f, h), f
    }
    return a.keys = function(i) {
        return arguments.length ? (e = typeof i == "function" ? i : W(Yi.call(i)), a) : e
    }, a.value = function(i) {
        return arguments.length ? (r = typeof i == "function" ? i : W(+i), a) : r
    }, a.order = function(i) {
        return arguments.length ? (t = i == null ? rn : typeof i == "function" ? i : W(Yi.call(i)), a) : t
    }, a.offset = function(i) {
        return arguments.length ? (n = i == null ? nn : i, a) : n
    }, a
}

function rS(e, t) {
    if ((r = e.length) > 0) {
        for (var n, r, a = 0, i = e[0].length, o; a < i; ++a) {
            for (o = n = 0; n < r; ++n) o += e[n][a][1] || 0;
            if (o)
                for (n = 0; n < r; ++n) e[n][a][1] /= o
        }
        nn(e, t)
    }
}

function aS(e, t) {
    if ((l = e.length) > 0)
        for (var n, r = 0, a, i, o, u, l, c = e[t[0]].length; r < c; ++r)
            for (o = u = 0, n = 0; n < l; ++n)(i = (a = e[t[n]][r])[1] - a[0]) > 0 ? (a[0] = o, a[1] = o += i) : i < 0 ? (a[1] = u, a[0] = u += i) : (a[0] = 0, a[1] = i)
}

function iS(e, t) {
    if ((a = e.length) > 0) {
        for (var n = 0, r = e[t[0]], a, i = r.length; n < i; ++n) {
            for (var o = 0, u = 0; o < a; ++o) u += e[o][n][1] || 0;
            r[n][1] += r[n][0] = -u / 2
        }
        nn(e, t)
    }
}

function oS(e, t) {
    if (!(!((o = e.length) > 0) || !((i = (a = e[t[0]]).length) > 0))) {
        for (var n = 0, r = 1, a, i, o; r < i; ++r) {
            for (var u = 0, l = 0, c = 0; u < o; ++u) {
                for (var f = e[t[u]], h = f[r][1] || 0, d = f[r - 1][1] || 0, y = (h - d) / 2, v = 0; v < u; ++v) {
                    var b = e[t[v]],
                        g = b[r][1] || 0,
                        p = b[r - 1][1] || 0;
                    y += g - p
                }
                l += h, c += y * h
            }
            a[r - 1][1] += a[r - 1][0] = n, l && (n -= c / l)
        }
        a[r - 1][1] += a[r - 1][0] = n, nn(e, t)
    }
}

function Ws(e) {
    var t = e.map(uS);
    return rn(e).sort(function(n, r) {
        return t[n] - t[r]
    })
}

function uS(e) {
    for (var t = -1, n = 0, r = e.length, a, i = -1 / 0; ++t < r;)(a = +e[t][1]) > i && (i = a, n = t);
    return n
}

function zs(e) {
    var t = e.map(Us);
    return rn(e).sort(function(n, r) {
        return t[n] - t[r]
    })
}

function Us(e) {
    for (var t = 0, n = -1, r = e.length, a; ++n < r;)(a = +e[n][1]) && (t += a);
    return t
}

function lS(e) {
    return zs(e).reverse()
}

function cS(e) {
    var t = e.length,
        n, r, a = e.map(Us),
        i = Ws(e),
        o = 0,
        u = 0,
        l = [],
        c = [];
    for (n = 0; n < t; ++n) r = i[n], o < u ? (o += a[r], l.push(r)) : (u += a[r], c.push(r));
    return c.reverse().concat(l)
}

function fS(e) {
    return rn(e).reverse()
}
var tr = Object.freeze(Object.defineProperty({
    __proto__: null,
    arc: pT,
    area: ra,
    line: Da,
    pie: wT,
    areaRadial: Vi,
    radialArea: Vi,
    lineRadial: qi,
    radialLine: qi,
    pointRadial: Rn,
    linkHorizontal: MT,
    linkVertical: CT,
    linkRadial: $T,
    symbol: jT,
    symbols: LT,
    symbolCircle: ru,
    symbolCross: ws,
    symbolDiamond: Os,
    symbolSquare: Es,
    symbolStar: Ss,
    symbolTriangle: Ms,
    symbolWye: Cs,
    curveBasisClosed: FT,
    curveBasisOpen: WT,
    curveBasis: RT,
    curveBundle: zT,
    curveCardinalClosed: HT,
    curveCardinalOpen: BT,
    curveCardinal: UT,
    curveCatmullRomClosed: qT,
    curveCatmullRomOpen: VT,
    curveCatmullRom: GT,
    curveLinearClosed: YT,
    curveLinear: Ia,
    curveMonotoneX: KT,
    curveMonotoneY: XT,
    curveNatural: ZT,
    curveStep: QT,
    curveStepAfter: eS,
    curveStepBefore: JT,
    stack: nS,
    stackOffsetExpand: rS,
    stackOffsetDiverging: aS,
    stackOffsetNone: nn,
    stackOffsetSilhouette: iS,
    stackOffsetWiggle: oS,
    stackOrderAppearance: Ws,
    stackOrderAscending: zs,
    stackOrderDescending: lS,
    stackOrderInsideOut: cS,
    stackOrderNone: rn,
    stackOrderReverse: fS
}, Symbol.toStringTag, {
    value: "Module"
}));

function sS(e) {
    for (var t = -1, n = e == null ? 0 : e.length, r = {}; ++t < n;) {
        var a = e[t];
        r[a[0]] = a[1]
    }
    return r
}
var hS = sS,
    Xi = {
        exports: {}
    };
(function(e, t) {
    t = e.exports = n, t.getSerialize = r;

    function n(a, i, o, u) {
        return JSON.stringify(a, r(i, u), o)
    }

    function r(a, i) {
        var o = [],
            u = [];
        return i == null && (i = function(l, c) {
                return o[0] === c ? "[Circular ~]" : "[Circular ~." + u.slice(0, o.indexOf(c)).join(".") + "]"
            }),
            function(l, c) {
                if (o.length > 0) {
                    var f = o.indexOf(this);
                    ~f ? o.splice(f + 1) : o.push(this), ~f ? u.splice(f, 1 / 0, l) : u.push(l), ~o.indexOf(c) && (c = i.call(this, l, c))
                } else o.push(c);
                return a == null ? c : a.call(this, l, c)
            }
    }
})(Xi, Xi.exports);
var dS = Xi.exports;

function vS(e, t) {
    return mS(e) || yS(e, t) || gS()
}

function gS() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function yS(e, t) {
    var n = [],
        r = !0,
        a = !1,
        i = void 0;
    try {
        for (var o = e[Symbol.iterator](), u; !(r = (u = o.next()).done) && (n.push(u.value), !(t && n.length === t)); r = !0);
    } catch (l) {
        a = !0, i = l
    } finally {
        try {
            !r && o.return != null && o.return()
        } finally {
            if (a) throw i
        }
    }
    return n
}

function mS(e) {
    if (Array.isArray(e)) return e
}

function bS(e) {
    return xS(e) || _S(e) || pS()
}

function pS() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _S(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function xS(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function wS(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function I0(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function AS(e, t, n) {
    return t && I0(e.prototype, t), n && I0(e, n), e
}

function OS(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : Zi(e)
}

function TS(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function Zi(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}
var bn = function(e) {
    TS(t, e);

    function t(n) {
        var r;
        return wS(this, t), r = OS(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n)), r.state = r.state || {}, r.getScopedEvents = Of.bind(Zi(r)), r.getEventState = Sf.bind(Zi(r)), r.baseProps = r.getBaseProps(n), r.sharedEventsCache = {}, r.globalEvents = {}, r.prevGlobalEventKeys = [], r.boundGlobalEvents = {}, r
    }
    return AS(t, [{
        key: "shouldComponentUpdate",
        value: function(r) {
            if (!qe(this.props, r)) {
                this.baseProps = this.getBaseProps(r);
                var a = this.getExternalMutations(r, this.baseProps);
                this.applyExternalMutations(r, a)
            }
            return !0
        }
    }, {
        key: "componentDidMount",
        value: function() {
            var r = this,
                a = ee(this.globalEvents);
            a.forEach(function(i) {
                return r.addGlobalListener(i)
            }), this.prevGlobalEventKeys = a
        }
    }, {
        key: "componentDidUpdate",
        value: function() {
            var r = this,
                a = ee(this.globalEvents),
                i = Gr(this.prevGlobalEventKeys, a);
            i.forEach(function(u) {
                return r.removeGlobalListener(u)
            });
            var o = Gr(a, this.prevGlobalEventKeys);
            o.forEach(function(u) {
                return r.addGlobalListener(u)
            }), this.prevGlobalEventKeys = a
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            var r = this;
            this.prevGlobalEventKeys.forEach(function(a) {
                return r.removeGlobalListener(a)
            })
        }
    }, {
        key: "addGlobalListener",
        value: function(r) {
            var a = this,
                i = function(o) {
                    var u = a.globalEvents[r];
                    return u && u($f(o))
                };
            this.boundGlobalEvents[r] = i, window.addEventListener(Vr(r), i)
        }
    }, {
        key: "removeGlobalListener",
        value: function(r) {
            window.removeEventListener(Vr(r), this.boundGlobalEvents[r])
        }
    }, {
        key: "getAllEvents",
        value: function(r) {
            var a = ["container", "groupComponent"],
                i = ko(r, a);
            return Array.isArray(i) ? Array.isArray(r.events) ? i.concat.apply(i, bS(r.events)) : i : r.events
        }
    }, {
        key: "applyExternalMutations",
        value: function(r, a) {
            if (!re(a)) {
                var i = r.externalEventMutations.reduce(function(u, l) {
                        return u = H(l.callback) ? u.concat(l.callback) : u, u
                    }, []),
                    o = i.length ? function() {
                        i.forEach(function(u) {
                            return u()
                        })
                    } : void 0;
                this.setState(a, o)
            }
        }
    }, {
        key: "getExternalMutations",
        value: function(r, a) {
            return re(r.externalEventMutations) ? void 0 : Yx(r.externalEventMutations, a, this.state, ee(a))
        }
    }, {
        key: "cacheSharedEvents",
        value: function(r, a, i) {
            this.sharedEventsCache[r] = [a, i]
        }
    }, {
        key: "getCachedSharedEvents",
        value: function(r, a) {
            var i = this.sharedEventsCache[r] || [],
                o = vS(i, 2),
                u = o[0],
                l = o[1];
            if (u && qe(a, l)) return u
        }
    }, {
        key: "getBaseProps",
        value: function(r) {
            var a = r.container,
                i = A.Children.toArray(this.props.children),
                o = this.getBasePropsFromChildren(i),
                u = a ? a.props : {};
            return S({}, o, {
                parent: u
            })
        }
    }, {
        key: "getBasePropsFromChildren",
        value: function(r) {
            var a = function(o, u) {
                    if (o.type && H(o.type.getBaseProps)) {
                        var l = o.props && o.type.getBaseProps(o.props);
                        return l ? [
                            [u, l]
                        ] : null
                    } else return null
                },
                i = jt(r, a);
            return hS(i)
        }
    }, {
        key: "getNewChildren",
        value: function(r, a) {
            var i = this,
                o = r.events,
                u = r.eventKey,
                l = function(h, d) {
                    return h.reduce(function(y, v, b) {
                        if (v.props.children) {
                            var g = A.Children.toArray(v.props.children),
                                p = d.slice(b, b + g.length),
                                m = A.cloneElement(v, v.props, l(g, p));
                            return y.concat(m)
                        } else if (d[b] !== "parent" && v.type && H(v.type.getBaseProps)) {
                            var _ = v.props.name || d[b],
                                w = Array.isArray(o) && o.filter(function(x) {
                                    return x.target === "parent" ? !1 : Array.isArray(x.childName) ? x.childName.indexOf(_) > -1 : x.childName === _ || x.childName === "all"
                                }),
                                O = [_, a, w, dS(i.state[_])],
                                T = i.getCachedSharedEvents(_, O) || {
                                    events: w,
                                    getEvents: function(x, M) {
                                        return i.getScopedEvents(x, M, _, a)
                                    },
                                    getEventState: function(x, M) {
                                        return i.getEventState(x, M, _)
                                    }
                                };
                            return i.cacheSharedEvents(_, T, O), y.concat(A.cloneElement(v, S({
                                key: "events-".concat(_),
                                sharedEvents: T,
                                eventKey: u,
                                name: _
                            }, v.props)))
                        } else return y.concat(v)
                    }, [])
                },
                c = ee(a),
                f = A.Children.toArray(r.children);
            return l(f, c)
        }
    }, {
        key: "getContainer",
        value: function(r, a, i) {
            var o = this,
                u = this.getNewChildren(r, a),
                l = Array.isArray(i) && i.filter(function(m) {
                    return m.target === "parent"
                }),
                c = l.length > 0 ? {
                    events: l,
                    getEvents: function(m, _) {
                        return o.getScopedEvents(m, _, null, a)
                    },
                    getEventState: this.getEventState
                } : null,
                f = r.container || r.groupComponent,
                h = f.type && f.type.role,
                d = f.props || {},
                y = Af.bind(this),
                v = c && y({
                    sharedEvents: c
                }, "parent"),
                b = L({}, this.getEventState("parent", "parent"), d, a.parent, {
                    children: u
                }),
                g = L({}, Tf(v, "parent", b), d.events);
            this.globalEvents = Mf(g);
            var p = Cf(g);
            return h === "container" ? A.cloneElement(f, S({}, b, {
                events: p
            })) : A.cloneElement(f, p, u)
        }
    }, {
        key: "render",
        value: function() {
            var r = this.getAllEvents(this.props);
            return r ? this.getContainer(this.props, this.baseProps, r) : A.cloneElement(this.props.container, {
                children: this.props.children
            })
        }
    }]), t
}(A.Component);
Object.defineProperty(bn, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictorySharedEvents"
});
Object.defineProperty(bn, "role", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "shared-event-wrapper"
});
Object.defineProperty(bn, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        children: s.oneOfType([s.arrayOf(s.node), s.node]),
        container: s.node,
        eventKey: s.oneOfType([s.array, s.func, Be([Le, G]), s.string]),
        events: s.arrayOf(s.shape({
            childName: s.oneOfType([s.string, s.array]),
            eventHandlers: s.object,
            eventKey: s.oneOfType([s.array, s.func, Be([Le, G]), s.string]),
            target: s.string
        })),
        externalEventMutations: s.arrayOf(s.shape({
            callback: s.function,
            childName: s.oneOfType([s.string, s.array]),
            eventKey: s.oneOfType([s.array, Be([Le, G]), s.string]),
            mutation: s.function,
            target: s.oneOfType([s.string, s.array])
        })),
        groupComponent: s.node
    }
});
Object.defineProperty(bn, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        groupComponent: A.createElement("g", null)
    }
});
Object.defineProperty(bn, "contextType", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: wa
});

function Fn(e) {
    return MS(e) || ES(e) || SS()
}

function SS() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function ES(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function MS(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function CS(e, t) {
    return kS(e) || PS(e, t) || $S()
}

function $S() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function PS(e, t) {
    var n = [],
        r = !0,
        a = !1,
        i = void 0;
    try {
        for (var o = e[Symbol.iterator](), u; !(r = (u = o.next()).done) && (n.push(u.value), !(t && n.length === t)); r = !0);
    } catch (l) {
        a = !0, i = l
    } finally {
        try {
            !r && o.return != null && o.return()
        } finally {
            if (a) throw i
        }
    }
    return n
}

function kS(e) {
    if (Array.isArray(e)) return e
}

function IS(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            DS(e, a, n[a])
        })
    }
    return e
}

function DS(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
var Hs = {
    width: 450,
    height: 300,
    padding: 50,
    offset: 0
};

function Bs(e, t) {
    var n = "group";
    e = hn(e, Hs, n);
    var r = WO(e.theme, e.style, n),
        a = e,
        i = a.offset,
        o = a.colorScale,
        u = a.color,
        l = a.polar,
        c = a.horizontal,
        f = e.categories || GO(e, t),
        h = e.datasets || NO(e),
        d = {
            x: A0(S({}, e, {
                categories: f
            }), "x", t),
            y: A0(S({}, e, {
                categories: f
            }), "y", t)
        },
        y = e.range || {
            x: Ze(e, "x"),
            y: Ze(e, "y")
        },
        v = {
            x: Wi(e, "x") || O0(e, "x"),
            y: Wi(e, "y") || O0(e, "y")
        },
        b = {
            x: v.x.domain(d.x).range(e.horizontal ? y.y : y.x),
            y: v.y.domain(d.y).range(e.horizontal ? y.x : y.y)
        },
        g = l ? e.origin : Uc(e),
        p = Xe(e);
    return {
        datasets: h,
        categories: f,
        range: y,
        domain: d,
        horizontal: c,
        scale: b,
        style: r,
        colorScale: o,
        color: u,
        offset: i,
        origin: g,
        padding: p
    }
}
var NS = function(e) {
    var t = e.children,
        n = A.Children.toArray(t).map(function(r) {
            return IS({}, r, {
                props: fr(r.props, ["sharedEvents"])
            })
        });
    return e.children = n, e
};

function LS(e) {
    var t = NS(e),
        n = A.useState(t),
        r = CS(n, 2),
        a = r[0],
        i = r[1];
    return A.useEffect(function() {
        qe(t, a) || i(t)
    }, [a, i, t]), A.useMemo(function() {
        return Bs(a, a.children)
    }, [a])
}

function jS(e, t, n) {
    if (!e.offset) return 0;
    var r = Hc(t, e.horizontal),
        a = n.domain[t],
        i = n.range[r],
        o = Math.max.apply(Math, Fn(a)) - Math.min.apply(Math, Fn(a)),
        u = Math.max.apply(Math, Fn(i)) - Math.min.apply(Math, Fn(i));
    return o / u * e.offset
}

function RS(e, t, n, r) {
    var a = r === "stack" ? t.datasets[0].length : t.datasets.length,
        i = (a - 1) / 2,
        o = jS(e, "x", t);
    return (n - i) * o
}

function FS(e, t, n, r) {
    var a = r === "stack" ? t.datasets[0].length : t.datasets.length,
        i = (a - 1) / 2,
        o = WS(e, t);
    return (n - i) * o
}

function WS(e, t) {
    var n = t.range,
        r = Math.abs(n.x[1] - n.x[0]),
        a = Math.max.apply(Math, Fn(n.y));
    return e.offset / (2 * Math.PI * a) * r
}

function zS(e, t, n) {
    if (!!e.labels) return Math.floor(t.length / 2) === n ? e.labels : void 0
}

function US(e, t) {
    var n = t.categories,
        r = t.domain,
        a = t.range,
        i = t.scale,
        o = t.horizontal,
        u = t.origin,
        l = t.padding,
        c = e.width,
        f = e.height,
        h = e.theme,
        d = e.polar;
    return {
        height: f,
        width: c,
        theme: h,
        polar: d,
        origin: u,
        categories: n,
        domain: r,
        range: a,
        scale: i,
        horizontal: o,
        padding: l,
        standalone: !1
    }
}

function HS(e, t) {
    var n = t.type && t.type.role,
        r = t.props.colorScale || e.colorScale;
    if (!(n !== "group" && n !== "stack")) return e.theme && e.theme.group ? r || e.theme.group.colorScale : r
}

function BS(e) {
    var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : [],
        n = arguments.length > 2 ? arguments[2] : void 0,
        r = e.data || e.y ? nt(e) : t,
        a = n || 0;
    return r.map(function(i) {
        var o = i._x instanceof Date ? new Date(i._x.getTime() + a) : i._x + a;
        return S({}, i, {
            _x1: o
        })
    })
}

function Gs(e, t, n) {
    e = hn(e, Hs, "stack"), t = t || A.Children.toArray(e.children), n = n || Bs(e, t);
    var r = n,
        a = r.datasets,
        i = e,
        o = i.labelComponent,
        u = i.polar,
        l = US(e, n),
        c = e.name || "group";
    return t.map(function(f, h) {
        var d = f.type && f.type.role,
            y = u ? FS(e, n, h, d) : RS(e, n, h, d),
            v = d === "voronoi" || d === "tooltip" || d === "label" ? f.props.style : zO(f, h, n),
            b = e.labels ? zS(e, a, h) : f.props.labels,
            g = f.props.name || "".concat(c, "-").concat(d, "-").concat(h);
        return A.cloneElement(f, S({
            labels: b,
            style: v,
            key: "".concat(g, "-key-").concat(h),
            name: g,
            data: BS(e, a[h], y),
            colorScale: HS(e, f),
            labelComponent: o || f.props.labelComponent,
            xOffset: y
        }, l))
    })
}

function GS(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            qS(e, a, n[a])
        })
    }
    return e
}

function qS(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
var VS = {
        width: 450,
        height: 300,
        padding: 50,
        offset: 0
    },
    lu = function(e) {
        var t = pn.role,
            n = cT(),
            r = n.getAnimationProps,
            a = n.setAnimationState,
            i = n.getProps,
            o = i(e),
            u = hn(o, VS, t),
            l = u.eventKey,
            c = u.containerComponent,
            f = u.standalone,
            h = u.groupComponent,
            d = u.externalEventMutations,
            y = u.width,
            v = u.height,
            b = u.theme,
            g = u.polar,
            p = u.horizontal,
            m = u.name,
            _ = A.Children.toArray(u.children),
            w = LS(u),
            O = w.domain,
            T = w.scale,
            x = w.style,
            M = w.origin,
            C = A.useMemo(function() {
                var Z = Gs(o, _, w);
                return Z.map(function(Y, X) {
                    var K = S({
                        animate: r(o, Y, X, "victory-group")
                    }, Y.props);
                    return A.cloneElement(Y, K)
                })
            }, [o, _, w, r]),
            I = A.useMemo(function() {
                return f ? {
                    domain: O,
                    scale: T,
                    width: y,
                    height: v,
                    standalone: f,
                    theme: b,
                    style: x.parent,
                    horizontal: p,
                    polar: g,
                    origin: M,
                    name: m
                } : {}
            }, [f, O, T, y, v, b, x, p, g, M, m]),
            $ = A.useMemo(function() {
                return Ea(e)
            }, [e]),
            E = A.useMemo(function() {
                if (f) {
                    var Z = L({}, c.props, I, $);
                    return A.cloneElement(c, Z)
                }
                return A.cloneElement(h, $)
            }, [h, f, c, I, $]),
            k = A.useMemo(function() {
                return RO(o)
            }, [o]),
            F = qO(e);
        return A.useEffect(function() {
            return function() {
                e.animate && a(F, o)
            }
        }, [a, F, e, o]), re(k) ? A.cloneElement(E, E.props, C) : A.createElement(bn, {
            container: E,
            eventKey: l,
            events: k,
            externalEventMutations: d
        }, C)
    };
lu.propTypes = GS({}, ff, cf, {
    children: s.oneOfType([s.arrayOf(s.node), s.node]),
    color: s.oneOfType([s.string, s.func]),
    colorScale: s.oneOfType([s.arrayOf(s.string), s.oneOf(["grayscale", "qualitative", "heatmap", "warm", "cool", "red", "green", "blue"])]),
    horizontal: s.bool,
    offset: s.number
});
lu.defaultProps = {
    containerComponent: A.createElement(Qe, null),
    groupComponent: A.createElement("g", null),
    samples: 50,
    sortOrder: "ascending",
    standalone: !0,
    theme: $o.grayscale
};
var pn = A.memo(lu, qe);
pn.displayName = "VictoryGroup";
pn.role = "group";
pn.expectedComponents = ["groupComponent", "containerComponent", "labelComponent"];
pn.getChildren = Gs;
var YS = pn,
    KS = function(e, t) {
        var n = nt(e);
        n.length < 2 && (n = []);
        var r = function(a) {
            var i = ls(t[a]) === "log" ? 1 / Number.MAX_SAFE_INTEGER : 0,
                o = t[a].domain(),
                u = ut(o),
                l = Rt(o),
                c = i;
            return u < 0 && l <= 0 ? c = l : u >= 0 && l > 0 && (c = u), sr(o) ? new Date(c) : c
        };
        return n.map(function(a) {
            var i = a._y1 !== void 0 ? a._y1 : a._y,
                o = a._y0 !== void 0 ? a._y0 : r("y"),
                u = a._x1 !== void 0 ? a._x1 : a._x,
                l = a._x0 !== void 0 ? a._x0 : r("x");
            return S({}, a, {
                _y0: o,
                _y1: i,
                _x0: l,
                _x1: u
            })
        })
    },
    XS = function(e) {
        var t = e.polar,
            n = _p(e, "area"),
            r = zc(e.style, n),
            a = {
                x: Ze(e, "x"),
                y: Ze(e, "y")
            },
            i = {
                x: Ui(e, "x"),
                y: Ui(e, "y")
            },
            o = {
                x: ea(e, "x").domain(i.x).range(e.horizontal ? a.y : a.x),
                y: ea(e, "y").domain(i.y).range(e.horizontal ? a.x : a.y)
            },
            u = t ? e.origin || Uc(e) : void 0,
            l = KS(e, o);
        return {
            style: r,
            data: l,
            scale: o,
            domain: i,
            origin: u
        }
    },
    ZS = function(e, t) {
        var n = hn(e, t, "area");
        e = S({}, n, XS(n));
        var r = e,
            a = r.data,
            i = r.domain,
            o = r.events,
            u = r.groupComponent,
            l = r.height,
            c = r.horizontal,
            f = r.interpolation,
            h = r.origin,
            d = r.padding,
            y = r.polar,
            v = r.scale,
            b = r.sharedEvents,
            g = r.standalone,
            p = r.style,
            m = r.theme,
            _ = r.width,
            w = r.labels,
            O = r.name,
            T = r.disableInlineStyles,
            x = {
                parent: {
                    style: p.parent,
                    width: _,
                    height: l,
                    scale: v,
                    data: a,
                    domain: i,
                    standalone: g,
                    theme: m,
                    polar: y,
                    origin: h,
                    padding: d,
                    name: O,
                    horizontal: c
                },
                all: {
                    data: {
                        horizontal: c,
                        polar: y,
                        origin: h,
                        scale: v,
                        data: a,
                        interpolation: f,
                        groupComponent: u,
                        style: T ? {} : p.data,
                        disableInlineStyles: T
                    }
                }
            };
        return a.reduce(function(M, C, I) {
            var $ = qc(e, C, I);
            if ($ != null || w && (o || b)) {
                var E = $i(C.eventKey) ? I : C.eventKey;
                M[E] = {
                    labels: y_(e, I)
                }
            }
            return M
        }, x)
    };

function qs(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            QS(e, a, n[a])
        })
    }
    return e
}

function QS(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
var nr = function(e) {
        var t = e._y1 !== void 0 ? e._y1 : e._y;
        return t != null && e._y0 !== null
    },
    ua = function(e) {
        return function(t) {
            return e.x(t._x1 !== void 0 ? t._x1 : t._x)
        }
    },
    Vt = function(e) {
        return function(t) {
            return e.y(t._y1 !== void 0 ? t._y1 : t._y)
        }
    },
    Qi = function(e) {
        return function(t) {
            return e.y(t._y0)
        }
    },
    Vs = function(e) {
        return function(t) {
            var n = e.x(t._x1 !== void 0 ? t._x1 : t._x);
            return -1 * n + Math.PI / 2
        }
    },
    Ys = function(e) {
        var t = function(n) {
            return n && n[0].toUpperCase() + n.slice(1)
        };
        return "curve".concat(t(e))
    },
    JS = function(e) {
        var t = e.polar,
            n = e.scale,
            r = e.horizontal,
            a = typeof e.interpolation == "function" && e.interpolation,
            i = typeof e.interpolation == "string" && Ys(e.interpolation);
        return t ? qi().defined(nr).curve(a || tr["".concat(i, "Closed")]).angle(Vs(n)).radius(Vt(n)) : Da().defined(nr).curve(a || tr[i]).x(r ? Vt(n) : ua(n)).y(r ? ua(n) : Vt(n))
    },
    eE = function(e, t) {
        var n = e.horizontal,
            r = e.scale,
            a = typeof t == "function" && t,
            i = typeof t == "string" && t;
        return n ? ra().defined(nr).curve(a || tr[i]).x0(Qi(r)).x1(Vt(r)).y(ua(r)) : ra().defined(nr).curve(a || tr[i]).x(ua(r)).y1(Vt(r)).y0(Qi(r))
    },
    tE = function(e) {
        var t = e.polar,
            n = e.scale,
            r = typeof e.interpolation == "function" && e.interpolation,
            a = typeof e.interpolation == "string" && Ys(e.interpolation),
            i = r || a;
        return t ? Vi().defined(nr).curve(r || tr["".concat(a, "Closed")]).angle(Vs(n)).outerRadius(Vt(n)).innerRadius(Qi(n)) : eE(e, i)
    },
    nE = function(e) {
        var t = R(e.ariaLabel, e),
            n = R(e.desc, e),
            r = R(e.id, e),
            a = Ye(S({
                fill: "black"
            }, e.style), e),
            i = R(e.tabIndex, e);
        return S({}, e, {
            ariaLabel: t,
            desc: n,
            id: r,
            style: a,
            tabIndex: i
        })
    },
    cu = function(e) {
        e = nE(e);
        var t = e,
            n = t.ariaLabel,
            r = t.role,
            a = t.shapeRendering,
            i = t.className,
            o = t.polar,
            u = t.origin,
            l = t.data,
            c = t.pathComponent,
            f = t.events,
            h = t.groupComponent,
            d = t.clipPath,
            y = t.id,
            v = t.style,
            b = t.desc,
            g = t.tabIndex,
            p = o && u ? "translate(".concat(u.x, ", ").concat(u.y, ")") : void 0,
            m = e.transform || p,
            _ = v.stroke && v.stroke !== "none" && v.stroke !== "transparent",
            w = tE(e),
            O = _ && JS(e),
            T = v.stroke ? "none" : v.fill,
            x = qs({
                "aria-label": n,
                className: i,
                role: r,
                shapeRendering: a,
                transform: m
            }, f, {
                clipPath: d,
                tabIndex: g
            }),
            M = A.cloneElement(c, S({
                key: "".concat(y, "-area"),
                style: S({}, v, {
                    stroke: T
                }),
                d: w(l),
                desc: b,
                tabIndex: g
            }, x)),
            C = _ ? A.cloneElement(c, S({
                key: "".concat(y, "-area-stroke"),
                style: S({}, v, {
                    fill: "none"
                }),
                d: O(l)
            }, x)) : null;
        return _ ? A.cloneElement(h, {}, [M, C]) : M
    };
cu.propTypes = qs({}, sf, {
    groupComponent: s.element,
    interpolation: s.oneOfType([s.string, s.func]),
    pathComponent: s.element
});
cu.defaultProps = {
    groupComponent: A.createElement("g", null),
    pathComponent: A.createElement(hf, null),
    role: "presentation",
    shapeRendering: "auto"
};
var rE = cu;

function aE(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            iE(e, a, n[a])
        })
    }
    return e
}

function iE(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function oE(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function D0(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function uE(e, t, n) {
    return t && D0(e.prototype, t), n && D0(e, n), e
}

function lE(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : cE(e)
}

function cE(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function fE(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var Ks = {
        width: 450,
        height: 300,
        padding: 50,
        interpolation: "linear"
    },
    sE = {
        components: [{
            name: "parent",
            index: "parent"
        }, {
            name: "data",
            index: "all"
        }, {
            name: "labels"
        }]
    },
    Se = function(e) {
        fE(t, e);

        function t() {
            return oE(this, t), lE(this, (t.__proto__ || Object.getPrototypeOf(t)).apply(this, arguments))
        }
        return uE(t, [{
            key: "shouldAnimate",
            value: function() {
                return !!this.props.animate
            }
        }, {
            key: "render",
            value: function() {
                var r = t.animationWhitelist,
                    a = t.role,
                    i = hn(this.props, Ks, a);
                if (this.shouldAnimate()) return this.animateComponent(i, r);
                var o = this.renderContinuousData(i),
                    u = A.cloneElement(i.containerComponent, Ea(i));
                return i.standalone ? this.renderContainer(u, o) : o
            }
        }]), t
    }(A.Component);
Object.defineProperty(Se, "animationWhitelist", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: ["data", "domain", "height", "padding", "style", "width"]
});
Object.defineProperty(Se, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: aE({}, ff, cf, {
        interpolation: s.oneOfType([s.oneOf(["basis", "cardinal", "catmullRom", "linear", "monotoneX", "monotoneY", "natural", "step", "stepAfter", "stepBefore"]), s.func]),
        label: L3(s.string)
    })
});
Object.defineProperty(Se, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        containerComponent: A.createElement(Qe, null),
        dataComponent: A.createElement(rE, null),
        groupComponent: A.createElement(kt, null),
        labelComponent: A.createElement(tf, {
            renderInPortal: !0
        }),
        samples: 50,
        sortKey: "x",
        sortOrder: "ascending",
        standalone: !0,
        theme: $o.grayscale
    }
});
Object.defineProperty(Se, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryArea"
});
Object.defineProperty(Se, "role", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "area"
});
Object.defineProperty(Se, "continuous", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: !0
});
Object.defineProperty(Se, "defaultTransitions", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: IA()
});
Object.defineProperty(Se, "defaultPolarTransitions", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: DA()
});
Object.defineProperty(Se, "getDomain", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: Ui
});
Object.defineProperty(Se, "getData", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: nt
});
Object.defineProperty(Se, "getBaseProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: function(e) {
        return ZS(e, Ks)
    }
});
Object.defineProperty(Se, "expectedComponents", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: ["dataComponent", "labelComponent", "groupComponent", "containerComponent"]
});
var N0 = a9(Se, sE),
    hE = Je,
    dE = function() {
        return hE.Date.now()
    },
    vE = dE,
    gE = Te,
    fi = vE,
    L0 = kc,
    yE = "Expected a function",
    mE = Math.max,
    bE = Math.min;

function pE(e, t, n) {
    var r, a, i, o, u, l, c = 0,
        f = !1,
        h = !1,
        d = !0;
    if (typeof e != "function") throw new TypeError(yE);
    t = L0(t) || 0, gE(n) && (f = !!n.leading, h = "maxWait" in n, i = h ? mE(L0(n.maxWait) || 0, t) : i, d = "trailing" in n ? !!n.trailing : d);

    function y(T) {
        var x = r,
            M = a;
        return r = a = void 0, c = T, o = e.apply(M, x), o
    }

    function v(T) {
        return c = T, u = setTimeout(p, t), f ? y(T) : o
    }

    function b(T) {
        var x = T - l,
            M = T - c,
            C = t - x;
        return h ? bE(C, i - M) : C
    }

    function g(T) {
        var x = T - l,
            M = T - c;
        return l === void 0 || x >= t || x < 0 || h && M >= i
    }

    function p() {
        var T = fi();
        if (g(T)) return m(T);
        u = setTimeout(p, b(T))
    }

    function m(T) {
        return u = void 0, d && r ? y(T) : (r = a = void 0, o)
    }

    function _() {
        u !== void 0 && clearTimeout(u), c = 0, r = l = a = u = void 0
    }

    function w() {
        return u === void 0 ? o : m(fi())
    }

    function O() {
        var T = fi(),
            x = g(T);
        if (r = arguments, a = this, l = T, x) {
            if (u === void 0) return v(l);
            if (h) return clearTimeout(u), u = setTimeout(p, t), y(l)
        }
        return u === void 0 && (u = setTimeout(p, t)), o
    }
    return O.cancel = _, O.flush = w, O
}
var _E = pE,
    xE = _E,
    wE = Te,
    AE = "Expected a function";

function OE(e, t, n) {
    var r = !0,
        a = !0;
    if (typeof e != "function") throw new TypeError(AE);
    return wE(n) && (r = "leading" in n ? !!n.leading : r, a = "trailing" in n ? !!n.trailing : a), xE(e, t, {
        leading: r,
        maxWait: t,
        trailing: a
    })
}
var TE = OE,
    SE = TE;

function Xs(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            EE(e, a, n[a])
        })
    }
    return e
}

function EE(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}
var ME = function(e) {
        var t = e.pointerWidth,
            n = e.cornerRadius,
            r = e.orientation,
            a = e.width,
            i = e.height,
            o = e.center,
            u = r === "bottom" ? 1 : -1,
            l = e.x + (e.dx || 0),
            c = e.y + (e.dy || 0),
            f = ne(o) && o.x,
            h = ne(o) && o.y,
            d = h + u * (i / 2),
            y = h - u * (i / 2),
            v = f + a / 2,
            b = f - a / 2,
            g = u * (c - d) < 0 ? 0 : e.pointerLength,
            p = r === "bottom" ? "0 0 0" : "0 0 1",
            m = "".concat(n, " ").concat(n, " ").concat(p);
        return "M ".concat(f - t / 2, ", ").concat(d, `
    L `).concat(g ? l : f + t / 2, ", ").concat(g ? c : d, `
    L `).concat(f + t / 2, ", ").concat(d, `
    L `).concat(v - n, ", ").concat(d, `
    A `).concat(m, " ").concat(v, ", ").concat(d - u * n, `
    L `).concat(v, ", ").concat(y + u * n, `
    A `).concat(m, " ").concat(v - n, ", ").concat(y, `
    L `).concat(b + n, ", ").concat(y, `
    A `).concat(m, " ").concat(b, ", ").concat(y + u * n, `
    L `).concat(b, ", ").concat(d - u * n, `
    A `).concat(m, " ").concat(b + n, ", ").concat(d, `
    z`)
    },
    CE = function(e) {
        var t = e.pointerWidth,
            n = e.cornerRadius,
            r = e.orientation,
            a = e.width,
            i = e.height,
            o = e.center,
            u = r === "left" ? 1 : -1,
            l = e.x + (e.dx || 0),
            c = e.y + (e.dy || 0),
            f = ne(o) && o.x,
            h = ne(o) && o.y,
            d = f - u * (a / 2),
            y = f + u * (a / 2),
            v = h + i / 2,
            b = h - i / 2,
            g = u * (l - d) > 0 ? 0 : e.pointerLength,
            p = r === "left" ? "0 0 0" : "0 0 1",
            m = "".concat(n, " ").concat(n, " ").concat(p);
        return "M ".concat(d, ", ").concat(h - t / 2, `
    L `).concat(g ? l : d, ", ").concat(g ? c : h + t / 2, `
    L `).concat(d, ", ").concat(h + t / 2, `
    L `).concat(d, ", ").concat(v - n, `
    A `).concat(m, " ").concat(d + u * n, ", ").concat(v, `
    L `).concat(y - u * n, ", ").concat(v, `
    A `).concat(m, " ").concat(y, ", ").concat(v - n, `
    L `).concat(y, ", ").concat(b + n, `
    A `).concat(m, " ").concat(y - u * n, ", ").concat(b, `
    L `).concat(d + u * n, ", ").concat(b, `
    A `).concat(m, " ").concat(d, ", ").concat(b + n, `
    z`)
    },
    $E = function(e) {
        var t = e.orientation || "top";
        return t === "left" || t === "right" ? CE(e) : ME(e)
    },
    PE = function(e) {
        var t = R(e.id, e),
            n = Ye(e.style, e);
        return S({}, e, {
            id: t,
            style: n
        })
    },
    fu = function(e) {
        return e = PE(e), A.cloneElement(e.pathComponent, Xs({}, e.events, {
            style: e.style,
            d: $E(e),
            className: e.className,
            shapeRendering: e.shapeRendering,
            role: e.role,
            transform: e.transform,
            clipPath: e.clipPath
        }))
    };
fu.propTypes = Xs({}, sf, {
    center: s.shape({
        x: s.number,
        y: s.number
    }),
    cornerRadius: s.number,
    datum: s.object,
    dx: s.number,
    dy: s.number,
    height: s.number,
    orientation: s.oneOf(["top", "bottom", "left", "right"]),
    pathComponent: s.element,
    pointerLength: s.number,
    pointerWidth: s.number,
    width: s.number,
    x: s.number,
    y: s.number
});
fu.defaultProps = {
    pathComponent: A.createElement(hf, null),
    role: "presentation",
    shapeRendering: "auto"
};
var kE = fu;

function IE(e) {
    return LE(e) || NE(e) || DE()
}

function DE() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function NE(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function LE(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function jE(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function j0(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function RE(e, t, n) {
    return t && j0(e.prototype, t), n && j0(e, n), e
}

function FE(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : WE(e)
}

function WE(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function zE(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var UE = {
        cornerRadius: 5,
        pointerLength: 10,
        pointerWidth: 10
    },
    _n = function(e) {
        zE(t, e);

        function t(n) {
            var r;
            return jE(this, t), r = FE(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this, n)), r.id = n.id === void 0 ? Oo("tooltip-") : n.id, r
        }
        return RE(t, [{
            key: "getDefaultOrientation",
            value: function(r) {
                var a = r.datum,
                    i = r.horizontal,
                    o = r.polar;
                if (o) return this.getPolarOrientation(r, a);
                var u = i ? "right" : "top",
                    l = i ? "left" : "bottom";
                return a && a.y < 0 ? l : u
            }
        }, {
            key: "getPolarOrientation",
            value: function(r, a) {
                var i = Zn(r, a),
                    o = r.labelPlacement || "vertical";
                return o === " vertical" ? this.getVerticalOrientations(i) : o === "parallel" ? i < 90 || i > 270 ? "right" : "left" : i > 180 ? "bottom" : "top"
            }
        }, {
            key: "getVerticalOrientations",
            value: function(r) {
                return r < 45 || r > 315 ? "right" : r >= 45 && r <= 135 ? "top" : r > 135 && r < 225 ? "left" : "bottom"
            }
        }, {
            key: "getStyles",
            value: function(r) {
                var a = r.theme || $o.grayscale,
                    i = a && a.tooltip && a.tooltip.style ? a.tooltip.style : {},
                    o = Array.isArray(r.style) ? r.style.map(function(h) {
                        return L({}, h, i)
                    }) : L({}, r.style, i),
                    u = a && a.tooltip && a.tooltip.flyoutStyle ? a.tooltip.flyoutStyle : {},
                    l = r.flyoutStyle ? L({}, r.flyoutStyle, u) : u,
                    c = Array.isArray(o) ? o.map(function(h) {
                        return Ye(h, r)
                    }) : Ye(o, r),
                    f = Ye(l, S({}, r, {
                        style: c
                    }));
                return {
                    style: c,
                    flyoutStyle: f
                }
            }
        }, {
            key: "getEvaluatedProps",
            value: function(r) {
                var a = r.cornerRadius,
                    i = r.centerOffset,
                    o = r.dx,
                    u = r.dy,
                    l = R(r.active, r),
                    c = R(r.text, S({}, r, {
                        active: l
                    })),
                    f = this.getStyles(S({}, r, {
                        active: l,
                        text: c
                    })),
                    h = f.style,
                    d = f.flyoutStyle,
                    y = R(r.orientation, S({}, r, {
                        active: l,
                        text: c,
                        style: h,
                        flyoutStyle: d
                    })) || this.getDefaultOrientation(r),
                    v = R(r.flyoutPadding, S({}, r, {
                        active: l,
                        text: c,
                        style: h,
                        flyoutStyle: d,
                        orientation: y
                    })) || this.getLabelPadding(h),
                    b = Xe({
                        padding: v
                    }),
                    g = R(r.pointerWidth, S({}, r, {
                        active: l,
                        text: c,
                        style: h,
                        flyoutStyle: d,
                        orientation: y
                    })),
                    p = R(r.pointerLength, S({}, r, {
                        active: l,
                        text: c,
                        style: h,
                        flyoutStyle: d,
                        orientation: y
                    })),
                    m = Ei(c, h),
                    _ = this.getDimensions(S({}, r, {
                        style: h,
                        flyoutStyle: d,
                        active: l,
                        text: c,
                        orientation: y,
                        flyoutPadding: b,
                        pointerWidth: g,
                        pointerLength: p
                    }), m),
                    w = _.flyoutHeight,
                    O = _.flyoutWidth,
                    T = S({}, r, {
                        active: l,
                        text: c,
                        style: h,
                        flyoutStyle: d,
                        orientation: y,
                        flyoutHeight: w,
                        flyoutWidth: O,
                        flyoutPadding: b,
                        pointerWidth: g,
                        pointerLength: p
                    }),
                    x = ne(i) && i.x !== void 0 ? R(i.x, T) : 0,
                    M = ne(i) && i.y !== void 0 ? R(i.y, T) : 0;
                return S({}, T, {
                    centerOffset: {
                        x,
                        y: M
                    },
                    dx: o !== void 0 ? R(o, T) : 0,
                    dy: u !== void 0 ? R(u, T) : 0,
                    cornerRadius: R(a, T)
                })
            }
        }, {
            key: "getCalculatedValues",
            value: function(r) {
                var a = r.style,
                    i = r.text,
                    o = r.flyoutStyle,
                    u = r.flyoutHeight,
                    l = r.flyoutWidth,
                    c = Ei(i, a),
                    f = {
                        height: u,
                        width: l
                    },
                    h = this.getFlyoutCenter(r, f),
                    d = this.getTransform(r);
                return {
                    style: a,
                    flyoutStyle: o,
                    labelSize: c,
                    flyoutDimensions: f,
                    flyoutCenter: h,
                    transform: d
                }
            }
        }, {
            key: "getTransform",
            value: function(r) {
                var a = r.x,
                    i = r.y,
                    o = r.style,
                    u = o || {},
                    l = u.angle || r.angle || this.getDefaultAngle(r);
                return l ? "rotate(".concat(l, " ").concat(a, " ").concat(i, ")") : void 0
            }
        }, {
            key: "getDefaultAngle",
            value: function(r) {
                var a = r.polar,
                    i = r.labelPlacement,
                    o = r.orientation,
                    u = r.datum;
                if (!a || !i || i === "vertical") return 0;
                var l = Zn(r, u),
                    c = l > 90 && l < 180 || l > 270 ? 1 : -1,
                    f = i === "perpendicular" ? 0 : 90,
                    h;
                return l === 0 || l === 180 ? h = o === "top" && l === 180 ? 270 : 90 : l > 0 && l < 180 ? h = 90 - l : l > 180 && l < 360 && (h = 270 - l), h + c * f
            }
        }, {
            key: "constrainTooltip",
            value: function(r, a, i) {
                var o = r.x,
                    u = r.y,
                    l = i.width,
                    c = i.height,
                    f = {
                        x: [0, a.width],
                        y: [0, a.height]
                    },
                    h = {
                        x: [o - l / 2, o + l / 2],
                        y: [u - c / 2, u + c / 2]
                    },
                    d = {
                        x: [h.x[0] < f.x[0] ? f.x[0] - h.x[0] : 0, h.x[1] > f.x[1] ? h.x[1] - f.x[1] : 0],
                        y: [h.y[0] < f.y[0] ? f.y[0] - h.y[0] : 0, h.y[1] > f.y[1] ? h.y[1] - f.y[1] : 0]
                    };
                return {
                    x: Math.round(o + d.x[0] - d.x[1]),
                    y: Math.round(u + d.y[0] - d.y[1])
                }
            }
        }, {
            key: "getFlyoutCenter",
            value: function(r, a) {
                var i = r.x,
                    o = r.y,
                    u = r.dx,
                    l = r.dy,
                    c = r.pointerLength,
                    f = r.orientation,
                    h = r.constrainToVisibleArea,
                    d = r.centerOffset,
                    y = a.height,
                    v = a.width,
                    b = f === "left" ? -1 : 1,
                    g = f === "bottom" ? -1 : 1,
                    p = {
                        x: f === "left" || f === "right" ? i + b * (c + v / 2 + b * u) : i + u,
                        y: f === "top" || f === "bottom" ? o - g * (c + y / 2 - g * l) : o + l
                    },
                    m = {
                        x: ne(r.center) && r.center.x !== void 0 ? r.center.x : p.x,
                        y: ne(r.center) && r.center.y !== void 0 ? r.center.y : p.y
                    },
                    _ = {
                        x: m.x + d.x,
                        y: m.y + d.y
                    };
                return h ? this.constrainTooltip(_, r, a) : _
            }
        }, {
            key: "getLabelPadding",
            value: function(r) {
                if (!r) return 0;
                var a = Array.isArray(r) ? r.map(function(i) {
                    return i.padding
                }) : [r.padding];
                return Math.max.apply(Math, IE(a).concat([0]))
            }
        }, {
            key: "getDimensions",
            value: function(r, a) {
                var i = r.orientation,
                    o = r.pointerLength,
                    u = r.pointerWidth,
                    l = r.flyoutHeight,
                    c = r.flyoutWidth,
                    f = r.flyoutPadding,
                    h = R(r.cornerRadius, r),
                    d = function() {
                        var v = a.height + f.top + f.bottom,
                            b = i === "top" || i === "bottom" ? 2 * h : 2 * h + u;
                        return Math.max(b, v)
                    },
                    y = function() {
                        var v = a.width + f.left + f.right,
                            b = i === "left" || i === "right" ? 2 * h + o : 2 * h;
                        return Math.max(b, v)
                    };
                return {
                    flyoutHeight: l ? R(l, r) : d(r, a, i),
                    flyoutWidth: c ? R(c, r) : y(r, a, i)
                }
            }
        }, {
            key: "getLabelProps",
            value: function(r, a) {
                var i = a.flyoutCenter,
                    o = a.style,
                    u = a.labelSize,
                    l = a.dy,
                    c = l === void 0 ? 0 : l,
                    f = a.dx,
                    h = f === void 0 ? 0 : f,
                    d = r.text,
                    y = r.datum,
                    v = r.activePoints,
                    b = r.labelComponent,
                    g = r.index,
                    p = r.flyoutPadding,
                    m = (Array.isArray(o) && o.length ? o[0].textAnchor : o.textAnchor) || "middle",
                    _ = function() {
                        if (!m || m === "middle") return i.x;
                        var w = m === "end" ? -1 : 1;
                        return i.x - w * (u.width / 2)
                    };
                return L({}, b.props, {
                    key: "".concat(this.id, "-label-").concat(g),
                    text: d,
                    datum: y,
                    activePoints: v,
                    textAnchor: m,
                    dy: c,
                    dx: h,
                    style: o,
                    x: _() + (p.left - p.right) / 2,
                    y: i.y + (p.top - p.bottom) / 2,
                    verticalAnchor: "middle",
                    angle: o.angle
                })
            }
        }, {
            key: "getPointerOrientation",
            value: function(r, a, i) {
                var o = {
                        bottom: a.y + i.height / 2,
                        top: a.y - i.height / 2,
                        left: a.x - i.width / 2,
                        right: a.x + i.width / 2
                    },
                    u = [{
                        side: "top",
                        val: o.top > r.y ? o.top - r.y : -1
                    }, {
                        side: "bottom",
                        val: o.bottom < r.y ? r.y - o.bottom : -1
                    }, {
                        side: "right",
                        val: o.right < r.x ? r.x - o.right : -1
                    }, {
                        side: "left",
                        val: o.left > r.x ? o.left - r.x : -1
                    }];
                return po(u, "val", "desc")[0].side
            }
        }, {
            key: "getFlyoutProps",
            value: function(r, a) {
                var i = a.flyoutDimensions,
                    o = a.flyoutStyle,
                    u = a.flyoutCenter,
                    l = r.x,
                    c = r.y,
                    f = r.dx,
                    h = r.dy,
                    d = r.datum,
                    y = r.activePoints,
                    v = r.index,
                    b = r.pointerLength,
                    g = r.pointerWidth,
                    p = r.cornerRadius,
                    m = r.events,
                    _ = r.flyoutComponent,
                    w = R(r.pointerOrientation, r);
                return L({}, _.props, {
                    x: l,
                    y: c,
                    dx: f,
                    dy: h,
                    datum: d,
                    activePoints: y,
                    index: v,
                    pointerLength: b,
                    pointerWidth: g,
                    cornerRadius: p,
                    events: m,
                    orientation: w || this.getPointerOrientation({
                        x: l,
                        y: c
                    }, u, i),
                    key: "".concat(this.id, "-tooltip-").concat(v),
                    width: i.width,
                    height: i.height,
                    style: o,
                    center: u
                })
            }
        }, {
            key: "renderTooltip",
            value: function(r) {
                var a = R(r.active, r),
                    i = r.renderInPortal;
                if (!a) return i ? A.createElement(ot, null, null) : null;
                var o = this.getEvaluatedProps(r),
                    u = o.flyoutComponent,
                    l = o.labelComponent,
                    c = o.groupComponent,
                    f = this.getCalculatedValues(o),
                    h = [A.cloneElement(u, this.getFlyoutProps(o, f)), A.cloneElement(l, this.getLabelProps(o, f))],
                    d = A.cloneElement(c, {
                        role: "presentation",
                        transform: f.transform
                    }, h);
                return i ? A.createElement(ot, null, d) : d
            }
        }, {
            key: "render",
            value: function() {
                var r = hn(this.props, UE, "tooltip");
                return this.renderTooltip(r)
            }
        }]), t
    }(A.Component);
Object.defineProperty(_n, "displayName", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "VictoryTooltip"
});
Object.defineProperty(_n, "role", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: "tooltip"
});
Object.defineProperty(_n, "propTypes", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        activateData: s.bool,
        active: s.oneOfType([s.bool, s.func]),
        activePoints: s.array,
        angle: s.number,
        center: s.shape({
            x: G,
            y: G
        }),
        centerOffset: s.shape({
            x: s.oneOfType([s.number, s.func]),
            y: s.oneOfType([s.number, s.func])
        }),
        constrainToVisibleArea: s.bool,
        cornerRadius: s.oneOfType([G, s.func]),
        data: s.array,
        datum: s.object,
        dx: s.oneOfType([s.number, s.func]),
        dy: s.oneOfType([s.number, s.func]),
        events: s.object,
        flyoutComponent: s.element,
        flyoutHeight: s.oneOfType([G, s.func]),
        flyoutPadding: s.oneOfType([s.func, s.number, s.shape({
            top: s.number,
            bottom: s.number,
            left: s.number,
            right: s.number
        })]),
        flyoutStyle: s.object,
        flyoutWidth: s.oneOfType([G, s.func]),
        groupComponent: s.element,
        height: s.number,
        horizontal: s.bool,
        id: s.oneOfType([s.number, s.string]),
        index: s.oneOfType([s.number, s.string]),
        labelComponent: s.element,
        orientation: s.oneOfType([s.oneOf(["top", "bottom", "left", "right"]), s.func]),
        pointerLength: s.oneOfType([G, s.func]),
        pointerOrientation: s.oneOfType([s.oneOf(["top", "bottom", "left", "right"]), s.func]),
        pointerWidth: s.oneOfType([G, s.func]),
        polar: s.bool,
        renderInPortal: s.bool,
        scale: s.shape({
            x: Ve,
            y: Ve
        }),
        style: s.oneOfType([s.object, s.array]),
        text: s.oneOfType([s.string, s.number, s.func, s.array]),
        theme: s.object,
        width: s.number,
        x: s.number,
        y: s.number
    }
});
Object.defineProperty(_n, "defaultProps", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: {
        active: !1,
        renderInPortal: !0,
        labelComponent: A.createElement(tf, null),
        flyoutComponent: A.createElement(kE, null),
        groupComponent: A.createElement("g", null)
    }
});
Object.defineProperty(_n, "defaultEvents", {
    configurable: !0,
    enumerable: !0,
    writable: !0,
    value: function(e) {
        var t = e.activateData ? [{
                target: "labels",
                mutation: function() {
                    return {
                        active: !0
                    }
                }
            }, {
                target: "data",
                mutation: function() {
                    return {
                        active: !0
                    }
                }
            }] : [{
                target: "labels",
                mutation: function() {
                    return {
                        active: !0
                    }
                }
            }],
            n = e.activateData ? [{
                target: "labels",
                mutation: function() {
                    return {
                        active: void 0
                    }
                }
            }, {
                target: "data",
                mutation: function() {
                    return {
                        active: void 0
                    }
                }
            }] : [{
                target: "labels",
                mutation: function() {
                    return {
                        active: void 0
                    }
                }
            }];
        return [{
            target: "data",
            eventHandlers: {
                onMouseOver: function() {
                    return t
                },
                onFocus: function() {
                    return t
                },
                onTouchStart: function() {
                    return t
                },
                onMouseOut: function() {
                    return n
                },
                onBlur: function() {
                    return n
                },
                onTouchEnd: function() {
                    return n
                }
            }
        }]
    }
});
var Zs = {},
    Qs = {
        exports: {}
    };
(function(e, t) {
    (function(n, r) {
        e.exports = r()
    })($n, function() {
        var n = Math.pow(2, -52),
            r = new Uint32Array(512),
            a = function(p) {
                var m = p.length >> 1;
                if (m > 0 && typeof p[0] != "number") throw new Error("Expected coords to contain numbers.");
                this.coords = p;
                var _ = Math.max(2 * m - 5, 0);
                this._triangles = new Uint32Array(_ * 3), this._halfedges = new Int32Array(_ * 3), this._hashSize = Math.ceil(Math.sqrt(m)), this._hullPrev = new Uint32Array(m), this._hullNext = new Uint32Array(m), this._hullTri = new Uint32Array(m), this._hullHash = new Int32Array(this._hashSize).fill(-1), this._ids = new Uint32Array(m), this._dists = new Float64Array(m), this.update()
            };
        a.from = function(p, m, _) {
            m === void 0 && (m = v), _ === void 0 && (_ = b);
            for (var w = p.length, O = new Float64Array(w * 2), T = 0; T < w; T++) {
                var x = p[T];
                O[2 * T] = m(x), O[2 * T + 1] = _(x)
            }
            return new a(O)
        }, a.prototype.update = function() {
            for (var p = this, m = p.coords, _ = p._hullPrev, w = p._hullNext, O = p._hullTri, T = p._hullHash, x = m.length >> 1, M = 1 / 0, C = 1 / 0, I = -1 / 0, $ = -1 / 0, E = 0; E < x; E++) {
                var k = m[2 * E],
                    F = m[2 * E + 1];
                k < M && (M = k), F < C && (C = F), k > I && (I = k), F > $ && ($ = F), this._ids[E] = E
            }
            for (var Z = (M + I) / 2, Y = (C + $) / 2, X = 1 / 0, K, z, te, Ee = 0; Ee < x; Ee++) {
                var ft = o(Z, Y, m[2 * Ee], m[2 * Ee + 1]);
                ft < X && (K = Ee, X = ft)
            }
            var De = m[2 * K],
                ce = m[2 * K + 1];
            X = 1 / 0;
            for (var Me = 0; Me < x; Me++)
                if (Me !== K) {
                    var rt = o(De, ce, m[2 * Me], m[2 * Me + 1]);
                    rt < X && rt > 0 && (z = Me, X = rt)
                }
            for (var Ce = m[2 * z], $e = m[2 * z + 1], N = 1 / 0, j = 0; j < x; j++)
                if (!(j === K || j === z)) {
                    var B = f(De, ce, Ce, $e, m[2 * j], m[2 * j + 1]);
                    B < N && (te = j, N = B)
                }
            var P = m[2 * te],
                ae = m[2 * te + 1];
            if (N === 1 / 0) {
                for (var q = 0; q < x; q++) this._dists[q] = m[2 * q] - m[0] || m[2 * q + 1] - m[1];
                d(this._ids, this._dists, 0, x - 1);
                for (var se = new Uint32Array(x), he = 0, Ne = 0, xn = -1 / 0; Ne < x; Ne++) {
                    var ja = this._ids[Ne];
                    this._dists[ja] > xn && (se[he++] = ja, xn = this._dists[ja])
                }
                this.hull = se.subarray(0, he), this.triangles = new Uint32Array(0), this.halfedges = new Uint32Array(0);
                return
            }
            if (l(De, ce, Ce, $e, P, ae)) {
                var Js = z,
                    e5 = Ce,
                    t5 = $e;
                z = te, Ce = P, $e = ae, te = Js, P = e5, ae = t5
            }
            var vr = h(De, ce, Ce, $e, P, ae);
            this._cx = vr.x, this._cy = vr.y;
            for (var wn = 0; wn < x; wn++) this._dists[wn] = o(m[2 * wn], m[2 * wn + 1], vr.x, vr.y);
            d(this._ids, this._dists, 0, x - 1), this._hullStart = K;
            var An = 3;
            w[K] = _[te] = z, w[z] = _[K] = te, w[te] = _[z] = K, O[K] = 0, O[z] = 1, O[te] = 2, T.fill(-1), T[this._hashKey(De, ce)] = K, T[this._hashKey(Ce, $e)] = z, T[this._hashKey(P, ae)] = te, this.trianglesLen = 0, this._addTriangle(K, z, te, -1, -1, -1);
            for (var gr = 0, su = void 0, hu = void 0; gr < this._ids.length; gr++) {
                var ye = this._ids[gr],
                    pt = m[2 * ye],
                    _t = m[2 * ye + 1];
                if (!(gr > 0 && Math.abs(pt - su) <= n && Math.abs(_t - hu) <= n) && (su = pt, hu = _t, !(ye === K || ye === z || ye === te))) {
                    for (var at = 0, Ra = 0, n5 = this._hashKey(pt, _t); Ra < this._hashSize && (at = T[(n5 + Ra) % this._hashSize], !(at !== -1 && at !== w[at])); Ra++);
                    at = _[at];
                    for (var Q = at, de = void 0; de = w[Q], !l(pt, _t, m[2 * Q], m[2 * Q + 1], m[2 * de], m[2 * de + 1]);)
                        if (Q = de, Q === at) {
                            Q = -1;
                            break
                        }
                    if (Q !== -1) {
                        var xt = this._addTriangle(Q, ye, w[Q], -1, -1, O[Q]);
                        O[ye] = this._legalize(xt + 2), O[Q] = xt, An++;
                        for (var Fe = w[Q]; de = w[Fe], l(pt, _t, m[2 * Fe], m[2 * Fe + 1], m[2 * de], m[2 * de + 1]);) xt = this._addTriangle(Fe, ye, de, O[ye], -1, O[Fe]), O[ye] = this._legalize(xt + 2), w[Fe] = Fe, An--, Fe = de;
                        if (Q === at)
                            for (; de = _[Q], l(pt, _t, m[2 * de], m[2 * de + 1], m[2 * Q], m[2 * Q + 1]);) xt = this._addTriangle(de, ye, Q, -1, O[Q], O[de]), this._legalize(xt + 2), O[de] = xt, w[Q] = Q, An--, Q = de;
                        this._hullStart = _[ye] = Q, w[Q] = _[Fe] = ye, w[ye] = Fe, T[this._hashKey(pt, _t)] = ye, T[this._hashKey(m[2 * Q], m[2 * Q + 1])] = Q
                    }
                }
            }
            this.hull = new Uint32Array(An);
            for (var Fa = 0, Wa = this._hullStart; Fa < An; Fa++) this.hull[Fa] = Wa, Wa = w[Wa];
            this.triangles = this._triangles.subarray(0, this.trianglesLen), this.halfedges = this._halfedges.subarray(0, this.trianglesLen)
        }, a.prototype._hashKey = function(p, m) {
            return Math.floor(i(p - this._cx, m - this._cy) * this._hashSize) % this._hashSize
        }, a.prototype._legalize = function(p) {
            for (var m = this, _ = m._triangles, w = m._halfedges, O = m.coords, T = 0, x = 0;;) {
                var M = w[p],
                    C = p - p % 3;
                if (x = C + (p + 2) % 3, M === -1) {
                    if (T === 0) break;
                    p = r[--T];
                    continue
                }
                var I = M - M % 3,
                    $ = C + (p + 1) % 3,
                    E = I + (M + 2) % 3,
                    k = _[x],
                    F = _[p],
                    Z = _[$],
                    Y = _[E],
                    X = c(O[2 * k], O[2 * k + 1], O[2 * F], O[2 * F + 1], O[2 * Z], O[2 * Z + 1], O[2 * Y], O[2 * Y + 1]);
                if (X) {
                    _[p] = Y, _[M] = k;
                    var K = w[E];
                    if (K === -1) {
                        var z = this._hullStart;
                        do {
                            if (this._hullTri[z] === E) {
                                this._hullTri[z] = p;
                                break
                            }
                            z = this._hullPrev[z]
                        } while (z !== this._hullStart)
                    }
                    this._link(p, K), this._link(M, w[x]), this._link(x, E);
                    var te = I + (M + 1) % 3;
                    T < r.length && (r[T++] = te)
                } else {
                    if (T === 0) break;
                    p = r[--T]
                }
            }
            return x
        }, a.prototype._link = function(p, m) {
            this._halfedges[p] = m, m !== -1 && (this._halfedges[m] = p)
        }, a.prototype._addTriangle = function(p, m, _, w, O, T) {
            var x = this.trianglesLen;
            return this._triangles[x] = p, this._triangles[x + 1] = m, this._triangles[x + 2] = _, this._link(x, w), this._link(x + 1, O), this._link(x + 2, T), this.trianglesLen += 3, x
        };

        function i(g, p) {
            var m = g / (Math.abs(g) + Math.abs(p));
            return (p > 0 ? 3 - m : 1 + m) / 4
        }

        function o(g, p, m, _) {
            var w = g - m,
                O = p - _;
            return w * w + O * O
        }

        function u(g, p, m, _, w, O) {
            var T = (_ - p) * (w - g),
                x = (m - g) * (O - p);
            return Math.abs(T - x) >= 33306690738754716e-32 * Math.abs(T + x) ? T - x : 0
        }

        function l(g, p, m, _, w, O) {
            var T = u(w, O, g, p, m, _) || u(g, p, m, _, w, O) || u(m, _, w, O, g, p);
            return T < 0
        }

        function c(g, p, m, _, w, O, T, x) {
            var M = g - T,
                C = p - x,
                I = m - T,
                $ = _ - x,
                E = w - T,
                k = O - x,
                F = M * M + C * C,
                Z = I * I + $ * $,
                Y = E * E + k * k;
            return M * ($ * Y - Z * k) - C * (I * Y - Z * E) + F * (I * k - $ * E) < 0
        }

        function f(g, p, m, _, w, O) {
            var T = m - g,
                x = _ - p,
                M = w - g,
                C = O - p,
                I = T * T + x * x,
                $ = M * M + C * C,
                E = .5 / (T * C - x * M),
                k = (C * I - x * $) * E,
                F = (T * $ - M * I) * E;
            return k * k + F * F
        }

        function h(g, p, m, _, w, O) {
            var T = m - g,
                x = _ - p,
                M = w - g,
                C = O - p,
                I = T * T + x * x,
                $ = M * M + C * C,
                E = .5 / (T * C - x * M),
                k = g + (C * I - x * $) * E,
                F = p + (T * $ - M * I) * E;
            return {
                x: k,
                y: F
            }
        }

        function d(g, p, m, _) {
            if (_ - m <= 20)
                for (var w = m + 1; w <= _; w++) {
                    for (var O = g[w], T = p[O], x = w - 1; x >= m && p[g[x]] > T;) g[x + 1] = g[x--];
                    g[x + 1] = O
                } else {
                    var M = m + _ >> 1,
                        C = m + 1,
                        I = _;
                    y(g, M, C), p[g[m]] > p[g[_]] && y(g, m, _), p[g[C]] > p[g[_]] && y(g, C, _), p[g[m]] > p[g[C]] && y(g, m, C);
                    for (var $ = g[C], E = p[$];;) {
                        do C++; while (p[g[C]] < E);
                        do I--; while (p[g[I]] > E);
                        if (I < C) break;
                        y(g, C, I)
                    }
                    g[m + 1] = g[I], g[I] = $, _ - C + 1 >= I - m ? (d(g, p, C, _), d(g, p, m, I - 1)) : (d(g, p, m, I - 1), d(g, p, C, _))
                }
        }

        function y(g, p, m) {
            var _ = g[p];
            g[p] = g[m], g[m] = _
        }

        function v(g) {
            return g[0]
        }

        function b(g) {
            return g[1]
        }
        return a
    })
})(Qs);
(function(e) {
    e.__esModule = !0, e.default = void 0;
    var t = n(Qs.exports);

    function n(c) {
        return c && c.__esModule ? c : {
            default: c
        }
    }

    function r(c) {
        return c[0]
    }

    function a(c) {
        return c[1]
    }

    function i(c) {
        for (var f = c.triangles, h = c.coords, d = 0; d < f.length; d += 3) {
            var y = 2 * f[d],
                v = 2 * f[d + 1],
                b = 2 * f[d + 2],
                g = (h[b] - h[y]) * (h[v + 1] - h[y + 1]) - (h[v] - h[y]) * (h[b + 1] - h[y + 1]);
            if (g > 1e-10) return !1
        }
        return !0
    }

    function o(c, f, h) {
        return [c + Math.sin(c + f) * h, f + Math.cos(c - f) * h]
    }

    function u(c, f, h, d) {
        for (var y = c.length, v = new Float64Array(y * 2), b = 0; b < y; ++b) {
            var g = c[b];
            v[b * 2] = f.call(d, g, b, c), v[b * 2 + 1] = h.call(d, g, b, c)
        }
        return v
    }
    var l = function() {
        function c(h) {
            var d = new t.default(h);
            this.inedges = new Int32Array(h.length / 2), this._hullIndex = new Int32Array(h.length / 2), this.points = d.coords, this._init(d)
        }
        var f = c.prototype;
        return f._init = function(d) {
            var y = d,
                v = this.points;
            if (y.hull && y.hull.length > 2 && i(y)) {
                this.collinear = Int32Array.from({
                    length: v.length / 2
                }, function(Y, X) {
                    return X
                }).sort(function(Y, X) {
                    return v[2 * Y] - v[2 * X] || v[2 * Y + 1] - v[2 * X + 1]
                });
                for (var b = this.collinear[0], g = this.collinear[this.collinear.length - 1], p = [v[2 * b], v[2 * b + 1], v[2 * g], v[2 * g + 1]], m = 1e-8 * Math.sqrt(Math.pow(p[3] - p[1], 2) + Math.pow(p[2] - p[0], 2)), _ = 0, w = v.length / 2; _ < w; ++_) {
                    var O = o(v[2 * _], v[2 * _ + 1], m);
                    v[2 * _] = O[0], v[2 * _ + 1] = O[1]
                }
                d = new t.default(v)
            }
            for (var T = this.halfedges = d.halfedges, x = this.hull = d.hull, M = this.triangles = d.triangles, C = this.inedges.fill(-1), I = this._hullIndex.fill(-1), $ = 0, E = T.length; $ < E; ++$) {
                var k = M[$ % 3 === 2 ? $ - 2 : $ + 1];
                (T[$] === -1 || C[k] === -1) && (C[k] = $)
            }
            for (var F = 0, Z = x.length; F < Z; ++F) I[x[F]] = F;
            x.length <= 2 && x.length > 0 && (this.triangles = new Int32Array(3).fill(-1), this.halfedges = new Int32Array(3).fill(-1), this.triangles[0] = x[0], this.triangles[1] = x[1], this.triangles[2] = x[1], C[x[0]] = 1, x.length === 2 && (C[x[1]] = 0))
        }, f.neighbors = function(d) {
            var y = [],
                v = this.inedges,
                b = this.hull,
                g = this._hullIndex,
                p = this.halfedges,
                m = this.triangles,
                _ = v[d];
            if (_ === -1) return y;
            var w = _,
                O = -1;
            do {
                if (O = m[w], y.push(O), w = w % 3 === 2 ? w - 2 : w + 1, m[w] !== d) break;
                if (w = p[w], w === -1) {
                    var T = b[(g[d] + 1) % b.length];
                    T !== O && y.push(T);
                    break
                }
            } while (w !== _);
            return y
        }, f.find = function(d, y, v) {
            if (v === void 0 && (v = 0), d = +d, d !== d || (y = +y, y !== y)) return -1;
            for (var b = v, g;
                (g = this._step(v, d, y)) >= 0 && g !== v && g !== b;) v = g;
            return g
        }, f._step = function(d, y, v) {
            var b = this.inedges,
                g = this.points;
            if (b[d] === -1 || !g.length) return (d + 1) % (g.length >> 1);
            for (var p = d, m = Math.pow(y - g[d * 2], 2) + Math.pow(v - g[d * 2 + 1], 2), O = this.neighbors(d), _ = Array.isArray(O), w = 0, O = _ ? O : O[Symbol.iterator]();;) {
                var T;
                if (_) {
                    if (w >= O.length) break;
                    T = O[w++]
                } else {
                    if (w = O.next(), w.done) break;
                    T = w.value
                }
                var x = T,
                    M = Math.pow(y - g[x * 2], 2) + Math.pow(v - g[x * 2 + 1], 2);
                M < m && (m = M, p = x)
            }
            return p
        }, c
    }();
    e.default = l, l.from = function(c, f, h, d) {
        return f === void 0 && (f = r), h === void 0 && (h = a), new l(u(c, f, h, d))
    }
})(Zs);
var HE = r5(Zs);

function Cn(e) {
    return qE(e) || GE(e) || BE()
}

function BE() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function GE(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function qE(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}
var Mr = {
        withinBounds: function(e, t) {
            var n = e.width,
                r = e.height,
                a = e.polar,
                i = e.origin,
                o = e.scale,
                u = Xe(e, "voronoiPadding"),
                l = t.x,
                c = t.y;
            if (a) {
                var f = Math.pow(l - i.x, 2) + Math.pow(c - i.y, 2),
                    h = Math.max.apply(Math, Cn(o.y.range()));
                return f < Math.pow(h, 2)
            } else return l >= u.left && l <= n - u.right && c >= u.top && c <= r - u.bottom
        },
        getDatasets: function(e) {
            var t = {
                    x: ut(e.domain.x),
                    y: ut(e.domain.y)
                },
                n = A.Children.toArray(e.children),
                r = function(o, u, l) {
                    var c = l && l.type && l.type.continuous,
                        f = l ? l.props && l.props.style : e.style;
                    return o.map(function(h, d) {
                        var y = Mo(h),
                            v = y.x,
                            b = y.y,
                            g = y.y0,
                            p = y.x0,
                            m = (+v + +p) / 2,
                            _ = (+b + +g) / 2;
                        return S({
                            _voronoiX: e.voronoiDimension === "y" ? t.x : m,
                            _voronoiY: e.voronoiDimension === "x" ? t.y : _,
                            eventKey: d,
                            childName: u,
                            continuous: c,
                            style: f
                        }, h)
                    })
                };
            if (e.data) return r(e.data);
            var a = function(o) {
                    var u = nt(o);
                    return Array.isArray(u) && u.length > 0 ? u : void 0
                },
                i = function(o, u) {
                    var l = o.props || {},
                        c = l.name || u,
                        f = e.voronoiBlacklist || [],
                        h = f.filter(bf),
                        d = f.filter($c),
                        y = d.some(function(g) {
                            return g.test(c)
                        });
                    if (!Ko(o) || vn(h, c) || y) return null;
                    var v = o.type && H(o.type.getData) ? o.type.getData : a,
                        b = v(o.props);
                    return b ? r(b, c, o) : null
                };
            return jt(n, i, e)
        },
        findPoints: function(e, t) {
            return e.filter(function(n) {
                return t._voronoiX === n._voronoiX && t._voronoiY === n._voronoiY
            })
        },
        withinRadius: function(e, t, n) {
            if (!e) return !1;
            if (!n) return !0;
            var r = t.x,
                a = t.y,
                i = Math.pow(r - e[0], 2) + Math.pow(a - e[1], 2);
            return i < Math.pow(n, 2)
        },
        getVoronoiPoints: function(e, t) {
            var n = this.getDatasets(e),
                r = n.map(function(l) {
                    var c = Ta(e, l),
                        f = c.x,
                        h = c.y;
                    return [f, h]
                }),
                a = HE.from(r),
                i = a.find(t.x, t.y),
                o = this.withinRadius(r[i], t, e.radius),
                u = o ? this.findPoints(n, n[i]) : [];
            return {
                points: u,
                index: i
            }
        },
        getActiveMutations: function(e, t) {
            var n = t.childName,
                r = t.continuous,
                a = e.activateData,
                i = e.activateLabels,
                o = e.labels;
            if (!a && !i) return [];
            var u = a ? ["data"] : [],
                l = o && !i ? u : u.concat("labels");
            return re(l) ? [] : l.map(function(c) {
                var f = r === !0 && c === "data" ? "all" : t.eventKey;
                return {
                    childName: n,
                    eventKey: f,
                    target: c,
                    mutation: function() {
                        return {
                            active: !0
                        }
                    }
                }
            })
        },
        getInactiveMutations: function(e, t) {
            var n = t.childName,
                r = t.continuous,
                a = e.activateData,
                i = e.activateLabels,
                o = e.labels;
            if (!a && !i) return [];
            var u = a ? ["data"] : [],
                l = o && !i ? u : u.concat("labels");
            return re(l) ? [] : l.map(function(c) {
                var f = r && c === "data" ? "all" : t.eventKey;
                return {
                    childName: n,
                    eventKey: f,
                    target: c,
                    mutation: function() {
                        return null
                    }
                }
            })
        },
        getParentMutation: function(e, t, n, r) {
            return [{
                target: "parent",
                eventKey: "parent",
                mutation: function() {
                    return {
                        activePoints: e,
                        mousePosition: t,
                        parentSVG: n,
                        vIndex: r
                    }
                }
            }]
        },
        onActivated: function(e, t) {
            H(e.onActivated) && e.onActivated(t, e)
        },
        onDeactivated: function(e, t) {
            H(e.onDeactivated) && e.onDeactivated(t, e)
        },
        onMouseLeave: function(e, t) {
            var n = this,
                r, a = t.activePoints || [];
            this.onDeactivated(t, a);
            var i = a.length ? a.map(function(o) {
                return n.getInactiveMutations(t, o)
            }) : [];
            return (r = this.getParentMutation([])).concat.apply(r, Cn(i))
        },
        onMouseMove: function(e, t) {
            var n = this,
                r = t.activePoints || [],
                a = t.parentSVG || ms(e),
                i = iO(e, a);
            if (!this.withinBounds(t, i)) {
                var o;
                this.onDeactivated(t, r);
                var u = r.length ? r.map(function(b) {
                    return n.getInactiveMutations(t, b)
                }) : [];
                return (o = this.getParentMutation([], i, a)).concat.apply(o, Cn(u))
            }
            var l = this.getVoronoiPoints(t, i),
                c = l.points,
                f = c === void 0 ? [] : c,
                h = l.index,
                d = this.getParentMutation(f, i, a, h);
            if (r.length && qe(f, r)) return d;
            this.onActivated(t, f), this.onDeactivated(t, r);
            var y = f.length ? f.map(function(b) {
                    return n.getActiveMutations(t, b)
                }) : [],
                v = r.length ? r.map(function(b) {
                    return n.getInactiveMutations(t, b)
                }) : [];
            return d.concat.apply(d, Cn(v).concat(Cn(y)))
        }
    },
    Cr = {
        onMouseLeave: Mr.onMouseLeave.bind(Mr),
        onMouseMove: SE(Mr.onMouseMove.bind(Mr), 32, {
            leading: !0,
            trailing: !1
        })
    };

function VE(e) {
    return XE(e) || KE(e) || YE()
}

function YE() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function KE(e) {
    if (Symbol.iterator in Object(e) || Object.prototype.toString.call(e) === "[object Arguments]") return Array.from(e)
}

function XE(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = new Array(e.length); t < e.length; t++) n[t] = e[t];
        return n
    }
}

function ZE(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        a, i;
    for (i = 0; i < r.length; i++) a = r[i], !(t.indexOf(a) >= 0) && (n[a] = e[a]);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for (i = 0; i < o.length; i++) a = o[i], !(t.indexOf(a) >= 0) && (!Object.prototype.propertyIsEnumerable.call(e, a) || (n[a] = e[a]))
    }
    return n
}

function si(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {},
            r = Object.keys(n);
        typeof Object.getOwnPropertySymbols == "function" && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(a) {
            return Object.getOwnPropertyDescriptor(n, a).enumerable
        }))), r.forEach(function(a) {
            QE(e, a, n[a])
        })
    }
    return e
}

function QE(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function JE(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function R0(e, t) {
    for (var n = 0; n < t.length; n++) {
        var r = t[n];
        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r)
    }
}

function eM(e, t, n) {
    return t && R0(e.prototype, t), n && R0(e, n), e
}

function tM(e, t) {
    return t && (typeof t == "object" || typeof t == "function") ? t : nM(e)
}

function nM(e) {
    if (e === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function rM(e, t) {
    if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}
var aM = function(e) {
        var t, n;
        return n = t = function(r) {
            rM(a, r);

            function a() {
                return JE(this, a), tM(this, (a.__proto__ || Object.getPrototypeOf(a)).apply(this, arguments))
            }
            return eM(a, [{
                key: "getDimension",
                value: function(o) {
                    var u = o.horizontal,
                        l = o.voronoiDimension;
                    return !u || !l ? l : l === "x" ? "y" : "x"
                }
            }, {
                key: "getPoint",
                value: function(o) {
                    var u = ["_x", "_x1", "_x0", "_y", "_y1", "_y0"];
                    return Xn(o, u)
                }
            }, {
                key: "getLabelPosition",
                value: function(o, u, l) {
                    var c = o.mousePosition,
                        f = o.mouseFollowTooltips,
                        h = this.getDimension(o),
                        d = this.getPoint(l[0]),
                        y = Ta(o, d),
                        v = f ? c : void 0;
                    if (!h || l.length < 2) return si({}, y, {
                        center: L({}, u.center, v)
                    });
                    var b = h === "y" ? c.x : y.x,
                        g = h === "x" ? c.y : y.y;
                    return v = f ? c : {
                        x: b,
                        y: g
                    }, {
                        x: b,
                        y: g,
                        center: L({}, u.center, v)
                    }
                }
            }, {
                key: "getStyle",
                value: function(o, u, l) {
                    var c = o.labels,
                        f = o.labelComponent,
                        h = o.theme,
                        d = f.props || {},
                        y = h && h.voronoi && h.voronoi.style ? h.voronoi.style : {},
                        v = l === "flyout" ? d.flyoutStyle : d.style;
                    return u.reduce(function(b, g, p) {
                        var m = L({}, d, {
                                datum: g,
                                active: !0
                            }),
                            _ = H(c) ? c(m) : void 0,
                            w = _ !== void 0 ? "".concat(_).split(`
`) : [],
                            O = g.style && g.style[l] || {},
                            T = Array.isArray(v) ? v[p] : v,
                            x = Ye(L({}, T, O, y[l]), m),
                            M = w.length ? w.map(function() {
                                return x
                            }) : [x];
                        return b = b.concat(M), b
                    }, [])
                }
            }, {
                key: "getDefaultLabelProps",
                value: function(o, u) {
                    var l = o.voronoiDimension,
                        c = o.horizontal,
                        f = o.mouseFollowTooltips,
                        h = this.getPoint(u[0]),
                        d = l && u.length > 1,
                        y = h._y1 !== void 0 ? h._y1 : h._y,
                        v = y < 0 ? "left" : "right",
                        b = y < 0 ? "bottom" : "top",
                        g = c ? v : b,
                        p = f ? void 0 : g;
                    return {
                        orientation: p,
                        pointerLength: d ? 0 : void 0,
                        constrainToVisibleArea: d || f ? !0 : void 0
                    }
                }
            }, {
                key: "getLabelProps",
                value: function(o, u) {
                    var l = o.labels,
                        c = o.scale,
                        f = o.labelComponent,
                        h = o.theme,
                        d = o.width,
                        y = o.height,
                        v = f.props || {},
                        b = u.reduce(function(x, M) {
                            var C = L({}, v, {
                                    datum: M,
                                    active: !0
                                }),
                                I = H(l) ? l(C) : null;
                            return I == null || (x = x.concat("".concat(I).split(`
`))), x
                        }, []),
                        g = u[0],
                        p = g.childName,
                        m = g.eventKey;
                    g.style, g.continuous;
                    var _ = ZE(g, ["childName", "eventKey", "style", "continuous"]),
                        w = o.name === p ? p : "".concat(o.name, "-").concat(p),
                        O = L({
                            key: "".concat(w, "-").concat(m, "-voronoi-tooltip"),
                            id: "".concat(w, "-").concat(m, "-voronoi-tooltip"),
                            active: !0,
                            renderInPortal: !1,
                            activePoints: u,
                            datum: _,
                            scale: c,
                            theme: h
                        }, v, {
                            text: b,
                            width: d,
                            height: y,
                            style: this.getStyle(o, u, "labels"),
                            flyoutStyle: this.getStyle(o, u, "flyout")[0]
                        }, this.getDefaultLabelProps(o, u)),
                        T = this.getLabelPosition(o, O, u);
                    return L({}, T, O)
                }
            }, {
                key: "getTooltip",
                value: function(o) {
                    var u = o.labels,
                        l = o.activePoints,
                        c = o.labelComponent;
                    if (!u) return null;
                    if (Array.isArray(l) && l.length) {
                        var f = this.getLabelProps(o, l),
                            h = f.text,
                            d = Array.isArray(h) ? h.filter(Boolean).length : h;
                        return d ? A.cloneElement(c, f) : null
                    } else return null
                }
            }, {
                key: "getChildren",
                value: function(o) {
                    return VE(A.Children.toArray(o.children)).concat([this.getTooltip(o)])
                }
            }]), a
        }(e), Object.defineProperty(t, "displayName", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: "VictoryVoronoiContainer"
        }), Object.defineProperty(t, "propTypes", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: si({}, Qe.propTypes, {
                activateData: s.bool,
                activateLabels: s.bool,
                disable: s.bool,
                labelComponent: s.element,
                labels: s.func,
                mouseFollowTooltips: s.bool,
                onActivated: s.func,
                onDeactivated: s.func,
                radius: s.number,
                voronoiBlacklist: s.arrayOf(s.oneOfType([s.string, j3])),
                voronoiDimension: s.oneOf(["x", "y"]),
                voronoiPadding: s.oneOfType([s.number, s.shape({
                    top: s.number,
                    bottom: s.number,
                    left: s.number,
                    right: s.number
                })])
            })
        }), Object.defineProperty(t, "defaultProps", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: si({}, Qe.defaultProps, {
                activateData: !0,
                activateLabels: !0,
                labelComponent: A.createElement(_n, null),
                voronoiPadding: 5
            })
        }), Object.defineProperty(t, "defaultEvents", {
            configurable: !0,
            enumerable: !0,
            writable: !0,
            value: function(r) {
                return [{
                    target: "parent",
                    eventHandlers: {
                        onMouseLeave: function(a, i) {
                            return r.disable ? {} : Cr.onMouseLeave(a, i)
                        },
                        onTouchCancel: function(a, i) {
                            return r.disable ? {} : Cr.onMouseLeave(a, i)
                        },
                        onMouseMove: function(a, i) {
                            return r.disable ? {} : Cr.onMouseMove(a, i)
                        },
                        onTouchMove: function(a, i) {
                            return r.disable ? {} : Cr.onMouseMove(a, i)
                        }
                    }
                }, {
                    target: "data",
                    eventHandlers: r.disable ? {} : {
                        onMouseOver: function() {
                            return null
                        },
                        onMouseOut: function() {
                            return null
                        },
                        onMouseMove: function() {
                            return null
                        }
                    }
                }]
            }
        }), n
    },
    iM = aM(Qe);
var oM = Mt(function() {
    const t = rr(),
        n = Ct.exports.useRef(null),
        [r, a] = Ct.exports.useState(null);

    function i() {
        const o = Ae.profits,
            u = o.length,
            l = Math.max(1, Math.floor(u / 50)),
            c = l * 50;
        return l > 1 ? o.slice(0, c).filter((f, h, d) => h % l === 0 || h === d.length - 1).concat(o.slice(c)) : o.filter((f, h) => h % l === 0 || h === u - 1)
    }
    return U("div", {
        ref: n,
        className: `${hM} m-item`,
        children: [U("div", {
            className: "title flex-center",
            children: [D("span", {
                children: t("common.bet")
            }), D("button", {
                className: "title-btn",
                onClick: Ae.clearData,
                children: D(Dr, {
                    name: "Clear"
                })
            })]
        }), U("div", {
            className: "chart-cont",
            children: [U("div", {
                className: "item-wrap wagered",
                children: [D("div", {
                    className: "item-label",
                    children: t("common.wagered")
                }), D(Bt, {
                    name: Ae.currencyName,
                    amount: Ae.wagered,
                    icon: !0,
                    showName: !1
                })]
            }), U("div", {
                className: "item-wrap profit",
                children: [D("div", {
                    className: "item-label",
                    children: t("common.profit")
                }), D(Bt, {
                    className: Ae.profit >= 0 ? "cl-success" : "cl-require",
                    name: Ae.currencyName,
                    amount: Ae.profit,
                    icon: !0,
                    showName: !1
                })]
            })]
        }), U("div", {
            className: "chart-wrap",
            children: [typeof r == "number" && D("div", {
                className: "tooltip-wrap",
                children: D(Bt, {
                    className: r >= 0 ? "cl-success" : "cl-require",
                    name: Ae.currencyName,
                    amount: r,
                    icon: !0
                })
            }), U(YS, {
                padding: {
                    top: 20,
                    left: 0,
                    right: 0,
                    bottom: 0
                },
                domainPadding: {
                    x: 0,
                    y: 5
                },
                animate: !0,
                data: i(),
                containerComponent: D(iM, {
                    voronoiBlacklist: ["positive"],
                    voronoiDimension: "x",
                    labels: ({
                        datum: o
                    }) => `${o._y.toFixed(9)}`,
                    onActivated: o => {
                        Ae.profits.length > 1 && a(o[0]._y)
                    },
                    events: {
                        onMouseOut: () => a(null)
                    },
                    labelComponent: D(uM, {})
                }),
                children: [D(N0, {
                    name: "positive",
                    style: lM,
                    interpolation: "catmullRom",
                    groupComponent: D(kt, {
                        clipPathComponent: D(fM, {})
                    })
                }), D(N0, {
                    name: "negative",
                    style: cM,
                    interpolation: "catmullRom",
                    groupComponent: D(kt, {
                        clipPathComponent: D(sM, {})
                    })
                })]
            })]
        }), U("div", {
            className: "bet-wrap",
            children: [U("div", {
                className: "bet-item win",
                children: [D("span", {
                    className: "txt ttc",
                    children: t("page.record.win").toLocaleLowerCase()
                }), D("span", {
                    className: `num ${Ae.winNum>0&&"cl-success"}`,
                    children: Ae.winNum
                })]
            }), U("div", {
                className: "bet-item lose",
                children: [D("span", {
                    className: "txt ttc",
                    children: t("page.record.lose").toLocaleLowerCase()
                }), D("span", {
                    className: `num ${Ae.lossNum<0&&"cl-require"}`,
                    children: Ae.lossNum
                })]
            })]
        })]
    })
});
const uM = function(t) {
        const {
            x: n,
            y: r,
            scale: a
        } = t;
        return U("g", {
            children: [D("line", {
                x1: n,
                y1: r,
                x2: n,
                y2: a.y(0),
                strokeDasharray: "5, 5",
                stroke: "#f5f6fa"
            }), D("circle", {
                cx: n,
                cy: r,
                r: 6,
                fill: "#f5f6fa"
            })]
        })
    },
    lM = {
        data: {
            stroke: "#5da000",
            strokeWidth: 5,
            fill: "#5da000",
            fillOpacity: .7,
            strokeLinecap: "round"
        }
    },
    cM = {
        data: {
            stroke: "#ed6300",
            strokeWidth: 5,
            fill: "#ed6300",
            fillOpacity: .7,
            strokeLinecap: "round"
        }
    },
    fM = e => D("defs", {
        children: D("clipPath", {
            id: e.clipId,
            children: D("rect", {
                x: "0",
                y: "0",
                width: "100%",
                height: e.scale.y(0)
            })
        })
    }),
    sM = e => D("defs", {
        children: D("clipPath", {
            id: e.clipId,
            children: D("rect", {
                x: "0",
                y: e.scale.y(0),
                width: "100%",
                height: "100%"
            })
        })
    });
la({
    cl1: [fe("#99a4b0", .6), fe("#5f6975", .8)],
    cl2: [fe("#99a4b0", .6), fe("#5f6975", .6)],
    cl3: ["#f5f6f7", "#31373d"]
});
const hM = "l1n7fkd0";
const dM = Mt(function({
        percent: t
    }) {
        const n = Ji.isDarken;
        return D("div", {
            className: a5(vM, "progress"),
            children: U("div", {
                className: "progress-cont",
                style: {
                    width: t + "%"
                },
                children: [D("img", {
                    className: "bar",
                    src: n ? za.progress_bar : za.progress_bar_w,
                    alt: ""
                }), D("img", {
                    className: "coin",
                    src: za.progress_coin,
                    alt: ""
                })]
            })
        })
    }),
    vM = "s1g8crrf";
var EM = Mt(function() {
    const t = rr(),
        [n, r] = Ct.exports.useState([{
            label: t("common.bet"),
            value: !0,
            disabled: !Ji.isMobile
        }, {
            label: t("page.contest.title"),
            value: !1,
            disabled: !1
        }, {
            label: t("wallet.bcd.dialog.treasure"),
            value: !1,
            disabled: !1
        }]);
    return U(Nr, {
        children: [D(gM, {
            options: n,
            setOptions: r
        }), n[0].value && D(oM, {}), n[1].value && D(mM, {}), n[2].value && D(yM, {})]
    })
});
const gM = Mt(function({
        options: t,
        setOptions: n
    }) {
        const [r, a] = Ct.exports.useState(!0), i = i5(() => {
            a(!0)
        }), o = {
            from: {
                y: -10,
                opacity: 0
            },
            enter: {
                y: 0,
                opacity: 1
            }
        };

        function u(c, f) {
            const h = t[f];
            h.disabled || (Ji.isMobile ? (t.map((d, y) => {
                d.disabled || (y === f ? d.value = !0 : d.value = !1)
            }), n([...t]), a(!0)) : (h.value = !c, n([...t])))
        }

        function l() {
            let c = t.filter(f => f.value);
            return c.length > 1 ? c.map(h => h.label).join("/") : c[0].label
        }
        return U("div", {
            className: wM,
            ref: i,
            children: [U("div", {
                className: `trigger flex-center m-item ${r?"fold":"unfold"}`,
                onClick: () => a(!r),
                children: [D("div", {
                    className: "current",
                    children: l()
                }), D(Dr, {
                    name: "Arrow"
                })]
            }), D(o5, {
                from: o.from,
                enter: o.enter,
                children: !r && D(u5.div, {
                    className: "options m-item",
                    children: t.map((c, f) => U("div", {
                        className: `item ${c.disabled?"disabled":""}`,
                        onClick: () => u(c.value, f),
                        children: [D("div", {
                            className: "checkbox",
                            children: c.value && D(Dr, {
                                name: "Check"
                            })
                        }), D("div", {
                            className: "item-value",
                            children: c.label
                        })]
                    }, f))
                })
            })]
        })
    }),
    yM = Mt(function() {
        const t = rr(),
            n = l5(),
            [r, a] = Ct.exports.useState(null),
            i = new c5(We.bonusAmount).div(We.bonusThreshold).mul(100).toFixed(2);
        return Ct.exports.useEffect(() => {
            We.init(!0).then(() => {
                a({
                    startTime: Date.now(),
                    endTime: Date.now() + 1e3 * 60
                })
            });
            let o = setInterval(() => {
                We.init(!0).then(() => {
                    a({
                        startTime: Date.now(),
                        endTime: Date.now() + 1e3 * 60
                    })
                })
            }, 1 * 60 * 1e3);
            return () => {
                clearInterval(o)
            }
        }, []), U("div", {
            className: `${xM} m-item`,
            children: [D("div", {
                className: "title",
                children: t("wallet.bcd.dialog.treasure")
            }), r && U("div", {
                className: "countdown-box",
                children: [U("div", {
                    className: "coin-amount",
                    children: [D(du, {
                        name: "BCD"
                    }), " ", Number(We.bonusAmount).toFixed(2)]
                }), D(f5, {
                    endTime: r.endTime,
                    startTime: r.startTime,
                    className: "circle"
                })]
            }), D(dM, {
                percent: i
            }), We.canReceive ? U(Nr, {
                children: [D("div", {
                    className: "claim-tit",
                    children: "Available to Claim"
                }), D(s5, {
                    className: "claim-btn",
                    onClick: We.claimBonus,
                    type: "conic4",
                    children: t("page.task.receive")
                })]
            }) : U("div", {
                className: "claim-desc",
                children: ["Minimum required  to claim:\xA0\xA0", D(du, {
                    name: "BCD"
                }), " ", We.bonusThreshold]
            }), D(g5, {
                className: "bcd-status",
                bonusAmount: We.bonusAmount,
                bonusThreshold: We.bonusThreshold
            }), U("div", {
                className: "detail",
                onClick: () => n("/bonus_dashboard"),
                children: [D("span", {
                    children: t("wallet.bcd.dialog.title")
                }), D(Dr, {
                    name: "Arrow"
                })]
            })]
        })
    }),
    mM = Mt(function() {
        const t = rr();
        Ct.exports.useEffect(() => {
            Ue.loadByContestType(Ue.contestType);
            let a = setInterval(() => {
                Ue.loadByContestType(Ue.contestType)
            }, 1 * 60 * 1e3);
            return () => {
                clearInterval(a)
            }
        }, []);
        const n = Ue.supportType.map(a => ({
                label: a,
                value: Mt(bM)
            })),
            r = n.findIndex(a => a.label === Ue.contestType);
        return n.length == 0 ? null : U("div", {
            className: `${_M} m-item`,
            children: [D("div", {
                className: "title",
                children: t("page.contest.title")
            }), D(h5, {
                className: "contest-tabs",
                value: r,
                tabs: n,
                onChange: a => Ue.loadByContestType(n[a].label)
            })]
        })
    });

function bM() {
    const e = rr(),
        {
            rank: t,
            wager: n,
            wagerCurrency: r,
            userBonusRate: a,
            activeList: i
        } = Ue;
    let o = 1;
    t == 0 ? o = a.length : t == 1 ? o = 1 : t <= a.length ? o = t - 1 : o = a.length;
    let u = 0,
        l = null;
    i.length > o - 1 && (l = i[o - 1]), l && (u = l.wager - n);

    function c() {
        if (i.length) {
            let f = i[t - 1];
            return f ? f.totalBonus : 0
        } else return 0
    }
    return U(Nr, {
        children: [U("div", {
            className: "time_ranking",
            children: [U("div", {
                className: "item endtime",
                children: [U("div", {
                    className: "item-label",
                    children: [Ue.contestType, " Contest end in"]
                }), D(d5, {
                    endTime: Ue.endTime.getTime(),
                    children: ({
                        days: f,
                        hours: h,
                        minutes: d,
                        seconds: y
                    }) => U("div", {
                        className: "countdown-wrap",
                        children: [f > 0 && D("div", {
                            className: "item",
                            children: D("div", {
                                className: "value",
                                children: yr(f)
                            })
                        }), D("div", {
                            className: "item",
                            children: D("div", {
                                className: "value",
                                children: yr(h)
                            })
                        }), D("div", {
                            className: "item",
                            children: D("div", {
                                className: "value",
                                children: yr(d)
                            })
                        }), f <= 0 && D("div", {
                            className: "item",
                            children: D("div", {
                                className: "value",
                                children: yr(y)
                            })
                        })]
                    })
                })]
            }), U("div", {
                className: "item ranking",
                children: [D("div", {
                    className: "item-label",
                    children: "Current Ranking"
                }), D("div", {
                    className: "item-value",
                    children: pM(t)
                })]
            })]
        }), D("div", {
            className: "target-box",
            children: U("div", {
                className: "target flex-center",
                children: [D("div", {
                    className: "dot"
                }), t !== 1 ? U(Nr, {
                    children: [U("div", {
                        children: ["Wager", " ", D(Bt, {
                            name: r,
                            amount: u,
                            showName: !1
                        }), " ", "more ", r, " to Reach"]
                    }), U("div", {
                        className: "spec",
                        children: ["TOP", o]
                    })]
                }) : D("div", {
                    children: "You are currently at 1st, well done!"
                })]
            })
        }), U("div", {
            className: "summary",
            children: [U("div", {
                className: "item wagered",
                children: [D("div", {
                    className: "item-label",
                    children: e("common.wagered")
                }), D(Bt, {
                    name: r,
                    amount: n,
                    icon: !0,
                    showName: !1
                })]
            }), U("div", {
                className: "item prize",
                children: [D("div", {
                    className: "item-label",
                    children: e("common.prize")
                }), D(Bt, {
                    name: r,
                    amount: c(),
                    icon: !0,
                    showName: !1
                })]
            })]
        })]
    })
}

function pM(e) {
    return e == 0 || e > 50 ? "50th+" : v5(e)
}
la({
    cl1: [fe("#99a4b0", .6), fe("#5f6975", .8)],
    cl2: ["#f5f6f7", "#31373d"],
    cl3: ["#353a43", "#dadde6"],
    cl4: ["#f5f6f7", fe("#31373d", .8)],
    gd1: ["linear-gradient(to bottom, #1e2024 -31%, #353a43 100%)", "linear-gradient(to bottom, #5f6975 -78%, rgba(95, 105, 117, 0) 100%)"]
});
const _M = "l1nrtaq9";
la({
    cl1: ["#99a4b0", fe("#5f6975", .8)],
    cl2: ["#fff", "#31373d"],
    cl3: ["#17181b", "#f5f6fa"],
    cl4: ["#1e2024", "#fff"],
    cl5: ["#fbcf12", "#fb9512"]
});
const xM = "lhadtgd";
la({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [fe("#f5f6f7", .6), fe("#5f6975", .35)],
    cl3: ["#1b1d21", "#fff"],
    cl4: [fe("#000000", .3), fe("#000000", .2)],
    cl5: [fe("#99a4b0", .1), fe("#5f6975", .1)],
    cl6: [fe("#99a4b0", .6), fe("#5f6975", .14)],
    cl7: [fe("#2d3035", .4), "#f6f7fa"]
});
const wM = "lkl4y2n";
export {
    EM as
    default
};
var G = Object.defineProperty,
    V = Object.defineProperties;
var D = Object.getOwnPropertyDescriptors;
var y = Object.getOwnPropertySymbols;
var T = Object.prototype.hasOwnProperty,
    B = Object.prototype.propertyIsEnumerable;
var x = (t, e, s) => e in t ? G(t, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[e] = s,
    w = (t, e) => {
        for (var s in e || (e = {})) T.call(e, s) && x(t, s, e[s]);
        if (y)
            for (var s of y(e)) B.call(e, s) && x(t, s, e[s]);
        return t
    },
    C = (t, e) => V(t, D(e));
import {
    u as _,
    a as l,
    e as E,
    ax as $,
    j as r,
    F as P,
    b9 as k,
    $ as b,
    ao as I,
    r as m,
    x as N,
    d as z,
    s as p,
    G as A,
    bZ as F,
    bK as W,
    a5 as M,
    b as Z,
    y as q,
    t as L,
    q as v,
    a2 as O,
    cj as H
} from "./index.28e31dff.js";
import {
    s as f
} from "./slotsUtils.a0534c25.js";
import {
    G as K
} from "./GameGridList.b3c3af9c.js";
var R = "/assets/allgame.a1f3f606.png",
    U = "/assets/feature.8a669ce8.png",
    J = "/assets/hotgame.fa6f745d.png",
    Q = "/assets/recommended.d5c73af1.png",
    X = "/assets/trending.1aad83c8.png";
const d = {
    allgame: R,
    feature: U,
    hotgame: J,
    recommended: Q,
    trending: X
};

function Y(t) {
    return t ? "Live Casino" : "Slots"
}

function tt(t) {
    const e = _(),
        s = [{
            tit: e("game.slots.recommend_list"),
            icon: l("img", {
                className: "slots-img",
                alt: "icon",
                src: d.recommended
            }),
            url: "/home/game/recommendList/"
        }, {
            tit: e("game.slots.feature_games"),
            icon: l("img", {
                className: "slots-img",
                alt: "icon",
                src: d.feature
            }),
            url: "/home/game/buyInList/"
        }, {
            tit: e("game.slots.trending_games"),
            icon: l("img", {
                className: "slots-img",
                alt: "icon",
                src: d.trending
            }),
            url: "/home/game/newestList/"
        }, {
            tit: e("game.slots.hot_list"),
            icon: l("img", {
                className: "slots-img",
                alt: "icon",
                src: d.hotgame
            }),
            url: "/home/game/hotList/"
        }];
    return t ? [s[0], s[2], s[3]] : s
}
const et = ({
        live: t,
        list: e,
        active: s
    }) => {
        const o = e.map(i => ({
                label: i.providerName,
                value: i
            })),
            a = E();
        return l($, {
            className: at,
            options: o,
            value: s,
            onChange: i => a(`/provider/${i.providerName}/${t?"Live Casino":"Slots"}/`),
            renderLabel: i => l("div", {
                className: "provider-select-label provider-label",
                children: i.label
            }),
            renderOption: i => r(P, {
                children: [r("div", {
                    className: "provider-label",
                    children: [i.value.providerName, " "]
                }), i.value.gameNum > 0 && l("div", {
                    className: "game-num",
                    children: i.value.gameNum
                })]
            })
        })
    },
    at = "swvi1rr";
const st = k((t, e, s, o, a) => b.get(a, {
        params: {
            page: 1,
            pageSize: 20,
            restriction: e,
            lang: t,
            device: s,
            categoryId: o
        }
    }), (t, e, s, o, a) => t + s + e + o + a),
    lt = ({
        url: t,
        tit: e,
        live: s,
        sliderName: o,
        icon: a
    }) => {
        const [i, n] = I({
            list: [],
            loading: !0,
            page: 1,
            pageSize: 20,
            total: 0,
            showTotal: 0
        });
        return m.exports.useEffect(() => {
            st(N.lng, z.areaCode, p.isMobile ? 1 : 2, s, t).then(c => {
                n({
                    list: c.list,
                    loading: !1,
                    total: c.total,
                    showTotal: c.list.length
                })
            }).catch(A)
        }, []), l(F, {
            className: it,
            sliderClassName: o,
            list: i.list,
            isSlots: !0,
            clickSource: f.getClickSource(),
            children: r("div", {
                className: "swrap-header",
                children: [r("div", {
                    className: "tit",
                    children: [a, l("div", {
                        className: "cont",
                        children: e
                    }), i.total > 0 && l("span", {
                        className: "total",
                        children: i.showTotal
                    })]
                }), l(W, {
                    name: o
                })]
            })
        })
    },
    it = "s1b4c2rq";
const ot = M.memo(({
        tit: t,
        live: e,
        loading: s,
        providerId: o
    }) => {
        const [a, i] = I({
            list: [],
            inited: !1,
            page: 1,
            pageSize: 20,
            total: 0,
            totalPage: 0,
            btnloading: !0,
            sortby: 3,
            num: p.isMobile ? 2 : 6
        }), n = _();
        m.exports.useEffect(() => {
            if (!s) return;
            i({
                btnloading: !0
            });
            let g = {
                    page: a.page,
                    pageSize: a.pageSize,
                    restriction: z.areaCode,
                    lang: N.lng,
                    device: p.isMobile ? 1 : 2,
                    categoryId: e,
                    sortBy: a.sortby
                },
                S = "/home/game/categoryList/";
            o && (S = "/home/game/providerList/", Object.assign(g, {
                providerId: o
            })), b.get(S, {
                cache: !0,
                params: g
            }).then(u => {
                const j = a.page === 1 ? u.list : a.list.concat(u.list);
                i({
                    list: j,
                    inited: !0,
                    total: u.total,
                    btnloading: !1,
                    totalPage: u.totalPage
                })
            }).catch(A)
        }, [s, a.page, a.sortby]);
        let c = a.list.length > a.num && a.page < a.totalPage ? [...a.list].splice(a.list.length % a.num) : a.list;
        return r("div", {
            className: ct,
            children: [r("div", {
                className: mt,
                children: [r("div", {
                    className: "tit",
                    children: [l("img", {
                        className: "all-slots-img",
                        alt: "icon",
                        src: d.allgame
                    }), l("div", {
                        className: "cont",
                        children: t
                    }), l("span", {
                        className: "total",
                        children: a.total
                    })]
                }), r("div", {
                    className: "sort",
                    children: [n("common.sort_by"), ":", l("button", {
                        disabled: a.sortby === 0 || a.btnloading,
                        onClick: () => i({
                            sortby: 0,
                            page: 1
                        }),
                        className: a.sortby === 0 ? "active" : "",
                        children: "A to Z"
                    }), l("button", {
                        disabled: a.sortby === 1 || a.btnloading,
                        onClick: () => i({
                            sortby: 1,
                            page: 1
                        }),
                        className: a.sortby === 1 ? "active" : "",
                        children: "Z to A"
                    })]
                })]
            }), l(K, {
                onCallBack: g => i({
                    num: g
                }),
                isSlots: !0,
                clickSource: f.getClickSource(),
                list: c
            }), r("div", {
                className: dt,
                children: [l(rt, {
                    current: c.length,
                    total: a.total
                }), l(Z, {
                    type: "gray",
                    disabled: a.page >= a.totalPage,
                    loading: a.btnloading,
                    className: "load-btn",
                    onClick: () => i({
                        page: a.page + 1
                    }),
                    children: n("common.load_more")
                })]
            })]
        })
    }),
    rt = t => {
        const e = (t.total === 0 ? 0 : new q(t.current).div(t.total).mul(100).toFixed(0)) + "%";
        return r("div", {
            className: nt,
            children: [l("span", {
                className: "current",
                children: t.current
            }), "\xA0 / \xA0", l("span", {
                children: t.total
            }), l("div", {
                className: "progress",
                children: l("div", {
                    style: {
                        width: e
                    },
                    className: "green"
                })
            }), e]
        })
    };
L({
    cl1: ["#fff", "#000"],
    cl2: ["#31343c", v("#e9eaf2", .6)]
});
const nt = "l1uegn85",
    ct = "a1drlziv";
L({
    cl1: ["#31343a", v("#6b7180", .6)],
    cl2: [v("#99a4b0", .6), "#f5f6f7"]
});
const dt = "b1bu45hm",
    mt = "sxmibvi";
const h = {
        gameNum: 0,
        providerName: N.t("common.all_proviers"),
        providerId: void 0,
        isAll: !0,
        path: "/all/"
    },
    gt = k((t, e, s) => b.get("/home/provider/list/", {
        cache: !0,
        params: {
            categoryId: t,
            device: e,
            live: s
        }
    }), (t, e, s) => t + e + s),
    Lt = ({
        live: t
    }) => {
        const [e, s] = m.exports.useState({
            list: null,
            allLoading: !1
        });
        let {
            provider: o
        } = O();
        o = o || "";
        let a = h;
        return m.exports.useEffect(() => {
            gt(t, p.isMobile ? 1 : 2, t).then(i => {
                h.path = t ? "live-list/all" : "/slots-list/all", i.find(n => n.isAll) || i.unshift(h), s({
                    list: i,
                    allLoading: !0
                })
            })
        }, [t]), e.list && (a = e.list.find(i => i.providerName === o) || h), r("div", {
            className: ht,
            id: "slots",
            children: [r("div", {
                className: pt,
                children: [l(H, {
                    list: [{
                        label: Y(t === 4),
                        path: f.getSlotsListPath(t, a.providerName)
                    }]
                }), e.list && l(et, {
                    live: f.getIsLive(t),
                    active: a,
                    list: e.list
                })]
            }), o === "all" && l(ut, {
                live: t
            }), l(ot, {
                live: t,
                tit: a.providerName,
                providerId: a.providerId,
                loading: e.allLoading
            }, a.providerId)]
        }, t + o)
    },
    ut = M.memo(({
        live: t
    }) => {
        const e = tt(t === 4);
        return l(P, {
            children: e.map((s, o) => m.exports.createElement(lt, C(w({}, s), {
                tit: s.tit,
                sliderName: "slots" + o,
                key: s.tit,
                live: t
            })))
        })
    }),
    ht = "l1g6esah";
L({
    cl1: [v("#31343c", .5), "#fff"]
});
const pt = "t4w33jd";
export {
    Lt as
    default
};
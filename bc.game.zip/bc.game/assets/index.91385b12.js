var fe = Object.defineProperty;
var _ = Object.getOwnPropertySymbols;
var pe = Object.prototype.hasOwnProperty,
    ye = Object.prototype.propertyIsEnumerable;
var E = (i, t, e) => t in i ? fe(i, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : i[t] = e,
    ee = (i, t) => {
        for (var e in t || (t = {})) pe.call(t, e) && E(i, e, t[e]);
        if (_)
            for (var e of _(t)) ye.call(t, e) && E(i, e, t[e]);
        return i
    };
var o = (i, t, e) => (E(i, typeof t != "symbol" ? t + "" : t, e), e);
import {
    et as ge,
    o as I,
    u as F,
    J as be,
    j as u,
    l as X,
    a as s,
    ea as we,
    an as ve,
    du as O,
    r as S,
    dv as ke,
    y as te,
    s as T,
    a$ as xe,
    t as Se,
    q as ie,
    dj as Ce,
    F as q,
    dk as Ie,
    dl as Be,
    b as Oe,
    G as se,
    e9 as ne,
    a5 as Z,
    dx as re,
    dy as Ae,
    dz as Ne,
    dG as Me,
    dY as Te,
    dC as Fe,
    dZ as Ge,
    dD as De,
    dE as Pe,
    dp as B,
    bN as We,
    d_ as je,
    ba as ze,
    bb as Y,
    bc as Re,
    am as ae
} from "./index.28e31dff.js";
import {
    s as R
} from "./index.dd8128e8.js";
import {
    G as Le,
    l as $e,
    C as K,
    k as He,
    T as Ve,
    L as Ee,
    c as j,
    j as Ye
} from "./usePixiGsap.bf451f35.js";
import {
    s as N
} from "./index.d71e4992.js";
import {
    G as m
} from "./index.06a59a68.js";

function Ue(i, t) {
    for (var e = -1, n = i.length, r = 0, l = []; ++e < n;) {
        var h = i[e],
            f = t ? t(h) : h;
        if (!e || !ge(f, y)) {
            var y = f;
            l[r++] = h === 0 ? 0 : h
        }
    }
    return l
}

function oe(i) {
    return i && i.length ? Ue(i) : []
}
const M = {
        easeOutSine: N(.39, .575, .565, 1),
        easeInSine: N(.47, 0, .745, .715),
        easeOutExpo: N(.19, 1, .22, 1),
        easeInBack: N(.6, -.28, .735, .045),
        easeOutBack: N(.175, .885, .32, 1.275)
    },
    U = [16186367, 7192575, 5741325, 16362775, 9657055, 16731471];

function Q(i, t) {
    return i > 10 ? U[U.length - 1] : U[t.indexOf(i)]
}
const a = class extends Le {
    constructor(e) {
        super();
        o(this, "wheel");
        o(this, "prevArc", 0);
        o(this, "targetArc", 0);
        o(this, "gradientTexture");
        o(this, "spinResolve", () => {});
        this.wheel = e, this.gradientTexture = this.gradient("#ffffff", "#ff0000"), this.pivot.set(a.radius), this.drawRing(this.wheel.segment, this.wheel.risk), this.on("removed", () => {
            this.spinResolve()
        })
    }
    update(e) {
        return this.rotation = this.prevArc + a.ease(e) * (this.targetArc - this.prevArc)
    }
    reset() {
        this.drawRing(this.wheel.segment, this.wheel.risk)
    }
    spin(e) {
        let n = this.rotation % (Math.PI * 2);
        this.rotation = n, this.prevArc = n, this.targetArc = a.spinArc + e
    }
    drawRing(e, n) {
        this.cacheAsBitmap = !1, this.clear();
        let r = a.colors[this.wheel.theme],
            l = 2 * Math.PI / e,
            h = .5 * Math.PI;
        this.lineStyle(a.arcWidth + 2, 0, .1), this.beginFill(r[3], 1), this.arc(a.radius, a.radius, a.radius - a.arcWidth * .5, 0, 2 * Math.PI), this.endFill(), this.beginFill(r[2], 1), this.lineStyle(0, 16777215);
        for (let d = 0; d < e; d++) {
            let c = d * l - h,
                p = (d + 1) * l - h,
                x = a.radius + Math.cos(c) * a.radius * .2,
                A = a.radius + Math.sin(c) * a.radius * .2,
                H = a.radius + Math.cos(c) * a.shadowRadius,
                V = a.radius + Math.sin(c) * a.shadowRadius;
            d == 0 && this.moveTo(x, A), d % 2 == 0 ? (this.lineTo(H, V), this.arc(a.radius, a.radius, a.shadowRadius, c, p)) : (this.lineTo(x, A), this.arc(a.radius, a.radius, a.radius * .2, c, p))
        }
        this.endFill(), this.lineStyle(0, 3355443, .2), this.beginFill(r[1]), this.drawCircle(a.radius, a.radius, a.innerRadius), this.beginFill(r[0]), this.drawCircle(a.radius, a.radius, a.innerRadius * .9), this.endFill(), this.lineStyle(a.arcWidth, 16777215);
        let f = this.wheel.payout[n][e],
            y = oe(f.concat().sort());
        for (let d = 0; d < e; d++) {
            let c = -d * l - h,
                p = -(d + 1) * l - h;
            this.lineStyle(a.arcWidth, Q(f[d], y)), this.arc(a.radius, a.radius, a.radius - a.arcWidth * .5, c, p, !0)
        }
        this.lineStyle(a.arcWidth * .5, 0, .2), this.drawCircle(a.radius, a.radius, a.radius - a.arcWidth * .75);
        for (let d = 0; d < e; d++) {
            let c = -(d + 1) * l - h,
                p = Math.cos(c),
                x = Math.sin(c),
                A = a.radius + p * (a.radius - a.arcWidth),
                H = a.radius + x * (a.radius - a.arcWidth),
                V = a.radius + p * a.radius,
                me = a.radius + x * a.radius;
            this.lineStyle(3, 16777215, .2), this.moveTo(A, H), this.lineTo(V, me), this.endFill()
        }
        this.cacheAsBitmap = !0
    }
    gradient(e, n) {
        const r = document.createElement("canvas");
        r.width = r.height = a.radius * 2;
        const l = r.getContext("2d"),
            h = l.createRadialGradient(a.radius, a.radius, 0, a.radius, a.radius, a.radius);
        return h.addColorStop(0, e), h.addColorStop(1, n), l.fillStyle = h, l.fillRect(0, 0, a.radius * 2, a.radius * 2), $e.from(r)
    }
};
let b = a;
o(b, "spinArc", Math.PI * 2 * 10), o(b, "ease", N(0, .8, 0, 1)), o(b, "radius", 400), o(b, "arcWidth", 400 * .0875), o(b, "shadowRadius", 400 * .92), o(b, "innerRadius", 400 * .33), o(b, "colors", {
    white: [16119548, 15001579, 16119548, 15330034],
    black: [1974308, 1513499, 2369067, 1974052]
});
const W = class extends K {
    constructor(e) {
        super();
        o(this, "fram", 0);
        o(this, "isShow", !1);
        o(this, "text");
        o(this, "textStyle", new He({
            fontSize: 70,
            fill: 16777215,
            fontFamily: "Montserrat",
            fontWeight: "bold"
        }));
        o(this, "wheel");
        this.wheel = e, this.drawText(), this.alpha = 0, this.scale.x = this.scale.y = .5
    }
    update() {
        if (this.fram <= 0) return;
        this.fram--;
        let e = 1 - this.fram / W.animateFrams;
        this.isShow ? this.showAnimate(e) : this.hideAnimate(e)
    }
    showAnimate(e) {
        this.alpha = M.easeInSine(e), this.scale.set(M.easeOutBack(e) * .5 + .5)
    }
    hideAnimate(e) {
        this.alpha = 1 - M.easeInSine(e), this.scale.set(1 - M.easeInBack(e) * .5)
    }
    drawText() {
        this.text = new Ve("", this.textStyle), this.text.anchor.x = this.text.anchor.y = .5, this.addChild(this.text)
    }
    show(e) {
        e > 1 ? this.wheel.playSound("sound_win") : this.wheel.playSound("sound_lose");
        let n = this.wheel.payout[this.wheel.risk][this.wheel.segment],
            r = oe(n.concat().sort()),
            l = Q(e, r);
        this.text.text = `${e.toFixed(2)}\xD7`, this.textStyle.fill = l, !this.isShow && (this.isShow = !0, this.fram = W.animateFrams)
    }
    hide() {
        !this.isShow || (this.isShow = !1, this.fram = W.animateFrams)
    }
};
let z = W;
o(z, "animateFrams", .5 * 60);
var qe = "/assets/peg.1c224ce6.png",
    Je = "/assets/eye.18b56bbd.png",
    Xe = "/assets/tongue.11757d1c.png";
const G = {
        peg: qe,
        eye: Je,
        tongue: Xe
    },
    D = {};

function Ze(i) {
    return new Promise(t => {
        new Ee().add(Object.values(G)).load((n, r) => {
            Object.assign(D, r), t(r)
        })
    })
}
const g = class extends K {
    constructor(e) {
        super();
        o(this, "fram", 0);
        o(this, "eye_fram", 0);
        o(this, "wheel");
        o(this, "head");
        o(this, "eye_left");
        o(this, "eye_right");
        o(this, "tongue");
        this.wheel = e, this.pivot.y = g.pinCenter, this.width = g.width, this.height = g.height, this.scale.set(.5), this.init()
    }
    init() {
        this.head = new j(D[G.peg].texture), this.head.anchor.x = .5, this.addChild(this.head), this.eye_left = new j(D[G.eye].texture), this.eye_left.anchor.x = this.eye_left.anchor.y = .5, this.eye_left.position.y = 75, this.eye_left.position.x = -40, this.eye_left.pivot.x = -18, this.addChild(this.eye_left), this.eye_right = new j(D[G.eye].texture), this.eye_right.anchor.x = this.eye_right.anchor.y = .5, this.eye_right.position.y = 75, this.eye_right.position.x = 40, this.eye_right.pivot.x = -18, this.eye_right.rotation = Math.PI, this.addChild(this.eye_right), this.tongue = new j(D[G.tongue].texture), this.tongue.visible = !1, this.tongue.anchor.set(.5), this.tongue.position.y = 170, this.addChild(this.tongue)
    }
    update() {
        this.eye_fram > 0 && (this.eye_fram--, this.eye_left.rotation = 4 * Math.PI * M.easeOutBack((g.eyeAnimateFrame - this.eye_fram) / g.eyeAnimateFrame), this.eye_right.rotation = this.eye_left.rotation + Math.PI, this.eye_fram == 0 && (this.tongue.visible = !1)), this.fram > 0 && (this.fram == g.animateFram && this.actionDizziness(), this.fram--, this.rotation = (1 - M.easeOutSine((g.animateFram - this.fram) / g.animateFram)) * g.animateArc)
    }
    actionDial() {
        this.fram = g.animateFram, this.wheel.playSound("sound_tick")
    }
    actionDizziness() {
        this.tongue.visible = !0, this.eye_fram = g.eyeAnimateFrame
    }
};
let w = g;
o(w, "pinCenter", 43), o(w, "width", 174), o(w, "height", 232), o(w, "animateFram", .2 * 60), o(w, "eyeAnimateFrame", 4 * 60), o(w, "animateArc", -40 * Math.PI / 180);
const v = class extends Ye {
    constructor(e, n, r, l, h) {
        super();
        o(this, "theme", "white");
        o(this, "risk");
        o(this, "segment");
        o(this, "payout");
        o(this, "inited", !1);
        o(this, "segUnit", 0);
        o(this, "segCurrent", 0);
        o(this, "ring");
        o(this, "result");
        o(this, "peg");
        o(this, "fram", 0);
        o(this, "spinResolve", () => {});
        this.segment = e, this.segUnit = Math.PI * 2 / e, this.risk = n, this.payout = r, this.theme = l, this.resize(h), this.init()
    }
    update() {
        if (!this.inited || (this.result.update(), this.peg.update(), this.fram <= 0)) return;
        this.fram--, this.ring.update((v.animateFram - this.fram) / v.animateFram), this.fram == 0 && this.spinResolve();
        const e = Math.ceil(this.ring.rotation / this.segUnit);
        e > this.segCurrent && this.peg.actionDial(), this.segCurrent = e
    }
    resize(e) {
        this.renderer.resize(e, e), this.stage.scale.set(e / v.size)
    }
    render() {
        this.update(), super.render()
    }
    destroy() {
        super.destroy(), this.spinResolve()
    }
    async init() {
        await Ze(this.loader), this.inited = !0;
        const e = new K;
        e.position.x = e.position.y = v.size * .5, this.stage.addChild(e), this.ring = new b(this);
        const n = (v.size - this.ring.height) / 2;
        this.ring.position.y = n, e.addChild(this.ring), this.peg = new w(this), this.peg.position.y = -v.size * .41, e.addChild(this.peg), this.result = new z(this), this.result.position.y = n, e.addChild(this.result)
    }
    resetRing(e, n, r) {
        this.theme = r, this.segment = e, this.segUnit = Math.PI * 2 / e, this.risk = n, this.inited && this.ring.reset()
    }
    async spin(e) {
        let n, r, l = [];
        this.payout[this.risk][this.segment].forEach((f, y) => f == e && l.push(y)), this.segCurrent = Math.ceil(this.ring.rotation % (Math.PI * 2) / this.segUnit), r = l[Math.round(Math.random() * 1e5) % l.length], n = (r + Math.random() * .6 + .2) * this.segUnit, this.fram = v.animateFram, this.ring.spin(n), this.result.hide(), await new Promise(f => this.spinResolve = f), this.result.show(e)
    }
    playSound(e) {
        $.sounds.playSound(e)
    }
};
let P = v;
o(P, "animateFram", 5 * 60), o(P, "size", 900);
const Ke = I(i => {
        const t = F(),
            e = be.dict[i.currencyName],
            n = e ? e.precision : 0,
            r = () => ((i.active * 2 + 1) / (i.total * 2) * 100).toFixed(2) + "%";
        return u("div", {
            className: X(Qe, "detail-panel"),
            children: [s(we, {
                label: t("common.win_amount"),
                size: "small",
                currencyName: i.currencyName,
                value: i.winAmount,
                disabled: !0,
                onChange: () => {},
                precision: n,
                className: "detail__item"
            }), s(ve, {
                label: t("common.chance"),
                size: "small",
                disabled: !0,
                className: "detail__item",
                children: s("div", {
                    className: "input-control",
                    children: s("input", {
                        value: i.changce,
                        disabled: !0
                    })
                })
            }), s("div", {
                className: "arr-down",
                style: {
                    left: r()
                }
            })]
        })
    }),
    Qe = "d96stee";
const le = I(({
        payouts: i,
        curactive: t
    }) => {
        const e = O(),
            n = typeof t == "number",
            [r, l] = S.exports.useState({
                active: t || -1,
                winAmount: 0,
                changce: "0",
                total: 3,
                currencyName: e.currencyName
            }),
            [h, f] = S.exports.useState(-1),
            y = c => {
                let p = i.map(A => A[0]);
                return `#${Q(c,p).toString(16)}`
            },
            d = c => {
                if (n) return;
                let p = new te(i[c][0]),
                    x = Math.round(i[c][1] * e.segment);
                l({
                    active: c,
                    winAmount: new te(e.amount).mul(p).toNumber(),
                    changce: `${x} / ${e.segment}`,
                    total: i.length,
                    currencyName: e.currencyName
                }), f(c)
            };
        return S.exports.useEffect(() => {
            setTimeout(() => {
                e.odds = -1
            }, 3e3)
        }, [e.odds]), u("div", {
            className: X(_e, "wheel-result"),
            children: [h > -1 && s(Ke, ee({}, r)), i.map((c, p) => u("div", {
                className: c[0] === t ? "item active" : "item",
                onMouseEnter: () => d(p),
                onMouseLeave: () => f(-1),
                children: [s("div", {
                    className: "bg",
                    style: {
                        backgroundColor: y(c[0])
                    }
                }), u("div", {
                    className: "text",
                    children: [c[0].toFixed(2), "\xD7"]
                }), i.length - 1 === p && !n && c[0] === e.odds && !e.isBetting && s(ke, {
                    className: "winner"
                })]
            }, p))]
        })
    }),
    _e = "t1rxngp3",
    he = {
        1: {
            10: [1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0],
            20: [1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0],
            30: [1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0],
            40: [1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0],
            50: [1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0, 1.5, 1.2, 1.2, 1.2, 0, 1.2, 1.2, 1.2, 1.2, 0]
        },
        2: {
            10: [0, 1.9, 0, 1.5, 0, 2, 0, 1.5, 0, 3],
            20: [1.5, 0, 2, 0, 2, 0, 2, 0, 1.5, 0, 3, 0, 1.8, 0, 2, 0, 2, 0, 2, 0],
            30: [1.5, 0, 1.5, 0, 2, 0, 1.5, 0, 2, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 2, 0, 2, 0, 1.7, 0, 4, 0, 1.5, 0, 2, 0],
            40: [2, 0, 3, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 1.5, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 2, 0, 2, 0, 1.6, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 2, 0, 1.5, 0],
            50: [2, 0, 1.5, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 1.5, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 2, 0, 1.5, 0, 2, 0, 2, 0, 1.5, 0, 3, 0, 1.5, 0, 2, 0, 1.5, 0, 1.5, 0, 5, 0, 1.5, 0, 2, 0, 1.5, 0]
        },
        3: {
            10: [0, 0, 0, 0, 0, 0, 0, 0, 0, 9.9],
            20: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 19.8],
            30: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 29.7],
            40: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39.6],
            50: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 49.5]
        }
    },
    ce = {
        "1": {
            "10": [
                [0, .2],
                [1.2, .7],
                [1.5, .1]
            ],
            "20": [
                [0, .2],
                [1.2, .7],
                [1.5, .1]
            ],
            "30": [
                [0, .2],
                [1.2, .7],
                [1.5, .1]
            ],
            "40": [
                [0, .2],
                [1.2, .7],
                [1.5, .1]
            ],
            "50": [
                [0, .2],
                [1.2, .7],
                [1.5, .1]
            ]
        },
        "2": {
            "10": [
                [0, .5],
                [1.5, .2],
                [1.9, .1],
                [2, .1],
                [3, .1]
            ],
            "20": [
                [0, .5],
                [1.5, .1],
                [1.8, .05],
                [2, .3],
                [3, .05]
            ],
            "30": [
                [0, .5],
                [1.5, .2],
                [1.7, .03333333333333333],
                [2, .2],
                [3, .03333333333333333],
                [4, .03333333333333333]
            ],
            "40": [
                [0, .5],
                [1.5, .2],
                [1.6, .025],
                [2, .175],
                [3, .1]
            ],
            "50": [
                [0, .5],
                [1.5, .26],
                [2, .16],
                [3, .06],
                [5, .02]
            ]
        },
        "3": {
            "10": [
                [0, .9],
                [9.9, .1]
            ],
            "20": [
                [0, .95],
                [19.8, .05]
            ],
            "30": [
                [0, .9666666666666667],
                [29.7, .03333333333333333]
            ],
            "40": [
                [0, .975],
                [39.6, .025]
            ],
            "50": [
                [0, .98],
                [49.5, .02]
            ]
        }
    };

function et() {
    const i = window.innerHeight,
        t = window.innerWidth;
    return T.isMobile ? t * .6 : Math.min(450, i - 360)
}
const tt = I(() => {
    const i = O(),
        t = ce[i.risk][i.segment],
        e = T.isDarken ? "black" : "white",
        [n, r] = S.exports.useState(0),
        l = xe(({
            width: y
        }) => {
            r(Math.min(y, 750))
        }, 300),
        [h] = S.exports.useState(() => new P(i.segment, i.risk, he, e, et())),
        f = S.exports.useCallback(y => {
            y ? (y.appendChild(h.renderer.view), i.onBetRequest = async d => {
                let c = await d;
                try {
                    await h.spin(c.odds), i.odds = c.odds
                } catch (p) {
                    console.error("spin error", p)
                }
                return c
            }) : h.destroy()
        }, []);
    return S.exports.useLayoutEffect(() => {
        h.resize(n * (n > 600 ? .6 : .8))
    }, [n]), S.exports.useEffect(() => {
        h.resetRing(i.segment, i.risk, e)
    }, [i.risk, i.segment, T.isDarken]), u("div", {
        className: it,
        ref: l,
        id: "wheel-game-canvas",
        children: [s("div", {
            className: "wheel-canvas-wrap",
            ref: f
        }), s(le, {
            payouts: t
        })]
    })
});
Se({
    cl1: [ie("#31343c", .3), ie("#cccfd9", .4)]
});
const it = "g11rocm1",
    st = I(() => {
        const i = O(),
            t = R.useSingleDetail();
        return s(Ce, {
            list: i.myBets,
            keyof: "betId",
            onDetail: t
        })
    }),
    nt = () => u(q, {
        children: [s(st, {}), u(Ie, {
            children: [s(tt, {}), s(Be, {})]
        })]
    });
var at = I(nt);

function rt() {
    const i = F(),
        t = O(),
        {
            isBetting: e,
            controlIdx: n
        } = t,
        r = n === 1;
    return s(Oe, {
        className: "bet-button",
        size: "big",
        type: "conic",
        onClick: () => {
            r ? t.autoBet.isRunning ? t.autoBet.stop() : t.autoBet.start().catch(se) : t.handleBet().catch(se)
        },
        disabled: r ? !t.autoBet.isRunning && t.isBetting : r || e,
        children: r ? t.autoBet.isRunning ? i("common.stop_auto_bet") : i("common.start_auto_bet") : i("common.bet")
    })
}
var L = I(rt);

function ot() {
    const i = F(),
        t = O();
    return s("div", {
        className: X(ht, "bet-control-auto"),
        children: T.isMobile ? u(q, {
            children: [s(L, {}), s(m.CoinInput, {
                checkIncrease: !0
            }), s(m.TimesInput, {}), s(m.LabelSelect, {
                label: i("common.risk"),
                disabled: t.isBetting,
                value: t.risk,
                options: t.riskOptions,
                onChange: e => t.risk = e
            }), s(m.LabelSelect, {
                label: i("game.wheel.segment"),
                disabled: t.isBetting,
                value: t.segment,
                options: t.segmentOptions,
                onChange: e => t.segment = e
            }), s(m.IncreaseInput, {}), s(m.StopInput, {}), s(m.IncreaseInput, {
                isLose: !0
            }), s(m.StopInput, {
                isLose: !0
            }), s(ne, {})]
        }) : u(q, {
            children: [s(m.CoinInput, {
                checkIncrease: !0
            }), s(m.TimesInput, {}), u("div", {
                className: "flex-wrap",
                children: [s(m.LabelSelect, {
                    label: i("common.risk"),
                    disabled: t.isBetting,
                    value: t.risk,
                    options: t.riskOptions,
                    onChange: e => t.risk = e
                }), s(m.LabelSelect, {
                    label: i("game.wheel.segment"),
                    disabled: t.isBetting,
                    value: t.segment,
                    options: t.segmentOptions,
                    onChange: e => t.segment = e
                })]
            }), s(m.IncreaseInput, {}), s(m.StopInput, {}), s(m.IncreaseInput, {
                isLose: !0
            }), s(m.StopInput, {
                isLose: !0
            }), s(ne, {}), s(L, {})]
        })
    })
}
var lt = I(ot);
const ht = "a19d8ukc";

function ct() {
    const i = F(),
        t = O();
    return u("div", {
        className: "bet-control-manual",
        children: [T.isMobile && s(L, {}), s(m.CoinInput, {
            checkIncrease: !0
        }), s(m.LabelSelect, {
            label: i("common.risk"),
            disabled: t.isBetting,
            value: t.risk,
            options: t.riskOptions,
            onChange: e => t.risk = e
        }), s(m.LabelSelect, {
            label: i("game.wheel.segment"),
            disabled: t.isBetting,
            value: t.segment,
            options: t.segmentOptions,
            onChange: e => t.segment = e
        }), !T.isMobile && s(L, {})]
    })
}
var ut = I(ct);
const dt = Z.memo(({
        game: i
    }) => s(re, {
        children: u("div", {
            className: "item",
            children: [s("h2", {
                children: "What Is The Wheel?"
            }), s("div", {
                className: "help-content",
                children: i.gameInfo.detail.split(`
`).map((t, e) => s("p", {
                    children: `${t}`
                }, e.toString()))
            }), s("h2", {
                children: "How To Play It?"
            }), u("div", {
                className: "help-content",
                children: [s("p", {
                    children: "Use some crypto coins to start the wheel spinning."
                }), s("p", {
                    children: "Pay close attention until the end of the game. We can\u2019t rely on the dizzy, red bird to watch all the action."
                })]
            })]
        })
    })),
    mt = Z.memo(({
        game: i
    }) => s(Ae, {
        game: i,
        children: u("div", {
            className: "item",
            children: [s("h2", {
                children: "What is the bankroll?"
            }), u("div", {
                className: "help-content",
                children: [s("p", {
                    children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                }), s("p", {
                    children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                }), s("p", {
                    children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                }), s("p", {
                    onClick: () => Ne(i),
                    className: "cl-primary cursor",
                    children: "Read more about bankrollers."
                })]
            }), s("h2", {
                children: "How does the pool of funds operate? "
            }), u("div", {
                className: "help-content",
                children: [s("p", {
                    children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                }), u("p", {
                    children: [s("b", {
                        className: "cl-primary",
                        children: "The house edge is 1%."
                    }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                }), s("p", {
                    children: "Payouts made to the winning players will be deducted from the bankroll."
                })]
            }), s("h2", {
                children: "How does leverage investment work?"
            }), u("div", {
                className: "help-content",
                children: [s("p", {
                    children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                }), s("p", {
                    children: "Hint: You can also use this feature as an Off-Site investment."
                }), s("p", {
                    children: "Let's make an example:"
                }), s("p", {
                    children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                })]
            }), s("h2", {
                children: "What is the bankroller dilution fee?"
            }), u("div", {
                className: "help-content",
                children: [s("p", {
                    children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                }), s("p", {
                    children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                }), s("p", {
                    children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                }), s("p", {
                    children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                })]
            }), " "]
        })
    }));
var ft = mt;
const pt = Z.memo(() => {
        const i = F(),
            t = O(),
            e = [{
                title: i("common.game_intro"),
                node: s(dt, {
                    game: t
                })
            }, {
                title: i("common.fairness"),
                node: "/wheel_help/fairness"
            }, {
                title: i("common.bankroll"),
                node: s(ft, {
                    game: t
                })
            }];
        return s(Me, {
            className: yt,
            manualControl: s(ut, {}),
            autoControl: s(lt, {}),
            gameView: s(at, {}),
            tabs: [{
                label: i("common.all_bet"),
                value: R.AllBet
            }, {
                label: i("common.my_bet"),
                value: R.MyBet
            }],
            actions: [s(Te, {}), s(Fe, {}), s(Ge, {}), s(De, {}), s(Pe, {
                list: e
            })]
        })
    }),
    yt = "wbr1o32",
    C = B.Reader,
    ue = B.Writer,
    J = B.util,
    k = B.roots.gameWheel || (B.roots.gameWheel = {});
k.BetValue = (() => {
    function i(t) {
        if (t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return i.prototype.risk = 0, i.prototype.segment = 0, i.create = function(e) {
        return new i(e)
    }, i.encode = function(e, n) {
        return n || (n = ue.create()), e.risk != null && Object.hasOwnProperty.call(e, "risk") && n.uint32(8).int32(e.risk), e.segment != null && Object.hasOwnProperty.call(e, "segment") && n.uint32(16).int32(e.segment), n
    }, i.encodeDelimited = function(e, n) {
        return this.encode(e, n).ldelim()
    }, i.decode = function(e, n) {
        e instanceof C || (e = C.create(e));
        let r = n === void 0 ? e.len : e.pos + n,
            l = new k.BetValue;
        for (; e.pos < r;) {
            let h = e.uint32();
            switch (h >>> 3) {
                case 1:
                    l.risk = e.int32();
                    break;
                case 2:
                    l.segment = e.int32();
                    break;
                default:
                    e.skipType(h & 7);
                    break
            }
        }
        return l
    }, i.decodeDelimited = function(e) {
        return e instanceof C || (e = new C(e)), this.decode(e, e.uint32())
    }, i.verify = function(e) {
        return typeof e != "object" || e === null ? "object expected" : e.risk != null && e.hasOwnProperty("risk") && !J.isInteger(e.risk) ? "risk: integer expected" : e.segment != null && e.hasOwnProperty("segment") && !J.isInteger(e.segment) ? "segment: integer expected" : null
    }, i.fromObject = function(e) {
        if (e instanceof k.BetValue) return e;
        let n = new k.BetValue;
        return e.risk != null && (n.risk = e.risk | 0), e.segment != null && (n.segment = e.segment | 0), n
    }, i.toObject = function(e, n) {
        n || (n = {});
        let r = {};
        return n.defaults && (r.risk = 0, r.segment = 0), e.risk != null && e.hasOwnProperty("risk") && (r.risk = e.risk), e.segment != null && e.hasOwnProperty("segment") && (r.segment = e.segment), r
    }, i.prototype.toJSON = function() {
        return this.constructor.toObject(this, B.util.toJSONOptions)
    }, i
})();
k.GameValue = (() => {
    function i(t) {
        if (t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return i.prototype.result = 0, i.create = function(e) {
        return new i(e)
    }, i.encode = function(e, n) {
        return n || (n = ue.create()), e.result != null && Object.hasOwnProperty.call(e, "result") && n.uint32(8).int32(e.result), n
    }, i.encodeDelimited = function(e, n) {
        return this.encode(e, n).ldelim()
    }, i.decode = function(e, n) {
        e instanceof C || (e = C.create(e));
        let r = n === void 0 ? e.len : e.pos + n,
            l = new k.GameValue;
        for (; e.pos < r;) {
            let h = e.uint32();
            switch (h >>> 3) {
                case 1:
                    l.result = e.int32();
                    break;
                default:
                    e.skipType(h & 7);
                    break
            }
        }
        return l
    }, i.decodeDelimited = function(e) {
        return e instanceof C || (e = new C(e)), this.decode(e, e.uint32())
    }, i.verify = function(e) {
        return typeof e != "object" || e === null ? "object expected" : e.result != null && e.hasOwnProperty("result") && !J.isInteger(e.result) ? "result: integer expected" : null
    }, i.fromObject = function(e) {
        if (e instanceof k.GameValue) return e;
        let n = new k.GameValue;
        return e.result != null && (n.result = e.result | 0), n
    }, i.toObject = function(e, n) {
        n || (n = {});
        let r = {};
        return n.defaults && (r.result = 0), e.result != null && e.hasOwnProperty("result") && (r.result = e.result), r
    }, i.prototype.toJSON = function() {
        return this.constructor.toObject(this, B.util.toJSONOptions)
    }, i
})();
var gt = "/assets/tick.723c6672.mp3",
    bt = "/assets/lose.f61ace17.mp3",
    wt = "/assets/win.1d26aac1.mp3";
const vt = We.encode(k.BetValue);
class kt extends je {
    constructor() {
        super({
            name: "Wheel",
            namespace: "/g/w",
            sounds: {
                sound_tick: gt,
                sound_lose: bt,
                sound_win: wt
            },
            fairLink: "/wheel_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/wheel.html"
        }, pt);
        o(this, "risk", 1);
        o(this, "segment", 10);
        o(this, "odds", -1);
        o(this, "riskOptions", [{
            label: "Low",
            value: 1
        }, {
            label: "Medium",
            value: 2
        }, {
            label: "High",
            value: 3
        }]);
        o(this, "segmentOptions", [{
            label: "10",
            value: 10
        }, {
            label: "20",
            value: 20
        }, {
            label: "30",
            value: 30
        }, {
            label: "40",
            value: 40
        }, {
            label: "50",
            value: 50
        }]);
        o(this, "theme", {
            text: "#ffffff",
            main: "#5b6eaf",
            light: "#aeb9dd",
            dark: "#475998",
            dark2: "#384a88"
        });
        ze(this, {
            risk: Y,
            segment: Y,
            odds: Y,
            maxProfit: Re
        });
        const e = this.hotkeyList.find(n => n.key == "space");
        e && (e.handler = () => {
            if (this.controlIdx === 1) this.autoBet.isRunning ? this.autoBet.stop() : this.autoBet.start();
            else {
                if (this.isBetting) return !1;
                this.handleBet()
            }
            return !1
        })
    }
    get maxProfit() {
        const e = he[this.risk][this.segment];
        return this.amount.mul(Math.max(...e) - 1)
    }
    betValue() {
        return vt({
            risk: this.risk,
            segment: this.segment
        })
    }
}
const de = new kt;
var $ = de;
window.wlg = de;

function Ft({
    bodyLock: i
}) {
    return s(re, {
        bodyLock: i,
        children: u("div", {
            className: "item",
            children: [s("h2", {
                children: "How are results calculated?"
            }), u("div", {
                className: "help-content",
                children: [s("p", {
                    children: "To get the Wheel results, we first combine your client seed and your nonce."
                }), u("ul", {
                    children: [s("li", {
                        children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                    }), s("li", {
                        children: "Finally, take the first 8 characters of the hash and convert it to an int32 value according to Big-endian. Divide the converted value by 0x100000000 and multiply by the number of segments to round up to get the position of the odds table. Check the table to get the odds."
                    })]
                }), s("br", {}), s("p", {
                    children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                }), s("p", {}), s("p", {
                    children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                }), s("p", {
                    children: "Good luck, and dizzy does it!"
                })]
            })]
        })
    })
}
const xt = (i, t, e, n, r) => {
        let {
            segment: l,
            risk: h
        } = r.betLog.bv;
        const f = $.riskOptions.find(y => y.value === h);
        h = f == null ? void 0 : f.label, window.open(`${$.config.validateLink}?s=${i}&c=${t}&h=${n}&n=${e}&t=${l}&r=${h}`)
    },
    St = R.withSingleDetail({
        onValidate: xt,
        result: ({
            betLog: i
        }) => {
            const {
                risk: t,
                segment: e
            } = i.bv, n = ce[t][e];
            return s("div", {
                className: Ct,
                children: s(le, {
                    payouts: n,
                    curactive: i.odds / 1e4
                })
            })
        },
        slot: ({
            betLog: i
        }) => {
            const t = F(),
                {
                    risk: e,
                    segment: n
                } = i.bv,
                r = $.riskOptions.find(l => l.value === e);
            return u("div", {
                className: It,
                children: [s(ae, {
                    label: t("common.risk"),
                    value: r == null ? void 0 : r.label,
                    readOnly: !0
                }), s(ae, {
                    label: t("game.wheel.segment"),
                    value: n,
                    readOnly: !0
                })]
            })
        }
    });
var Gt = St;
const Ct = "dr1192o",
    It = "s1u68j2r";
export {
    ft as Bankroll, Gt as Detail, Ft as Fairness, $ as Game
};
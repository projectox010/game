import {
    u as o,
    j as e,
    a,
    C as p,
    p as d,
    B as l,
    s as m,
    b as t,
    o as h,
    D as N,
    S as b,
    c as i,
    n as g,
    d as f
} from "./index.28e31dff.js";
import {
    L as k,
    s as x
} from "./Starting.25c670fc.js";
import "./DepositBonus.c3043053.js";

function M({
    amount: s
}) {
    const r = o();
    return e("div", {
        className: v,
        children: [a(p, {
            onClick: () => d.close()
        }), e("div", {
            className: "main-bg",
            children: [e("div", {
                className: "top",
                children: [a("img", {
                    className: "flower",
                    alt: "flower",
                    src: l.pop_flower
                }), a("img", {
                    className: "ribbons",
                    alt: "ribbons",
                    src: l.pop_ribbons
                }), a("img", {
                    className: "bcd",
                    alt: "bcd",
                    src: l.pop_bcd
                }), a("img", {
                    className: "star star_one",
                    alt: "star",
                    src: l.pop_star
                }), a("img", {
                    className: "star star_two",
                    alt: "star",
                    src: l.pop_star
                }), a("img", {
                    className: "star star_three",
                    alt: "star",
                    src: l.pop_star
                })]
            }), e("p", {
                className: "one",
                children: [a("img", {
                    alt: "bcd",
                    src: l.pop_one
                }), s]
            }), e("p", {
                className: "two",
                children: [r("page.bcd.youget"), " ", a("img", {
                    alt: "bcd",
                    src: m.isDarken ? l.pop_two : l.pop_two_w
                }), s]
            }), a("p", {
                className: "three",
                children: r("page.bcd.checkwallet")
            }), a(t, {
                type: "conic",
                className: "ok",
                onClick: () => d.close(),
                children: "OK"
            })]
        })]
    })
}
const v = "bka2da1";
const c = [
    [.8, 1, 1.8],
    [1, 1.5, 2],
    [1, 1.5, 2.2],
    [1, 1.5, 2.4]
];
var B = h(function() {
    const s = o(),
        r = n => `${i.maxBonusRatio[n]*100}%`;
    return a(N, {
        title: "Deposit Bonus Rules",
        children: e(b, {
            className: w,
            children: [a("p", {
                children: s("page.bcd.rule1")
            }), a("p", {
                children: s("page.bcd.rule2")
            }), a("p", {
                children: s("page.bcd.rule3")
            }), e("div", {
                className: "item",
                children: [a("p", {
                    className: "title",
                    children: s("page.bcd.dep1")
                }), a("div", {
                    className: "word",
                    children: s("page.bcd.dep1_desc", r(1))
                }), e("div", {
                    className: "deposit-level-info first",
                    children: [e("p", {
                        className: "b",
                        children: [Math.floor(c[0][0] * 100), "%"]
                    }), e("p", {
                        className: "b",
                        children: [Math.floor(c[0][1] * 100), "%"]
                    }), e("p", {
                        className: "y",
                        children: [Math.floor(c[0][2] * 100), "%"]
                    })]
                })]
            }), e("div", {
                className: "item",
                children: [a("p", {
                    className: "title",
                    children: s("page.bcd.dep2")
                }), a("div", {
                    className: "word",
                    children: s("page.bcd.dep2_desc", r(2))
                }), e("div", {
                    className: "deposit-level-info second",
                    children: [e("p", {
                        className: "b",
                        children: [Math.floor(c[1][0] * 100), "%"]
                    }), e("p", {
                        className: "b",
                        children: [Math.floor(c[1][1] * 100), "%"]
                    }), e("p", {
                        className: "y",
                        children: [Math.floor(c[1][2] * 100), "%"]
                    })]
                })]
            }), e("div", {
                className: "item",
                children: [a("p", {
                    className: "title",
                    children: s("page.bcd.dep3")
                }), a("div", {
                    className: "word",
                    children: s("page.bcd.dep3_desc", r(3))
                }), e("div", {
                    className: "deposit-level-info third",
                    children: [e("p", {
                        className: "w",
                        children: [Math.floor(c[2][0] * 100), "%"]
                    }), e("p", {
                        className: "w",
                        children: [Math.floor(c[2][1] * 100), "%"]
                    }), e("p", {
                        className: "y",
                        children: [Math.floor(c[2][2] * 100), "%"]
                    })]
                })]
            }), e("div", {
                className: "item last",
                children: [a("p", {
                    className: "title",
                    children: s("page.bcd.dep4")
                }), a("div", {
                    className: "word",
                    children: s("page.bcd.dep4_desc", r(4))
                }), e("div", {
                    className: "deposit-level-info fourth",
                    children: [e("p", {
                        className: "w",
                        children: [Math.floor(c[3][0] * 100), "%"]
                    }), e("p", {
                        className: "w",
                        children: [Math.floor(c[3][1] * 100), "%"]
                    }), e("p", {
                        className: "y",
                        children: [Math.floor(c[3][2] * 100), "%"]
                    })]
                })]
            }), i.rechargeValidNum < 4 ? a(t, {
                onClick: () => g("/wallet/deposit"),
                className: "deposit-btn",
                type: "conic",
                children: f.login ? s("page.bcd.deposit_now") : s("common.signup_deposit")
            }) : null]
        })
    })
});
const w = "b1cw39n";
export {
    M as BcdReward, B as BcdRule, k as LimitBonus, x as Starting
};
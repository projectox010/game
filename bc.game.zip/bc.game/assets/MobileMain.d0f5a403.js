import {
    a5 as n,
    r as i,
    j as l,
    a as o,
    fn as m
} from "./index.28e31dff.js";
import u from "./SearchMain.dd85b9a0.js";
const x = n.memo(function({
        big: c,
        onCLose: a
    }) {
        const e = i.exports.useRef(null);
        return i.exports.useEffect(() => {
            var s;
            let r;
            return c ? (s = e.current) == null || s.focus() : r = setTimeout(() => {
                var t;
                (t = e.current) == null || t.focus()
            }, 200), () => {
                clearTimeout(r)
            }
        }, []), l("div", {
            className: `${f} mobile-search-main`,
            children: [o(m, {
                isSmall: !0,
                closeFn: a,
                ref: e,
                className: "search-input-bigwrap"
            }), o(u, {
                closeFn: a
            })]
        })
    }),
    f = "mr0xt0w";
export {
    x as
    default
};
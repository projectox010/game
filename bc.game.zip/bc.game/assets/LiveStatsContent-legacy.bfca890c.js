! function() {
    var t = document.createElement("style");
    t.innerHTML = '.l1n7fkd0{--1yhspeg:rgba(95,105,117,.8);--1hr07om:rgba(95,105,117,.6);--whdmoy:#31373d;width:260px;height:301.59999999999997px;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;box-sizing:content-box;color:var(--1yhspeg);padding-bottom:1.25rem}.darken .l1n7fkd0{--1yhspeg:rgba(153,164,176,.6);--1hr07om:rgba(153,164,176,.6);--whdmoy:#f5f6f7}.l1n7fkd0>.title{-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}.l1n7fkd0 .title-btn{width:2.5rem;height:2.5rem;margin-right:-.625rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.l1n7fkd0 .title-btn .icon{width:1.25rem;height:1.25rem;fill:var(--1hr07om)}.l1n7fkd0 .chart-cont{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex}.l1n7fkd0 .chart-cont .item-wrap.wagered{-webkit-flex:1;-ms-flex:1;flex:1}.l1n7fkd0 .chart-cont .item-wrap.wagered .amount{color:var(--whdmoy)}.l1n7fkd0 .chart-cont .item-wrap.profit .amount{color:var(--primary-color)}.l1n7fkd0 .chart-cont .item-wrap .amount{font-weight:600}.l1n7fkd0 .chart-cont .item-wrap .coin-icon{width:.875rem;height:.875rem;margin-right:.3125rem}.l1n7fkd0 .chart-cont .item-wrap .cl-success .amount{color:var(--primary-color)}.l1n7fkd0 .chart-cont .item-wrap .cl-require .amount{color:#ed6300}.l1n7fkd0 .bet-wrap,.l1n7fkd0 .bet-wrap .bet-item{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex}.l1n7fkd0 .bet-wrap .win{-webkit-flex:1;-ms-flex:1;flex:1}.l1n7fkd0 .bet-wrap .win .num{color:var(--primary-color)}.l1n7fkd0 .bet-wrap .lose .num{color:#ed6300}.l1n7fkd0 .bet-wrap .num{margin-left:.75rem;font-weight:600}.l1n7fkd0 .chart-wrap{position:relative;width:16.25rem;height:10.9375rem}.l1n7fkd0 .chart-wrap .tooltip-wrap{position:absolute;right:0;top:-.375rem}.l1n7fkd0 .chart-wrap .tooltip-wrap .amount{font-weight:600}.l1n7fkd0 .chart-wrap .tooltip-wrap .coin-icon{width:.875rem;height:.875rem;margin-right:.3125rem}.l1n7fkd0 .chart-wrap .tooltip-wrap .cl-success .amount{color:var(--primary-color)}.l1n7fkd0 .chart-wrap .tooltip-wrap .cl-require .amount{color:#ed6300}.s1g8crrf{height:.5rem;background:url(./progress_bg.png) 100% auto;position:relative}.s1g8crrf .progress-cont{position:absolute;width:0%;max-width:100%;left:0;top:0;height:100%;-webkit-transition:all .5s linear;transition:all .5s linear}.s1g8crrf .progress-cont .bar{width:100%;height:100%;display:inline-block;vertical-align:top;border-top-left-radius:.25rem;border-bottom-left-radius:.25rem}.s1g8crrf .progress-cont .coin{position:absolute;right:-.3125rem;top:-.375rem;width:1.125rem;height:1.125rem}.l1nrtaq9{--1yhspeg:rgba(95,105,117,.8);--whdmoy:#31373d;--kg53wy:#dadde6;--i5wv4c:rgba(49,55,61,.8);--ub5ndl:linear-gradient(to bottom,#5f6975 -78%,rgba(95,105,117,0) 100%);text-align:center;color:var(--1yhspeg);height:17.75rem;overflow:hidden}.darken .l1nrtaq9{--1yhspeg:rgba(153,164,176,.6);--whdmoy:#f5f6f7;--kg53wy:#353a43;--i5wv4c:#f5f6f7;--ub5ndl:linear-gradient(to bottom,#1e2024 -31%,#353a43 100%)}.l1nrtaq9 .contest-tabs .tabs-navs{text-transform:capitalize}.l1nrtaq9 .time_ranking{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}.l1nrtaq9 .time_ranking .item-label{margin:.75rem 0;text-transform:capitalize}.l1nrtaq9 .time_ranking .item-value{font-size:1rem;color:var(--whdmoy);font-weight:600;line-height:2.375rem}.l1nrtaq9 .countdown-wrap{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.l1nrtaq9 .countdown-wrap .item{width:2rem;height:2.375rem;border-radius:.3125rem;box-shadow:0 1px 1px rgba(0,0,0,.02);background:var(--kg53wy);font-weight:600;color:var(--whdmoy);font-size:.875rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;position:relative;text-transform:capitalize}.l1nrtaq9 .countdown-wrap .item:nth-child(2),.l1nrtaq9 .countdown-wrap .item:nth-child(3){margin-left:.75rem}.l1nrtaq9 .countdown-wrap .item:nth-child(2):before,.l1nrtaq9 .countdown-wrap .item:nth-child(3):before{content:":";position:absolute;top:0;bottom:0;left:-.75rem;width:.75rem;line-height:2.25rem}.l1nrtaq9 .countdown-wrap .item:after{content:"";position:absolute;z-index:1;left:0;right:0;bottom:0;top:50%;background-image:var(--ub5ndl);border-radius:0 0 .3125rem .3125rem}.l1nrtaq9 .countdown-wrap .item .value{position:relative;z-index:2}.l1nrtaq9 .target-box{position:relative;width:16.25rem;height:1.25rem;overflow:hidden;margin:.9375rem 0;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.l1nrtaq9 .target{position:absolute;top:50%;left:50%;-webkit-transform-origin:center;-ms-transform-origin:center;transform-origin:center;-webkit-transform:translate(-50%,-50%) scale(.83);-ms-transform:translate(-50%,-50%) scale(.83);transform:translate(-50%,-50%) scale(.83);white-space:nowrap}.l1nrtaq9 .target .dot{width:.375rem;height:.375rem;border-radius:50%;background:var(--primary-color);margin-right:.3125rem}.l1nrtaq9 .target .spec{color:var(--i5wv4c);margin-left:.3125rem}.l1nrtaq9 .summary{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;padding:1.25rem 0;text-align:left;border-top:1px solid rgba(153,164,176,.1)}.l1nrtaq9 .summary .item .amount{font-weight:600}.l1nrtaq9 .summary .item .coin-icon{width:.875rem;height:.875rem;margin-right:.3125rem}.l1nrtaq9 .summary .wagered{-webkit-flex:1;-ms-flex:1;flex:1}.l1nrtaq9 .summary .wagered .amount{color:var(--whdmoy)}.l1nrtaq9 .summary .prize .amount{color:var(--primary-color)}.l1nrtaq9 .summary .item-label{margin-bottom:.3125rem}.lhadtgd{--1waic39:rgba(95,105,117,.8);--njpvpw:#31373d;--7h9g04:#f5f6fa;--35p5sb:#fff;--1m7qyf:#fb9512;color:var(--1waic39);padding-bottom:1.25rem;position:relative}.darken .lhadtgd{--1waic39:#99a4b0;--njpvpw:#fff;--7h9g04:#17181b;--35p5sb:#1e2024;--1m7qyf:#fbcf12}.lhadtgd.m-item .title{height:2.625rem}.lhadtgd .light{color:var(--njpvpw);padding:0 .125rem}.lhadtgd .progress{position:relative;height:.375rem;border-radius:.1875rem;background:var(--7h9g04);margin:.3125rem 0 .5rem}.lhadtgd .progress .current{position:absolute;top:0;left:0;bottom:0;border-radius:.1875rem;background-image:linear-gradient(to left,var(--primary-color),var(--35p5sb) 114%)}.lhadtgd .bcd-status{-webkit-transform:scale(.5);-ms-transform:scale(.5);transform:scale(.5);-webkit-transform-origin:right bottom;-ms-transform-origin:right bottom;transform-origin:right bottom;position:absolute;right:.9375rem;bottom:.625rem}.lhadtgd .claim-desc{margin-bottom:4.375rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.lhadtgd .claim-desc .coin-icon{width:1.25rem;height:1.25rem;margin:0 .3125rem 0 0}.lhadtgd .claim-tit{color:var(--1m7qyf);height:1.125rem;line-height:1.125rem;margin-top:.625rem}.lhadtgd .claim-btn{width:6.875rem;margin:.4375rem 0}.lhadtgd .claim-btn .loading{height:auto}.lhadtgd .progress-img{position:absolute;width:8.125rem;right:.625rem;bottom:1.375rem}.lhadtgd .detail{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;cursor:pointer;color:var(--primary-color)}.lhadtgd .detail .icon{width:.875rem;height:.875rem;fill:var(--primary-color);margin-left:.125rem}.lhadtgd .countdown-box{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-size:.75rem;position:absolute;top:.75rem;right:.75rem;padding-right:1.25rem}.lhadtgd .countdown-box .circle{width:.875rem;height:.875rem;position:absolute;right:0}.lhadtgd .countdown-box .time{width:2rem;margin-left:.375rem;opacity:.6}.lhadtgd .countdown-box .coin-amount{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.lhadtgd .countdown-box .coin-amount .coin-icon{width:1.4em;height:1.4em;margin-right:.25em}.lkl4y2n{--whdmoy:#31373d;--19k4iut:rgba(95,105,117,.35);--iq9wf1:#fff;--19j0w47:rgba(0,0,0,.2);--aeprok:rgba(95,105,117,.1);--1arpbgo:rgba(95,105,117,.14);--1hi6cf:#f6f7fa;position:relative}.darken .lkl4y2n{--whdmoy:#f5f6f7;--19k4iut:rgba(245,246,247,.6);--iq9wf1:#1b1d21;--19j0w47:rgba(0,0,0,.3);--aeprok:rgba(153,164,176,.1);--1arpbgo:rgba(153,164,176,.6);--1hi6cf:rgba(45,48,53,.4)}.lkl4y2n .trigger{height:2.5rem;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;color:var(--whdmoy);cursor:pointer}.lkl4y2n .trigger .icon{fill:var(--19k4iut);-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0);-webkit-transition:-webkit-transform .2s ease-in-out;-webkit-transition:transform .2s ease-in-out;transition:transform .2s ease-in-out}.lkl4y2n .trigger.unfold .icon{-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.lkl4y2n .options{position:absolute;top:2.5rem;left:0;right:0;z-index:11;padding-bottom:1.875rem;background-color:var(--iq9wf1);box-shadow:0 1px 5px 0 var(--19j0w47)}.lkl4y2n .options .item{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:1.875rem;cursor:pointer}.lkl4y2n .options .item.disabled{border-bottom:1px solid var(--aeprok);cursor:unset;height:2.625rem;margin-bottom:.25rem}.lkl4y2n .options .item.disabled .checkbox{opacity:.5}.lkl4y2n .options .item-value{margin-left:.75rem}.lkl4y2n .checkbox{width:1rem;height:1rem;border-radius:.3125rem;border:1px solid var(--1arpbgo);position:relative;background:var(--1hi6cf);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.lkl4y2n .checkbox .icon{width:.625rem;height:.625rem;fill:var(--primary-color)}\n', document.head.appendChild(t), System.register(["./index-legacy.1416f96c.js", "./ContestStore-legacy.ae4fb74e.js", "./index-legacy.1f31f668.js", "./Status-legacy.ce7bc332.js"], (function(t) {
        "use strict";
        var e, n, r, i, a, o, u, c, l, s, f, h, d, p, y, v, b, g, m, _, x, w, k, O, A, E, M, T, j, P, S, C, N;
        return {
            setters: [function(t) {
                e = t.aM, n = t.a5, r = t.bz, i = t.o, a = t.u, o = t.r, u = t.j, c = t.a, l = t.cO, s = t.A, f = t.M, h = t.t, d = t.q, p = t.s, y = t.l, v = t.B, b = t.F, g = t.H, m = t.T, _ = t.k, x = t.e, w = t.y, k = t.c, O = t.z, A = t.aQ, E = t.b, M = t.b2, T = t.m, j = t.b1, P = t.ag
            }, function(t) {
                S = t.c
            }, function(t) {
                C = t.P
            }, function(t) {
                N = t.B
            }],
            execute: function() {
                function D(t) {
                    return ((t *= 2) <= 1 ? t * t : --t * (2 - t) + 1) / 2
                }

                function I(t) {
                    return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2
                }
                var L = function t(e) {
                        function n(t) {
                            return Math.pow(t, e)
                        }
                        return e = +e, n.exponent = t, n
                    }(3),
                    z = function t(e) {
                        function n(t) {
                            return 1 - Math.pow(1 - t, e)
                        }
                        return e = +e, n.exponent = t, n
                    }(3),
                    W = function t(e) {
                        function n(t) {
                            return ((t *= 2) <= 1 ? Math.pow(t, e) : 2 - Math.pow(2 - t, e)) / 2
                        }
                        return e = +e, n.exponent = t, n
                    }(3),
                    F = Math.PI,
                    R = F / 2;

                function U(t) {
                    return (1 - Math.cos(F * t)) / 2
                }

                function q(t) {
                    return 1.0009775171065494 * (Math.pow(2, -10 * t) - .0009765625)
                }

                function B(t) {
                    return ((t *= 2) <= 1 ? q(1 - t) : 2 - q(t - 1)) / 2
                }

                function H(t) {
                    return ((t *= 2) <= 1 ? 1 - Math.sqrt(1 - t * t) : Math.sqrt(1 - (t -= 2) * t) + 1) / 2
                }
                var K = 4 / 11,
                    Y = 7.5625;

                function V(t) {
                    return (t = +t) < K ? Y * t * t : t < .7272727272727273 ? Y * (t -= .5454545454545454) * t + .75 : t < .9090909090909091 ? Y * (t -= .8181818181818182) * t + .9375 : Y * (t -= .9545454545454546) * t + .984375
                }
                var G = 1.70158,
                    $ = function t(e) {
                        function n(t) {
                            return (t = +t) * t * (e * (t - 1) + t)
                        }
                        return e = +e, n.overshoot = t, n
                    }(G),
                    X = function t(e) {
                        function n(t) {
                            return --t * t * ((t + 1) * e + t) + 1
                        }
                        return e = +e, n.overshoot = t, n
                    }(G),
                    Q = function t(e) {
                        function n(t) {
                            return ((t *= 2) < 1 ? t * t * ((e + 1) * t - e) : (t -= 2) * t * ((e + 1) * t + e) + 2) / 2
                        }
                        return e = +e, n.overshoot = t, n
                    }(G),
                    Z = 2 * Math.PI,
                    J = function t(e, n) {
                        var r = Math.asin(1 / (e = Math.max(1, e))) * (n /= Z);

                        function i(t) {
                            return e * q(- --t) * Math.sin((r - t) / n)
                        }
                        return i.amplitude = function(e) {
                            return t(e, n * Z)
                        }, i.period = function(n) {
                            return t(e, n)
                        }, i
                    }(1, .3),
                    tt = function t(e, n) {
                        var r = Math.asin(1 / (e = Math.max(1, e))) * (n /= Z);

                        function i(t) {
                            return 1 - e * q(t = +t) * Math.sin((t + r) / n)
                        }
                        return i.amplitude = function(e) {
                            return t(e, n * Z)
                        }, i.period = function(n) {
                            return t(e, n)
                        }, i
                    }(1, .3),
                    et = function t(e, n) {
                        var r = Math.asin(1 / (e = Math.max(1, e))) * (n /= Z);

                        function i(t) {
                            return ((t = 2 * t - 1) < 0 ? e * q(-t) * Math.sin((r - t) / n) : 2 - e * q(t) * Math.sin((r + t) / n)) / 2
                        }
                        return i.amplitude = function(e) {
                            return t(e, n * Z)
                        }, i.period = function(n) {
                            return t(e, n)
                        }, i
                    }(1, .3),
                    nt = Object.freeze(Object.defineProperty({
                        __proto__: null,
                        easeLinear: function(t) {
                            return +t
                        },
                        easeQuad: D,
                        easeQuadIn: function(t) {
                            return t * t
                        },
                        easeQuadOut: function(t) {
                            return t * (2 - t)
                        },
                        easeQuadInOut: D,
                        easeCubic: I,
                        easeCubicIn: function(t) {
                            return t * t * t
                        },
                        easeCubicOut: function(t) {
                            return --t * t * t + 1
                        },
                        easeCubicInOut: I,
                        easePoly: W,
                        easePolyIn: L,
                        easePolyOut: z,
                        easePolyInOut: W,
                        easeSin: U,
                        easeSinIn: function(t) {
                            return 1 == +t ? 1 : 1 - Math.cos(t * R)
                        },
                        easeSinOut: function(t) {
                            return Math.sin(t * R)
                        },
                        easeSinInOut: U,
                        easeExp: B,
                        easeExpIn: function(t) {
                            return q(1 - +t)
                        },
                        easeExpOut: function(t) {
                            return 1 - q(t)
                        },
                        easeExpInOut: B,
                        easeCircle: H,
                        easeCircleIn: function(t) {
                            return 1 - Math.sqrt(1 - t * t)
                        },
                        easeCircleOut: function(t) {
                            return Math.sqrt(1 - --t * t)
                        },
                        easeCircleInOut: H,
                        easeBounce: V,
                        easeBounceIn: function(t) {
                            return 1 - V(1 - t)
                        },
                        easeBounceOut: V,
                        easeBounceInOut: function(t) {
                            return ((t *= 2) <= 1 ? 1 - V(1 - t) : V(t - 1) + 1) / 2
                        },
                        easeBack: Q,
                        easeBackIn: $,
                        easeBackOut: X,
                        easeBackInOut: Q,
                        easeElastic: tt,
                        easeElasticIn: J,
                        easeElasticOut: tt,
                        easeElasticInOut: et
                    }, Symbol.toStringTag, {
                        value: "Module"
                    }));
                var rt = function(t, e) {
                        for (var n = -1, r = null == t ? 0 : t.length, i = Array(r); ++n < r;) i[n] = e(t[n], n, t);
                        return i
                    },
                    it = Array.isArray,
                    at = "object" == typeof e && e && e.Object === Object && e,
                    ot = at,
                    ut = "object" == typeof self && self && self.Object === Object && self,
                    ct = ot || ut || Function("return this")(),
                    lt = ct.Symbol,
                    st = lt,
                    ft = Object.prototype,
                    ht = ft.hasOwnProperty,
                    dt = ft.toString,
                    pt = st ? st.toStringTag : void 0;
                var yt = function(t) {
                        var e = ht.call(t, pt),
                            n = t[pt];
                        try {
                            t[pt] = void 0;
                            var r = !0
                        } catch (a) {}
                        var i = dt.call(t);
                        return r && (e ? t[pt] = n : delete t[pt]), i
                    },
                    vt = Object.prototype.toString;
                var bt = yt,
                    gt = function(t) {
                        return vt.call(t)
                    },
                    mt = lt ? lt.toStringTag : void 0;
                var _t = function(t) {
                    return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : mt && mt in Object(t) ? bt(t) : gt(t)
                };
                var xt = function(t) {
                        return null != t && "object" == typeof t
                    },
                    wt = _t,
                    kt = xt;
                var Ot = function(t) {
                        return "symbol" == typeof t || kt(t) && "[object Symbol]" == wt(t)
                    },
                    At = it,
                    Et = Ot,
                    Mt = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
                    Tt = /^\w*$/;
                var jt = function(t, e) {
                    if (At(t)) return !1;
                    var n = typeof t;
                    return !("number" != n && "symbol" != n && "boolean" != n && null != t && !Et(t)) || (Tt.test(t) || !Mt.test(t) || null != e && t in Object(e))
                };
                var Pt = function(t) {
                        var e = typeof t;
                        return null != t && ("object" == e || "function" == e)
                    },
                    St = _t,
                    Ct = Pt;
                var Nt, Dt = function(t) {
                        if (!Ct(t)) return !1;
                        var e = St(t);
                        return "[object Function]" == e || "[object GeneratorFunction]" == e || "[object AsyncFunction]" == e || "[object Proxy]" == e
                    },
                    It = Dt,
                    Lt = ct["__core-js_shared__"],
                    zt = (Nt = /[^.]+$/.exec(Lt && Lt.keys && Lt.keys.IE_PROTO || "")) ? "Symbol(src)_1." + Nt : "";
                var Wt = function(t) {
                        return !!zt && zt in t
                    },
                    Ft = Function.prototype.toString;
                var Rt = function(t) {
                        if (null != t) {
                            try {
                                return Ft.call(t)
                            } catch (e) {}
                            try {
                                return t + ""
                            } catch (e) {}
                        }
                        return ""
                    },
                    Ut = Dt,
                    qt = Wt,
                    Bt = Pt,
                    Ht = Rt,
                    Kt = /^\[object .+?Constructor\]$/,
                    Yt = Function.prototype,
                    Vt = Object.prototype,
                    Gt = Yt.toString,
                    $t = Vt.hasOwnProperty,
                    Xt = RegExp("^" + Gt.call($t).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
                var Qt = function(t, e) {
                        return null == t ? void 0 : t[e]
                    },
                    Zt = function(t) {
                        return !(!Bt(t) || qt(t)) && (Ut(t) ? Xt : Kt).test(Ht(t))
                    },
                    Jt = Qt;
                var te = function(t, e) {
                        var n = Jt(t, e);
                        return Zt(n) ? n : void 0
                    },
                    ee = te(Object, "create"),
                    ne = ee;
                var re = function() {
                    this.__data__ = ne ? ne(null) : {}, this.size = 0
                };
                var ie = function(t) {
                        var e = this.has(t) && delete this.__data__[t];
                        return this.size -= e ? 1 : 0, e
                    },
                    ae = ee,
                    oe = Object.prototype.hasOwnProperty;
                var ue = function(t) {
                        var e = this.__data__;
                        if (ae) {
                            var n = e[t];
                            return "__lodash_hash_undefined__" === n ? void 0 : n
                        }
                        return oe.call(e, t) ? e[t] : void 0
                    },
                    ce = ee,
                    le = Object.prototype.hasOwnProperty;
                var se = ee;
                var fe = re,
                    he = ie,
                    de = ue,
                    pe = function(t) {
                        var e = this.__data__;
                        return ce ? void 0 !== e[t] : le.call(e, t)
                    },
                    ye = function(t, e) {
                        var n = this.__data__;
                        return this.size += this.has(t) ? 0 : 1, n[t] = se && void 0 === e ? "__lodash_hash_undefined__" : e, this
                    };

                function ve(t) {
                    var e = -1,
                        n = null == t ? 0 : t.length;
                    for (this.clear(); ++e < n;) {
                        var r = t[e];
                        this.set(r[0], r[1])
                    }
                }
                ve.prototype.clear = fe, ve.prototype.delete = he, ve.prototype.get = de, ve.prototype.has = pe, ve.prototype.set = ye;
                var be = ve;
                var ge = function() {
                    this.__data__ = [], this.size = 0
                };
                var me = function(t, e) {
                        return t === e || t != t && e != e
                    },
                    _e = me;
                var xe = function(t, e) {
                        for (var n = t.length; n--;)
                            if (_e(t[n][0], e)) return n;
                        return -1
                    },
                    we = xe,
                    ke = Array.prototype.splice;
                var Oe = xe;
                var Ae = xe;
                var Ee = xe;
                var Me = ge,
                    Te = function(t) {
                        var e = this.__data__,
                            n = we(e, t);
                        return !(n < 0) && (n == e.length - 1 ? e.pop() : ke.call(e, n, 1), --this.size, !0)
                    },
                    je = function(t) {
                        var e = this.__data__,
                            n = Oe(e, t);
                        return n < 0 ? void 0 : e[n][1]
                    },
                    Pe = function(t) {
                        return Ae(this.__data__, t) > -1
                    },
                    Se = function(t, e) {
                        var n = this.__data__,
                            r = Ee(n, t);
                        return r < 0 ? (++this.size, n.push([t, e])) : n[r][1] = e, this
                    };

                function Ce(t) {
                    var e = -1,
                        n = null == t ? 0 : t.length;
                    for (this.clear(); ++e < n;) {
                        var r = t[e];
                        this.set(r[0], r[1])
                    }
                }
                Ce.prototype.clear = Me, Ce.prototype.delete = Te, Ce.prototype.get = je, Ce.prototype.has = Pe, Ce.prototype.set = Se;
                var Ne = Ce,
                    De = te(ct, "Map"),
                    Ie = be,
                    Le = Ne,
                    ze = De;
                var We = function(t) {
                    var e = typeof t;
                    return "string" == e || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== t : null === t
                };
                var Fe = function(t, e) {
                        var n = t.__data__;
                        return We(e) ? n["string" == typeof e ? "string" : "hash"] : n.map
                    },
                    Re = Fe;
                var Ue = Fe;
                var qe = Fe;
                var Be = Fe;
                var He = function() {
                        this.size = 0, this.__data__ = {
                            hash: new Ie,
                            map: new(ze || Le),
                            string: new Ie
                        }
                    },
                    Ke = function(t) {
                        var e = Re(this, t).delete(t);
                        return this.size -= e ? 1 : 0, e
                    },
                    Ye = function(t) {
                        return Ue(this, t).get(t)
                    },
                    Ve = function(t) {
                        return qe(this, t).has(t)
                    },
                    Ge = function(t, e) {
                        var n = Be(this, t),
                            r = n.size;
                        return n.set(t, e), this.size += n.size == r ? 0 : 1, this
                    };

                function $e(t) {
                    var e = -1,
                        n = null == t ? 0 : t.length;
                    for (this.clear(); ++e < n;) {
                        var r = t[e];
                        this.set(r[0], r[1])
                    }
                }
                $e.prototype.clear = He, $e.prototype.delete = Ke, $e.prototype.get = Ye, $e.prototype.has = Ve, $e.prototype.set = Ge;
                var Xe = $e,
                    Qe = Xe;

                function Ze(t, e) {
                    if ("function" != typeof t || null != e && "function" != typeof e) throw new TypeError("Expected a function");
                    var n = function() {
                        var r = arguments,
                            i = e ? e.apply(this, r) : r[0],
                            a = n.cache;
                        if (a.has(i)) return a.get(i);
                        var o = t.apply(this, r);
                        return n.cache = a.set(i, o) || a, o
                    };
                    return n.cache = new(Ze.Cache || Qe), n
                }
                Ze.Cache = Qe;
                var Je = Ze;
                var tn = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
                    en = /\\(\\)?/g,
                    nn = function(t) {
                        var e = Je(t, (function(t) {
                                return 500 === n.size && n.clear(), t
                            })),
                            n = e.cache;
                        return e
                    }((function(t) {
                        var e = [];
                        return 46 === t.charCodeAt(0) && e.push(""), t.replace(tn, (function(t, n, r, i) {
                            e.push(r ? i.replace(en, "$1") : n || t)
                        })), e
                    })),
                    rn = nn,
                    an = rt,
                    on = it,
                    un = Ot,
                    cn = lt ? lt.prototype : void 0,
                    ln = cn ? cn.toString : void 0;
                var sn = function t(e) {
                        if ("string" == typeof e) return e;
                        if (on(e)) return an(e, t) + "";
                        if (un(e)) return ln ? ln.call(e) : "";
                        var n = e + "";
                        return "0" == n && 1 / e == -Infinity ? "-0" : n
                    },
                    fn = sn;
                var hn = function(t) {
                        return null == t ? "" : fn(t)
                    },
                    dn = it,
                    pn = jt,
                    yn = rn,
                    vn = hn;
                var bn = function(t, e) {
                        return dn(t) ? t : pn(t, e) ? [t] : yn(vn(t))
                    },
                    gn = Ot;
                var mn = function(t) {
                        if ("string" == typeof t || gn(t)) return t;
                        var e = t + "";
                        return "0" == e && 1 / t == -Infinity ? "-0" : e
                    },
                    _n = bn,
                    xn = mn;
                var wn = function(t, e) {
                        for (var n = 0, r = (e = _n(e, t)).length; null != t && n < r;) t = t[xn(e[n++])];
                        return n && n == r ? t : void 0
                    },
                    kn = Ne;
                var On = Ne,
                    An = De,
                    En = Xe;
                var Mn = Ne,
                    Tn = function() {
                        this.__data__ = new kn, this.size = 0
                    },
                    jn = function(t) {
                        var e = this.__data__,
                            n = e.delete(t);
                        return this.size = e.size, n
                    },
                    Pn = function(t) {
                        return this.__data__.get(t)
                    },
                    Sn = function(t) {
                        return this.__data__.has(t)
                    },
                    Cn = function(t, e) {
                        var n = this.__data__;
                        if (n instanceof On) {
                            var r = n.__data__;
                            if (!An || r.length < 199) return r.push([t, e]), this.size = ++n.size, this;
                            n = this.__data__ = new En(r)
                        }
                        return n.set(t, e), this.size = n.size, this
                    };

                function Nn(t) {
                    var e = this.__data__ = new Mn(t);
                    this.size = e.size
                }
                Nn.prototype.clear = Tn, Nn.prototype.delete = jn, Nn.prototype.get = Pn, Nn.prototype.has = Sn, Nn.prototype.set = Cn;
                var Dn = Nn;
                var In = Xe,
                    Ln = function(t) {
                        return this.__data__.set(t, "__lodash_hash_undefined__"), this
                    },
                    zn = function(t) {
                        return this.__data__.has(t)
                    };

                function Wn(t) {
                    var e = -1,
                        n = null == t ? 0 : t.length;
                    for (this.__data__ = new In; ++e < n;) this.add(t[e])
                }
                Wn.prototype.add = Wn.prototype.push = Ln, Wn.prototype.has = zn;
                var Fn = Wn;
                var Rn = function(t, e) {
                    for (var n = -1, r = null == t ? 0 : t.length; ++n < r;)
                        if (e(t[n], n, t)) return !0;
                    return !1
                };
                var Un = function(t, e) {
                        return t.has(e)
                    },
                    qn = Fn,
                    Bn = Rn,
                    Hn = Un;
                var Kn = function(t, e, n, r, i, a) {
                    var o = 1 & n,
                        u = t.length,
                        c = e.length;
                    if (u != c && !(o && c > u)) return !1;
                    var l = a.get(t),
                        s = a.get(e);
                    if (l && s) return l == e && s == t;
                    var f = -1,
                        h = !0,
                        d = 2 & n ? new qn : void 0;
                    for (a.set(t, e), a.set(e, t); ++f < u;) {
                        var p = t[f],
                            y = e[f];
                        if (r) var v = o ? r(y, p, f, e, t, a) : r(p, y, f, t, e, a);
                        if (void 0 !== v) {
                            if (v) continue;
                            h = !1;
                            break
                        }
                        if (d) {
                            if (!Bn(e, (function(t, e) {
                                    if (!Hn(d, e) && (p === t || i(p, t, n, r, a))) return d.push(e)
                                }))) {
                                h = !1;
                                break
                            }
                        } else if (p !== y && !i(p, y, n, r, a)) {
                            h = !1;
                            break
                        }
                    }
                    return a.delete(t), a.delete(e), h
                };
                var Yn = function(t) {
                    var e = -1,
                        n = Array(t.size);
                    return t.forEach((function(t, r) {
                        n[++e] = [r, t]
                    })), n
                };
                var Vn = function(t) {
                        var e = -1,
                            n = Array(t.size);
                        return t.forEach((function(t) {
                            n[++e] = t
                        })), n
                    },
                    Gn = ct.Uint8Array,
                    $n = me,
                    Xn = Kn,
                    Qn = Yn,
                    Zn = Vn,
                    Jn = lt ? lt.prototype : void 0,
                    tr = Jn ? Jn.valueOf : void 0;
                var er = function(t, e, n, r, i, a, o) {
                    switch (n) {
                        case "[object DataView]":
                            if (t.byteLength != e.byteLength || t.byteOffset != e.byteOffset) return !1;
                            t = t.buffer, e = e.buffer;
                        case "[object ArrayBuffer]":
                            return !(t.byteLength != e.byteLength || !a(new Gn(t), new Gn(e)));
                        case "[object Boolean]":
                        case "[object Date]":
                        case "[object Number]":
                            return $n(+t, +e);
                        case "[object Error]":
                            return t.name == e.name && t.message == e.message;
                        case "[object RegExp]":
                        case "[object String]":
                            return t == e + "";
                        case "[object Map]":
                            var u = Qn;
                        case "[object Set]":
                            var c = 1 & r;
                            if (u || (u = Zn), t.size != e.size && !c) return !1;
                            var l = o.get(t);
                            if (l) return l == e;
                            r |= 2, o.set(t, e);
                            var s = Xn(u(t), u(e), r, i, a, o);
                            return o.delete(t), s;
                        case "[object Symbol]":
                            if (tr) return tr.call(t) == tr.call(e)
                    }
                    return !1
                };
                var nr = function(t, e) {
                        for (var n = -1, r = e.length, i = t.length; ++n < r;) t[i + n] = e[n];
                        return t
                    },
                    rr = nr,
                    ir = it;
                var ar = function(t, e, n) {
                    var r = e(t);
                    return ir(t) ? r : rr(r, n(t))
                };
                var or = function(t, e) {
                    for (var n = -1, r = null == t ? 0 : t.length, i = 0, a = []; ++n < r;) {
                        var o = t[n];
                        e(o, n, t) && (a[i++] = o)
                    }
                    return a
                };
                var ur = function() {
                        return []
                    },
                    cr = or,
                    lr = ur,
                    sr = Object.prototype.propertyIsEnumerable,
                    fr = Object.getOwnPropertySymbols,
                    hr = fr ? function(t) {
                        return null == t ? [] : (t = Object(t), cr(fr(t), (function(e) {
                            return sr.call(t, e)
                        })))
                    } : lr,
                    dr = hr;
                var pr = function(t, e) {
                        for (var n = -1, r = Array(t); ++n < t;) r[n] = e(n);
                        return r
                    },
                    yr = _t,
                    vr = xt;
                var br = function(t) {
                        return vr(t) && "[object Arguments]" == yr(t)
                    },
                    gr = xt,
                    mr = Object.prototype,
                    _r = mr.hasOwnProperty,
                    xr = mr.propertyIsEnumerable,
                    wr = br(function() {
                        return arguments
                    }()) ? br : function(t) {
                        return gr(t) && _r.call(t, "callee") && !xr.call(t, "callee")
                    },
                    kr = wr,
                    Or = {
                        exports: {}
                    };
                var Ar = function() {
                    return !1
                };
                ! function(t, e) {
                    var n = ct,
                        r = Ar,
                        i = e && !e.nodeType && e,
                        a = i && t && !t.nodeType && t,
                        o = a && a.exports === i ? n.Buffer : void 0,
                        u = (o ? o.isBuffer : void 0) || r;
                    t.exports = u
                }(Or, Or.exports);
                var Er = /^(?:0|[1-9]\d*)$/;
                var Mr = function(t, e) {
                    var n = typeof t;
                    return !!(e = null == e ? 9007199254740991 : e) && ("number" == n || "symbol" != n && Er.test(t)) && t > -1 && t % 1 == 0 && t < e
                };
                var Tr = function(t) {
                        return "number" == typeof t && t > -1 && t % 1 == 0 && t <= 9007199254740991
                    },
                    jr = _t,
                    Pr = Tr,
                    Sr = xt,
                    Cr = {};
                Cr["[object Float32Array]"] = Cr["[object Float64Array]"] = Cr["[object Int8Array]"] = Cr["[object Int16Array]"] = Cr["[object Int32Array]"] = Cr["[object Uint8Array]"] = Cr["[object Uint8ClampedArray]"] = Cr["[object Uint16Array]"] = Cr["[object Uint32Array]"] = !0, Cr["[object Arguments]"] = Cr["[object Array]"] = Cr["[object ArrayBuffer]"] = Cr["[object Boolean]"] = Cr["[object DataView]"] = Cr["[object Date]"] = Cr["[object Error]"] = Cr["[object Function]"] = Cr["[object Map]"] = Cr["[object Number]"] = Cr["[object Object]"] = Cr["[object RegExp]"] = Cr["[object Set]"] = Cr["[object String]"] = Cr["[object WeakMap]"] = !1;
                var Nr = function(t) {
                    return Sr(t) && Pr(t.length) && !!Cr[jr(t)]
                };
                var Dr = function(t) {
                        return function(e) {
                            return t(e)
                        }
                    },
                    Ir = {
                        exports: {}
                    };
                ! function(t, e) {
                    var n = at,
                        r = e && !e.nodeType && e,
                        i = r && t && !t.nodeType && t,
                        a = i && i.exports === r && n.process,
                        o = function() {
                            try {
                                var t = i && i.require && i.require("util").types;
                                return t || a && a.binding && a.binding("util")
                            } catch (e) {}
                        }();
                    t.exports = o
                }(Ir, Ir.exports);
                var Lr = Nr,
                    zr = Dr,
                    Wr = Ir.exports,
                    Fr = Wr && Wr.isTypedArray,
                    Rr = Fr ? zr(Fr) : Lr,
                    Ur = pr,
                    qr = kr,
                    Br = it,
                    Hr = Or.exports,
                    Kr = Mr,
                    Yr = Rr,
                    Vr = Object.prototype.hasOwnProperty;
                var Gr = function(t, e) {
                        var n = Br(t),
                            r = !n && qr(t),
                            i = !n && !r && Hr(t),
                            a = !n && !r && !i && Yr(t),
                            o = n || r || i || a,
                            u = o ? Ur(t.length, String) : [],
                            c = u.length;
                        for (var l in t) !e && !Vr.call(t, l) || o && ("length" == l || i && ("offset" == l || "parent" == l) || a && ("buffer" == l || "byteLength" == l || "byteOffset" == l) || Kr(l, c)) || u.push(l);
                        return u
                    },
                    $r = Object.prototype;
                var Xr = function(t) {
                    var e = t && t.constructor;
                    return t === ("function" == typeof e && e.prototype || $r)
                };
                var Qr = function(t, e) {
                        return function(n) {
                            return t(e(n))
                        }
                    },
                    Zr = Qr(Object.keys, Object),
                    Jr = Xr,
                    ti = Zr,
                    ei = Object.prototype.hasOwnProperty;
                var ni = function(t) {
                        if (!Jr(t)) return ti(t);
                        var e = [];
                        for (var n in Object(t)) ei.call(t, n) && "constructor" != n && e.push(n);
                        return e
                    },
                    ri = Dt,
                    ii = Tr;
                var ai = function(t) {
                        return null != t && ii(t.length) && !ri(t)
                    },
                    oi = Gr,
                    ui = ni,
                    ci = ai;
                var li = function(t) {
                        return ci(t) ? oi(t) : ui(t)
                    },
                    si = li,
                    fi = ar,
                    hi = dr,
                    di = li;
                var pi = function(t) {
                        return fi(t, di, hi)
                    },
                    yi = pi,
                    vi = Object.prototype.hasOwnProperty;
                var bi = function(t, e, n, r, i, a) {
                        var o = 1 & n,
                            u = yi(t),
                            c = u.length;
                        if (c != yi(e).length && !o) return !1;
                        for (var l = c; l--;) {
                            var s = u[l];
                            if (!(o ? s in e : vi.call(e, s))) return !1
                        }
                        var f = a.get(t),
                            h = a.get(e);
                        if (f && h) return f == e && h == t;
                        var d = !0;
                        a.set(t, e), a.set(e, t);
                        for (var p = o; ++l < c;) {
                            var y = t[s = u[l]],
                                v = e[s];
                            if (r) var b = o ? r(v, y, s, e, t, a) : r(y, v, s, t, e, a);
                            if (!(void 0 === b ? y === v || i(y, v, n, r, a) : b)) {
                                d = !1;
                                break
                            }
                            p || (p = "constructor" == s)
                        }
                        if (d && !p) {
                            var g = t.constructor,
                                m = e.constructor;
                            g == m || !("constructor" in t) || !("constructor" in e) || "function" == typeof g && g instanceof g && "function" == typeof m && m instanceof m || (d = !1)
                        }
                        return a.delete(t), a.delete(e), d
                    },
                    gi = te(ct, "DataView"),
                    mi = te(ct, "Promise"),
                    _i = te(ct, "Set"),
                    xi = gi,
                    wi = De,
                    ki = mi,
                    Oi = _i,
                    Ai = te(ct, "WeakMap"),
                    Ei = _t,
                    Mi = Rt,
                    Ti = "[object Map]",
                    ji = "[object Promise]",
                    Pi = "[object Set]",
                    Si = "[object WeakMap]",
                    Ci = "[object DataView]",
                    Ni = Mi(xi),
                    Di = Mi(wi),
                    Ii = Mi(ki),
                    Li = Mi(Oi),
                    zi = Mi(Ai),
                    Wi = Ei;
                (xi && Wi(new xi(new ArrayBuffer(1))) != Ci || wi && Wi(new wi) != Ti || ki && Wi(ki.resolve()) != ji || Oi && Wi(new Oi) != Pi || Ai && Wi(new Ai) != Si) && (Wi = function(t) {
                    var e = Ei(t),
                        n = "[object Object]" == e ? t.constructor : void 0,
                        r = n ? Mi(n) : "";
                    if (r) switch (r) {
                        case Ni:
                            return Ci;
                        case Di:
                            return Ti;
                        case Ii:
                            return ji;
                        case Li:
                            return Pi;
                        case zi:
                            return Si
                    }
                    return e
                });
                var Fi = Wi,
                    Ri = Dn,
                    Ui = Kn,
                    qi = er,
                    Bi = bi,
                    Hi = Fi,
                    Ki = it,
                    Yi = Or.exports,
                    Vi = Rr,
                    Gi = "[object Arguments]",
                    $i = "[object Array]",
                    Xi = "[object Object]",
                    Qi = Object.prototype.hasOwnProperty;
                var Zi = function(t, e, n, r, i, a) {
                        var o = Ki(t),
                            u = Ki(e),
                            c = o ? $i : Hi(t),
                            l = u ? $i : Hi(e),
                            s = (c = c == Gi ? Xi : c) == Xi,
                            f = (l = l == Gi ? Xi : l) == Xi,
                            h = c == l;
                        if (h && Yi(t)) {
                            if (!Yi(e)) return !1;
                            o = !0, s = !1
                        }
                        if (h && !s) return a || (a = new Ri), o || Vi(t) ? Ui(t, e, n, r, i, a) : qi(t, e, c, n, r, i, a);
                        if (!(1 & n)) {
                            var d = s && Qi.call(t, "__wrapped__"),
                                p = f && Qi.call(e, "__wrapped__");
                            if (d || p) {
                                var y = d ? t.value() : t,
                                    v = p ? e.value() : e;
                                return a || (a = new Ri), i(y, v, n, r, a)
                            }
                        }
                        return !!h && (a || (a = new Ri), Bi(t, e, n, r, i, a))
                    },
                    Ji = Zi,
                    ta = xt;
                var ea = function t(e, n, r, i, a) {
                        return e === n || (null == e || null == n || !ta(e) && !ta(n) ? e != e && n != n : Ji(e, n, r, i, t, a))
                    },
                    na = Dn,
                    ra = ea;
                var ia = function(t, e, n, r) {
                        var i = n.length,
                            a = i,
                            o = !r;
                        if (null == t) return !a;
                        for (t = Object(t); i--;) {
                            var u = n[i];
                            if (o && u[2] ? u[1] !== t[u[0]] : !(u[0] in t)) return !1
                        }
                        for (; ++i < a;) {
                            var c = (u = n[i])[0],
                                l = t[c],
                                s = u[1];
                            if (o && u[2]) {
                                if (void 0 === l && !(c in t)) return !1
                            } else {
                                var f = new na;
                                if (r) var h = r(l, s, c, t, e, f);
                                if (!(void 0 === h ? ra(s, l, 3, r, f) : h)) return !1
                            }
                        }
                        return !0
                    },
                    aa = Pt;
                var oa = function(t) {
                        return t == t && !aa(t)
                    },
                    ua = oa,
                    ca = li;
                var la = function(t) {
                    for (var e = ca(t), n = e.length; n--;) {
                        var r = e[n],
                            i = t[r];
                        e[n] = [r, i, ua(i)]
                    }
                    return e
                };
                var sa = function(t, e) {
                        return function(n) {
                            return null != n && (n[t] === e && (void 0 !== e || t in Object(n)))
                        }
                    },
                    fa = ia,
                    ha = la,
                    da = sa;
                var pa = function(t) {
                        var e = ha(t);
                        return 1 == e.length && e[0][2] ? da(e[0][0], e[0][1]) : function(n) {
                            return n === t || fa(n, t, e)
                        }
                    },
                    ya = wn;
                var va = function(t, e, n) {
                    var r = null == t ? void 0 : ya(t, e);
                    return void 0 === r ? n : r
                };
                var ba = function(t, e) {
                        return null != t && e in Object(t)
                    },
                    ga = bn,
                    ma = kr,
                    _a = it,
                    xa = Mr,
                    wa = Tr,
                    ka = mn;
                var Oa = function(t, e, n) {
                        for (var r = -1, i = (e = ga(e, t)).length, a = !1; ++r < i;) {
                            var o = ka(e[r]);
                            if (!(a = null != t && n(t, o))) break;
                            t = t[o]
                        }
                        return a || ++r != i ? a : !!(i = null == t ? 0 : t.length) && wa(i) && xa(o, i) && (_a(t) || ma(t))
                    },
                    Aa = ba,
                    Ea = Oa;
                var Ma = function(t, e) {
                        return null != t && Ea(t, e, Aa)
                    },
                    Ta = ea,
                    ja = va,
                    Pa = Ma,
                    Sa = jt,
                    Ca = oa,
                    Na = sa,
                    Da = mn;
                var Ia = function(t, e) {
                    return Sa(t) && Ca(e) ? Na(Da(t), e) : function(n) {
                        var r = ja(n, t);
                        return void 0 === r && r === e ? Pa(n, t) : Ta(e, r, 3)
                    }
                };
                var La = function(t) {
                    return t
                };
                var za = function(t) {
                        return function(e) {
                            return null == e ? void 0 : e[t]
                        }
                    },
                    Wa = wn;
                var Fa = function(t) {
                        return function(e) {
                            return Wa(e, t)
                        }
                    },
                    Ra = za,
                    Ua = Fa,
                    qa = jt,
                    Ba = mn;
                var Ha = function(t) {
                        return qa(t) ? Ra(Ba(t)) : Ua(t)
                    },
                    Ka = pa,
                    Ya = Ia,
                    Va = La,
                    Ga = it,
                    $a = Ha;
                var Xa = function(t) {
                    return "function" == typeof t ? t : null == t ? Va : "object" == typeof t ? Ga(t) ? Ya(t[0], t[1]) : Ka(t) : $a(t)
                };
                var Qa = function(t) {
                        return function(e, n, r) {
                            for (var i = -1, a = Object(e), o = r(e), u = o.length; u--;) {
                                var c = o[t ? u : ++i];
                                if (!1 === n(a[c], c, a)) break
                            }
                            return e
                        }
                    },
                    Za = Qa(),
                    Ja = li;
                var to = function(t, e) {
                        return t && Za(t, e, Ja)
                    },
                    eo = ai;
                var no = function(t, e) {
                        return function(n, r) {
                            if (null == n) return n;
                            if (!eo(n)) return t(n, r);
                            for (var i = n.length, a = e ? i : -1, o = Object(n);
                                (e ? a-- : ++a < i) && !1 !== r(o[a], a, o););
                            return n
                        }
                    }(to),
                    ro = no,
                    io = ai;
                var ao = function(t, e) {
                        var n = t.length;
                        for (t.sort(e); n--;) t[n] = t[n].value;
                        return t
                    },
                    oo = Ot;
                var uo = function(t, e) {
                    if (t !== e) {
                        var n = void 0 !== t,
                            r = null === t,
                            i = t == t,
                            a = oo(t),
                            o = void 0 !== e,
                            u = null === e,
                            c = e == e,
                            l = oo(e);
                        if (!u && !l && !a && t > e || a && o && c && !u && !l || r && o && c || !n && c || !i) return 1;
                        if (!r && !a && !l && t < e || l && n && i && !r && !a || u && n && i || !o && i || !c) return -1
                    }
                    return 0
                };
                var co = function(t, e, n) {
                        for (var r = -1, i = t.criteria, a = e.criteria, o = i.length, u = n.length; ++r < o;) {
                            var c = uo(i[r], a[r]);
                            if (c) return r >= u ? c : c * ("desc" == n[r] ? -1 : 1)
                        }
                        return t.index - e.index
                    },
                    lo = rt,
                    so = wn,
                    fo = Xa,
                    ho = function(t, e) {
                        var n = -1,
                            r = io(t) ? Array(t.length) : [];
                        return ro(t, (function(t, i, a) {
                            r[++n] = e(t, i, a)
                        })), r
                    },
                    po = ao,
                    yo = Dr,
                    vo = co,
                    bo = La,
                    go = it;
                var mo = function(t, e, n) {
                        e = e.length ? lo(e, (function(t) {
                            return go(t) ? function(e) {
                                return so(e, 1 === t.length ? t[0] : t)
                            } : t
                        })) : [bo];
                        var r = -1;
                        e = lo(e, yo(fo));
                        var i = ho(t, (function(t, n, i) {
                            return {
                                criteria: lo(e, (function(e) {
                                    return e(t)
                                })),
                                index: ++r,
                                value: t
                            }
                        }));
                        return po(i, (function(t, e) {
                            return vo(t, e, n)
                        }))
                    },
                    _o = mo,
                    xo = it;
                var wo = function(t, e, n, r) {
                        return null == t ? [] : (xo(e) || (e = null == e ? [] : [e]), xo(n = r ? void 0 : n) || (n = null == n ? [] : [n]), _o(t, e, n))
                    },
                    ko = Qr(Object.getPrototypeOf, Object),
                    Oo = _t,
                    Ao = ko,
                    Eo = xt,
                    Mo = Function.prototype,
                    To = Object.prototype,
                    jo = Mo.toString,
                    Po = To.hasOwnProperty,
                    So = jo.call(Object);
                var Co = function(t) {
                    if (!Eo(t) || "[object Object]" != Oo(t)) return !1;
                    var e = Ao(t);
                    if (null === e) return !0;
                    var n = Po.call(e, "constructor") && e.constructor;
                    return "function" == typeof n && n instanceof n && jo.call(n) == So
                };

                function No(t, e, n) {
                    t.prototype = e.prototype = n, n.constructor = t
                }

                function Do(t, e) {
                    var n = Object.create(t.prototype);
                    for (var r in e) n[r] = e[r];
                    return n
                }

                function Io() {}
                var Lo = .7,
                    zo = 1 / Lo,
                    Wo = "\\s*([+-]?\\d+)\\s*",
                    Fo = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
                    Ro = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
                    Uo = /^#([0-9a-f]{3,8})$/,
                    qo = new RegExp("^rgb\\(" + [Wo, Wo, Wo] + "\\)$"),
                    Bo = new RegExp("^rgb\\(" + [Ro, Ro, Ro] + "\\)$"),
                    Ho = new RegExp("^rgba\\(" + [Wo, Wo, Wo, Fo] + "\\)$"),
                    Ko = new RegExp("^rgba\\(" + [Ro, Ro, Ro, Fo] + "\\)$"),
                    Yo = new RegExp("^hsl\\(" + [Fo, Ro, Ro] + "\\)$"),
                    Vo = new RegExp("^hsla\\(" + [Fo, Ro, Ro, Fo] + "\\)$"),
                    Go = {
                        aliceblue: 15792383,
                        antiquewhite: 16444375,
                        aqua: 65535,
                        aquamarine: 8388564,
                        azure: 15794175,
                        beige: 16119260,
                        bisque: 16770244,
                        black: 0,
                        blanchedalmond: 16772045,
                        blue: 255,
                        blueviolet: 9055202,
                        brown: 10824234,
                        burlywood: 14596231,
                        cadetblue: 6266528,
                        chartreuse: 8388352,
                        chocolate: 13789470,
                        coral: 16744272,
                        cornflowerblue: 6591981,
                        cornsilk: 16775388,
                        crimson: 14423100,
                        cyan: 65535,
                        darkblue: 139,
                        darkcyan: 35723,
                        darkgoldenrod: 12092939,
                        darkgray: 11119017,
                        darkgreen: 25600,
                        darkgrey: 11119017,
                        darkkhaki: 12433259,
                        darkmagenta: 9109643,
                        darkolivegreen: 5597999,
                        darkorange: 16747520,
                        darkorchid: 10040012,
                        darkred: 9109504,
                        darksalmon: 15308410,
                        darkseagreen: 9419919,
                        darkslateblue: 4734347,
                        darkslategray: 3100495,
                        darkslategrey: 3100495,
                        darkturquoise: 52945,
                        darkviolet: 9699539,
                        deeppink: 16716947,
                        deepskyblue: 49151,
                        dimgray: 6908265,
                        dimgrey: 6908265,
                        dodgerblue: 2003199,
                        firebrick: 11674146,
                        floralwhite: 16775920,
                        forestgreen: 2263842,
                        fuchsia: 16711935,
                        gainsboro: 14474460,
                        ghostwhite: 16316671,
                        gold: 16766720,
                        goldenrod: 14329120,
                        gray: 8421504,
                        green: 32768,
                        greenyellow: 11403055,
                        grey: 8421504,
                        honeydew: 15794160,
                        hotpink: 16738740,
                        indianred: 13458524,
                        indigo: 4915330,
                        ivory: 16777200,
                        khaki: 15787660,
                        lavender: 15132410,
                        lavenderblush: 16773365,
                        lawngreen: 8190976,
                        lemonchiffon: 16775885,
                        lightblue: 11393254,
                        lightcoral: 15761536,
                        lightcyan: 14745599,
                        lightgoldenrodyellow: 16448210,
                        lightgray: 13882323,
                        lightgreen: 9498256,
                        lightgrey: 13882323,
                        lightpink: 16758465,
                        lightsalmon: 16752762,
                        lightseagreen: 2142890,
                        lightskyblue: 8900346,
                        lightslategray: 7833753,
                        lightslategrey: 7833753,
                        lightsteelblue: 11584734,
                        lightyellow: 16777184,
                        lime: 65280,
                        limegreen: 3329330,
                        linen: 16445670,
                        magenta: 16711935,
                        maroon: 8388608,
                        mediumaquamarine: 6737322,
                        mediumblue: 205,
                        mediumorchid: 12211667,
                        mediumpurple: 9662683,
                        mediumseagreen: 3978097,
                        mediumslateblue: 8087790,
                        mediumspringgreen: 64154,
                        mediumturquoise: 4772300,
                        mediumvioletred: 13047173,
                        midnightblue: 1644912,
                        mintcream: 16121850,
                        mistyrose: 16770273,
                        moccasin: 16770229,
                        navajowhite: 16768685,
                        navy: 128,
                        oldlace: 16643558,
                        olive: 8421376,
                        olivedrab: 7048739,
                        orange: 16753920,
                        orangered: 16729344,
                        orchid: 14315734,
                        palegoldenrod: 15657130,
                        palegreen: 10025880,
                        paleturquoise: 11529966,
                        palevioletred: 14381203,
                        papayawhip: 16773077,
                        peachpuff: 16767673,
                        peru: 13468991,
                        pink: 16761035,
                        plum: 14524637,
                        powderblue: 11591910,
                        purple: 8388736,
                        rebeccapurple: 6697881,
                        red: 16711680,
                        rosybrown: 12357519,
                        royalblue: 4286945,
                        saddlebrown: 9127187,
                        salmon: 16416882,
                        sandybrown: 16032864,
                        seagreen: 3050327,
                        seashell: 16774638,
                        sienna: 10506797,
                        silver: 12632256,
                        skyblue: 8900331,
                        slateblue: 6970061,
                        slategray: 7372944,
                        slategrey: 7372944,
                        snow: 16775930,
                        springgreen: 65407,
                        steelblue: 4620980,
                        tan: 13808780,
                        teal: 32896,
                        thistle: 14204888,
                        tomato: 16737095,
                        turquoise: 4251856,
                        violet: 15631086,
                        wheat: 16113331,
                        white: 16777215,
                        whitesmoke: 16119285,
                        yellow: 16776960,
                        yellowgreen: 10145074
                    };

                function $o() {
                    return this.rgb().formatHex()
                }

                function Xo() {
                    return this.rgb().formatRgb()
                }

                function Qo(t) {
                    var e, n;
                    return t = (t + "").trim().toLowerCase(), (e = Uo.exec(t)) ? (n = e[1].length, e = parseInt(e[1], 16), 6 === n ? Zo(e) : 3 === n ? new nu(e >> 8 & 15 | e >> 4 & 240, e >> 4 & 15 | 240 & e, (15 & e) << 4 | 15 & e, 1) : 8 === n ? Jo(e >> 24 & 255, e >> 16 & 255, e >> 8 & 255, (255 & e) / 255) : 4 === n ? Jo(e >> 12 & 15 | e >> 8 & 240, e >> 8 & 15 | e >> 4 & 240, e >> 4 & 15 | 240 & e, ((15 & e) << 4 | 15 & e) / 255) : null) : (e = qo.exec(t)) ? new nu(e[1], e[2], e[3], 1) : (e = Bo.exec(t)) ? new nu(255 * e[1] / 100, 255 * e[2] / 100, 255 * e[3] / 100, 1) : (e = Ho.exec(t)) ? Jo(e[1], e[2], e[3], e[4]) : (e = Ko.exec(t)) ? Jo(255 * e[1] / 100, 255 * e[2] / 100, 255 * e[3] / 100, e[4]) : (e = Yo.exec(t)) ? ou(e[1], e[2] / 100, e[3] / 100, 1) : (e = Vo.exec(t)) ? ou(e[1], e[2] / 100, e[3] / 100, e[4]) : Go.hasOwnProperty(t) ? Zo(Go[t]) : "transparent" === t ? new nu(NaN, NaN, NaN, 0) : null
                }

                function Zo(t) {
                    return new nu(t >> 16 & 255, t >> 8 & 255, 255 & t, 1)
                }

                function Jo(t, e, n, r) {
                    return r <= 0 && (t = e = n = NaN), new nu(t, e, n, r)
                }

                function tu(t) {
                    return t instanceof Io || (t = Qo(t)), t ? new nu((t = t.rgb()).r, t.g, t.b, t.opacity) : new nu
                }

                function eu(t, e, n, r) {
                    return 1 === arguments.length ? tu(t) : new nu(t, e, n, null == r ? 1 : r)
                }

                function nu(t, e, n, r) {
                    this.r = +t, this.g = +e, this.b = +n, this.opacity = +r
                }

                function ru() {
                    return "#" + au(this.r) + au(this.g) + au(this.b)
                }

                function iu() {
                    var t = this.opacity;
                    return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "rgb(" : "rgba(") + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.b) || 0)) + (1 === t ? ")" : ", " + t + ")")
                }

                function au(t) {
                    return ((t = Math.max(0, Math.min(255, Math.round(t) || 0))) < 16 ? "0" : "") + t.toString(16)
                }

                function ou(t, e, n, r) {
                    return r <= 0 ? t = e = n = NaN : n <= 0 || n >= 1 ? t = e = NaN : e <= 0 && (t = NaN), new cu(t, e, n, r)
                }

                function uu(t) {
                    if (t instanceof cu) return new cu(t.h, t.s, t.l, t.opacity);
                    if (t instanceof Io || (t = Qo(t)), !t) return new cu;
                    if (t instanceof cu) return t;
                    var e = (t = t.rgb()).r / 255,
                        n = t.g / 255,
                        r = t.b / 255,
                        i = Math.min(e, n, r),
                        a = Math.max(e, n, r),
                        o = NaN,
                        u = a - i,
                        c = (a + i) / 2;
                    return u ? (o = e === a ? (n - r) / u + 6 * (n < r) : n === a ? (r - e) / u + 2 : (e - n) / u + 4, u /= c < .5 ? a + i : 2 - a - i, o *= 60) : u = c > 0 && c < 1 ? 0 : o, new cu(o, u, c, t.opacity)
                }

                function cu(t, e, n, r) {
                    this.h = +t, this.s = +e, this.l = +n, this.opacity = +r
                }

                function lu(t, e, n) {
                    return 255 * (t < 60 ? e + (n - e) * t / 60 : t < 180 ? n : t < 240 ? e + (n - e) * (240 - t) / 60 : e)
                }
                No(Io, Qo, {
                    copy: function(t) {
                        return Object.assign(new this.constructor, this, t)
                    },
                    displayable: function() {
                        return this.rgb().displayable()
                    },
                    hex: $o,
                    formatHex: $o,
                    formatHsl: function() {
                        return uu(this).formatHsl()
                    },
                    formatRgb: Xo,
                    toString: Xo
                }), No(nu, eu, Do(Io, {
                    brighter: function(t) {
                        return t = null == t ? zo : Math.pow(zo, t), new nu(this.r * t, this.g * t, this.b * t, this.opacity)
                    },
                    darker: function(t) {
                        return t = null == t ? Lo : Math.pow(Lo, t), new nu(this.r * t, this.g * t, this.b * t, this.opacity)
                    },
                    rgb: function() {
                        return this
                    },
                    displayable: function() {
                        return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1
                    },
                    hex: ru,
                    formatHex: ru,
                    formatRgb: iu,
                    toString: iu
                })), No(cu, (function(t, e, n, r) {
                    return 1 === arguments.length ? uu(t) : new cu(t, e, n, null == r ? 1 : r)
                }), Do(Io, {
                    brighter: function(t) {
                        return t = null == t ? zo : Math.pow(zo, t), new cu(this.h, this.s, this.l * t, this.opacity)
                    },
                    darker: function(t) {
                        return t = null == t ? Lo : Math.pow(Lo, t), new cu(this.h, this.s, this.l * t, this.opacity)
                    },
                    rgb: function() {
                        var t = this.h % 360 + 360 * (this.h < 0),
                            e = isNaN(t) || isNaN(this.s) ? 0 : this.s,
                            n = this.l,
                            r = n + (n < .5 ? n : 1 - n) * e,
                            i = 2 * n - r;
                        return new nu(lu(t >= 240 ? t - 240 : t + 120, i, r), lu(t, i, r), lu(t < 120 ? t + 240 : t - 120, i, r), this.opacity)
                    },
                    displayable: function() {
                        return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
                    },
                    formatHsl: function() {
                        var t = this.opacity;
                        return (1 === (t = isNaN(t) ? 1 : Math.max(0, Math.min(1, t))) ? "hsl(" : "hsla(") + (this.h || 0) + ", " + 100 * (this.s || 0) + "%, " + 100 * (this.l || 0) + "%" + (1 === t ? ")" : ", " + t + ")")
                    }
                }));
                var su = Math.PI / 180,
                    fu = 180 / Math.PI,
                    hu = -.14861,
                    du = 1.78277,
                    pu = -.29227,
                    yu = -.90649,
                    vu = 1.97294,
                    bu = vu * yu,
                    gu = vu * du,
                    mu = du * pu - yu * hu;

                function _u(t) {
                    if (t instanceof wu) return new wu(t.h, t.s, t.l, t.opacity);
                    t instanceof nu || (t = tu(t));
                    var e = t.r / 255,
                        n = t.g / 255,
                        r = t.b / 255,
                        i = (mu * r + bu * e - gu * n) / (mu + bu - gu),
                        a = r - i,
                        o = (vu * (n - i) - pu * a) / yu,
                        u = Math.sqrt(o * o + a * a) / (vu * i * (1 - i)),
                        c = u ? Math.atan2(o, a) * fu - 120 : NaN;
                    return new wu(c < 0 ? c + 360 : c, u, i, t.opacity)
                }

                function xu(t, e, n, r) {
                    return 1 === arguments.length ? _u(t) : new wu(t, e, n, null == r ? 1 : r)
                }

                function wu(t, e, n, r) {
                    this.h = +t, this.s = +e, this.l = +n, this.opacity = +r
                }

                function ku(t) {
                    return function() {
                        return t
                    }
                }

                function Ou(t, e) {
                    return function(n) {
                        return t + n * e
                    }
                }

                function Au(t) {
                    return 1 == (t = +t) ? Eu : function(e, n) {
                        return n - e ? function(t, e, n) {
                            return t = Math.pow(t, n), e = Math.pow(e, n) - t, n = 1 / n,
                                function(r) {
                                    return Math.pow(t + r * e, n)
                                }
                        }(e, n, t) : ku(isNaN(e) ? n : e)
                    }
                }

                function Eu(t, e) {
                    var n = e - t;
                    return n ? Ou(t, n) : ku(isNaN(t) ? e : t)
                }
                No(wu, xu, Do(Io, {
                    brighter: function(t) {
                        return t = null == t ? zo : Math.pow(zo, t), new wu(this.h, this.s, this.l * t, this.opacity)
                    },
                    darker: function(t) {
                        return t = null == t ? Lo : Math.pow(Lo, t), new wu(this.h, this.s, this.l * t, this.opacity)
                    },
                    rgb: function() {
                        var t = isNaN(this.h) ? 0 : (this.h + 120) * su,
                            e = +this.l,
                            n = isNaN(this.s) ? 0 : this.s * e * (1 - e),
                            r = Math.cos(t),
                            i = Math.sin(t);
                        return new nu(255 * (e + n * (hu * r + du * i)), 255 * (e + n * (pu * r + yu * i)), 255 * (e + n * (vu * r)), this.opacity)
                    }
                }));
                var Mu = function t(e) {
                    var n = Au(e);

                    function r(t, e) {
                        var r = n((t = eu(t)).r, (e = eu(e)).r),
                            i = n(t.g, e.g),
                            a = n(t.b, e.b),
                            o = Eu(t.opacity, e.opacity);
                        return function(e) {
                            return t.r = r(e), t.g = i(e), t.b = a(e), t.opacity = o(e), t + ""
                        }
                    }
                    return r.gamma = t, r
                }(1);

                function Tu(t, e) {
                    e || (e = []);
                    var n, r = t ? Math.min(e.length, t.length) : 0,
                        i = e.slice();
                    return function(a) {
                        for (n = 0; n < r; ++n) i[n] = t[n] * (1 - a) + e[n] * a;
                        return i
                    }
                }

                function ju(t, e) {
                    var n, r = e ? e.length : 0,
                        i = t ? Math.min(r, t.length) : 0,
                        a = new Array(i),
                        o = new Array(r);
                    for (n = 0; n < i; ++n) a[n] = Lu(t[n], e[n]);
                    for (; n < r; ++n) o[n] = e[n];
                    return function(t) {
                        for (n = 0; n < i; ++n) o[n] = a[n](t);
                        return o
                    }
                }

                function Pu(t, e) {
                    var n = new Date;
                    return t = +t, e = +e,
                        function(r) {
                            return n.setTime(t * (1 - r) + e * r), n
                        }
                }

                function Su(t, e) {
                    return t = +t, e = +e,
                        function(n) {
                            return t * (1 - n) + e * n
                        }
                }

                function Cu(t, e) {
                    var n, r = {},
                        i = {};
                    for (n in null !== t && "object" == typeof t || (t = {}), null !== e && "object" == typeof e || (e = {}), e) n in t ? r[n] = Lu(t[n], e[n]) : i[n] = e[n];
                    return function(t) {
                        for (n in r) i[n] = r[n](t);
                        return i
                    }
                }
                var Nu = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
                    Du = new RegExp(Nu.source, "g");

                function Iu(t, e) {
                    var n, r, i, a = Nu.lastIndex = Du.lastIndex = 0,
                        o = -1,
                        u = [],
                        c = [];
                    for (t += "", e += "";
                        (n = Nu.exec(t)) && (r = Du.exec(e));)(i = r.index) > a && (i = e.slice(a, i), u[o] ? u[o] += i : u[++o] = i), (n = n[0]) === (r = r[0]) ? u[o] ? u[o] += r : u[++o] = r : (u[++o] = null, c.push({
                        i: o,
                        x: Su(n, r)
                    })), a = Du.lastIndex;
                    return a < e.length && (i = e.slice(a), u[o] ? u[o] += i : u[++o] = i), u.length < 2 ? c[0] ? function(t) {
                        return function(e) {
                            return t(e) + ""
                        }
                    }(c[0].x) : function(t) {
                        return function() {
                            return t
                        }
                    }(e) : (e = c.length, function(t) {
                        for (var n, r = 0; r < e; ++r) u[(n = c[r]).i] = n.x(t);
                        return u.join("")
                    })
                }

                function Lu(t, e) {
                    var n, r = typeof e;
                    return null == e || "boolean" === r ? ku(e) : ("number" === r ? Su : "string" === r ? (n = Qo(e)) ? (e = n, Mu) : Iu : e instanceof Qo ? Mu : e instanceof Date ? Pu : function(t) {
                        return ArrayBuffer.isView(t) && !(t instanceof DataView)
                    }(e) ? Tu : Array.isArray(e) ? ju : "function" != typeof e.valueOf && "function" != typeof e.toString || isNaN(e) ? Cu : Su)(t, e)
                }

                function zu(t, e) {
                    return t = +t, e = +e,
                        function(n) {
                            return Math.round(t * (1 - n) + e * n)
                        }
                }

                function Wu(t) {
                    return function e(n) {
                        function r(e, r) {
                            var i = t((e = xu(e)).h, (r = xu(r)).h),
                                a = Eu(e.s, r.s),
                                o = Eu(e.l, r.l),
                                u = Eu(e.opacity, r.opacity);
                            return function(t) {
                                return e.h = i(t), e.s = a(t), e.l = o(Math.pow(t, n)), e.opacity = u(t), e + ""
                            }
                        }
                        return n = +n, r.gamma = e, r
                    }(1)
                }
                Wu((function(t, e) {
                    var n = e - t;
                    return n ? Ou(t, n > 180 || n < -180 ? n - 360 * Math.round(n / 360) : n) : ku(isNaN(t) ? e : t)
                }));
                var Fu, Ru, Uu = Wu(Eu),
                    qu = function(t) {
                        if (null !== t) switch (typeof t) {
                            case "undefined":
                            case "boolean":
                                return !1;
                            case "number":
                                return !isNaN(t) && t !== Number.POSITIVE_INFINITY && t !== Number.NEGATIVE_INFINITY;
                            case "string":
                            case "function":
                                return !0;
                            case "object":
                                return t instanceof Date || Array.isArray(t) || Co(t)
                        }
                        return !1
                    },
                    Bu = function(t, e) {
                        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                        return function(r) {
                            return r < n ? t : e
                        }
                    },
                    Hu = function(t, e) {
                        return function(n) {
                            return n >= 1 ? e : function() {
                                var r = "function" == typeof t ? t.apply(this, arguments) : t,
                                    i = "function" == typeof e ? e.apply(this, arguments) : e;
                                return Lu(r, i)(n)
                            }
                        }
                    },
                    Ku = function(t, e) {
                        var n, r = function(t, e) {
                                return t !== e && qu(t) && qu(e) ? "function" == typeof t || "function" == typeof e ? Hu(t, e) : "object" == typeof t && Co(t) || "object" == typeof e && Co(e) ? Ku(t, e) : Lu(t, e) : Bu(t, e)
                            },
                            i = function(t) {
                                return Array.isArray(t) ? wo(t, "key") : t
                            },
                            a = {},
                            o = {};
                        for (n in null !== t && "object" == typeof t || (t = {}), null !== e && "object" == typeof e || (e = {}), e) n in t ? a[n] = r(i(t[n]), i(e[n])) : o[n] = e[n];
                        return function(t) {
                            for (n in a) o[n] = a[n](t);
                            return o
                        }
                    },
                    Yu = function(t, e) {
                        return t !== e && qu(t) && qu(e) ? "function" == typeof t || "function" == typeof e ? Hu(t, e) : Co(t) || Co(e) ? Ku(t, e) : "string" == typeof t || "string" == typeof e ? function(t, e) {
                            var n = function(t) {
                                return "string" == typeof t ? t.replace(/,/g, "") : t
                            };
                            return Lu(n(t), n(e))
                        }(t, e) : Lu(t, e) : Bu(t, e)
                    },
                    Vu = 0,
                    Gu = 0,
                    $u = 0,
                    Xu = 0,
                    Qu = 0,
                    Zu = 0,
                    Ju = "object" == typeof performance && performance.now ? performance : Date,
                    tc = "object" == typeof window && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(t) {
                        setTimeout(t, 17)
                    };

                function ec() {
                    return Qu || (tc(nc), Qu = Ju.now() + Zu)
                }

                function nc() {
                    Qu = 0
                }

                function rc() {
                    this._call = this._time = this._next = null
                }

                function ic(t, e, n) {
                    var r = new rc;
                    return r.restart(t, e, n), r
                }

                function ac() {
                    Qu = (Xu = Ju.now()) + Zu, Vu = Gu = 0;
                    try {
                        ! function() {
                            ec(), ++Vu;
                            for (var t, e = Fu; e;)(t = Qu - e._time) >= 0 && e._call.call(null, t), e = e._next;
                            --Vu
                        }()
                    } finally {
                        Vu = 0,
                            function() {
                                var t, e, n = Fu,
                                    r = 1 / 0;
                                for (; n;) n._call ? (r > n._time && (r = n._time), t = n, n = n._next) : (e = n._next, n._next = null, n = t ? t._next = e : Fu = e);
                                Ru = t, uc(r)
                            }(), Qu = 0
                    }
                }

                function oc() {
                    var t = Ju.now(),
                        e = t - Xu;
                    e > 1e3 && (Zu -= e, Xu = t)
                }

                function uc(t) {
                    Vu || (Gu && (Gu = clearTimeout(Gu)), t - Qu > 24 ? (t < 1 / 0 && (Gu = setTimeout(ac, t - Ju.now() - Zu)), $u && ($u = clearInterval($u))) : ($u || (Xu = Ju.now(), $u = setInterval(oc, 1e3)), Vu = 1, tc(ac)))
                }

                function cc(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }
                rc.prototype = ic.prototype = {
                    constructor: rc,
                    restart: function(t, e, n) {
                        if ("function" != typeof t) throw new TypeError("callback is not a function");
                        n = (null == n ? ec() : +n) + (null == e ? 0 : +e), this._next || Ru === this || (Ru ? Ru._next = this : Fu = this, Ru = this), this._call = t, this._time = n, uc()
                    },
                    stop: function() {
                        this._call && (this._call = null, this._time = 1 / 0, uc())
                    }
                };
                var lc = function() {
                        function t() {
                            ! function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, t), this.shouldAnimate = !0, this.subscribers = [], this.loop = this.loop.bind(this), this.timer = null, this.activeSubscriptions = 0
                        }
                        var e, n, r;
                        return e = t, n = [{
                            key: "bypassAnimation",
                            value: function() {
                                this.shouldAnimate = !1
                            }
                        }, {
                            key: "resumeAnimation",
                            value: function() {
                                this.shouldAnimate = !0
                            }
                        }, {
                            key: "loop",
                            value: function() {
                                this.subscribers.forEach((function(t) {
                                    t.callback(ec() - t.startTime, t.duration)
                                }))
                            }
                        }, {
                            key: "start",
                            value: function() {
                                this.timer || (this.timer = ic(this.loop))
                            }
                        }, {
                            key: "stop",
                            value: function() {
                                this.timer && (this.timer.stop(), this.timer = null)
                            }
                        }, {
                            key: "subscribe",
                            value: function(t, e) {
                                e = this.shouldAnimate ? e : 0;
                                var n = this.subscribers.push({
                                    startTime: ec(),
                                    callback: t,
                                    duration: e
                                });
                                return this.activeSubscriptions++, this.start(), n
                            }
                        }, {
                            key: "unsubscribe",
                            value: function(t) {
                                null !== t && this.subscribers[t - 1] && (delete this.subscribers[t - 1], this.activeSubscriptions--), 0 === this.activeSubscriptions && this.stop()
                            }
                        }], n && cc(e.prototype, n), r && cc(e, r), t
                    }(),
                    sc = n.createContext({
                        transitionTimer: new lc,
                        animationTimer: new lc
                    });
                sc.displayName = "TimerContext";
                var fc = sc,
                    hc = Array.isArray,
                    dc = Object.keys,
                    pc = Object.prototype.hasOwnProperty,
                    yc = "undefined" != typeof Element;

                function vc(t, e) {
                    if (t === e) return !0;
                    if (t && e && "object" == typeof t && "object" == typeof e) {
                        var n, r, i, a = hc(t),
                            o = hc(e);
                        if (a && o) {
                            if ((r = t.length) != e.length) return !1;
                            for (n = r; 0 != n--;)
                                if (!vc(t[n], e[n])) return !1;
                            return !0
                        }
                        if (a != o) return !1;
                        var u = t instanceof Date,
                            c = e instanceof Date;
                        if (u != c) return !1;
                        if (u && c) return t.getTime() == e.getTime();
                        var l = t instanceof RegExp,
                            s = e instanceof RegExp;
                        if (l != s) return !1;
                        if (l && s) return t.toString() == e.toString();
                        var f = dc(t);
                        if ((r = f.length) !== dc(e).length) return !1;
                        for (n = r; 0 != n--;)
                            if (!pc.call(e, f[n])) return !1;
                        if (yc && t instanceof Element && e instanceof Element) return t === e;
                        for (n = r; 0 != n--;)
                            if (!("_owner" === (i = f[n]) && t.$$typeof || vc(t[i], e[i]))) return !1;
                        return !0
                    }
                    return t != t && e != e
                }
                var bc = function(t, e) {
                    try {
                        return vc(t, e)
                    } catch (n) {
                        if (n.message && n.message.match(/stack|recursion/i) || -2146828260 === n.number) return console.warn("Warning: react-fast-compare does not handle circular references.", n.name, n.message), !1;
                        throw n
                    }
                };

                function gc(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function mc(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function _c(t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }
                var xc = function(t) {
                    function e(t, n) {
                        var r;
                        return function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), (r = function(t, e) {
                            return !e || "object" != typeof e && "function" != typeof e ? _c(t) : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t, n))).state = {
                            data: Array.isArray(r.props.data) ? r.props.data[0] : r.props.data,
                            animationInfo: {
                                progress: 0,
                                animating: !1
                            }
                        }, r.interpolator = null, r.queue = Array.isArray(r.props.data) ? r.props.data.slice(1) : [], r.ease = nt[r.toNewName(r.props.easing)], r.functionToBeRunEachFrame = r.functionToBeRunEachFrame.bind(_c(r)), r.timer = r.context.animationTimer, r
                    }
                    var n, r, i;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), n = e, r = [{
                        key: "componentDidMount",
                        value: function() {
                            this.queue.length && this.traverseQueue()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function(t) {
                            if (!bc(this.props, t))
                                if (this.interpolator && this.state.animationInfo && this.state.animationInfo.progress < 1) this.setState({
                                    data: this.interpolator(1),
                                    animationInfo: {
                                        progress: 1,
                                        animating: !1,
                                        terminating: !0
                                    }
                                });
                                else {
                                    var e;
                                    this.timer.unsubscribe(this.loopID), Array.isArray(this.props.data) ? (e = this.queue).push.apply(e, gc(this.props.data)) : (this.queue.length = 0, this.queue.push(this.props.data)), this.traverseQueue()
                                }
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.loopID ? this.timer.unsubscribe(this.loopID) : this.timer.stop()
                        }
                    }, {
                        key: "toNewName",
                        value: function(t) {
                            return "ease".concat(function(t) {
                                return t && t[0].toUpperCase() + t.slice(1)
                            }(t))
                        }
                    }, {
                        key: "traverseQueue",
                        value: function() {
                            var t = this;
                            if (this.queue.length) {
                                var e = this.queue[0];
                                this.interpolator = Yu(this.state.data, e), this.props.delay ? setTimeout((function() {
                                    t.loopID = t.timer.subscribe(t.functionToBeRunEachFrame, t.props.duration)
                                }), this.props.delay) : this.loopID = this.timer.subscribe(this.functionToBeRunEachFrame, this.props.duration)
                            } else this.props.onEnd && this.props.onEnd()
                        }
                    }, {
                        key: "functionToBeRunEachFrame",
                        value: function(t, e) {
                            var n = (e = void 0 !== e ? e : this.props.duration) ? t / e : 1;
                            if (n >= 1) return this.setState({
                                data: this.interpolator(1),
                                animationInfo: {
                                    progress: 1,
                                    animating: !1,
                                    terminating: !0
                                }
                            }), this.loopID && this.timer.unsubscribe(this.loopID), this.queue.shift(), void this.traverseQueue();
                            this.setState({
                                data: this.interpolator(this.ease(n)),
                                animationInfo: {
                                    progress: n,
                                    animating: n < 1
                                }
                            })
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return this.props.children(this.state.data, this.state.animationInfo)
                        }
                    }], r && mc(n.prototype, r), i && mc(n, i), e
                }(n.Component);
                Object.defineProperty(xc, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryAnimation"
                }), Object.defineProperty(xc, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        children: C.func,
                        data: C.oneOfType([C.object, C.array]),
                        delay: C.number,
                        duration: C.number,
                        easing: C.oneOf(["back", "backIn", "backOut", "backInOut", "bounce", "bounceIn", "bounceOut", "bounceInOut", "circle", "circleIn", "circleOut", "circleInOut", "linear", "linearIn", "linearOut", "linearInOut", "cubic", "cubicIn", "cubicOut", "cubicInOut", "elastic", "elasticIn", "elasticOut", "elasticInOut", "exp", "expIn", "expOut", "expInOut", "poly", "polyIn", "polyOut", "polyInOut", "quad", "quadIn", "quadOut", "quadInOut", "sin", "sinIn", "sinOut", "sinInOut"]),
                        onEnd: C.func
                    }
                }), Object.defineProperty(xc, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        data: {},
                        delay: 0,
                        duration: 1e3,
                        easing: "quadInOut"
                    }
                }), Object.defineProperty(xc, "contextType", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: fc
                });
                var wc = hn,
                    kc = 0;
                var Oc = function(t) {
                    var e = ++kc;
                    return wc(t) + e
                };
                var Ac = function(t, e, n) {
                        switch (n.length) {
                            case 0:
                                return t.call(e);
                            case 1:
                                return t.call(e, n[0]);
                            case 2:
                                return t.call(e, n[0], n[1]);
                            case 3:
                                return t.call(e, n[0], n[1], n[2])
                        }
                        return t.apply(e, n)
                    },
                    Ec = Math.max;
                var Mc = function(t, e, n) {
                    return e = Ec(void 0 === e ? t.length - 1 : e, 0),
                        function() {
                            for (var r = arguments, i = -1, a = Ec(r.length - e, 0), o = Array(a); ++i < a;) o[i] = r[e + i];
                            i = -1;
                            for (var u = Array(e + 1); ++i < e;) u[i] = r[i];
                            return u[e] = n(o), Ac(t, this, u)
                        }
                };
                var Tc = function(t) {
                        return function() {
                            return t
                        }
                    },
                    jc = te,
                    Pc = function() {
                        try {
                            var t = jc(Object, "defineProperty");
                            return t({}, "", {}), t
                        } catch (e) {}
                    }(),
                    Sc = Tc,
                    Cc = Pc,
                    Nc = Cc ? function(t, e) {
                        return Cc(t, "toString", {
                            configurable: !0,
                            enumerable: !1,
                            value: Sc(e),
                            writable: !0
                        })
                    } : La,
                    Dc = Nc,
                    Ic = Date.now;
                var Lc = function(t) {
                        var e = 0,
                            n = 0;
                        return function() {
                            var r = Ic(),
                                i = 16 - (r - n);
                            if (n = r, i > 0) {
                                if (++e >= 800) return arguments[0]
                            } else e = 0;
                            return t.apply(void 0, arguments)
                        }
                    },
                    zc = Lc(Dc),
                    Wc = La,
                    Fc = Mc,
                    Rc = zc;
                var Uc = function(t, e) {
                        return Rc(Fc(t, e, Wc), t + "")
                    },
                    qc = me,
                    Bc = ai,
                    Hc = Mr,
                    Kc = Pt;
                var Yc = function(t, e, n) {
                    if (!Kc(n)) return !1;
                    var r = typeof e;
                    return !!("number" == r ? Bc(n) && Hc(e, n.length) : "string" == r && e in n) && qc(n[e], t)
                };
                var Vc = function(t) {
                        var e = [];
                        if (null != t)
                            for (var n in Object(t)) e.push(n);
                        return e
                    },
                    Gc = Pt,
                    $c = Xr,
                    Xc = Vc,
                    Qc = Object.prototype.hasOwnProperty;
                var Zc = function(t) {
                        if (!Gc(t)) return Xc(t);
                        var e = $c(t),
                            n = [];
                        for (var r in t)("constructor" != r || !e && Qc.call(t, r)) && n.push(r);
                        return n
                    },
                    Jc = Gr,
                    tl = Zc,
                    el = ai;
                var nl = function(t) {
                        return el(t) ? Jc(t, !0) : tl(t)
                    },
                    rl = Uc,
                    il = me,
                    al = Yc,
                    ol = nl,
                    ul = Object.prototype,
                    cl = ul.hasOwnProperty,
                    ll = rl((function(t, e) {
                        t = Object(t);
                        var n = -1,
                            r = e.length,
                            i = r > 2 ? e[2] : void 0;
                        for (i && al(e[0], e[1], i) && (r = 1); ++n < r;)
                            for (var a = e[n], o = ol(a), u = -1, c = o.length; ++u < c;) {
                                var l = o[u],
                                    s = t[l];
                                (void 0 === s || il(s, ul[l]) && !cl.call(t, l)) && (t[l] = a[l])
                            }
                        return t
                    })),
                    sl = ll,
                    fl = Pc;
                var hl = function(t, e, n) {
                        "__proto__" == e && fl ? fl(t, e, {
                            configurable: !0,
                            enumerable: !0,
                            value: n,
                            writable: !0
                        }) : t[e] = n
                    },
                    dl = hl,
                    pl = me,
                    yl = Object.prototype.hasOwnProperty;
                var vl = function(t, e, n) {
                        var r = t[e];
                        yl.call(t, e) && pl(r, n) && (void 0 !== n || e in t) || dl(t, e, n)
                    },
                    bl = vl,
                    gl = hl;
                var ml = function(t, e, n, r) {
                        var i = !n;
                        n || (n = {});
                        for (var a = -1, o = e.length; ++a < o;) {
                            var u = e[a],
                                c = r ? r(n[u], t[u], u, n, t) : void 0;
                            void 0 === c && (c = t[u]), i ? gl(n, u, c) : bl(n, u, c)
                        }
                        return n
                    },
                    _l = Uc,
                    xl = Yc;
                var wl = function(t) {
                        return _l((function(e, n) {
                            var r = -1,
                                i = n.length,
                                a = i > 1 ? n[i - 1] : void 0,
                                o = i > 2 ? n[2] : void 0;
                            for (a = t.length > 3 && "function" == typeof a ? (i--, a) : void 0, o && xl(n[0], n[1], o) && (a = i < 3 ? void 0 : a, i = 1), e = Object(e); ++r < i;) {
                                var u = n[r];
                                u && t(e, u, r, a)
                            }
                            return e
                        }))
                    },
                    kl = vl,
                    Ol = ml,
                    Al = wl,
                    El = ai,
                    Ml = Xr,
                    Tl = li,
                    jl = Object.prototype.hasOwnProperty,
                    Pl = Al((function(t, e) {
                        if (Ml(e) || El(e)) Ol(e, Tl(e), t);
                        else
                            for (var n in e) jl.call(e, n) && kl(t, n, e[n])
                    })),
                    Sl = Pl,
                    Cl = _t,
                    Nl = xt;
                var Dl = function(t) {
                        return Nl(t) && "[object RegExp]" == Cl(t)
                    },
                    Il = Dr,
                    Ll = Ir.exports,
                    zl = Ll && Ll.isRegExp,
                    Wl = zl ? Il(zl) : Dl,
                    Fl = Xa,
                    Rl = ai,
                    Ul = li;
                var ql = function(t) {
                    return function(e, n, r) {
                        var i = Object(e);
                        if (!Rl(e)) {
                            var a = Fl(n);
                            e = Ul(e), n = function(t) {
                                return a(i[t], t, i)
                            }
                        }
                        var o = t(e, n, r);
                        return o > -1 ? i[a ? e[o] : o] : void 0
                    }
                };
                var Bl = function(t, e, n, r) {
                        for (var i = t.length, a = n + (r ? 1 : -1); r ? a-- : ++a < i;)
                            if (e(t[a], a, t)) return a;
                        return -1
                    },
                    Hl = /\s/;
                var Kl = function(t) {
                        for (var e = t.length; e-- && Hl.test(t.charAt(e)););
                        return e
                    },
                    Yl = Kl,
                    Vl = /^\s+/;
                var Gl = function(t) {
                        return t ? t.slice(0, Yl(t) + 1).replace(Vl, "") : t
                    },
                    $l = Gl,
                    Xl = Pt,
                    Ql = Ot,
                    Zl = /^[-+]0x[0-9a-f]+$/i,
                    Jl = /^0b[01]+$/i,
                    ts = /^0o[0-7]+$/i,
                    es = parseInt;
                var ns = function(t) {
                        if ("number" == typeof t) return t;
                        if (Ql(t)) return NaN;
                        if (Xl(t)) {
                            var e = "function" == typeof t.valueOf ? t.valueOf() : t;
                            t = Xl(e) ? e + "" : e
                        }
                        if ("string" != typeof t) return 0 === t ? t : +t;
                        t = $l(t);
                        var n = Jl.test(t);
                        return n || ts.test(t) ? es(t.slice(2), n ? 2 : 8) : Zl.test(t) ? NaN : +t
                    },
                    rs = ns,
                    is = 1 / 0;
                var as = function(t) {
                        return t ? (t = rs(t)) === is || t === -1 / 0 ? 17976931348623157e292 * (t < 0 ? -1 : 1) : t == t ? t : 0 : 0 === t ? t : 0
                    },
                    os = as;
                var us = function(t) {
                        var e = os(t),
                            n = e % 1;
                        return e == e ? n ? e - n : e : 0
                    },
                    cs = Bl,
                    ls = Xa,
                    ss = us,
                    fs = Math.max;
                var hs = function(t, e, n) {
                        var r = null == t ? 0 : t.length;
                        if (!r) return -1;
                        var i = null == n ? 0 : ss(n);
                        return i < 0 && (i = fs(r + i, 0)), cs(t, ls(e), i)
                    },
                    ds = ql(hs);
                var ps = function(t) {
                        var e = function(e, n, r, i) {
                                var a = n[r];
                                if (null == a) return e ? new Error("Required `".concat(r, "` was not specified in `").concat(i, "`.")) : null;
                                for (var o = arguments.length, u = new Array(o > 4 ? o - 4 : 0), c = 4; c < o; c++) u[c - 4] = arguments[c];
                                return t.apply(void 0, [n, r, i].concat(u))
                            },
                            n = e.bind(null, !1);
                        return n.isRequired = e.bind(null, !0), n
                    },
                    ys = function() {
                        return null
                    },
                    vs = function() {},
                    bs = function(t) {
                        return void 0 === t ? vs : null === t ? ys : t.constructor
                    },
                    gs = function(t) {
                        return void 0 === t ? "undefined" : null === t ? "null" : Object.prototype.toString.call(t).slice(8, -1)
                    };

                function ms(t) {
                    return ps((function(e, n, r) {
                        for (var i = arguments.length, a = new Array(i > 3 ? i - 3 : 0), o = 3; o < i; o++) a[o - 3] = arguments[o];
                        return t.reduce((function(t, i) {
                            return t || i.apply(void 0, [e, n, r].concat(a))
                        }), void 0)
                    }))
                }
                var _s = ps((function(t, e, n) {
                        var r = t[e];
                        if ("number" != typeof r || r < 0) return new Error("`".concat(e, "` in `").concat(n, "` must be a non-negative number."))
                    })),
                    xs = ps((function(t, e, n) {
                        var r = t[e];
                        if ("number" != typeof r || r % 1 != 0) return new Error("`".concat(e, "` in `").concat(n, "` must be an integer."))
                    }));
                ps((function(t, e, n) {
                    var r = t[e];
                    if ("number" != typeof r || r <= 0) return new Error("`".concat(e, "` in `").concat(n, "` must be a number greater than zero."))
                }));
                var ws = ps((function(t, e, n) {
                        var r = t[e];
                        if (!Array.isArray(r) || 2 !== r.length || r[1] === r[0]) return new Error("`".concat(e, "` in `").concat(n, "` must be an array of two unique numeric values."))
                    })),
                    ks = ps((function(t, e, n) {
                        var r, i = ["linear", "time", "log", "sqrt"],
                            a = t[e];
                        if (!(It(r = a) ? It(r.copy) && It(r.domain) && It(r.range) : "string" == typeof r && -1 !== i.indexOf(r))) return new Error("`".concat(e, "` in `").concat(n, "` must be a d3 scale."))
                    }));
                ps((function(t, e, n) {
                    var r = t[e];
                    if (!Array.isArray(r)) return new Error("`".concat(e, "` in `").concat(n, "` must be an array."));
                    if (!(r.length < 2)) {
                        var i = bs(r[0]),
                            a = ds(r, (function(t) {
                                return i !== bs(t)
                            }));
                        if (a) {
                            var o = gs(r[0]),
                                u = gs(a);
                            return new Error("Expected `".concat(e, "` in `").concat(n, "` to be a ") + "homogeneous array, but found types `".concat(o, "` and ") + "`".concat(u, "`."))
                        }
                    }
                })), ps((function(t, e) {
                    if (t[e] && Array.isArray(t[e]) && t[e].length !== t.data.length) return new Error("Length of data and ".concat(e, " arrays must match."))
                }));
                var Os = ps((function(t, e, n) {
                    if (t[e] && !Wl(t[e])) return new Error("`".concat(e, "` in `").concat(n, "` must be a regular expression."))
                }));

                function As(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function Es(t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }
                var Ms = function(t) {
                    function e(t) {
                        var n;
                        return function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), (n = function(t, e) {
                            return !e || "object" != typeof e && "function" != typeof e ? Es(t) : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t))).map = {}, n.index = 1, n.portalUpdate = n.portalUpdate.bind(Es(n)), n.portalRegister = n.portalRegister.bind(Es(n)), n.portalDeregister = n.portalDeregister.bind(Es(n)), n
                    }
                    var r, i, a;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), r = e, (i = [{
                        key: "portalRegister",
                        value: function() {
                            return ++this.index
                        }
                    }, {
                        key: "portalUpdate",
                        value: function(t, e) {
                            this.map[t] = e, this.forceUpdate()
                        }
                    }, {
                        key: "portalDeregister",
                        value: function(t) {
                            delete this.map[t], this.forceUpdate()
                        }
                    }, {
                        key: "getChildren",
                        value: function() {
                            var t = this;
                            return si(this.map).map((function(e) {
                                var r = t.map[e];
                                return r ? n.cloneElement(r, {
                                    key: e
                                }) : r
                            }))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            return n.createElement("svg", this.props, this.getChildren())
                        }
                    }]) && As(r.prototype, i), a && As(r, a), e
                }(n.Component);
                Object.defineProperty(Ms, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "Portal"
                }), Object.defineProperty(Ms, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        className: C.string,
                        height: _s,
                        style: C.object,
                        viewBox: C.string,
                        width: _s
                    }
                });
                var Ts = n.createContext({});
                Ts.displayName = "PortalContext";
                var js = Ts,
                    Ps = vl,
                    Ss = bn,
                    Cs = Mr,
                    Ns = Pt,
                    Ds = mn;
                var Is = function(t, e, n, r) {
                        if (!Ns(t)) return t;
                        for (var i = -1, a = (e = Ss(e, t)).length, o = a - 1, u = t; null != u && ++i < a;) {
                            var c = Ds(e[i]),
                                l = n;
                            if ("__proto__" === c || "constructor" === c || "prototype" === c) return t;
                            if (i != o) {
                                var s = u[c];
                                void 0 === (l = r ? r(s, c, u) : void 0) && (l = Ns(s) ? s : Cs(e[i + 1]) ? [] : {})
                            }
                            Ps(u, c, l), u = u[c]
                        }
                        return t
                    },
                    Ls = wn,
                    zs = Is,
                    Ws = bn;
                var Fs = function(t, e, n) {
                        for (var r = -1, i = e.length, a = {}; ++r < i;) {
                            var o = e[r],
                                u = Ls(t, o);
                            n(u, o) && zs(a, Ws(o, t), u)
                        }
                        return a
                    },
                    Rs = Fs,
                    Us = Ma;
                var qs = function(t, e) {
                        return Rs(t, e, (function(e, n) {
                            return Us(t, n)
                        }))
                    },
                    Bs = kr,
                    Hs = it,
                    Ks = lt ? lt.isConcatSpreadable : void 0;
                var Ys = nr,
                    Vs = function(t) {
                        return Hs(t) || Bs(t) || !!(Ks && t && t[Ks])
                    };
                var Gs = function t(e, n, r, i, a) {
                        var o = -1,
                            u = e.length;
                        for (r || (r = Vs), a || (a = []); ++o < u;) {
                            var c = e[o];
                            n > 0 && r(c) ? n > 1 ? t(c, n - 1, r, i, a) : Ys(a, c) : i || (a[a.length] = c)
                        }
                        return a
                    },
                    $s = Gs;
                var Xs = function(t) {
                        return (null == t ? 0 : t.length) ? $s(t, 1) : []
                    },
                    Qs = Xs,
                    Zs = Mc,
                    Js = zc;
                var tf = qs,
                    ef = function(t) {
                        return Js(Zs(t, void 0, Qs), t + "")
                    }((function(t, e) {
                        return null == t ? {} : tf(t, e)
                    })),
                    nf = ef;

                function rf(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                        n = {};
                    for (var r in t) e.indexOf(r) >= 0 || Object.prototype.hasOwnProperty.call(t, r) && (n[r] = t[r]);
                    return n
                }

                function af(t) {
                    var e = function(t) {
                            return void 0 !== t
                        },
                        n = t._x,
                        r = t._x1,
                        i = t._x0,
                        a = t._voronoiX,
                        o = t._y,
                        u = t._y1,
                        c = t._y0,
                        l = t._voronoiY,
                        s = e(r) ? r : n,
                        f = e(u) ? u : o,
                        h = {
                            x: e(a) ? a : s,
                            x0: e(i) ? i : n,
                            y: e(l) ? l : f,
                            y0: e(c) ? c : o
                        };
                    return sl({}, h, t)
                }

                function of (t, e) {
                    var n = t.scale,
                        r = t.polar,
                        i = t.horizontal,
                        a = af(e),
                        o = t.origin || {
                            x: 0,
                            y: 0
                        },
                        u = i ? n.y(a.y) : n.x(a.x),
                        c = i ? n.y(a.y0) : n.x(a.x0),
                        l = i ? n.x(a.x) : n.y(a.y),
                        s = i ? n.x(a.x0) : n.y(a.y0);
                    return {
                        x: r ? l * Math.cos(u) + o.x : u,
                        x0: r ? s * Math.cos(c) + o.x : c,
                        y: r ? -l * Math.sin(u) + o.y : l,
                        y0: r ? -s * Math.sin(c) + o.x : s
                    }
                }

                function uf(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "padding",
                        n = t[e],
                        r = "number" == typeof n ? n : 0,
                        i = "object" == typeof n ? n : {};
                    return {
                        top: i.top || r,
                        bottom: i.bottom || r,
                        left: i.left || r,
                        right: i.right || r
                    }
                }

                function cf(t) {
                    return "tooltip" === (t && t.type && t.type.role)
                }

                function lf(t, e) {
                    var n = "100%",
                        r = "100%";
                    if (!t) return sl({
                        parent: {
                            height: r,
                            width: n
                        }
                    }, e);
                    var i = t.data,
                        a = t.labels,
                        o = t.parent,
                        u = e && e.parent || {},
                        c = e && e.labels || {},
                        l = e && e.data || {};
                    return {
                        parent: sl({}, o, u, {
                            width: n,
                            height: r
                        }),
                        labels: sl({}, a, c),
                        data: sl({}, i, l)
                    }
                }

                function sf(t, e) {
                    return It(t) ? t(e) : t
                }

                function ff(t, e) {
                    return e.disableInlineStyles ? {} : t && si(t).some((function(e) {
                        return It(t[e])
                    })) ? si(t).reduce((function(n, r) {
                        return n[r] = sf(t[r], e), n
                    }), {}) : t
                }

                function hf(t) {
                    return "number" == typeof t ? t * (Math.PI / 180) : t
                }

                function df(t) {
                    var e = uf(t),
                        n = e.left,
                        r = e.right,
                        i = e.top,
                        a = e.bottom,
                        o = t.width,
                        u = t.height;
                    return Math.min(o - n - r, u - i - a) / 2
                }

                function pf(t) {
                    var e = t.width,
                        n = t.height,
                        r = uf(t),
                        i = r.top,
                        a = r.bottom,
                        o = r.left,
                        u = r.right,
                        c = Math.min(e - o - u, n - i - a) / 2,
                        l = e / 2 + o - u,
                        s = n / 2 + i - a;
                    return {
                        x: l + c > e ? c + o - u : l,
                        y: s + c > n ? c + i - a : s
                    }
                }

                function yf(t, e) {
                    return t.range && t.range[e] ? t.range[e] : t.range && Array.isArray(t.range) ? t.range : t.polar ? function(t, e) {
                        return "x" === e ? [hf(t.startAngle || 0), hf(t.endAngle || 360)] : [t.innerRadius || 0, df(t)]
                    }(t, e) : function(t, e) {
                        var n = "x" !== e,
                            r = uf(t);
                        return n ? [t.height - r.bottom, r.top] : [r.left, t.width - r.right]
                    }(t, e)
                }

                function vf(t) {
                    return It(t) ? t : null == t ? function(t) {
                        return t
                    } : Ha(t)
                }

                function bf(t, e, r) {
                    var i = rf(t.theme && t.theme[r] ? t.theme[r] : {}, ["style"]),
                        a = function(t) {
                            if (void 0 !== t.horizontal || !t.children) return t.horizontal;
                            var e = function(t) {
                                return t.reduce((function(t, r) {
                                    var i = r.props || {};
                                    return t || i.horizontal || !i.children ? t = t || i.horizontal : e(n.Children.toArray(i.children))
                                }), !1)
                            };
                            return e(n.Children.toArray(t.children))
                        }(t);
                    return sl(void 0 === a ? {} : {
                        horizontal: a
                    }, t, i, e)
                }

                function gf(t, e) {
                    return e ? "x" === t ? "y" : "x" : t
                }

                function mf(t, e) {
                    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                        i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : [],
                        a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : function(t, e) {
                            return t.concat(e)
                        },
                        o = ["data", "domain", "categories", "polar", "startAngle", "endAngle", "minDomain", "maxDomain", "horizontal"],
                        u = function(t, c, l) {
                            return t.reduce((function(t, i, s) {
                                var f = i.type && i.type.role,
                                    h = i.props.name || "".concat(f, "-").concat(c[s]);
                                if (i.props && i.props.children) {
                                    var d = Sl({}, i.props, nf(r, o)),
                                        p = i.type && "stack" === i.type.role && It(i.type.getChildren) ? i.type.getChildren(d) : n.Children.toArray(i.props.children).map((function(t) {
                                            var e = Sl({}, t.props, nf(d, o));
                                            return n.cloneElement(t, e)
                                        })),
                                        y = p.map((function(t, e) {
                                            return "".concat(h, "-").concat(e)
                                        })),
                                        v = u(p, y, i);
                                    t = a(t, v)
                                } else {
                                    var b = e(i, h, l);
                                    b && (t = a(t, b))
                                }
                                return t
                            }), i)
                        },
                        c = t.map((function(t, e) {
                            return e
                        }));
                    return u(t, c)
                }

                function _f(t, e) {
                    return function(t) {
                        if (Array.isArray(t)) return t
                    }(t) || function(t, e) {
                        var n = [],
                            r = !0,
                            i = !1,
                            a = void 0;
                        try {
                            for (var o, u = t[Symbol.iterator](); !(r = (o = u.next()).done) && (n.push(o.value), !e || n.length !== e); r = !0);
                        } catch (c) {
                            i = !0, a = c
                        } finally {
                            try {
                                r || null == u.return || u.return()
                            } finally {
                                if (i) throw a
                            }
                        }
                        return n
                    }(t, e) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }()
                }

                function xf(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }
                var wf = {
                        startsWith: ["data-", "aria-"],
                        exactMatch: []
                    },
                    kf = function(t) {
                        return !(! function(t) {
                            var e = !1;
                            return wf.startsWith.forEach((function(n) {
                                new RegExp("\\b(".concat(n, ")(\\w|-)+"), "g").test(t) && (e = !0)
                            })), e
                        }(t) && ! function(t) {
                            return wf.exactMatch.includes(t)
                        }(t))
                    },
                    Of = function(t) {
                        var e = function(t) {
                            for (var e = 1; e < arguments.length; e++) {
                                var n = null != arguments[e] ? arguments[e] : {},
                                    r = Object.keys(n);
                                "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                    return Object.getOwnPropertyDescriptor(n, t).enumerable
                                })))), r.forEach((function(e) {
                                    xf(t, e, n[e])
                                }))
                            }
                            return t
                        }({}, t);
                        return Object.fromEntries(Object.entries(e).filter((function(t) {
                            var e = _f(t, 1)[0];
                            return kf(e)
                        })))
                    };

                function Af() {
                    return Af = Object.assign || function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = arguments[e];
                            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
                        }
                        return t
                    }, Af.apply(this, arguments)
                }

                function Ef(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {},
                            r = Object.keys(n);
                        "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                            return Object.getOwnPropertyDescriptor(n, t).enumerable
                        })))), r.forEach((function(e) {
                            Mf(t, e, n[e])
                        }))
                    }
                    return t
                }

                function Mf(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function Tf(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function jf(t, e) {
                    return !e || "object" != typeof e && "function" != typeof e ? function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t) : e
                }
                var Pf = function(t) {
                    function e(t) {
                        var n;
                        return function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), (n = jf(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t))).containerId = Pt(t) && void 0 !== t.containerId ? t.containerId : Oc("victory-container-"), n.savePortalRef = function(t) {
                            return n.portalRef = t, t
                        }, n.portalUpdate = function(t, e) {
                            return n.portalRef.portalUpdate(t, e)
                        }, n.portalRegister = function() {
                            return n.portalRef.portalRegister()
                        }, n.portalDeregister = function(t) {
                            return n.portalRef.portalDeregister(t)
                        }, n.saveContainerRef = t && It(t.containerRef) ? t.containerRef : function(t) {
                            return n.containerRef = t, t
                        }, n.shouldHandleWheel = t && t.events && t.events.onWheel, n.shouldHandleWheel && (n.handleWheel = function(t) {
                            return t.preventDefault()
                        }), n
                    }
                    var r, i, a;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), r = e, i = [{
                        key: "componentDidMount",
                        value: function() {
                            this.shouldHandleWheel && this.containerRef && this.containerRef.addEventListener("wheel", this.handleWheel)
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.shouldHandleWheel && this.containerRef && this.containerRef.removeEventListener("wheel", this.handleWheel)
                        }
                    }, {
                        key: "getIdForElement",
                        value: function(t) {
                            return "".concat(this.containerId, "-").concat(t)
                        }
                    }, {
                        key: "getChildren",
                        value: function(t) {
                            return t.children
                        }
                    }, {
                        key: "getOUIAProps",
                        value: function(t) {
                            var e = t.ouiaId,
                                n = t.ouiaSafe,
                                r = t.ouiaType;
                            return Ef({}, e && {
                                "data-ouia-component-id": e
                            }, r && {
                                "data-ouia-component-type": r
                            }, void 0 !== n && {
                                "data-ouia-safe": n
                            })
                        }
                    }, {
                        key: "renderContainer",
                        value: function(t, e, r) {
                            var i = t.title,
                                a = t.desc,
                                o = t.portalComponent,
                                u = t.className,
                                c = t.width,
                                l = t.height,
                                s = t.portalZIndex,
                                f = t.responsive,
                                h = this.getChildren(t),
                                d = f ? {
                                    width: "100%",
                                    height: "100%"
                                } : {
                                    width: c,
                                    height: l
                                },
                                p = Sl({
                                    pointerEvents: "none",
                                    touchAction: "none",
                                    position: "relative"
                                }, d),
                                y = Sl({
                                    zIndex: s,
                                    position: "absolute",
                                    top: 0,
                                    left: 0
                                }, d),
                                v = Sl({
                                    pointerEvents: "all"
                                }, d),
                                b = Sl({
                                    overflow: "visible"
                                }, d),
                                g = {
                                    width: c,
                                    height: l,
                                    viewBox: e.viewBox,
                                    preserveAspectRatio: e.preserveAspectRatio,
                                    style: b
                                };
                            return n.createElement(js.Provider, {
                                value: {
                                    portalUpdate: this.portalUpdate,
                                    portalRegister: this.portalRegister,
                                    portalDeregister: this.portalDeregister
                                }
                            }, n.createElement("div", Af({
                                style: sl({}, r, p),
                                className: u,
                                ref: this.saveContainerRef
                            }, this.getOUIAProps(t)), n.createElement("svg", Af({}, e, {
                                style: v
                            }), i ? n.createElement("title", {
                                id: this.getIdForElement("title")
                            }, i) : null, a ? n.createElement("desc", {
                                id: this.getIdForElement("desc")
                            }, a) : null, h), n.createElement("div", {
                                style: y
                            }, n.cloneElement(o, Ef({}, g, {
                                ref: this.savePortalRef
                            })))))
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.props,
                                e = t.width,
                                n = t.height,
                                r = t.responsive,
                                i = t.events,
                                a = t.title,
                                o = t.desc,
                                u = t.tabIndex,
                                c = t.preserveAspectRatio,
                                l = t.role,
                                s = r ? this.props.style : rf(this.props.style, ["height", "width"]),
                                f = Of(this.props),
                                h = Sl(Ef({
                                    width: e,
                                    height: n,
                                    tabIndex: u,
                                    role: l,
                                    "aria-labelledby": [a && this.getIdForElement("title"), this.props["aria-labelledby"]].filter(Boolean).join(" ") || void 0,
                                    "aria-describedby": [o && this.getIdForElement("desc"), this.props["aria-describedby"]].filter(Boolean).join(" ") || void 0,
                                    viewBox: r ? "0 0 ".concat(e, " ").concat(n) : void 0,
                                    preserveAspectRatio: r ? c : void 0
                                }, f), i);
                            return this.renderContainer(this.props, h, s)
                        }
                    }], i && Tf(r.prototype, i), a && Tf(r, a), e
                }(n.Component);
                Object.defineProperty(Pf, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryContainer"
                }), Object.defineProperty(Pf, "role", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "container"
                }), Object.defineProperty(Pf, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        "aria-describedby": C.string,
                        "aria-labelledby": C.string,
                        children: C.oneOfType([C.arrayOf(C.node), C.node]),
                        className: C.string,
                        containerId: C.oneOfType([C.number, C.string]),
                        containerRef: C.func,
                        desc: C.string,
                        events: C.object,
                        height: _s,
                        name: C.string,
                        origin: C.shape({
                            x: _s,
                            y: _s
                        }),
                        ouiaId: C.oneOfType([C.number, C.string]),
                        ouiaSafe: C.bool,
                        ouiaType: C.string,
                        polar: C.bool,
                        portalComponent: C.element,
                        portalZIndex: xs,
                        preserveAspectRatio: C.string,
                        responsive: C.bool,
                        role: C.string,
                        style: C.object,
                        tabIndex: C.number,
                        theme: C.object,
                        title: C.string,
                        width: _s
                    }
                }), Object.defineProperty(Pf, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        className: "VictoryContainer",
                        portalComponent: n.createElement(Ms, null),
                        portalZIndex: 99,
                        responsive: !0,
                        role: "img"
                    }
                }), Object.defineProperty(Pf, "contextType", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: fc
                });
                var Sf = ni,
                    Cf = Fi,
                    Nf = kr,
                    Df = it,
                    If = ai,
                    Lf = Or.exports,
                    zf = Xr,
                    Wf = Rr,
                    Ff = Object.prototype.hasOwnProperty;
                var Rf = function(t) {
                    if (null == t) return !0;
                    if (If(t) && (Df(t) || "string" == typeof t || "function" == typeof t.splice || Lf(t) || Wf(t) || Nf(t))) return !t.length;
                    var e = Cf(t);
                    if ("[object Map]" == e || "[object Set]" == e) return !t.size;
                    if (zf(t)) return !Sf(t).length;
                    for (var n in t)
                        if (Ff.call(t, n)) return !1;
                    return !0
                };

                function Uf(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }

                function qf(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function Bf(t, e) {
                    return !e || "object" != typeof e && "function" != typeof e ? function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t) : e
                }
                var Hf = function(t) {
                    function e() {
                        return Uf(this, e), Bf(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                    }
                    var r, i, a;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), r = e, (i = [{
                        key: "componentDidMount",
                        value: function() {
                            this.checkedContext || ("function" != typeof this.context.portalUpdate && (this.renderInPlace = !0), this.checkedContext = !0), this.forceUpdate()
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            this.renderInPlace || (this.portalKey = this.portalKey || this.context.portalRegister(), this.context.portalUpdate(this.portalKey, this.element))
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.context && this.context.portalDeregister && this.context.portalDeregister(this.portalKey)
                        }
                    }, {
                        key: "renderPortal",
                        value: function(t) {
                            return this.renderInPlace ? t : (this.element = t, null)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = Array.isArray(this.props.children) ? this.props.children[0] : this.props.children,
                                e = this.props.groupComponent,
                                r = t && t.props || {},
                                i = r.groupComponent ? {
                                    groupComponent: e,
                                    standalone: !1
                                } : {},
                                a = sl(i, r, rf(this.props, ["children", "groupComponent"])),
                                o = t && n.cloneElement(t, a);
                            return this.renderPortal(o)
                        }
                    }]) && qf(r.prototype, i), a && qf(r, a), e
                }(n.Component);

                function Kf() {
                    return Kf = Object.assign || function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = arguments[e];
                            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
                        }
                        return t
                    }, Kf.apply(this, arguments)
                }
                Object.defineProperty(Hf, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryPortal"
                }), Object.defineProperty(Hf, "role", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "portal"
                }), Object.defineProperty(Hf, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        children: C.node,
                        groupComponent: C.element
                    }
                }), Object.defineProperty(Hf, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        groupComponent: n.createElement("g", null)
                    }
                }), Object.defineProperty(Hf, "contextType", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: js
                });
                var Yf = function(t) {
                    var e = t.desc,
                        r = function(t, e) {
                            if (null == t) return {};
                            var n, r, i = {},
                                a = Object.keys(t);
                            for (r = 0; r < a.length; r++) n = a[r], e.indexOf(n) >= 0 || (i[n] = t[n]);
                            if (Object.getOwnPropertySymbols) {
                                var o = Object.getOwnPropertySymbols(t);
                                for (r = 0; r < o.length; r++) n = o[r], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (i[n] = t[n])
                            }
                            return i
                        }(t, ["desc"]);
                    return e ? n.createElement("rect", Kf({
                        vectorEffect: "non-scaling-stroke"
                    }, r), n.createElement("desc", null, e)) : n.createElement("rect", Kf({
                        vectorEffect: "non-scaling-stroke"
                    }, r))
                };

                function Vf(t, e) {
                    if (t.polar) return {};
                    var n = function(t, e) {
                        e = e || {};
                        var n = t.horizontal,
                            r = sf((t.style.labels || {}).padding, t) || 0,
                            i = e._y < 0 ? -1 : 1;
                        return {
                            x: n ? i * r : 0,
                            y: n ? 0 : -1 * i * r
                        }
                    }(t, e);
                    return {
                        dx: n.x,
                        dy: n.y
                    }
                }

                function Gf(t, e) {
                    var n = t.polar,
                        r = of (t, e),
                        i = r.x,
                        a = r.y;
                    if (n) {
                        var o = function(t, e) {
                            var n = t.style,
                                r = Qf(t, e),
                                i = sf((n.labels || {}).padding, t) || 0,
                                a = hf(r);
                            return {
                                x: i * Math.cos(a),
                                y: -i * Math.sin(a)
                            }
                        }(t, e);
                        return {
                            x: i + o.x,
                            y: a + o.y
                        }
                    }
                    return {
                        x: i,
                        y: a
                    }
                }

                function $f(t) {
                    var e = t.labelComponent,
                        n = t.labelPlacement,
                        r = t.polar ? "perpendicular" : "vertical";
                    return n || (e.props && e.props.labelPlacement || r)
                }

                function Xf(t, e, n) {
                    return void 0 !== (e = e || {}).label ? e.label : Array.isArray(t.labels) ? t.labels[n] : t.labels
                }

                function Qf(t, e) {
                    var n, r = af(e).x;
                    return ("number" == typeof(n = t.scale.x(r)) ? n / (Math.PI / 180) : n) % 360
                }

                function Zf(t, e) {
                    var n = t.scale,
                        r = t.data,
                        i = t.style,
                        a = t.horizontal,
                        o = t.polar,
                        u = t.width,
                        c = t.height,
                        l = t.theme,
                        s = t.labelComponent,
                        f = t.disableInlineStyles,
                        h = r[e],
                        d = Qf(t, h),
                        p = o ? function(t, e) {
                            var n = $f(t);
                            return "perpendicular" === n || "vertical" === n && (90 === e || 270 === e) ? "middle" : e <= 90 || e > 270 ? "start" : "end"
                        }(t, d) : function(t, e) {
                            e = e || {};
                            var n = t.style,
                                r = t.horizontal,
                                i = e._y >= 0 ? 1 : -1,
                                a = n && n.labels || {};
                            return e.verticalAnchor || a.verticalAnchor ? e.verticalAnchor || a.verticalAnchor : r ? i >= 0 ? "start" : "end" : "middle"
                        }(t, h),
                        y = o ? function(t, e) {
                            var n = $f(t),
                                r = function(t) {
                                    return t < 45 || t > 315 ? "right" : t >= 45 && t <= 135 ? "top" : t > 135 && t < 225 ? "left" : "bottom"
                                }(e);
                            return "parallel" === n || "left" === r || "right" === r ? "middle" : "top" === r ? "end" : "start"
                        }(t, d) : function(t, e) {
                            var n = (e = e || {})._y >= 0 ? 1 : -1,
                                r = t.style && t.style.labels || {};
                            return e.verticalAnchor || r.verticalAnchor ? e.verticalAnchor || r.verticalAnchor : t.horizontal ? "middle" : n >= 0 ? "end" : "start"
                        }(t, h),
                        v = function(t, e) {
                            e = e || {};
                            var n = t.style && t.style.labels || {};
                            return void 0 === e.angle ? n.angle : e.angle
                        }(t, h),
                        b = Xf(t, h, e),
                        g = $f(t),
                        m = Gf(t, h),
                        _ = m.x,
                        x = m.y,
                        w = Vf(t, h),
                        k = {
                            angle: v,
                            data: r,
                            datum: h,
                            disableInlineStyles: f,
                            horizontal: a,
                            index: e,
                            polar: o,
                            scale: n,
                            labelPlacement: g,
                            text: b,
                            textAnchor: p,
                            verticalAnchor: y,
                            x: _,
                            y: x,
                            dx: w.dx,
                            dy: w.dy,
                            width: u,
                            height: c,
                            style: i.labels
                        };
                    if (!cf(s)) return k;
                    var O = l && l.tooltip || {};
                    return sl({}, k, rf(O, ["style"]))
                }
                var Jf = function(t) {
                    for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                    if (n.length > 0) return n.reduce((function(t, e) {
                        return [t, Jf(e)].join(" ")
                    }), Jf(t)).trim();
                    if (null == t || "string" == typeof t) return t;
                    var i = [];
                    for (var a in t)
                        if (t.hasOwnProperty(a)) {
                            var o = t[a];
                            i.push("".concat(a, "(").concat(o, ")"))
                        }
                    return i.join(" ").trim()
                };

                function th(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }
                var eh = {
                        "American Typewriter": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .25, .4203125, .3296875, .6, .6375, .8015625, .8203125, .1875, .45625, .45625, .6375, .5, .2734375, .309375, .2734375, .4390625, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .6375, .2734375, .2734375, .5, .5, .5, .6, .6921875, .7640625, .6921875, .6375, .728125, .6734375, .6203125, .7109375, .784375, .3828125, .6421875, .7859375, .6375, .9484375, .7640625, .65625, .6375, .65625, .7296875, .6203125, .6375, .7109375, .740625, .940625, .784375, .7578125, .6203125, .4375, .5, .4375, .5, .5, .4921875, .5734375, .5890625, .5109375, .6, .528125, .43125, .5578125, .6375, .3109375, .40625, .6234375, .309375, .928125, .6375, .546875, .6, .58125, .4921875, .4921875, .4, .6203125, .625, .825, .6375, .640625, .528125, .5, .5, .5, .6671875],
                            avg: .5793421052631578
                        },
                        Arial: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .278125, .278125, .35625, .55625, .55625, .890625, .6671875, .1921875, .334375, .334375, .390625, .584375, .278125, .334375, .278125, .278125, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .278125, .278125, .584375, .584375, .584375, .55625, 1.015625, .6703125, .6671875, .7234375, .7234375, .6671875, .6109375, .778125, .7234375, .278125, .5, .6671875, .55625, .834375, .7234375, .778125, .6671875, .778125, .7234375, .6671875, .6109375, .7234375, .6671875, .9453125, .6671875, .6671875, .6109375, .278125, .278125, .278125, .4703125, .584375, .334375, .55625, .55625, .5, .55625, .55625, .3125, .55625, .55625, .2234375, .2703125, .5, .2234375, .834375, .55625, .55625, .55625, .55625, .346875, .5, .278125, .55625, .5, .7234375, .5, .5, .5, .334375, .2609375, .334375, .584375],
                            avg: .528733552631579
                        },
                        "Arial Black": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .33125, .334375, .5, .6609375, .6671875, 1, .890625, .278125, .390625, .390625, .55625, .6609375, .334375, .334375, .334375, .28125, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .334375, .334375, .6609375, .6609375, .6609375, .6109375, .7453125, .78125, .778125, .778125, .778125, .7234375, .6671875, .834375, .834375, .390625, .6671875, .834375, .6671875, .9453125, .834375, .834375, .7234375, .834375, .78125, .7234375, .7234375, .834375, .7796875, 1.003125, .78125, .78125, .7234375, .390625, .28125, .390625, .6609375, .5125, .334375, .6671875, .6671875, .6671875, .6671875, .6671875, .41875, .6671875, .6671875, .334375, .384375, .6671875, .334375, 1, .6671875, .6671875, .6671875, .6671875, .4703125, .6109375, .4453125, .6671875, .6140625, .946875, .6671875, .615625, .55625, .390625, .278125, .390625, .6609375],
                            avg: .6213157894736842
                        },
                        Baskerville: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .25, .25, .40625, .6671875, .490625, .875, .7015625, .178125, .2453125, .246875, .4171875, .6671875, .25, .3125, .25, .521875, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .25, .25, .6671875, .6671875, .6671875, .396875, .9171875, .684375, .615625, .71875, .7609375, .625, .553125, .771875, .803125, .3546875, .515625, .78125, .6046875, .928125, .75, .8234375, .5625, .96875, .7296875, .5421875, .6984375, .771875, .7296875, .9484375, .771875, .678125, .6359375, .3640625, .521875, .3640625, .46875, .5125, .334375, .46875, .521875, .428125, .521875, .4375, .3890625, .4765625, .53125, .25, .359375, .4640625, .240625, .803125, .53125, .5, .521875, .521875, .365625, .334375, .2921875, .521875, .4640625, .678125, .4796875, .465625, .428125, .4796875, .5109375, .4796875, .6671875],
                            avg: .5323519736842108
                        },
                        Courier: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .5984375, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6078125, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .61875, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .615625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6140625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625],
                            avg: .6020559210526316
                        },
                        "Courier New": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .5984375, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625],
                            avg: .6015296052631579
                        },
                        cursive: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .1921875, .24375, .40625, .5671875, .3984375, .721875, .909375, .2328125, .434375, .365625, .4734375, .5578125, .19375, .3484375, .19375, .7734375, .503125, .4171875, .5453125, .45, .6046875, .4703125, .5984375, .55625, .503125, .5546875, .20625, .2, .5625, .5546875, .546875, .403125, .70625, .734375, .7078125, .64375, .85, .753125, .75, .6484375, 1.0765625, .44375, .5359375, .8359375, .653125, 1.0109375, 1.1515625, .6796875, .6984375, 1.0625, .8234375, .5125, .9234375, .8546875, .70625, .9109375, .7421875, .715625, .6015625, .4640625, .3359375, .4109375, .5421875, .5421875, .4328125, .5125, .5, .3859375, .7375, .359375, .75625, .540625, .5328125, .3203125, .5296875, .5015625, .484375, .7890625, .5640625, .4203125, .703125, .471875, .4734375, .35, .4125, .5640625, .471875, .6484375, .5296875, .575, .4140625, .415625, .20625, .3796875, .5421875],
                            avg: .5604440789473684
                        },
                        fantasy: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .215625, .2625, .3265625, .6109375, .534375, .7625, .7828125, .2, .4359375, .4359375, .3765625, .5109375, .2796875, .4609375, .2796875, .5296875, .6640625, .253125, .521875, .4765625, .6640625, .490625, .528125, .5546875, .496875, .5421875, .2796875, .2796875, .5625, .4609375, .5625, .4828125, .609375, .740625, .7234375, .740625, .8265625, .7234375, .6171875, .7359375, .765625, .240625, .5453125, .715625, .6078125, .8640625, .653125, .9125, .6484375, .946875, .6921875, .653125, .6953125, .8015625, .58125, .784375, .671875, .6265625, .690625, .4359375, .5296875, .4359375, .53125, .5, .2875, .5375, .603125, .4984375, .60625, .53125, .434375, .6421875, .56875, .209375, .4671875, .5484375, .2203125, .709375, .55, .5984375, .6140625, .5765625, .40625, .4734375, .3734375, .559375, .4421875, .6421875, .4890625, .578125, .4484375, .2546875, .2203125, .2546875, .55],
                            avg: .536496710526316
                        },
                        Geneva: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .3328125, .3046875, .5, .6671875, .6671875, .90625, .728125, .3046875, .446875, .446875, .5078125, .6671875, .3046875, .3796875, .3046875, .5390625, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .6671875, .3046875, .3046875, .6671875, .6671875, .6671875, .56875, .871875, .728125, .6375, .6515625, .7015625, .5765625, .5546875, .675, .690625, .2421875, .4921875, .6640625, .584375, .7890625, .709375, .7359375, .584375, .78125, .60625, .60625, .640625, .6671875, .728125, .946875, .6109375, .6109375, .5765625, .446875, .5390625, .446875, .6671875, .6671875, .5921875, .5546875, .6109375, .546875, .603125, .5765625, .390625, .6109375, .584375, .2359375, .334375, .5390625, .2359375, .8953125, .584375, .60625, .603125, .603125, .3875, .509375, .44375, .584375, .565625, .78125, .53125, .571875, .5546875, .4515625, .246875, .4515625, .6671875],
                            avg: .5762664473684211
                        },
                        Georgia: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2421875, .33125, .4125, .64375, .6109375, .81875, .7109375, .215625, .375, .375, .4734375, .64375, .2703125, .375, .2703125, .46875, .6140625, .4296875, .559375, .553125, .565625, .5296875, .5671875, .503125, .596875, .5671875, .3125, .3125, .64375, .64375, .64375, .4796875, .9296875, .715625, .6546875, .6421875, .75, .6546875, .6, .7265625, .815625, .390625, .51875, .7203125, .6046875, .928125, .7671875, .7453125, .6109375, .7453125, .7234375, .5625, .61875, .7578125, .70625, .99375, .7125, .6640625, .6015625, .375, .46875, .375, .64375, .65, .5, .5046875, .56875, .4546875, .575, .484375, .39375, .509375, .5828125, .29375, .3671875, .546875, .2875, .88125, .5921875, .5390625, .571875, .5640625, .4109375, .4328125, .3453125, .5765625, .5203125, .75625, .50625, .5171875, .4453125, .43125, .375, .43125, .64375],
                            avg: .5551809210526316
                        },
                        "Gill Sans": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2765625, .271875, .3546875, .584375, .5421875, .6765625, .625, .1890625, .3234375, .3234375, .4171875, .584375, .2203125, .3234375, .2203125, .28125, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .2203125, .2296875, .584375, .584375, .584375, .334375, 1.0109375, .6671875, .5640625, .709375, .75, .5, .4703125, .740625, .7296875, .25, .3125, .65625, .490625, .78125, .78125, .8234375, .5109375, .8234375, .6046875, .459375, .6046875, .709375, .6046875, 1.0421875, .709375, .6046875, .646875, .334375, .28125, .334375, .4703125, .5828125, .334375, .428125, .5, .4390625, .5109375, .4796875, .296875, .428125, .5, .2203125, .2265625, .5, .2203125, .771875, .5, .553125, .5, .5, .3984375, .3859375, .334375, .5, .4390625, .7203125, .5, .4390625, .4171875, .334375, .2609375, .334375, .584375],
                            avg: .4933717105263159
                        },
                        Helvetica: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2796875, .2765625, .3546875, .5546875, .5546875, .8890625, .665625, .190625, .3328125, .3328125, .3890625, .5828125, .2765625, .3328125, .2765625, .3015625, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .5546875, .2765625, .2765625, .584375, .5828125, .584375, .5546875, 1.0140625, .665625, .665625, .721875, .721875, .665625, .609375, .7765625, .721875, .2765625, .5, .665625, .5546875, .8328125, .721875, .7765625, .665625, .7765625, .721875, .665625, .609375, .721875, .665625, .94375, .665625, .665625, .609375, .2765625, .3546875, .2765625, .4765625, .5546875, .3328125, .5546875, .5546875, .5, .5546875, .5546875, .2765625, .5546875, .5546875, .221875, .240625, .5, .221875, .8328125, .5546875, .5546875, .5546875, .5546875, .3328125, .5, .2765625, .5546875, .5, .721875, .5, .5, .5, .3546875, .259375, .353125, .5890625],
                            avg: .5279276315789471
                        },
                        "Helvetica Neue": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .278125, .259375, .4265625, .55625, .55625, 1, .6453125, .278125, .2703125, .26875, .353125, .6, .278125, .3890625, .278125, .36875, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .278125, .278125, .6, .6, .6, .55625, .8, .6625, .6859375, .7234375, .7046875, .6125, .575, .759375, .7234375, .259375, .5203125, .6703125, .55625, .871875, .7234375, .7609375, .6484375, .7609375, .6859375, .6484375, .575, .7234375, .6140625, .9265625, .6125, .6484375, .6125, .259375, .36875, .259375, .6, .5, .25625, .5375, .59375, .5375, .59375, .5375, .2984375, .575, .55625, .2234375, .2375, .5203125, .2234375, .853125, .55625, .575, .59375, .59375, .334375, .5, .315625, .55625, .5, .759375, .51875, .5, .48125, .334375, .2234375, .334375, .6],
                            avg: .5279440789473684
                        },
                        "Hoefler Text": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2359375, .2234375, .3921875, .7125, .49375, .8859375, .771875, .2125, .3078125, .309375, .375, .4234375, .234375, .3125, .234375, .3, .5828125, .365625, .434375, .3921875, .5234375, .3984375, .5125, .4328125, .46875, .5125, .234375, .234375, .515625, .4234375, .515625, .340625, .7609375, .7359375, .6359375, .721875, .8125, .6375, .5875, .8078125, .853125, .4296875, .503125, .78125, .609375, .9609375, .8515625, .8140625, .6125, .8140625, .71875, .49375, .7125, .76875, .771875, 1.125, .7765625, .7734375, .65625, .321875, .3078125, .321875, .3546875, .5, .3375, .446875, .5359375, .45, .5296875, .4546875, .425, .4921875, .54375, .2671875, .240625, .5390625, .25, .815625, .5375, .5234375, .5390625, .5421875, .365625, .36875, .35625, .5171875, .5015625, .75, .5, .509375, .44375, .2421875, .14375, .2421875, .35],
                            avg: .5116447368421051
                        },
                        Montserrat: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2625, .2609375, .3734375, .696875, .615625, .8296875, .6703125, .203125, .3296875, .3296875, .3875, .575, .2125, .3828125, .2125, .3953125, .6625, .3625, .56875, .5640625, .6625, .5671875, .609375, .5890625, .6390625, .609375, .2125, .2125, .575, .575, .575, .5671875, 1.034375, .7171875, .7546875, .7203125, .8265625, .6703125, .634375, .7734375, .8140625, .303125, .5078125, .7125, .5890625, .95625, .8140625, .8390625, .71875, .8390625, .7234375, .615625, .575, .7921875, .6984375, 1.1125, .65625, .6359375, .6515625, .31875, .396875, .31875, .5765625, .5, .6, .590625, .678125, .5640625, .678125, .6046875, .375, .6875, .678125, .2703125, .365625, .6015625, .2703125, 1.0625, .678125, .628125, .678125, .678125, .4015625, .4890625, .40625, .6734375, .5421875, .8796875, .534375, .5671875, .5125, .334375, .2953125, .334375, .575],
                            avg: .571792763157895
                        },
                        monospace: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .5984375, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6078125, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .61875, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .615625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6140625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625, .6015625],
                            avg: .6020559210526316
                        },
                        Overpass: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2296875, .2765625, .4203125, .68125, .584375, .8515625, .7015625, .2203125, .3453125, .3453125, .53125, .63125, .2234375, .3953125, .2234375, .509375, .65, .4046875, .6171875, .60625, .6484375, .60625, .6015625, .5375, .615625, .6015625, .2234375, .2234375, .63125, .63125, .63125, .5015625, .8203125, .696875, .6671875, .65, .6859375, .6015625, .559375, .690625, .7078125, .2953125, .565625, .678125, .58125, .8046875, .7109375, .740625, .6421875, .740625, .6765625, .6046875, .590625, .696875, .6640625, .853125, .65, .6671875, .6625, .3734375, .509375, .3734375, .63125, .5125, .4, .5328125, .5625, .51875, .5625, .546875, .3359375, .5625, .565625, .25625, .3203125, .55, .265625, .85, .565625, .5671875, .5625, .5625, .4046875, .4765625, .3796875, .565625, .521875, .7265625, .53125, .5390625, .5125, .3671875, .275, .3671875, .63125],
                            avg: .5430756578947369
                        },
                        Palatino: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .25, .278125, .371875, .60625, .5, .840625, .778125, .209375, .334375, .334375, .390625, .60625, .2578125, .334375, .25, .60625, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .25, .25, .60625, .60625, .60625, .4453125, .7484375, .778125, .6109375, .709375, .775, .6109375, .55625, .7640625, .8328125, .3375, .346875, .7265625, .6109375, .946875, .83125, .7875, .6046875, .7875, .66875, .525, .6140625, .778125, .7234375, 1, .6671875, .6671875, .6671875, .334375, .60625, .334375, .60625, .5, .334375, .5, .565625, .4453125, .6109375, .4796875, .340625, .55625, .5828125, .2921875, .2671875, .5640625, .2921875, .8828125, .5828125, .546875, .6015625, .5609375, .3953125, .425, .3265625, .603125, .565625, .834375, .5171875, .55625, .5, .334375, .60625, .334375, .60625],
                            avg: .5408552631578947
                        },
                        RedHatText: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2328125, .2203125, .35625, .6890625, .55, .7390625, .6703125, .2140625, .4015625, .4015625, .4546875, .53125, .2203125, .45625, .2203125, .515625, .6609375, .3078125, .5484375, .5875, .61875, .5703125, .6203125, .559375, .6140625, .6203125, .2203125, .2234375, .465625, .534375, .465625, .5125, .7671875, .6609375, .6703125, .7265625, .728125, .6203125, .6109375, .8, .73125, .253125, .6, .6125, .6078125, .8625, .7390625, .8109375, .6546875, .809375, .6484375, .6234375, .6171875, .7125, .6609375, .8984375, .6546875, .646875, .60625, .3625, .5203125, .3625, .540625, .4609375, .5234375, .5265625, .584375, .509375, .5828125, .5578125, .3703125, .5828125, .553125, .2234375, .24375, .4890625, .2234375, .8453125, .553125, .58125, .584375, .5828125, .353125, .453125, .378125, .553125, .5015625, .6984375, .4875, .4984375, .459375, .3953125, .2921875, .3953125, .58125],
                            avg: .5341940789473685
                        },
                        "sans-serif": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .278125, .278125, .35625, .55625, .55625, .890625, .6671875, .1921875, .334375, .334375, .390625, .584375, .278125, .334375, .278125, .303125, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .55625, .278125, .278125, .5859375, .584375, .5859375, .55625, 1.015625, .6671875, .6671875, .7234375, .7234375, .6671875, .6109375, .778125, .7234375, .278125, .5, .6671875, .55625, .834375, .7234375, .778125, .6671875, .778125, .7234375, .6671875, .6109375, .7234375, .6671875, .9453125, .6671875, .6671875, .6109375, .278125, .35625, .278125, .478125, .55625, .334375, .55625, .55625, .5, .55625, .55625, .278125, .55625, .55625, .2234375, .2421875, .5, .2234375, .834375, .55625, .55625, .55625, .55625, .334375, .5, .278125, .55625, .5, .7234375, .5, .5, .5, .35625, .2609375, .3546875, .590625],
                            avg: .5293256578947368
                        },
                        Seravek: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .215625, .296875, .4171875, .6734375, .4953125, .9125, .740625, .2421875, .3375, .3375, .409375, .60625, .2609375, .35625, .25625, .41875, .5921875, .3515625, .475, .4875, .5375, .509375, .5484375, .4546875, .5421875, .5484375, .25625, .2546875, .5875, .6171875, .5875, .4578125, .8140625, .6765625, .5703125, .6109375, .684375, .5109375, .4953125, .678125, .6859375, .2625, .2625, .5859375, .4734375, .846875, .709375, .740625, .509375, .740625, .584375, .5015625, .528125, .675, .5953125, .9453125, .596875, .540625, .540625, .359375, .4203125, .359375, .5109375, .421875, .4046875, .5015625, .5421875, .446875, .5453125, .484375, .38125, .5140625, .5546875, .240625, .2640625, .490625, .2765625, .8625, .5546875, .546875, .5453125, .5453125, .3625, .41875, .3890625, .5453125, .4703125, .7546875, .4921875, .4609375, .453125, .4015625, .2640625, .4015625, .58125],
                            avg: .5044078947368421
                        },
                        serif: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2484375, .334375, .409375, .5, .5, .834375, .778125, .18125, .334375, .334375, .5, .5640625, .25, .334375, .25, .278125, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .278125, .278125, .5640625, .5640625, .5640625, .4453125, .921875, .7234375, .6671875, .6671875, .7234375, .6109375, .55625, .7234375, .7234375, .334375, .390625, .7234375, .6109375, .890625, .7234375, .7234375, .55625, .7234375, .6671875, .55625, .6109375, .7234375, .7234375, .9453125, .7234375, .7234375, .6109375, .334375, .340625, .334375, .4703125, .5, .3453125, .4453125, .5, .4453125, .5, .4453125, .3828125, .5, .5, .278125, .3359375, .5, .278125, .778125, .5, .5, .5, .5, .3375, .390625, .2796875, .5, .5, .7234375, .5, .5, .4453125, .48125, .2015625, .48125, .5421875],
                            avg: .5126315789473684
                        },
                        Tahoma: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .3109375, .3328125, .4015625, .728125, .546875, .9765625, .70625, .2109375, .3828125, .3828125, .546875, .728125, .303125, .3640625, .303125, .3953125, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .546875, .3546875, .3546875, .728125, .728125, .728125, .475, .909375, .6109375, .590625, .6015625, .6796875, .5625, .521875, .66875, .6765625, .3734375, .4171875, .6046875, .4984375, .771875, .66875, .7078125, .5515625, .7078125, .6375, .5578125, .5875, .65625, .60625, .903125, .58125, .5890625, .559375, .3828125, .39375, .3828125, .728125, .5625, .546875, .525, .553125, .4625, .553125, .5265625, .3546875, .553125, .5578125, .2296875, .328125, .51875, .2296875, .840625, .5578125, .54375, .553125, .553125, .3609375, .446875, .3359375, .5578125, .4984375, .7421875, .4953125, .4984375, .4453125, .48125, .3828125, .48125, .728125],
                            avg: .5384374999999998
                        },
                        "Times New Roman": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .2484375, .334375, .409375, .5, .5, .834375, .778125, .18125, .334375, .334375, .5, .5640625, .25, .334375, .25, .28125, .5, .5, .5, .5, .5, .5, .5, .5, .5, .5, .278125, .278125, .5640625, .5640625, .5640625, .4453125, .921875, .7234375, .6671875, .6671875, .7234375, .6109375, .55625, .7234375, .7234375, .334375, .390625, .73125, .6109375, .890625, .7375, .7234375, .55625, .7234375, .6765625, .55625, .6109375, .7234375, .7234375, .9453125, .7234375, .7234375, .6109375, .334375, .28125, .334375, .4703125, .51875, .334375, .4453125, .503125, .4453125, .503125, .4453125, .4359375, .5, .5, .278125, .35625, .50625, .278125, .778125, .5, .5, .5046875, .5, .340625, .390625, .2796875, .5, .5, .7234375, .5, .5, .4453125, .48125, .2015625, .48125, .5421875],
                            avg: .5134375
                        },
                        "Trebuchet MS": {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .3015625, .3671875, .325, .53125, .525, .6015625, .70625, .1609375, .3671875, .3671875, .3671875, .525, .3671875, .3671875, .3671875, .525, .525, .525, .525, .525, .525, .525, .525, .525, .525, .525, .3671875, .3671875, .525, .525, .525, .3671875, .771875, .590625, .5671875, .5984375, .6140625, .5359375, .525, .6765625, .6546875, .2796875, .4765625, .5765625, .5078125, .7109375, .6390625, .675, .5578125, .7421875, .5828125, .48125, .58125, .6484375, .5875, .853125, .5578125, .5703125, .5515625, .3671875, .3578125, .3671875, .525, .53125, .525, .5265625, .5578125, .4953125, .5578125, .546875, .375, .503125, .546875, .2859375, .3671875, .5046875, .2953125, .83125, .546875, .5375, .5578125, .5578125, .3890625, .40625, .396875, .546875, .490625, .7453125, .5015625, .49375, .475, .3671875, .525, .3671875, .525],
                            avg: .5085197368421052
                        },
                        Verdana: {
                            widths: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, .35, .39375, .459375, .81875, .6359375, 1.0765625, .759375, .26875, .4546875, .4546875, .6359375, .81875, .3640625, .4546875, .3640625, .4703125, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .6359375, .4546875, .4546875, .81875, .81875, .81875, .546875, 1, .684375, .6859375, .6984375, .771875, .6328125, .575, .7765625, .7515625, .421875, .4546875, .69375, .5578125, .84375, .7484375, .7875, .603125, .7875, .7, .684375, .6171875, .7328125, .684375, .9890625, .6859375, .615625, .6859375, .4546875, .46875, .4546875, .81875, .6421875, .6359375, .6015625, .6234375, .521875, .6234375, .596875, .384375, .6234375, .6328125, .275, .3765625, .5921875, .275, .9734375, .6328125, .6078125, .6234375, .6234375, .43125, .521875, .3953125, .6328125, .5921875, .81875, .5921875, .5921875, .5265625, .6359375, .4546875, .6359375, .81875],
                            avg: .6171875000000003
                        }
                    },
                    nh = {
                        mm: 3.8,
                        sm: 38,
                        pt: 1.33,
                        pc: 16,
                        in: 96,
                        px: 1
                    },
                    rh = {
                        em: 1,
                        ex: .5
                    },
                    ih = 1.05,
                    ah = 1.15,
                    oh = {
                        lineHeight: 1,
                        letterSpacing: "0px",
                        fontSize: 0,
                        angle: 0,
                        fontFamily: ""
                    },
                    uh = function(t) {
                        return Array.isArray(t) ? t : t.toString().split(/\r\n|\r|\n/g)
                    },
                    ch = function(t, e, n) {
                        var r = function(t) {
                            return t * Math.PI / 180
                        }(n);
                        return Math.abs(Math.cos(r) * t) + Math.abs(Math.sin(r) * e)
                    },
                    lh = function(t, e) {
                        var n = t.match(/[a-zA-Z%]+/) && t.match(/[a-zA-Z%]+/)[0],
                            r = t.match(/[0-9.,]+/);
                        return n ? nh.hasOwnProperty(n) ? r * nh[n] : rh.hasOwnProperty(n) ? (e ? r * e : r * oh.fontSize) * rh[n] : r : r || 0
                    },
                    sh = function(t, e) {
                        var n = Array.isArray(t) ? t[e] : t,
                            r = sl({}, n, oh);
                        return Sl({}, r, {
                            fontFamily: r.fontFamily,
                            letterSpacing: "number" == typeof r.letterSpacing ? r.letterSpacing : lh(String(r.letterSpacing), r.fontSize),
                            fontSize: "number" == typeof r.fontSize ? r.fontSize : lh(String(r.fontSize))
                        })
                    },
                    fh = function(t, e) {
                        if (void 0 === t || "" === t || null === t) return 0;
                        var n = uh(t).map((function(t, n) {
                            var r = t.toString().length,
                                i = sh(e, n),
                                a = i.fontSize,
                                o = i.letterSpacing,
                                u = function(t) {
                                    var e = t.split(",").map((function(t) {
                                        return t.replace(/'|"/g, "")
                                    })).find((function(t) {
                                        return eh[t]
                                    })) || "Helvetica";
                                    return eh[e]
                                }(i.fontFamily),
                                c = t.toString().split("").map((function(t) {
                                    return t.charCodeAt(0) < u.widths.length ? u.widths[t.charCodeAt(0)] : u.avg
                                })).reduce((function(t, e) {
                                    return e + t
                                }), 0) * a;
                            return c + o * Math.max(r - 1, 0)
                        }));
                        return Math.max.apply(Math, th(n))
                    },
                    hh = function(t, e) {
                        var n = Array.isArray(e) ? e[0] && e[0].angle : e && e.angle,
                            r = function(t, e) {
                                return void 0 === t || "" === t || null === t ? 0 : uh(t).reduce((function(t, n, r) {
                                    var i = sh(e, r),
                                        a = n.toString().match(/[(A-Z)(0-9)]/) ? i.fontSize * ah : i.fontSize;
                                    return t + i.lineHeight * a
                                }), 0)
                            }(t, e),
                            i = fh(t, e);
                        return {
                            width: n ? ch(i, r, n) : i,
                            height: (n ? ch(r, i, n) : r) * ih
                        }
                    },
                    dh = function(t, e) {
                        return hh(t, e)
                    },
                    ph = function(t) {
                        return n.createElement("tspan", t)
                    };
                var yh = function(t) {
                    var e = t.children,
                        r = t.title,
                        i = t.desc,
                        a = function(t, e) {
                            if (null == t) return {};
                            var n, r, i = {},
                                a = Object.keys(t);
                            for (r = 0; r < a.length; r++) n = a[r], e.indexOf(n) >= 0 || (i[n] = t[n]);
                            if (Object.getOwnPropertySymbols) {
                                var o = Object.getOwnPropertySymbols(t);
                                for (r = 0; r < o.length; r++) n = o[r], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (i[n] = t[n])
                            }
                            return i
                        }(t, ["children", "title", "desc"]);
                    return n.createElement("text", a, r && n.createElement("title", null, r), i && n.createElement("desc", null, i), e)
                };
                yh.propTypes = {
                    children: C.node,
                    desc: C.string,
                    title: C.string
                };
                var vh = yh;

                function bh(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function gh(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }
                var mh = {
                        fill: "#252525",
                        fontSize: 14,
                        fontFamily: "'Gill Sans', 'Gill Sans MT', 'Ser­avek', 'Trebuchet MS', sans-serif",
                        stroke: "transparent"
                    },
                    _h = function(t, e) {
                        return t.datum ? of (t, t.datum)[e] : 0
                    },
                    xh = function(t) {
                        var e = t && t.fontSize;
                        if ("number" == typeof e) return e;
                        if (null == e) return mh.fontSize;
                        if ("string" == typeof e) {
                            var n = +e.replace("px", "");
                            return isNaN(n) ? mh.fontSize : n
                        }
                        return mh.fontSize
                    },
                    wh = function(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        return Array.isArray(t) ? t[e] || t[0] : t
                    },
                    kh = function(t) {
                        var e = t.backgroundStyle,
                            n = t.backgroundPadding;
                        return Array.isArray(e) && !Rf(e) || Array.isArray(n) && !Rf(n)
                    },
                    Oh = function(t, e, n) {
                        var r = t.polar,
                            i = wh(t.style),
                            a = r ? function(t, e) {
                                var n = t.labelPlacement,
                                    r = t.datum;
                                if (!n || "vertical" === n) return 0;
                                var i = void 0 !== e ? e % 360 : Qf(t, r),
                                    a = 0;
                                return 0 === i || 180 === i ? a = 90 : i > 0 && i < 180 ? a = 90 - i : i > 180 && i < 360 && (a = 270 - i), a + (i > 90 && i < 180 || i > 270 ? 1 : -1) * ("perpendicular" === n ? 0 : 90)
                            }(t) : 0,
                            o = void 0 === i.angle ? sf(t.angle, t) : i.angle,
                            u = void 0 === o ? a : o,
                            c = t.transform || i.transform,
                            l = c && sf(c, t);
                        return l || u ? Jf(l, u && {
                            rotate: [u, e, n]
                        }) : void 0
                    },
                    Ah = function(t, e) {
                        var n = t.direction,
                            r = t.textAnchor,
                            i = t.x,
                            a = t.dx;
                        if ("rtl" === n) return i - e;
                        switch (r) {
                            case "middle":
                                return Math.round(i - e / 2);
                            case "end":
                                return Math.round(i - e);
                            default:
                                return i + (a || 0)
                        }
                    },
                    Eh = function(t, e) {
                        var n = t.verticalAnchor,
                            r = t.y,
                            i = t.originalDy,
                            a = r + (void 0 === i ? 0 : i);
                        switch (n) {
                            case "start":
                                return Math.floor(a);
                            case "end":
                                return Math.ceil(a - e);
                            default:
                                return Math.floor(a - e / 2)
                        }
                    },
                    Mh = function(t, e) {
                        return kh(t) ? function(t, e) {
                            var r = t.dy,
                                i = t.dx,
                                a = t.transform,
                                o = t.backgroundStyle,
                                u = t.backgroundPadding,
                                c = t.backgroundComponent,
                                l = t.inline,
                                s = t.y,
                                f = e.map((function(t, n) {
                                    var a = wh(e, n - 1),
                                        o = t.textSize,
                                        c = t.fontSize * t.lineHeight,
                                        f = Math.ceil(c),
                                        h = wh(u, n),
                                        d = wh(u, n - 1),
                                        p = l && i || 0,
                                        y = n && !l ? a.fontSize * a.lineHeight + d.top + d.bottom : r - .5 * c - (t.fontSize - t.capHeight);
                                    return {
                                        textHeight: f,
                                        labelSize: o,
                                        heightWithPadding: f + h.top + h.bottom,
                                        widthWithPadding: o.width + h.left + h.right + p,
                                        y: s,
                                        fontSize: t.fontSize,
                                        dy: y
                                    }
                                }));
                            return f.map((function(e, r) {
                                var i = Ah(t, e.labelSize.width),
                                    h = f.slice(0, r + 1).reduce((function(t, e) {
                                        return t + e.dy
                                    }), s),
                                    d = wh(u, r),
                                    p = e.heightWithPadding,
                                    y = l ? function(t, e, n) {
                                        var r = t.textAnchor,
                                            i = e.map((function(t) {
                                                return t.widthWithPadding
                                            })),
                                            a = -i.reduce((function(t, e) {
                                                return t + e
                                            }), 0) / 2;
                                        switch (r) {
                                            case "start":
                                                return i.reduce((function(t, e, r) {
                                                    return r < n ? t + e : t
                                                }), 0);
                                            case "end":
                                                return i.reduce((function(t, e, r) {
                                                    return r > n ? t - e : t
                                                }), 0);
                                            default:
                                                return i.reduce((function(t, e, r) {
                                                    return r === n ? t + e / 2 : t + (r < n ? e : 0)
                                                }), a)
                                        }
                                    }(t, f, r) + i - d.left : i,
                                    v = l ? Eh(t, p) - d.top : h,
                                    b = {
                                        key: "tspan-background-".concat(r),
                                        height: p,
                                        style: wh(o, r),
                                        width: e.widthWithPadding,
                                        transform: a,
                                        x: y - d.left,
                                        y: v
                                    };
                                return n.cloneElement(c, sl({}, c.props, b))
                            }))
                        }(t, e) : function(t, e) {
                            var r = t.dx,
                                i = void 0 === r ? 0 : r,
                                a = t.transform,
                                o = t.backgroundComponent,
                                u = t.backgroundStyle,
                                c = t.inline,
                                l = t.backgroundPadding,
                                s = t.capHeight,
                                f = e.map((function(t) {
                                    return t.textSize
                                })),
                                h = c ? Math.max.apply(Math, gh(f.map((function(t) {
                                    return t.height
                                })))) : f.reduce((function(t, n, r) {
                                    var i = r ? 0 : s / 2;
                                    return t + n.height * (e[r].lineHeight - i)
                                }), 0),
                                d = c ? f.reduce((function(t, e, n) {
                                    var r = n ? i : 0;
                                    return t + e.width + r
                                }), 0) : Math.max.apply(Math, gh(f.map((function(t) {
                                    return t.width
                                })))),
                                p = Ah(t, d),
                                y = Eh(t, h),
                                v = {
                                    key: "background",
                                    height: h + l.top + l.bottom,
                                    style: u,
                                    transform: a,
                                    width: d + l.left + l.right,
                                    x: c ? p - l.left : p + i - l.left,
                                    y: y
                                };
                            return n.cloneElement(o, sl({}, o.props, v))
                        }(t, e)
                    },
                    Th = function(t, e, n) {
                        var r = e.inline,
                            i = wh(t, n);
                        return n && !r ? function(t, e, n) {
                            var r = wh(t, e),
                                i = wh(t, e - 1),
                                a = i.fontSize * i.lineHeight,
                                o = r.fontSize * r.lineHeight,
                                u = i.fontSize - i.capHeight,
                                c = r.fontSize - r.capHeight,
                                l = a - i.fontSize / 2 + r.fontSize / 2 - a / 2 + o / 2 - c / 2 + u / 2;
                            return kh(n) ? l + r.backgroundPadding.top + i.backgroundPadding.bottom : l
                        }(t, n, e) : r ? 0 === n ? i.backgroundPadding.top : void 0 : i.backgroundPadding.top
                    },
                    jh = function(t) {
                        var e = function(t, e) {
                                if (null != t) {
                                    if (Array.isArray(t)) return t.map((function(t) {
                                        return sf(t, e)
                                    }));
                                    var n = sf(t, e);
                                    if (null != n) return Array.isArray(n) ? n : "".concat(n).split("\n")
                                }
                            }(t.text, t),
                            n = function(t, e) {
                                if (e.disableInlineStyles) {
                                    var n = ff(t, e);
                                    return {
                                        fontSize: xh(n)
                                    }
                                }
                                var r = function(t) {
                                    var n = ff(t = t ? sl({}, t, mh) : mh, e);
                                    return Sl({}, n, {
                                        fontSize: xh(n)
                                    })
                                };
                                return Array.isArray(t) && !Rf(t) ? t.map((function(t) {
                                    return r(t)
                                })) : r(t)
                            }(t.style, Sl({}, t, {
                                text: e
                            })),
                            r = function(t, e) {
                                if (t) return Array.isArray(t) && !Rf(t) ? t.map((function(t) {
                                    return ff(t, e)
                                })) : ff(t, e)
                            }(t.backgroundStyle, Sl({}, t, {
                                text: e,
                                style: n
                            })),
                            i = function(t) {
                                return t.backgroundPadding && Array.isArray(t.backgroundPadding) ? t.backgroundPadding.map((function(e) {
                                    return uf({
                                        padding: sf(e, t)
                                    })
                                })) : uf({
                                    padding: sf(t.backgroundPadding, t)
                                })
                            }(Sl({}, t, {
                                text: e,
                                style: n,
                                backgroundStyle: r
                            })),
                            a = sf(t.id, t);
                        return Sl({}, t, {
                            backgroundStyle: r,
                            backgroundPadding: i,
                            style: n,
                            text: e,
                            id: a
                        })
                    },
                    Ph = function(t) {
                        var e = sf(t.ariaLabel, t),
                            n = wh(t.style),
                            r = function(t) {
                                var e = sf(t.lineHeight, t);
                                return Array.isArray(e) && Rf(e) ? [1] : e
                            }(t),
                            i = t.direction ? sf(t.direction, t) : "inherit",
                            a = t.textAnchor ? sf(t.textAnchor, t) : n.textAnchor || "start",
                            o = t.verticalAnchor ? sf(t.verticalAnchor, t) : n.verticalAnchor || "middle",
                            u = t.dx ? sf(t.dx, t) : 0,
                            c = function(t, e, n) {
                                var r = t.dy ? sf(t.dy, t) : 0,
                                    i = t.inline ? 1 : t.text.length,
                                    a = sf(t.capHeight, t),
                                    o = e ? sf(e, t) : "middle",
                                    u = gh(Array(i).keys()).map((function(e) {
                                        return wh(t.style, e).fontSize
                                    })),
                                    c = gh(Array(i).keys()).map((function(t) {
                                        return wh(n, t)
                                    }));
                                if ("start" === o) return r + (a / 2 + c[0] / 2) * u[0];
                                if (t.inline) return "end" === o ? r + (a / 2 - c[0] / 2) * u[0] : r + a / 2 * u[0];
                                if (1 === i) return "end" === o ? r + (a / 2 + (.5 - i) * c[0]) * u[0] : r + (a / 2 + (.5 - i / 2) * c[0]) * u[0];
                                var l = gh(Array(i).keys()).reduce((function(t, e) {
                                    return t + (a / 2 + (.5 - i) * c[e]) * u[e] / i
                                }), 0);
                                return "end" === o ? r + l : r + l / 2 + a / 2 * c[i - 1] * u[i - 1]
                            }(t, o, r),
                            l = void 0 !== t.x ? t.x : _h(t, "x"),
                            s = void 0 !== t.y ? t.y : _h(t, "y"),
                            f = Oh(t, l, s);
                        return Sl({}, t, {
                            ariaLabel: e,
                            lineHeight: r,
                            direction: i,
                            textAnchor: a,
                            verticalAnchor: o,
                            dx: u,
                            dy: c,
                            originalDy: t.dy,
                            transform: f,
                            x: l,
                            y: s
                        })
                    },
                    Sh = function(t, e) {
                        var r = t.ariaLabel,
                            i = t.inline,
                            a = t.className,
                            o = t.title,
                            u = t.events,
                            c = t.direction,
                            l = t.text,
                            s = t.textAnchor,
                            f = t.dx,
                            h = t.dy,
                            d = t.transform,
                            p = t.x,
                            y = t.y,
                            v = t.desc,
                            b = t.id,
                            g = t.tabIndex,
                            m = t.tspanComponent,
                            _ = t.textComponent,
                            x = function(t) {
                                for (var e = 1; e < arguments.length; e++) {
                                    var n = null != arguments[e] ? arguments[e] : {},
                                        r = Object.keys(n);
                                    "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                                    })))), r.forEach((function(e) {
                                        bh(t, e, n[e])
                                    }))
                                }
                                return t
                            }({
                                "aria-label": r,
                                key: "text"
                            }, u, {
                                direction: c,
                                dx: f,
                                x: p,
                                y: y + h,
                                transform: d,
                                className: a,
                                title: o,
                                desc: sf(v, t),
                                tabIndex: sf(g, t),
                                id: b
                            }),
                            w = l.map((function(r, a) {
                                var o = e[a].style,
                                    u = {
                                        key: "".concat(b, "-key-").concat(a),
                                        x: i ? void 0 : p,
                                        dx: i ? f + e[a].backgroundPadding.left : f,
                                        dy: Th(e, t, a),
                                        textAnchor: o.textAnchor || s,
                                        style: o,
                                        children: r
                                    };
                                return n.cloneElement(m, u)
                            }));
                        return n.cloneElement(_, x, w)
                    },
                    Ch = function(t) {
                        if (null === (t = jh(t)).text || void 0 === t.text) return null;
                        var e = Ph(t),
                            r = e.text,
                            i = e.style,
                            a = e.capHeight,
                            o = e.backgroundPadding,
                            u = e.lineHeight,
                            c = r.map((function(t, e) {
                                var n = wh(i, e),
                                    r = lh("".concat(a, "em"), n.fontSize),
                                    c = wh(u, e);
                                return {
                                    style: n,
                                    fontSize: n.fontSize || mh.fontSize,
                                    capHeight: r,
                                    text: t,
                                    textSize: dh(t, n),
                                    lineHeight: c,
                                    backgroundPadding: wh(o, e)
                                }
                            })),
                            l = Sh(e, c);
                        if (t.backgroundStyle) {
                            var s = [Mh(e, c), l],
                                f = n.cloneElement(t.groupComponent, {}, s);
                            return t.renderInPortal ? n.createElement(Hf, null, f) : f
                        }
                        return t.renderInPortal ? n.createElement(Hf, null, l) : l
                    };
                Ch.displayName = "VictoryLabel", Ch.role = "label", Ch.defaultStyles = mh, Ch.propTypes = {
                    active: C.bool,
                    angle: C.oneOfType([C.string, C.number, C.func]),
                    ariaLabel: C.oneOfType([C.string, C.func]),
                    backgroundComponent: C.element,
                    backgroundPadding: C.oneOfType([C.number, C.object, C.array]),
                    backgroundStyle: C.oneOfType([C.object, C.array]),
                    capHeight: C.oneOfType([C.string, _s, C.func]),
                    className: C.string,
                    data: C.array,
                    datum: C.any,
                    desc: C.oneOfType([C.string, C.func]),
                    direction: C.oneOf(["rtl", "ltr", "inherit"]),
                    dx: C.oneOfType([C.number, C.string, C.func]),
                    dy: C.oneOfType([C.number, C.string, C.func]),
                    events: C.object,
                    groupComponent: C.element,
                    id: C.oneOfType([C.number, C.string, C.func]),
                    index: C.oneOfType([C.number, C.string]),
                    inline: C.bool,
                    labelPlacement: C.oneOf(["parallel", "perpendicular", "vertical"]),
                    lineHeight: C.oneOfType([C.string, _s, C.func, C.array]),
                    origin: C.shape({
                        x: _s,
                        y: _s
                    }),
                    polar: C.bool,
                    renderInPortal: C.bool,
                    scale: C.shape({
                        x: ks,
                        y: ks
                    }),
                    style: C.oneOfType([C.object, C.array]),
                    tabIndex: C.oneOfType([C.number, C.func]),
                    text: C.oneOfType([C.string, C.number, C.func, C.array]),
                    textAnchor: C.oneOfType([C.oneOf(["start", "middle", "end", "inherit"]), C.func]),
                    textComponent: C.element,
                    title: C.string,
                    transform: C.oneOfType([C.string, C.object, C.func]),
                    tspanComponent: C.element,
                    verticalAnchor: C.oneOfType([C.oneOf(["start", "middle", "end"]), C.func]),
                    x: C.oneOfType([C.number, C.string]),
                    y: C.oneOfType([C.number, C.string])
                }, Ch.defaultProps = {
                    backgroundComponent: n.createElement(Yf, null),
                    groupComponent: n.createElement("g", null),
                    direction: "inherit",
                    textComponent: n.createElement(vh, null),
                    tspanComponent: n.createElement(ph, null),
                    capHeight: .71,
                    lineHeight: 1
                };
                var Nh = Ch;

                function Dh(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function Ih(t) {
                    return Array.isArray(t) && t.some((function(t) {
                        return t instanceof Date
                    }))
                }

                function Lh(t) {
                    return function(t) {
                        return Array.isArray(t) && t.length > 0
                    }(t) && t.every(Array.isArray)
                }

                function zh(t) {
                    return t.filter((function(t) {
                        return void 0 !== t
                    }))
                }

                function Wh(t) {
                    for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                    var i = t.concat(n);
                    return Ih(i) ? new Date(Math.max.apply(Math, Dh(i))) : Math.max.apply(Math, Dh(i))
                }

                function Fh(t) {
                    for (var e = arguments.length, n = new Array(e > 1 ? e - 1 : 0), r = 1; r < e; r++) n[r - 1] = arguments[r];
                    var i = t.concat(n);
                    return Ih(i) ? new Date(Math.min.apply(Math, Dh(i))) : Math.min.apply(Math, Dh(i))
                }

                function Rh(t, e) {
                    return (t.key || e).toString()
                }

                function Uh(t) {
                    return t.reduce((function(t, e, n) {
                        return t[Rh(e, n)] = e, t
                    }), {})
                }

                function qh(t, e) {
                    var n = !1,
                        r = si(t).reduce((function(t, r) {
                            return r in e || (n = !0, t[r] = !0), t
                        }), {});
                    return n && r
                }

                function Bh(t) {
                    return t.type && t.type.getData ? t.type.getData(t.props) : t.props && t.props.data || !1
                }

                function Hh(t, e) {
                    var r = !1,
                        i = !1,
                        a = function(t, e) {
                            if (!e || t.type !== e.type) return {};
                            var n, a, o, u, c = (n = Bh(t), a = Bh(e), o = n && Uh(n), u = a && Uh(a), {
                                    entering: o && qh(u, o),
                                    exiting: u && qh(o, u)
                                } || {}),
                                l = c.entering,
                                s = c.exiting;
                            return r = r || !!s, i = i || !!l, {
                                entering: l || !1,
                                exiting: s || !1
                            }
                        },
                        o = function(t, e) {
                            return t.map((function(r, i) {
                                return r && r.props && r.props.children && e[i] ? o(n.Children.toArray(t[i].props.children), n.Children.toArray(e[i].props.children)) : a(r, e[i])
                            }))
                        },
                        u = o(n.Children.toArray(t), n.Children.toArray(e));
                    return {
                        nodesWillExit: r,
                        nodesWillEnter: i,
                        childrenTransitions: u,
                        nodesShouldEnter: !1
                    }
                }

                function Kh(t, e, n) {
                    var r = e && e.nodesWillExit,
                        i = e && e.nodesWillEnter,
                        a = e && e.nodesShouldEnter,
                        o = e && e.nodesShouldLoad,
                        u = e && e.nodesDoneLoad,
                        c = e && e.childrenTransitions || [],
                        l = {
                            enter: t.animate && t.animate.onEnter && t.animate.onEnter.duration,
                            exit: t.animate && t.animate.onExit && t.animate.onExit.duration,
                            load: t.animate && t.animate.onLoad && t.animate.onLoad.duration,
                            move: t.animate && t.animate.duration
                        },
                        s = function(t, e, r) {
                            return o ? function(t, e, n) {
                                if ((t = Sl({}, t, {
                                        onEnd: n
                                    })) && t.onLoad && !t.onLoad.duration) return {
                                    animate: t,
                                    data: e
                                };
                                var r = t.onLoad && t.onLoad.after ? t.onLoad.after : La;
                                return {
                                    animate: t,
                                    data: e = e.map((function(t, n) {
                                        return Sl({}, t, r(t, n, e))
                                    }))
                                }
                            }(r, e, (function() {
                                n({
                                    nodesShouldLoad: !1,
                                    nodesDoneLoad: !0
                                })
                            })) : function(t, e, n, r) {
                                if ((t = Sl({}, t, {
                                        onEnd: r
                                    })) && t.onLoad && !t.onLoad.duration) return {
                                    animate: t,
                                    data: n
                                };
                                var i = t.onLoad && t.onLoad.before ? t.onLoad.before : La;
                                return {
                                    animate: t,
                                    data: n = n.map((function(t, e) {
                                        return Sl({}, t, i(t, e, n))
                                    })),
                                    clipWidth: 0
                                }
                            }(r, 0, e, (function() {
                                n({
                                    nodesDoneLoad: !0
                                })
                            }))
                        },
                        f = function(t, e, r, i) {
                            return function(t, e, n, r, i) {
                                var a = t && t.onExit;
                                if (t = Sl({}, t, a), r) {
                                    t.onEnd = i;
                                    var o = t.onExit && t.onExit.before ? t.onExit.before : La;
                                    n = n.map((function(t, e) {
                                        var i = (t.key || e).toString();
                                        return r[i] ? Sl({}, t, o(t, e, n)) : t
                                    }))
                                }
                                return {
                                    animate: t,
                                    data: n
                                }
                            }(i, 0, r, t, (function() {
                                n({
                                    nodesWillExit: !1
                                })
                            }))
                        },
                        h = function(t, e, r, i) {
                            return a ? function(t, e, n, r) {
                                var i = t && t.onEnter;
                                if (t = Sl({}, t, i), n) {
                                    t.onEnd = r;
                                    var a = t.onEnter && t.onEnter.after ? t.onEnter.after : La;
                                    e = e.map((function(t, r) {
                                        var i = Rh(t, r);
                                        return n[i] ? Sl({}, t, a(t, r, e)) : t
                                    }))
                                }
                                return {
                                    animate: t,
                                    data: e
                                }
                            }(i, r, t, (function() {
                                n({
                                    nodesWillEnter: !1
                                })
                            })) : function(t, e, n, r, i) {
                                if (r) {
                                    var a = (t = Sl({}, t, {
                                        onEnd: i
                                    })).onEnter && t.onEnter.before ? t.onEnter.before : La;
                                    n = n.map((function(t, e) {
                                        var i = (t.key || e).toString();
                                        return r[i] ? Sl({}, t, a(t, e, n)) : t
                                    }))
                                }
                                return {
                                    animate: t,
                                    data: n
                                }
                            }(i, 0, r, t, (function() {
                                n({
                                    nodesShouldEnter: !0
                                })
                            }))
                        },
                        d = function(t, e) {
                            var n = t.props.animate;
                            if (!t.type) return {};
                            var r = t.props && t.props.polar && t.type.defaultPolarTransitions || t.type.defaultTransitions;
                            if (r) {
                                var i = n[e] && n[e].duration;
                                return void 0 !== i ? i : r[e] && r[e].duration
                            }
                            return {}
                        };
                    return function(n, o) {
                        var p = Bh(n) || [],
                            y = sl({}, t.animate, n.props.animate),
                            v = n.props.polar && n.type.defaultPolarTransitions || n.type.defaultTransitions;
                        y.onExit = sl({}, y.onExit, v && v.onExit), y.onEnter = sl({}, y.onEnter, v && v.onEnter), y.onLoad = sl({}, y.onLoad, v && v.onLoad);
                        var b = c[o] || c[0];
                        if (!u) {
                            var g = void 0 !== l.load ? l.load : d(n, "onLoad");
                            return s(0, p, Sl({}, y, {
                                duration: g
                            }))
                        }
                        if (r) {
                            var m = b && b.exiting,
                                _ = void 0 !== l.exit ? l.exit : d(n, "onExit");
                            return f(m, 0, p, Sl({}, y, m ? {
                                duration: _
                            } : {
                                delay: _
                            }))
                        }
                        if (i) {
                            var x = b && b.entering,
                                w = void 0 !== l.enter ? l.enter : d(n, "onEnter"),
                                k = void 0 !== l.move ? l.move : n.props.animate && n.props.animate.duration;
                            return h(x, 0, p, Sl({}, y, {
                                duration: a && x ? w : k
                            }))
                        }
                        return !e && y && y.onExit ? function(t, e) {
                            var n = t.onEnter && t.onEnter.after ? t.onEnter.after : La;
                            return {
                                data: e.map((function(t, r) {
                                    return Sl({}, t, n(t, r, e))
                                }))
                            }
                        }(y, p) : {
                            animate: y,
                            data: p
                        }
                    }
                }

                function Yh() {
                    return Yh = Object.assign || function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = arguments[e];
                            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
                        }
                        return t
                    }, Yh.apply(this, arguments)
                }

                function Vh(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function Gh(t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }
                var $h = function(t) {
                    function e(t, n) {
                        var r;
                        ! function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), (r = function(t, e) {
                            return !e || "object" != typeof e && "function" != typeof e ? Gh(t) : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t, n))).state = {
                            nodesShouldLoad: !1,
                            nodesDoneLoad: !1
                        };
                        var i = r.props.children,
                            a = i.props.polar;
                        return r.continuous = !a && i.type && !0 === i.type.continuous, r.getTransitionState = r.getTransitionState.bind(Gh(r)), r.timer = r.context.transitionTimer, r
                    }
                    var r, i, a;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), r = e, i = [{
                        key: "componentDidMount",
                        value: function() {
                            this.setState({
                                nodesShouldLoad: !0
                            })
                        }
                    }, {
                        key: "shouldComponentUpdate",
                        value: function(t) {
                            var e = this;
                            return bc(this.props, t) || (this.timer.bypassAnimation(), this.setState(this.getTransitionState(this.props, t), (function() {
                                return e.timer.resumeAnimation()
                            }))), !0
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            this.timer.stop()
                        }
                    }, {
                        key: "getTransitionState",
                        value: function(t, e) {
                            var r = t.animate;
                            if (r) {
                                if (r.parentState) return {
                                    oldProps: r.parentState.nodesWillExit ? t : null,
                                    nextProps: e
                                };
                                var i = Hh(n.Children.toArray(t.children), n.Children.toArray(e.children)),
                                    a = i.nodesWillExit;
                                return {
                                    nodesWillExit: a,
                                    nodesWillEnter: i.nodesWillEnter,
                                    childrenTransitions: i.childrenTransitions,
                                    nodesShouldEnter: i.nodesShouldEnter,
                                    oldProps: a ? t : null,
                                    nextProps: e
                                }
                            }
                            return {}
                        }
                    }, {
                        key: "getDomainFromChildren",
                        value: function(t, e) {
                            var r = function(t) {
                                    return t.reduce((function(t, i) {
                                        if (i.type && It(i.type.getDomain)) {
                                            var a = i.props && i.type.getDomain(i.props, e);
                                            return a ? t.concat(a) : t
                                        }
                                        return i.props && i.props.children ? t.concat(r(n.Children.toArray(i.props.children))) : t
                                    }), [])
                                },
                                i = n.Children.toArray(t.children)[0],
                                a = i.props || {},
                                o = Array.isArray(a.domain) ? a.domain : a.domain && a.domain[e];
                            if (!a.children && o) return o;
                            var u = r([i]);
                            return 0 === u.length ? [0, 1] : [Fh(u), Wh(u)]
                        }
                    }, {
                        key: "pickProps",
                        value: function() {
                            return this.state && this.state.nodesWillExit && this.state.oldProps || this.props
                        }
                    }, {
                        key: "pickDomainProps",
                        value: function(t) {
                            var e = Pt(t.animate) && t.animate.parentState;
                            return e && e.nodesWillExit ? (this.continous || e.continuous) && (e.nextProps || this.state.nextProps) || t : this.continuous && this.state.nodesWillExit && this.state.nextProps || t
                        }
                    }, {
                        key: "getClipWidth",
                        value: function(t, e) {
                            var n = this.transitionProps ? this.transitionProps.clipWidth : void 0;
                            return void 0 !== n ? n : function() {
                                var n = yf(e.props, "x");
                                return n ? Math.abs(n[1] - n[0]) : t.width
                            }()
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this,
                                e = this.pickProps(),
                                r = Pt(this.props.animate) && this.props.animate.getTransitions ? this.props.animate.getTransitions : Kh(e, this.state, (function(e) {
                                    return t.setState(e)
                                })),
                                i = n.Children.toArray(e.children)[0],
                                a = r(i);
                            this.transitionProps = a;
                            var o = {
                                    x: this.getDomainFromChildren(this.pickDomainProps(e), "x"),
                                    y: this.getDomainFromChildren(e, "y")
                                },
                                u = this.getClipWidth(e, i),
                                c = sl({
                                    domain: o,
                                    clipWidth: u
                                }, a, i.props),
                                l = (e.animationWhitelist || []).concat(["clipWidth"]),
                                s = l.length ? nf(c, l) : c;
                            return n.createElement(xc, Yh({}, c.animate, {
                                data: s
                            }), (function(e) {
                                if (i.props.groupComponent) {
                                    var r = t.continuous ? n.cloneElement(i.props.groupComponent, {
                                        clipWidth: e.clipWidth || 0
                                    }) : i.props.groupComponent;
                                    return n.cloneElement(i, sl({
                                        animate: null,
                                        animating: !0,
                                        groupComponent: r
                                    }, e, c))
                                }
                                return n.cloneElement(i, sl({
                                    animate: null,
                                    animating: !0
                                }, e, c))
                            }))
                        }
                    }], i && Vh(r.prototype, i), a && Vh(r, a), e
                }(n.Component);
                Object.defineProperty($h, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryTransition"
                }), Object.defineProperty($h, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        animate: C.oneOfType([C.bool, C.object]),
                        animationWhitelist: C.array,
                        children: C.node
                    }
                }), Object.defineProperty($h, "contextType", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: fc
                });
                var Xh = function(t) {
                    return n.createElement("defs", null, n.createElement("clipPath", {
                        id: t.clipId
                    }, t.children))
                };
                Xh.propTypes = {
                    children: C.oneOfType([C.arrayOf(C.node), C.node]),
                    clipId: C.oneOfType([C.number, C.string])
                };
                var Qh = Xh;

                function Zh() {
                    return Zh = Object.assign || function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = arguments[e];
                            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r])
                        }
                        return t
                    }, Zh.apply(this, arguments)
                }
                var Jh = function(t) {
                    var e = t.desc,
                        r = function(t, e) {
                            if (null == t) return {};
                            var n, r, i = {},
                                a = Object.keys(t);
                            for (r = 0; r < a.length; r++) n = a[r], e.indexOf(n) >= 0 || (i[n] = t[n]);
                            if (Object.getOwnPropertySymbols) {
                                var o = Object.getOwnPropertySymbols(t);
                                for (r = 0; r < o.length; r++) n = o[r], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (i[n] = t[n])
                            }
                            return i
                        }(t, ["desc"]);
                    return e ? n.createElement("circle", Zh({
                        vectorEffect: "non-scaling-stroke"
                    }, r), n.createElement("desc", null, e)) : n.createElement("circle", Zh({
                        vectorEffect: "non-scaling-stroke"
                    }, r))
                };

                function td(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function ed(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function nd(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function rd(t, e) {
                    return !e || "object" != typeof e && "function" != typeof e ? function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t) : e
                }
                var id = function(t) {
                    function e(t) {
                        var n;
                        return function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), (n = rd(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t))).clipId = Pt(t) && void 0 !== t.clipId ? t.clipId : Oc("victory-clip-"), n
                    }
                    var r, i, a;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), r = e, i = [{
                        key: "calculateAttributes",
                        value: function(t) {
                            var e = t.polar,
                                n = t.origin,
                                r = t.clipWidth,
                                i = void 0 === r ? 0 : r,
                                a = t.clipHeight,
                                o = void 0 === a ? 0 : a,
                                u = t.translateX,
                                c = void 0 === u ? 0 : u,
                                l = t.translateY,
                                s = void 0 === l ? 0 : l,
                                f = uf({
                                    padding: t.clipPadding
                                }),
                                h = t.radius || df(t);
                            return {
                                x: (e ? n.x : c) - f.left,
                                y: (e ? n.y : s) - f.top,
                                width: Math.max((e ? h : i) + f.left + f.right, 0),
                                height: Math.max((e ? h : o) + f.top + f.bottom, 0)
                            }
                        }
                    }, {
                        key: "renderClippedGroup",
                        value: function(t, e) {
                            var r = t.style,
                                i = t.events,
                                a = t.transform,
                                o = t.children,
                                u = t.className,
                                c = t.groupComponent,
                                l = t.tabIndex,
                                s = this.renderClipComponent(t, e),
                                f = Sl({
                                    className: u,
                                    style: r,
                                    transform: a,
                                    key: "clipped-group-".concat(e),
                                    clipPath: "url(#".concat(e, ")")
                                }, i);
                            return n.cloneElement(c, function(t) {
                                for (var e = 1; e < arguments.length; e++) {
                                    var n = null != arguments[e] ? arguments[e] : {},
                                        r = Object.keys(n);
                                    "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                                    })))), r.forEach((function(e) {
                                        ed(t, e, n[e])
                                    }))
                                }
                                return t
                            }({}, f, {
                                "aria-label": t["aria-label"],
                                tabIndex: l
                            }), [s].concat(td(n.Children.toArray(o))))
                        }
                    }, {
                        key: "renderGroup",
                        value: function(t) {
                            var e = t.style,
                                r = t.events,
                                i = t.transform,
                                a = t.children,
                                o = t.className,
                                u = t.groupComponent,
                                c = t.tabIndex;
                            return n.cloneElement(u, Sl({
                                className: o,
                                style: e,
                                transform: i,
                                "aria-label": t["aria-label"],
                                tabIndex: c
                            }, r), a)
                        }
                    }, {
                        key: "renderClipComponent",
                        value: function(t, e) {
                            var r, i = t.polar,
                                a = t.origin,
                                o = t.clipWidth,
                                u = void 0 === o ? 0 : o,
                                c = t.clipHeight,
                                l = void 0 === c ? 0 : c,
                                s = t.translateX,
                                f = void 0 === s ? 0 : s,
                                h = t.translateY,
                                d = void 0 === h ? 0 : h,
                                p = t.circleComponent,
                                y = t.rectComponent,
                                v = t.clipPathComponent,
                                b = uf({
                                    padding: t.clipPadding
                                }),
                                g = b.top,
                                m = b.bottom,
                                _ = b.left,
                                x = b.right;
                            if (i) {
                                var w = t.radius || df(t),
                                    k = {
                                        r: Math.max(w + _ + x, w + g + m, 0),
                                        cx: a.x - _,
                                        cy: a.y - g
                                    };
                                r = n.cloneElement(p, k)
                            } else {
                                var O = {
                                    x: f - _,
                                    y: d - g,
                                    width: Math.max(u + _ + x, 0),
                                    height: Math.max(l + g + m, 0)
                                };
                                r = n.cloneElement(y, O)
                            }
                            return n.cloneElement(v, Sl({
                                key: "clip-path-".concat(e)
                            }, t, {
                                clipId: e
                            }), r)
                        }
                    }, {
                        key: "getClipValue",
                        value: function(t, e) {
                            var n = {
                                x: t.clipWidth,
                                y: t.clipHeight
                            };
                            if (void 0 !== n[e]) return n[e];
                            var r = yf(t, e);
                            return r && Math.abs(r[0] - r[1]) || void 0
                        }
                    }, {
                        key: "getTranslateValue",
                        value: function(t, e) {
                            var n = {
                                x: t.translateX,
                                y: t.translateY
                            };
                            if (void 0 !== n[e]) return n[e];
                            var r = yf(t, e);
                            return r ? Math.min.apply(Math, td(r)) : void 0
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.getClipValue(this.props, "y"),
                                e = this.getClipValue(this.props, "x");
                            if (void 0 === e || void 0 === t) return this.renderGroup(this.props);
                            var n = this.getTranslateValue(this.props, "x"),
                                r = this.getTranslateValue(this.props, "y"),
                                i = sl({}, this.props, {
                                    clipHeight: t,
                                    clipWidth: e,
                                    translateX: n,
                                    translateY: r
                                });
                            return this.renderClippedGroup(i, this.clipId)
                        }
                    }], i && nd(r.prototype, i), a && nd(r, a), e
                }(n.Component);
                Object.defineProperty(id, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryClipContainer"
                }), Object.defineProperty(id, "role", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "container"
                }), Object.defineProperty(id, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        "aria-label": C.string,
                        children: C.oneOfType([C.arrayOf(C.node), C.node]),
                        circleComponent: C.element,
                        className: C.string,
                        clipHeight: _s,
                        clipId: C.oneOfType([C.number, C.string]),
                        clipPadding: C.shape({
                            top: C.number,
                            bottom: C.number,
                            left: C.number,
                            right: C.number
                        }),
                        clipPathComponent: C.element,
                        clipWidth: _s,
                        events: C.object,
                        groupComponent: C.element,
                        origin: C.shape({
                            x: _s,
                            y: _s
                        }),
                        polar: C.bool,
                        radius: _s,
                        style: C.object,
                        tabIndex: C.number,
                        transform: C.string,
                        translateX: C.number,
                        translateY: C.number
                    }
                }), Object.defineProperty(id, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        circleComponent: n.createElement(Jh, null),
                        rectComponent: n.createElement(Yf, null),
                        clipPathComponent: n.createElement(Qh, null),
                        groupComponent: n.createElement("g", null)
                    }
                });
                var ad = ["#F4511E", "#FFF59D", "#DCE775", "#8BC34A", "#00796B", "#006064"],
                    od = "#ECEFF1",
                    ud = "#90A4AE",
                    cd = "#455A64",
                    ld = "#212121",
                    sd = {
                        width: 350,
                        height: 350,
                        padding: 50
                    },
                    fd = {
                        fontFamily: "'Helvetica Neue', 'Helvetica', sans-serif",
                        fontSize: 12,
                        letterSpacing: "normal",
                        padding: 8,
                        fill: cd,
                        stroke: "transparent",
                        strokeWidth: 0
                    },
                    hd = Sl({
                        textAnchor: "middle"
                    }, fd),
                    dd = "round",
                    pd = "round",
                    yd = {
                        area: Sl({
                            style: {
                                data: {
                                    fill: ld
                                },
                                labels: fd
                            }
                        }, sd),
                        axis: Sl({
                            style: {
                                axis: {
                                    fill: "transparent",
                                    stroke: ud,
                                    strokeWidth: 2,
                                    strokeLinecap: dd,
                                    strokeLinejoin: pd
                                },
                                axisLabel: Sl({}, hd, {
                                    padding: 8,
                                    stroke: "transparent"
                                }),
                                grid: {
                                    fill: "none",
                                    stroke: od,
                                    strokeDasharray: "10, 5",
                                    strokeLinecap: dd,
                                    strokeLinejoin: pd,
                                    pointerEvents: "painted"
                                },
                                ticks: {
                                    fill: "transparent",
                                    size: 5,
                                    stroke: ud,
                                    strokeWidth: 1,
                                    strokeLinecap: dd,
                                    strokeLinejoin: pd
                                },
                                tickLabels: Sl({}, fd, {
                                    fill: cd
                                })
                            }
                        }, sd),
                        polarDependentAxis: Sl({
                            style: {
                                ticks: {
                                    fill: "transparent",
                                    size: 1,
                                    stroke: "transparent"
                                }
                            }
                        }),
                        bar: Sl({
                            style: {
                                data: {
                                    fill: cd,
                                    padding: 8,
                                    strokeWidth: 0
                                },
                                labels: fd
                            }
                        }, sd),
                        boxplot: Sl({
                            style: {
                                max: {
                                    padding: 8,
                                    stroke: cd,
                                    strokeWidth: 1
                                },
                                maxLabels: Sl({}, fd, {
                                    padding: 3
                                }),
                                median: {
                                    padding: 8,
                                    stroke: cd,
                                    strokeWidth: 1
                                },
                                medianLabels: Sl({}, fd, {
                                    padding: 3
                                }),
                                min: {
                                    padding: 8,
                                    stroke: cd,
                                    strokeWidth: 1
                                },
                                minLabels: Sl({}, fd, {
                                    padding: 3
                                }),
                                q1: {
                                    padding: 8,
                                    fill: cd
                                },
                                q1Labels: Sl({}, fd, {
                                    padding: 3
                                }),
                                q3: {
                                    padding: 8,
                                    fill: cd
                                },
                                q3Labels: Sl({}, fd, {
                                    padding: 3
                                })
                            },
                            boxWidth: 20
                        }, sd),
                        candlestick: Sl({
                            style: {
                                data: {
                                    stroke: cd
                                },
                                labels: Sl({}, fd, {
                                    padding: 5
                                })
                            },
                            candleColors: {
                                positive: "#ffffff",
                                negative: cd
                            }
                        }, sd),
                        chart: sd,
                        errorbar: Sl({
                            borderWidth: 8,
                            style: {
                                data: {
                                    fill: "transparent",
                                    opacity: 1,
                                    stroke: cd,
                                    strokeWidth: 2
                                },
                                labels: fd
                            }
                        }, sd),
                        group: Sl({
                            colorScale: ad
                        }, sd),
                        histogram: Sl({
                            style: {
                                data: {
                                    fill: cd,
                                    stroke: ld,
                                    strokeWidth: 2
                                },
                                labels: fd
                            }
                        }, sd),
                        legend: {
                            colorScale: ad,
                            gutter: 10,
                            orientation: "vertical",
                            titleOrientation: "top",
                            style: {
                                data: {
                                    type: "circle"
                                },
                                labels: fd,
                                title: Sl({}, fd, {
                                    padding: 5
                                })
                            }
                        },
                        line: Sl({
                            style: {
                                data: {
                                    fill: "transparent",
                                    opacity: 1,
                                    stroke: cd,
                                    strokeWidth: 2
                                },
                                labels: fd
                            }
                        }, sd),
                        pie: Sl({
                            colorScale: ad,
                            style: {
                                data: {
                                    padding: 8,
                                    stroke: od,
                                    strokeWidth: 1
                                },
                                labels: Sl({}, fd, {
                                    padding: 20
                                })
                            }
                        }, sd),
                        scatter: Sl({
                            style: {
                                data: {
                                    fill: cd,
                                    opacity: 1,
                                    stroke: "transparent",
                                    strokeWidth: 0
                                },
                                labels: fd
                            }
                        }, sd),
                        stack: Sl({
                            colorScale: ad
                        }, sd),
                        tooltip: {
                            style: Sl({}, fd, {
                                padding: 0,
                                pointerEvents: "none"
                            }),
                            flyoutStyle: {
                                stroke: ld,
                                strokeWidth: 1,
                                fill: "#f0f0f0",
                                pointerEvents: "none"
                            },
                            flyoutPadding: 5,
                            cornerRadius: 5,
                            pointerLength: 10
                        },
                        voronoi: Sl({
                            style: {
                                data: {
                                    fill: "transparent",
                                    stroke: "transparent",
                                    strokeWidth: 0
                                },
                                labels: Sl({}, fd, {
                                    padding: 5,
                                    pointerEvents: "none"
                                }),
                                flyout: {
                                    stroke: ld,
                                    strokeWidth: 1,
                                    fill: "#f0f0f0",
                                    pointerEvents: "none"
                                }
                            }
                        }, sd)
                    },
                    vd = ["#252525", "#525252", "#737373", "#969696", "#bdbdbd", "#d9d9d9", "#f0f0f0"],
                    bd = "#252525",
                    gd = "#969696",
                    md = {
                        width: 450,
                        height: 300,
                        padding: 50,
                        colorScale: vd
                    },
                    _d = {
                        fontFamily: "'Gill Sans', 'Seravek', 'Trebuchet MS', sans-serif",
                        fontSize: 14,
                        letterSpacing: "normal",
                        padding: 10,
                        fill: bd,
                        stroke: "transparent"
                    },
                    xd = Sl({
                        textAnchor: "middle"
                    }, _d),
                    wd = {
                        material: yd,
                        grayscale: {
                            area: Sl({
                                style: {
                                    data: {
                                        fill: bd
                                    },
                                    labels: _d
                                }
                            }, md),
                            axis: Sl({
                                style: {
                                    axis: {
                                        fill: "transparent",
                                        stroke: bd,
                                        strokeWidth: 1,
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round"
                                    },
                                    axisLabel: Sl({}, xd, {
                                        padding: 25
                                    }),
                                    grid: {
                                        fill: "none",
                                        stroke: "none",
                                        pointerEvents: "painted"
                                    },
                                    ticks: {
                                        fill: "transparent",
                                        size: 1,
                                        stroke: "transparent"
                                    },
                                    tickLabels: _d
                                }
                            }, md),
                            bar: Sl({
                                style: {
                                    data: {
                                        fill: bd,
                                        padding: 8,
                                        strokeWidth: 0
                                    },
                                    labels: _d
                                }
                            }, md),
                            boxplot: Sl({
                                style: {
                                    max: {
                                        padding: 8,
                                        stroke: bd,
                                        strokeWidth: 1
                                    },
                                    maxLabels: Sl({}, _d, {
                                        padding: 3
                                    }),
                                    median: {
                                        padding: 8,
                                        stroke: bd,
                                        strokeWidth: 1
                                    },
                                    medianLabels: Sl({}, _d, {
                                        padding: 3
                                    }),
                                    min: {
                                        padding: 8,
                                        stroke: bd,
                                        strokeWidth: 1
                                    },
                                    minLabels: Sl({}, _d, {
                                        padding: 3
                                    }),
                                    q1: {
                                        padding: 8,
                                        fill: gd
                                    },
                                    q1Labels: Sl({}, _d, {
                                        padding: 3
                                    }),
                                    q3: {
                                        padding: 8,
                                        fill: gd
                                    },
                                    q3Labels: Sl({}, _d, {
                                        padding: 3
                                    })
                                },
                                boxWidth: 20
                            }, md),
                            candlestick: Sl({
                                style: {
                                    data: {
                                        stroke: bd,
                                        strokeWidth: 1
                                    },
                                    labels: Sl({}, _d, {
                                        padding: 5
                                    })
                                },
                                candleColors: {
                                    positive: "#ffffff",
                                    negative: bd
                                }
                            }, md),
                            chart: md,
                            errorbar: Sl({
                                borderWidth: 8,
                                style: {
                                    data: {
                                        fill: "transparent",
                                        stroke: bd,
                                        strokeWidth: 2
                                    },
                                    labels: _d
                                }
                            }, md),
                            group: Sl({
                                colorScale: vd
                            }, md),
                            histogram: Sl({
                                style: {
                                    data: {
                                        fill: gd,
                                        stroke: bd,
                                        strokeWidth: 2
                                    },
                                    labels: _d
                                }
                            }, md),
                            legend: {
                                colorScale: vd,
                                gutter: 10,
                                orientation: "vertical",
                                titleOrientation: "top",
                                style: {
                                    data: {
                                        type: "circle"
                                    },
                                    labels: _d,
                                    title: Sl({}, _d, {
                                        padding: 5
                                    })
                                }
                            },
                            line: Sl({
                                style: {
                                    data: {
                                        fill: "transparent",
                                        stroke: bd,
                                        strokeWidth: 2
                                    },
                                    labels: _d
                                }
                            }, md),
                            pie: {
                                style: {
                                    data: {
                                        padding: 10,
                                        stroke: "transparent",
                                        strokeWidth: 1
                                    },
                                    labels: Sl({}, _d, {
                                        padding: 20
                                    })
                                },
                                colorScale: vd,
                                width: 400,
                                height: 400,
                                padding: 50
                            },
                            scatter: Sl({
                                style: {
                                    data: {
                                        fill: bd,
                                        stroke: "transparent",
                                        strokeWidth: 0
                                    },
                                    labels: _d
                                }
                            }, md),
                            stack: Sl({
                                colorScale: vd
                            }, md),
                            tooltip: {
                                style: Sl({}, _d, {
                                    padding: 0,
                                    pointerEvents: "none"
                                }),
                                flyoutStyle: {
                                    stroke: bd,
                                    strokeWidth: 1,
                                    fill: "#f0f0f0",
                                    pointerEvents: "none"
                                },
                                flyoutPadding: 5,
                                cornerRadius: 5,
                                pointerLength: 10
                            },
                            voronoi: Sl({
                                style: {
                                    data: {
                                        fill: "transparent",
                                        stroke: "transparent",
                                        strokeWidth: 0
                                    },
                                    labels: Sl({}, _d, {
                                        padding: 5,
                                        pointerEvents: "none"
                                    }),
                                    flyout: {
                                        stroke: bd,
                                        strokeWidth: 1,
                                        fill: "#f0f0f0",
                                        pointerEvents: "none"
                                    }
                                }
                            }, md)
                        }
                    },
                    kd = {
                        categories: C.oneOfType([C.arrayOf(C.string), C.shape({
                            x: C.arrayOf(C.string),
                            y: C.arrayOf(C.string)
                        })]),
                        data: C.oneOfType([C.array, C.object]),
                        dataComponent: C.element,
                        disableInlineStyles: C.bool,
                        labelComponent: C.element,
                        labels: C.oneOfType([C.func, C.array]),
                        samples: _s,
                        sortKey: C.oneOfType([C.func, ms([xs, _s]), C.string, C.arrayOf(C.string)]),
                        sortOrder: C.oneOf(["ascending", "descending"]),
                        style: C.shape({
                            parent: C.object,
                            data: C.object,
                            labels: C.object
                        }),
                        x: C.oneOfType([C.func, ms([xs, _s]), C.string, C.arrayOf(C.string)]),
                        y: C.oneOfType([C.func, ms([xs, _s]), C.string, C.arrayOf(C.string)]),
                        y0: C.oneOfType([C.func, ms([xs, _s]), C.string, C.arrayOf(C.string)])
                    },
                    Od = {
                        animate: C.oneOfType([C.bool, C.object]),
                        containerComponent: C.element,
                        domain: C.oneOfType([ws, C.shape({
                            x: ws,
                            y: ws
                        })]),
                        maxDomain: C.oneOfType([C.number, C.instanceOf(Date), C.shape({
                            x: C.oneOfType([C.number, C.instanceOf(Date)]),
                            y: C.oneOfType([C.number, C.instanceOf(Date)])
                        })]),
                        minDomain: C.oneOfType([C.number, C.instanceOf(Date), C.shape({
                            x: C.oneOfType([C.number, C.instanceOf(Date)]),
                            y: C.oneOfType([C.number, C.instanceOf(Date)])
                        })]),
                        domainPadding: C.oneOfType([C.shape({
                            x: C.oneOfType([C.number, C.arrayOf(C.number)]),
                            y: C.oneOfType([C.number, C.arrayOf(C.number)])
                        }), C.number, C.arrayOf(C.number)]),
                        eventKey: C.oneOfType([C.func, ms([xs, _s]), C.string]),
                        events: C.arrayOf(C.shape({
                            target: C.oneOf(["data", "labels", "parent"]),
                            eventKey: C.oneOfType([C.array, ms([xs, _s]), C.string]),
                            eventHandlers: C.object
                        })),
                        externalEventMutations: C.arrayOf(C.shape({
                            callback: C.function,
                            childName: C.oneOfType([C.string, C.array]),
                            eventKey: C.oneOfType([C.array, ms([xs, _s]), C.string]),
                            mutation: C.function,
                            target: C.oneOfType([C.string, C.array])
                        })),
                        groupComponent: C.element,
                        height: _s,
                        name: C.string,
                        origin: C.shape({
                            x: C.number,
                            y: C.number
                        }),
                        padding: C.oneOfType([C.number, C.shape({
                            top: C.number,
                            bottom: C.number,
                            left: C.number,
                            right: C.number
                        })]),
                        polar: C.bool,
                        range: C.oneOfType([ws, C.shape({
                            x: ws,
                            y: ws
                        })]),
                        scale: C.oneOfType([ks, C.shape({
                            x: ks,
                            y: ks
                        })]),
                        sharedEvents: C.shape({
                            events: C.array,
                            getEventState: C.func
                        }),
                        singleQuadrantDomainPadding: C.oneOfType([C.bool, C.shape({
                            x: C.oneOfType([C.bool]),
                            y: C.oneOfType([C.bool])
                        })]),
                        standalone: C.bool,
                        theme: C.object,
                        width: _s
                    },
                    Ad = {
                        active: C.bool,
                        ariaLabel: C.oneOfType([C.string, C.func]),
                        className: C.string,
                        clipPath: C.string,
                        data: C.oneOfType([C.array, C.object]),
                        desc: C.oneOfType([C.string, C.func]),
                        disableInlineStyles: C.bool,
                        events: C.object,
                        id: C.oneOfType([C.number, C.string, C.func]),
                        index: C.oneOfType([C.number, C.string]),
                        origin: C.shape({
                            x: C.number,
                            y: C.number
                        }),
                        polar: C.bool,
                        role: C.string,
                        scale: C.oneOfType([ks, C.shape({
                            x: ks,
                            y: ks
                        })]),
                        shapeRendering: C.string,
                        style: C.object,
                        tabIndex: C.oneOfType([C.number, C.func]),
                        transform: C.string
                    };
                var Ed = function(t) {
                        var e = t.desc,
                            r = function(t, e) {
                                if (null == t) return {};
                                var n, r, i = {},
                                    a = Object.keys(t);
                                for (r = 0; r < a.length; r++) n = a[r], e.indexOf(n) >= 0 || (i[n] = t[n]);
                                if (Object.getOwnPropertySymbols) {
                                    var o = Object.getOwnPropertySymbols(t);
                                    for (r = 0; r < o.length; r++) n = o[r], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (i[n] = t[n])
                                }
                                return i
                            }(t, ["desc"]);
                        return e ? n.createElement("path", r, n.createElement("desc", null, e)) : n.createElement("path", r)
                    },
                    Md = Math.ceil,
                    Td = Math.max;
                var jd = function(t, e, n, r) {
                        for (var i = -1, a = Td(Md((e - t) / (n || 1)), 0), o = Array(a); a--;) o[r ? a : ++i] = t, t += n;
                        return o
                    },
                    Pd = jd,
                    Sd = Yc,
                    Cd = as;
                var Nd = function(t) {
                        return function(e, n, r) {
                            return r && "number" != typeof r && Sd(e, n, r) && (n = r = void 0), e = Cd(e), void 0 === n ? (n = e, e = 0) : n = Cd(n), r = void 0 === r ? e < n ? 1 : -1 : Cd(r), Pd(e, n, r, t)
                        }
                    },
                    Dd = Nd();
                var Id = function(t, e, n) {
                        for (var r = n - 1, i = t.length; ++r < i;)
                            if (t[r] === e) return r;
                        return -1
                    },
                    Ld = Bl,
                    zd = function(t) {
                        return t != t
                    },
                    Wd = Id;
                var Fd = function(t, e, n) {
                        return e == e ? Wd(t, e, n) : Ld(t, zd, n)
                    },
                    Rd = Fd;
                var Ud = function(t, e) {
                    return !!(null == t ? 0 : t.length) && Rd(t, e, 0) > -1
                };
                var qd = function(t, e, n) {
                        for (var r = -1, i = null == t ? 0 : t.length; ++r < i;)
                            if (n(e, t[r])) return !0;
                        return !1
                    },
                    Bd = Fn,
                    Hd = Ud,
                    Kd = qd,
                    Yd = rt,
                    Vd = Dr,
                    Gd = Un;
                var $d = function(t, e, n, r) {
                        var i = -1,
                            a = Hd,
                            o = !0,
                            u = t.length,
                            c = [],
                            l = e.length;
                        if (!u) return c;
                        n && (e = Yd(e, Vd(n))), r ? (a = Kd, o = !1) : e.length >= 200 && (a = Gd, o = !1, e = new Bd(e));
                        t: for (; ++i < u;) {
                            var s = t[i],
                                f = null == n ? s : n(s);
                            if (s = r || 0 !== s ? s : 0, o && f == f) {
                                for (var h = l; h--;)
                                    if (e[h] === f) continue t;
                                c.push(s)
                            } else a(e, f, r) || c.push(s)
                        }
                        return c
                    },
                    Xd = ai,
                    Qd = xt;
                var Zd = function(t) {
                        return Qd(t) && Xd(t)
                    },
                    Jd = $d,
                    tp = Gs,
                    ep = Zd,
                    np = Uc((function(t, e) {
                        return ep(t) ? Jd(t, tp(e, 1, ep, !0)) : []
                    })),
                    rp = np;
                var ip = function(t) {
                        return null == t
                    },
                    ap = $d,
                    op = Zd,
                    up = Uc((function(t, e) {
                        return op(t) ? ap(t, e) : []
                    })),
                    cp = up,
                    lp = _t,
                    sp = it,
                    fp = xt;
                var hp = function(t) {
                        return "string" == typeof t || !sp(t) && fp(t) && "[object String]" == lp(t)
                    },
                    dp = rt;
                var pp = function(t, e) {
                        return dp(e, (function(e) {
                            return t[e]
                        }))
                    },
                    yp = pp,
                    vp = li;
                var bp = function(t) {
                        return null == t ? [] : yp(t, vp(t))
                    },
                    gp = Fd,
                    mp = ai,
                    _p = hp,
                    xp = us,
                    wp = bp,
                    kp = Math.max;
                var Op = function(t, e, n, r) {
                    t = mp(t) ? t : wp(t), n = n && !r ? xp(n) : 0;
                    var i = t.length;
                    return n < 0 && (n = kp(i + n, 0)), _p(t) ? n <= i && t.indexOf(e, n) > -1 : !!i && gp(t, e, n) > -1
                };
                var Ap = _i,
                    Ep = function() {},
                    Mp = Ap && 1 / Vn(new Ap([, -0]))[1] == 1 / 0 ? function(t) {
                        return new Ap(t)
                    } : Ep,
                    Tp = Fn,
                    jp = Ud,
                    Pp = qd,
                    Sp = Un,
                    Cp = Mp,
                    Np = Vn;
                var Dp = function(t, e, n) {
                        var r = -1,
                            i = jp,
                            a = t.length,
                            o = !0,
                            u = [],
                            c = u;
                        if (n) o = !1, i = Pp;
                        else if (a >= 200) {
                            var l = e ? null : Cp(t);
                            if (l) return Np(l);
                            o = !1, i = Sp, c = new Tp
                        } else c = e ? [] : u;
                        t: for (; ++r < a;) {
                            var s = t[r],
                                f = e ? e(s) : s;
                            if (s = n || 0 !== s ? s : 0, o && f == f) {
                                for (var h = c.length; h--;)
                                    if (c[h] === f) continue t;
                                e && c.push(f), u.push(s)
                            } else i(c, f, n) || (c !== u && c.push(f), u.push(s))
                        }
                        return u
                    },
                    Ip = Dp;
                var Lp = function(t) {
                        return t && t.length ? Ip(t) : []
                    },
                    zp = Lp;
                var Wp = function(t) {
                        if ("function" != typeof t) throw new TypeError("Expected a function");
                        return function() {
                            var e = arguments;
                            switch (e.length) {
                                case 0:
                                    return !t.call(this);
                                case 1:
                                    return !t.call(this, e[0]);
                                case 2:
                                    return !t.call(this, e[0], e[1]);
                                case 3:
                                    return !t.call(this, e[0], e[1], e[2])
                            }
                            return !t.apply(this, e)
                        }
                    },
                    Fp = nr,
                    Rp = ko,
                    Up = dr,
                    qp = ur,
                    Bp = Object.getOwnPropertySymbols ? function(t) {
                        for (var e = []; t;) Fp(e, Up(t)), t = Rp(t);
                        return e
                    } : qp,
                    Hp = ar,
                    Kp = Bp,
                    Yp = nl;
                var Vp = function(t) {
                        return Hp(t, Yp, Kp)
                    },
                    Gp = rt,
                    $p = Xa,
                    Xp = Fs,
                    Qp = Vp;
                var Zp = function(t, e) {
                        if (null == t) return {};
                        var n = Gp(Qp(t), (function(t) {
                            return [t]
                        }));
                        return e = $p(e), Xp(t, n, (function(t, n) {
                            return e(t, n[0])
                        }))
                    },
                    Jp = Zp,
                    ty = Xa,
                    ey = Wp,
                    ny = Zp;
                var ry = function(t, e) {
                        return ny(t, ey(ty(e)))
                    },
                    iy = ry;

                function ay(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function oy(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }
                var uy = /^onGlobal(.*)$/;

                function cy(t, e, n, r) {
                    var i, a = this,
                        o = function(t) {
                            var r, i = (r = t.reduce((function(t, n) {
                                return void 0 !== n.target ? (Array.isArray(n.target) ? Op(n.target, e) : "".concat(n.target) === "".concat(e)) ? t.concat(n) : t : t.concat(n)
                            }), []), void 0 !== n && "parent" !== e ? r.filter((function(t) {
                                var e = t.eventKey,
                                    r = function(t) {
                                        return !t || "".concat(t) === "".concat(n)
                                    };
                                return Array.isArray(e) ? e.some((function(t) {
                                    return r(t)
                                })) : r(e)
                            })) : r);
                            return Array.isArray(i) && i.reduce((function(t, e) {
                                return e ? Sl(t, e.eventHandlers) : t
                            }), {})
                        },
                        u = Array.isArray(a.componentEvents) ? Array.isArray(t.events) ? (i = a.componentEvents).concat.apply(i, oy(t.events)) : a.componentEvents : t.events,
                        c = u && It(r) ? r(o(u), e) : void 0;
                    if (!t.sharedEvents) return c;
                    var l = t.sharedEvents.getEvents,
                        s = t.sharedEvents.events && l(o(t.sharedEvents.events), e);
                    return Sl({}, s, c)
                }

                function ly(t, e, n, r) {
                    var i = this;
                    if (Rf(t)) return {};
                    r = r || this.baseProps;
                    var a = function(t, e) {
                            var n = t.childName,
                                a = t.target,
                                o = t.key,
                                u = "props" === e ? r : i.state || {},
                                c = null != n && u[n] ? u[n] : u;
                            return "parent" === o ? c.parent : c[o] && c[o][a]
                        },
                        o = function(t, o) {
                            var u = "parent" === e ? t.childName : t.childName || n,
                                c = t.target || e,
                                l = function(e, n) {
                                    var o = i.state || {};
                                    if (!It(t.mutation)) return o;
                                    var u = a({
                                            childName: n,
                                            key: e,
                                            target: c
                                        }, "props"),
                                        l = a({
                                            childName: n,
                                            key: e,
                                            target: c
                                        }, "state"),
                                        s = t.mutation(Sl({}, u, l), r),
                                        f = o[n] || {},
                                        h = function(t) {
                                            return s ? function(t) {
                                                return Sl(t, ay({}, e, Sl(t[e], "parent" === c ? s : ay({}, c, s))))
                                            }(t) : function(t) {
                                                return t[e] && t[e][c] && delete t[e][c], t[e] && !si(t[e]).length && delete t[e], t
                                            }(t)
                                        };
                                    return null != n ? Sl(o, ay({}, n, h(f))) : h(o)
                                },
                                s = function(e) {
                                    var n = function(e) {
                                        return "parent" === c ? "parent" : "all" === t.eventKey ? r[e] ? cp(si(r[e]), "parent") : cp(si(r), "parent") : void 0 === t.eventKey && "parent" === o ? r[e] ? si(r[e]) : si(r) : void 0 !== t.eventKey ? t.eventKey : o
                                    }(e);
                                    return Array.isArray(n) ? n.reduce((function(t, n) {
                                        return Sl(t, l(n, e))
                                    }), {}) : l(n, e)
                                },
                                f = "all" === u ? cp(si(r), "parent") : u;
                            return Array.isArray(f) ? f.reduce((function(t, e) {
                                return Sl(t, s(e))
                            }), {}) : s(f)
                        },
                        u = function(e, n, r, a) {
                            var u = t[a](e, n, r, i);
                            if (!Rf(u)) {
                                var c = function(t) {
                                    var e = function(t) {
                                            return It(t.callback) && t.callback
                                        },
                                        n = (Array.isArray(t) ? t.map((function(t) {
                                            return e(t)
                                        })) : [e(t)]).filter((function(t) {
                                            return !1 !== t
                                        }));
                                    return n.length ? function() {
                                        return n.forEach((function(t) {
                                            return t()
                                        }))
                                    } : void 0
                                }(u);
                                i.setState(function(t, e) {
                                    return Array.isArray(t) ? t.reduce((function(t, n) {
                                        return Sl({}, t, o(n, e))
                                    }), {}) : o(t, e)
                                }(u, r), c)
                            }
                        };
                    return si(t).reduce((function(t, e) {
                        return t[e] = u, t
                    }), {})
                }

                function sy(t, e, n) {
                    return t ? si(t).reduce((function(r, i) {
                        return r[i] = function(r) {
                            return t[i](r, n, e, i)
                        }, r
                    }), {}) : {}
                }

                function fy(t, e, n) {
                    var r = this.state || {};
                    return n ? r[n] && r[n][t] && r[n][t][e] : "parent" === t ? r[t] && r[t][e] || r[t] : r[t] && r[t][e]
                }

                function hy(t, e, n, r) {
                    return e = e || {}, n = n || {}, r.reduce((function(r, i) {
                        var a = n[i],
                            o = dy(t, e[i], n[i], i);
                        return r[i] = o || a, Jp(r, (function(t) {
                            return !Rf(t)
                        }))
                    }), {})
                }

                function dy(t, e, n, r) {
                    return n = n || {}, si(e = e || {}).reduce((function(i, a) {
                        var o = n[a] || {},
                            u = e[a] || {};
                        if ("parent" === a) {
                            var c = py(t, u, o, {
                                eventKey: a,
                                target: "parent"
                            });
                            i[a] = void 0 !== c ? Sl({}, o, c) : o
                        } else {
                            var l = zp(si(u).concat(si(o)));
                            i[a] = l.reduce((function(e, n) {
                                var i = {
                                        eventKey: a,
                                        target: n,
                                        childName: r
                                    },
                                    c = py(t, u[n], o[n], i);
                                return e[n] = void 0 !== c ? Sl({}, o[n], c) : o[n], Jp(e, (function(t) {
                                    return !Rf(t)
                                }))
                            }), {})
                        }
                        return Jp(i, (function(t) {
                            return !Rf(t)
                        }))
                    }), {})
                }

                function py(t, e, n, r) {
                    var i = function(t, e) {
                            if ("string" == typeof t[e]) return "all" === t[e] || t[e] === r[e];
                            if (Array.isArray(t[e])) {
                                var n = t[e].map((function(t) {
                                    return "".concat(t)
                                }));
                                return Op(n, r[e])
                            }
                            return !1
                        },
                        a = t = Array.isArray(t) ? t : [t];
                    r.childName && (a = t.filter((function(t) {
                        return i(t, "childName")
                    })));
                    var o = a.filter((function(t) {
                        return i(t, "target")
                    }));
                    if (!Rf(o)) {
                        var u = o.filter((function(t) {
                            return i(t, "eventKey")
                        }));
                        if (!Rf(u)) return u.reduce((function(t, r) {
                            var i = (r && It(r.mutation) ? r.mutation : function() {})(Sl({}, e, n));
                            return Sl({}, t, i)
                        }), {})
                    }
                }

                function yy(t, e) {
                    var n = Array.isArray(e) && e.reduce((function(e, n) {
                        var r, i = t[n],
                            a = i && i.type && i.type.defaultEvents,
                            o = It(a) ? a(i.props) : a;
                        return e = Array.isArray(o) ? (r = e).concat.apply(r, oy(o)) : e
                    }), []);
                    return n && n.length ? n : void 0
                }

                function vy(t) {
                    var e = t.match(uy);
                    return e && e[1] && e[1].toLowerCase()
                }
                var by = function(t) {
                        return Jp(t, (function(t, e) {
                            return uy.test(e)
                        }))
                    },
                    gy = function(t) {
                        return iy(t, (function(t, e) {
                            return uy.test(e)
                        }))
                    },
                    my = function(t) {
                        return Sl(t, {
                            nativeEvent: t
                        })
                    };

                function _y(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function xy(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function wy(t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }
                var ky = function(t) {
                        return !ip(t._x) && !ip(t._y)
                    },
                    Oy = [{
                        name: "parent",
                        index: "parent"
                    }, {
                        name: "data"
                    }, {
                        name: "labels"
                    }],
                    Ay = ea;
                var Ey = function(t, e) {
                    return Ay(t, e)
                };
                var My = function(t) {
                    var e = null == t ? 0 : t.length;
                    return e ? t[e - 1] : void 0
                };

                function Ty(t, e) {
                    return t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN
                }

                function jy(t) {
                    var e;
                    return 1 === t.length && (e = t, t = function(t, n) {
                        return Ty(e(t), n)
                    }), {
                        left: function(e, n, r, i) {
                            for (null == r && (r = 0), null == i && (i = e.length); r < i;) {
                                var a = r + i >>> 1;
                                t(e[a], n) < 0 ? r = a + 1 : i = a
                            }
                            return r
                        },
                        right: function(e, n, r, i) {
                            for (null == r && (r = 0), null == i && (i = e.length); r < i;) {
                                var a = r + i >>> 1;
                                t(e[a], n) > 0 ? i = a : r = a + 1
                            }
                            return r
                        }
                    }
                }
                var Py = jy(Ty).right;

                function Sy(t) {
                    return null === t ? NaN : +t
                }
                var Cy = Math.sqrt(50),
                    Ny = Math.sqrt(10),
                    Dy = Math.sqrt(2);

                function Iy(t, e, n) {
                    var r, i, a, o, u = -1;
                    if (n = +n, (t = +t) === (e = +e) && n > 0) return [t];
                    if ((r = e < t) && (i = t, t = e, e = i), 0 === (o = Ly(t, e, n)) || !isFinite(o)) return [];
                    if (o > 0)
                        for (t = Math.ceil(t / o), e = Math.floor(e / o), a = new Array(i = Math.ceil(e - t + 1)); ++u < i;) a[u] = (t + u) * o;
                    else
                        for (t = Math.floor(t * o), e = Math.ceil(e * o), a = new Array(i = Math.ceil(t - e + 1)); ++u < i;) a[u] = (t - u) / o;
                    return r && a.reverse(), a
                }

                function Ly(t, e, n) {
                    var r = (e - t) / Math.max(0, n),
                        i = Math.floor(Math.log(r) / Math.LN10),
                        a = r / Math.pow(10, i);
                    return i >= 0 ? (a >= Cy ? 10 : a >= Ny ? 5 : a >= Dy ? 2 : 1) * Math.pow(10, i) : -Math.pow(10, -i) / (a >= Cy ? 10 : a >= Ny ? 5 : a >= Dy ? 2 : 1)
                }

                function zy(t, e, n) {
                    var r = Math.abs(e - t) / Math.max(0, n),
                        i = Math.pow(10, Math.floor(Math.log(r) / Math.LN10)),
                        a = r / i;
                    return a >= Cy ? i *= 10 : a >= Ny ? i *= 5 : a >= Dy && (i *= 2), e < t ? -i : i
                }

                function Wy(t, e, n) {
                    if (null == n && (n = Sy), r = t.length) {
                        if ((e = +e) <= 0 || r < 2) return +n(t[0], 0, t);
                        if (e >= 1) return +n(t[r - 1], r - 1, t);
                        var r, i = (r - 1) * e,
                            a = Math.floor(i),
                            o = +n(t[a], a, t);
                        return o + (+n(t[a + 1], a + 1, t) - o) * (i - a)
                    }
                }
                var Fy = "$";

                function Ry() {}

                function Uy(t, e) {
                    var n = new Ry;
                    if (t instanceof Ry) t.each((function(t, e) {
                        n.set(e, t)
                    }));
                    else if (Array.isArray(t)) {
                        var r, i = -1,
                            a = t.length;
                        if (null == e)
                            for (; ++i < a;) n.set(i, t[i]);
                        else
                            for (; ++i < a;) n.set(e(r = t[i], i, t), r)
                    } else if (t)
                        for (var o in t) n.set(o, t[o]);
                    return n
                }

                function qy() {}
                Ry.prototype = Uy.prototype = {
                    constructor: Ry,
                    has: function(t) {
                        return Fy + t in this
                    },
                    get: function(t) {
                        return this[Fy + t]
                    },
                    set: function(t, e) {
                        return this[Fy + t] = e, this
                    },
                    remove: function(t) {
                        var e = Fy + t;
                        return e in this && delete this[e]
                    },
                    clear: function() {
                        for (var t in this) t[0] === Fy && delete this[t]
                    },
                    keys: function() {
                        var t = [];
                        for (var e in this) e[0] === Fy && t.push(e.slice(1));
                        return t
                    },
                    values: function() {
                        var t = [];
                        for (var e in this) e[0] === Fy && t.push(this[e]);
                        return t
                    },
                    entries: function() {
                        var t = [];
                        for (var e in this) e[0] === Fy && t.push({
                            key: e.slice(1),
                            value: this[e]
                        });
                        return t
                    },
                    size: function() {
                        var t = 0;
                        for (var e in this) e[0] === Fy && ++t;
                        return t
                    },
                    empty: function() {
                        for (var t in this)
                            if (t[0] === Fy) return !1;
                        return !0
                    },
                    each: function(t) {
                        for (var e in this) e[0] === Fy && t(this[e], e.slice(1), this)
                    }
                };
                var By = Uy.prototype;
                qy.prototype = {
                    constructor: qy,
                    has: By.has,
                    add: function(t) {
                        return this[Fy + (t += "")] = t, this
                    },
                    remove: By.remove,
                    clear: By.clear,
                    values: By.keys,
                    size: By.size,
                    empty: By.empty,
                    each: By.each
                };
                var Hy = Array.prototype,
                    Ky = Hy.map,
                    Yy = Hy.slice,
                    Vy = {
                        name: "implicit"
                    };

                function Gy(t) {
                    var e = Uy(),
                        n = [],
                        r = Vy;

                    function i(i) {
                        var a = i + "",
                            o = e.get(a);
                        if (!o) {
                            if (r !== Vy) return r;
                            e.set(a, o = n.push(i))
                        }
                        return t[(o - 1) % t.length]
                    }
                    return t = null == t ? [] : Yy.call(t), i.domain = function(t) {
                        if (!arguments.length) return n.slice();
                        n = [], e = Uy();
                        for (var r, a, o = -1, u = t.length; ++o < u;) e.has(a = (r = t[o]) + "") || e.set(a, n.push(r));
                        return i
                    }, i.range = function(e) {
                        return arguments.length ? (t = Yy.call(e), i) : t.slice()
                    }, i.unknown = function(t) {
                        return arguments.length ? (r = t, i) : r
                    }, i.copy = function() {
                        return Gy().domain(n).range(t).unknown(r)
                    }, i
                }

                function $y() {
                    var t, e, n = Gy().unknown(void 0),
                        r = n.domain,
                        i = n.range,
                        a = [0, 1],
                        o = !1,
                        u = 0,
                        c = 0,
                        l = .5;

                    function s() {
                        var n = r().length,
                            s = a[1] < a[0],
                            f = a[s - 0],
                            h = a[1 - s];
                        t = (h - f) / Math.max(1, n - u + 2 * c), o && (t = Math.floor(t)), f += (h - f - t * (n - u)) * l, e = t * (1 - u), o && (f = Math.round(f), e = Math.round(e));
                        var d = function(t, e, n) {
                            t = +t, e = +e, n = (i = arguments.length) < 2 ? (e = t, t = 0, 1) : i < 3 ? 1 : +n;
                            for (var r = -1, i = 0 | Math.max(0, Math.ceil((e - t) / n)), a = new Array(i); ++r < i;) a[r] = t + r * n;
                            return a
                        }(n).map((function(e) {
                            return f + t * e
                        }));
                        return i(s ? d.reverse() : d)
                    }
                    return delete n.unknown, n.domain = function(t) {
                        return arguments.length ? (r(t), s()) : r()
                    }, n.range = function(t) {
                        return arguments.length ? (a = [+t[0], +t[1]], s()) : a.slice()
                    }, n.rangeRound = function(t) {
                        return a = [+t[0], +t[1]], o = !0, s()
                    }, n.bandwidth = function() {
                        return e
                    }, n.step = function() {
                        return t
                    }, n.round = function(t) {
                        return arguments.length ? (o = !!t, s()) : o
                    }, n.padding = function(t) {
                        return arguments.length ? (u = c = Math.max(0, Math.min(1, t)), s()) : u
                    }, n.paddingInner = function(t) {
                        return arguments.length ? (u = Math.max(0, Math.min(1, t)), s()) : u
                    }, n.paddingOuter = function(t) {
                        return arguments.length ? (c = Math.max(0, Math.min(1, t)), s()) : c
                    }, n.align = function(t) {
                        return arguments.length ? (l = Math.max(0, Math.min(1, t)), s()) : l
                    }, n.copy = function() {
                        return $y().domain(r()).range(a).round(o).paddingInner(u).paddingOuter(c).align(l)
                    }, s()
                }

                function Xy(t) {
                    var e = t.copy;
                    return t.padding = t.paddingOuter, delete t.paddingInner, delete t.paddingOuter, t.copy = function() {
                        return Xy(e())
                    }, t
                }

                function Qy(t) {
                    return function() {
                        return t
                    }
                }

                function Zy(t) {
                    return +t
                }
                var Jy = [0, 1];

                function tv(t, e) {
                    return (e -= t = +t) ? function(n) {
                        return (n - t) / e
                    } : Qy(e)
                }

                function ev(t, e, n, r) {
                    var i = t[0],
                        a = t[1],
                        o = e[0],
                        u = e[1];
                    return a < i ? (i = n(a, i), o = r(u, o)) : (i = n(i, a), o = r(o, u)),
                        function(t) {
                            return o(i(t))
                        }
                }

                function nv(t, e, n, r) {
                    var i = Math.min(t.length, e.length) - 1,
                        a = new Array(i),
                        o = new Array(i),
                        u = -1;
                    for (t[i] < t[0] && (t = t.slice().reverse(), e = e.slice().reverse()); ++u < i;) a[u] = n(t[u], t[u + 1]), o[u] = r(e[u], e[u + 1]);
                    return function(e) {
                        var n = Py(t, e, 1, i) - 1;
                        return o[n](a[n](e))
                    }
                }

                function rv(t, e) {
                    return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp())
                }

                function iv(t, e) {
                    var n, r, i, a = Jy,
                        o = Jy,
                        u = Lu,
                        c = !1;

                    function l() {
                        return n = Math.min(a.length, o.length) > 2 ? nv : ev, r = i = null, s
                    }

                    function s(e) {
                        return (r || (r = n(a, o, c ? function(t) {
                            return function(e, n) {
                                var r = t(e = +e, n = +n);
                                return function(t) {
                                    return t <= e ? 0 : t >= n ? 1 : r(t)
                                }
                            }
                        }(t) : t, u)))(+e)
                    }
                    return s.invert = function(t) {
                        return (i || (i = n(o, a, tv, c ? function(t) {
                            return function(e, n) {
                                var r = t(e = +e, n = +n);
                                return function(t) {
                                    return t <= 0 ? e : t >= 1 ? n : r(t)
                                }
                            }
                        }(e) : e)))(+t)
                    }, s.domain = function(t) {
                        return arguments.length ? (a = Ky.call(t, Zy), l()) : a.slice()
                    }, s.range = function(t) {
                        return arguments.length ? (o = Yy.call(t), l()) : o.slice()
                    }, s.rangeRound = function(t) {
                        return o = Yy.call(t), u = zu, l()
                    }, s.clamp = function(t) {
                        return arguments.length ? (c = !!t, l()) : c
                    }, s.interpolate = function(t) {
                        return arguments.length ? (u = t, l()) : u
                    }, l()
                }

                function av(t, e) {
                    if ((n = (t = e ? t.toExponential(e - 1) : t.toExponential()).indexOf("e")) < 0) return null;
                    var n, r = t.slice(0, n);
                    return [r.length > 1 ? r[0] + r.slice(2) : r, +t.slice(n + 1)]
                }

                function ov(t) {
                    return (t = av(Math.abs(t))) ? t[1] : NaN
                }
                var uv, cv = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;

                function lv(t) {
                    if (!(e = cv.exec(t))) throw new Error("invalid format: " + t);
                    var e;
                    return new sv({
                        fill: e[1],
                        align: e[2],
                        sign: e[3],
                        symbol: e[4],
                        zero: e[5],
                        width: e[6],
                        comma: e[7],
                        precision: e[8] && e[8].slice(1),
                        trim: e[9],
                        type: e[10]
                    })
                }

                function sv(t) {
                    this.fill = void 0 === t.fill ? " " : t.fill + "", this.align = void 0 === t.align ? ">" : t.align + "", this.sign = void 0 === t.sign ? "-" : t.sign + "", this.symbol = void 0 === t.symbol ? "" : t.symbol + "", this.zero = !!t.zero, this.width = void 0 === t.width ? void 0 : +t.width, this.comma = !!t.comma, this.precision = void 0 === t.precision ? void 0 : +t.precision, this.trim = !!t.trim, this.type = void 0 === t.type ? "" : t.type + ""
                }

                function fv(t, e) {
                    var n = av(t, e);
                    if (!n) return t + "";
                    var r = n[0],
                        i = n[1];
                    return i < 0 ? "0." + new Array(-i).join("0") + r : r.length > i + 1 ? r.slice(0, i + 1) + "." + r.slice(i + 1) : r + new Array(i - r.length + 2).join("0")
                }
                lv.prototype = sv.prototype, sv.prototype.toString = function() {
                    return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (void 0 === this.width ? "" : Math.max(1, 0 | this.width)) + (this.comma ? "," : "") + (void 0 === this.precision ? "" : "." + Math.max(0, 0 | this.precision)) + (this.trim ? "~" : "") + this.type
                };
                var hv = {
                    "%": function(t, e) {
                        return (100 * t).toFixed(e)
                    },
                    b: function(t) {
                        return Math.round(t).toString(2)
                    },
                    c: function(t) {
                        return t + ""
                    },
                    d: function(t) {
                        return Math.abs(t = Math.round(t)) >= 1e21 ? t.toLocaleString("en").replace(/,/g, "") : t.toString(10)
                    },
                    e: function(t, e) {
                        return t.toExponential(e)
                    },
                    f: function(t, e) {
                        return t.toFixed(e)
                    },
                    g: function(t, e) {
                        return t.toPrecision(e)
                    },
                    o: function(t) {
                        return Math.round(t).toString(8)
                    },
                    p: function(t, e) {
                        return fv(100 * t, e)
                    },
                    r: fv,
                    s: function(t, e) {
                        var n = av(t, e);
                        if (!n) return t + "";
                        var r = n[0],
                            i = n[1],
                            a = i - (uv = 3 * Math.max(-8, Math.min(8, Math.floor(i / 3)))) + 1,
                            o = r.length;
                        return a === o ? r : a > o ? r + new Array(a - o + 1).join("0") : a > 0 ? r.slice(0, a) + "." + r.slice(a) : "0." + new Array(1 - a).join("0") + av(t, Math.max(0, e + a - 1))[0]
                    },
                    X: function(t) {
                        return Math.round(t).toString(16).toUpperCase()
                    },
                    x: function(t) {
                        return Math.round(t).toString(16)
                    }
                };

                function dv(t) {
                    return t
                }
                var pv, yv, vv, bv = Array.prototype.map,
                    gv = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];

                function mv(t) {
                    var e, n, r = void 0 === t.grouping || void 0 === t.thousands ? dv : (e = bv.call(t.grouping, Number), n = t.thousands + "", function(t, r) {
                            for (var i = t.length, a = [], o = 0, u = e[0], c = 0; i > 0 && u > 0 && (c + u + 1 > r && (u = Math.max(1, r - c)), a.push(t.substring(i -= u, i + u)), !((c += u + 1) > r));) u = e[o = (o + 1) % e.length];
                            return a.reverse().join(n)
                        }),
                        i = void 0 === t.currency ? "" : t.currency[0] + "",
                        a = void 0 === t.currency ? "" : t.currency[1] + "",
                        o = void 0 === t.decimal ? "." : t.decimal + "",
                        u = void 0 === t.numerals ? dv : function(t) {
                            return function(e) {
                                return e.replace(/[0-9]/g, (function(e) {
                                    return t[+e]
                                }))
                            }
                        }(bv.call(t.numerals, String)),
                        c = void 0 === t.percent ? "%" : t.percent + "",
                        l = void 0 === t.minus ? "-" : t.minus + "",
                        s = void 0 === t.nan ? "NaN" : t.nan + "";

                    function f(t) {
                        var e = (t = lv(t)).fill,
                            n = t.align,
                            f = t.sign,
                            h = t.symbol,
                            d = t.zero,
                            p = t.width,
                            y = t.comma,
                            v = t.precision,
                            b = t.trim,
                            g = t.type;
                        "n" === g ? (y = !0, g = "g") : hv[g] || (void 0 === v && (v = 12), b = !0, g = "g"), (d || "0" === e && "=" === n) && (d = !0, e = "0", n = "=");
                        var m = "$" === h ? i : "#" === h && /[boxX]/.test(g) ? "0" + g.toLowerCase() : "",
                            _ = "$" === h ? a : /[%p]/.test(g) ? c : "",
                            x = hv[g],
                            w = /[defgprs%]/.test(g);

                        function k(t) {
                            var i, a, c, h = m,
                                k = _;
                            if ("c" === g) k = x(t) + k, t = "";
                            else {
                                var O = (t = +t) < 0 || 1 / t < 0;
                                if (t = isNaN(t) ? s : x(Math.abs(t), v), b && (t = function(t) {
                                        t: for (var e, n = t.length, r = 1, i = -1; r < n; ++r) switch (t[r]) {
                                            case ".":
                                                i = e = r;
                                                break;
                                            case "0":
                                                0 === i && (i = r), e = r;
                                                break;
                                            default:
                                                if (!+t[r]) break t;
                                                i > 0 && (i = 0)
                                        }
                                        return i > 0 ? t.slice(0, i) + t.slice(e + 1) : t
                                    }(t)), O && 0 == +t && "+" !== f && (O = !1), h = (O ? "(" === f ? f : l : "-" === f || "(" === f ? "" : f) + h, k = ("s" === g ? gv[8 + uv / 3] : "") + k + (O && "(" === f ? ")" : ""), w)
                                    for (i = -1, a = t.length; ++i < a;)
                                        if (48 > (c = t.charCodeAt(i)) || c > 57) {
                                            k = (46 === c ? o + t.slice(i + 1) : t.slice(i)) + k, t = t.slice(0, i);
                                            break
                                        }
                            }
                            y && !d && (t = r(t, 1 / 0));
                            var A = h.length + t.length + k.length,
                                E = A < p ? new Array(p - A + 1).join(e) : "";
                            switch (y && d && (t = r(E + t, E.length ? p - k.length : 1 / 0), E = ""), n) {
                                case "<":
                                    t = h + t + k + E;
                                    break;
                                case "=":
                                    t = h + E + t + k;
                                    break;
                                case "^":
                                    t = E.slice(0, A = E.length >> 1) + h + t + k + E.slice(A);
                                    break;
                                default:
                                    t = E + h + t + k
                            }
                            return u(t)
                        }
                        return v = void 0 === v ? 6 : /[gprs]/.test(g) ? Math.max(1, Math.min(21, v)) : Math.max(0, Math.min(20, v)), k.toString = function() {
                            return t + ""
                        }, k
                    }
                    return {
                        format: f,
                        formatPrefix: function(t, e) {
                            var n = f(((t = lv(t)).type = "f", t)),
                                r = 3 * Math.max(-8, Math.min(8, Math.floor(ov(e) / 3))),
                                i = Math.pow(10, -r),
                                a = gv[8 + r / 3];
                            return function(t) {
                                return n(i * t) + a
                            }
                        }
                    }
                }

                function _v(t, e, n) {
                    var r, i = t[0],
                        a = t[t.length - 1],
                        o = zy(i, a, null == e ? 10 : e);
                    switch ((n = lv(null == n ? ",f" : n)).type) {
                        case "s":
                            var u = Math.max(Math.abs(i), Math.abs(a));
                            return null != n.precision || isNaN(r = function(t, e) {
                                return Math.max(0, 3 * Math.max(-8, Math.min(8, Math.floor(ov(e) / 3))) - ov(Math.abs(t)))
                            }(o, u)) || (n.precision = r), vv(n, u);
                        case "":
                        case "e":
                        case "g":
                        case "p":
                        case "r":
                            null != n.precision || isNaN(r = function(t, e) {
                                return t = Math.abs(t), e = Math.abs(e) - t, Math.max(0, ov(e) - ov(t)) + 1
                            }(o, Math.max(Math.abs(i), Math.abs(a)))) || (n.precision = r - ("e" === n.type));
                            break;
                        case "f":
                        case "%":
                            null != n.precision || isNaN(r = function(t) {
                                return Math.max(0, -ov(Math.abs(t)))
                            }(o)) || (n.precision = r - 2 * ("%" === n.type))
                    }
                    return yv(n)
                }

                function xv(t) {
                    var e = t.domain;
                    return t.ticks = function(t) {
                        var n = e();
                        return Iy(n[0], n[n.length - 1], null == t ? 10 : t)
                    }, t.tickFormat = function(t, n) {
                        return _v(e(), t, n)
                    }, t.nice = function(n) {
                        null == n && (n = 10);
                        var r, i = e(),
                            a = 0,
                            o = i.length - 1,
                            u = i[a],
                            c = i[o];
                        return c < u && (r = u, u = c, c = r, r = a, a = o, o = r), (r = Ly(u, c, n)) > 0 ? r = Ly(u = Math.floor(u / r) * r, c = Math.ceil(c / r) * r, n) : r < 0 && (r = Ly(u = Math.ceil(u * r) / r, c = Math.floor(c * r) / r, n)), r > 0 ? (i[a] = Math.floor(u / r) * r, i[o] = Math.ceil(c / r) * r, e(i)) : r < 0 && (i[a] = Math.ceil(u * r) / r, i[o] = Math.floor(c * r) / r, e(i)), t
                    }, t
                }

                function wv() {
                    var t = iv(tv, Su);
                    return t.copy = function() {
                        return rv(t, wv())
                    }, xv(t)
                }

                function kv(t, e) {
                    var n, r = 0,
                        i = (t = t.slice()).length - 1,
                        a = t[r],
                        o = t[i];
                    return o < a && (n = r, r = i, i = n, n = a, a = o, o = n), t[r] = e.floor(a), t[i] = e.ceil(o), t
                }

                function Ov(t, e) {
                    return (e = Math.log(e / t)) ? function(n) {
                        return Math.log(n / t) / e
                    } : Qy(e)
                }

                function Av(t, e) {
                    return t < 0 ? function(n) {
                        return -Math.pow(-e, n) * Math.pow(-t, 1 - n)
                    } : function(n) {
                        return Math.pow(e, n) * Math.pow(t, 1 - n)
                    }
                }

                function Ev(t) {
                    return isFinite(t) ? +("1e" + t) : t < 0 ? 0 : t
                }

                function Mv(t) {
                    return 10 === t ? Ev : t === Math.E ? Math.exp : function(e) {
                        return Math.pow(t, e)
                    }
                }

                function Tv(t) {
                    return t === Math.E ? Math.log : 10 === t && Math.log10 || 2 === t && Math.log2 || (t = Math.log(t), function(e) {
                        return Math.log(e) / t
                    })
                }

                function jv(t) {
                    return function(e) {
                        return -t(-e)
                    }
                }

                function Pv(t, e) {
                    return t < 0 ? -Math.pow(-t, e) : Math.pow(t, e)
                }

                function Sv() {
                    var t = 1,
                        e = iv((function(e, n) {
                            return (n = Pv(n, t) - (e = Pv(e, t))) ? function(r) {
                                return (Pv(r, t) - e) / n
                            } : Qy(n)
                        }), (function(e, n) {
                            return n = Pv(n, t) - (e = Pv(e, t)),
                                function(r) {
                                    return Pv(e + n * r, 1 / t)
                                }
                        })),
                        n = e.domain;
                    return e.exponent = function(e) {
                        return arguments.length ? (t = +e, n(n())) : t
                    }, e.copy = function() {
                        return rv(e, Sv().exponent(t))
                    }, xv(e)
                }
                pv = mv({
                    decimal: ".",
                    thousands: ",",
                    grouping: [3],
                    currency: ["$", ""],
                    minus: "-"
                }), yv = pv.format, vv = pv.formatPrefix;
                var Cv = new Date,
                    Nv = new Date;

                function Dv(t, e, n, r) {
                    function i(e) {
                        return t(e = 0 === arguments.length ? new Date : new Date(+e)), e
                    }
                    return i.floor = function(e) {
                        return t(e = new Date(+e)), e
                    }, i.ceil = function(n) {
                        return t(n = new Date(n - 1)), e(n, 1), t(n), n
                    }, i.round = function(t) {
                        var e = i(t),
                            n = i.ceil(t);
                        return t - e < n - t ? e : n
                    }, i.offset = function(t, n) {
                        return e(t = new Date(+t), null == n ? 1 : Math.floor(n)), t
                    }, i.range = function(n, r, a) {
                        var o, u = [];
                        if (n = i.ceil(n), a = null == a ? 1 : Math.floor(a), !(n < r && a > 0)) return u;
                        do {
                            u.push(o = new Date(+n)), e(n, a), t(n)
                        } while (o < n && n < r);
                        return u
                    }, i.filter = function(n) {
                        return Dv((function(e) {
                            if (e >= e)
                                for (; t(e), !n(e);) e.setTime(e - 1)
                        }), (function(t, r) {
                            if (t >= t)
                                if (r < 0)
                                    for (; ++r <= 0;)
                                        for (; e(t, -1), !n(t););
                                else
                                    for (; --r >= 0;)
                                        for (; e(t, 1), !n(t););
                        }))
                    }, n && (i.count = function(e, r) {
                        return Cv.setTime(+e), Nv.setTime(+r), t(Cv), t(Nv), Math.floor(n(Cv, Nv))
                    }, i.every = function(t) {
                        return t = Math.floor(t), isFinite(t) && t > 0 ? t > 1 ? i.filter(r ? function(e) {
                            return r(e) % t == 0
                        } : function(e) {
                            return i.count(0, e) % t == 0
                        }) : i : null
                    }), i
                }
                var Iv = Dv((function() {}), (function(t, e) {
                    t.setTime(+t + e)
                }), (function(t, e) {
                    return e - t
                }));
                Iv.every = function(t) {
                    return t = Math.floor(t), isFinite(t) && t > 0 ? t > 1 ? Dv((function(e) {
                        e.setTime(Math.floor(e / t) * t)
                    }), (function(e, n) {
                        e.setTime(+e + n * t)
                    }), (function(e, n) {
                        return (n - e) / t
                    })) : Iv : null
                };
                var Lv = Iv,
                    zv = 1e3,
                    Wv = 6e4,
                    Fv = 36e5,
                    Rv = 864e5,
                    Uv = 6048e5,
                    qv = Dv((function(t) {
                        t.setTime(t - t.getMilliseconds())
                    }), (function(t, e) {
                        t.setTime(+t + e * zv)
                    }), (function(t, e) {
                        return (e - t) / zv
                    }), (function(t) {
                        return t.getUTCSeconds()
                    })),
                    Bv = qv,
                    Hv = Dv((function(t) {
                        t.setTime(t - t.getMilliseconds() - t.getSeconds() * zv)
                    }), (function(t, e) {
                        t.setTime(+t + e * Wv)
                    }), (function(t, e) {
                        return (e - t) / Wv
                    }), (function(t) {
                        return t.getMinutes()
                    })),
                    Kv = Hv,
                    Yv = Dv((function(t) {
                        t.setTime(t - t.getMilliseconds() - t.getSeconds() * zv - t.getMinutes() * Wv)
                    }), (function(t, e) {
                        t.setTime(+t + e * Fv)
                    }), (function(t, e) {
                        return (e - t) / Fv
                    }), (function(t) {
                        return t.getHours()
                    })),
                    Vv = Yv,
                    Gv = Dv((function(t) {
                        t.setHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setDate(t.getDate() + e)
                    }), (function(t, e) {
                        return (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * Wv) / Rv
                    }), (function(t) {
                        return t.getDate() - 1
                    })),
                    $v = Gv;

                function Xv(t) {
                    return Dv((function(e) {
                        e.setDate(e.getDate() - (e.getDay() + 7 - t) % 7), e.setHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setDate(t.getDate() + 7 * e)
                    }), (function(t, e) {
                        return (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * Wv) / Uv
                    }))
                }
                var Qv = Xv(0),
                    Zv = Xv(1);
                Xv(2), Xv(3);
                var Jv = Xv(4);
                Xv(5), Xv(6);
                var tb = Dv((function(t) {
                        t.setDate(1), t.setHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setMonth(t.getMonth() + e)
                    }), (function(t, e) {
                        return e.getMonth() - t.getMonth() + 12 * (e.getFullYear() - t.getFullYear())
                    }), (function(t) {
                        return t.getMonth()
                    })),
                    eb = tb,
                    nb = Dv((function(t) {
                        t.setMonth(0, 1), t.setHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setFullYear(t.getFullYear() + e)
                    }), (function(t, e) {
                        return e.getFullYear() - t.getFullYear()
                    }), (function(t) {
                        return t.getFullYear()
                    }));
                nb.every = function(t) {
                    return isFinite(t = Math.floor(t)) && t > 0 ? Dv((function(e) {
                        e.setFullYear(Math.floor(e.getFullYear() / t) * t), e.setMonth(0, 1), e.setHours(0, 0, 0, 0)
                    }), (function(e, n) {
                        e.setFullYear(e.getFullYear() + n * t)
                    })) : null
                };
                var rb = nb,
                    ib = Dv((function(t) {
                        t.setUTCSeconds(0, 0)
                    }), (function(t, e) {
                        t.setTime(+t + e * Wv)
                    }), (function(t, e) {
                        return (e - t) / Wv
                    }), (function(t) {
                        return t.getUTCMinutes()
                    })),
                    ab = ib,
                    ob = Dv((function(t) {
                        t.setUTCMinutes(0, 0, 0)
                    }), (function(t, e) {
                        t.setTime(+t + e * Fv)
                    }), (function(t, e) {
                        return (e - t) / Fv
                    }), (function(t) {
                        return t.getUTCHours()
                    })),
                    ub = ob,
                    cb = Dv((function(t) {
                        t.setUTCHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setUTCDate(t.getUTCDate() + e)
                    }), (function(t, e) {
                        return (e - t) / Rv
                    }), (function(t) {
                        return t.getUTCDate() - 1
                    })),
                    lb = cb;

                function sb(t) {
                    return Dv((function(e) {
                        e.setUTCDate(e.getUTCDate() - (e.getUTCDay() + 7 - t) % 7), e.setUTCHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setUTCDate(t.getUTCDate() + 7 * e)
                    }), (function(t, e) {
                        return (e - t) / Uv
                    }))
                }
                var fb = sb(0),
                    hb = sb(1);
                sb(2), sb(3);
                var db = sb(4);
                sb(5), sb(6);
                var pb = Dv((function(t) {
                        t.setUTCDate(1), t.setUTCHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setUTCMonth(t.getUTCMonth() + e)
                    }), (function(t, e) {
                        return e.getUTCMonth() - t.getUTCMonth() + 12 * (e.getUTCFullYear() - t.getUTCFullYear())
                    }), (function(t) {
                        return t.getUTCMonth()
                    })),
                    yb = pb,
                    vb = Dv((function(t) {
                        t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0)
                    }), (function(t, e) {
                        t.setUTCFullYear(t.getUTCFullYear() + e)
                    }), (function(t, e) {
                        return e.getUTCFullYear() - t.getUTCFullYear()
                    }), (function(t) {
                        return t.getUTCFullYear()
                    }));
                vb.every = function(t) {
                    return isFinite(t = Math.floor(t)) && t > 0 ? Dv((function(e) {
                        e.setUTCFullYear(Math.floor(e.getUTCFullYear() / t) * t), e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0)
                    }), (function(e, n) {
                        e.setUTCFullYear(e.getUTCFullYear() + n * t)
                    })) : null
                };
                var bb = vb;

                function gb(t) {
                    if (0 <= t.y && t.y < 100) {
                        var e = new Date(-1, t.m, t.d, t.H, t.M, t.S, t.L);
                        return e.setFullYear(t.y), e
                    }
                    return new Date(t.y, t.m, t.d, t.H, t.M, t.S, t.L)
                }

                function mb(t) {
                    if (0 <= t.y && t.y < 100) {
                        var e = new Date(Date.UTC(-1, t.m, t.d, t.H, t.M, t.S, t.L));
                        return e.setUTCFullYear(t.y), e
                    }
                    return new Date(Date.UTC(t.y, t.m, t.d, t.H, t.M, t.S, t.L))
                }

                function _b(t, e, n) {
                    return {
                        y: t,
                        m: e,
                        d: n,
                        H: 0,
                        M: 0,
                        S: 0,
                        L: 0
                    }
                }
                var xb, wb, kb, Ob = {
                        "-": "",
                        _: " ",
                        0: "0"
                    },
                    Ab = /^\s*\d+/,
                    Eb = /^%/,
                    Mb = /[\\^$*+?|[\]().{}]/g;

                function Tb(t, e, n) {
                    var r = t < 0 ? "-" : "",
                        i = (r ? -t : t) + "",
                        a = i.length;
                    return r + (a < n ? new Array(n - a + 1).join(e) + i : i)
                }

                function jb(t) {
                    return t.replace(Mb, "\\$&")
                }

                function Pb(t) {
                    return new RegExp("^(?:" + t.map(jb).join("|") + ")", "i")
                }

                function Sb(t) {
                    for (var e = {}, n = -1, r = t.length; ++n < r;) e[t[n].toLowerCase()] = n;
                    return e
                }

                function Cb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 1));
                    return r ? (t.w = +r[0], n + r[0].length) : -1
                }

                function Nb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 1));
                    return r ? (t.u = +r[0], n + r[0].length) : -1
                }

                function Db(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.U = +r[0], n + r[0].length) : -1
                }

                function Ib(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.V = +r[0], n + r[0].length) : -1
                }

                function Lb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.W = +r[0], n + r[0].length) : -1
                }

                function zb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 4));
                    return r ? (t.y = +r[0], n + r[0].length) : -1
                }

                function Wb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1
                }

                function Fb(t, e, n) {
                    var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n, n + 6));
                    return r ? (t.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1
                }

                function Rb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 1));
                    return r ? (t.q = 3 * r[0] - 3, n + r[0].length) : -1
                }

                function Ub(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.m = r[0] - 1, n + r[0].length) : -1
                }

                function qb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.d = +r[0], n + r[0].length) : -1
                }

                function Bb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 3));
                    return r ? (t.m = 0, t.d = +r[0], n + r[0].length) : -1
                }

                function Hb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.H = +r[0], n + r[0].length) : -1
                }

                function Kb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.M = +r[0], n + r[0].length) : -1
                }

                function Yb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 2));
                    return r ? (t.S = +r[0], n + r[0].length) : -1
                }

                function Vb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 3));
                    return r ? (t.L = +r[0], n + r[0].length) : -1
                }

                function Gb(t, e, n) {
                    var r = Ab.exec(e.slice(n, n + 6));
                    return r ? (t.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1
                }

                function $b(t, e, n) {
                    var r = Eb.exec(e.slice(n, n + 1));
                    return r ? n + r[0].length : -1
                }

                function Xb(t, e, n) {
                    var r = Ab.exec(e.slice(n));
                    return r ? (t.Q = +r[0], n + r[0].length) : -1
                }

                function Qb(t, e, n) {
                    var r = Ab.exec(e.slice(n));
                    return r ? (t.s = +r[0], n + r[0].length) : -1
                }

                function Zb(t, e) {
                    return Tb(t.getDate(), e, 2)
                }

                function Jb(t, e) {
                    return Tb(t.getHours(), e, 2)
                }

                function tg(t, e) {
                    return Tb(t.getHours() % 12 || 12, e, 2)
                }

                function eg(t, e) {
                    return Tb(1 + $v.count(rb(t), t), e, 3)
                }

                function ng(t, e) {
                    return Tb(t.getMilliseconds(), e, 3)
                }

                function rg(t, e) {
                    return ng(t, e) + "000"
                }

                function ig(t, e) {
                    return Tb(t.getMonth() + 1, e, 2)
                }

                function ag(t, e) {
                    return Tb(t.getMinutes(), e, 2)
                }

                function og(t, e) {
                    return Tb(t.getSeconds(), e, 2)
                }

                function ug(t) {
                    var e = t.getDay();
                    return 0 === e ? 7 : e
                }

                function cg(t, e) {
                    return Tb(Qv.count(rb(t) - 1, t), e, 2)
                }

                function lg(t) {
                    var e = t.getDay();
                    return e >= 4 || 0 === e ? Jv(t) : Jv.ceil(t)
                }

                function sg(t, e) {
                    return t = lg(t), Tb(Jv.count(rb(t), t) + (4 === rb(t).getDay()), e, 2)
                }

                function fg(t) {
                    return t.getDay()
                }

                function hg(t, e) {
                    return Tb(Zv.count(rb(t) - 1, t), e, 2)
                }

                function dg(t, e) {
                    return Tb(t.getFullYear() % 100, e, 2)
                }

                function pg(t, e) {
                    return Tb((t = lg(t)).getFullYear() % 100, e, 2)
                }

                function yg(t, e) {
                    return Tb(t.getFullYear() % 1e4, e, 4)
                }

                function vg(t, e) {
                    var n = t.getDay();
                    return Tb((t = n >= 4 || 0 === n ? Jv(t) : Jv.ceil(t)).getFullYear() % 1e4, e, 4)
                }

                function bg(t) {
                    var e = t.getTimezoneOffset();
                    return (e > 0 ? "-" : (e *= -1, "+")) + Tb(e / 60 | 0, "0", 2) + Tb(e % 60, "0", 2)
                }

                function gg(t, e) {
                    return Tb(t.getUTCDate(), e, 2)
                }

                function mg(t, e) {
                    return Tb(t.getUTCHours(), e, 2)
                }

                function _g(t, e) {
                    return Tb(t.getUTCHours() % 12 || 12, e, 2)
                }

                function xg(t, e) {
                    return Tb(1 + lb.count(bb(t), t), e, 3)
                }

                function wg(t, e) {
                    return Tb(t.getUTCMilliseconds(), e, 3)
                }

                function kg(t, e) {
                    return wg(t, e) + "000"
                }

                function Og(t, e) {
                    return Tb(t.getUTCMonth() + 1, e, 2)
                }

                function Ag(t, e) {
                    return Tb(t.getUTCMinutes(), e, 2)
                }

                function Eg(t, e) {
                    return Tb(t.getUTCSeconds(), e, 2)
                }

                function Mg(t) {
                    var e = t.getUTCDay();
                    return 0 === e ? 7 : e
                }

                function Tg(t, e) {
                    return Tb(fb.count(bb(t) - 1, t), e, 2)
                }

                function jg(t) {
                    var e = t.getUTCDay();
                    return e >= 4 || 0 === e ? db(t) : db.ceil(t)
                }

                function Pg(t, e) {
                    return t = jg(t), Tb(db.count(bb(t), t) + (4 === bb(t).getUTCDay()), e, 2)
                }

                function Sg(t) {
                    return t.getUTCDay()
                }

                function Cg(t, e) {
                    return Tb(hb.count(bb(t) - 1, t), e, 2)
                }

                function Ng(t, e) {
                    return Tb(t.getUTCFullYear() % 100, e, 2)
                }

                function Dg(t, e) {
                    return Tb((t = jg(t)).getUTCFullYear() % 100, e, 2)
                }

                function Ig(t, e) {
                    return Tb(t.getUTCFullYear() % 1e4, e, 4)
                }

                function Lg(t, e) {
                    var n = t.getUTCDay();
                    return Tb((t = n >= 4 || 0 === n ? db(t) : db.ceil(t)).getUTCFullYear() % 1e4, e, 4)
                }

                function zg() {
                    return "+0000"
                }

                function Wg() {
                    return "%"
                }

                function Fg(t) {
                    return +t
                }

                function Rg(t) {
                    return Math.floor(+t / 1e3)
                }! function(t) {
                    xb = function(t) {
                        var e = t.dateTime,
                            n = t.date,
                            r = t.time,
                            i = t.periods,
                            a = t.days,
                            o = t.shortDays,
                            u = t.months,
                            c = t.shortMonths,
                            l = Pb(i),
                            s = Sb(i),
                            f = Pb(a),
                            h = Sb(a),
                            d = Pb(o),
                            p = Sb(o),
                            y = Pb(u),
                            v = Sb(u),
                            b = Pb(c),
                            g = Sb(c),
                            m = {
                                a: function(t) {
                                    return o[t.getDay()]
                                },
                                A: function(t) {
                                    return a[t.getDay()]
                                },
                                b: function(t) {
                                    return c[t.getMonth()]
                                },
                                B: function(t) {
                                    return u[t.getMonth()]
                                },
                                c: null,
                                d: Zb,
                                e: Zb,
                                f: rg,
                                g: pg,
                                G: vg,
                                H: Jb,
                                I: tg,
                                j: eg,
                                L: ng,
                                m: ig,
                                M: ag,
                                p: function(t) {
                                    return i[+(t.getHours() >= 12)]
                                },
                                q: function(t) {
                                    return 1 + ~~(t.getMonth() / 3)
                                },
                                Q: Fg,
                                s: Rg,
                                S: og,
                                u: ug,
                                U: cg,
                                V: sg,
                                w: fg,
                                W: hg,
                                x: null,
                                X: null,
                                y: dg,
                                Y: yg,
                                Z: bg,
                                "%": Wg
                            },
                            _ = {
                                a: function(t) {
                                    return o[t.getUTCDay()]
                                },
                                A: function(t) {
                                    return a[t.getUTCDay()]
                                },
                                b: function(t) {
                                    return c[t.getUTCMonth()]
                                },
                                B: function(t) {
                                    return u[t.getUTCMonth()]
                                },
                                c: null,
                                d: gg,
                                e: gg,
                                f: kg,
                                g: Dg,
                                G: Lg,
                                H: mg,
                                I: _g,
                                j: xg,
                                L: wg,
                                m: Og,
                                M: Ag,
                                p: function(t) {
                                    return i[+(t.getUTCHours() >= 12)]
                                },
                                q: function(t) {
                                    return 1 + ~~(t.getUTCMonth() / 3)
                                },
                                Q: Fg,
                                s: Rg,
                                S: Eg,
                                u: Mg,
                                U: Tg,
                                V: Pg,
                                w: Sg,
                                W: Cg,
                                x: null,
                                X: null,
                                y: Ng,
                                Y: Ig,
                                Z: zg,
                                "%": Wg
                            },
                            x = {
                                a: function(t, e, n) {
                                    var r = d.exec(e.slice(n));
                                    return r ? (t.w = p[r[0].toLowerCase()], n + r[0].length) : -1
                                },
                                A: function(t, e, n) {
                                    var r = f.exec(e.slice(n));
                                    return r ? (t.w = h[r[0].toLowerCase()], n + r[0].length) : -1
                                },
                                b: function(t, e, n) {
                                    var r = b.exec(e.slice(n));
                                    return r ? (t.m = g[r[0].toLowerCase()], n + r[0].length) : -1
                                },
                                B: function(t, e, n) {
                                    var r = y.exec(e.slice(n));
                                    return r ? (t.m = v[r[0].toLowerCase()], n + r[0].length) : -1
                                },
                                c: function(t, n, r) {
                                    return O(t, e, n, r)
                                },
                                d: qb,
                                e: qb,
                                f: Gb,
                                g: Wb,
                                G: zb,
                                H: Hb,
                                I: Hb,
                                j: Bb,
                                L: Vb,
                                m: Ub,
                                M: Kb,
                                p: function(t, e, n) {
                                    var r = l.exec(e.slice(n));
                                    return r ? (t.p = s[r[0].toLowerCase()], n + r[0].length) : -1
                                },
                                q: Rb,
                                Q: Xb,
                                s: Qb,
                                S: Yb,
                                u: Nb,
                                U: Db,
                                V: Ib,
                                w: Cb,
                                W: Lb,
                                x: function(t, e, r) {
                                    return O(t, n, e, r)
                                },
                                X: function(t, e, n) {
                                    return O(t, r, e, n)
                                },
                                y: Wb,
                                Y: zb,
                                Z: Fb,
                                "%": $b
                            };

                        function w(t, e) {
                            return function(n) {
                                var r, i, a, o = [],
                                    u = -1,
                                    c = 0,
                                    l = t.length;
                                for (n instanceof Date || (n = new Date(+n)); ++u < l;) 37 === t.charCodeAt(u) && (o.push(t.slice(c, u)), null != (i = Ob[r = t.charAt(++u)]) ? r = t.charAt(++u) : i = "e" === r ? " " : "0", (a = e[r]) && (r = a(n, i)), o.push(r), c = u + 1);
                                return o.push(t.slice(c, u)), o.join("")
                            }
                        }

                        function k(t, e) {
                            return function(n) {
                                var r, i, a = _b(1900, void 0, 1);
                                if (O(a, t, n += "", 0) != n.length) return null;
                                if ("Q" in a) return new Date(a.Q);
                                if ("s" in a) return new Date(1e3 * a.s + ("L" in a ? a.L : 0));
                                if (e && !("Z" in a) && (a.Z = 0), "p" in a && (a.H = a.H % 12 + 12 * a.p), void 0 === a.m && (a.m = "q" in a ? a.q : 0), "V" in a) {
                                    if (a.V < 1 || a.V > 53) return null;
                                    "w" in a || (a.w = 1), "Z" in a ? (i = (r = mb(_b(a.y, 0, 1))).getUTCDay(), r = i > 4 || 0 === i ? hb.ceil(r) : hb(r), r = lb.offset(r, 7 * (a.V - 1)), a.y = r.getUTCFullYear(), a.m = r.getUTCMonth(), a.d = r.getUTCDate() + (a.w + 6) % 7) : (i = (r = gb(_b(a.y, 0, 1))).getDay(), r = i > 4 || 0 === i ? Zv.ceil(r) : Zv(r), r = $v.offset(r, 7 * (a.V - 1)), a.y = r.getFullYear(), a.m = r.getMonth(), a.d = r.getDate() + (a.w + 6) % 7)
                                } else("W" in a || "U" in a) && ("w" in a || (a.w = "u" in a ? a.u % 7 : "W" in a ? 1 : 0), i = "Z" in a ? mb(_b(a.y, 0, 1)).getUTCDay() : gb(_b(a.y, 0, 1)).getDay(), a.m = 0, a.d = "W" in a ? (a.w + 6) % 7 + 7 * a.W - (i + 5) % 7 : a.w + 7 * a.U - (i + 6) % 7);
                                return "Z" in a ? (a.H += a.Z / 100 | 0, a.M += a.Z % 100, mb(a)) : gb(a)
                            }
                        }

                        function O(t, e, n, r) {
                            for (var i, a, o = 0, u = e.length, c = n.length; o < u;) {
                                if (r >= c) return -1;
                                if (37 === (i = e.charCodeAt(o++))) {
                                    if (i = e.charAt(o++), !(a = x[i in Ob ? e.charAt(o++) : i]) || (r = a(t, n, r)) < 0) return -1
                                } else if (i != n.charCodeAt(r++)) return -1
                            }
                            return r
                        }
                        return m.x = w(n, m), m.X = w(r, m), m.c = w(e, m), _.x = w(n, _), _.X = w(r, _), _.c = w(e, _), {
                            format: function(t) {
                                var e = w(t += "", m);
                                return e.toString = function() {
                                    return t
                                }, e
                            },
                            parse: function(t) {
                                var e = k(t += "", !1);
                                return e.toString = function() {
                                    return t
                                }, e
                            },
                            utcFormat: function(t) {
                                var e = w(t += "", _);
                                return e.toString = function() {
                                    return t
                                }, e
                            },
                            utcParse: function(t) {
                                var e = k(t += "", !0);
                                return e.toString = function() {
                                    return t
                                }, e
                            }
                        }
                    }(t), wb = xb.format, kb = xb.utcFormat
                }({
                    dateTime: "%x, %X",
                    date: "%-m/%-d/%Y",
                    time: "%-I:%M:%S %p",
                    periods: ["AM", "PM"],
                    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
                    shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                    months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                    shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
                });
                var Ug = 1e3,
                    qg = 6e4,
                    Bg = 36e5,
                    Hg = 864e5,
                    Kg = 2592e6,
                    Yg = 31536e6;

                function Vg(t) {
                    return new Date(t)
                }

                function Gg(t) {
                    return t instanceof Date ? +t : +new Date(+t)
                }

                function $g(t, e, n, r, i, a, o, u, c) {
                    var l = iv(tv, Su),
                        s = l.invert,
                        f = l.domain,
                        h = c(".%L"),
                        d = c(":%S"),
                        p = c("%I:%M"),
                        y = c("%I %p"),
                        v = c("%a %d"),
                        b = c("%b %d"),
                        g = c("%B"),
                        m = c("%Y"),
                        _ = [
                            [o, 1, Ug],
                            [o, 5, 5e3],
                            [o, 15, 15e3],
                            [o, 30, 3e4],
                            [a, 1, qg],
                            [a, 5, 3e5],
                            [a, 15, 9e5],
                            [a, 30, 18e5],
                            [i, 1, Bg],
                            [i, 3, 108e5],
                            [i, 6, 216e5],
                            [i, 12, 432e5],
                            [r, 1, Hg],
                            [r, 2, 1728e5],
                            [n, 1, 6048e5],
                            [e, 1, Kg],
                            [e, 3, 7776e6],
                            [t, 1, Yg]
                        ];

                    function x(u) {
                        return (o(u) < u ? h : a(u) < u ? d : i(u) < u ? p : r(u) < u ? y : e(u) < u ? n(u) < u ? v : b : t(u) < u ? g : m)(u)
                    }

                    function w(e, n, r, i) {
                        if (null == e && (e = 10), "number" == typeof e) {
                            var a = Math.abs(r - n) / e,
                                o = jy((function(t) {
                                    return t[2]
                                })).right(_, a);
                            o === _.length ? (i = zy(n / Yg, r / Yg, e), e = t) : o ? (i = (o = _[a / _[o - 1][2] < _[o][2] / a ? o - 1 : o])[1], e = o[0]) : (i = Math.max(zy(n, r, e), 1), e = u)
                        }
                        return null == i ? e : e.every(i)
                    }
                    return l.invert = function(t) {
                        return new Date(s(t))
                    }, l.domain = function(t) {
                        return arguments.length ? f(Ky.call(t, Gg)) : f().map(Vg)
                    }, l.ticks = function(t, e) {
                        var n, r = f(),
                            i = r[0],
                            a = r[r.length - 1],
                            o = a < i;
                        return o && (n = i, i = a, a = n), n = (n = w(t, i, a, e)) ? n.range(i, a + 1) : [], o ? n.reverse() : n
                    }, l.tickFormat = function(t, e) {
                        return null == e ? x : c(e)
                    }, l.nice = function(t, e) {
                        var n = f();
                        return (t = w(t, n[0], n[n.length - 1], e)) ? f(kv(n, t)) : l
                    }, l.copy = function() {
                        return rv(l, $g(t, e, n, r, i, a, o, u, c))
                    }, l
                }

                function Xg(t) {
                    return t.match(/.{6}/g).map((function(t) {
                        return "#" + t
                    }))
                }
                var Qg = Xg("1f77b4ff7f0e2ca02cd627289467bd8c564be377c27f7f7fbcbd2217becf"),
                    Zg = Xg("393b795254a36b6ecf9c9ede6379398ca252b5cf6bcedb9c8c6d31bd9e39e7ba52e7cb94843c39ad494ad6616be7969c7b4173a55194ce6dbdde9ed6"),
                    Jg = Xg("3182bd6baed69ecae1c6dbefe6550dfd8d3cfdae6bfdd0a231a35474c476a1d99bc7e9c0756bb19e9ac8bcbddcdadaeb636363969696bdbdbdd9d9d9"),
                    tm = Xg("1f77b4aec7e8ff7f0effbb782ca02c98df8ad62728ff98969467bdc5b0d58c564bc49c94e377c2f7b6d27f7f7fc7c7c7bcbd22dbdb8d17becf9edae5"),
                    em = Uu(xu(300, .5, 0), xu(-240, .5, 1)),
                    nm = Uu(xu(-100, .75, .35), xu(80, 1.5, .8)),
                    rm = Uu(xu(260, .75, .35), xu(80, 1.5, .8)),
                    im = xu();

                function am(t) {
                    var e = t.length;
                    return function(n) {
                        return t[Math.max(0, Math.min(e - 1, Math.floor(n * e)))]
                    }
                }
                var om = am(Xg("44015444025645045745055946075a46085c460a5d460b5e470d60470e6147106347116447136548146748166848176948186a481a6c481b6d481c6e481d6f481f70482071482173482374482475482576482677482878482979472a7a472c7a472d7b472e7c472f7d46307e46327e46337f463480453581453781453882443983443a83443b84433d84433e85423f854240864241864142874144874045884046883f47883f48893e49893e4a893e4c8a3d4d8a3d4e8a3c4f8a3c508b3b518b3b528b3a538b3a548c39558c39568c38588c38598c375a8c375b8d365c8d365d8d355e8d355f8d34608d34618d33628d33638d32648e32658e31668e31678e31688e30698e306a8e2f6b8e2f6c8e2e6d8e2e6e8e2e6f8e2d708e2d718e2c718e2c728e2c738e2b748e2b758e2a768e2a778e2a788e29798e297a8e297b8e287c8e287d8e277e8e277f8e27808e26818e26828e26828e25838e25848e25858e24868e24878e23888e23898e238a8d228b8d228c8d228d8d218e8d218f8d21908d21918c20928c20928c20938c1f948c1f958b1f968b1f978b1f988b1f998a1f9a8a1e9b8a1e9c891e9d891f9e891f9f881fa0881fa1881fa1871fa28720a38620a48621a58521a68522a78522a88423a98324aa8325ab8225ac8226ad8127ad8128ae8029af7f2ab07f2cb17e2db27d2eb37c2fb47c31b57b32b67a34b67935b77937b87838b9773aba763bbb753dbc743fbc7340bd7242be7144bf7046c06f48c16e4ac16d4cc26c4ec36b50c46a52c56954c56856c66758c7655ac8645cc8635ec96260ca6063cb5f65cb5e67cc5c69cd5b6ccd5a6ece5870cf5773d05675d05477d1537ad1517cd2507fd34e81d34d84d44b86d54989d5488bd6468ed64590d74393d74195d84098d83e9bd93c9dd93ba0da39a2da37a5db36a8db34aadc32addc30b0dd2fb2dd2db5de2bb8de29bade28bddf26c0df25c2df23c5e021c8e020cae11fcde11dd0e11cd2e21bd5e21ad8e219dae319dde318dfe318e2e418e5e419e7e419eae51aece51befe51cf1e51df4e61ef6e620f8e621fbe723fde725")),
                    um = am(Xg("00000401000501010601010802010902020b02020d03030f03031204041405041606051806051a07061c08071e0907200a08220b09240c09260d0a290e0b2b100b2d110c2f120d31130d34140e36150e38160f3b180f3d19103f1a10421c10441d11471e114920114b21114e22115024125325125527125829115a2a115c2c115f2d11612f116331116533106734106936106b38106c390f6e3b0f703d0f713f0f72400f74420f75440f764510774710784910784a10794c117a4e117b4f127b51127c52137c54137d56147d57157e59157e5a167e5c167f5d177f5f187f601880621980641a80651a80671b80681c816a1c816b1d816d1d816e1e81701f81721f817320817521817621817822817922827b23827c23827e24828025828125818326818426818627818827818928818b29818c29818e2a81902a81912b81932b80942c80962c80982d80992d809b2e7f9c2e7f9e2f7fa02f7fa1307ea3307ea5317ea6317da8327daa337dab337cad347cae347bb0357bb2357bb3367ab5367ab73779b83779ba3878bc3978bd3977bf3a77c03a76c23b75c43c75c53c74c73d73c83e73ca3e72cc3f71cd4071cf4070d0416fd2426fd3436ed5446dd6456cd8456cd9466bdb476adc4869de4968df4a68e04c67e24d66e34e65e44f64e55064e75263e85362e95462ea5661eb5760ec5860ed5a5fee5b5eef5d5ef05f5ef1605df2625df2645cf3655cf4675cf4695cf56b5cf66c5cf66e5cf7705cf7725cf8745cf8765cf9785df9795df97b5dfa7d5efa7f5efa815ffb835ffb8560fb8761fc8961fc8a62fc8c63fc8e64fc9065fd9266fd9467fd9668fd9869fd9a6afd9b6bfe9d6cfe9f6dfea16efea36ffea571fea772fea973feaa74feac76feae77feb078feb27afeb47bfeb67cfeb77efeb97ffebb81febd82febf84fec185fec287fec488fec68afec88cfeca8dfecc8ffecd90fecf92fed194fed395fed597fed799fed89afdda9cfddc9efddea0fde0a1fde2a3fde3a5fde5a7fde7a9fde9aafdebacfcecaefceeb0fcf0b2fcf2b4fcf4b6fcf6b8fcf7b9fcf9bbfcfbbdfcfdbf")),
                    cm = am(Xg("00000401000501010601010802010a02020c02020e03021004031204031405041706041907051b08051d09061f0a07220b07240c08260d08290e092b10092d110a30120a32140b34150b37160b39180c3c190c3e1b0c411c0c431e0c451f0c48210c4a230c4c240c4f260c51280b53290b552b0b572d0b592f0a5b310a5c320a5e340a5f3609613809623909633b09643d09653e0966400a67420a68440a68450a69470b6a490b6a4a0c6b4c0c6b4d0d6c4f0d6c510e6c520e6d540f6d550f6d57106e59106e5a116e5c126e5d126e5f136e61136e62146e64156e65156e67166e69166e6a176e6c186e6d186e6f196e71196e721a6e741a6e751b6e771c6d781c6d7a1d6d7c1d6d7d1e6d7f1e6c801f6c82206c84206b85216b87216b88226a8a226a8c23698d23698f24699025689225689326679526679727669827669a28659b29649d29649f2a63a02a63a22b62a32c61a52c60a62d60a82e5fa92e5eab2f5ead305dae305cb0315bb1325ab3325ab43359b63458b73557b93556ba3655bc3754bd3853bf3952c03a51c13a50c33b4fc43c4ec63d4dc73e4cc83f4bca404acb4149cc4248ce4347cf4446d04545d24644d34743d44842d54a41d74b3fd84c3ed94d3dda4e3cdb503bdd513ade5238df5337e05536e15635e25734e35933e45a31e55c30e65d2fe75e2ee8602de9612bea632aeb6429eb6628ec6726ed6925ee6a24ef6c23ef6e21f06f20f1711ff1731df2741cf3761bf37819f47918f57b17f57d15f67e14f68013f78212f78410f8850ff8870ef8890cf98b0bf98c0af98e09fa9008fa9207fa9407fb9606fb9706fb9906fb9b06fb9d07fc9f07fca108fca309fca50afca60cfca80dfcaa0ffcac11fcae12fcb014fcb216fcb418fbb61afbb81dfbba1ffbbc21fbbe23fac026fac228fac42afac62df9c72ff9c932f9cb35f8cd37f8cf3af7d13df7d340f6d543f6d746f5d949f5db4cf4dd4ff4df53f4e156f3e35af3e55df2e661f2e865f2ea69f1ec6df1ed71f1ef75f1f179f2f27df2f482f3f586f3f68af4f88ef5f992f6fa96f8fb9af9fc9dfafda1fcffa4")),
                    lm = am(Xg("0d088710078813078916078a19068c1b068d1d068e20068f2206902406912605912805922a05932c05942e05952f059631059733059735049837049938049a3a049a3c049b3e049c3f049c41049d43039e44039e46039f48039f4903a04b03a14c02a14e02a25002a25102a35302a35502a45601a45801a45901a55b01a55c01a65e01a66001a66100a76300a76400a76600a76700a86900a86a00a86c00a86e00a86f00a87100a87201a87401a87501a87701a87801a87a02a87b02a87d03a87e03a88004a88104a78305a78405a78606a68707a68808a68a09a58b0aa58d0ba58e0ca48f0da4910ea3920fa39410a29511a19613a19814a099159f9a169f9c179e9d189d9e199da01a9ca11b9ba21d9aa31e9aa51f99a62098a72197a82296aa2395ab2494ac2694ad2793ae2892b02991b12a90b22b8fb32c8eb42e8db52f8cb6308bb7318ab83289ba3388bb3488bc3587bd3786be3885bf3984c03a83c13b82c23c81c33d80c43e7fc5407ec6417dc7427cc8437bc9447aca457acb4679cc4778cc4977cd4a76ce4b75cf4c74d04d73d14e72d24f71d35171d45270d5536fd5546ed6556dd7566cd8576bd9586ada5a6ada5b69db5c68dc5d67dd5e66de5f65de6164df6263e06363e16462e26561e26660e3685fe4695ee56a5de56b5de66c5ce76e5be76f5ae87059e97158e97257ea7457eb7556eb7655ec7754ed7953ed7a52ee7b51ef7c51ef7e50f07f4ff0804ef1814df1834cf2844bf3854bf3874af48849f48948f58b47f58c46f68d45f68f44f79044f79143f79342f89441f89540f9973ff9983ef99a3efa9b3dfa9c3cfa9e3bfb9f3afba139fba238fca338fca537fca636fca835fca934fdab33fdac33fdae32fdaf31fdb130fdb22ffdb42ffdb52efeb72dfeb82cfeba2cfebb2bfebd2afebe2afec029fdc229fdc328fdc527fdc627fdc827fdca26fdcb26fccd25fcce25fcd025fcd225fbd324fbd524fbd724fad824fada24f9dc24f9dd25f8df25f8e125f7e225f7e425f6e626f6e826f5e926f5eb27f4ed27f3ee27f3f027f2f227f1f426f1f525f0f724f0f921"));
                var sm = Object.freeze(Object.defineProperty({
                        __proto__: null,
                        scaleBand: $y,
                        scalePoint: function() {
                            return Xy($y().paddingInner(1))
                        },
                        scaleIdentity: function t() {
                            var e = [0, 1];

                            function n(t) {
                                return +t
                            }
                            return n.invert = n, n.domain = n.range = function(t) {
                                return arguments.length ? (e = Ky.call(t, Zy), n) : e.slice()
                            }, n.copy = function() {
                                return t().domain(e)
                            }, xv(n)
                        },
                        scaleLinear: wv,
                        scaleLog: function t() {
                            var e = iv(Ov, Av).domain([1, 10]),
                                n = e.domain,
                                r = 10,
                                i = Tv(10),
                                a = Mv(10);

                            function o() {
                                return i = Tv(r), a = Mv(r), n()[0] < 0 && (i = jv(i), a = jv(a)), e
                            }
                            return e.base = function(t) {
                                return arguments.length ? (r = +t, o()) : r
                            }, e.domain = function(t) {
                                return arguments.length ? (n(t), o()) : n()
                            }, e.ticks = function(t) {
                                var e, o = n(),
                                    u = o[0],
                                    c = o[o.length - 1];
                                (e = c < u) && (h = u, u = c, c = h);
                                var l, s, f, h = i(u),
                                    d = i(c),
                                    p = null == t ? 10 : +t,
                                    y = [];
                                if (!(r % 1) && d - h < p) {
                                    if (h = Math.round(h) - 1, d = Math.round(d) + 1, u > 0) {
                                        for (; h < d; ++h)
                                            for (s = 1, l = a(h); s < r; ++s)
                                                if (!((f = l * s) < u)) {
                                                    if (f > c) break;
                                                    y.push(f)
                                                }
                                    } else
                                        for (; h < d; ++h)
                                            for (s = r - 1, l = a(h); s >= 1; --s)
                                                if (!((f = l * s) < u)) {
                                                    if (f > c) break;
                                                    y.push(f)
                                                }
                                } else y = Iy(h, d, Math.min(d - h, p)).map(a);
                                return e ? y.reverse() : y
                            }, e.tickFormat = function(t, n) {
                                if (null == n && (n = 10 === r ? ".0e" : ","), "function" != typeof n && (n = yv(n)), t === 1 / 0) return n;
                                null == t && (t = 10);
                                var o = Math.max(1, r * t / e.ticks().length);
                                return function(t) {
                                    var e = t / a(Math.round(i(t)));
                                    return e * r < r - .5 && (e *= r), e <= o ? n(t) : ""
                                }
                            }, e.nice = function() {
                                return n(kv(n(), {
                                    floor: function(t) {
                                        return a(Math.floor(i(t)))
                                    },
                                    ceil: function(t) {
                                        return a(Math.ceil(i(t)))
                                    }
                                }))
                            }, e.copy = function() {
                                return rv(e, t().base(r))
                            }, e
                        },
                        scaleOrdinal: Gy,
                        scaleImplicit: Vy,
                        scalePow: Sv,
                        scaleSqrt: function() {
                            return Sv().exponent(.5)
                        },
                        scaleQuantile: function t() {
                            var e = [],
                                n = [],
                                r = [];

                            function i() {
                                var t = 0,
                                    i = Math.max(1, n.length);
                                for (r = new Array(i - 1); ++t < i;) r[t - 1] = Wy(e, t / i);
                                return a
                            }

                            function a(t) {
                                if (!isNaN(t = +t)) return n[Py(r, t)]
                            }
                            return a.invertExtent = function(t) {
                                var i = n.indexOf(t);
                                return i < 0 ? [NaN, NaN] : [i > 0 ? r[i - 1] : e[0], i < r.length ? r[i] : e[e.length - 1]]
                            }, a.domain = function(t) {
                                if (!arguments.length) return e.slice();
                                e = [];
                                for (var n, r = 0, a = t.length; r < a; ++r) null == (n = t[r]) || isNaN(n = +n) || e.push(n);
                                return e.sort(Ty), i()
                            }, a.range = function(t) {
                                return arguments.length ? (n = Yy.call(t), i()) : n.slice()
                            }, a.quantiles = function() {
                                return r.slice()
                            }, a.copy = function() {
                                return t().domain(e).range(n)
                            }, a
                        },
                        scaleQuantize: function t() {
                            var e = 0,
                                n = 1,
                                r = 1,
                                i = [.5],
                                a = [0, 1];

                            function o(t) {
                                if (t <= t) return a[Py(i, t, 0, r)]
                            }

                            function u() {
                                var t = -1;
                                for (i = new Array(r); ++t < r;) i[t] = ((t + 1) * n - (t - r) * e) / (r + 1);
                                return o
                            }
                            return o.domain = function(t) {
                                return arguments.length ? (e = +t[0], n = +t[1], u()) : [e, n]
                            }, o.range = function(t) {
                                return arguments.length ? (r = (a = Yy.call(t)).length - 1, u()) : a.slice()
                            }, o.invertExtent = function(t) {
                                var o = a.indexOf(t);
                                return o < 0 ? [NaN, NaN] : o < 1 ? [e, i[0]] : o >= r ? [i[r - 1], n] : [i[o - 1], i[o]]
                            }, o.copy = function() {
                                return t().domain([e, n]).range(a)
                            }, xv(o)
                        },
                        scaleThreshold: function t() {
                            var e = [.5],
                                n = [0, 1],
                                r = 1;

                            function i(t) {
                                if (t <= t) return n[Py(e, t, 0, r)]
                            }
                            return i.domain = function(t) {
                                return arguments.length ? (e = Yy.call(t), r = Math.min(e.length, n.length - 1), i) : e.slice()
                            }, i.range = function(t) {
                                return arguments.length ? (n = Yy.call(t), r = Math.min(e.length, n.length - 1), i) : n.slice()
                            }, i.invertExtent = function(t) {
                                var r = n.indexOf(t);
                                return [e[r - 1], e[r]]
                            }, i.copy = function() {
                                return t().domain(e).range(n)
                            }, i
                        },
                        scaleTime: function() {
                            return $g(rb, eb, Qv, $v, Vv, Kv, Bv, Lv, wb).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)])
                        },
                        scaleUtc: function() {
                            return $g(bb, yb, fb, lb, ub, ab, Bv, Lv, kb).domain([Date.UTC(2e3, 0, 1), Date.UTC(2e3, 0, 2)])
                        },
                        schemeCategory10: Qg,
                        schemeCategory20b: Zg,
                        schemeCategory20c: Jg,
                        schemeCategory20: tm,
                        interpolateCubehelixDefault: em,
                        interpolateRainbow: function(t) {
                            (t < 0 || t > 1) && (t -= Math.floor(t));
                            var e = Math.abs(t - .5);
                            return im.h = 360 * t - 100, im.s = 1.5 - 1.5 * e, im.l = .8 - .9 * e, im + ""
                        },
                        interpolateWarm: nm,
                        interpolateCool: rm,
                        interpolateViridis: om,
                        interpolateMagma: um,
                        interpolateInferno: cm,
                        interpolatePlasma: lm,
                        scaleSequential: function t(e) {
                            var n = 0,
                                r = 1,
                                i = !1;

                            function a(t) {
                                var a = (t - n) / (r - n);
                                return e(i ? Math.max(0, Math.min(1, a)) : a)
                            }
                            return a.domain = function(t) {
                                return arguments.length ? (n = +t[0], r = +t[1], a) : [n, r]
                            }, a.clamp = function(t) {
                                return arguments.length ? (i = !!t, a) : i
                            }, a.interpolator = function(t) {
                                return arguments.length ? (e = t, a) : e
                            }, a.copy = function() {
                                return t(e).domain([n, r]).clamp(i)
                            }, xv(a)
                        }
                    }, Symbol.toStringTag, {
                        value: "Module"
                    })),
                    fm = ["linear", "time", "log", "sqrt"];

                function hm(t) {
                    return "scale".concat(function(t) {
                        return t && t[0].toUpperCase() + t.slice(1)
                    }(t))
                }

                function dm(t) {
                    return "function" == typeof t ? It(t.copy) && It(t.domain) && It(t.range) : "string" == typeof t && Op(fm, t)
                }

                function pm(t, e) {
                    return !!t.scale && (!t.scale.x && !t.scale.y || !!t.scale[e])
                }

                function ym(t, e) {
                    if (!t.data) return "linear";
                    var n = vf(t[e]);
                    return Ih(t.data.map((function(t) {
                        var r = Co(n(t)) ? n(t)[e] : n(t);
                        return void 0 !== r ? r : t[e]
                    }))) ? "time" : "linear"
                }

                function vm(t) {
                    return dm(t) ? sm[hm(t)]() : wv()
                }

                function bm(t, e) {
                    var n = gm(t, e);
                    if (n) return "string" == typeof n ? vm(n) : n;
                    var r = function(t, e) {
                        var n;
                        if (t.domain && t.domain[e] ? n = t.domain[e] : t.domain && Array.isArray(t.domain) && (n = t.domain), n) return Ih(n) ? "time" : "linear"
                    }(t, e) || ym(t, e);
                    return sm[hm(r)]()
                }

                function gm(t, e) {
                    if (pm(t, e)) {
                        var n = t.scale[e] || t.scale;
                        return dm(n) ? It(n) ? n : sm[hm(n)]() : void 0
                    }
                }

                function mm(t, e) {
                    return function(t, e) {
                        if (pm(t, e)) {
                            var n = t.scale[e] || t.scale;
                            return "string" == typeof n ? n : _m(n)
                        }
                    }(t, e) || ym(t, e)
                }

                function _m(t) {
                    if ("string" == typeof t) return t;
                    var e = [{
                        name: "log",
                        method: "base"
                    }, {
                        name: "ordinal",
                        method: "unknown"
                    }, {
                        name: "pow-sqrt",
                        method: "exponent"
                    }, {
                        name: "quantile",
                        method: "quantiles"
                    }, {
                        name: "quantize-threshold",
                        method: "invertExtent"
                    }].filter((function(e) {
                        return void 0 !== t[e.method]
                    }))[0];
                    return e ? e.name : void 0
                }

                function xm(t) {
                    return !(!t || !t["@@__IMMUTABLE_ITERABLE__@@"])
                }

                function wm(t, e) {
                    return xm(t) ? t.reduce((function(t, n, r) {
                        return e && e[r] && (n = wm(n)), t[r] = n, t
                    }), function(t) {
                        return !(!t || !t["@@__IMMUTABLE_LIST__@@"])
                    }(t) ? [] : {}) : t
                }

                function km(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function Om(t) {
                    return function(t) {
                        return xm(t) || function(t) {
                            return !(!t || !t["@@__IMMUTABLE_RECORD__@@"])
                        }(t)
                    }(t) ? wm(t, {
                        errorX: !0,
                        errorY: !0
                    }) : t
                }

                function Am(t, e) {
                    var n = (Co(t.domain) ? t.domain[e] : t.domain) || bm(t, e).domain(),
                        r = t.samples || 1,
                        i = Math.max.apply(Math, km(n)),
                        a = Math.min.apply(Math, km(n)),
                        o = Dd(a, i, (i - a) / r);
                    return My(o) === i ? o : o.concat(i)
                }

                function Em(t, e) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "ascending";
                    if (!e) return t;
                    "x" !== e && "y" !== e || (e = "_".concat(e));
                    var r = "ascending" === n ? "asc" : "desc";
                    return wo(t, e, r)
                }

                function Mm(t, e) {
                    var n = 1 / Number.MAX_SAFE_INTEGER,
                        r = {
                            x: mm(e, "x"),
                            y: mm(e, "y")
                        };
                    if ("log" !== r.x && "log" !== r.y) return t;
                    var i = function(t, e) {
                        return "log" !== r[e] || 0 !== t["_".concat(e)]
                    };
                    return t.map((function(t) {
                        return i(t, "x") && i(t, "y") && i(t, "y0") ? t : function(t) {
                            var e = i(t, "x") ? t._x : n,
                                r = i(t, "y") ? t._y : n,
                                a = i(t, "y0") ? t._y0 : n;
                            return Sl({}, t, {
                                _x: e,
                                _y: r,
                                _y0: a
                            })
                        }(t)
                    }))
                }

                function Tm(t, e) {
                    var n, r = !!t.eventKey,
                        i = (n = t.eventKey, It(n) ? n : null == n ? function() {} : Ha(n));
                    return e.map((function(t, e) {
                        if (void 0 !== t.eventKey) return t;
                        if (r) {
                            var n = i(t, e);
                            return void 0 !== n ? Sl({
                                eventKey: n
                            }, t) : t
                        }
                        return t
                    }))
                }

                function jm(t, e) {
                    var n = Nm(t, e),
                        r = Dm(t, e),
                        i = function(t, e) {
                            if (!Array.isArray(t.data) && !xm(t.data)) return [];
                            var n = vf(void 0 === t[e] ? e : t[e]);
                            return Em(t.data.reduce((function(t, e) {
                                return t.push(Om(e)), t
                            }), []), t.sortKey, t.sortOrder).reduce((function(t, e) {
                                return e = Om(e), t.push(n(e)), t
                            }), []).filter((function(t) {
                                return "string" == typeof t
                            })).reduce((function(t, e) {
                                return null != e && -1 === t.indexOf(e) && t.push(e), t
                            }), [])
                        }(t, e),
                        a = zp(km(n).concat(km(r), km(i)));
                    return 0 === a.length ? null : a.reduce((function(t, e, n) {
                        return t[e] = n + 1, t
                    }), {})
                }

                function Pm(t, e, n) {
                    if (!(Array.isArray(t) || xm(t)) || function(t) {
                            return xm(t) ? t.size : t.length
                        }(t) < 1) return [];
                    var r = ["x", "y", "y0"];
                    n = Array.isArray(n) ? n : r;
                    var i, a = n.reduce((function(t, n) {
                            var r;
                            return t[n] = vf(void 0 !== e[r = n] ? e[r] : r), t
                        }), {}),
                        o = Ey(n, r) && "_x" === e.x && "_y" === e.y && "_y0" === e.y0;
                    !1 === o && (i = {
                        x: -1 !== n.indexOf("x") ? jm(e, "x") : void 0,
                        y: -1 !== n.indexOf("y") ? jm(e, "y") : void 0,
                        y0: -1 !== n.indexOf("y0") ? jm(e, "y") : void 0
                    });
                    var u = Mm(Em(o ? t : t.reduce((function(t, e, r) {
                        var o = {
                                x: r,
                                y: e = Om(e)
                            },
                            u = n.reduce((function(t, n) {
                                var r = a[n](e),
                                    u = void 0 !== r ? r : o[n];
                                return void 0 !== u && ("string" == typeof u && i[n] ? (t["".concat(n, "Name")] = u, t["_".concat(n)] = i[n][u]) : t["_".concat(n)] = u), t
                            }), {}),
                            c = Sl({}, u, e);
                        return Rf(c) || t.push(c), t
                    }), []), e.sortKey, e.sortOrder), e);
                    return Tm(e, u)
                }

                function Sm(t, e) {
                    return t.categories && !Array.isArray(t.categories) ? t.categories[e] : t.categories
                }

                function Cm(t) {
                    return t.data ? Pm(t.data, t) : Pm(function(t) {
                        var e = Am(t, "x"),
                            n = Am(t, "y"),
                            r = e.map((function(t, e) {
                                return {
                                    x: t,
                                    y: n[e]
                                }
                            }));
                        return r
                    }(t), t)
                }

                function Nm(t, e) {
                    var n = t.tickValues,
                        r = t.tickFormat;
                    return (n && (Array.isArray(n) || n[e]) ? n[e] || n : r && Array.isArray(r) ? r : []).filter((function(t) {
                        return "string" == typeof t
                    }))
                }

                function Dm(t, e) {
                    if (!t.categories) return [];
                    var n = Sm(t, e),
                        r = n && n.filter((function(t) {
                            return "string" == typeof t
                        }));
                    return r ? zh(r) : []
                }

                function Im(t) {
                    var e = function(t) {
                            return t && t.type ? t.type.role : ""
                        },
                        r = e(t);
                    if ("portal" === r) {
                        var i = n.Children.toArray(t.props.children);
                        r = i.length ? e(i[0]) : ""
                    }
                    return Op(["area", "bar", "boxplot", "candlestick", "errorbar", "group", "histogram", "line", "pie", "scatter", "stack", "voronoi"], r)
                }
                var Lm = _t,
                    zm = xt;
                var Wm = function(t) {
                        return zm(t) && "[object Date]" == Lm(t)
                    },
                    Fm = Dr,
                    Rm = Ir.exports,
                    Um = Rm && Rm.isDate,
                    qm = Um ? Fm(Um) : Wm,
                    Bm = me;
                var Hm = function(t, e) {
                        for (var n = -1, r = t.length, i = 0, a = []; ++n < r;) {
                            var o = t[n],
                                u = e ? e(o) : o;
                            if (!n || !Bm(u, c)) {
                                var c = u;
                                a[i++] = 0 === o ? 0 : o
                            }
                        }
                        return a
                    },
                    Km = Hm;
                var Ym = function(t) {
                    return t && t.length ? Km(t) : []
                };

                function Vm(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function Gm(t, e) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "min",
                        r = function(t) {
                            return "max" === n ? Math.max.apply(Math, Vm(t)) : Math.min.apply(Math, Vm(t))
                        },
                        i = "max" === n ? -1 / 0 : 1 / 0,
                        a = !1,
                        o = Xs(t).reduce((function(t, n) {
                            var i = void 0 !== n["_".concat(e, "0")] ? n["_".concat(e, "0")] : n["_".concat(e)],
                                o = void 0 !== n["_".concat(e, "1")] ? n["_".concat(e, "1")] : n["_".concat(e)],
                                u = r([i, o]);
                            return a = a || i instanceof Date || o instanceof Date, r([t, u])
                        }), i);
                    return a ? new Date(o) : o
                }

                function $m(t, e, n) {
                    if (!e.domainPadding) return t;
                    var r = r_(e, n),
                        i = n_(e, n),
                        a = function(t, e) {
                            var n = function(t) {
                                return Array.isArray(t) ? {
                                    left: t[0],
                                    right: t[1]
                                } : {
                                    left: t,
                                    right: t
                                }
                            };
                            return Co(t.domainPadding) ? n(t.domainPadding[e]) : n(t.domainPadding)
                        }(e, n);
                    if (!a.left && !a.right) return t;
                    var o = Fh(t),
                        u = Wh(t),
                        c = yf(e, gf(n, e.horizontal)),
                        l = Math.abs(c[0] - c[1]),
                        s = Math.max(l - a.left - a.right, 1),
                        f = Math.abs(u.valueOf() - o.valueOf()) / s * l,
                        h = f * a.left / l,
                        d = f * a.right / l,
                        p = {
                            min: o.valueOf() - h,
                            max: u.valueOf() + d
                        },
                        y = Co(e.singleQuadrantDomainPadding) ? e.singleQuadrantDomainPadding[n] : e.singleQuadrantDomainPadding,
                        v = function(t, e) {
                            return "min" === e && o >= 0 && t <= 0 || "max" === e && u <= 0 && t >= 0 ? 0 : t
                        };
                    if ((o >= 0 && p.min <= 0 || u <= 0 && p.max >= 0) && !1 !== y) {
                        var b = {
                                left: Math.abs(u - o) * a.left / l,
                                right: Math.abs(u - o) * a.right / l
                            },
                            g = {
                                min: v(o.valueOf() - b.left, "min"),
                                max: v(u.valueOf() + b.right, "max")
                            },
                            m = {
                                left: Math.abs(g.max - g.min) * a.left / l,
                                right: Math.abs(g.max - g.min) * a.right / l
                            };
                        p = {
                            min: v(o.valueOf() - m.left, "min"),
                            max: v(u.valueOf() + m.right, "max")
                        }
                    }
                    var _ = {
                        min: void 0 !== r ? r : p.min,
                        max: void 0 !== i ? i : p.max
                    };
                    return o instanceof Date || u instanceof Date ? Jm(new Date(_.min), new Date(_.max)) : Jm(_.min, _.max)
                }

                function Xm(t, e) {
                    return t = It(t) ? t : Zm, e = It(e) ? e : Qm,
                        function(n, r) {
                            var i = t_(n, r);
                            if (i) return e(i, n, r);
                            var a = Sm(n, r),
                                o = a ? function(t, e, n) {
                                    n = n || Sm(t, e);
                                    var r = t.polar,
                                        i = t.startAngle,
                                        a = void 0 === i ? 0 : i,
                                        o = t.endAngle,
                                        u = void 0 === o ? 360 : o;
                                    if (!n) return;
                                    var c = r_(t, e),
                                        l = n_(t, e),
                                        s = (v = n, Array.isArray(v) && v.some((function(t) {
                                            return "string" == typeof t
                                        })) ? Dm(t, e) : []),
                                        f = 0 === s.length ? null : s.reduce((function(t, e, n) {
                                            return t[e] = n + 1, t
                                        }), {}),
                                        h = f ? n.map((function(t) {
                                            return f[t]
                                        })) : n,
                                        d = void 0 !== c ? c : Fh(h),
                                        p = void 0 !== l ? l : Wh(h),
                                        y = Jm(d, p);
                                    var v;
                                    return r && "x" === e && 360 === Math.abs(a - u) ? i_(y, h) : y
                                }(n, r, a) : t(n, r);
                            return o ? e(o, n, r) : void 0
                        }
                }

                function Qm(t, e, n) {
                    return function(t, e, n) {
                        return "log" !== mm(e, n) ? t : (i = (r = t)[0] < 0 || r[1] < 0 ? -1 / Number.MAX_SAFE_INTEGER : 1 / Number.MAX_SAFE_INTEGER, [0 === r[0] ? i : r[0], 0 === r[1] ? i : r[1]]);
                        var r, i
                    }($m(t, e, n), e, n)
                }

                function Zm(t, e, n) {
                    n = n || Cm(t);
                    var r = t.polar,
                        i = t.startAngle,
                        a = void 0 === i ? 0 : i,
                        o = t.endAngle,
                        u = void 0 === o ? 360 : o,
                        c = r_(t, e),
                        l = n_(t, e);
                    if (n.length < 1) return void 0 !== c && void 0 !== l ? Jm(c, l) : void 0;
                    var s = Jm(void 0 !== c ? c : Gm(n, e, "min"), void 0 !== l ? l : Gm(n, e, "max"));
                    return r && "x" === e && 360 === Math.abs(a - u) ? i_(s, function(t, e) {
                        return Xs(t).map((function(t) {
                            return t["_".concat(e)] && void 0 !== t["_".concat(e)][1] ? t["_".concat(e)][1] : t["_".concat(e)]
                        }))
                    }(n, e)) : s
                }

                function Jm(t, e) {
                    var n, r, i, a;
                    return +t == +e ? (r = 0 === (n = e) ? 2 * Math.pow(10, -10) : Math.pow(10, -10), i = n instanceof Date ? new Date(+n - 1) : +n - r, a = n instanceof Date ? new Date(+n + 1) : +n + r, 0 === n ? [0, a] : [i, a]) : [t, e]
                }

                function t_(t, e) {
                    var n = r_(t, e),
                        r = n_(t, e);
                    return Co(t.domain) && t.domain[e] ? t.domain[e] : Array.isArray(t.domain) ? t.domain : void 0 !== n && void 0 !== r ? Jm(n, r) : void 0
                }

                function e_(t, e) {
                    var n = t_(t, e);
                    if (n) return n;
                    var r = Cm(t),
                        i = r.reduce((function(t, e) {
                            return e._y0 < t ? e._y0 : t
                        }), 1 / 0);
                    return Xm((function() {
                        return Zm(t, e, r)
                    }), (function(n) {
                        return Qm(function(n) {
                            if ("x" === e) return n;
                            var r = i !== 1 / 0 ? i : 0,
                                a = n_(t, e),
                                o = r_(t, e),
                                u = void 0 !== a ? a : Wh(n, r);
                            return Jm(void 0 !== o ? o : Fh(n, r), u)
                        }(n), t, e)
                    }))(t, e)
                }

                function n_(t, e) {
                    return Co(t.maxDomain) && void 0 !== t.maxDomain[e] ? t.maxDomain[e] : "number" == typeof t.maxDomain || qm(t.maxDomain) ? t.maxDomain : void 0
                }

                function r_(t, e) {
                    return Co(t.minDomain) && void 0 !== t.minDomain[e] ? t.minDomain[e] : "number" == typeof t.minDomain || qm(t.minDomain) ? t.minDomain : void 0
                }

                function i_(t, e) {
                    var n = Ym(e.sort((function(t, e) {
                            return t - e
                        }))),
                        r = n[1] - n[0];
                    return [t[0], t[1] + r]
                }

                function a_(t) {
                    var e = function(t) {
                            return t && t.type ? t.type.role : ""
                        },
                        r = e(t);
                    if ("portal" === r) {
                        var i = n.Children.toArray(t.props.children);
                        r = i.length ? e(i[0]) : ""
                    }
                    return Op(["area", "axis", "bar", "boxplot", "candlestick", "errorbar", "group", "histogram", "line", "pie", "scatter", "stack", "voronoi"], r)
                }

                function o_(t, e, n) {
                    var r = e.a,
                        i = e.d,
                        a = e.e,
                        o = e.f;
                    return "y" === n ? i * t + o : r * t + a
                }

                function u_(t) {
                    if (!t.nativeEvent || void 0 === t.nativeEvent.identifier) {
                        var e = function(t) {
                            return "svg" === t.nodeName ? t : t.parentNode ? e(t.parentNode) : t
                        };
                        return e(t.target)
                    }
                }
                var c_ = Xa,
                    l_ = Dp;
                var s_ = function(t, e) {
                    return t && t.length ? l_(t, c_(e)) : []
                };
                var f_ = function(t, e, n, r) {
                        for (var i = -1, a = null == t ? 0 : t.length; ++i < a;) {
                            var o = t[i];
                            e(r, o, n(o), t)
                        }
                        return r
                    },
                    h_ = no;
                var d_ = f_,
                    p_ = function(t, e, n, r) {
                        return h_(t, (function(t, i, a) {
                            e(r, t, n(t), a)
                        })), r
                    },
                    y_ = Xa,
                    v_ = it;
                var b_ = hl,
                    g_ = function(t, e) {
                        return function(n, r) {
                            var i = v_(n) ? d_ : p_,
                                a = e ? e() : {};
                            return i(n, t, y_(r), a)
                        }
                    },
                    m_ = Object.prototype.hasOwnProperty,
                    __ = g_((function(t, e, n) {
                        m_.call(t, n) ? t[n].push(e) : b_(t, n, [e])
                    }));

                function x_(t, e) {
                    return function(t, e) {
                        e = e || La;
                        var r = function(t) {
                            return t.reduce((function(t, i) {
                                return i.type && "axis" === i.type.role && e(i) ? t.concat(i) : i.props && i.props.children ? t.concat(r(n.Children.toArray(i.props.children))) : t
                            }), [])
                        };
                        return r(t)
                    }(t, (function(t) {
                        return t.type.getAxis(t.props) === e
                    }))[0]
                }

                function w_(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function k_(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function O_(t) {
                    var e = t.children,
                        n = t.props,
                        r = t.childComponents,
                        i = t.parentProps;
                    if (!(e.some((function(t) {
                            return t.type && "histogram" === t.type.role
                        })) && e.length && e.every((function(t) {
                            return t.type && "histogram" === t.type.role
                        })))) return i;
                    var a = n.bins || r[0].props.bins;
                    if (!Array.isArray(a)) {
                        var o = e.reduce((function(t, e) {
                            var n = vf(e.props.x || "x");
                            return t.concat(e.props.data.map((function(t) {
                                return {
                                    x: n(t)
                                }
                            })))
                        }), []);
                        a = (0, e[0].type.getFormattedData)({
                            data: o,
                            bins: a
                        }).reduce((function(t, e, n) {
                            var r = e.x0,
                                i = e.x1;
                            return 0 === n ? t.concat([r, i]) : t.concat(i)
                        }), [])
                    }
                    return function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? arguments[e] : {},
                                r = Object.keys(n);
                            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                return Object.getOwnPropertyDescriptor(n, t).enumerable
                            })))), r.forEach((function(e) {
                                k_(t, e, n[e])
                            }))
                        }
                        return t
                    }({}, i, {
                        bins: a
                    })
                }

                function A_(t, e, n) {
                    var r = t.datasets,
                        i = yf(t, t.horizontal ? "y" : "x"),
                        a = Math.abs(i[1] - i[0]);
                    n = void 0 !== n ? n : Array.isArray(r[0]) && r[0].length || 1;
                    var o = (e = e || r.length) * n;
                    return Math.round(.5 * a / o)
                }

                function E_(t, e, r) {
                    var i = r ? r.slice(0) : n.Children.toArray(t.children),
                        a = t.data ? Cm(t) : void 0,
                        o = t.polar,
                        u = t.startAngle,
                        c = t.endAngle,
                        l = t.categories,
                        s = t.minDomain,
                        f = t.maxDomain,
                        h = {
                            horizontal: t.horizontal,
                            polar: o,
                            startAngle: u,
                            endAngle: c,
                            minDomain: s,
                            maxDomain: f,
                            categories: l
                        },
                        d = a ? Sl(h, {
                            data: a
                        }) : h,
                        p = mf(i, (function(t) {
                            var n = Sl({}, t.props, d);
                            return a_(t) ? t.type && It(t.type.getDomain) ? t.props && t.type.getDomain(n, e) : function(t, e) {
                                return Xm()(t, e)
                            }(n, e) : null
                        }), t);
                    return [0 === p.length ? 0 : Fh(p), 0 === p.length ? 1 : Wh(p)]
                }

                function M_(t, e, r) {
                    r = r || n.Children.toArray(t.children);
                    var i, a = t_(t, e),
                        o = function(t, e, n) {
                            if (!t.polar && "x" === e) {
                                var r = n.filter((function(t) {
                                    return t.type && t.type.role && "group" === t.type.role
                                }));
                                if (!(r.length < 1)) {
                                    var i = r[0].props,
                                        a = i.offset,
                                        o = i.children;
                                    if (a) {
                                        var u = Array.isArray(o) && o[0];
                                        if (u) {
                                            var c = u.props.barWidth,
                                                l = u.props.data && u.props.data.length || 1;
                                            if (u && "stack" === u.type.role) {
                                                var s = u.props.children && u.props.children[0];
                                                if (!s) return;
                                                c = s.props.barWidth, l = u.props.children.length
                                            }
                                            var f = c || A_(t, o.length, l);
                                            return {
                                                x: f * o.length / 2 + (a - f * ((o.length - 1) / 2))
                                            }
                                        }
                                    }
                                }
                            }
                        }(t, e, r);
                    if (a) i = a;
                    else {
                        var u = r_(t, e),
                            c = n_(t, e),
                            l = (t.data || t.y) && Cm(t),
                            s = l ? Zm(t, e, l) : [],
                            f = E_(t, e, r);
                        i = Jm(u || Fh(w_(s).concat(w_(f))), c || Wh(w_(s).concat(w_(f))))
                    }
                    return Qm(i, Sl({
                        domainPadding: o
                    }, t), e)
                }

                function T_(t, e, r) {
                    if (t.data) return bm(t, e);
                    var i = r ? r.slice(0) : n.Children.toArray(t.children),
                        a = zp(mf(i, (function(n) {
                            return mm(Sl({}, n.props, {
                                horizontal: t.horizontal
                            }), e)
                        }), t));
                    return a.length > 1 ? vm("linear") : vm(a[0])
                }

                function j_(t, e, n) {
                    var r = n.style,
                        i = n.role,
                        a = t.props.style || {};
                    if (Array.isArray(a)) return a;
                    var o = t.type && t.type.role,
                        u = "stack" === o ? void 0 : function(t, e, n) {
                            var r = t.style,
                                i = t.colorScale,
                                a = t.color;
                            if (r && r.data && r.data.fill) return r.data.fill;
                            if (i = e.props && e.props.colorScale ? e.props.colorScale : i, a = e.props && e.props.color ? e.props.color : a, i || a) {
                                var o, u, c = Array.isArray(i) ? i : (u = {
                                    grayscale: ["#cccccc", "#969696", "#636363", "#252525"],
                                    qualitative: ["#334D5C", "#45B29D", "#EFC94C", "#E27A3F", "#DF5A49", "#4F7DA1", "#55DBC1", "#EFDA97", "#E2A37F", "#DF948A"],
                                    heatmap: ["#428517", "#77D200", "#D6D305", "#EC8E19", "#C92B05"],
                                    warm: ["#940031", "#C43343", "#DC5429", "#FF821D", "#FFAF55"],
                                    cool: ["#2746B9", "#0B69D4", "#2794DB", "#31BB76", "#60E83B"],
                                    red: ["#FCAE91", "#FB6A4A", "#DE2D26", "#A50F15", "#750B0E"],
                                    blue: ["#002C61", "#004B8F", "#006BC9", "#3795E5", "#65B4F4"],
                                    green: ["#354722", "#466631", "#649146", "#8AB25C", "#A9C97E"]
                                }, (o = i) ? u[o] : u.grayscale);
                                return a || c[n % c.length]
                            }
                        }(n, t, e),
                        c = "line" === o ? {
                            fill: "none",
                            stroke: u
                        } : {
                            fill: u
                        },
                        l = "stack" === i ? {} : {
                            width: A_(n)
                        },
                        s = sl({}, a.data, Sl({}, l, r.data, c)),
                        f = sl({}, a.labels, r.labels);
                    return {
                        parent: r.parent,
                        data: s,
                        labels: f
                    }
                }

                function P_(t, e, n) {
                    var r = Co(t.categories) ? t.categories[e] : t.categories,
                        i = x_(n, e),
                        a = i ? Nm(i.props, e) : [],
                        o = r || function(t, e) {
                            return mf(t.slice(0), (function(t) {
                                var n = t.props || {};
                                if (a_(t) && n.categories) {
                                    var r = n.categories && !Array.isArray(n.categories) ? n.categories[e] : n.props.categories,
                                        i = r && r.filter((function(t) {
                                            return "string" == typeof t
                                        }));
                                    return i ? zh(i) : []
                                }
                                return null
                            }))
                        }(n, e);
                    return zp(Xs(w_(o).concat(w_(a))))
                }

                function S_(t, e) {
                    var r = P_(t, "x", e = e || n.Children.toArray(t.children)),
                        i = P_(t, "y", e),
                        a = function(t) {
                            return mf(t.slice(0), (function(t) {
                                var e = t.props || {};
                                return Im(t) ? (t.type && It(t.type.getData) ? t.type.getData(e) : Cm(e)).map((function(t) {
                                    return {
                                        x: t.xName,
                                        y: t.yName
                                    }
                                })) : null
                            }), {}, {
                                x: [],
                                y: []
                            }, (function(t, e) {
                                var n = Array.isArray(e) ? e.map((function(t) {
                                        return t.x
                                    })).filter(Boolean) : e.x,
                                    r = Array.isArray(e) ? e.map((function(t) {
                                        return t.y
                                    })).filter(Boolean) : e.y;
                                return {
                                    x: void 0 !== n ? t.x.concat(n) : t.x,
                                    y: void 0 !== r ? t.y.concat(r) : t.y
                                }
                            }))
                        }(e);
                    return {
                        x: zp(Xs(w_(r).concat(w_(a.x)))),
                        y: zp(Xs(w_(i).concat(w_(a.y))))
                    }
                }
                var C_ = no;
                var N_ = Rn,
                    D_ = Xa,
                    I_ = function(t, e) {
                        var n;
                        return C_(t, (function(t, r, i) {
                            return !(n = e(t, r, i))
                        })), !!n
                    },
                    L_ = it,
                    z_ = Yc;
                var W_ = function(t, e, n) {
                    var r = L_(t) ? N_ : I_;
                    return n && z_(t, e, n) && (e = void 0), r(t, D_(e))
                };

                function F_(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {},
                            r = Object.keys(n);
                        "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                            return Object.getOwnPropertyDescriptor(n, t).enumerable
                        })))), r.forEach((function(e) {
                            R_(t, e, n[e])
                        }))
                    }
                    return t
                }

                function R_(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function U_(t, e) {
                    return function(t) {
                        if (Array.isArray(t)) return t
                    }(t) || function(t, e) {
                        var n = [],
                            r = !0,
                            i = !1,
                            a = void 0;
                        try {
                            for (var o, u = t[Symbol.iterator](); !(r = (o = u.next()).done) && (n.push(o.value), !e || n.length !== e); r = !0);
                        } catch (c) {
                            i = !0, a = c
                        } finally {
                            try {
                                r || null == u.return || u.return()
                            } finally {
                                if (i) throw a
                            }
                        }
                        return n
                    }(t, e) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }()
                }
                var q_ = {
                        nodesShouldLoad: !1,
                        nodesDoneLoad: !1,
                        animating: !0
                    },
                    B_ = Math.PI,
                    H_ = 2 * B_,
                    K_ = 1e-6,
                    Y_ = H_ - K_;

                function V_() {
                    this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = ""
                }

                function G_() {
                    return new V_
                }

                function $_(t) {
                    return function() {
                        return t
                    }
                }
                V_.prototype = G_.prototype = {
                    constructor: V_,
                    moveTo: function(t, e) {
                        this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +e)
                    },
                    closePath: function() {
                        null !== this._x1 && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z")
                    },
                    lineTo: function(t, e) {
                        this._ += "L" + (this._x1 = +t) + "," + (this._y1 = +e)
                    },
                    quadraticCurveTo: function(t, e, n, r) {
                        this._ += "Q" + +t + "," + +e + "," + (this._x1 = +n) + "," + (this._y1 = +r)
                    },
                    bezierCurveTo: function(t, e, n, r, i, a) {
                        this._ += "C" + +t + "," + +e + "," + +n + "," + +r + "," + (this._x1 = +i) + "," + (this._y1 = +a)
                    },
                    arcTo: function(t, e, n, r, i) {
                        t = +t, e = +e, n = +n, r = +r, i = +i;
                        var a = this._x1,
                            o = this._y1,
                            u = n - t,
                            c = r - e,
                            l = a - t,
                            s = o - e,
                            f = l * l + s * s;
                        if (i < 0) throw new Error("negative radius: " + i);
                        if (null === this._x1) this._ += "M" + (this._x1 = t) + "," + (this._y1 = e);
                        else if (f > K_)
                            if (Math.abs(s * u - c * l) > K_ && i) {
                                var h = n - a,
                                    d = r - o,
                                    p = u * u + c * c,
                                    y = h * h + d * d,
                                    v = Math.sqrt(p),
                                    b = Math.sqrt(f),
                                    g = i * Math.tan((B_ - Math.acos((p + f - y) / (2 * v * b))) / 2),
                                    m = g / b,
                                    _ = g / v;
                                Math.abs(m - 1) > K_ && (this._ += "L" + (t + m * l) + "," + (e + m * s)), this._ += "A" + i + "," + i + ",0,0," + +(s * h > l * d) + "," + (this._x1 = t + _ * u) + "," + (this._y1 = e + _ * c)
                            } else this._ += "L" + (this._x1 = t) + "," + (this._y1 = e);
                        else;
                    },
                    arc: function(t, e, n, r, i, a) {
                        t = +t, e = +e, a = !!a;
                        var o = (n = +n) * Math.cos(r),
                            u = n * Math.sin(r),
                            c = t + o,
                            l = e + u,
                            s = 1 ^ a,
                            f = a ? r - i : i - r;
                        if (n < 0) throw new Error("negative radius: " + n);
                        null === this._x1 ? this._ += "M" + c + "," + l : (Math.abs(this._x1 - c) > K_ || Math.abs(this._y1 - l) > K_) && (this._ += "L" + c + "," + l), n && (f < 0 && (f = f % H_ + H_), f > Y_ ? this._ += "A" + n + "," + n + ",0,1," + s + "," + (t - o) + "," + (e - u) + "A" + n + "," + n + ",0,1," + s + "," + (this._x1 = c) + "," + (this._y1 = l) : f > K_ && (this._ += "A" + n + "," + n + ",0," + +(f >= B_) + "," + s + "," + (this._x1 = t + n * Math.cos(i)) + "," + (this._y1 = e + n * Math.sin(i))))
                    },
                    rect: function(t, e, n, r) {
                        this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +e) + "h" + +n + "v" + +r + "h" + -n + "Z"
                    },
                    toString: function() {
                        return this._
                    }
                };
                var X_ = Math.abs,
                    Q_ = Math.atan2,
                    Z_ = Math.cos,
                    J_ = Math.max,
                    tx = Math.min,
                    ex = Math.sin,
                    nx = Math.sqrt,
                    rx = 1e-12,
                    ix = Math.PI,
                    ax = ix / 2,
                    ox = 2 * ix;

                function ux(t) {
                    return t > 1 ? 0 : t < -1 ? ix : Math.acos(t)
                }

                function cx(t) {
                    return t >= 1 ? ax : t <= -1 ? -ax : Math.asin(t)
                }

                function lx(t) {
                    return t.innerRadius
                }

                function sx(t) {
                    return t.outerRadius
                }

                function fx(t) {
                    return t.startAngle
                }

                function hx(t) {
                    return t.endAngle
                }

                function dx(t) {
                    return t && t.padAngle
                }

                function px(t, e, n, r, i, a, o, u) {
                    var c = n - t,
                        l = r - e,
                        s = o - i,
                        f = u - a,
                        h = f * c - s * l;
                    if (!(h * h < rx)) return [t + (h = (s * (e - a) - f * (t - i)) / h) * c, e + h * l]
                }

                function yx(t, e, n, r, i, a, o) {
                    var u = t - n,
                        c = e - r,
                        l = (o ? a : -a) / nx(u * u + c * c),
                        s = l * c,
                        f = -l * u,
                        h = t + s,
                        d = e + f,
                        p = n + s,
                        y = r + f,
                        v = (h + p) / 2,
                        b = (d + y) / 2,
                        g = p - h,
                        m = y - d,
                        _ = g * g + m * m,
                        x = i - a,
                        w = h * y - p * d,
                        k = (m < 0 ? -1 : 1) * nx(J_(0, x * x * _ - w * w)),
                        O = (w * m - g * k) / _,
                        A = (-w * g - m * k) / _,
                        E = (w * m + g * k) / _,
                        M = (-w * g + m * k) / _,
                        T = O - v,
                        j = A - b,
                        P = E - v,
                        S = M - b;
                    return T * T + j * j > P * P + S * S && (O = E, A = M), {
                        cx: O,
                        cy: A,
                        x01: -s,
                        y01: -f,
                        x11: O * (i / x - 1),
                        y11: A * (i / x - 1)
                    }
                }

                function vx(t) {
                    this._context = t
                }

                function bx(t) {
                    return new vx(t)
                }

                function gx(t) {
                    return t[0]
                }

                function mx(t) {
                    return t[1]
                }

                function _x() {
                    var t = gx,
                        e = mx,
                        n = $_(!0),
                        r = null,
                        i = bx,
                        a = null;

                    function o(o) {
                        var u, c, l, s = o.length,
                            f = !1;
                        for (null == r && (a = i(l = G_())), u = 0; u <= s; ++u) !(u < s && n(c = o[u], u, o)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+t(c, u, o), +e(c, u, o));
                        if (l) return a = null, l + "" || null
                    }
                    return o.x = function(e) {
                        return arguments.length ? (t = "function" == typeof e ? e : $_(+e), o) : t
                    }, o.y = function(t) {
                        return arguments.length ? (e = "function" == typeof t ? t : $_(+t), o) : e
                    }, o.defined = function(t) {
                        return arguments.length ? (n = "function" == typeof t ? t : $_(!!t), o) : n
                    }, o.curve = function(t) {
                        return arguments.length ? (i = t, null != r && (a = i(r)), o) : i
                    }, o.context = function(t) {
                        return arguments.length ? (null == t ? r = a = null : a = i(r = t), o) : r
                    }, o
                }

                function xx() {
                    var t = gx,
                        e = null,
                        n = $_(0),
                        r = mx,
                        i = $_(!0),
                        a = null,
                        o = bx,
                        u = null;

                    function c(c) {
                        var l, s, f, h, d, p = c.length,
                            y = !1,
                            v = new Array(p),
                            b = new Array(p);
                        for (null == a && (u = o(d = G_())), l = 0; l <= p; ++l) {
                            if (!(l < p && i(h = c[l], l, c)) === y)
                                if (y = !y) s = l, u.areaStart(), u.lineStart();
                                else {
                                    for (u.lineEnd(), u.lineStart(), f = l - 1; f >= s; --f) u.point(v[f], b[f]);
                                    u.lineEnd(), u.areaEnd()
                                }
                            y && (v[l] = +t(h, l, c), b[l] = +n(h, l, c), u.point(e ? +e(h, l, c) : v[l], r ? +r(h, l, c) : b[l]))
                        }
                        if (d) return u = null, d + "" || null
                    }

                    function l() {
                        return _x().defined(i).curve(o).context(a)
                    }
                    return c.x = function(n) {
                        return arguments.length ? (t = "function" == typeof n ? n : $_(+n), e = null, c) : t
                    }, c.x0 = function(e) {
                        return arguments.length ? (t = "function" == typeof e ? e : $_(+e), c) : t
                    }, c.x1 = function(t) {
                        return arguments.length ? (e = null == t ? null : "function" == typeof t ? t : $_(+t), c) : e
                    }, c.y = function(t) {
                        return arguments.length ? (n = "function" == typeof t ? t : $_(+t), r = null, c) : n
                    }, c.y0 = function(t) {
                        return arguments.length ? (n = "function" == typeof t ? t : $_(+t), c) : n
                    }, c.y1 = function(t) {
                        return arguments.length ? (r = null == t ? null : "function" == typeof t ? t : $_(+t), c) : r
                    }, c.lineX0 = c.lineY0 = function() {
                        return l().x(t).y(n)
                    }, c.lineY1 = function() {
                        return l().x(t).y(r)
                    }, c.lineX1 = function() {
                        return l().x(e).y(n)
                    }, c.defined = function(t) {
                        return arguments.length ? (i = "function" == typeof t ? t : $_(!!t), c) : i
                    }, c.curve = function(t) {
                        return arguments.length ? (o = t, null != a && (u = o(a)), c) : o
                    }, c.context = function(t) {
                        return arguments.length ? (null == t ? a = u = null : u = o(a = t), c) : a
                    }, c
                }

                function wx(t, e) {
                    return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN
                }

                function kx(t) {
                    return t
                }
                vx.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._point = 0
                    },
                    lineEnd: function() {
                        (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                                break;
                            case 1:
                                this._point = 2;
                            default:
                                this._context.lineTo(t, e)
                        }
                    }
                };
                var Ox = Ex(bx);

                function Ax(t) {
                    this._curve = t
                }

                function Ex(t) {
                    function e(e) {
                        return new Ax(t(e))
                    }
                    return e._curve = t, e
                }

                function Mx(t) {
                    var e = t.curve;
                    return t.angle = t.x, delete t.x, t.radius = t.y, delete t.y, t.curve = function(t) {
                        return arguments.length ? e(Ex(t)) : e()._curve
                    }, t
                }

                function Tx() {
                    return Mx(_x().curve(Ox))
                }

                function jx() {
                    var t = xx().curve(Ox),
                        e = t.curve,
                        n = t.lineX0,
                        r = t.lineX1,
                        i = t.lineY0,
                        a = t.lineY1;
                    return t.angle = t.x, delete t.x, t.startAngle = t.x0, delete t.x0, t.endAngle = t.x1, delete t.x1, t.radius = t.y, delete t.y, t.innerRadius = t.y0, delete t.y0, t.outerRadius = t.y1, delete t.y1, t.lineStartAngle = function() {
                        return Mx(n())
                    }, delete t.lineX0, t.lineEndAngle = function() {
                        return Mx(r())
                    }, delete t.lineX1, t.lineInnerRadius = function() {
                        return Mx(i())
                    }, delete t.lineY0, t.lineOuterRadius = function() {
                        return Mx(a())
                    }, delete t.lineY1, t.curve = function(t) {
                        return arguments.length ? e(Ex(t)) : e()._curve
                    }, t
                }

                function Px(t, e) {
                    return [(e = +e) * Math.cos(t -= Math.PI / 2), e * Math.sin(t)]
                }
                Ax.prototype = {
                    areaStart: function() {
                        this._curve.areaStart()
                    },
                    areaEnd: function() {
                        this._curve.areaEnd()
                    },
                    lineStart: function() {
                        this._curve.lineStart()
                    },
                    lineEnd: function() {
                        this._curve.lineEnd()
                    },
                    point: function(t, e) {
                        this._curve.point(e * Math.sin(t), e * -Math.cos(t))
                    }
                };
                var Sx = Array.prototype.slice;

                function Cx(t) {
                    return t.source
                }

                function Nx(t) {
                    return t.target
                }

                function Dx(t) {
                    var e = Cx,
                        n = Nx,
                        r = gx,
                        i = mx,
                        a = null;

                    function o() {
                        var o, u = Sx.call(arguments),
                            c = e.apply(this, u),
                            l = n.apply(this, u);
                        if (a || (a = o = G_()), t(a, +r.apply(this, (u[0] = c, u)), +i.apply(this, u), +r.apply(this, (u[0] = l, u)), +i.apply(this, u)), o) return a = null, o + "" || null
                    }
                    return o.source = function(t) {
                        return arguments.length ? (e = t, o) : e
                    }, o.target = function(t) {
                        return arguments.length ? (n = t, o) : n
                    }, o.x = function(t) {
                        return arguments.length ? (r = "function" == typeof t ? t : $_(+t), o) : r
                    }, o.y = function(t) {
                        return arguments.length ? (i = "function" == typeof t ? t : $_(+t), o) : i
                    }, o.context = function(t) {
                        return arguments.length ? (a = null == t ? null : t, o) : a
                    }, o
                }

                function Ix(t, e, n, r, i) {
                    t.moveTo(e, n), t.bezierCurveTo(e = (e + r) / 2, n, e, i, r, i)
                }

                function Lx(t, e, n, r, i) {
                    t.moveTo(e, n), t.bezierCurveTo(e, n = (n + i) / 2, r, n, r, i)
                }

                function zx(t, e, n, r, i) {
                    var a = Px(e, n),
                        o = Px(e, n = (n + i) / 2),
                        u = Px(r, n),
                        c = Px(r, i);
                    t.moveTo(a[0], a[1]), t.bezierCurveTo(o[0], o[1], u[0], u[1], c[0], c[1])
                }
                var Wx = {
                        draw: function(t, e) {
                            var n = Math.sqrt(e / ix);
                            t.moveTo(n, 0), t.arc(0, 0, n, 0, ox)
                        }
                    },
                    Fx = {
                        draw: function(t, e) {
                            var n = Math.sqrt(e / 5) / 2;
                            t.moveTo(-3 * n, -n), t.lineTo(-n, -n), t.lineTo(-n, -3 * n), t.lineTo(n, -3 * n), t.lineTo(n, -n), t.lineTo(3 * n, -n), t.lineTo(3 * n, n), t.lineTo(n, n), t.lineTo(n, 3 * n), t.lineTo(-n, 3 * n), t.lineTo(-n, n), t.lineTo(-3 * n, n), t.closePath()
                        }
                    },
                    Rx = Math.sqrt(1 / 3),
                    Ux = 2 * Rx,
                    qx = {
                        draw: function(t, e) {
                            var n = Math.sqrt(e / Ux),
                                r = n * Rx;
                            t.moveTo(0, -n), t.lineTo(r, 0), t.lineTo(0, n), t.lineTo(-r, 0), t.closePath()
                        }
                    },
                    Bx = Math.sin(ix / 10) / Math.sin(7 * ix / 10),
                    Hx = Math.sin(ox / 10) * Bx,
                    Kx = -Math.cos(ox / 10) * Bx,
                    Yx = {
                        draw: function(t, e) {
                            var n = Math.sqrt(.8908130915292852 * e),
                                r = Hx * n,
                                i = Kx * n;
                            t.moveTo(0, -n), t.lineTo(r, i);
                            for (var a = 1; a < 5; ++a) {
                                var o = ox * a / 5,
                                    u = Math.cos(o),
                                    c = Math.sin(o);
                                t.lineTo(c * n, -u * n), t.lineTo(u * r - c * i, c * r + u * i)
                            }
                            t.closePath()
                        }
                    },
                    Vx = {
                        draw: function(t, e) {
                            var n = Math.sqrt(e),
                                r = -n / 2;
                            t.rect(r, r, n, n)
                        }
                    },
                    Gx = Math.sqrt(3),
                    $x = {
                        draw: function(t, e) {
                            var n = -Math.sqrt(e / (3 * Gx));
                            t.moveTo(0, 2 * n), t.lineTo(-Gx * n, -n), t.lineTo(Gx * n, -n), t.closePath()
                        }
                    },
                    Xx = -.5,
                    Qx = Math.sqrt(3) / 2,
                    Zx = 1 / Math.sqrt(12),
                    Jx = 3 * (Zx / 2 + 1),
                    tw = {
                        draw: function(t, e) {
                            var n = Math.sqrt(e / Jx),
                                r = n / 2,
                                i = n * Zx,
                                a = r,
                                o = n * Zx + n,
                                u = -a,
                                c = o;
                            t.moveTo(r, i), t.lineTo(a, o), t.lineTo(u, c), t.lineTo(Xx * r - Qx * i, Qx * r + Xx * i), t.lineTo(Xx * a - Qx * o, Qx * a + Xx * o), t.lineTo(Xx * u - Qx * c, Qx * u + Xx * c), t.lineTo(Xx * r + Qx * i, Xx * i - Qx * r), t.lineTo(Xx * a + Qx * o, Xx * o - Qx * a), t.lineTo(Xx * u + Qx * c, Xx * c - Qx * u), t.closePath()
                        }
                    },
                    ew = [Wx, Fx, qx, Vx, Yx, $x, tw];

                function nw() {}

                function rw(t, e, n) {
                    t._context.bezierCurveTo((2 * t._x0 + t._x1) / 3, (2 * t._y0 + t._y1) / 3, (t._x0 + 2 * t._x1) / 3, (t._y0 + 2 * t._y1) / 3, (t._x0 + 4 * t._x1 + e) / 6, (t._y0 + 4 * t._y1 + n) / 6)
                }

                function iw(t) {
                    this._context = t
                }

                function aw(t) {
                    this._context = t
                }

                function ow(t) {
                    this._context = t
                }

                function uw(t, e) {
                    this._basis = new iw(t), this._beta = e
                }
                iw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 3:
                                rw(this, this._x1, this._y1);
                            case 2:
                                this._context.lineTo(this._x1, this._y1)
                        }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                                break;
                            case 1:
                                this._point = 2;
                                break;
                            case 2:
                                this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
                            default:
                                rw(this, t, e)
                        }
                        this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e
                    }
                }, aw.prototype = {
                    areaStart: nw,
                    areaEnd: nw,
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 1:
                                this._context.moveTo(this._x2, this._y2), this._context.closePath();
                                break;
                            case 2:
                                this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
                                break;
                            case 3:
                                this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4)
                        }
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1, this._x2 = t, this._y2 = e;
                                break;
                            case 1:
                                this._point = 2, this._x3 = t, this._y3 = e;
                                break;
                            case 2:
                                this._point = 3, this._x4 = t, this._y4 = e, this._context.moveTo((this._x0 + 4 * this._x1 + t) / 6, (this._y0 + 4 * this._y1 + e) / 6);
                                break;
                            default:
                                rw(this, t, e)
                        }
                        this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e
                    }
                }, ow.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        (this._line || 0 !== this._line && 3 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1;
                                break;
                            case 1:
                                this._point = 2;
                                break;
                            case 2:
                                this._point = 3;
                                var n = (this._x0 + 4 * this._x1 + t) / 6,
                                    r = (this._y0 + 4 * this._y1 + e) / 6;
                                this._line ? this._context.lineTo(n, r) : this._context.moveTo(n, r);
                                break;
                            case 3:
                                this._point = 4;
                            default:
                                rw(this, t, e)
                        }
                        this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e
                    }
                }, uw.prototype = {
                    lineStart: function() {
                        this._x = [], this._y = [], this._basis.lineStart()
                    },
                    lineEnd: function() {
                        var t = this._x,
                            e = this._y,
                            n = t.length - 1;
                        if (n > 0)
                            for (var r, i = t[0], a = e[0], o = t[n] - i, u = e[n] - a, c = -1; ++c <= n;) r = c / n, this._basis.point(this._beta * t[c] + (1 - this._beta) * (i + r * o), this._beta * e[c] + (1 - this._beta) * (a + r * u));
                        this._x = this._y = null, this._basis.lineEnd()
                    },
                    point: function(t, e) {
                        this._x.push(+t), this._y.push(+e)
                    }
                };
                var cw = function t(e) {
                    function n(t) {
                        return 1 === e ? new iw(t) : new uw(t, e)
                    }
                    return n.beta = function(e) {
                        return t(+e)
                    }, n
                }(.85);

                function lw(t, e, n) {
                    t._context.bezierCurveTo(t._x1 + t._k * (t._x2 - t._x0), t._y1 + t._k * (t._y2 - t._y0), t._x2 + t._k * (t._x1 - e), t._y2 + t._k * (t._y1 - n), t._x2, t._y2)
                }

                function sw(t, e) {
                    this._context = t, this._k = (1 - e) / 6
                }
                sw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 2:
                                this._context.lineTo(this._x2, this._y2);
                                break;
                            case 3:
                                lw(this, this._x1, this._y1)
                        }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                                break;
                            case 1:
                                this._point = 2, this._x1 = t, this._y1 = e;
                                break;
                            case 2:
                                this._point = 3;
                            default:
                                lw(this, t, e)
                        }
                        this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e
                    }
                };
                var fw = function t(e) {
                    function n(t) {
                        return new sw(t, e)
                    }
                    return n.tension = function(e) {
                        return t(+e)
                    }, n
                }(0);

                function hw(t, e) {
                    this._context = t, this._k = (1 - e) / 6
                }
                hw.prototype = {
                    areaStart: nw,
                    areaEnd: nw,
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 1:
                                this._context.moveTo(this._x3, this._y3), this._context.closePath();
                                break;
                            case 2:
                                this._context.lineTo(this._x3, this._y3), this._context.closePath();
                                break;
                            case 3:
                                this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5)
                        }
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1, this._x3 = t, this._y3 = e;
                                break;
                            case 1:
                                this._point = 2, this._context.moveTo(this._x4 = t, this._y4 = e);
                                break;
                            case 2:
                                this._point = 3, this._x5 = t, this._y5 = e;
                                break;
                            default:
                                lw(this, t, e)
                        }
                        this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e
                    }
                };
                var dw = function t(e) {
                    function n(t) {
                        return new hw(t, e)
                    }
                    return n.tension = function(e) {
                        return t(+e)
                    }, n
                }(0);

                function pw(t, e) {
                    this._context = t, this._k = (1 - e) / 6
                }
                pw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        (this._line || 0 !== this._line && 3 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1;
                                break;
                            case 1:
                                this._point = 2;
                                break;
                            case 2:
                                this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
                                break;
                            case 3:
                                this._point = 4;
                            default:
                                lw(this, t, e)
                        }
                        this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e
                    }
                };
                var yw = function t(e) {
                    function n(t) {
                        return new pw(t, e)
                    }
                    return n.tension = function(e) {
                        return t(+e)
                    }, n
                }(0);

                function vw(t, e, n) {
                    var r = t._x1,
                        i = t._y1,
                        a = t._x2,
                        o = t._y2;
                    if (t._l01_a > rx) {
                        var u = 2 * t._l01_2a + 3 * t._l01_a * t._l12_a + t._l12_2a,
                            c = 3 * t._l01_a * (t._l01_a + t._l12_a);
                        r = (r * u - t._x0 * t._l12_2a + t._x2 * t._l01_2a) / c, i = (i * u - t._y0 * t._l12_2a + t._y2 * t._l01_2a) / c
                    }
                    if (t._l23_a > rx) {
                        var l = 2 * t._l23_2a + 3 * t._l23_a * t._l12_a + t._l12_2a,
                            s = 3 * t._l23_a * (t._l23_a + t._l12_a);
                        a = (a * l + t._x1 * t._l23_2a - e * t._l12_2a) / s, o = (o * l + t._y1 * t._l23_2a - n * t._l12_2a) / s
                    }
                    t._context.bezierCurveTo(r, i, a, o, t._x2, t._y2)
                }

                function bw(t, e) {
                    this._context = t, this._alpha = e
                }
                bw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 2:
                                this._context.lineTo(this._x2, this._y2);
                                break;
                            case 3:
                                this.point(this._x2, this._y2)
                        }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        if (t = +t, e = +e, this._point) {
                            var n = this._x2 - t,
                                r = this._y2 - e;
                            this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha))
                        }
                        switch (this._point) {
                            case 0:
                                this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                                break;
                            case 1:
                                this._point = 2;
                                break;
                            case 2:
                                this._point = 3;
                            default:
                                vw(this, t, e)
                        }
                        this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e
                    }
                };
                var gw = function t(e) {
                    function n(t) {
                        return e ? new bw(t, e) : new sw(t, 0)
                    }
                    return n.alpha = function(e) {
                        return t(+e)
                    }, n
                }(.5);

                function mw(t, e) {
                    this._context = t, this._alpha = e
                }
                mw.prototype = {
                    areaStart: nw,
                    areaEnd: nw,
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 1:
                                this._context.moveTo(this._x3, this._y3), this._context.closePath();
                                break;
                            case 2:
                                this._context.lineTo(this._x3, this._y3), this._context.closePath();
                                break;
                            case 3:
                                this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5)
                        }
                    },
                    point: function(t, e) {
                        if (t = +t, e = +e, this._point) {
                            var n = this._x2 - t,
                                r = this._y2 - e;
                            this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha))
                        }
                        switch (this._point) {
                            case 0:
                                this._point = 1, this._x3 = t, this._y3 = e;
                                break;
                            case 1:
                                this._point = 2, this._context.moveTo(this._x4 = t, this._y4 = e);
                                break;
                            case 2:
                                this._point = 3, this._x5 = t, this._y5 = e;
                                break;
                            default:
                                vw(this, t, e)
                        }
                        this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e
                    }
                };
                var _w = function t(e) {
                    function n(t) {
                        return e ? new mw(t, e) : new hw(t, 0)
                    }
                    return n.alpha = function(e) {
                        return t(+e)
                    }, n
                }(.5);

                function xw(t, e) {
                    this._context = t, this._alpha = e
                }
                xw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0
                    },
                    lineEnd: function() {
                        (this._line || 0 !== this._line && 3 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        if (t = +t, e = +e, this._point) {
                            var n = this._x2 - t,
                                r = this._y2 - e;
                            this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha))
                        }
                        switch (this._point) {
                            case 0:
                                this._point = 1;
                                break;
                            case 1:
                                this._point = 2;
                                break;
                            case 2:
                                this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
                                break;
                            case 3:
                                this._point = 4;
                            default:
                                vw(this, t, e)
                        }
                        this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e
                    }
                };
                var ww = function t(e) {
                    function n(t) {
                        return e ? new xw(t, e) : new pw(t, 0)
                    }
                    return n.alpha = function(e) {
                        return t(+e)
                    }, n
                }(.5);

                function kw(t) {
                    this._context = t
                }

                function Ow(t) {
                    return t < 0 ? -1 : 1
                }

                function Aw(t, e, n) {
                    var r = t._x1 - t._x0,
                        i = e - t._x1,
                        a = (t._y1 - t._y0) / (r || i < 0 && -0),
                        o = (n - t._y1) / (i || r < 0 && -0),
                        u = (a * i + o * r) / (r + i);
                    return (Ow(a) + Ow(o)) * Math.min(Math.abs(a), Math.abs(o), .5 * Math.abs(u)) || 0
                }

                function Ew(t, e) {
                    var n = t._x1 - t._x0;
                    return n ? (3 * (t._y1 - t._y0) / n - e) / 2 : e
                }

                function Mw(t, e, n) {
                    var r = t._x0,
                        i = t._y0,
                        a = t._x1,
                        o = t._y1,
                        u = (a - r) / 3;
                    t._context.bezierCurveTo(r + u, i + u * e, a - u, o - u * n, a, o)
                }

                function Tw(t) {
                    this._context = t
                }

                function jw(t) {
                    this._context = new Pw(t)
                }

                function Pw(t) {
                    this._context = t
                }

                function Sw(t) {
                    this._context = t
                }

                function Cw(t) {
                    var e, n, r = t.length - 1,
                        i = new Array(r),
                        a = new Array(r),
                        o = new Array(r);
                    for (i[0] = 0, a[0] = 2, o[0] = t[0] + 2 * t[1], e = 1; e < r - 1; ++e) i[e] = 1, a[e] = 4, o[e] = 4 * t[e] + 2 * t[e + 1];
                    for (i[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * t[r - 1] + t[r], e = 1; e < r; ++e) n = i[e] / a[e - 1], a[e] -= n, o[e] -= n * o[e - 1];
                    for (i[r - 1] = o[r - 1] / a[r - 1], e = r - 2; e >= 0; --e) i[e] = (o[e] - i[e + 1]) / a[e];
                    for (a[r - 1] = (t[r] + i[r - 1]) / 2, e = 0; e < r - 1; ++e) a[e] = 2 * t[e + 1] - i[e + 1];
                    return [i, a]
                }

                function Nw(t, e) {
                    this._context = t, this._t = e
                }

                function Dw(t, e) {
                    if ((i = t.length) > 1)
                        for (var n, r, i, a = 1, o = t[e[0]], u = o.length; a < i; ++a)
                            for (r = o, o = t[e[a]], n = 0; n < u; ++n) o[n][1] += o[n][0] = isNaN(r[n][1]) ? r[n][0] : r[n][1]
                }

                function Iw(t) {
                    for (var e = t.length, n = new Array(e); --e >= 0;) n[e] = e;
                    return n
                }

                function Lw(t, e) {
                    return t[e]
                }

                function zw(t) {
                    var e = t.map(Ww);
                    return Iw(t).sort((function(t, n) {
                        return e[t] - e[n]
                    }))
                }

                function Ww(t) {
                    for (var e, n = -1, r = 0, i = t.length, a = -1 / 0; ++n < i;)(e = +t[n][1]) > a && (a = e, r = n);
                    return r
                }

                function Fw(t) {
                    var e = t.map(Rw);
                    return Iw(t).sort((function(t, n) {
                        return e[t] - e[n]
                    }))
                }

                function Rw(t) {
                    for (var e, n = 0, r = -1, i = t.length; ++r < i;)(e = +t[r][1]) && (n += e);
                    return n
                }
                kw.prototype = {
                    areaStart: nw,
                    areaEnd: nw,
                    lineStart: function() {
                        this._point = 0
                    },
                    lineEnd: function() {
                        this._point && this._context.closePath()
                    },
                    point: function(t, e) {
                        t = +t, e = +e, this._point ? this._context.lineTo(t, e) : (this._point = 1, this._context.moveTo(t, e))
                    }
                }, Tw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        switch (this._point) {
                            case 2:
                                this._context.lineTo(this._x1, this._y1);
                                break;
                            case 3:
                                Mw(this, this._t0, Ew(this, this._t0))
                        }(this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line = 1 - this._line
                    },
                    point: function(t, e) {
                        var n = NaN;
                        if (e = +e, (t = +t) !== this._x1 || e !== this._y1) {
                            switch (this._point) {
                                case 0:
                                    this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                                    break;
                                case 1:
                                    this._point = 2;
                                    break;
                                case 2:
                                    this._point = 3, Mw(this, Ew(this, n = Aw(this, t, e)), n);
                                    break;
                                default:
                                    Mw(this, this._t0, n = Aw(this, t, e))
                            }
                            this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e, this._t0 = n
                        }
                    }
                }, (jw.prototype = Object.create(Tw.prototype)).point = function(t, e) {
                    Tw.prototype.point.call(this, e, t)
                }, Pw.prototype = {
                    moveTo: function(t, e) {
                        this._context.moveTo(e, t)
                    },
                    closePath: function() {
                        this._context.closePath()
                    },
                    lineTo: function(t, e) {
                        this._context.lineTo(e, t)
                    },
                    bezierCurveTo: function(t, e, n, r, i, a) {
                        this._context.bezierCurveTo(e, t, r, n, a, i)
                    }
                }, Sw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x = [], this._y = []
                    },
                    lineEnd: function() {
                        var t = this._x,
                            e = this._y,
                            n = t.length;
                        if (n)
                            if (this._line ? this._context.lineTo(t[0], e[0]) : this._context.moveTo(t[0], e[0]), 2 === n) this._context.lineTo(t[1], e[1]);
                            else
                                for (var r = Cw(t), i = Cw(e), a = 0, o = 1; o < n; ++a, ++o) this._context.bezierCurveTo(r[0][a], i[0][a], r[1][a], i[1][a], t[o], e[o]);
                        (this._line || 0 !== this._line && 1 === n) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null
                    },
                    point: function(t, e) {
                        this._x.push(+t), this._y.push(+e)
                    }
                }, Nw.prototype = {
                    areaStart: function() {
                        this._line = 0
                    },
                    areaEnd: function() {
                        this._line = NaN
                    },
                    lineStart: function() {
                        this._x = this._y = NaN, this._point = 0
                    },
                    lineEnd: function() {
                        0 < this._t && this._t < 1 && 2 === this._point && this._context.lineTo(this._x, this._y), (this._line || 0 !== this._line && 1 === this._point) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line)
                    },
                    point: function(t, e) {
                        switch (t = +t, e = +e, this._point) {
                            case 0:
                                this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                                break;
                            case 1:
                                this._point = 2;
                            default:
                                if (this._t <= 0) this._context.lineTo(this._x, e), this._context.lineTo(t, e);
                                else {
                                    var n = this._x * (1 - this._t) + t * this._t;
                                    this._context.lineTo(n, this._y), this._context.lineTo(n, e)
                                }
                        }
                        this._x = t, this._y = e
                    }
                };
                var Uw = Object.freeze(Object.defineProperty({
                    __proto__: null,
                    arc: function() {
                        var t = lx,
                            e = sx,
                            n = $_(0),
                            r = null,
                            i = fx,
                            a = hx,
                            o = dx,
                            u = null;

                        function c() {
                            var c, l, s = +t.apply(this, arguments),
                                f = +e.apply(this, arguments),
                                h = i.apply(this, arguments) - ax,
                                d = a.apply(this, arguments) - ax,
                                p = X_(d - h),
                                y = d > h;
                            if (u || (u = c = G_()), f < s && (l = f, f = s, s = l), f > rx)
                                if (p > ox - rx) u.moveTo(f * Z_(h), f * ex(h)), u.arc(0, 0, f, h, d, !y), s > rx && (u.moveTo(s * Z_(d), s * ex(d)), u.arc(0, 0, s, d, h, y));
                                else {
                                    var v, b, g = h,
                                        m = d,
                                        _ = h,
                                        x = d,
                                        w = p,
                                        k = p,
                                        O = o.apply(this, arguments) / 2,
                                        A = O > rx && (r ? +r.apply(this, arguments) : nx(s * s + f * f)),
                                        E = tx(X_(f - s) / 2, +n.apply(this, arguments)),
                                        M = E,
                                        T = E;
                                    if (A > rx) {
                                        var j = cx(A / s * ex(O)),
                                            P = cx(A / f * ex(O));
                                        (w -= 2 * j) > rx ? (_ += j *= y ? 1 : -1, x -= j) : (w = 0, _ = x = (h + d) / 2), (k -= 2 * P) > rx ? (g += P *= y ? 1 : -1, m -= P) : (k = 0, g = m = (h + d) / 2)
                                    }
                                    var S = f * Z_(g),
                                        C = f * ex(g),
                                        N = s * Z_(x),
                                        D = s * ex(x);
                                    if (E > rx) {
                                        var I, L = f * Z_(m),
                                            z = f * ex(m),
                                            W = s * Z_(_),
                                            F = s * ex(_);
                                        if (p < ix && (I = px(S, C, W, F, L, z, N, D))) {
                                            var R = S - I[0],
                                                U = C - I[1],
                                                q = L - I[0],
                                                B = z - I[1],
                                                H = 1 / ex(ux((R * q + U * B) / (nx(R * R + U * U) * nx(q * q + B * B))) / 2),
                                                K = nx(I[0] * I[0] + I[1] * I[1]);
                                            M = tx(E, (s - K) / (H - 1)), T = tx(E, (f - K) / (H + 1))
                                        }
                                    }
                                    k > rx ? T > rx ? (v = yx(W, F, S, C, f, T, y), b = yx(L, z, N, D, f, T, y), u.moveTo(v.cx + v.x01, v.cy + v.y01), T < E ? u.arc(v.cx, v.cy, T, Q_(v.y01, v.x01), Q_(b.y01, b.x01), !y) : (u.arc(v.cx, v.cy, T, Q_(v.y01, v.x01), Q_(v.y11, v.x11), !y), u.arc(0, 0, f, Q_(v.cy + v.y11, v.cx + v.x11), Q_(b.cy + b.y11, b.cx + b.x11), !y), u.arc(b.cx, b.cy, T, Q_(b.y11, b.x11), Q_(b.y01, b.x01), !y))) : (u.moveTo(S, C), u.arc(0, 0, f, g, m, !y)) : u.moveTo(S, C), s > rx && w > rx ? M > rx ? (v = yx(N, D, L, z, s, -M, y), b = yx(S, C, W, F, s, -M, y), u.lineTo(v.cx + v.x01, v.cy + v.y01), M < E ? u.arc(v.cx, v.cy, M, Q_(v.y01, v.x01), Q_(b.y01, b.x01), !y) : (u.arc(v.cx, v.cy, M, Q_(v.y01, v.x01), Q_(v.y11, v.x11), !y), u.arc(0, 0, s, Q_(v.cy + v.y11, v.cx + v.x11), Q_(b.cy + b.y11, b.cx + b.x11), y), u.arc(b.cx, b.cy, M, Q_(b.y11, b.x11), Q_(b.y01, b.x01), !y))) : u.arc(0, 0, s, x, _, y) : u.lineTo(N, D)
                                }
                            else u.moveTo(0, 0);
                            if (u.closePath(), c) return u = null, c + "" || null
                        }
                        return c.centroid = function() {
                            var n = (+t.apply(this, arguments) + +e.apply(this, arguments)) / 2,
                                r = (+i.apply(this, arguments) + +a.apply(this, arguments)) / 2 - ix / 2;
                            return [Z_(r) * n, ex(r) * n]
                        }, c.innerRadius = function(e) {
                            return arguments.length ? (t = "function" == typeof e ? e : $_(+e), c) : t
                        }, c.outerRadius = function(t) {
                            return arguments.length ? (e = "function" == typeof t ? t : $_(+t), c) : e
                        }, c.cornerRadius = function(t) {
                            return arguments.length ? (n = "function" == typeof t ? t : $_(+t), c) : n
                        }, c.padRadius = function(t) {
                            return arguments.length ? (r = null == t ? null : "function" == typeof t ? t : $_(+t), c) : r
                        }, c.startAngle = function(t) {
                            return arguments.length ? (i = "function" == typeof t ? t : $_(+t), c) : i
                        }, c.endAngle = function(t) {
                            return arguments.length ? (a = "function" == typeof t ? t : $_(+t), c) : a
                        }, c.padAngle = function(t) {
                            return arguments.length ? (o = "function" == typeof t ? t : $_(+t), c) : o
                        }, c.context = function(t) {
                            return arguments.length ? (u = null == t ? null : t, c) : u
                        }, c
                    },
                    area: xx,
                    line: _x,
                    pie: function() {
                        var t = kx,
                            e = wx,
                            n = null,
                            r = $_(0),
                            i = $_(ox),
                            a = $_(0);

                        function o(o) {
                            var u, c, l, s, f, h = o.length,
                                d = 0,
                                p = new Array(h),
                                y = new Array(h),
                                v = +r.apply(this, arguments),
                                b = Math.min(ox, Math.max(-ox, i.apply(this, arguments) - v)),
                                g = Math.min(Math.abs(b) / h, a.apply(this, arguments)),
                                m = g * (b < 0 ? -1 : 1);
                            for (u = 0; u < h; ++u)(f = y[p[u] = u] = +t(o[u], u, o)) > 0 && (d += f);
                            for (null != e ? p.sort((function(t, n) {
                                    return e(y[t], y[n])
                                })) : null != n && p.sort((function(t, e) {
                                    return n(o[t], o[e])
                                })), u = 0, l = d ? (b - h * m) / d : 0; u < h; ++u, v = s) c = p[u], s = v + ((f = y[c]) > 0 ? f * l : 0) + m, y[c] = {
                                data: o[c],
                                index: u,
                                value: f,
                                startAngle: v,
                                endAngle: s,
                                padAngle: g
                            };
                            return y
                        }
                        return o.value = function(e) {
                            return arguments.length ? (t = "function" == typeof e ? e : $_(+e), o) : t
                        }, o.sortValues = function(t) {
                            return arguments.length ? (e = t, n = null, o) : e
                        }, o.sort = function(t) {
                            return arguments.length ? (n = t, e = null, o) : n
                        }, o.startAngle = function(t) {
                            return arguments.length ? (r = "function" == typeof t ? t : $_(+t), o) : r
                        }, o.endAngle = function(t) {
                            return arguments.length ? (i = "function" == typeof t ? t : $_(+t), o) : i
                        }, o.padAngle = function(t) {
                            return arguments.length ? (a = "function" == typeof t ? t : $_(+t), o) : a
                        }, o
                    },
                    areaRadial: jx,
                    radialArea: jx,
                    lineRadial: Tx,
                    radialLine: Tx,
                    pointRadial: Px,
                    linkHorizontal: function() {
                        return Dx(Ix)
                    },
                    linkVertical: function() {
                        return Dx(Lx)
                    },
                    linkRadial: function() {
                        var t = Dx(zx);
                        return t.angle = t.x, delete t.x, t.radius = t.y, delete t.y, t
                    },
                    symbol: function() {
                        var t = $_(Wx),
                            e = $_(64),
                            n = null;

                        function r() {
                            var r;
                            if (n || (n = r = G_()), t.apply(this, arguments).draw(n, +e.apply(this, arguments)), r) return n = null, r + "" || null
                        }
                        return r.type = function(e) {
                            return arguments.length ? (t = "function" == typeof e ? e : $_(e), r) : t
                        }, r.size = function(t) {
                            return arguments.length ? (e = "function" == typeof t ? t : $_(+t), r) : e
                        }, r.context = function(t) {
                            return arguments.length ? (n = null == t ? null : t, r) : n
                        }, r
                    },
                    symbols: ew,
                    symbolCircle: Wx,
                    symbolCross: Fx,
                    symbolDiamond: qx,
                    symbolSquare: Vx,
                    symbolStar: Yx,
                    symbolTriangle: $x,
                    symbolWye: tw,
                    curveBasisClosed: function(t) {
                        return new aw(t)
                    },
                    curveBasisOpen: function(t) {
                        return new ow(t)
                    },
                    curveBasis: function(t) {
                        return new iw(t)
                    },
                    curveBundle: cw,
                    curveCardinalClosed: dw,
                    curveCardinalOpen: yw,
                    curveCardinal: fw,
                    curveCatmullRomClosed: _w,
                    curveCatmullRomOpen: ww,
                    curveCatmullRom: gw,
                    curveLinearClosed: function(t) {
                        return new kw(t)
                    },
                    curveLinear: bx,
                    curveMonotoneX: function(t) {
                        return new Tw(t)
                    },
                    curveMonotoneY: function(t) {
                        return new jw(t)
                    },
                    curveNatural: function(t) {
                        return new Sw(t)
                    },
                    curveStep: function(t) {
                        return new Nw(t, .5)
                    },
                    curveStepAfter: function(t) {
                        return new Nw(t, 1)
                    },
                    curveStepBefore: function(t) {
                        return new Nw(t, 0)
                    },
                    stack: function() {
                        var t = $_([]),
                            e = Iw,
                            n = Dw,
                            r = Lw;

                        function i(i) {
                            var a, o, u = t.apply(this, arguments),
                                c = i.length,
                                l = u.length,
                                s = new Array(l);
                            for (a = 0; a < l; ++a) {
                                for (var f, h = u[a], d = s[a] = new Array(c), p = 0; p < c; ++p) d[p] = f = [0, +r(i[p], h, p, i)], f.data = i[p];
                                d.key = h
                            }
                            for (a = 0, o = e(s); a < l; ++a) s[o[a]].index = a;
                            return n(s, o), s
                        }
                        return i.keys = function(e) {
                            return arguments.length ? (t = "function" == typeof e ? e : $_(Sx.call(e)), i) : t
                        }, i.value = function(t) {
                            return arguments.length ? (r = "function" == typeof t ? t : $_(+t), i) : r
                        }, i.order = function(t) {
                            return arguments.length ? (e = null == t ? Iw : "function" == typeof t ? t : $_(Sx.call(t)), i) : e
                        }, i.offset = function(t) {
                            return arguments.length ? (n = null == t ? Dw : t, i) : n
                        }, i
                    },
                    stackOffsetExpand: function(t, e) {
                        if ((r = t.length) > 0) {
                            for (var n, r, i, a = 0, o = t[0].length; a < o; ++a) {
                                for (i = n = 0; n < r; ++n) i += t[n][a][1] || 0;
                                if (i)
                                    for (n = 0; n < r; ++n) t[n][a][1] /= i
                            }
                            Dw(t, e)
                        }
                    },
                    stackOffsetDiverging: function(t, e) {
                        if ((u = t.length) > 0)
                            for (var n, r, i, a, o, u, c = 0, l = t[e[0]].length; c < l; ++c)
                                for (a = o = 0, n = 0; n < u; ++n)(i = (r = t[e[n]][c])[1] - r[0]) > 0 ? (r[0] = a, r[1] = a += i) : i < 0 ? (r[1] = o, r[0] = o += i) : (r[0] = 0, r[1] = i)
                    },
                    stackOffsetNone: Dw,
                    stackOffsetSilhouette: function(t, e) {
                        if ((n = t.length) > 0) {
                            for (var n, r = 0, i = t[e[0]], a = i.length; r < a; ++r) {
                                for (var o = 0, u = 0; o < n; ++o) u += t[o][r][1] || 0;
                                i[r][1] += i[r][0] = -u / 2
                            }
                            Dw(t, e)
                        }
                    },
                    stackOffsetWiggle: function(t, e) {
                        if ((i = t.length) > 0 && (r = (n = t[e[0]]).length) > 0) {
                            for (var n, r, i, a = 0, o = 1; o < r; ++o) {
                                for (var u = 0, c = 0, l = 0; u < i; ++u) {
                                    for (var s = t[e[u]], f = s[o][1] || 0, h = (f - (s[o - 1][1] || 0)) / 2, d = 0; d < u; ++d) {
                                        var p = t[e[d]];
                                        h += (p[o][1] || 0) - (p[o - 1][1] || 0)
                                    }
                                    c += f, l += h * f
                                }
                                n[o - 1][1] += n[o - 1][0] = a, c && (a -= l / c)
                            }
                            n[o - 1][1] += n[o - 1][0] = a, Dw(t, e)
                        }
                    },
                    stackOrderAppearance: zw,
                    stackOrderAscending: Fw,
                    stackOrderDescending: function(t) {
                        return Fw(t).reverse()
                    },
                    stackOrderInsideOut: function(t) {
                        var e, n, r = t.length,
                            i = t.map(Rw),
                            a = zw(t),
                            o = 0,
                            u = 0,
                            c = [],
                            l = [];
                        for (e = 0; e < r; ++e) n = a[e], o < u ? (o += i[n], c.push(n)) : (u += i[n], l.push(n));
                        return l.reverse().concat(c)
                    },
                    stackOrderNone: Iw,
                    stackOrderReverse: function(t) {
                        return Iw(t).reverse()
                    }
                }, Symbol.toStringTag, {
                    value: "Module"
                }));
                var qw = function(t) {
                        for (var e = -1, n = null == t ? 0 : t.length, r = {}; ++e < n;) {
                            var i = t[e];
                            r[i[0]] = i[1]
                        }
                        return r
                    },
                    Bw = {
                        exports: {}
                    };
                ! function(t, e) {
                    function n(t, e) {
                        var n = [],
                            r = [];
                        return null == e && (e = function(t, e) {
                                return n[0] === e ? "[Circular ~]" : "[Circular ~." + r.slice(0, n.indexOf(e)).join(".") + "]"
                            }),
                            function(i, a) {
                                if (n.length > 0) {
                                    var o = n.indexOf(this);
                                    ~o ? n.splice(o + 1) : n.push(this), ~o ? r.splice(o, 1 / 0, i) : r.push(i), ~n.indexOf(a) && (a = e.call(this, i, a))
                                } else n.push(a);
                                return null == t ? a : t.call(this, i, a)
                            }
                    }(t.exports = function(t, e, r, i) {
                        return JSON.stringify(t, n(e, i), r)
                    }).getSerialize = n
                }(Bw);
                var Hw = Bw.exports;

                function Kw(t, e) {
                    return function(t) {
                        if (Array.isArray(t)) return t
                    }(t) || function(t, e) {
                        var n = [],
                            r = !0,
                            i = !1,
                            a = void 0;
                        try {
                            for (var o, u = t[Symbol.iterator](); !(r = (o = u.next()).done) && (n.push(o.value), !e || n.length !== e); r = !0);
                        } catch (c) {
                            i = !0, a = c
                        } finally {
                            try {
                                r || null == u.return || u.return()
                            } finally {
                                if (i) throw a
                            }
                        }
                        return n
                    }(t, e) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }()
                }

                function Yw(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function Vw(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function Gw(t) {
                    if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return t
                }
                var $w = function(t) {
                    function e(t) {
                        var n;
                        return function(t, e) {
                            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), (n = function(t, e) {
                            return !e || "object" != typeof e && "function" != typeof e ? Gw(t) : e
                        }(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t))).state = n.state || {}, n.getScopedEvents = ly.bind(Gw(n)), n.getEventState = fy.bind(Gw(n)), n.baseProps = n.getBaseProps(t), n.sharedEventsCache = {}, n.globalEvents = {}, n.prevGlobalEventKeys = [], n.boundGlobalEvents = {}, n
                    }
                    var r, i, a;
                    return function(t, e) {
                        if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                        t.prototype = Object.create(e && e.prototype, {
                            constructor: {
                                value: t,
                                enumerable: !1,
                                writable: !0,
                                configurable: !0
                            }
                        }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                    }(e, t), r = e, i = [{
                        key: "shouldComponentUpdate",
                        value: function(t) {
                            if (!bc(this.props, t)) {
                                this.baseProps = this.getBaseProps(t);
                                var e = this.getExternalMutations(t, this.baseProps);
                                this.applyExternalMutations(t, e)
                            }
                            return !0
                        }
                    }, {
                        key: "componentDidMount",
                        value: function() {
                            var t = this,
                                e = si(this.globalEvents);
                            e.forEach((function(e) {
                                return t.addGlobalListener(e)
                            })), this.prevGlobalEventKeys = e
                        }
                    }, {
                        key: "componentDidUpdate",
                        value: function() {
                            var t = this,
                                e = si(this.globalEvents);
                            rp(this.prevGlobalEventKeys, e).forEach((function(e) {
                                return t.removeGlobalListener(e)
                            })), rp(e, this.prevGlobalEventKeys).forEach((function(e) {
                                return t.addGlobalListener(e)
                            })), this.prevGlobalEventKeys = e
                        }
                    }, {
                        key: "componentWillUnmount",
                        value: function() {
                            var t = this;
                            this.prevGlobalEventKeys.forEach((function(e) {
                                return t.removeGlobalListener(e)
                            }))
                        }
                    }, {
                        key: "addGlobalListener",
                        value: function(t) {
                            var e = this,
                                n = function(n) {
                                    var r = e.globalEvents[t];
                                    return r && r(my(n))
                                };
                            this.boundGlobalEvents[t] = n, window.addEventListener(vy(t), n)
                        }
                    }, {
                        key: "removeGlobalListener",
                        value: function(t) {
                            window.removeEventListener(vy(t), this.boundGlobalEvents[t])
                        }
                    }, {
                        key: "getAllEvents",
                        value: function(t) {
                            var e = yy(t, ["container", "groupComponent"]);
                            return Array.isArray(e) ? Array.isArray(t.events) ? e.concat.apply(e, Yw(t.events)) : e : t.events
                        }
                    }, {
                        key: "applyExternalMutations",
                        value: function(t, e) {
                            if (!Rf(e)) {
                                var n = t.externalEventMutations.reduce((function(t, e) {
                                        return t = It(e.callback) ? t.concat(e.callback) : t
                                    }), []),
                                    r = n.length ? function() {
                                        n.forEach((function(t) {
                                            return t()
                                        }))
                                    } : void 0;
                                this.setState(e, r)
                            }
                        }
                    }, {
                        key: "getExternalMutations",
                        value: function(t, e) {
                            return Rf(t.externalEventMutations) ? void 0 : hy(t.externalEventMutations, e, this.state, si(e))
                        }
                    }, {
                        key: "cacheSharedEvents",
                        value: function(t, e, n) {
                            this.sharedEventsCache[t] = [e, n]
                        }
                    }, {
                        key: "getCachedSharedEvents",
                        value: function(t, e) {
                            var n = Kw(this.sharedEventsCache[t] || [], 2),
                                r = n[0],
                                i = n[1];
                            if (r && bc(e, i)) return r
                        }
                    }, {
                        key: "getBaseProps",
                        value: function(t) {
                            var e = t.container,
                                r = n.Children.toArray(this.props.children),
                                i = this.getBasePropsFromChildren(r),
                                a = e ? e.props : {};
                            return Sl({}, i, {
                                parent: a
                            })
                        }
                    }, {
                        key: "getBasePropsFromChildren",
                        value: function(t) {
                            var e = mf(t, (function(t, e) {
                                if (t.type && It(t.type.getBaseProps)) {
                                    var n = t.props && t.type.getBaseProps(t.props);
                                    return n ? [
                                        [e, n]
                                    ] : null
                                }
                                return null
                            }));
                            return qw(e)
                        }
                    }, {
                        key: "getNewChildren",
                        value: function(t, e) {
                            var r = this,
                                i = t.events,
                                a = t.eventKey,
                                o = function(t, u) {
                                    return t.reduce((function(t, c, l) {
                                        if (c.props.children) {
                                            var s = n.Children.toArray(c.props.children),
                                                f = u.slice(l, l + s.length),
                                                h = n.cloneElement(c, c.props, o(s, f));
                                            return t.concat(h)
                                        }
                                        if ("parent" !== u[l] && c.type && It(c.type.getBaseProps)) {
                                            var d = c.props.name || u[l],
                                                p = Array.isArray(i) && i.filter((function(t) {
                                                    return "parent" !== t.target && (Array.isArray(t.childName) ? t.childName.indexOf(d) > -1 : t.childName === d || "all" === t.childName)
                                                })),
                                                y = [d, e, p, Hw(r.state[d])],
                                                v = r.getCachedSharedEvents(d, y) || {
                                                    events: p,
                                                    getEvents: function(t, n) {
                                                        return r.getScopedEvents(t, n, d, e)
                                                    },
                                                    getEventState: function(t, e) {
                                                        return r.getEventState(t, e, d)
                                                    }
                                                };
                                            return r.cacheSharedEvents(d, v, y), t.concat(n.cloneElement(c, Sl({
                                                key: "events-".concat(d),
                                                sharedEvents: v,
                                                eventKey: a,
                                                name: d
                                            }, c.props)))
                                        }
                                        return t.concat(c)
                                    }), [])
                                },
                                u = si(e),
                                c = n.Children.toArray(t.children);
                            return o(c, u)
                        }
                    }, {
                        key: "getContainer",
                        value: function(t, e, r) {
                            var i = this,
                                a = this.getNewChildren(t, e),
                                o = Array.isArray(r) && r.filter((function(t) {
                                    return "parent" === t.target
                                })),
                                u = o.length > 0 ? {
                                    events: o,
                                    getEvents: function(t, n) {
                                        return i.getScopedEvents(t, n, null, e)
                                    },
                                    getEventState: this.getEventState
                                } : null,
                                c = t.container || t.groupComponent,
                                l = c.type && c.type.role,
                                s = c.props || {},
                                f = cy.bind(this),
                                h = u && f({
                                    sharedEvents: u
                                }, "parent"),
                                d = sl({}, this.getEventState("parent", "parent"), s, e.parent, {
                                    children: a
                                }),
                                p = sl({}, sy(h, "parent", d), s.events);
                            this.globalEvents = by(p);
                            var y = gy(p);
                            return "container" === l ? n.cloneElement(c, Sl({}, d, {
                                events: y
                            })) : n.cloneElement(c, y, a)
                        }
                    }, {
                        key: "render",
                        value: function() {
                            var t = this.getAllEvents(this.props);
                            return t ? this.getContainer(this.props, this.baseProps, t) : n.cloneElement(this.props.container, {
                                children: this.props.children
                            })
                        }
                    }], i && Vw(r.prototype, i), a && Vw(r, a), e
                }(n.Component);

                function Xw(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function Qw(t, e) {
                    return function(t) {
                        if (Array.isArray(t)) return t
                    }(t) || function(t, e) {
                        var n = [],
                            r = !0,
                            i = !1,
                            a = void 0;
                        try {
                            for (var o, u = t[Symbol.iterator](); !(r = (o = u.next()).done) && (n.push(o.value), !e || n.length !== e); r = !0);
                        } catch (c) {
                            i = !0, a = c
                        } finally {
                            try {
                                r || null == u.return || u.return()
                            } finally {
                                if (i) throw a
                            }
                        }
                        return n
                    }(t, e) || function() {
                        throw new TypeError("Invalid attempt to destructure non-iterable instance")
                    }()
                }

                function Zw(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }
                Object.defineProperty($w, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictorySharedEvents"
                }), Object.defineProperty($w, "role", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "shared-event-wrapper"
                }), Object.defineProperty($w, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        children: C.oneOfType([C.arrayOf(C.node), C.node]),
                        container: C.node,
                        eventKey: C.oneOfType([C.array, C.func, ms([xs, _s]), C.string]),
                        events: C.arrayOf(C.shape({
                            childName: C.oneOfType([C.string, C.array]),
                            eventHandlers: C.object,
                            eventKey: C.oneOfType([C.array, C.func, ms([xs, _s]), C.string]),
                            target: C.string
                        })),
                        externalEventMutations: C.arrayOf(C.shape({
                            callback: C.function,
                            childName: C.oneOfType([C.string, C.array]),
                            eventKey: C.oneOfType([C.array, ms([xs, _s]), C.string]),
                            mutation: C.function,
                            target: C.oneOfType([C.string, C.array])
                        })),
                        groupComponent: C.node
                    }
                }), Object.defineProperty($w, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        groupComponent: n.createElement("g", null)
                    }
                }), Object.defineProperty($w, "contextType", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: fc
                });
                var Jw = {
                    width: 450,
                    height: 300,
                    padding: 50,
                    offset: 0
                };

                function tk(t, e) {
                    var r = "group",
                        i = function(t, e, n) {
                            return lf(e, t && t[n] && t[n].style ? t[n].style : {})
                        }((t = bf(t, Jw, r)).theme, t.style, r),
                        a = t,
                        o = a.offset,
                        u = a.colorScale,
                        c = a.color,
                        l = a.polar,
                        s = a.horizontal,
                        f = t.categories || function(t, e, n) {
                            var r = t.categories && !Array.isArray(t.categories) ? t.categories.x : t.categories,
                                i = t.categories && !Array.isArray(t.categories) ? t.categories.y : t.categories,
                                a = r && i ? {} : n || S_(t, e),
                                o = r || a.x,
                                u = i || a.y;
                            return {
                                x: o.length > 0 ? o : void 0,
                                y: u.length > 0 ? u : void 0
                            }
                        }(t, e),
                        h = t.datasets || function(t, e) {
                            var r = {
                                    polar: t.polar,
                                    startAngle: t.startAngle,
                                    endAngle: t.endAngle,
                                    categories: t.categories,
                                    minDomain: t.minDomain,
                                    maxDomain: t.maxDomain
                                },
                                i = 0,
                                a = e ? e.slice(0) : n.Children.toArray(t.children);
                            r = O_({
                                children: a,
                                props: t,
                                childComponents: e,
                                parentProps: r
                            });
                            var o = a.filter((function(t) {
                                    return t.type && "stack" === t.type.role
                                })).length,
                                u = mf(a, (function(t, e, a) {
                                    var o, u = Sl({}, t.props, r);
                                    return Im(t) ? (o = t.type && It(t.type.getData) ? (t = a ? n.cloneElement(t, a.props) : t).type.getData(u) : Cm(u), i += 1, o.map((function(t, e) {
                                        return Sl({
                                            _stack: i,
                                            _group: e
                                        }, t)
                                    }))) : null
                                }), t, [], (function(t, e) {
                                    return t.concat(s_(e, "_group"))
                                }));
                            return bp(__(u, o ? "_group" : "_stack"))
                        }(t),
                        d = {
                            x: M_(Sl({}, t, {
                                categories: f
                            }), "x", e),
                            y: M_(Sl({}, t, {
                                categories: f
                            }), "y", e)
                        },
                        p = t.range || {
                            x: yf(t, "x"),
                            y: yf(t, "y")
                        },
                        y = {
                            x: gm(t, "x") || T_(t, "x"),
                            y: gm(t, "y") || T_(t, "y")
                        };
                    return {
                        datasets: h,
                        categories: f,
                        range: p,
                        domain: d,
                        horizontal: s,
                        scale: {
                            x: y.x.domain(d.x).range(t.horizontal ? p.y : p.x),
                            y: y.y.domain(d.y).range(t.horizontal ? p.x : p.y)
                        },
                        style: i,
                        colorScale: u,
                        color: c,
                        offset: o,
                        origin: l ? t.origin : pf(t),
                        padding: uf(t)
                    }
                }
                var ek = function(t) {
                    var e = t.children,
                        r = n.Children.toArray(e).map((function(t) {
                            return function(t) {
                                for (var e = 1; e < arguments.length; e++) {
                                    var n = null != arguments[e] ? arguments[e] : {},
                                        r = Object.keys(n);
                                    "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                                    })))), r.forEach((function(e) {
                                        Zw(t, e, n[e])
                                    }))
                                }
                                return t
                            }({}, t, {
                                props: rf(t.props, ["sharedEvents"])
                            })
                        }));
                    return t.children = r, t
                };

                function nk(t, e, n, r) {
                    var i = (("stack" === r ? e.datasets[0].length : e.datasets.length) - 1) / 2,
                        a = function(t, e, n) {
                            if (!t.offset) return 0;
                            var r = gf(e, t.horizontal),
                                i = n.domain[e],
                                a = n.range[r];
                            return (Math.max.apply(Math, Xw(i)) - Math.min.apply(Math, Xw(i))) / (Math.max.apply(Math, Xw(a)) - Math.min.apply(Math, Xw(a))) * t.offset
                        }(t, "x", e);
                    return (n - i) * a
                }

                function rk(t, e, n, r) {
                    var i = (("stack" === r ? e.datasets[0].length : e.datasets.length) - 1) / 2,
                        a = function(t, e) {
                            var n = e.range,
                                r = Math.abs(n.x[1] - n.x[0]),
                                i = Math.max.apply(Math, Xw(n.y));
                            return t.offset / (2 * Math.PI * i) * r
                        }(t, e);
                    return (n - i) * a
                }

                function ik(t, e) {
                    var n = e.type && e.type.role,
                        r = e.props.colorScale || t.colorScale;
                    if ("group" === n || "stack" === n) return t.theme && t.theme.group ? r || t.theme.group.colorScale : r
                }

                function ak(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                        n = arguments.length > 2 ? arguments[2] : void 0,
                        r = t.data || t.y ? Cm(t) : e,
                        i = n || 0;
                    return r.map((function(t) {
                        var e = t._x instanceof Date ? new Date(t._x.getTime() + i) : t._x + i;
                        return Sl({}, t, {
                            _x1: e
                        })
                    }))
                }

                function ok(t, e, r) {
                    t = bf(t, Jw, "stack"), e = e || n.Children.toArray(t.children);
                    var i = (r = r || tk(t, e)).datasets,
                        a = t,
                        o = a.labelComponent,
                        u = a.polar,
                        c = function(t, e) {
                            var n = e.categories,
                                r = e.domain,
                                i = e.range,
                                a = e.scale,
                                o = e.horizontal,
                                u = e.origin,
                                c = e.padding,
                                l = t.width;
                            return {
                                height: t.height,
                                width: l,
                                theme: t.theme,
                                polar: t.polar,
                                origin: u,
                                categories: n,
                                domain: r,
                                range: i,
                                scale: a,
                                horizontal: o,
                                padding: c,
                                standalone: !1
                            }
                        }(t, r),
                        l = t.name || "group";
                    return e.map((function(e, a) {
                        var s = e.type && e.type.role,
                            f = u ? rk(t, r, a, s) : nk(t, r, a, s),
                            h = "voronoi" === s || "tooltip" === s || "label" === s ? e.props.style : j_(e, a, r),
                            d = t.labels ? function(t, e, n) {
                                if (t.labels) return Math.floor(e.length / 2) === n ? t.labels : void 0
                            }(t, i, a) : e.props.labels,
                            p = e.props.name || "".concat(l, "-").concat(s, "-").concat(a);
                        return n.cloneElement(e, Sl({
                            labels: d,
                            style: h,
                            key: "".concat(p, "-key-").concat(a),
                            name: p,
                            data: ak(t, i[a], f),
                            colorScale: ik(t, e),
                            labelComponent: o || e.props.labelComponent,
                            xOffset: f
                        }, c))
                    }))
                }

                function uk(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }
                var ck = {
                        width: 450,
                        height: 300,
                        padding: 50,
                        offset: 0
                    },
                    lk = function(t) {
                        var e = sk.role,
                            r = function() {
                                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : q_,
                                    e = U_(n.useState(t), 2),
                                    r = e[0],
                                    i = e[1],
                                    a = n.useCallback((function(t) {
                                        i((function(e) {
                                            return F_({}, e, t)
                                        }))
                                    }), [i]),
                                    o = n.useCallback((function(t, e, n) {
                                        if (!t.animate) return e.props.animate;
                                        var i, o = t.animate && t.animate.getTransitions,
                                            u = (i = Lh(i = r && r.childrenTransitions) ? i[n] : i, sl({
                                                childrenTransitions: i
                                            }, r)),
                                            c = t.animate && t.animate.parentState || u;
                                        if (!o) {
                                            var l = Kh(t, u, (function(t) {
                                                return a(t)
                                            }));
                                            o = function(t) {
                                                return l(t, n)
                                            }
                                        }
                                        return sl({
                                            getTransitions: o,
                                            parentState: c
                                        }, t.animate, e.props.animate)
                                    }), [r, a]),
                                    u = n.useCallback((function(t, e) {
                                        if (t.animate)
                                            if (t.animate.parentState) {
                                                var r = t.animate.parentState.nodesWillExit,
                                                    i = sl({
                                                        oldProps: r ? t : null,
                                                        nextProps: e
                                                    }, t.animate.parentState);
                                                a(i)
                                            } else {
                                                var o = n.Children.toArray(t.children),
                                                    u = n.Children.toArray(e.children),
                                                    c = function(t) {
                                                        var e = function(t) {
                                                            return t.type && t.type.continuous
                                                        };
                                                        return Array.isArray(t) ? W_(t, e) : e(t)
                                                    },
                                                    l = !t.polar && W_(o, (function(t) {
                                                        return c(t) || t.props.children && c(t.props.children)
                                                    })),
                                                    s = Hh(o, u),
                                                    f = s.nodesWillExit,
                                                    h = s.nodesWillEnter,
                                                    d = s.childrenTransitions,
                                                    p = s.nodesShouldEnter;
                                                a({
                                                    nodesWillExit: f,
                                                    nodesWillEnter: h,
                                                    nodesShouldEnter: p,
                                                    childrenTransitions: Lh(d) ? d[0] : d,
                                                    oldProps: f ? t : null,
                                                    nextProps: e,
                                                    continuous: l
                                                })
                                            }
                                    }), [a]),
                                    c = n.useCallback((function(t) {
                                        return r && r.nodesWillExit && r.oldProps || t
                                    }), [r]);
                                return {
                                    state: r,
                                    setState: a,
                                    getAnimationProps: o,
                                    setAnimationState: u,
                                    getProps: c
                                }
                            }(),
                            i = r.getAnimationProps,
                            a = r.setAnimationState,
                            o = (0, r.getProps)(t),
                            u = bf(o, ck, e),
                            c = u.eventKey,
                            l = u.containerComponent,
                            s = u.standalone,
                            f = u.groupComponent,
                            h = u.externalEventMutations,
                            d = u.width,
                            p = u.height,
                            y = u.theme,
                            v = u.polar,
                            b = u.horizontal,
                            g = u.name,
                            m = n.Children.toArray(u.children),
                            _ = function(t) {
                                var e = ek(t),
                                    r = Qw(n.useState(e), 2),
                                    i = r[0],
                                    a = r[1];
                                return n.useEffect((function() {
                                    bc(e, i) || a(e)
                                }), [i, a, e]), n.useMemo((function() {
                                    return tk(i, i.children)
                                }), [i])
                            }(u),
                            x = _.domain,
                            w = _.scale,
                            k = _.style,
                            O = _.origin,
                            A = n.useMemo((function() {
                                return ok(o, m, _).map((function(t, e) {
                                    var r = Sl({
                                        animate: i(o, t, e, "victory-group")
                                    }, t.props);
                                    return n.cloneElement(t, r)
                                }))
                            }), [o, m, _, i]),
                            E = n.useMemo((function() {
                                return s ? {
                                    domain: x,
                                    scale: w,
                                    width: d,
                                    height: p,
                                    standalone: s,
                                    theme: y,
                                    style: k.parent,
                                    horizontal: b,
                                    polar: v,
                                    origin: O,
                                    name: g
                                } : {}
                            }), [s, x, w, d, p, y, k, b, v, O, g]),
                            M = n.useMemo((function() {
                                return Of(t)
                            }), [t]),
                            T = n.useMemo((function() {
                                if (s) {
                                    var t = sl({}, l.props, E, M);
                                    return n.cloneElement(l, t)
                                }
                                return n.cloneElement(f, M)
                            }), [f, s, l, E, M]),
                            j = n.useMemo((function() {
                                return function(t) {
                                    var e = yy(t, ["groupComponent", "containerComponent", "labelComponent"]),
                                        n = t.events;
                                    return Array.isArray(e) && (n = Array.isArray(t.events) ? e.concat.apply(e, w_(t.events)) : e), n || []
                                }(o)
                            }), [o]),
                            P = function(t) {
                                var e = n.useRef();
                                return n.useEffect((function() {
                                    e.current = t
                                })), e.current || {}
                            }(t);
                        return n.useEffect((function() {
                            return function() {
                                t.animate && a(P, o)
                            }
                        }), [a, P, t, o]), Rf(j) ? n.cloneElement(T, T.props, A) : n.createElement($w, {
                            container: T,
                            eventKey: c,
                            events: j,
                            externalEventMutations: h
                        }, A)
                    };
                lk.propTypes = function(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {},
                            r = Object.keys(n);
                        "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                            return Object.getOwnPropertyDescriptor(n, t).enumerable
                        })))), r.forEach((function(e) {
                            uk(t, e, n[e])
                        }))
                    }
                    return t
                }({}, Od, kd, {
                    children: C.oneOfType([C.arrayOf(C.node), C.node]),
                    color: C.oneOfType([C.string, C.func]),
                    colorScale: C.oneOfType([C.arrayOf(C.string), C.oneOf(["grayscale", "qualitative", "heatmap", "warm", "cool", "red", "green", "blue"])]),
                    horizontal: C.bool,
                    offset: C.number
                }), lk.defaultProps = {
                    containerComponent: n.createElement(Pf, null),
                    groupComponent: n.createElement("g", null),
                    samples: 50,
                    sortOrder: "ascending",
                    standalone: !0,
                    theme: wd.grayscale
                };
                var sk = n.memo(lk, bc);
                sk.displayName = "VictoryGroup", sk.role = "group", sk.expectedComponents = ["groupComponent", "containerComponent", "labelComponent"], sk.getChildren = ok;
                var fk = sk,
                    hk = function(t) {
                        var e = t.polar,
                            n = function(t, e) {
                                var n = t.theme,
                                    r = void 0 === n ? {} : n,
                                    i = t.labelComponent,
                                    a = r[e] && r[e].style || {};
                                if (!cf(i)) return a;
                                var o = r.tooltip && r.tooltip.style || {},
                                    u = sl({}, o, a.labels);
                                return sl({}, {
                                    labels: u
                                }, a)
                            }(t, "area"),
                            r = lf(t.style, n),
                            i = {
                                x: yf(t, "x"),
                                y: yf(t, "y")
                            },
                            a = {
                                x: e_(t, "x"),
                                y: e_(t, "y")
                            },
                            o = {
                                x: bm(t, "x").domain(a.x).range(t.horizontal ? i.y : i.x),
                                y: bm(t, "y").domain(a.y).range(t.horizontal ? i.x : i.y)
                            },
                            u = e ? t.origin || pf(t) : void 0,
                            c = function(t, e) {
                                var n = Cm(t);
                                n.length < 2 && (n = []);
                                var r = function(t) {
                                    var n = "log" === _m(e[t]) ? 1 / Number.MAX_SAFE_INTEGER : 0,
                                        r = e[t].domain(),
                                        i = Fh(r),
                                        a = Wh(r),
                                        o = n;
                                    return i < 0 && a <= 0 ? o = a : i >= 0 && a > 0 && (o = i), Ih(r) ? new Date(o) : o
                                };
                                return n.map((function(t) {
                                    var e = void 0 !== t._y1 ? t._y1 : t._y,
                                        n = void 0 !== t._y0 ? t._y0 : r("y"),
                                        i = void 0 !== t._x1 ? t._x1 : t._x,
                                        a = void 0 !== t._x0 ? t._x0 : r("x");
                                    return Sl({}, t, {
                                        _y0: n,
                                        _y1: e,
                                        _x0: a,
                                        _x1: i
                                    })
                                }))
                            }(t, o);
                        return {
                            style: r,
                            data: c,
                            scale: o,
                            domain: a,
                            origin: u
                        }
                    };

                function dk(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {},
                            r = Object.keys(n);
                        "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                            return Object.getOwnPropertyDescriptor(n, t).enumerable
                        })))), r.forEach((function(e) {
                            pk(t, e, n[e])
                        }))
                    }
                    return t
                }

                function pk(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }
                var yk = function(t) {
                        var e = void 0 !== t._y1 ? t._y1 : t._y;
                        return null != e && null !== t._y0
                    },
                    vk = function(t) {
                        return function(e) {
                            return t.x(void 0 !== e._x1 ? e._x1 : e._x)
                        }
                    },
                    bk = function(t) {
                        return function(e) {
                            return t.y(void 0 !== e._y1 ? e._y1 : e._y)
                        }
                    },
                    gk = function(t) {
                        return function(e) {
                            return t.y(e._y0)
                        }
                    },
                    mk = function(t) {
                        return function(e) {
                            return -1 * t.x(void 0 !== e._x1 ? e._x1 : e._x) + Math.PI / 2
                        }
                    },
                    _k = function(t) {
                        return "curve".concat(function(t) {
                            return t && t[0].toUpperCase() + t.slice(1)
                        }(t))
                    },
                    xk = function(t) {
                        var e = t.polar,
                            n = t.scale,
                            r = t.horizontal,
                            i = "function" == typeof t.interpolation && t.interpolation,
                            a = "string" == typeof t.interpolation && _k(t.interpolation);
                        return e ? Tx().defined(yk).curve(i || Uw["".concat(a, "Closed")]).angle(mk(n)).radius(bk(n)) : _x().defined(yk).curve(i || Uw[a]).x(r ? bk(n) : vk(n)).y(r ? vk(n) : bk(n))
                    },
                    wk = function(t) {
                        var e = t.polar,
                            n = t.scale,
                            r = "function" == typeof t.interpolation && t.interpolation,
                            i = "string" == typeof t.interpolation && _k(t.interpolation),
                            a = r || i;
                        return e ? jx().defined(yk).curve(r || Uw["".concat(i, "Closed")]).angle(mk(n)).outerRadius(bk(n)).innerRadius(gk(n)) : function(t, e) {
                            var n = t.horizontal,
                                r = t.scale,
                                i = "function" == typeof e && e,
                                a = "string" == typeof e && e;
                            return n ? xx().defined(yk).curve(i || Uw[a]).x0(gk(r)).x1(bk(r)).y(vk(r)) : xx().defined(yk).curve(i || Uw[a]).x(vk(r)).y1(bk(r)).y0(gk(r))
                        }(t, a)
                    },
                    kk = function(t) {
                        t = function(t) {
                            var e = sf(t.ariaLabel, t),
                                n = sf(t.desc, t),
                                r = sf(t.id, t),
                                i = ff(Sl({
                                    fill: "black"
                                }, t.style), t),
                                a = sf(t.tabIndex, t);
                            return Sl({}, t, {
                                ariaLabel: e,
                                desc: n,
                                id: r,
                                style: i,
                                tabIndex: a
                            })
                        }(t);
                        var e = t,
                            r = e.ariaLabel,
                            i = e.role,
                            a = e.shapeRendering,
                            o = e.className,
                            u = e.polar,
                            c = e.origin,
                            l = e.data,
                            s = e.pathComponent,
                            f = e.events,
                            h = e.groupComponent,
                            d = e.clipPath,
                            p = e.id,
                            y = e.style,
                            v = e.desc,
                            b = e.tabIndex,
                            g = u && c ? "translate(".concat(c.x, ", ").concat(c.y, ")") : void 0,
                            m = t.transform || g,
                            _ = y.stroke && "none" !== y.stroke && "transparent" !== y.stroke,
                            x = wk(t),
                            w = _ && xk(t),
                            k = y.stroke ? "none" : y.fill,
                            O = dk({
                                "aria-label": r,
                                className: o,
                                role: i,
                                shapeRendering: a,
                                transform: m
                            }, f, {
                                clipPath: d,
                                tabIndex: b
                            }),
                            A = n.cloneElement(s, Sl({
                                key: "".concat(p, "-area"),
                                style: Sl({}, y, {
                                    stroke: k
                                }),
                                d: x(l),
                                desc: v,
                                tabIndex: b
                            }, O)),
                            E = _ ? n.cloneElement(s, Sl({
                                key: "".concat(p, "-area-stroke"),
                                style: Sl({}, y, {
                                    fill: "none"
                                }),
                                d: w(l)
                            }, O)) : null;
                        return _ ? n.cloneElement(h, {}, [A, E]) : A
                    };
                kk.propTypes = dk({}, Ad, {
                    groupComponent: C.element,
                    interpolation: C.oneOfType([C.string, C.func]),
                    pathComponent: C.element
                }), kk.defaultProps = {
                    groupComponent: n.createElement("g", null),
                    pathComponent: n.createElement(Ed, null),
                    role: "presentation",
                    shapeRendering: "auto"
                };
                var Ok = kk;

                function Ak(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function Ek(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }

                function Mk(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function Tk(t, e) {
                    return !e || "object" != typeof e && "function" != typeof e ? function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t) : e
                }
                var jk, Pk = {
                        width: 450,
                        height: 300,
                        padding: 50,
                        interpolation: "linear"
                    },
                    Sk = function(t) {
                        function e() {
                            return Ek(this, e), Tk(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                        }
                        var r, i, a;
                        return function(t, e) {
                            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                            t.prototype = Object.create(e && e.prototype, {
                                constructor: {
                                    value: t,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                        }(e, t), r = e, (i = [{
                            key: "shouldAnimate",
                            value: function() {
                                return !!this.props.animate
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var t = e.animationWhitelist,
                                    r = e.role,
                                    i = bf(this.props, Pk, r);
                                if (this.shouldAnimate()) return this.animateComponent(i, t);
                                var a = this.renderContinuousData(i),
                                    o = n.cloneElement(i.containerComponent, Of(i));
                                return i.standalone ? this.renderContainer(o, a) : a
                            }
                        }]) && Mk(r.prototype, i), a && Mk(r, a), e
                    }(n.Component);
                Object.defineProperty(Sk, "animationWhitelist", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: ["data", "domain", "height", "padding", "style", "width"]
                }), Object.defineProperty(Sk, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? arguments[e] : {},
                                r = Object.keys(n);
                            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                return Object.getOwnPropertyDescriptor(n, t).enumerable
                            })))), r.forEach((function(e) {
                                Ak(t, e, n[e])
                            }))
                        }
                        return t
                    }({}, Od, kd, {
                        interpolation: C.oneOfType([C.oneOf(["basis", "cardinal", "catmullRom", "linear", "monotoneX", "monotoneY", "natural", "step", "stepAfter", "stepBefore"]), C.func]),
                        label: (jk = C.string, function(t, e, n) {
                            return t[e], C.checkPropTypes((a = jk, (i = e) in (r = {}) ? Object.defineProperty(r, i, {
                                value: a,
                                enumerable: !0,
                                configurable: !0,
                                writable: !0
                            }) : r[i] = a, r), t, e, n);
                            var r, i, a
                        })
                    })
                }), Object.defineProperty(Sk, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        containerComponent: n.createElement(Pf, null),
                        dataComponent: n.createElement(Ok, null),
                        groupComponent: n.createElement(id, null),
                        labelComponent: n.createElement(Nh, {
                            renderInPortal: !0
                        }),
                        samples: 50,
                        sortKey: "x",
                        sortOrder: "ascending",
                        standalone: !0,
                        theme: wd.grayscale
                    }
                }), Object.defineProperty(Sk, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryArea"
                }), Object.defineProperty(Sk, "role", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "area"
                }), Object.defineProperty(Sk, "continuous", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: !0
                }), Object.defineProperty(Sk, "defaultTransitions", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        onLoad: {
                            duration: 2e3
                        },
                        onExit: {
                            duration: 500
                        },
                        onEnter: {
                            duration: 500
                        }
                    }
                }), Object.defineProperty(Sk, "defaultPolarTransitions", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        onLoad: {
                            duration: 2e3,
                            before: function() {
                                return {
                                    _y: 0,
                                    _y1: 0,
                                    _y0: 0
                                }
                            },
                            after: function(t) {
                                return {
                                    _y: t._y,
                                    _y1: t._y1,
                                    _y0: t._y0
                                }
                            }
                        },
                        onExit: {
                            duration: 500,
                            before: function(t, e, n) {
                                var r = function(t) {
                                    return (0 === e ? n[e + 1] : n[e - 1])[t]
                                };
                                return {
                                    _x: r("_x"),
                                    _y: r("_y"),
                                    _y0: r("_y0")
                                }
                            }
                        },
                        onEnter: {
                            duration: 500,
                            before: function(t, e, n) {
                                var r = function(t) {
                                    return (0 === e ? n[e + 1] : n[e - 1])[t]
                                };
                                return {
                                    _x: r("_x"),
                                    _y: r("_y"),
                                    _y0: r("_y0")
                                }
                            },
                            after: function(t) {
                                return {
                                    _x: t._x,
                                    _y: t._y,
                                    _y1: t._y1,
                                    _y0: t._y0
                                }
                            }
                        }
                    }
                }), Object.defineProperty(Sk, "getDomain", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: e_
                }), Object.defineProperty(Sk, "getData", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: Cm
                }), Object.defineProperty(Sk, "getBaseProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: function(t) {
                        return function(t, e) {
                            var n = bf(t, e, "area"),
                                r = t = Sl({}, n, hk(n)),
                                i = r.data,
                                a = r.domain,
                                o = r.events,
                                u = r.groupComponent,
                                c = r.height,
                                l = r.horizontal,
                                s = r.interpolation,
                                f = r.origin,
                                h = r.padding,
                                d = r.polar,
                                p = r.scale,
                                y = r.sharedEvents,
                                v = r.standalone,
                                b = r.style,
                                g = r.theme,
                                m = r.width,
                                _ = r.labels,
                                x = r.name,
                                w = r.disableInlineStyles,
                                k = {
                                    parent: {
                                        style: b.parent,
                                        width: m,
                                        height: c,
                                        scale: p,
                                        data: i,
                                        domain: a,
                                        standalone: v,
                                        theme: g,
                                        polar: d,
                                        origin: f,
                                        padding: h,
                                        name: x,
                                        horizontal: l
                                    },
                                    all: {
                                        data: {
                                            horizontal: l,
                                            polar: d,
                                            origin: f,
                                            scale: p,
                                            data: i,
                                            interpolation: s,
                                            groupComponent: u,
                                            style: w ? {} : b.data,
                                            disableInlineStyles: w
                                        }
                                    }
                                };
                            return i.reduce((function(e, n, r) {
                                return (null != Xf(t, n, r) || _ && (o || y)) && (e[ip(n.eventKey) ? r : n.eventKey] = {
                                    labels: Zf(t, r)
                                }), e
                            }), k)
                        }(t, Pk)
                    }
                }), Object.defineProperty(Sk, "expectedComponents", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: ["dataComponent", "labelComponent", "groupComponent", "containerComponent"]
                });
                var Ck = function(t, e) {
                        return function(r) {
                            function i(t) {
                                var e;
                                ! function(t, e) {
                                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                                }(this, i), e = function(t, e) {
                                    return !e || "object" != typeof e && "function" != typeof e ? wy(t) : e
                                }(this, (i.__proto__ || Object.getPrototypeOf(i)).call(this, t));
                                var n = ly.bind(wy(e)),
                                    r = cy.bind(wy(e));
                                e.state = {}, e.getEvents = function(t, e, i) {
                                    return r(t, e, i, n)
                                }, e.getEventState = fy.bind(wy(e));
                                var a = e.getCalculatedValues(t);
                                return e.cacheValues(a), e.externalMutations = e.getExternalMutations(t), e.calculatedState = e.getStateChanges(t), e.globalEvents = {}, e.prevGlobalEventKeys = [], e.boundGlobalEvents = {}, e
                            }
                            var a, o, u;
                            return function(t, e) {
                                if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                                t.prototype = Object.create(e && e.prototype, {
                                    constructor: {
                                        value: t,
                                        enumerable: !1,
                                        writable: !0,
                                        configurable: !0
                                    }
                                }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                            }(i, r), a = i, o = [{
                                key: "shouldComponentUpdate",
                                value: function(t) {
                                    var e = this.getExternalMutations(t),
                                        n = this.props.animating || this.props.animate,
                                        r = !bc(e, this.externalMutations);
                                    if (n || r) return this.cacheValues(this.getCalculatedValues(t)), this.externalMutations = e, this.applyExternalMutations(t, e), !0;
                                    var i = this.getStateChanges(t);
                                    return bc(this.calculatedState, i) ? !bc(this.props, t) && (this.cacheValues(this.getCalculatedValues(t)), !0) : (this.cacheValues(this.getCalculatedValues(t)), !0)
                                }
                            }, {
                                key: "componentDidMount",
                                value: function() {
                                    var t = this,
                                        e = si(this.globalEvents);
                                    e.forEach((function(e) {
                                        return t.addGlobalListener(e)
                                    })), this.prevGlobalEventKeys = e
                                }
                            }, {
                                key: "componentDidUpdate",
                                value: function(t) {
                                    var e = this,
                                        n = this.getStateChanges(t);
                                    this.calculatedState = n;
                                    var r = si(this.globalEvents);
                                    rp(this.prevGlobalEventKeys, r).forEach((function(t) {
                                        return e.removeGlobalListener(t)
                                    })), rp(r, this.prevGlobalEventKeys).forEach((function(t) {
                                        return e.addGlobalListener(t)
                                    })), this.prevGlobalEventKeys = r
                                }
                            }, {
                                key: "componentWillUnmount",
                                value: function() {
                                    var t = this;
                                    this.prevGlobalEventKeys.forEach((function(e) {
                                        return t.removeGlobalListener(e)
                                    }))
                                }
                            }, {
                                key: "addGlobalListener",
                                value: function(t) {
                                    var e = this,
                                        n = function(n) {
                                            var r = e.globalEvents[t];
                                            return r && r(my(n))
                                        };
                                    this.boundGlobalEvents[t] = n, window.addEventListener(vy(t), n)
                                }
                            }, {
                                key: "removeGlobalListener",
                                value: function(t) {
                                    window.removeEventListener(vy(t), this.boundGlobalEvents[t])
                                }
                            }, {
                                key: "getStateChanges",
                                value: function(t) {
                                    var n = this;
                                    if (!this.hasEvents) return {};
                                    var r = function(t, e) {
                                        var r = sl({}, n.getEventState(t, e), n.getSharedEventState(t, e));
                                        return Rf(r) ? void 0 : r
                                    };
                                    return ((e = e || {}).components || Oy).map((function(e) {
                                        return t.standalone || "parent" !== e.name ? void 0 !== e.index ? r(e.index, e.name) : n.dataKeys.map((function(t) {
                                            return r(t, e.name)
                                        })).filter(Boolean) : void 0
                                    })).filter(Boolean)
                                }
                            }, {
                                key: "applyExternalMutations",
                                value: function(t, e) {
                                    if (!Rf(e)) {
                                        var n = t.externalEventMutations.reduce((function(t, e) {
                                                return t = It(e.callback) ? t.concat(e.callback) : t
                                            }), []),
                                            r = n.length ? function() {
                                                n.forEach((function(t) {
                                                    return t()
                                                }))
                                            } : void 0;
                                        this.setState(e, r)
                                    }
                                }
                            }, {
                                key: "getCalculatedValues",
                                value: function(e) {
                                    var n = e.sharedEvents,
                                        r = yy(e, t.expectedComponents),
                                        i = n && It(n.getEventState) ? n.getEventState : function() {},
                                        a = this.getBaseProps(e, i);
                                    return {
                                        componentEvents: r,
                                        getSharedEventState: i,
                                        baseProps: a,
                                        dataKeys: si(a).filter((function(t) {
                                            return "parent" !== t
                                        })),
                                        hasEvents: e.events || e.sharedEvents || r,
                                        events: this.getAllEvents(e)
                                    }
                                }
                            }, {
                                key: "getExternalMutations",
                                value: function(t) {
                                    var e = t.sharedEvents,
                                        n = t.externalEventMutations;
                                    return Rf(n) || e ? void 0 : dy(n, this.baseProps, this.state)
                                }
                            }, {
                                key: "cacheValues",
                                value: function(t) {
                                    var e = this;
                                    si(t).forEach((function(n) {
                                        e[n] = t[n]
                                    }))
                                }
                            }, {
                                key: "getBaseProps",
                                value: function(e, n) {
                                    var r = (n = n || this.getSharedEventState)("parent", "parent"),
                                        i = this.getEventState("parent", "parent"),
                                        a = sl({}, i, r),
                                        o = a.parentControlledProps,
                                        u = o ? nf(a, o) : {},
                                        c = sl({}, u, e);
                                    return It(t.getBaseProps) ? t.getBaseProps(c) : {}
                                }
                            }, {
                                key: "getAllEvents",
                                value: function(t) {
                                    var e;
                                    return Array.isArray(this.componentEvents) ? Array.isArray(t.events) ? (e = this.componentEvents).concat.apply(e, _y(t.events)) : this.componentEvents : t.events
                                }
                            }, {
                                key: "getComponentProps",
                                value: function(e, n, r) {
                                    var i = this.props.name || t.role,
                                        a = this.dataKeys && this.dataKeys[r] || r,
                                        o = "".concat(i, "-").concat(n, "-").concat(a),
                                        u = this.baseProps[a] && this.baseProps[a][n] || this.baseProps[a];
                                    if (u || this.hasEvents) {
                                        if (this.hasEvents) {
                                            var c = this.getEvents(this.props, n, a),
                                                l = sl({
                                                    index: r,
                                                    key: o
                                                }, this.getEventState(a, n), this.getSharedEventState(a, n), e.props, u, {
                                                    id: o
                                                }),
                                                s = sl({}, sy(c, a, l), l.events);
                                            return Sl({}, l, {
                                                events: s
                                            })
                                        }
                                        return sl({
                                            index: r,
                                            key: o
                                        }, e.props, u, {
                                            id: o
                                        })
                                    }
                                }
                            }, {
                                key: "renderContainer",
                                value: function(t, e) {
                                    var r = t.type && "container" === t.type.role ? this.getComponentProps(t, "parent", "parent") : {};
                                    return r.events && (this.globalEvents = by(r.events), r.events = gy(r.events)), n.cloneElement(t, r, e)
                                }
                            }, {
                                key: "animateComponent",
                                value: function(t, e) {
                                    var r = t.animate && t.animate.animationWhitelist ? t.animate.animationWhitelist : e;
                                    return n.createElement($h, {
                                        animate: t.animate,
                                        animationWhitelist: r
                                    }, n.createElement(this.constructor, t))
                                }
                            }, {
                                key: "renderContinuousData",
                                value: function(t) {
                                    var e = this,
                                        r = t.dataComponent,
                                        i = t.labelComponent,
                                        a = t.groupComponent,
                                        o = cp(this.dataKeys, "all").reduce((function(t, r) {
                                            var a = e.getComponentProps(i, "labels", r);
                                            return a && void 0 !== a.text && null !== a.text && (t = t.concat(n.cloneElement(i, a))), t
                                        }), []),
                                        u = this.getComponentProps(r, "data", "all"),
                                        c = [n.cloneElement(r, u)].concat(_y(o));
                                    return this.renderContainer(a, c)
                                }
                            }, {
                                key: "renderData",
                                value: function(t) {
                                    var e = this,
                                        r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : ky,
                                        i = t.dataComponent,
                                        a = t.labelComponent,
                                        o = t.groupComponent,
                                        u = Of(t),
                                        c = this.dataKeys.reduce((function(t, a, o) {
                                            var u = e.getComponentProps(i, "data", o);
                                            return r(u.datum) && t.push(n.cloneElement(i, u)), t
                                        }), []),
                                        l = this.dataKeys.map((function(t, r) {
                                            var i = e.getComponentProps(a, "labels", r);
                                            if (void 0 !== i.text && null !== i.text) return n.cloneElement(a, i)
                                        })).filter(Boolean),
                                        s = _y(c).concat(_y(l)),
                                        f = n.cloneElement(o, u, s);
                                    return this.renderContainer(f, s)
                                }
                            }], o && xy(a.prototype, o), u && xy(a, u), i
                        }(t)
                    }(Sk, {
                        components: [{
                            name: "parent",
                            index: "parent"
                        }, {
                            name: "data",
                            index: "all"
                        }, {
                            name: "labels"
                        }]
                    }),
                    Nk = ct,
                    Dk = Pt,
                    Ik = function() {
                        return Nk.Date.now()
                    },
                    Lk = ns,
                    zk = Math.max,
                    Wk = Math.min;
                var Fk = function(t, e, n) {
                        var r, i, a, o, u, c, l = 0,
                            s = !1,
                            f = !1,
                            h = !0;
                        if ("function" != typeof t) throw new TypeError("Expected a function");

                        function d(e) {
                            var n = r,
                                a = i;
                            return r = i = void 0, l = e, o = t.apply(a, n)
                        }

                        function p(t) {
                            return l = t, u = setTimeout(v, e), s ? d(t) : o
                        }

                        function y(t) {
                            var n = t - c;
                            return void 0 === c || n >= e || n < 0 || f && t - l >= a
                        }

                        function v() {
                            var t = Ik();
                            if (y(t)) return b(t);
                            u = setTimeout(v, function(t) {
                                var n = e - (t - c);
                                return f ? Wk(n, a - (t - l)) : n
                            }(t))
                        }

                        function b(t) {
                            return u = void 0, h && r ? d(t) : (r = i = void 0, o)
                        }

                        function g() {
                            var t = Ik(),
                                n = y(t);
                            if (r = arguments, i = this, c = t, n) {
                                if (void 0 === u) return p(c);
                                if (f) return clearTimeout(u), u = setTimeout(v, e), d(c)
                            }
                            return void 0 === u && (u = setTimeout(v, e)), o
                        }
                        return e = Lk(e) || 0, Dk(n) && (s = !!n.leading, a = (f = "maxWait" in n) ? zk(Lk(n.maxWait) || 0, e) : a, h = "trailing" in n ? !!n.trailing : h), g.cancel = function() {
                            void 0 !== u && clearTimeout(u), l = 0, r = c = i = u = void 0
                        }, g.flush = function() {
                            return void 0 === u ? o : b(Ik())
                        }, g
                    },
                    Rk = Fk,
                    Uk = Pt;
                var qk = function(t, e, n) {
                        var r = !0,
                            i = !0;
                        if ("function" != typeof t) throw new TypeError("Expected a function");
                        return Uk(n) && (r = "leading" in n ? !!n.leading : r, i = "trailing" in n ? !!n.trailing : i), Rk(t, e, {
                            leading: r,
                            maxWait: e,
                            trailing: i
                        })
                    },
                    Bk = qk;

                function Hk(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {},
                            r = Object.keys(n);
                        "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                            return Object.getOwnPropertyDescriptor(n, t).enumerable
                        })))), r.forEach((function(e) {
                            Kk(t, e, n[e])
                        }))
                    }
                    return t
                }

                function Kk(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }
                var Yk = function(t) {
                        var e = t.orientation || "top";
                        return "left" === e || "right" === e ? function(t) {
                            var e = t.pointerWidth,
                                n = t.cornerRadius,
                                r = t.orientation,
                                i = t.width,
                                a = t.height,
                                o = t.center,
                                u = "left" === r ? 1 : -1,
                                c = t.x + (t.dx || 0),
                                l = t.y + (t.dy || 0),
                                s = Co(o) && o.x,
                                f = Co(o) && o.y,
                                h = s - u * (i / 2),
                                d = s + u * (i / 2),
                                p = f + a / 2,
                                y = f - a / 2,
                                v = u * (c - h) > 0 ? 0 : t.pointerLength,
                                b = "left" === r ? "0 0 0" : "0 0 1",
                                g = "".concat(n, " ").concat(n, " ").concat(b);
                            return "M ".concat(h, ", ").concat(f - e / 2, "\n    L ").concat(v ? c : h, ", ").concat(v ? l : f + e / 2, "\n    L ").concat(h, ", ").concat(f + e / 2, "\n    L ").concat(h, ", ").concat(p - n, "\n    A ").concat(g, " ").concat(h + u * n, ", ").concat(p, "\n    L ").concat(d - u * n, ", ").concat(p, "\n    A ").concat(g, " ").concat(d, ", ").concat(p - n, "\n    L ").concat(d, ", ").concat(y + n, "\n    A ").concat(g, " ").concat(d - u * n, ", ").concat(y, "\n    L ").concat(h + u * n, ", ").concat(y, "\n    A ").concat(g, " ").concat(h, ", ").concat(y + n, "\n    z")
                        }(t) : function(t) {
                            var e = t.pointerWidth,
                                n = t.cornerRadius,
                                r = t.orientation,
                                i = t.width,
                                a = t.height,
                                o = t.center,
                                u = "bottom" === r ? 1 : -1,
                                c = t.x + (t.dx || 0),
                                l = t.y + (t.dy || 0),
                                s = Co(o) && o.x,
                                f = Co(o) && o.y,
                                h = f + u * (a / 2),
                                d = f - u * (a / 2),
                                p = s + i / 2,
                                y = s - i / 2,
                                v = u * (l - h) < 0 ? 0 : t.pointerLength,
                                b = "bottom" === r ? "0 0 0" : "0 0 1",
                                g = "".concat(n, " ").concat(n, " ").concat(b);
                            return "M ".concat(s - e / 2, ", ").concat(h, "\n    L ").concat(v ? c : s + e / 2, ", ").concat(v ? l : h, "\n    L ").concat(s + e / 2, ", ").concat(h, "\n    L ").concat(p - n, ", ").concat(h, "\n    A ").concat(g, " ").concat(p, ", ").concat(h - u * n, "\n    L ").concat(p, ", ").concat(d + u * n, "\n    A ").concat(g, " ").concat(p - n, ", ").concat(d, "\n    L ").concat(y + n, ", ").concat(d, "\n    A ").concat(g, " ").concat(y, ", ").concat(d + u * n, "\n    L ").concat(y, ", ").concat(h - u * n, "\n    A ").concat(g, " ").concat(y + n, ", ").concat(h, "\n    z")
                        }(t)
                    },
                    Vk = function(t) {
                        return t = function(t) {
                            var e = sf(t.id, t),
                                n = ff(t.style, t);
                            return Sl({}, t, {
                                id: e,
                                style: n
                            })
                        }(t), n.cloneElement(t.pathComponent, Hk({}, t.events, {
                            style: t.style,
                            d: Yk(t),
                            className: t.className,
                            shapeRendering: t.shapeRendering,
                            role: t.role,
                            transform: t.transform,
                            clipPath: t.clipPath
                        }))
                    };
                Vk.propTypes = Hk({}, Ad, {
                    center: C.shape({
                        x: C.number,
                        y: C.number
                    }),
                    cornerRadius: C.number,
                    datum: C.object,
                    dx: C.number,
                    dy: C.number,
                    height: C.number,
                    orientation: C.oneOf(["top", "bottom", "left", "right"]),
                    pathComponent: C.element,
                    pointerLength: C.number,
                    pointerWidth: C.number,
                    width: C.number,
                    x: C.number,
                    y: C.number
                }), Vk.defaultProps = {
                    pathComponent: n.createElement(Ed, null),
                    role: "presentation",
                    shapeRendering: "auto"
                };
                var Gk = Vk;

                function $k(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function Xk(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function Qk(t, e) {
                    return !e || "object" != typeof e && "function" != typeof e ? function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t) : e
                }
                var Zk = {
                        cornerRadius: 5,
                        pointerLength: 10,
                        pointerWidth: 10
                    },
                    Jk = function(t) {
                        function e(t) {
                            var n;
                            return function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e), (n = Qk(this, (e.__proto__ || Object.getPrototypeOf(e)).call(this, t))).id = void 0 === t.id ? Oc("tooltip-") : t.id, n
                        }
                        var r, i, a;
                        return function(t, e) {
                            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                            t.prototype = Object.create(e && e.prototype, {
                                constructor: {
                                    value: t,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                        }(e, t), r = e, i = [{
                            key: "getDefaultOrientation",
                            value: function(t) {
                                var e = t.datum,
                                    n = t.horizontal;
                                if (t.polar) return this.getPolarOrientation(t, e);
                                var r = n ? "right" : "top",
                                    i = n ? "left" : "bottom";
                                return e && e.y < 0 ? i : r
                            }
                        }, {
                            key: "getPolarOrientation",
                            value: function(t, e) {
                                var n = Qf(t, e),
                                    r = t.labelPlacement || "vertical";
                                return " vertical" === r ? this.getVerticalOrientations(n) : "parallel" === r ? n < 90 || n > 270 ? "right" : "left" : n > 180 ? "bottom" : "top"
                            }
                        }, {
                            key: "getVerticalOrientations",
                            value: function(t) {
                                return t < 45 || t > 315 ? "right" : t >= 45 && t <= 135 ? "top" : t > 135 && t < 225 ? "left" : "bottom"
                            }
                        }, {
                            key: "getStyles",
                            value: function(t) {
                                var e = t.theme || wd.grayscale,
                                    n = e && e.tooltip && e.tooltip.style ? e.tooltip.style : {},
                                    r = Array.isArray(t.style) ? t.style.map((function(t) {
                                        return sl({}, t, n)
                                    })) : sl({}, t.style, n),
                                    i = e && e.tooltip && e.tooltip.flyoutStyle ? e.tooltip.flyoutStyle : {},
                                    a = t.flyoutStyle ? sl({}, t.flyoutStyle, i) : i,
                                    o = Array.isArray(r) ? r.map((function(e) {
                                        return ff(e, t)
                                    })) : ff(r, t);
                                return {
                                    style: o,
                                    flyoutStyle: ff(a, Sl({}, t, {
                                        style: o
                                    }))
                                }
                            }
                        }, {
                            key: "getEvaluatedProps",
                            value: function(t) {
                                var e = t.cornerRadius,
                                    n = t.centerOffset,
                                    r = t.dx,
                                    i = t.dy,
                                    a = sf(t.active, t),
                                    o = sf(t.text, Sl({}, t, {
                                        active: a
                                    })),
                                    u = this.getStyles(Sl({}, t, {
                                        active: a,
                                        text: o
                                    })),
                                    c = u.style,
                                    l = u.flyoutStyle,
                                    s = sf(t.orientation, Sl({}, t, {
                                        active: a,
                                        text: o,
                                        style: c,
                                        flyoutStyle: l
                                    })) || this.getDefaultOrientation(t),
                                    f = uf({
                                        padding: sf(t.flyoutPadding, Sl({}, t, {
                                            active: a,
                                            text: o,
                                            style: c,
                                            flyoutStyle: l,
                                            orientation: s
                                        })) || this.getLabelPadding(c)
                                    }),
                                    h = sf(t.pointerWidth, Sl({}, t, {
                                        active: a,
                                        text: o,
                                        style: c,
                                        flyoutStyle: l,
                                        orientation: s
                                    })),
                                    d = sf(t.pointerLength, Sl({}, t, {
                                        active: a,
                                        text: o,
                                        style: c,
                                        flyoutStyle: l,
                                        orientation: s
                                    })),
                                    p = dh(o, c),
                                    y = this.getDimensions(Sl({}, t, {
                                        style: c,
                                        flyoutStyle: l,
                                        active: a,
                                        text: o,
                                        orientation: s,
                                        flyoutPadding: f,
                                        pointerWidth: h,
                                        pointerLength: d
                                    }), p),
                                    v = y.flyoutHeight,
                                    b = y.flyoutWidth,
                                    g = Sl({}, t, {
                                        active: a,
                                        text: o,
                                        style: c,
                                        flyoutStyle: l,
                                        orientation: s,
                                        flyoutHeight: v,
                                        flyoutWidth: b,
                                        flyoutPadding: f,
                                        pointerWidth: h,
                                        pointerLength: d
                                    }),
                                    m = Co(n) && void 0 !== n.x ? sf(n.x, g) : 0,
                                    _ = Co(n) && void 0 !== n.y ? sf(n.y, g) : 0;
                                return Sl({}, g, {
                                    centerOffset: {
                                        x: m,
                                        y: _
                                    },
                                    dx: void 0 !== r ? sf(r, g) : 0,
                                    dy: void 0 !== i ? sf(i, g) : 0,
                                    cornerRadius: sf(e, g)
                                })
                            }
                        }, {
                            key: "getCalculatedValues",
                            value: function(t) {
                                var e = t.style,
                                    n = t.text,
                                    r = t.flyoutStyle,
                                    i = {
                                        height: t.flyoutHeight,
                                        width: t.flyoutWidth
                                    };
                                return {
                                    style: e,
                                    flyoutStyle: r,
                                    labelSize: dh(n, e),
                                    flyoutDimensions: i,
                                    flyoutCenter: this.getFlyoutCenter(t, i),
                                    transform: this.getTransform(t)
                                }
                            }
                        }, {
                            key: "getTransform",
                            value: function(t) {
                                var e = t.x,
                                    n = t.y,
                                    r = (t.style || {}).angle || t.angle || this.getDefaultAngle(t);
                                return r ? "rotate(".concat(r, " ").concat(e, " ").concat(n, ")") : void 0
                            }
                        }, {
                            key: "getDefaultAngle",
                            value: function(t) {
                                var e = t.polar,
                                    n = t.labelPlacement,
                                    r = t.orientation,
                                    i = t.datum;
                                if (!e || !n || "vertical" === n) return 0;
                                var a, o = Qf(t, i);
                                return 0 === o || 180 === o ? a = "top" === r && 180 === o ? 270 : 90 : o > 0 && o < 180 ? a = 90 - o : o > 180 && o < 360 && (a = 270 - o), a + (o > 90 && o < 180 || o > 270 ? 1 : -1) * ("perpendicular" === n ? 0 : 90)
                            }
                        }, {
                            key: "constrainTooltip",
                            value: function(t, e, n) {
                                var r = t.x,
                                    i = t.y,
                                    a = n.width,
                                    o = n.height,
                                    u = [0, e.width],
                                    c = [0, e.height],
                                    l = [r - a / 2, r + a / 2],
                                    s = [i - o / 2, i + o / 2],
                                    f = [l[0] < u[0] ? u[0] - l[0] : 0, l[1] > u[1] ? l[1] - u[1] : 0],
                                    h = [s[0] < c[0] ? c[0] - s[0] : 0, s[1] > c[1] ? s[1] - c[1] : 0];
                                return {
                                    x: Math.round(r + f[0] - f[1]),
                                    y: Math.round(i + h[0] - h[1])
                                }
                            }
                        }, {
                            key: "getFlyoutCenter",
                            value: function(t, e) {
                                var n = t.x,
                                    r = t.y,
                                    i = t.dx,
                                    a = t.dy,
                                    o = t.pointerLength,
                                    u = t.orientation,
                                    c = t.constrainToVisibleArea,
                                    l = t.centerOffset,
                                    s = e.height,
                                    f = e.width,
                                    h = "left" === u ? -1 : 1,
                                    d = "bottom" === u ? -1 : 1,
                                    p = {
                                        x: "left" === u || "right" === u ? n + h * (o + f / 2 + h * i) : n + i,
                                        y: "top" === u || "bottom" === u ? r - d * (o + s / 2 - d * a) : r + a
                                    },
                                    y = Co(t.center) && void 0 !== t.center.x ? t.center.x : p.x,
                                    v = Co(t.center) && void 0 !== t.center.y ? t.center.y : p.y,
                                    b = {
                                        x: y + l.x,
                                        y: v + l.y
                                    };
                                return c ? this.constrainTooltip(b, t, e) : b
                            }
                        }, {
                            key: "getLabelPadding",
                            value: function(t) {
                                if (!t) return 0;
                                var e = Array.isArray(t) ? t.map((function(t) {
                                    return t.padding
                                })) : [t.padding];
                                return Math.max.apply(Math, $k(e).concat([0]))
                            }
                        }, {
                            key: "getDimensions",
                            value: function(t, e) {
                                var n, r, i, a, o = t.orientation,
                                    u = t.pointerLength,
                                    c = t.pointerWidth,
                                    l = t.flyoutHeight,
                                    s = t.flyoutWidth,
                                    f = t.flyoutPadding,
                                    h = sf(t.cornerRadius, t);
                                return {
                                    flyoutHeight: l ? sf(l, t) : (i = e.height + f.top + f.bottom, a = "top" === o || "bottom" === o ? 2 * h : 2 * h + c, Math.max(a, i)),
                                    flyoutWidth: s ? sf(s, t) : (n = e.width + f.left + f.right, r = "left" === o || "right" === o ? 2 * h + u : 2 * h, Math.max(r, n))
                                }
                            }
                        }, {
                            key: "getLabelProps",
                            value: function(t, e) {
                                var n = e.flyoutCenter,
                                    r = e.style,
                                    i = e.labelSize,
                                    a = e.dy,
                                    o = void 0 === a ? 0 : a,
                                    u = e.dx,
                                    c = void 0 === u ? 0 : u,
                                    l = t.text,
                                    s = t.datum,
                                    f = t.activePoints,
                                    h = t.labelComponent,
                                    d = t.index,
                                    p = t.flyoutPadding,
                                    y = (Array.isArray(r) && r.length ? r[0].textAnchor : r.textAnchor) || "middle";
                                return sl({}, h.props, {
                                    key: "".concat(this.id, "-label-").concat(d),
                                    text: l,
                                    datum: s,
                                    activePoints: f,
                                    textAnchor: y,
                                    dy: o,
                                    dx: c,
                                    style: r,
                                    x: function() {
                                        if (!y || "middle" === y) return n.x;
                                        var t = "end" === y ? -1 : 1;
                                        return n.x - t * (i.width / 2)
                                    }() + (p.left - p.right) / 2,
                                    y: n.y + (p.top - p.bottom) / 2,
                                    verticalAnchor: "middle",
                                    angle: r.angle
                                })
                            }
                        }, {
                            key: "getPointerOrientation",
                            value: function(t, e, n) {
                                var r = e.y + n.height / 2,
                                    i = e.y - n.height / 2,
                                    a = e.x - n.width / 2,
                                    o = e.x + n.width / 2,
                                    u = [{
                                        side: "top",
                                        val: i > t.y ? i - t.y : -1
                                    }, {
                                        side: "bottom",
                                        val: r < t.y ? t.y - r : -1
                                    }, {
                                        side: "right",
                                        val: o < t.x ? t.x - o : -1
                                    }, {
                                        side: "left",
                                        val: a > t.x ? a - t.x : -1
                                    }];
                                return wo(u, "val", "desc")[0].side
                            }
                        }, {
                            key: "getFlyoutProps",
                            value: function(t, e) {
                                var n = e.flyoutDimensions,
                                    r = e.flyoutStyle,
                                    i = e.flyoutCenter,
                                    a = t.x,
                                    o = t.y,
                                    u = t.dx,
                                    c = t.dy,
                                    l = t.datum,
                                    s = t.activePoints,
                                    f = t.index,
                                    h = t.pointerLength,
                                    d = t.pointerWidth,
                                    p = t.cornerRadius,
                                    y = t.events,
                                    v = t.flyoutComponent,
                                    b = sf(t.pointerOrientation, t);
                                return sl({}, v.props, {
                                    x: a,
                                    y: o,
                                    dx: u,
                                    dy: c,
                                    datum: l,
                                    activePoints: s,
                                    index: f,
                                    pointerLength: h,
                                    pointerWidth: d,
                                    cornerRadius: p,
                                    events: y,
                                    orientation: b || this.getPointerOrientation({
                                        x: a,
                                        y: o
                                    }, i, n),
                                    key: "".concat(this.id, "-tooltip-").concat(f),
                                    width: n.width,
                                    height: n.height,
                                    style: r,
                                    center: i
                                })
                            }
                        }, {
                            key: "renderTooltip",
                            value: function(t) {
                                var e = sf(t.active, t),
                                    r = t.renderInPortal;
                                if (!e) return r ? n.createElement(Hf, null, null) : null;
                                var i = this.getEvaluatedProps(t),
                                    a = i.flyoutComponent,
                                    o = i.labelComponent,
                                    u = i.groupComponent,
                                    c = this.getCalculatedValues(i),
                                    l = [n.cloneElement(a, this.getFlyoutProps(i, c)), n.cloneElement(o, this.getLabelProps(i, c))],
                                    s = n.cloneElement(u, {
                                        role: "presentation",
                                        transform: c.transform
                                    }, l);
                                return r ? n.createElement(Hf, null, s) : s
                            }
                        }, {
                            key: "render",
                            value: function() {
                                var t = bf(this.props, Zk, "tooltip");
                                return this.renderTooltip(t)
                            }
                        }], i && Xk(r.prototype, i), a && Xk(r, a), e
                    }(n.Component);
                Object.defineProperty(Jk, "displayName", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "VictoryTooltip"
                }), Object.defineProperty(Jk, "role", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: "tooltip"
                }), Object.defineProperty(Jk, "propTypes", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        activateData: C.bool,
                        active: C.oneOfType([C.bool, C.func]),
                        activePoints: C.array,
                        angle: C.number,
                        center: C.shape({
                            x: _s,
                            y: _s
                        }),
                        centerOffset: C.shape({
                            x: C.oneOfType([C.number, C.func]),
                            y: C.oneOfType([C.number, C.func])
                        }),
                        constrainToVisibleArea: C.bool,
                        cornerRadius: C.oneOfType([_s, C.func]),
                        data: C.array,
                        datum: C.object,
                        dx: C.oneOfType([C.number, C.func]),
                        dy: C.oneOfType([C.number, C.func]),
                        events: C.object,
                        flyoutComponent: C.element,
                        flyoutHeight: C.oneOfType([_s, C.func]),
                        flyoutPadding: C.oneOfType([C.func, C.number, C.shape({
                            top: C.number,
                            bottom: C.number,
                            left: C.number,
                            right: C.number
                        })]),
                        flyoutStyle: C.object,
                        flyoutWidth: C.oneOfType([_s, C.func]),
                        groupComponent: C.element,
                        height: C.number,
                        horizontal: C.bool,
                        id: C.oneOfType([C.number, C.string]),
                        index: C.oneOfType([C.number, C.string]),
                        labelComponent: C.element,
                        orientation: C.oneOfType([C.oneOf(["top", "bottom", "left", "right"]), C.func]),
                        pointerLength: C.oneOfType([_s, C.func]),
                        pointerOrientation: C.oneOfType([C.oneOf(["top", "bottom", "left", "right"]), C.func]),
                        pointerWidth: C.oneOfType([_s, C.func]),
                        polar: C.bool,
                        renderInPortal: C.bool,
                        scale: C.shape({
                            x: ks,
                            y: ks
                        }),
                        style: C.oneOfType([C.object, C.array]),
                        text: C.oneOfType([C.string, C.number, C.func, C.array]),
                        theme: C.object,
                        width: C.number,
                        x: C.number,
                        y: C.number
                    }
                }), Object.defineProperty(Jk, "defaultProps", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: {
                        active: !1,
                        renderInPortal: !0,
                        labelComponent: n.createElement(Nh, null),
                        flyoutComponent: n.createElement(Gk, null),
                        groupComponent: n.createElement("g", null)
                    }
                }), Object.defineProperty(Jk, "defaultEvents", {
                    configurable: !0,
                    enumerable: !0,
                    writable: !0,
                    value: function(t) {
                        var e = t.activateData ? [{
                                target: "labels",
                                mutation: function() {
                                    return {
                                        active: !0
                                    }
                                }
                            }, {
                                target: "data",
                                mutation: function() {
                                    return {
                                        active: !0
                                    }
                                }
                            }] : [{
                                target: "labels",
                                mutation: function() {
                                    return {
                                        active: !0
                                    }
                                }
                            }],
                            n = t.activateData ? [{
                                target: "labels",
                                mutation: function() {
                                    return {
                                        active: void 0
                                    }
                                }
                            }, {
                                target: "data",
                                mutation: function() {
                                    return {
                                        active: void 0
                                    }
                                }
                            }] : [{
                                target: "labels",
                                mutation: function() {
                                    return {
                                        active: void 0
                                    }
                                }
                            }];
                        return [{
                            target: "data",
                            eventHandlers: {
                                onMouseOver: function() {
                                    return e
                                },
                                onFocus: function() {
                                    return e
                                },
                                onTouchStart: function() {
                                    return e
                                },
                                onMouseOut: function() {
                                    return n
                                },
                                onBlur: function() {
                                    return n
                                },
                                onTouchEnd: function() {
                                    return n
                                }
                            }
                        }]
                    }
                });
                var tO = {},
                    eO = {
                        exports: {}
                    };
                eO.exports = function() {
                        var t = Math.pow(2, -52),
                            e = new Uint32Array(512),
                            n = function(t) {
                                var e = t.length >> 1;
                                if (e > 0 && "number" != typeof t[0]) throw new Error("Expected coords to contain numbers.");
                                this.coords = t;
                                var n = Math.max(2 * e - 5, 0);
                                this._triangles = new Uint32Array(3 * n), this._halfedges = new Int32Array(3 * n), this._hashSize = Math.ceil(Math.sqrt(e)), this._hullPrev = new Uint32Array(e), this._hullNext = new Uint32Array(e), this._hullTri = new Uint32Array(e), this._hullHash = new Int32Array(this._hashSize).fill(-1), this._ids = new Uint32Array(e), this._dists = new Float64Array(e), this.update()
                            };

                        function r(t, e) {
                            var n = t / (Math.abs(t) + Math.abs(e));
                            return (e > 0 ? 3 - n : 1 + n) / 4
                        }

                        function i(t, e, n, r) {
                            var i = t - n,
                                a = e - r;
                            return i * i + a * a
                        }

                        function a(t, e, n, r, i, a) {
                            var o = (r - e) * (i - t),
                                u = (n - t) * (a - e);
                            return Math.abs(o - u) >= 33306690738754716e-32 * Math.abs(o + u) ? o - u : 0
                        }

                        function o(t, e, n, r, i, o) {
                            return (a(i, o, t, e, n, r) || a(t, e, n, r, i, o) || a(n, r, i, o, t, e)) < 0
                        }

                        function u(t, e, n, r, i, a, o, u) {
                            var c = t - o,
                                l = e - u,
                                s = n - o,
                                f = r - u,
                                h = i - o,
                                d = a - u,
                                p = s * s + f * f,
                                y = h * h + d * d;
                            return c * (f * y - p * d) - l * (s * y - p * h) + (c * c + l * l) * (s * d - f * h) < 0
                        }

                        function c(t, e, n, r, i, a) {
                            var o = n - t,
                                u = r - e,
                                c = i - t,
                                l = a - e,
                                s = o * o + u * u,
                                f = c * c + l * l,
                                h = .5 / (o * l - u * c),
                                d = (l * s - u * f) * h,
                                p = (o * f - c * s) * h;
                            return d * d + p * p
                        }

                        function l(t, e, n, r, i, a) {
                            var o = n - t,
                                u = r - e,
                                c = i - t,
                                l = a - e,
                                s = o * o + u * u,
                                f = c * c + l * l,
                                h = .5 / (o * l - u * c);
                            return {
                                x: t + (l * s - u * f) * h,
                                y: e + (o * f - c * s) * h
                            }
                        }

                        function s(t, e, n, r) {
                            if (r - n <= 20)
                                for (var i = n + 1; i <= r; i++) {
                                    for (var a = t[i], o = e[a], u = i - 1; u >= n && e[t[u]] > o;) t[u + 1] = t[u--];
                                    t[u + 1] = a
                                } else {
                                    var c = n + 1,
                                        l = r;
                                    f(t, n + r >> 1, c), e[t[n]] > e[t[r]] && f(t, n, r), e[t[c]] > e[t[r]] && f(t, c, r), e[t[n]] > e[t[c]] && f(t, n, c);
                                    for (var h = t[c], d = e[h];;) {
                                        do {
                                            c++
                                        } while (e[t[c]] < d);
                                        do {
                                            l--
                                        } while (e[t[l]] > d);
                                        if (l < c) break;
                                        f(t, c, l)
                                    }
                                    t[n + 1] = t[l], t[l] = h, r - c + 1 >= l - n ? (s(t, e, c, r), s(t, e, n, l - 1)) : (s(t, e, n, l - 1), s(t, e, c, r))
                                }
                        }

                        function f(t, e, n) {
                            var r = t[e];
                            t[e] = t[n], t[n] = r
                        }

                        function h(t) {
                            return t[0]
                        }

                        function d(t) {
                            return t[1]
                        }
                        return n.from = function(t, e, r) {
                            void 0 === e && (e = h), void 0 === r && (r = d);
                            for (var i = t.length, a = new Float64Array(2 * i), o = 0; o < i; o++) {
                                var u = t[o];
                                a[2 * o] = e(u), a[2 * o + 1] = r(u)
                            }
                            return new n(a)
                        }, n.prototype.update = function() {
                            for (var e = this, n = e.coords, r = e._hullPrev, a = e._hullNext, u = e._hullTri, f = e._hullHash, h = n.length >> 1, d = 1 / 0, p = 1 / 0, y = -1 / 0, v = -1 / 0, b = 0; b < h; b++) {
                                var g = n[2 * b],
                                    m = n[2 * b + 1];
                                g < d && (d = g), m < p && (p = m), g > y && (y = g), m > v && (v = m), this._ids[b] = b
                            }
                            for (var _, x, w, k = (d + y) / 2, O = (p + v) / 2, A = 1 / 0, E = 0; E < h; E++) {
                                var M = i(k, O, n[2 * E], n[2 * E + 1]);
                                M < A && (_ = E, A = M)
                            }
                            var T = n[2 * _],
                                j = n[2 * _ + 1];
                            A = 1 / 0;
                            for (var P = 0; P < h; P++)
                                if (P !== _) {
                                    var S = i(T, j, n[2 * P], n[2 * P + 1]);
                                    S < A && S > 0 && (x = P, A = S)
                                }
                            for (var C = n[2 * x], N = n[2 * x + 1], D = 1 / 0, I = 0; I < h; I++)
                                if (I !== _ && I !== x) {
                                    var L = c(T, j, C, N, n[2 * I], n[2 * I + 1]);
                                    L < D && (w = I, D = L)
                                }
                            var z = n[2 * w],
                                W = n[2 * w + 1];
                            if (D === 1 / 0) {
                                for (var F = 0; F < h; F++) this._dists[F] = n[2 * F] - n[0] || n[2 * F + 1] - n[1];
                                s(this._ids, this._dists, 0, h - 1);
                                for (var R = new Uint32Array(h), U = 0, q = 0, B = -1 / 0; q < h; q++) {
                                    var H = this._ids[q];
                                    this._dists[H] > B && (R[U++] = H, B = this._dists[H])
                                }
                                return this.hull = R.subarray(0, U), this.triangles = new Uint32Array(0), void(this.halfedges = new Uint32Array(0))
                            }
                            if (o(T, j, C, N, z, W)) {
                                var K = x,
                                    Y = C,
                                    V = N;
                                x = w, C = z, N = W, w = K, z = Y, W = V
                            }
                            var G = l(T, j, C, N, z, W);
                            this._cx = G.x, this._cy = G.y;
                            for (var $ = 0; $ < h; $++) this._dists[$] = i(n[2 * $], n[2 * $ + 1], G.x, G.y);
                            s(this._ids, this._dists, 0, h - 1), this._hullStart = _;
                            var X = 3;
                            a[_] = r[w] = x, a[x] = r[_] = w, a[w] = r[x] = _, u[_] = 0, u[x] = 1, u[w] = 2, f.fill(-1), f[this._hashKey(T, j)] = _, f[this._hashKey(C, N)] = x, f[this._hashKey(z, W)] = w, this.trianglesLen = 0, this._addTriangle(_, x, w, -1, -1, -1);
                            for (var Q = 0, Z = void 0, J = void 0; Q < this._ids.length; Q++) {
                                var tt = this._ids[Q],
                                    et = n[2 * tt],
                                    nt = n[2 * tt + 1];
                                if (!(Q > 0 && Math.abs(et - Z) <= t && Math.abs(nt - J) <= t) && (Z = et, J = nt, tt !== _ && tt !== x && tt !== w)) {
                                    for (var rt = 0, it = 0, at = this._hashKey(et, nt); it < this._hashSize && (-1 === (rt = f[(at + it) % this._hashSize]) || rt === a[rt]); it++);
                                    for (var ot = rt = r[rt], ut = void 0; ut = a[ot], !o(et, nt, n[2 * ot], n[2 * ot + 1], n[2 * ut], n[2 * ut + 1]);)
                                        if ((ot = ut) === rt) {
                                            ot = -1;
                                            break
                                        }
                                    if (-1 !== ot) {
                                        var ct = this._addTriangle(ot, tt, a[ot], -1, -1, u[ot]);
                                        u[tt] = this._legalize(ct + 2), u[ot] = ct, X++;
                                        for (var lt = a[ot]; ut = a[lt], o(et, nt, n[2 * lt], n[2 * lt + 1], n[2 * ut], n[2 * ut + 1]);) ct = this._addTriangle(lt, tt, ut, u[tt], -1, u[lt]), u[tt] = this._legalize(ct + 2), a[lt] = lt, X--, lt = ut;
                                        if (ot === rt)
                                            for (; o(et, nt, n[2 * (ut = r[ot])], n[2 * ut + 1], n[2 * ot], n[2 * ot + 1]);) ct = this._addTriangle(ut, tt, ot, -1, u[ot], u[ut]), this._legalize(ct + 2), u[ut] = ct, a[ot] = ot, X--, ot = ut;
                                        this._hullStart = r[tt] = ot, a[ot] = r[lt] = tt, a[tt] = lt, f[this._hashKey(et, nt)] = tt, f[this._hashKey(n[2 * ot], n[2 * ot + 1])] = ot
                                    }
                                }
                            }
                            this.hull = new Uint32Array(X);
                            for (var st = 0, ft = this._hullStart; st < X; st++) this.hull[st] = ft, ft = a[ft];
                            this.triangles = this._triangles.subarray(0, this.trianglesLen), this.halfedges = this._halfedges.subarray(0, this.trianglesLen)
                        }, n.prototype._hashKey = function(t, e) {
                            return Math.floor(r(t - this._cx, e - this._cy) * this._hashSize) % this._hashSize
                        }, n.prototype._legalize = function(t) {
                            for (var n = this, r = n._triangles, i = n._halfedges, a = n.coords, o = 0, c = 0;;) {
                                var l = i[t],
                                    s = t - t % 3;
                                if (c = s + (t + 2) % 3, -1 !== l) {
                                    var f = l - l % 3,
                                        h = s + (t + 1) % 3,
                                        d = f + (l + 2) % 3,
                                        p = r[c],
                                        y = r[t],
                                        v = r[h],
                                        b = r[d];
                                    if (u(a[2 * p], a[2 * p + 1], a[2 * y], a[2 * y + 1], a[2 * v], a[2 * v + 1], a[2 * b], a[2 * b + 1])) {
                                        r[t] = b, r[l] = p;
                                        var g = i[d];
                                        if (-1 === g) {
                                            var m = this._hullStart;
                                            do {
                                                if (this._hullTri[m] === d) {
                                                    this._hullTri[m] = t;
                                                    break
                                                }
                                                m = this._hullPrev[m]
                                            } while (m !== this._hullStart)
                                        }
                                        this._link(t, g), this._link(l, i[c]), this._link(c, d);
                                        var _ = f + (l + 1) % 3;
                                        o < e.length && (e[o++] = _)
                                    } else {
                                        if (0 === o) break;
                                        t = e[--o]
                                    }
                                } else {
                                    if (0 === o) break;
                                    t = e[--o]
                                }
                            }
                            return c
                        }, n.prototype._link = function(t, e) {
                            this._halfedges[t] = e, -1 !== e && (this._halfedges[e] = t)
                        }, n.prototype._addTriangle = function(t, e, n, r, i, a) {
                            var o = this.trianglesLen;
                            return this._triangles[o] = t, this._triangles[o + 1] = e, this._triangles[o + 2] = n, this._link(o, r), this._link(o + 1, i), this._link(o + 2, a), this.trianglesLen += 3, o
                        }, n
                    }(),
                    function(t) {
                        t.__esModule = !0, t.default = void 0;
                        var e, n = (e = eO.exports) && e.__esModule ? e : {
                            default: e
                        };

                        function r(t) {
                            return t[0]
                        }

                        function i(t) {
                            return t[1]
                        }

                        function a(t, e, n) {
                            return [t + Math.sin(t + e) * n, e + Math.cos(t - e) * n]
                        }
                        var o = function() {
                            function t(t) {
                                var e = new n.default(t);
                                this.inedges = new Int32Array(t.length / 2), this._hullIndex = new Int32Array(t.length / 2), this.points = e.coords, this._init(e)
                            }
                            var e = t.prototype;
                            return e._init = function(t) {
                                var e = t,
                                    r = this.points;
                                if (e.hull && e.hull.length > 2 && function(t) {
                                        for (var e = t.triangles, n = t.coords, r = 0; r < e.length; r += 3) {
                                            var i = 2 * e[r],
                                                a = 2 * e[r + 1],
                                                o = 2 * e[r + 2];
                                            if ((n[o] - n[i]) * (n[a + 1] - n[i + 1]) - (n[a] - n[i]) * (n[o + 1] - n[i + 1]) > 1e-10) return !1
                                        }
                                        return !0
                                    }(e)) {
                                    this.collinear = Int32Array.from({
                                        length: r.length / 2
                                    }, (function(t, e) {
                                        return e
                                    })).sort((function(t, e) {
                                        return r[2 * t] - r[2 * e] || r[2 * t + 1] - r[2 * e + 1]
                                    }));
                                    for (var i = this.collinear[0], o = this.collinear[this.collinear.length - 1], u = [r[2 * i], r[2 * i + 1], r[2 * o], r[2 * o + 1]], c = 1e-8 * Math.sqrt(Math.pow(u[3] - u[1], 2) + Math.pow(u[2] - u[0], 2)), l = 0, s = r.length / 2; l < s; ++l) {
                                        var f = a(r[2 * l], r[2 * l + 1], c);
                                        r[2 * l] = f[0], r[2 * l + 1] = f[1]
                                    }
                                    t = new n.default(r)
                                }
                                for (var h = this.halfedges = t.halfedges, d = this.hull = t.hull, p = this.triangles = t.triangles, y = this.inedges.fill(-1), v = this._hullIndex.fill(-1), b = 0, g = h.length; b < g; ++b) {
                                    var m = p[b % 3 == 2 ? b - 2 : b + 1]; - 1 !== h[b] && -1 !== y[m] || (y[m] = b)
                                }
                                for (var _ = 0, x = d.length; _ < x; ++_) v[d[_]] = _;
                                d.length <= 2 && d.length > 0 && (this.triangles = new Int32Array(3).fill(-1), this.halfedges = new Int32Array(3).fill(-1), this.triangles[0] = d[0], this.triangles[1] = d[1], this.triangles[2] = d[1], y[d[0]] = 1, 2 === d.length && (y[d[1]] = 0))
                            }, e.neighbors = function(t) {
                                var e = [],
                                    n = this.inedges,
                                    r = this.hull,
                                    i = this._hullIndex,
                                    a = this.halfedges,
                                    o = this.triangles,
                                    u = n[t];
                                if (-1 === u) return e;
                                var c = u,
                                    l = -1;
                                do {
                                    if (l = o[c], e.push(l), o[c = c % 3 == 2 ? c - 2 : c + 1] !== t) break;
                                    if (-1 === (c = a[c])) {
                                        var s = r[(i[t] + 1) % r.length];
                                        s !== l && e.push(s);
                                        break
                                    }
                                } while (c !== u);
                                return e
                            }, e.find = function(t, e, n) {
                                if (void 0 === n && (n = 0), (t = +t) != t || (e = +e) != e) return -1;
                                for (var r, i = n;
                                    (r = this._step(n, t, e)) >= 0 && r !== n && r !== i;) n = r;
                                return r
                            }, e._step = function(t, e, n) {
                                var r = this.inedges,
                                    i = this.points;
                                if (-1 === r[t] || !i.length) return (t + 1) % (i.length >> 1);
                                var a = t,
                                    o = Math.pow(e - i[2 * t], 2) + Math.pow(n - i[2 * t + 1], 2),
                                    u = this.neighbors(t),
                                    c = Array.isArray(u),
                                    l = 0;
                                for (u = c ? u : u[Symbol.iterator]();;) {
                                    var s;
                                    if (c) {
                                        if (l >= u.length) break;
                                        s = u[l++]
                                    } else {
                                        if ((l = u.next()).done) break;
                                        s = l.value
                                    }
                                    var f = s,
                                        h = Math.pow(e - i[2 * f], 2) + Math.pow(n - i[2 * f + 1], 2);
                                    h < o && (o = h, a = f)
                                }
                                return a
                            }, t
                        }();
                        t.default = o, o.from = function(t, e, n, a) {
                            return void 0 === e && (e = r), void 0 === n && (n = i), new o(function(t, e, n, r) {
                                for (var i = t.length, a = new Float64Array(2 * i), o = 0; o < i; ++o) {
                                    var u = t[o];
                                    a[2 * o] = e.call(r, u, o, t), a[2 * o + 1] = n.call(r, u, o, t)
                                }
                                return a
                            }(t, e, n, a))
                        }
                    }(tO);
                var nO = r(tO);

                function rO(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }
                var iO = {
                        withinBounds: function(t, e) {
                            var n = t.width,
                                r = t.height,
                                i = t.polar,
                                a = t.origin,
                                o = t.scale,
                                u = uf(t, "voronoiPadding"),
                                c = e.x,
                                l = e.y;
                            if (i) {
                                var s = Math.pow(c - a.x, 2) + Math.pow(l - a.y, 2),
                                    f = Math.max.apply(Math, rO(o.y.range()));
                                return s < Math.pow(f, 2)
                            }
                            return c >= u.left && c <= n - u.right && l >= u.top && l <= r - u.bottom
                        },
                        getDatasets: function(t) {
                            var e = {
                                    x: Fh(t.domain.x),
                                    y: Fh(t.domain.y)
                                },
                                r = n.Children.toArray(t.children),
                                i = function(n, r, i) {
                                    var a = i && i.type && i.type.continuous,
                                        o = i ? i.props && i.props.style : t.style;
                                    return n.map((function(n, i) {
                                        var u = af(n),
                                            c = u.x,
                                            l = u.y,
                                            s = u.y0,
                                            f = (+c + +u.x0) / 2,
                                            h = (+l + +s) / 2;
                                        return Sl({
                                            _voronoiX: "y" === t.voronoiDimension ? e.x : f,
                                            _voronoiY: "x" === t.voronoiDimension ? e.y : h,
                                            eventKey: i,
                                            childName: r,
                                            continuous: a,
                                            style: o
                                        }, n)
                                    }))
                                };
                            if (t.data) return i(t.data);
                            var a = function(t) {
                                var e = Cm(t);
                                return Array.isArray(e) && e.length > 0 ? e : void 0
                            };
                            return mf(r, (function(e, n) {
                                var r = (e.props || {}).name || n,
                                    o = t.voronoiBlacklist || [],
                                    u = o.filter(hp),
                                    c = o.filter(Wl).some((function(t) {
                                        return t.test(r)
                                    }));
                                if (!Im(e) || Op(u, r) || c) return null;
                                var l = (e.type && It(e.type.getData) ? e.type.getData : a)(e.props);
                                return l ? i(l, r, e) : null
                            }), t)
                        },
                        findPoints: function(t, e) {
                            return t.filter((function(t) {
                                return e._voronoiX === t._voronoiX && e._voronoiY === t._voronoiY
                            }))
                        },
                        withinRadius: function(t, e, n) {
                            if (!t) return !1;
                            if (!n) return !0;
                            var r = e.x,
                                i = e.y;
                            return Math.pow(r - t[0], 2) + Math.pow(i - t[1], 2) < Math.pow(n, 2)
                        },
                        getVoronoiPoints: function(t, e) {
                            var n = this.getDatasets(t),
                                r = n.map((function(e) {
                                    var n = of (t, e);
                                    return [n.x, n.y]
                                })),
                                i = nO.from(r).find(e.x, e.y);
                            return {
                                points: this.withinRadius(r[i], e, t.radius) ? this.findPoints(n, n[i]) : [],
                                index: i
                            }
                        },
                        getActiveMutations: function(t, e) {
                            var n = e.childName,
                                r = e.continuous,
                                i = t.activateData,
                                a = t.activateLabels,
                                o = t.labels;
                            if (!i && !a) return [];
                            var u = i ? ["data"] : [],
                                c = o && !a ? u : u.concat("labels");
                            return Rf(c) ? [] : c.map((function(t) {
                                var i = !0 === r && "data" === t ? "all" : e.eventKey;
                                return {
                                    childName: n,
                                    eventKey: i,
                                    target: t,
                                    mutation: function() {
                                        return {
                                            active: !0
                                        }
                                    }
                                }
                            }))
                        },
                        getInactiveMutations: function(t, e) {
                            var n = e.childName,
                                r = e.continuous,
                                i = t.activateData,
                                a = t.activateLabels,
                                o = t.labels;
                            if (!i && !a) return [];
                            var u = i ? ["data"] : [],
                                c = o && !a ? u : u.concat("labels");
                            return Rf(c) ? [] : c.map((function(t) {
                                var i = r && "data" === t ? "all" : e.eventKey;
                                return {
                                    childName: n,
                                    eventKey: i,
                                    target: t,
                                    mutation: function() {
                                        return null
                                    }
                                }
                            }))
                        },
                        getParentMutation: function(t, e, n, r) {
                            return [{
                                target: "parent",
                                eventKey: "parent",
                                mutation: function() {
                                    return {
                                        activePoints: t,
                                        mousePosition: e,
                                        parentSVG: n,
                                        vIndex: r
                                    }
                                }
                            }]
                        },
                        onActivated: function(t, e) {
                            It(t.onActivated) && t.onActivated(e, t)
                        },
                        onDeactivated: function(t, e) {
                            It(t.onDeactivated) && t.onDeactivated(e, t)
                        },
                        onMouseLeave: function(t, e) {
                            var n, r = this,
                                i = e.activePoints || [];
                            this.onDeactivated(e, i);
                            var a = i.length ? i.map((function(t) {
                                return r.getInactiveMutations(e, t)
                            })) : [];
                            return (n = this.getParentMutation([])).concat.apply(n, rO(a))
                        },
                        onMouseMove: function(t, e) {
                            var n = this,
                                r = e.activePoints || [],
                                i = e.parentSVG || u_(t),
                                a = function(t, e) {
                                    if (t.nativeEvent && void 0 !== t.nativeEvent.identifier) return {
                                        x: t.nativeEvent.locationX,
                                        y: t.nativeEvent.locationY
                                    };
                                    t = t.changedTouches && t.changedTouches.length ? t.changedTouches[0] : t;
                                    var n = function(t) {
                                        return t.getScreenCTM().inverse()
                                    }(e = e || u_(t));
                                    return {
                                        x: o_(t.clientX, n, "x"),
                                        y: o_(t.clientY, n, "y")
                                    }
                                }(t, i);
                            if (!this.withinBounds(e, a)) {
                                var o;
                                this.onDeactivated(e, r);
                                var u = r.length ? r.map((function(t) {
                                    return n.getInactiveMutations(e, t)
                                })) : [];
                                return (o = this.getParentMutation([], a, i)).concat.apply(o, rO(u))
                            }
                            var c = this.getVoronoiPoints(e, a),
                                l = c.points,
                                s = void 0 === l ? [] : l,
                                f = c.index,
                                h = this.getParentMutation(s, a, i, f);
                            if (r.length && bc(s, r)) return h;
                            this.onActivated(e, s), this.onDeactivated(e, r);
                            var d = s.length ? s.map((function(t) {
                                    return n.getActiveMutations(e, t)
                                })) : [],
                                p = r.length ? r.map((function(t) {
                                    return n.getInactiveMutations(e, t)
                                })) : [];
                            return h.concat.apply(h, rO(p).concat(rO(d)))
                        }
                    },
                    aO = {
                        onMouseLeave: iO.onMouseLeave.bind(iO),
                        onMouseMove: Bk(iO.onMouseMove.bind(iO), 32, {
                            leading: !0,
                            trailing: !1
                        })
                    };

                function oO(t) {
                    return function(t) {
                        if (Array.isArray(t)) {
                            for (var e = 0, n = new Array(t.length); e < t.length; e++) n[e] = t[e];
                            return n
                        }
                    }(t) || function(t) {
                        if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
                    }(t) || function() {
                        throw new TypeError("Invalid attempt to spread non-iterable instance")
                    }()
                }

                function uO(t) {
                    for (var e = 1; e < arguments.length; e++) {
                        var n = null != arguments[e] ? arguments[e] : {},
                            r = Object.keys(n);
                        "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                            return Object.getOwnPropertyDescriptor(n, t).enumerable
                        })))), r.forEach((function(e) {
                            cO(t, e, n[e])
                        }))
                    }
                    return t
                }

                function cO(t, e, n) {
                    return e in t ? Object.defineProperty(t, e, {
                        value: n,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : t[e] = n, t
                }

                function lO(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }

                function sO(t, e) {
                    for (var n = 0; n < e.length; n++) {
                        var r = e[n];
                        r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
                    }
                }

                function fO(t, e) {
                    return !e || "object" != typeof e && "function" != typeof e ? function(t) {
                        if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return t
                    }(t) : e
                }
                var hO, dO, pO = (dO = hO = function(t) {
                        function e() {
                            return lO(this, e), fO(this, (e.__proto__ || Object.getPrototypeOf(e)).apply(this, arguments))
                        }
                        var r, i, a;
                        return function(t, e) {
                            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                            t.prototype = Object.create(e && e.prototype, {
                                constructor: {
                                    value: t,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                        }(e, t), r = e, i = [{
                            key: "getDimension",
                            value: function(t) {
                                var e = t.horizontal,
                                    n = t.voronoiDimension;
                                return e && n ? "x" === n ? "y" : "x" : n
                            }
                        }, {
                            key: "getPoint",
                            value: function(t) {
                                return nf(t, ["_x", "_x1", "_x0", "_y", "_y1", "_y0"])
                            }
                        }, {
                            key: "getLabelPosition",
                            value: function(t, e, n) {
                                var r = t.mousePosition,
                                    i = t.mouseFollowTooltips,
                                    a = this.getDimension(t),
                                    o = of (t, this.getPoint(n[0])),
                                    u = i ? r : void 0;
                                if (!a || n.length < 2) return uO({}, o, {
                                    center: sl({}, e.center, u)
                                });
                                var c = "y" === a ? r.x : o.x,
                                    l = "x" === a ? r.y : o.y;
                                return u = i ? r : {
                                    x: c,
                                    y: l
                                }, {
                                    x: c,
                                    y: l,
                                    center: sl({}, e.center, u)
                                }
                            }
                        }, {
                            key: "getStyle",
                            value: function(t, e, n) {
                                var r = t.labels,
                                    i = t.labelComponent,
                                    a = t.theme,
                                    o = i.props || {},
                                    u = a && a.voronoi && a.voronoi.style ? a.voronoi.style : {},
                                    c = "flyout" === n ? o.flyoutStyle : o.style;
                                return e.reduce((function(t, e, i) {
                                    var a = sl({}, o, {
                                            datum: e,
                                            active: !0
                                        }),
                                        l = It(r) ? r(a) : void 0,
                                        s = void 0 !== l ? "".concat(l).split("\n") : [],
                                        f = e.style && e.style[n] || {},
                                        h = Array.isArray(c) ? c[i] : c,
                                        d = ff(sl({}, h, f, u[n]), a),
                                        p = s.length ? s.map((function() {
                                            return d
                                        })) : [d];
                                    return t = t.concat(p)
                                }), [])
                            }
                        }, {
                            key: "getDefaultLabelProps",
                            value: function(t, e) {
                                var n = t.voronoiDimension,
                                    r = t.horizontal,
                                    i = t.mouseFollowTooltips,
                                    a = this.getPoint(e[0]),
                                    o = n && e.length > 1,
                                    u = void 0 !== a._y1 ? a._y1 : a._y;
                                return {
                                    orientation: i ? void 0 : r ? u < 0 ? "left" : "right" : u < 0 ? "bottom" : "top",
                                    pointerLength: o ? 0 : void 0,
                                    constrainToVisibleArea: !(!o && !i) || void 0
                                }
                            }
                        }, {
                            key: "getLabelProps",
                            value: function(t, e) {
                                var n = t.labels,
                                    r = t.scale,
                                    i = t.labelComponent,
                                    a = t.theme,
                                    o = t.width,
                                    u = t.height,
                                    c = i.props || {},
                                    l = e.reduce((function(t, e) {
                                        var r = sl({}, c, {
                                                datum: e,
                                                active: !0
                                            }),
                                            i = It(n) ? n(r) : null;
                                        return null == i ? t : t = t.concat("".concat(i).split("\n"))
                                    }), []),
                                    s = e[0],
                                    f = s.childName,
                                    h = s.eventKey;
                                s.style, s.continuous;
                                var d = function(t, e) {
                                        if (null == t) return {};
                                        var n, r, i = {},
                                            a = Object.keys(t);
                                        for (r = 0; r < a.length; r++) n = a[r], e.indexOf(n) >= 0 || (i[n] = t[n]);
                                        if (Object.getOwnPropertySymbols) {
                                            var o = Object.getOwnPropertySymbols(t);
                                            for (r = 0; r < o.length; r++) n = o[r], e.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(t, n) && (i[n] = t[n])
                                        }
                                        return i
                                    }(s, ["childName", "eventKey", "style", "continuous"]),
                                    p = t.name === f ? f : "".concat(t.name, "-").concat(f),
                                    y = sl({
                                        key: "".concat(p, "-").concat(h, "-voronoi-tooltip"),
                                        id: "".concat(p, "-").concat(h, "-voronoi-tooltip"),
                                        active: !0,
                                        renderInPortal: !1,
                                        activePoints: e,
                                        datum: d,
                                        scale: r,
                                        theme: a
                                    }, c, {
                                        text: l,
                                        width: o,
                                        height: u,
                                        style: this.getStyle(t, e, "labels"),
                                        flyoutStyle: this.getStyle(t, e, "flyout")[0]
                                    }, this.getDefaultLabelProps(t, e)),
                                    v = this.getLabelPosition(t, y, e);
                                return sl({}, v, y)
                            }
                        }, {
                            key: "getTooltip",
                            value: function(t) {
                                var e = t.labels,
                                    r = t.activePoints,
                                    i = t.labelComponent;
                                if (!e) return null;
                                if (Array.isArray(r) && r.length) {
                                    var a = this.getLabelProps(t, r),
                                        o = a.text;
                                    return (Array.isArray(o) ? o.filter(Boolean).length : o) ? n.cloneElement(i, a) : null
                                }
                                return null
                            }
                        }, {
                            key: "getChildren",
                            value: function(t) {
                                return oO(n.Children.toArray(t.children)).concat([this.getTooltip(t)])
                            }
                        }], i && sO(r.prototype, i), a && sO(r, a), e
                    }(Pf), Object.defineProperty(hO, "displayName", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: "VictoryVoronoiContainer"
                    }), Object.defineProperty(hO, "propTypes", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: uO({}, Pf.propTypes, {
                            activateData: C.bool,
                            activateLabels: C.bool,
                            disable: C.bool,
                            labelComponent: C.element,
                            labels: C.func,
                            mouseFollowTooltips: C.bool,
                            onActivated: C.func,
                            onDeactivated: C.func,
                            radius: C.number,
                            voronoiBlacklist: C.arrayOf(C.oneOfType([C.string, Os])),
                            voronoiDimension: C.oneOf(["x", "y"]),
                            voronoiPadding: C.oneOfType([C.number, C.shape({
                                top: C.number,
                                bottom: C.number,
                                left: C.number,
                                right: C.number
                            })])
                        })
                    }), Object.defineProperty(hO, "defaultProps", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: uO({}, Pf.defaultProps, {
                            activateData: !0,
                            activateLabels: !0,
                            labelComponent: n.createElement(Jk, null),
                            voronoiPadding: 5
                        })
                    }), Object.defineProperty(hO, "defaultEvents", {
                        configurable: !0,
                        enumerable: !0,
                        writable: !0,
                        value: function(t) {
                            return [{
                                target: "parent",
                                eventHandlers: {
                                    onMouseLeave: function(e, n) {
                                        return t.disable ? {} : aO.onMouseLeave(e, n)
                                    },
                                    onTouchCancel: function(e, n) {
                                        return t.disable ? {} : aO.onMouseLeave(e, n)
                                    },
                                    onMouseMove: function(e, n) {
                                        return t.disable ? {} : aO.onMouseMove(e, n)
                                    },
                                    onTouchMove: function(e, n) {
                                        return t.disable ? {} : aO.onMouseMove(e, n)
                                    }
                                }
                            }, {
                                target: "data",
                                eventHandlers: t.disable ? {} : {
                                    onMouseOver: function() {
                                        return null
                                    },
                                    onMouseOut: function() {
                                        return null
                                    },
                                    onMouseMove: function() {
                                        return null
                                    }
                                }
                            }]
                        }
                    }), dO),
                    yO = i((function() {
                        const t = a(),
                            e = o.exports.useRef(null),
                            [n, r] = o.exports.useState(null);
                        return u("div", {
                            ref: e,
                            className: `${xO} m-item`,
                            children: [u("div", {
                                className: "title flex-center",
                                children: [c("span", {
                                    children: t("common.bet")
                                }), c("button", {
                                    className: "title-btn",
                                    onClick: l.clearData,
                                    children: c(s, {
                                        name: "Clear"
                                    })
                                })]
                            }), u("div", {
                                className: "chart-cont",
                                children: [u("div", {
                                    className: "item-wrap wagered",
                                    children: [c("div", {
                                        className: "item-label",
                                        children: t("common.wagered")
                                    }), c(f, {
                                        name: l.currencyName,
                                        amount: l.wagered,
                                        icon: !0,
                                        showName: !1
                                    })]
                                }), u("div", {
                                    className: "item-wrap profit",
                                    children: [c("div", {
                                        className: "item-label",
                                        children: t("common.profit")
                                    }), c(f, {
                                        className: l.profit >= 0 ? "cl-success" : "cl-require",
                                        name: l.currencyName,
                                        amount: l.profit,
                                        icon: !0,
                                        showName: !1
                                    })]
                                })]
                            }), u("div", {
                                className: "chart-wrap",
                                children: ["number" == typeof n && c("div", {
                                    className: "tooltip-wrap",
                                    children: c(f, {
                                        className: n >= 0 ? "cl-success" : "cl-require",
                                        name: l.currencyName,
                                        amount: n,
                                        icon: !0
                                    })
                                }), u(fk, {
                                    padding: {
                                        top: 20,
                                        left: 0,
                                        right: 0,
                                        bottom: 0
                                    },
                                    domainPadding: {
                                        x: 0,
                                        y: 5
                                    },
                                    animate: !0,
                                    data: function() {
                                        const t = l.profits,
                                            e = t.length,
                                            n = Math.max(1, Math.floor(e / 50)),
                                            r = 50 * n;
                                        return n > 1 ? t.slice(0, r).filter(((t, e, r) => e % n == 0 || e === r.length - 1)).concat(t.slice(r)) : t.filter(((t, r) => r % n == 0 || r === e - 1))
                                    }(),
                                    containerComponent: c(pO, {
                                        voronoiBlacklist: ["positive"],
                                        voronoiDimension: "x",
                                        labels: ({
                                            datum: t
                                        }) => `${t._y.toFixed(9)}`,
                                        onActivated: t => {
                                            l.profits.length > 1 && r(t[0]._y)
                                        },
                                        events: {
                                            onMouseOut: () => r(null)
                                        },
                                        labelComponent: c(vO, {})
                                    }),
                                    children: [c(Ck, {
                                        name: "positive",
                                        style: bO,
                                        interpolation: "catmullRom",
                                        groupComponent: c(id, {
                                            clipPathComponent: c(mO, {})
                                        })
                                    }), c(Ck, {
                                        name: "negative",
                                        style: gO,
                                        interpolation: "catmullRom",
                                        groupComponent: c(id, {
                                            clipPathComponent: c(_O, {})
                                        })
                                    })]
                                })]
                            }), u("div", {
                                className: "bet-wrap",
                                children: [u("div", {
                                    className: "bet-item win",
                                    children: [c("span", {
                                        className: "txt ttc",
                                        children: t("page.record.win").toLocaleLowerCase()
                                    }), c("span", {
                                        className: `num ${l.winNum>0&&"cl-success"}`,
                                        children: l.winNum
                                    })]
                                }), u("div", {
                                    className: "bet-item lose",
                                    children: [c("span", {
                                        className: "txt ttc",
                                        children: t("page.record.lose").toLocaleLowerCase()
                                    }), c("span", {
                                        className: `num ${l.lossNum<0&&"cl-require"}`,
                                        children: l.lossNum
                                    })]
                                })]
                            })]
                        })
                    }));
                const vO = function(t) {
                        const {
                            x: e,
                            y: n,
                            scale: r
                        } = t;
                        return u("g", {
                            children: [c("line", {
                                x1: e,
                                y1: n,
                                x2: e,
                                y2: r.y(0),
                                strokeDasharray: "5, 5",
                                stroke: "#f5f6fa"
                            }), c("circle", {
                                cx: e,
                                cy: n,
                                r: 6,
                                fill: "#f5f6fa"
                            })]
                        })
                    },
                    bO = {
                        data: {
                            stroke: "#5da000",
                            strokeWidth: 5,
                            fill: "#5da000",
                            fillOpacity: .7,
                            strokeLinecap: "round"
                        }
                    },
                    gO = {
                        data: {
                            stroke: "#ed6300",
                            strokeWidth: 5,
                            fill: "#ed6300",
                            fillOpacity: .7,
                            strokeLinecap: "round"
                        }
                    },
                    mO = t => c("defs", {
                        children: c("clipPath", {
                            id: t.clipId,
                            children: c("rect", {
                                x: "0",
                                y: "0",
                                width: "100%",
                                height: t.scale.y(0)
                            })
                        })
                    }),
                    _O = t => c("defs", {
                        children: c("clipPath", {
                            id: t.clipId,
                            children: c("rect", {
                                x: "0",
                                y: t.scale.y(0),
                                width: "100%",
                                height: "100%"
                            })
                        })
                    });
                h({
                    cl1: [d("#99a4b0", .6), d("#5f6975", .8)],
                    cl2: [d("#99a4b0", .6), d("#5f6975", .6)],
                    cl3: ["#f5f6f7", "#31373d"]
                });
                const xO = "l1n7fkd0";
                const wO = i((function({
                        percent: t
                    }) {
                        const e = p.isDarken;
                        return c("div", {
                            className: y(kO, "progress"),
                            children: u("div", {
                                className: "progress-cont",
                                style: {
                                    width: t + "%"
                                },
                                children: [c("img", {
                                    className: "bar",
                                    src: e ? v.progress_bar : v.progress_bar_w,
                                    alt: ""
                                }), c("img", {
                                    className: "coin",
                                    src: v.progress_coin,
                                    alt: ""
                                })]
                            })
                        })
                    })),
                    kO = "s1g8crrf";
                t("default", i((function() {
                    const t = a(),
                        [e, n] = o.exports.useState([{
                            label: t("common.bet"),
                            value: !0,
                            disabled: !p.isMobile
                        }, {
                            label: t("page.contest.title"),
                            value: !1,
                            disabled: !1
                        }, {
                            label: t("wallet.bcd.dialog.treasure"),
                            value: !1,
                            disabled: !1
                        }]);
                    return u(b, {
                        children: [c(OO, {
                            options: e,
                            setOptions: n
                        }), e[0].value && c(yO, {}), e[1].value && c(EO, {}), e[2].value && c(AO, {})]
                    })
                })));
                const OO = i((function({
                        options: t,
                        setOptions: e
                    }) {
                        const [n, r] = o.exports.useState(!0), i = g((() => {
                            r(!0)
                        })), a = {
                            from: {
                                y: -10,
                                opacity: 0
                            },
                            enter: {
                                y: 0,
                                opacity: 1
                            }
                        };
                        return u("div", {
                            className: SO,
                            ref: i,
                            children: [u("div", {
                                className: "trigger flex-center m-item " + (n ? "fold" : "unfold"),
                                onClick: () => r(!n),
                                children: [c("div", {
                                    className: "current",
                                    children: function() {
                                        let e = t.filter((t => t.value));
                                        if (e.length > 1) {
                                            return e.map((t => t.label)).join("/")
                                        }
                                        return e[0].label
                                    }()
                                }), c(s, {
                                    name: "Arrow"
                                })]
                            }), c(m, {
                                from: a.from,
                                enter: a.enter,
                                children: !n && c(_.div, {
                                    className: "options m-item",
                                    children: t.map(((n, i) => u("div", {
                                        className: "item " + (n.disabled ? "disabled" : ""),
                                        onClick: () => function(n, i) {
                                            const a = t[i];
                                            a.disabled || (p.isMobile ? (t.map(((t, e) => {
                                                t.disabled || (t.value = e === i)
                                            })), e([...t]), r(!0)) : (a.value = !n, e([...t])))
                                        }(n.value, i),
                                        children: [c("div", {
                                            className: "checkbox",
                                            children: n.value && c(s, {
                                                name: "Check"
                                            })
                                        }), c("div", {
                                            className: "item-value",
                                            children: n.label
                                        })]
                                    }, i)))
                                })
                            })]
                        })
                    })),
                    AO = i((function() {
                        const t = a(),
                            e = x(),
                            [n, r] = o.exports.useState(null),
                            i = new w(k.bonusAmount).div(k.bonusThreshold).mul(100).toFixed(2);
                        return o.exports.useEffect((() => {
                            k.init(!0).then((() => {
                                r({
                                    startTime: Date.now(),
                                    endTime: Date.now() + 6e4
                                })
                            }));
                            let t = setInterval((() => {
                                k.init(!0).then((() => {
                                    r({
                                        startTime: Date.now(),
                                        endTime: Date.now() + 6e4
                                    })
                                }))
                            }), 6e4);
                            return () => {
                                clearInterval(t)
                            }
                        }), []), u("div", {
                            className: `${PO} m-item`,
                            children: [c("div", {
                                className: "title",
                                children: t("wallet.bcd.dialog.treasure")
                            }), n && u("div", {
                                className: "countdown-box",
                                children: [u("div", {
                                    className: "coin-amount",
                                    children: [c(O, {
                                        name: "BCD"
                                    }), " ", Number(k.bonusAmount).toFixed(2)]
                                }), c(A, {
                                    endTime: n.endTime,
                                    startTime: n.startTime,
                                    className: "circle"
                                })]
                            }), c(wO, {
                                percent: i
                            }), k.canReceive ? u(b, {
                                children: [c("div", {
                                    className: "claim-tit",
                                    children: "Available to Claim"
                                }), c(E, {
                                    className: "claim-btn",
                                    onClick: k.claimBonus,
                                    type: "conic4",
                                    children: t("page.task.receive")
                                })]
                            }) : u("div", {
                                className: "claim-desc",
                                children: ["Minimum required  to claim:  ", c(O, {
                                    name: "BCD"
                                }), " ", k.bonusThreshold]
                            }), c(N, {
                                className: "bcd-status",
                                bonusAmount: k.bonusAmount,
                                bonusThreshold: k.bonusThreshold
                            }), u("div", {
                                className: "detail",
                                onClick: () => e("/bonus_dashboard"),
                                children: [c("span", {
                                    children: t("wallet.bcd.dialog.title")
                                }), c(s, {
                                    name: "Arrow"
                                })]
                            })]
                        })
                    })),
                    EO = i((function() {
                        const t = a();
                        o.exports.useEffect((() => {
                            S.loadByContestType(S.contestType);
                            let t = setInterval((() => {
                                S.loadByContestType(S.contestType)
                            }), 6e4);
                            return () => {
                                clearInterval(t)
                            }
                        }), []);
                        const e = S.supportType.map((t => ({
                                label: t,
                                value: i(MO)
                            }))),
                            n = e.findIndex((t => t.label === S.contestType));
                        return 0 == e.length ? null : u("div", {
                            className: `${jO} m-item`,
                            children: [c("div", {
                                className: "title",
                                children: t("page.contest.title")
                            }), c(M, {
                                className: "contest-tabs",
                                value: n,
                                tabs: e,
                                onChange: t => S.loadByContestType(e[t].label)
                            })]
                        })
                    }));

                function MO() {
                    const t = a(),
                        {
                            rank: e,
                            wager: n,
                            wagerCurrency: r,
                            userBonusRate: i,
                            activeList: o
                        } = S;
                    let l = 1;
                    l = 0 == e ? i.length : 1 == e ? 1 : e <= i.length ? e - 1 : i.length;
                    let s = 0,
                        h = null;
                    return o.length > l - 1 && (h = o[l - 1]), h && (s = h.wager - n), u(b, {
                        children: [u("div", {
                            className: "time_ranking",
                            children: [u("div", {
                                className: "item endtime",
                                children: [u("div", {
                                    className: "item-label",
                                    children: [S.contestType, " Contest end in"]
                                }), c(T, {
                                    endTime: S.endTime.getTime(),
                                    children: ({
                                        days: t,
                                        hours: e,
                                        minutes: n,
                                        seconds: r
                                    }) => u("div", {
                                        className: "countdown-wrap",
                                        children: [t > 0 && c("div", {
                                            className: "item",
                                            children: c("div", {
                                                className: "value",
                                                children: j(t)
                                            })
                                        }), c("div", {
                                            className: "item",
                                            children: c("div", {
                                                className: "value",
                                                children: j(e)
                                            })
                                        }), c("div", {
                                            className: "item",
                                            children: c("div", {
                                                className: "value",
                                                children: j(n)
                                            })
                                        }), t <= 0 && c("div", {
                                            className: "item",
                                            children: c("div", {
                                                className: "value",
                                                children: j(r)
                                            })
                                        })]
                                    })
                                })]
                            }), u("div", {
                                className: "item ranking",
                                children: [c("div", {
                                    className: "item-label",
                                    children: "Current Ranking"
                                }), c("div", {
                                    className: "item-value",
                                    children: TO(e)
                                })]
                            })]
                        }), c("div", {
                            className: "target-box",
                            children: u("div", {
                                className: "target flex-center",
                                children: [c("div", {
                                    className: "dot"
                                }), 1 !== e ? u(b, {
                                    children: [u("div", {
                                        children: ["Wager", " ", c(f, {
                                            name: r,
                                            amount: s,
                                            showName: !1
                                        }), " ", "more ", r, " to Reach"]
                                    }), u("div", {
                                        className: "spec",
                                        children: ["TOP", l]
                                    })]
                                }) : c("div", {
                                    children: "You are currently at 1st, well done!"
                                })]
                            })
                        }), u("div", {
                            className: "summary",
                            children: [u("div", {
                                className: "item wagered",
                                children: [c("div", {
                                    className: "item-label",
                                    children: t("common.wagered")
                                }), c(f, {
                                    name: r,
                                    amount: n,
                                    icon: !0,
                                    showName: !1
                                })]
                            }), u("div", {
                                className: "item prize",
                                children: [c("div", {
                                    className: "item-label",
                                    children: t("common.prize")
                                }), c(f, {
                                    name: r,
                                    amount: function() {
                                        if (o.length) {
                                            let t = o[e - 1];
                                            return t ? t.totalBonus : 0
                                        }
                                        return 0
                                    }(),
                                    icon: !0,
                                    showName: !1
                                })]
                            })]
                        })]
                    })
                }

                function TO(t) {
                    return 0 == t || t > 50 ? "50th+" : P(t)
                }
                h({
                    cl1: [d("#99a4b0", .6), d("#5f6975", .8)],
                    cl2: ["#f5f6f7", "#31373d"],
                    cl3: ["#353a43", "#dadde6"],
                    cl4: ["#f5f6f7", d("#31373d", .8)],
                    gd1: ["linear-gradient(to bottom, #1e2024 -31%, #353a43 100%)", "linear-gradient(to bottom, #5f6975 -78%, rgba(95, 105, 117, 0) 100%)"]
                });
                const jO = "l1nrtaq9";
                h({
                    cl1: ["#99a4b0", d("#5f6975", .8)],
                    cl2: ["#fff", "#31373d"],
                    cl3: ["#17181b", "#f5f6fa"],
                    cl4: ["#1e2024", "#fff"],
                    cl5: ["#fbcf12", "#fb9512"]
                });
                const PO = "lhadtgd";
                h({
                    cl1: ["#f5f6f7", "#31373d"],
                    cl2: [d("#f5f6f7", .6), d("#5f6975", .35)],
                    cl3: ["#1b1d21", "#fff"],
                    cl4: [d("#000000", .3), d("#000000", .2)],
                    cl5: [d("#99a4b0", .1), d("#5f6975", .1)],
                    cl6: [d("#99a4b0", .6), d("#5f6975", .14)],
                    cl7: [d("#2d3035", .4), "#f6f7fa"]
                });
                const SO = "lkl4y2n"
            }
        }
    }))
}();
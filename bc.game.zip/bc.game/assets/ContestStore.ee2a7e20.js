import {
    $ as i,
    cP as b,
    d as r,
    cp as u
} from "./index.28e31dff.js";
var w = (t => (t.DAILY = "daily", t.WEEKLY = "weekly", t.MONTHLY = "monthly", t))(w || {});
const p = {
        daily: "DAILY",
        weekly: "WEEKLY",
        monthly: "MONTHLY"
    },
    Y = {
        [p.daily]: "daily",
        [p.weekly]: "weekly",
        [p.monthly]: "monthly"
    },
    L = () => i.get("/activity/contest/infos/"),
    f = t => i.get(`/activity/contest/${t}/list/`),
    C = t => i.get(`/activity/contest/${t}/rank/`).then(e => ({
        wager: parseFloat(e.wager),
        rank: Number(e.rank)
    })),
    R = t => i.get(`/activity/contest/${t}/last/`);
var a = {
    api_info: L,
    api_list: f,
    api_rank: C,
    api_prev: R
};
class _ {
    constructor() {
        this.inited = new Promise(() => {}), this.contestType = w.DAILY, this.supportType = [], this.startTime = new Date, this.endTime = new Date, this.baseBonus = 0, this.userBonusRate = [], this.wagerCurrency = "BCD", this.totalBonusWagerRate = 0, this.participateCurrency = [], this.prizePoolChangeRate = 0, this.totalWager = 0, this.prizeAmount = 0, this.activeList = [], this.prevStartTime = new Date, this.prevEndTime = new Date, this.prevList = [], this.rank = 0, this.wager = 0, b(this), this.loadByContestType = this.loadByContestType.bind(this), r.login || r.waitLogin().then(this.loadMyRank.bind(this))
    }
    loadByContestType(e = this.contestType) {
        return this.contestType = e, this.inited = this.init(), r.login && this.loadMyRank(), this.inited
    }
    async init() {
        let [e, n, s] = await Promise.all([a.api_info(), a.api_list(this.contestType), a.api_prev(this.contestType)]);
        const c = e.find(o => o.contestType == this.contestType);
        if (c) {
            const {
                startTime: o,
                endTime: d,
                baseBonus: h,
                userBonusRate: g,
                wagerCurrency: m,
                totalBonusWagerRate: l,
                totalWager: y,
                participateCurrency: v,
                prizePoolChangeRate: k
            } = c, B = h + l * y;
            u(() => {
                Object.assign(this, {
                    startTime: new Date(o),
                    endTime: new Date(d),
                    baseBonus: h,
                    userBonusRate: g,
                    wagerCurrency: m,
                    totalBonusWagerRate: l,
                    totalWager: y,
                    participateCurrency: v,
                    prizeAmount: B,
                    prizePoolChangeRate: k,
                    prevStartTime: new Date(s ? s.startTime : 0),
                    prevEndTime: new Date(s ? s.endTime : 0)
                }), this.supportType = e.map(D => D.contestType), this.activeList = n.map(T), this.prevList = s ? s.players.map(T) : []
            })
        }
    }
    async loadMyRank() {
        let {
            rank: e,
            wager: n
        } = await a.api_rank(this.contestType);
        u(() => {
            this.rank = e, this.wager = n
        })
    }
}
const T = t => (t.totalBonus = parseFloat(t.totalBonus), t.basicBonus = parseFloat(t.basicBonus), t.bonusRate = parseFloat(t.bonusRate), t.wager = parseFloat(t.wager), t),
    A = new _;
window.cs = A;
export {
    w as C, Y as T, A as c
};
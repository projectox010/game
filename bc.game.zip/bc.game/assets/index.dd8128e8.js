import {
    e1 as e,
    e2 as a,
    e3 as l,
    e4 as s,
    e5 as t,
    e6 as i
} from "./index.28e31dff.js";
const g = {
    MyBet: e,
    AllBet: a,
    GameValidate: l,
    HashTable: s,
    useSingleDetail: t,
    withSingleDetail: i
};
export {
    g as s
};
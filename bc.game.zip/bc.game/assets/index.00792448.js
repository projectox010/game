import {
    fa as L,
    p as v,
    a as e,
    bg as B,
    u as h,
    j as r,
    l as E,
    a4 as F,
    bn as D,
    b as p,
    d as _,
    A as u,
    al as M,
    o as q,
    t as R,
    q as U,
    ao as $,
    r as k,
    a3 as Y,
    s as S,
    cC as C,
    m as A,
    fb as m,
    ca as x,
    $ as j,
    be as G,
    fc as V,
    fd as Q,
    am as T,
    Y as b,
    an as W
} from "./index.28e31dff.js";
var re = L((n, t = !0) => v.push(e(B, {
    closeable: t,
    className: O,
    children: e(z, {
        state: n,
        isPop: !0
    })
}), {
    closeable: !1
}));

function z({
    state: n = "your region",
    isPop: t = !1
}) {
    const a = h();
    return r("div", {
        className: E(H, t ? "" : "s-p"),
        children: [e(F, {
            type: "ban"
        }), e("h2", {
            children: a("page.setting.block_title", D.host)
        }), e("p", {
            className: "desc",
            children: a("page.setting.block_desc", n, "support@bc.game")
        }), r("div", {
            className: "actions",
            children: [e(p, {
                onClick: () => _.emit("openLiveSupport"),
                children: e(u, {
                    name: "Support"
                })
            }), e(p, {
                onClick: () => window.open("mailto:support@bc.game"),
                children: e(u, {
                    name: "Mail"
                })
            })]
        }), e("div", {
            className: "privacy",
            children: e(M, {
                to: "/help_privacy",
                children: a("title.help_privacy")
            })
        })]
    })
}
const O = "p1uxjvi2",
    H = "bjndpye";
var ie = q(function() {
    const n = h(),
        [t, a] = $({
            message: [],
            endTime: 0,
            loading: !0
        }),
        o = async i => {
            try {
                await j.get("/user/get/"), window.location.reload()
            } catch (l) {
                a(i ? {
                    endTime: l.response.data.endTime || 0,
                    loading: !1
                } : {
                    endTime: l.response.data.endTime || 0
                })
            }
        };
    k.exports.useEffect(() => {
        o(!0);
        const i = setInterval(() => {
            o()
        }, 6e4);
        return () => {
            clearInterval(i)
        }
    }, []);
    const c = i => i < 10 ? "0" + i : i;
    return t.loading ? e("div", {
        className: J,
        children: e(Y, {})
    }) : e("div", {
        className: X,
        children: r("div", {
            className: "main-area",
            children: [e("img", {
                className: "logo",
                alt: "logo",
                src: S.isDarken ? C.logo : C.logo_w
            }), e("p", {
                className: "title",
                children: "The time has finally arrived\u2026\u2026"
            }), e(A, {
                endTime: t.endTime,
                onEnd: o,
                children: ({
                    hours: i,
                    minutes: l,
                    seconds: d
                }) => r("p", {
                    className: "common",
                    children: ["BC 3.0 launching in", " ", r("span", {
                        children: [c(i), ":", c(l), ":", c(d)]
                    }), "."]
                })
            }), e("p", {
                className: "common",
                children: "Are you ready?\u{1F680}"
            }), e("p", {
                className: "common",
                children: "See you on the new BC.GAME! "
            }), r("button", {
                className: "contact",
                onClick: () => _.emit("openLiveSupport"),
                children: [e(u, {
                    name: "Support"
                }), e("span", {
                    children: n("common.Live_supports")
                })]
            }), r("div", {
                className: "icon-wrap",
                children: [e("a", {
                    href: "https://github.com/bcgame-project",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: e("img", {
                        src: m.Github,
                        alt: ""
                    })
                }), e("a", {
                    href: "https://twitter.com/BCGameOfficial",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: e("img", {
                        src: m.Twitter,
                        alt: ""
                    })
                }), e("a", {
                    href: "https://www.facebook.com/bcgameofficial",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: e("img", {
                        src: m.Facebook,
                        alt: ""
                    })
                }), e("a", {
                    href: "https://discord.gg/bcgame",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: e("img", {
                        src: m.Discord,
                        alt: ""
                    })
                }), e("a", {
                    href: "https://bitcointalk.org/index.php?topic=5088875.0",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    children: e("img", {
                        src: m.Btc,
                        alt: ""
                    })
                })]
            }), e("img", {
                className: "update",
                alt: "update",
                src: S.isDarken ? x.update : x.update_w
            })]
        })
    })
});
const J = "u5og2e1";
R({
    cl1: ["#24262b", "#f5f6f7"],
    cl2: ["#31343c", U("#d0d6d9", .5)],
    cl3: ["#ffffff", "#17181b"],
    cl4: ["#2e3036", "#e9eaf2"]
});
const X = "u1p29tmj";

function oe() {
    const n = h();
    return e("div", {
        className: Z,
        children: r("div", {
            className: "box",
            children: [e("img", {
                src: G.init_wrong
            }), e("div", {
                className: "msg",
                children: n("common.messages.went_wrong")
            }), r("div", {
                className: "btns",
                children: [r(p, {
                    onClick: () => _.emit("openLiveSupport"),
                    type: "gray",
                    children: [e(u, {
                        name: "Support"
                    }), e("span", {
                        children: n("common.Live_supports")
                    })]
                }), e(p, {
                    onClick: () => window.location.reload(),
                    type: "conic",
                    children: n("common.refresh_now")
                })]
            })]
        })
    })
}
const Z = "i1shhvbx";
var ce = L(() => V.add(() => v.push(e(ae, {
    onSuccess: () => v.back()
}), {
    closeable: !1,
    path: "/kyc_pop"
}), {
    key: Q.SET_KYC
}));
const y = new Date,
    ee = P(y.getFullYear(), y.getMonth() + 1, y.getDate());

function ae({
    onSuccess: n
}) {
    const t = h(),
        [a, o] = $({
            submitNum: 0,
            firstName: "",
            lastName: "",
            year: 2e3,
            day: 1,
            month: 1
        }),
        c = k.exports.useRef(a);
    c.current = a;
    const i = P(a.year, a.month, a.day),
        l = ee - i < 18e4,
        d = a.year == 0 || l || a.firstName == "" || a.lastName == "",
        K = async () => {
            if (!d) await j.post("/user/kyc/save/", {
                birthday: i,
                firstName: a.firstName,
                lastName: a.lastName
            }), n();
            else if (a.submitNum === 0) return o({
                submitNum: a.submitNum + 1
            })
        },
        g = [s => {
            const {
                submitNum: f
            } = c.current;
            if (f === 0) return null;
            if (s === "") return "Required";
            if (l) return t("page.settings.year18")
        }],
        w = k.exports.useMemo(() => [s => {
            const {
                submitNum: f
            } = c.current;
            if (f === 0) return null;
            if (s === "") return "Required"
        }], [a.submitNum]);
    return r(B, {
        className: te,
        title: t("page.setting.kyc_title"),
        closeable: !1,
        children: [e("p", {
            children: t("page.setting.kyc_tips", D.siteName)
        }), r(I, {
            label: t("page.setting.your_name"),
            children: [e(T, {
                placeholder: t("page.setting.last_name"),
                value: a.lastName,
                validates: w,
                onChange: s => o({
                    lastName: s
                })
            }), e(T, {
                placeholder: t("page.setting.first_name"),
                value: a.firstName,
                validates: w,
                onChange: s => o({
                    firstName: s
                })
            })]
        }), r(I, {
            className: "birth-input",
            label: t("page.setting.date_of_birth"),
            children: [e(b, {
                placeholder: t("page.setting.date_day"),
                value: a.day,
                validates: g,
                formatter: N,
                onChange: s => o({
                    day: s
                }),
                min: 1,
                max: 31
            }), e(b, {
                placeholder: t("page.setting.date_month"),
                value: a.month,
                validates: g,
                formatter: N,
                onChange: s => o({
                    month: s
                }),
                min: 1,
                max: 12
            }), e(b, {
                placeholder: t("page.setting.date_year"),
                value: a.year,
                validates: g,
                formatter: N,
                onChange: s => o({
                    year: s
                }),
                min: a.year > 0 ? 1900 : 0,
                max: new Date().getFullYear()
            })]
        }), e(p, {
            disabled: a.submitNum > 0 && d,
            className: "submit-btn",
            type: "conic",
            onClick: K,
            children: t("common.actions.confirm")
        })]
    })
}

function P(n, t, a) {
    return Number(`${n}${t<10?"0":""}${t}${a<10?"0":""}${a}`)
}

function N(n) {
    return n === 0 ? "" : String(n)
}
const I = ({
        label: n,
        children: t,
        className: a
    }) => e(W, {
        className: E(a, ne),
        label: n,
        after: t
    }),
    te = "ppi1ry5",
    ne = "imw2g2y";
export {
    z as BlockPage, oe as InitError, ie as Updating, re as showBlock, ce as showKyc
};
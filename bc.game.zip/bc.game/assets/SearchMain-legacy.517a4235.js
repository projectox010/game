! function() {
    var e = document.createElement("style");
    e.innerHTML = ".h1ivtg2n{--1724xtk:#000;--1ujkooj:rgba(95,105,117,.59);--ybdudv:rgb(95,105,117)}.darken .h1ivtg2n{--1724xtk:#e5e9ed;--1ujkooj:#6a717b;--ybdudv:#f5f6f7}.h1ivtg2n .history-top{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;padding:0 .5rem;margin-bottom:1.5rem}.h1ivtg2n .history-top p{font-size:.9375rem;color:var(--1724xtk);font-weight:700;margin:0}.h1ivtg2n .history-top .icon{fill:var(--1ujkooj);cursor:pointer;width:1.5rem;height:1.5rem}.h1ivtg2n .history-top .icon:hover{fill:var(--ybdudv)}.h1ivtg2n .history-list-wrap{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;height:2.25rem;overflow:hidden}.h1ivtg2n .history-list-wrap .no{font-weight:700;color:#e5e9ed;text-align:center;width:100%}.h1n7lk5i{--15er5b9:rgb(246,247,250);--1jy8ut5:rgba(152,167,181,.69);--1u2wd97:rgba(152,167,181,.59);--tq8d8c:rgba(95,105,117,.59);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;height:2.25rem;padding:0 .5rem 0 1rem;background-color:var(--15er5b9);border-radius:1.125rem;-webkit-transition:width .5s;transition:width .5s;cursor:pointer;margin-right:.625rem}.darken .h1n7lk5i{--15er5b9:rgba(0,0,0,.3);--1jy8ut5:#e5e9ed;--1u2wd97:#41454e;--tq8d8c:#1c1e22}.h1n7lk5i p{font-size:1rem;line-height:1rem;color:var(--1jy8ut5);margin:0;margin-right:1rem}.h1n7lk5i button{width:1.25rem;height:1.25rem;border-radius:50%;background-color:var(--1u2wd97);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;cursor:pointer;display:none}.h1n7lk5i button .icon{fill:var(--tq8d8c);width:.75rem;height:.75rem;margin-top:.125rem}@media screen and (max-width:621px){.h1n7lk5i button{display:block}}.h1n7lk5i:hover button{display:block}.rftkjoj{--g52yms:#000;--ng93ma:rgba(233,234,242,.6);--1o9sbnx:rgb(246,247,250);--pqids4:rgba(152,167,181,.7);overflow:hidden;height:10rem;color:var(--g52yms)}.darken .rftkjoj{--g52yms:#fff;--ng93ma:rgba(0,0,0,.4);--1o9sbnx:rgba(0,0,0,.4);--pqids4:#fff}.rftkjoj .result-top{width:7.625rem;height:7.625rem;border-radius:1.25rem;overflow:hidden;background-color:var(--ng93ma);cursor:pointer}.rftkjoj .result-top img{width:100%;height:100%}.rftkjoj .result-bottom{margin-top:.5rem;padding-left:.625rem}.rftkjoj .result-bottom p{margin:0;line-height:.875rem;height:.875rem;font-weight:700;font-size:.75rem;width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.rftkjoj .result-bottom .result-rtp{margin-top:.125rem}.rftkjoj .result-bottom .result-rtp span{color:#5ddb1c;padding-left:.25rem}.rftkjoj .result-bottom .more{display:none}.rftkjoj.result-loading .result-bottom{padding:0 .625rem}.rftkjoj.result-loading .result-bottom p{background-color:var(--1o9sbnx)}.rftkjoj.result-loading .result-bottom .more span{width:100%;margin-left:0}@media screen and (min-width:1401px){.rftkjoj{width:15.25rem;height:7.625rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.rftkjoj .result-bottom{margin-top:0;width:7.625rem;padding-left:.875rem}.rftkjoj .result-bottom .more{display:block;font-size:.75rem;font-weight:700}.rftkjoj .result-bottom .more span{height:1.375rem;border-radius:.75rem;background-color:var(--1o9sbnx);color:var(--pqids4);padding:0 .5rem;display:inline-block;line-height:1.375rem;margin-left:-.375rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.rftkjoj .result-bottom .more-one{margin-top:1rem}.rftkjoj .result-bottom .more-two{margin-top:.375rem}}.r1mhbogg{--1724xtk:#000;--1jy8ut5:rgba(152,167,181,.69);overflow:hidden}.darken .r1mhbogg{--1724xtk:#e5e9ed;--1jy8ut5:#e5e9ed}.r1mhbogg .result-title{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;margin-bottom:1.5rem;width:100%}.r1mhbogg .result-title p{margin:0;color:var(--1724xtk);font-size:.9375rem;line-height:1.25rem}.r1mhbogg .result-title p span{color:#5ddb1c;padding:0 .25rem}.r1mhbogg .result-title .title{font-weight:700}.r1mhbogg .no-result p{font-weight:700;text-align:center;color:var(--1jy8ut5)}.r1mhbogg .result-list-wrap{display:grid;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;grid-template-columns:repeat(auto-fill,15.25rem);grid-gap:.75rem;height:22.5rem}.r1mhbogg .result-list-wrap .result-item{margin-bottom:1.25rem}@media screen and (max-width:1400px){.r1mhbogg .result-list-wrap{grid-template-columns:repeat(auto-fill,7.625rem)}.r1mhbogg .result-list-wrap .result-item{margin-bottom:.75rem}}.s1it4miu{--1724xtk:#000;--1ejo1vu:rgba(152,167,181,.69)}.darken .s1it4miu{--1724xtk:#e5e9ed;--1ejo1vu:#98a7b5}.s1it4miu .recommend-wrap{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;margin:4rem 0 1rem;padding-right:4px}.s1it4miu .recommend-title{margin:0;color:var(--1724xtk);font-size:.9375rem;line-height:1.25rem;font-weight:700;padding-left:.5rem}.s1it4miu .require-wrod{margin:0;margin-bottom:1rem;font-size:12px;color:var(--1ejo1vu);line-height:1.125rem;text-align:center}.s1it4miu .slider-wrap-tit{display:none}@media screen and (max-width:621px){.s1it4miu .recommend-wrap{padding-right:0}.s1it4miu .require-wrod{margin:.5rem 0 .875rem}}\n", document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js"], (function(e) {
        "use strict";
        var t, i, r, n, o, l, a, s, m, c, d, g, h, p, u, b, f, w;
        return {
            setters: [function(e) {
                t = e.a5, i = e.r, r = e.j, n = e.a, o = e.A, l = e.fk, a = e.d, s = e.$, m = e.fl, c = e.G, d = e.e, g = e.l, h = e.F, p = e.fm, u = e.S, b = e.bZ, f = e.bQ, w = e.bK
            }],
            execute: function() {
                const k = () => {
                        const e = window.localStorage.getItem("game-search-list");
                        return e ? e.split("**") : []
                    },
                    x = t.memo((function() {
                        const [e, t] = i.exports.useState(k());
                        if (!e || k.length < 0) return null;
                        return 0 === e.length ? null : r("div", {
                            className: j,
                            children: [r("div", {
                                className: "history-top",
                                children: [n("p", {
                                    children: "Search History"
                                }), e.length > 0 && n(o, {
                                    name: "Delete",
                                    onClick: () => {
                                        t([]), window.localStorage.setItem("game-search-list", "")
                                    }
                                })]
                            }), n("div", {
                                className: "history-list-wrap",
                                children: e.length > 0 ? e.map(((i, r) => n(y, {
                                    onDelete: () => {
                                        (i => {
                                            const r = [...e];
                                            r.splice(i, 1), t(r), window.localStorage.setItem("game-search-list", r.join("**"))
                                        })(r)
                                    },
                                    name: i
                                }, r))) : n("p", {
                                    className: "no",
                                    children: "No Search history."
                                })
                            })]
                        })
                    })),
                    y = t.memo((function({
                        name: e,
                        onDelete: t
                    }) {
                        const {
                            isSearching: i,
                            changeInputText: d,
                            changeIsSearching: g,
                            changeSearchResult: h,
                            changePageInfo: p
                        } = l();
                        return r("div", {
                            className: v,
                            onClick: () => {
                                d(e), (async e => {
                                    await a.inited, i || (g(!0), s.post("/home/search/game/", {
                                        keyword: e,
                                        page: 1,
                                        pageSize: 100,
                                        areaCode: a.areaCode
                                    }).then((t => {
                                        t && (h(t.list || []), g(!1), p({
                                            page: t.page,
                                            total: t.total
                                        }), t.list && t.list.length > 0 && m(e))
                                    })).catch(c))
                                })(e)
                            },
                            children: [n("p", {
                                children: e
                            }), n("button", {
                                onClick: e => {
                                    e.stopPropagation(), t()
                                },
                                children: n(o, {
                                    name: "Close"
                                })
                            })]
                        })
                    })),
                    j = "h1ivtg2n",
                    v = "h1n7lk5i";
                const N = t.memo((function({
                        resultItem: e,
                        isLoading: t,
                        closeFn: i
                    }) {
                        const o = d(),
                            l = e.thumbnail.indexOf("http") >= 0 ? e.thumbnail : `http://img2.supersell.com${e.thumbnail}`;
                        return r("div", {
                            className: g(S, "result-item", t && "result-loading"),
                            children: [n("div", {
                                className: "result-top",
                                onClick: () => {
                                    i(), a.emit("game_click", "game_search"), o(e.gameUrl)
                                },
                                children: !t && n("img", {
                                    alt: "logo",
                                    src: l
                                })
                            }), r("div", {
                                className: "result-bottom",
                                children: [n("p", {
                                    children: e.fullName
                                }), n("p", {
                                    className: "result-rtp",
                                    children: t ? "" : r(h, {
                                        children: ["RTP:", r("span", {
                                            children: [e.rtpDes, "%"]
                                        })]
                                    })
                                }), n("div", {
                                    className: "more more-one",
                                    children: n("span", {
                                        children: e.categoryName
                                    })
                                }), n("div", {
                                    className: "more more-two",
                                    children: n("span", {
                                        children: e.providerName
                                    })
                                })]
                            })]
                        })
                    })),
                    S = "rftkjoj";
                const C = t.memo((function({
                        closeFn: e
                    }) {
                        const {
                            isSearching: t,
                            searchResult: i,
                            pageInfo: o
                        } = l(), a = t ? Array(20).fill(p) : i;
                        return !t && (o.page, o.total), r("div", {
                            className: q,
                            children: [r("div", {
                                className: "result-title",
                                children: [n("p", {
                                    className: "title",
                                    children: "Search Result"
                                }), !t && i.length > 0 && r("p", {
                                    children: ["About", n("span", {
                                        children: o.total > 99 ? "99+" : o.total
                                    }), "results"]
                                })]
                            }), 0 !== i.length || t ? n(u, {
                                className: "result-list-wrap hidden-scroll-y",
                                children: a.map(((i, r) => n(N, {
                                    closeFn: e,
                                    resultItem: i,
                                    isLoading: t
                                }, r)))
                            }) : n("div", {
                                className: "no-result",
                                children: n("p", {
                                    children: "No results found."
                                })
                            })]
                        })
                    })),
                    q = "r1mhbogg",
                    I = [{
                        width: 1716,
                        num: 8
                    }, {
                        width: 1396,
                        num: 7
                    }, {
                        width: 1076,
                        num: 6
                    }, {
                        width: 900,
                        num: 5
                    }, {
                        width: 724,
                        num: 4
                    }, {
                        width: f,
                        num: 3
                    }, {
                        width: f,
                        num: 2
                    }],
                    z = t.memo((function({
                        closeFn: e
                    }) {
                        const {
                            recommendList: t,
                            changeRecommendList: r
                        } = l();
                        i.exports.useEffect((() => {
                            const e = "/home/statistic/search-recommended/" + (a.areaCode || "UNKNOWN") + "/";
                            s.get(e, {
                                cache: !0
                            }).then((e => {
                                r(e || [])
                            })).catch(console.log)
                        }), []);
                        const o = t.length > 0 ? t : void 0;
                        return n(b, {
                            list: o,
                            isSlots: !0,
                            sliderClassName: "search-recommend",
                            clickSource: "game_search_recommend",
                            sreenOpt: I,
                            onClick: e
                        })
                    }));
                e("default", t.memo((function({
                    closeFn: e
                }) {
                    const {
                        inputText: t,
                        isSearching: i
                    } = l(), o = t.length > 2 || i;
                    return r("div", {
                        className: `search-main ${F}`,
                        children: [t.length < 3 && n("p", {
                            className: "require-wrod",
                            children: "Search requires at Least 3 Characters"
                        }), o ? n(C, {
                            closeFn: e
                        }) : n(x, {}), r("div", {
                            className: "recommend-wrap",
                            children: [n("p", {
                                className: "recommend-title",
                                children: "Recommended for you"
                            }), n(w, {
                                name: "search-recommend"
                            })]
                        }), n(z, {
                            closeFn: e
                        })]
                    })
                })));
                const F = "s1it4miu"
            }
        }
    }))
}();
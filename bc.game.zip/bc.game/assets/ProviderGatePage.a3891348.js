import {
    a2 as s,
    bo as o,
    a as t
} from "./index.28e31dff.js";
import {
    F as e
} from "./AggregateList.fd1a9818.js";

function u() {
    const r = s(),
        a = o(r);
    return t(e, {
        tagName: a[0],
        subTagName: a[1] ? a[1] : void 0,
        isprovider: !0
    })
}
export {
    u as
    default
};
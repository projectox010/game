var re = Object.defineProperty,
    ue = Object.defineProperties;
var de = Object.getOwnPropertyDescriptors;
var L = Object.getOwnPropertySymbols;
var ce = Object.prototype.hasOwnProperty,
    he = Object.prototype.propertyIsEnumerable;
var Y = (n, s, e) => s in n ? re(n, s, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : n[s] = e,
    W = (n, s) => {
        for (var e in s || (s = {})) ce.call(s, e) && Y(n, e, s[e]);
        if (L)
            for (var e of L(s)) he.call(s, e) && Y(n, e, s[e]);
        return n
    },
    P = (n, s) => ue(n, de(s));
var p = (n, s, e) => (Y(n, typeof s != "symbol" ? s + "" : s, e), e);
import {
    a5 as T,
    a as i,
    dx as ne,
    j as d,
    dy as me,
    dz as fe,
    o as x,
    du as S,
    ek as ge,
    l as v,
    r as m,
    s as I,
    eg as Z,
    di as pe,
    aH as be,
    F as ie,
    dj as Ae,
    dk as ve,
    dl as ye,
    u as D,
    b as H,
    am as C,
    ea as J,
    G as ae,
    e9 as Ne,
    dG as we,
    ed as ke,
    dY as Ie,
    dC as Be,
    dZ as Ge,
    dD as Se,
    dE as Me,
    dp as V,
    bN as R,
    d_ as Ce,
    y as b,
    ba as xe,
    bb as w,
    bc as O,
    d as q,
    dR as Ee,
    b0 as He,
    J as _,
    e0 as Ve,
    n as Re,
    a2 as Oe,
    bo as je,
    dH as U,
    cJ as Te,
    D as De,
    x as Xe,
    S as Fe,
    t as Ye,
    q as z
} from "./index.28e31dff.js";
import {
    s as j
} from "./index.dd8128e8.js";
import {
    G as A
} from "./index.06a59a68.js";
import {
    i as K
} from "./isNumber.3847f240.js";
import {
    h as We
} from "./enc-hex.afd532ef.js";
import {
    u as Qe
} from "./useLocalStore.f739c306.js";
const Ue = T.memo(({
        game: n
    }) => i(ne, {
        children: d("div", {
            className: "item",
            children: [i("h2", {
                children: "What Is Mines?"
            }), i("div", {
                className: "content",
                children: n.gameInfo.detail.split(`
`).map((s, e) => i("p", {
                    children: `${s}`
                }, e.toString()))
            }), i("h2", {
                children: "How to Play Mines?"
            }), d("div", {
                className: "content",
                children: [i("p", {
                    children: "1. Select the number of mines you wish to place for the round. "
                }), i("p", {
                    children: "2. Press BET button to start the round. "
                }), i("p", {
                    children: "3. Each gem revealed will increase the payout multiplier."
                }), i("p", {
                    children: "4. Cash out any point to win at the last multiplier displayed."
                }), i("p", {
                    children: "5. If a mine is revealed, the game is ended and your wager is lost."
                }), i("p", {
                    children: "6. You may set more mines to increase multipliers on each gem revealed."
                })]
            }), i("h2", {
                children: "What is the House Edge of Mines?"
            }), i("div", {
                className: "content",
                children: i("p", {
                    children: "1% HouseEdge."
                })
            })]
        })
    })),
    Le = T.memo(({
        game: n
    }) => i(me, {
        game: n,
        children: d("div", {
            className: "item",
            children: [i("h2", {
                children: "What is the bankroll?"
            }), d("div", {
                className: "help-content",
                children: [i("p", {
                    children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                }), i("p", {
                    children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                }), i("p", {
                    children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                }), i("p", {
                    onClick: () => fe(n),
                    className: "cl-primary",
                    children: "Read more about bankrollers."
                })]
            }), i("h2", {
                children: "How does the pool of funds operate?"
            }), d("div", {
                className: "help-content",
                children: [i("p", {
                    children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                }), d("p", {
                    children: [i("b", {
                        className: "cl-primary",
                        children: "The house edge is 1%."
                    }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                }), i("p", {
                    children: "Payouts made to the winning players will be deducted from the bankroll."
                })]
            }), i("h2", {
                children: "How does leverage investment work?"
            }), d("div", {
                className: "help-content",
                children: [i("p", {
                    children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                }), i("p", {
                    children: "Hint: You can also use this feature as an Off-Site investment."
                }), i("p", {
                    children: "Let's make an example:"
                }), i("p", {
                    children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                })]
            }), i("h2", {
                children: "What is the bankroller dilution fee?"
            }), d("div", {
                className: "help-content",
                children: [i("p", {
                    children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                }), i("p", {
                    children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                }), i("p", {
                    children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                }), i("p", {
                    children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                })]
            })]
        })
    }));
var Pe = Le;
const Ze = T.memo(function({
        radius: s = "0",
        duration: e = 2e3,
        count: t = 0
    }) {
        return i("div", {
            className: Je,
            style: {
                borderRadius: s
            },
            children: i("div", {
                className: "sp-before",
                style: {
                    animation: `lightMove ${e+"ms"} ease ${t>0?t:"infinite"}`
                }
            })
        })
    }),
    Je = "e1w7b7ns";

function qe({
    index: n
}) {
    var h;
    const s = S(),
        e = ((h = s.guessQueue.find(u => u.index === n)) == null ? void 0 : h.status) === oe.PENDING,
        t = s.rounds.find(u => u.field === n + 1),
        o = ge(({
            hovering: u
        }) => {
            u && s.isBetting && !s.isAutoMode && (s.sounds.stopSound("hover"), s.sounds.playSound("hover")), u && s.isAutoMode && !s.isBetting && (s.sounds.stopSound("hover"), s.sounds.playSound("hover"))
        });

    function a() {
        return t && t.status === k.GEMS ? i(ze, {}) : t && t.status === k.MINES ? i(Ke, {}) : t && t.status === k.HIDE_GEMS ? i("div", {
            className: v(B, et)
        }) : t && t.status === k.HIDE_MINES ? i($e, {}) : s.isAutoMode && s.selectedItems.includes(n) ? i("div", {
            className: v(B, nt)
        }) : i("div", W({
            className: B
        }, o()))
    }

    function l() {
        let u = ["grid-item"];
        return e && u.push("loading"), t && [k.HIDE_MINES, k.HIDE_GEMS].includes(t.status) && u.push("unselected"), u.join(" ")
    }

    function r() {
        return s.isAutoMode ? s.isBetting : !s.isBetting || !!e || !!t
    }
    return i("button", {
        disabled: r(),
        className: v(it, l()),
        onClick: () => s.handleItemClick(n),
        children: a()
    })
}
var _e = x(qe);

function ze() {
    const [n, s] = m.exports.useState(!0);
    return m.exports.useEffect(() => {
        let e = setInterval(() => {
            s(t => !t)
        }, 3e3);
        return () => {
            clearInterval(e)
        }
    }, []), d("div", {
        className: v(B, st),
        children: [i("div", {
            className: v(B, "graph")
        }), n && i(Ze, {
            count: 1,
            radius: I.isMobile ? Z(3) : Z(4)
        })]
    })
}

function Ke() {
    const [n, s] = m.exports.useState(!1), t = `mines${m.exports.useRef(G(1,4)).current}`;
    return i("div", {
        className: v(B, tt, "effect", n && "end", t),
        onAnimationEnd: () => s(!0)
    })
}

function $e() {
    const s = `mines${m.exports.useRef(G(1,4)).current}`;
    return i("div", {
        className: v(B, s)
    })
}
const B = "ix3nmq4",
    et = "u54ie25",
    tt = "s1f8a337",
    st = "sf5i89h",
    nt = "slusuv0",
    it = "gbimp89";

function at() {
    const n = S(),
        [s, e] = pe(),
        [t, o] = m.exports.useState(n.isBetting ? null : {
            currencyName: n.currencyName,
            odds: n.currentOdds.toNumber(),
            amount: n.amount.toNumber()
        }),
        [a, l] = m.exports.useState(!1);
    let r;
    m.exports.useEffect(() => (t ? (n.currentOdds.toNumber() > 1 && e({
        profitAmount: t.odds * t.amount,
        currencyName: t.currencyName,
        odds: +t.odds.toFixed(2),
        isBigWin: !1,
        enableSound: n.settings.soundEnable
    }), n.isAutoMode && (r = window.setTimeout(() => {
        n.autoBet.isRunning || (e(null), n.resetStatus())
    }, 1e3))) : (e(null), r && window.clearTimeout(r)), () => {
        r && clearTimeout(r)
    }), [t]), m.exports.useEffect(() => {
        e(null)
    }, [n.isAutoMode]), m.exports.useEffect(() => {
        n.isBetting && l(!0);
        let u = setTimeout(() => {
            l(!1)
        }, 300);
        return () => {
            clearTimeout(u)
        }
    }, [n.isBetting]), m.exports.useEffect(() => {
        const u = () => {
                o(null)
            },
            c = N => {
                o(P(W({}, N), {
                    amount: N.amount.toNumber()
                }))
            };
        return n.on("betStart", u), n.on("betEnd", c), () => {
            n.off("betStart", u), n.off("betEnd", c)
        }
    }, []);
    const h = Array(n.grids).fill(1);
    return d("div", {
        className: v(ut, "mine-stage"),
        children: [s, i("div", {
            className: `grids-wrap ${a?"animate":""}`,
            children: h.map((u, c) => i(_e, {
                index: c
            }, c))
        }), i(ot, {})]
    })
}

function ot() {
    const [n, s] = m.exports.useState(() => [G(0, 3)]);
    return m.exports.useEffect(() => {
        let e = setInterval(async () => {
            let t = G(1, 3),
                o = Array(t).fill(1).map(() => G(1, 40) % 4);
            s([]), await be(500), s(o)
        }, 5e3);
        return () => {
            clearInterval(e)
        }
    }, []), d("div", {
        className: rt,
        children: [i("div", {
            className: `${n.includes(1)?"active ":""} star-item index1`
        }), i("div", {
            className: `${n.includes(2)?"active ":""} star-item index2`
        }), i("div", {
            className: `${n.includes(3)?"active ":""} star-item index3`
        }), i("div", {
            className: `${n.includes(0)?"active ":""} star-item index4`
        })]
    })
}
var lt = x(at);
const rt = "fctyxs8",
    ut = "g1rs4zrn";
const dt = () => {
    const n = S(),
        s = j.useSingleDetail();
    return d(ie, {
        children: [i(Ae, {
            list: n.myBets,
            keyof: "betId",
            onDetail: s
        }), d(ve, {
            className: ht,
            children: [i(lt, {}), i(ye, {})]
        })]
    })
};
var ct = x(dt);
const ht = "g16pktg7";

function mt() {
    const n = D(),
        s = S();
    return d("div", {
        className: gt,
        children: [I.isMobile && d(ie, {
            children: [i($, {}), s.isBetting && i(H, {
                className: "pick-button",
                type: "gray",
                size: "big",
                disabled: !s.isBetting,
                onClick: () => s.pickTile(),
                children: n("game.mines.pick")
            })]
        }), i(A.CoinInput, {
            checkIncrease: !0
        }), i(A.LabelSelect, {
            label: n("game.mines.mines"),
            disabled: s.isBetting,
            value: s.mines,
            options: s.minesOptions,
            onChange: e => s.handleMinesChange(e)
        }), s.isBetting && d("div", {
            className: "preview-wrap",
            children: [i(C, {
                label: n("game.mines.gems"),
                value: s.gems,
                readOnly: !0,
                size: "small"
            }), i(J, {
                label: n("game.mines.profit_next") + `(${s.nextOdds.sub(1).add(s.currentOdds).toFixed(2)}x)`,
                value: s.amount.mul(s.nextOdds.sub(1).add(s.currentOdds).toFixed(2)).toNumber(),
                currencyName: s.currencyName,
                size: "small",
                readOnly: !0,
                onChange: () => {}
            }), i(J, {
                label: n("common.total_profit") + `(${s.currentOdds.toFixed(2)}x)`,
                value: s.amount.mul(s.currentOdds.toFixed(2)).toNumber(),
                currencyName: s.currencyName,
                size: "small",
                readOnly: !0,
                onChange: () => {}
            }), !I.isMobile && i(H, {
                className: "pick-button",
                type: "gray",
                size: "big",
                disabled: !s.isBetting,
                onClick: () => s.pickTile(),
                children: n("game.mines.pick")
            })]
        }), !I.isMobile && i($, {})]
    })
}
const $ = x(function() {
    const s = D(),
        e = S();
    async function t() {
        e.handleBet().catch(o => {
            ae(o)
        })
    }
    return e.isBetting ? i(H, {
        className: "bet-button cashout-btn",
        type: "conic",
        size: "big",
        disabled: !e.canCashout,
        onClick: e.cashout,
        children: "Cashout"
    }) : i(H, {
        className: "bet-button",
        size: "big",
        type: "conic",
        onClick: t,
        children: s("common.bet")
    })
});
var ft = x(mt);
const gt = "m112ltai";
const pt = x(function() {
        const s = S(),
            e = D(),
            t = () => i(H, {
                className: "bet-button",
                type: "conic",
                size: "big",
                disabled: !s.selectedItems.length,
                onClick: () => {
                    s.autoBet.isRunning ? s.autoBet.stop() : s.autoBet.start().catch(ae)
                },
                children: s.autoBet.isRunning ? e("common.stop_auto_bet") : e("common.start_auto_bet")
            });
        return d("div", {
            className: v(bt, "game-form"),
            children: [I.isMobile && t(), i(A.CoinInput, {
                checkIncrease: !0
            }), i(A.LabelSelect, {
                label: e("game.mines.mines"),
                disabled: s.isBetting,
                value: s.mines,
                options: s.minesOptions,
                onChange: o => s.handleMinesChange(o)
            }), i(A.TimesInput, {}), i(A.IncreaseInput, {}), i(A.StopInput, {}), i(A.IncreaseInput, {
                isLose: !0
            }), i(A.StopInput, {
                isLose: !0
            }), i(Ne, {}), !I.isMobile && t()]
        })
    }),
    bt = "a1nn9f9a";
const At = T.memo(() => {
        const n = D(),
            s = S(),
            e = [{
                title: n("common.game_intro"),
                node: i(Ue, {
                    game: s
                })
            }, {
                title: n("common.fairness"),
                node: "/mines_help/fairness"
            }, {
                title: n("common.bankroll"),
                node: i(Pe, {
                    game: s
                })
            }];
        return i(we, {
            manualControl: i(ft, {}),
            className: vt,
            autoControl: i(pt, {}),
            gameView: i(ct, {}),
            tabs: [{
                label: n("common.all_bet"),
                value: j.AllBet
            }, {
                label: n("common.my_bet"),
                value: j.MyBet
            }],
            actions: [i(ke, {}), i(Ie, {}), i(Be, {}), i(Ge, {}), i(Se, {}), i(Me, {
                list: e
            })]
        })
    }),
    vt = "m1v4v9oy",
    y = V.Reader,
    X = V.Writer,
    Q = V.util,
    f = V.roots.gameMine || (V.roots.gameMine = {});
f.BetValue = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.mines = 0, n.encode = function(e, t) {
        return t || (t = X.create()), e.mines != null && Object.hasOwnProperty.call(e, "mines") && t.uint32(8).sint32(e.mines), t
    }, n.decode = function(e, t) {
        e instanceof y || (e = y.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new f.BetValue;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    a.mines = e.sint32();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, n
})();
f.GameValue = (() => {
    function n(s) {
        if (this.fields = [], this.cards = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.odds = 0, n.prototype.fields = Q.emptyArray, n.prototype.cards = Q.emptyArray, n.encode = function(e, t) {
        if (t || (t = X.create()), e.odds != null && Object.hasOwnProperty.call(e, "odds") && t.uint32(9).double(e.odds), e.fields != null && e.fields.length) {
            t.uint32(18).fork();
            for (let o = 0; o < e.fields.length; ++o) t.sint32(e.fields[o]);
            t.ldelim()
        }
        if (e.cards != null && e.cards.length) {
            t.uint32(26).fork();
            for (let o = 0; o < e.cards.length; ++o) t.sint32(e.cards[o]);
            t.ldelim()
        }
        return t
    }, n.decode = function(e, t) {
        e instanceof y || (e = y.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new f.GameValue;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    a.odds = e.double();
                    break;
                case 2:
                    if (a.fields && a.fields.length || (a.fields = []), (l & 7) === 2) {
                        let r = e.uint32() + e.pos;
                        for (; e.pos < r;) a.fields.push(e.sint32())
                    } else a.fields.push(e.sint32());
                    break;
                case 3:
                    if (a.cards && a.cards.length || (a.cards = []), (l & 7) === 2) {
                        let r = e.uint32() + e.pos;
                        for (; e.pos < r;) a.cards.push(e.sint32())
                    } else a.cards.push(e.sint32());
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, n
})();
f.Next = (() => {
    function n(s) {
        if (this.fields = [], s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.fields = Q.emptyArray, n.encode = function(e, t) {
        if (t || (t = X.create()), e.fields != null && e.fields.length) {
            t.uint32(10).fork();
            for (let o = 0; o < e.fields.length; ++o) t.sint32(e.fields[o]);
            t.ldelim()
        }
        return t
    }, n.decode = function(e, t) {
        e instanceof y || (e = y.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new f.Next;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    if (a.fields && a.fields.length || (a.fields = []), (l & 7) === 2) {
                        let r = e.uint32() + e.pos;
                        for (; e.pos < r;) a.fields.push(e.sint32())
                    } else a.fields.push(e.sint32());
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, n
})();
f.CashoutValue = (() => {
    function n(s) {
        if (s)
            for (let e = Object.keys(s), t = 0; t < e.length; ++t) s[e[t]] != null && (this[e[t]] = s[e[t]])
    }
    return n.prototype.frontgroundId = 0, n.encode = function(e, t) {
        return t || (t = X.create()), e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && t.uint32(120).sint32(e.frontgroundId), t
    }, n.decode = function(e, t) {
        e instanceof y || (e = y.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new f.CashoutValue;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 15:
                    a.frontgroundId = e.sint32();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, n
})();
var yt = "/assets/bg.136f0468.png",
    Nt = "/assets/bg-w.5b09b45e.png",
    wt = "/assets/bg-m.2dee6492.png",
    kt = "/assets/bg-m-w.7860475f.png",
    It = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAAAcCAMAAADGO9TYAAAAzFBMVEUAAABISEgVGRUaHBkfJR8VGRUYHBgXGhcXGxcZHRkVGRUXGxcXGhcYGxcoLiorKysXGhYXGxcaHRoZGxkfHx8aHhoXGhYaHhoaHhoXGxc6QTwaHxoXGhc4QDwXGxc8REA7RD8VGRUaHRk1PTk9Rz8XGhY1OzgbIBs1PDk9Rj89RT89RUEYGxcVGBUaHRktMzEpLiw4Pzs6Qj02PTk0Ozc8RD8+R0EyODUwNjMjJycmKikSFhMsMS8cHx8gIyQeIyAeISIZGx0kKSUhJSPPEBtlAAAALHRSTlMABPUlGo7ww4NT1c6pQDQJvJtgKxH3tnc76IpuWVNI7sB14bQl/umzlmLZeiYE94IAAAJsSURBVFjD1dT7d5owFAfwIFRBFMVHfdXHdH1tEdjqqoIZLfz//9NIfFzC0sh+wLrP4TQeven9nlwACXwdTl8/wXT29Gw1UH7KePbrc7yyv98W38cakoED/XkFprPhs6XID/THlVi5ftg17VG9Iz7Qhxfe2o389cvF0ZjOyfxRN1T+QBcrzsaLCCuNNqtL2kHMlG7FNhREacOHdYrrxcQBsbu+iOR0jjEJvcCgNmojarzYgJ0fO38JvU3BuJic8uPIQgeWewTlgrBuIeR9y7c97j3QcnfuzvNh5mJkm5S5tJauCfhMVwq+92ISRr6X/V28X5yz2+z1FcR78rbhPiZ2cHI5qc/dcvr7yMspOuxxwtg/X82aQx8WU4eYKRUslpx+X+n0Bhg40FnCJ5hhbVnerXQbwWndil5vILGyICZ75PYaozlOCbf+GSEWcOgN8QECVaY+YTHFVJwxt1sqV6G0qjiFxFsJCCrMK9rrYMa8mXSQlIHBfdW+04RFJtcy/ChofGgrzxtmotKYBosppy+XeImTS14+qdCaYy0mv0UIq6FKzTJdjvWZlQZ+O+2qGRrK5Zb+4wq7R+T6tBK8k7cMgk8/1pLmmqEneSXoAdN9dZRTNXnQIaaUVbvnWr2TNAhaheaqcXMmL3b6KCcF/QPVLvFHewJBS1+U7K47aV4LFSN50fKnAkFh9oDLWyldKCq8u8zsDJeC2efP20YFqu+fsGAZJBesMPsceWG/iooBN21wAHFh9ue1W0negFFRwTr6IOBIZi/Ja5YCDRWu0apCUMns5ZR2A13CpMlystlfvbZdYrP/L2g6zL5QfwACtwc45qOUEQAAAABJRU5ErkJggg==",
    Bt = "/assets/box-bg2.75183067.png",
    Gt = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKoAAAAcCAMAAADGO9TYAAAAq1BMVEUAAAB+f5FnbIBiZnxeZHldYnZcYXZhZntfZHhjaX5jaH1cYXZhZ3xla39cYXVfZHljaX5bYHReY3dfZHliaH1iaH1kaX5cYHVWWm5iaHxnboJjaH1gZXljaHxeZHhjaHxZXXFiaHxZXXJnbYJla39oboNZXHFla4BZXXJWWm5gZXpdY3dhZ3taX3NcYXVjaX5VWm5YXXFkan9mbIFSV2xRVWlNUWVQVGhoboNoUh1dAAAAKnRSTlMABAwWPqNzM9CBH/Pi8+T6yL6rX05G/NrWurKakXhnVkjYq24p57OKe/ZIj2w7AAACzklEQVRYw9XViVLiQBAA0Akk5CDcICq3sOrOlUmA1f//sm0TwkyYXFIL5b6aMld30vZoNcrhuX4QBRGsID0C7fxE3lNirsr3n92xh+ozxk8PlNKABrDiY0q9hkNxDLg+v9OfL+0GqtZ0fXo1TDGsf5K/sRaTZllDJ8Me/ilotP/1/LbaGXkNXfiYEExwDE7gglLlGlZy1MlnmXxwXX6w/0x1+rOt2UAKc9i7yKXBHhL2AamASQ3186Gd8Xc/4WdyBNBg104a2ppyFYEypYDwOyHQTk1S6XYXN9Rqs7Ov8OgiMKKcqTjjsJikPdOuq/M5tBM+rOs8b22UsLPhubLFhiyExST9mR5Xmg/bGOXpPC1s5f9qFMZg16MymIXfgQmvm8BoQZmuaaCM+VeZOMj3oEwhKFbEQhHC0s8lniRhDinlOXDCgkj7bN+dGEgzwHJqZKbNZjbymm5HmTA4FHWEWMmhhLGK8Mz3ocy3ScG06lDdgzNfnYZFY+FTCTNRiVANJqzkt6SSMx8XD1UvM9hAr/+WDW9sfTn0MHT2UCaM49J49d2EhyIvNy11M4P2lBljRfvJzWu+MdpgBTt98Hg4woqPID4XBJeK64U4NV/AbX82aqIq7ukVUObCNFABY+Wog4+JYy52jun2tKEq8wmDcs9+WyMP1TEkoDts2QYqN+4TBRfHj0uCpNotw7CXM6dHCsXtjdMeUU1+11ruUC3mAGYfl8V+/FEd2PmJlW4m1GvJejk55UtMiGPtUj30DfaQcIVQKhU85ZjZpIbdshyZp3HQbXjzdl6xB5begb3Py2uYLWt611JBo9VlivjPQA70Ybr3hfWySwN0O8bIYYpQsNRU7n1ZvS/Te5UKzNdQJ/e+ut5J66V7ShugG9tZ7TDrxUPf01y/f9X7im6u+d4Npcf1lW9Zr9AdGMtHkfj9bqCfbj0Q4NVD/wPbgr2/h7/1MuGz6lMSOgAAAABJRU5ErkJggg==",
    St = "/assets/box-bg2-w.774c3cf2.png",
    Mt = "/assets/gems.f2815a6d.png",
    Ct = "/assets/mines-1.33624994.png",
    xt = "/assets/mines-2.a6f64284.png",
    Et = "/assets/mines-3.b54d60a7.png",
    Ht = "/assets/mines-4.8900a7b8.png",
    Vt = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAAAKCAYAAACNMs+9AAAAAXNSR0IArs4c6QAAAJFJREFUGBljYEAD////5wLieDRhTC5QUSkQn8KUQRIBKuAG4ldADALySFIMTCAOUJARiMWAzCogFgWJAUEUhIKSQAUhQPwCiLGBo0DBOCDmYGJkZFwD1KMFxH1A/BOqH0S9AOJ7QMwIxHxAjABAnVVQY48gRLGwgIp0oAojsEijCgEVgtzFiiqKhQdUpIhFmAEAiABrq/Lg4u0AAAAASUVORK5CYII=",
    Rt = "/assets/mines-effect.905a1992.png",
    Ot = "/assets/sound_bet.42530855.mp3",
    jt = "/assets/sound_mines.50ef3b60.mp3",
    Tt = "/assets/sound_gems.08dbc6e7.mp3",
    Dt = "/assets/sound_hover.61e50321.mp3",
    Xt = "/assets/sound_bg.663fffac.mp3";
const E = {
    bg: yt,
    bgWhite: Nt,
    bgMobile: wt,
    bgMobileWhite: kt,
    boxBg1: It,
    boxBg1White: Gt,
    boxBg2: Bt,
    boxBg2White: St,
    gems: Mt,
    mines1: Ct,
    mines2: xt,
    mines3: Et,
    mines4: Ht,
    minesEffect: Rt,
    minesStar: Vt,
    soundBet: Ot,
    soundMines: jt,
    soundGems: Tt,
    soundHover: Dt,
    soundBG: Xt
};
var k = (n => (n[n.MINES = 0] = "MINES", n[n.GEMS = 1] = "GEMS", n[n.HIDE_MINES = 2] = "HIDE_MINES", n[n.HIDE_GEMS = 3] = "HIDE_GEMS", n))(k || {}),
    oe = (n => (n.PENDING = "pending", n.FULFILLED = "fulfilled", n.REJECTED = "rejected", n))(oe || {});
const ee = R.encode(f.CashoutValue),
    Ft = R.encode(f.BetValue),
    te = R.encode(f.Next),
    Yt = R.decode(f.BetValue),
    M = R.decode(f.GameValue);

function G(n, s) {
    return Math.floor(Math.random() * (s - n + 1) + n)
}
class Wt extends Ce {
    constructor() {
        super({
            name: "Mines",
            namespace: "/g/mines",
            sounds: {
                bet: E.soundBet,
                mines: E.soundMines,
                gems: E.soundGems,
                hover: E.soundHover,
                bg: {
                    src: E.soundBG,
                    loop: !0,
                    isBackground: !0
                }
            },
            fairLink: "/mines_help/fairness",
            validateLink: "/mines_help/validate"
        }, At);
        p(this, "rounds", []);
        p(this, "odds", 0);
        p(this, "guessing", !1);
        p(this, "DP", 15);
        p(this, "grids", 25);
        p(this, "minesOptions");
        p(this, "mines", 1);
        p(this, "selectedItems", []);
        p(this, "guessQueue", []);
        p(this, "currentOdds", new b(1));
        xe(this, {
            rounds: w,
            odds: w,
            guessing: w,
            mines: w,
            selectedItems: w,
            guessQueue: w,
            currentOdds: w,
            gems: O,
            canCashout: O,
            nextOdds: O,
            isAutoMode: O
        }), this.autoBet.interval = 2e3, this.minesOptions = Array(this.grids - 1).fill(1).map((t, o) => ({
            label: String(o + 1),
            value: o + 1,
            index: o
        })), this.cashout = this.cashout.bind(this), this.handleItemClick = this.handleItemClick.bind(this), this.pickTile = this.pickTile.bind(this), this.socket.on("connect", () => this.join()), q.waitLogin().then(() => this.join()), this.addHotkey("w", this.cashout, "Cashout"), this.addHotkey("p", this.pickTile, "Pick a Tile"), I.isMobile && (this.settings.hotkeyEnable = !1), this.on("submitItem", this.handleNext), Ee(() => {
            this.isAutoMode ? this.resetStatus() : this.resetStatus()
        });
        const e = this.hotkeyList.find(t => t.key == "space");
        e && (e.handler = () => {
            if (this.controlIdx === 1) this.autoBet.isRunning ? this.autoBet.stop() : this.selectedItems.length > 0 && this.autoBet.start();
            else {
                if (this.isBetting) return !1;
                this.handleBet()
            }
            return !1
        })
    }
    get gems() {
        return this.grids - this.mines - this.rounds.length
    }
    get canCashout() {
        return this.rounds.length >= 1
    }
    get nextOdds() {
        let e, t = this.grids - this.rounds.length;
        return this.rounds.length ? e = b.div(t, this.gems).mul(this.currentOdds).sub(this.currentOdds).add(1).toDP(this.DP) : e = b.div(this.grids, this.gems).mul(.99).toDP(this.DP), e
    }
    get isAutoMode() {
        return this.controlIdx === 1
    }
    hotkeyBet() {
        He(() => {
            this.isBetting || this.handleBet()
        }, 100)
    }
    pickTile() {
        if (!this.canGuess()) return;
        const e = this.rounds.map(o => o.field);
        let t = G(1, this.grids);
        for (; e.includes(t);) t = G(1, this.grids);
        this.handleItemClick(t - 1)
    }
    handleMinesChange(e) {
        this.mines = e, this.isAutoMode && this.selectedItems.length > this.gems && this.selectedItems.splice(0, this.selectedItems.length)
    }
    handleItemClick(e) {
        this.isAutoMode ? this.chooseItem(e) : this.addGuessQueue(e)
    }
    resetStatus() {
        this.rounds = [], this.guessQueue = []
    }
    chooseItem(e) {
        if (this.selectedItems.includes(e)) {
            let t = this.selectedItems.indexOf(e);
            this.selectedItems.splice(t, 1)
        } else this.selectedItems.length < this.grids - this.mines && this.selectedItems.push(e)
    }
    updateOdds() {
        this.rounds.length ? this.currentOdds = b.sub(this.grids, this.rounds.length).div(this.gems).mul(this.currentOdds).toDP(this.DP) : this.currentOdds = this.nextOdds
    }
    addGuessQueue(e, t = 0) {
        let o = {};
        o.promise = new Promise((a, l) => {
            o.index = e, o.status = "pending", o.resolve = () => {
                let r = this.guessQueue.find(h => h.index === e);
                r && (r.status = "fulfilled"), a(o.index)
            }, o.reject = () => {
                o.timmer && clearTimeout(o.timmer);
                let r = this.guessQueue.find(h => h.index === e);
                r && (r.status = "rejected"), l()
            }, o.timmer = setTimeout(() => {
                this.emit("submitItem", e)
            }, t)
        }).catch(a => a), this.guessQueue.push(o)
    }
    betValue() {
        return Ft({
            mines: this.mines
        })
    }
    canGuess() {
        return this.isBetting && !this.guessing
    }
    async join() {
        if (!this.isActived || !q.login) return;
        let e = await this.socketRequest("join").then(this.betResultDecoder),
            t = M(e.gameValue),
            o = Yt(e.betValue);
        if (e.odds > 0) {
            this.mines = o.mines, this.currentOdds = new b(t.odds), this.guessing = !1, this.setBetStatus(!0);
            let a = this.getBetlog(e);
            t.fields.length > 0 ? (this.currencyName = a.currencyName, setTimeout(() => this.amount = new b(a.betAmount), 100)) : this.resetStatus();
            try {
                await this.bet(new b(a.betAmount), a), this.setBetStatus(!1)
            } catch (l) {
                console.log("join error"), this.setBetStatus(!1)
            }
        }
    }
    updateGrids(e, t) {
        let o = e.slice(0, this.mines),
            a = e.slice(this.mines, this.grids),
            l = o.filter(c => !t.includes(c)),
            h = a.filter(c => !t.includes(c)).map(c => ({
                field: c,
                status: 3
            })),
            u = l.map(c => ({
                field: c,
                status: 2
            }));
        this.rounds.push(...h, ...u)
    }
    async handleNext(e) {
        const t = this.guessQueue.find(a => a.index === e),
            o = e + 1;
        if (!this.guessing && (t == null ? void 0 : t.status) === "pending") {
            this.guessing = !0;
            try {
                const a = await this.socketRequest("next", te({
                    fields: [o]
                })).then(M);
                let l = {
                    field: o,
                    status: 1
                };
                this.currentOdds = new b(a.odds), this.odds = a.odds, a.odds !== 0 ? (this.rounds.push(l), this.sounds.playSound("gems"), t == null || t.resolve(e), a.cards.length && (this.updateGrids(a.cards, a.fields), this.emit("end", {
                    odds: a.odds,
                    winAmount: this.amount.mul(a.odds).toNumber()
                }))) : (l.status = 0, this.rounds.push(l), this.sounds.playSound("mines"), t == null || t.resolve(e), this.guessQueue.filter(r => r.status === "pending").forEach(r => r.reject()), this.updateGrids(a.cards, a.fields), this.emit("end", {
                    odds: 0,
                    winAmount: 0
                }))
            } catch (a) {
                console.log("bet error", a), t == null || t.reject(), this.join()
            } finally {
                this.guessing = !1;
                const a = this.guessQueue.find(l => l.status === "pending");
                a && this.handleNext(a.index)
            }
        }
    }
    async handleAutoNext() {
        if (!this.guessing) {
            this.guessing = !0;
            try {
                const e = await this.socketRequest("next", te({
                    fields: this.selectedItems.map(t => t + 1)
                })).then(M);
                if (this.currentOdds = new b(e.odds), this.odds = e.odds, e.odds !== 0)
                    if (e.cards.length) this.rounds = this.selectedItems.map(t => ({
                        field: t + 1,
                        status: 1
                    })), this.updateGrids(e.cards, e.fields), this.emit("end", {
                        odds: e.odds,
                        winAmount: this.amount.mul(e.odds).toNumber()
                    });
                    else {
                        const t = await this.socketRequest("cashout", ee({
                            frontgroundId: this.txId
                        })).then(this.betResultDecoder);
                        let {
                            odds: o,
                            winAmount: a,
                            currencyName: l
                        } = t, r = M(t.gameValue);
                        o /= this.oddsScale;
                        const h = _.bn2amount(a, l);
                        this.rounds = this.selectedItems.map(u => ({
                            field: u + 1,
                            status: 1
                        })), this.updateGrids(r.cards, r.fields), this.emit("end", {
                            odds: o,
                            winAmount: h
                        })
                    }
                else {
                    let t = e.cards.slice(0, this.mines);
                    this.rounds = this.selectedItems.map(o => {
                        let a = o + 1;
                        return {
                            field: a,
                            status: t.includes(a) ? 0 : 1
                        }
                    }), this.updateGrids(e.cards, e.fields), this.emit("end", {
                        odds: 0,
                        winAmount: 0
                    })
                }
            } catch (e) {
                console.log("bet error", e), this.join()
            } finally {
                this.guessing = !1
            }
        }
    }
    async cashout() {
        if (!(!this.canGuess() || !this.canCashout)) {
            this.guessing = !0;
            try {
                const e = await this.socketRequest("cashout", ee({
                    frontgroundId: this.txId
                })).then(this.betResultDecoder);
                let {
                    odds: t,
                    winAmount: o,
                    currencyName: a
                } = e, l = M(e.gameValue);
                t /= this.oddsScale;
                const r = _.bn2amount(o, a);
                this.rounds.length !== l.fields.length && (console.log("cashout update"), this.isAutoMode || this.join()), this.updateGrids(l.cards, l.fields), this.emit("end", {
                    odds: t,
                    winAmount: r
                })
            } catch (e) {
                console.log("cashout error")
            } finally {
                this.guessing = !1
            }
        }
    }
    async bet(e = this.amount, t = 0) {
        if (this.resetStatus(), K(t)) {
            this.sounds.playSound("bet"), this.guessing = !0;
            try {
                let u = this.betRequest(e, this.betValue(), t);
                this.onBetRequest && (u = this.onBetRequest(u)), t = await u, this.currentOdds = new b(1), this.odds = t.odds
            } finally {
                K(t) && this.join(), this.guessing = !1
            }
        }
        M(t.gameValue).fields.forEach(u => {
            this.rounds.push({
                field: u,
                status: 1
            })
        });
        let {
            odds: a,
            winAmount: l
        } = await new Promise((u, c) => {
            const N = F => {
                    this.removeListener("deactivate", g), u(F)
                },
                g = () => {
                    this.removeListener("end", N), c()
                };
            this.once("end", N), this.once("deactivate", g), this.isAutoMode && this.handleAutoNext()
        });
        t.odds = a, t.winAmount = l, t.profitAmount = l - t.betAmount, delete t.gameValue;
        let r = t.betId;
        return this.myBets.find(u => u.betId === r) || (this.addMyBet(t), this.emit("betEnd", {
            amount: new b(t.betAmount),
            odds: t.odds,
            currencyName: t.currencyName
        })), t
    }
}
const le = new Wt;
var ss = le;
window.mineg = le;

function ns({
    bodyLock: n
}) {
    return i(ne, {
        bodyLock: n,
        children: d("div", {
            className: "item",
            children: [i("h2", {
                children: "How Are the Results Calculated?"
            }), d("div", {
                className: "content",
                children: [i("p", {
                    children: "To get the results, we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                }), i(Ve, {
                    children: `const crypto = require("crypto");

function getResult(hash) {
  const allNums = [
    7, 2, 19, 25, 1, 13, 5, 24, 14, 6, 15, 9, 22, 16, 3, 17, 18, 20, 8, 21, 4,
    12, 10, 23, 11,
  ];
  let seed = hash;
  let finalNums = createNums(allNums, seed);
  seed = crypto.createHash("SHA256").update(seed).digest("hex");
  finalNums = createNums(finalNums, seed);
  return finalNums.map((m) => m.num.num);
}

function createNums(allNums, hash) {
  let nums = [];
  let h = crypto.createHash("SHA256").update(hash).digest("hex");
  allNums.forEach((c) => {
    nums.push({ num: c, hash: h });
    h = h.substring(1) + h.charAt(0);
  });
  nums.sort(function (o1, o2) {
    if (o1.hash < o2.hash) {
      return -1;
    } else if (o1.hash === o2.hash) {
      return 0;
    } else {
      return 1;
    }
  });
  return nums;
}

function main (serverSeed, clientSeed, nonce) {
  let resultArr = [clientSeed, nonce];
  let hmacSha256Result = crypto.createHmac("sha256", serverSeed).update(resultArr.join(":")).digest("hex")
  let resultList = getResult(hmacSha256Result);
  console.log(resultList);
}

// main("server seed", "client seed", "nonce");
`
                })]
            })]
        })
    })
}
const Qt = (n, s, e, t, o) => {
        const a = o.betLog.bv.mines || "1";
        Re(`/mines_help/validate/${n}/${s}/${e}/${a}`)
    },
    Ut = j.withSingleDetail({
        onValidate: Qt,
        result: ({
            betLog: n
        }) => {
            const s = n.gv,
                e = n.bv,
                t = s.cards.slice(0, e.mines),
                o = s.fields;
            return i("div", {
                className: Lt,
                children: s.cards.sort((a, l) => a - l).map(a => i("div", {
                    className: "result-item",
                    children: o.includes(a) ? i("div", {
                        className: t.includes(a) ? "mines" : "gems"
                    }) : null
                }, a))
            })
        }
    }),
    Lt = "r1lr9gvh";
var is = Ut;
const Pt = () => {
    const n = Oe(),
        s = je(n),
        e = s[3] || "",
        t = Qe(() => ({
            serverSeed: s[0] || "",
            clientSeed: s[1] || "",
            nonce: parseInt(s[2]) || 0
        })),
        {
            serverSeed: o,
            clientSeed: a,
            nonce: l
        } = t,
        r = String(U(o)),
        u = String(Te([a, l].join(":"), o)),
        c = Zt(u),
        N = +e;
    return i(De, {
        title: Xe.t("common.fairness"),
        children: d(Fe, {
            className: Jt,
            children: [i("h2", {
                children: "Input"
            }), i(C, {
                label: "Server Seed",
                value: o,
                onChange: g => t.serverSeed = g
            }), i(C, {
                label: "Client Seed",
                value: a,
                onChange: g => t.clientSeed = g
            }), i(C, {
                label: "Nonce",
                value: l,
                onChange: g => t.nonce = Number(g)
            }), i("h2", {
                children: "Output"
            }), i(C, {
                label: "Sha256(server_seed)",
                value: r,
                readOnly: !0
            }), i(C, {
                label: "Hmac_sha256(client_seed:nonce, server_seed)",
                value: u,
                readOnly: !0
            }), i("h2", {
                children: "Final Result"
            }), i("div", {
                className: "result-list",
                children: c.map((g, F) => i("div", {
                    className: "result-item" + (F < N ? " mines-pos" : ""),
                    children: g
                }, g))
            })]
        })
    })
};
var as = Pt;

function se(n, s) {
    const e = [];
    let t = U(s).toString(We);
    return n.forEach(o => {
        e.push({
            num: o,
            hash: t
        }), t = t.substring(1) + t.charAt(0)
    }), e.sort(function(o, a) {
        return o.hash < a.hash ? -1 : o.hash === a.hash ? 0 : 1
    }), e
}

function Zt(n) {
    const s = [7, 2, 19, 25, 1, 13, 5, 24, 14, 6, 15, 9, 22, 16, 3, 17, 18, 20, 8, 21, 4, 12, 10, 23, 11];
    let e = n,
        t = se(s, e);
    return e = String(U(e)), t = se(t, e), t.map(o => o.num.num)
}
Ye({
    cl1: [z("#99a4b0", .8), z("#5f6975", .8)],
    cl2: ["#31343c", "#f6f6f9"]
});
const Jt = "f171t8mc";
export {
    Pe as Bankroll, is as Detail, ns as Fairness, ss as Game, as as Validate
};
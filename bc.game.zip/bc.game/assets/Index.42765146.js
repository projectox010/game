var te = Object.defineProperty,
    re = Object.defineProperties;
var de = Object.getOwnPropertyDescriptors;
var O = Object.getOwnPropertySymbols;
var oe = Object.prototype.hasOwnProperty,
    me = Object.prototype.propertyIsEnumerable;
var Y = (a, c, s) => c in a ? te(a, c, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : a[c] = s,
    C = (a, c) => {
        for (var s in c || (c = {})) oe.call(c, s) && Y(a, s, c[s]);
        if (O)
            for (var s of O(c)) me.call(c, s) && Y(a, s, c[s]);
        return a
    },
    k = (a, c) => re(a, de(c));
import {
    t as N,
    q as n,
    v as L,
    a as e,
    D as M,
    u as v,
    S as $,
    j as i,
    z as ee,
    o as x,
    d as D,
    l as _,
    A as u,
    s as V,
    L as f,
    E as he,
    G as J,
    I as g,
    r as b,
    H as fe,
    J as P,
    K as pe,
    M as ae,
    N as ge,
    O as ve,
    b as E,
    U as ue,
    e as Ne,
    P as we,
    Q as _e,
    R as be,
    V as ye,
    F as K,
    W as Ce
} from "./index.28e31dff.js";
const ke = [{
    level: "VIP 03",
    wager: "200",
    rewards: "0.50",
    bg: !0
}, {
    level: "VIP 04",
    wager: "1000",
    rewards: "3.00",
    linear: !0
}, {
    level: "VIP 05",
    wager: "2000",
    rewards: "1.00",
    bg: !0
}, {
    level: "VIP 06",
    wager: "3000",
    rewards: "1.00"
}, {
    level: "VIP 07",
    wager: "4000",
    rewards: "1.00",
    bg: !0
}, {
    level: "VIP 08",
    wager: "5000",
    rewards: "5.00",
    linear: !0
}, {
    level: "VIP 09",
    wager: "7000",
    rewards: "2.00",
    bg: !0
}, {
    level: "VIP 10",
    wager: "9000",
    rewards: "2.00"
}, {
    level: "VIP 11",
    wager: "11000",
    rewards: "2.00",
    bg: !0
}, {
    level: "VIP 12",
    wager: "13000",
    rewards: "2.00"
}, {
    level: "VIP 13",
    wager: "15000",
    rewards: "2.00",
    bg: !0
}, {
    level: "VIP 14",
    wager: "17000",
    rewards: "15.00",
    linear: !0
}, {
    level: "VIP 15",
    wager: "21000",
    rewards: "4.00",
    bg: !0
}, {
    level: "VIP 16",
    wager: "25000",
    rewards: "4.00"
}, {
    level: "VIP 17",
    wager: "29000",
    rewards: "4.00",
    bg: !0
}, {
    level: "VIP 18",
    wager: "33000",
    rewards: "4.00"
}, {
    level: "VIP 19",
    wager: "37000",
    rewards: "4.00",
    bg: !0
}, {
    level: "VIP 20",
    wager: "41000",
    rewards: "4.00"
}, {
    level: "VIP 21",
    wager: "45000",
    rewards: "4.00",
    bg: !0
}, {
    level: "VIP 22",
    wager: "49000",
    rewards: "35.50",
    linear: !0
}];

function xe() {
    const a = v();
    return e($, {
        className: Ie,
        children: i("div", {
            className: "rewards-dialog",
            children: [e("div", {
                className: "rewards-dialog_title",
                children: a("page.casino.dialog.rules.usd")
            }), i("div", {
                className: "rewards-dialog_content",
                children: [i("div", {
                    className: "rewards-dialog_content_head",
                    children: [e("span", {
                        children: a("page.casino.dialog.vip_level")
                    }), e("span", {
                        children: a("page.casino.dialog.total_wager")
                    }), e("span", {
                        className: "spec",
                        children: a("page.casino.dialog.rewards")
                    })]
                }), e("div", {
                    className: "rewards-dialog_content_list",
                    children: ke.map(c => i("div", {
                        className: `${c.bg?"bg ":""}${c.linear?"linear ":""}list_item`,
                        children: [e("span", {
                            className: "item_level",
                            children: c.level
                        }), e("span", {
                            className: "item_wager",
                            children: c.wager
                        }), i("div", {
                            className: "item_rewards",
                            children: [e(ee, {
                                name: "USD",
                                className: "icon"
                            }), e("span", {
                                children: c.rewards
                            })]
                        })]
                    }, c.level))
                })]
            })]
        })
    })
}
N({
    cl1: ["#17181b", "#ffffff"],
    cl2: ["#99a4b0", n("#5f6975", .6)],
    cl3: ["#1e2024", "#f5f6fa"],
    cl4: ["#ffffff", "#31373d"],
    cl5: ["#99a4b0", n("#5f6975", .8)]
});
const Ie = "rz32ciu";

function H() {
    L.push(e(M, {
        title: "USD Rewards Rule",
        className: "casino-rewards-dialog",
        children: e(xe, {})
    }))
}

function Re() {
    return e($, {
        className: Ue,
        children: e("div", {
            className: "commission-dialog"
        })
    })
}
const Ue = "csea3zh";

function Ae() {
    L.push(e(M, {
        title: "Commission Rewards Rule",
        size: [464, 470],
        className: "casino-commission-dialog",
        children: e(Re, {})
    }))
}

function Se() {
    const a = v();
    return e($, {
        className: Pe,
        children: i("pre", {
            className: "commissions-rules",
            children: [e("div", {
                children: a("page.casino.commission.cont_1")
            }), e("div", {
                children: a("page.casino.commission.cont_2")
            }), e("div", {
                children: a("page.casino.commission.cont_3")
            }), i("ul", {
                children: [e("li", {
                    children: a("page.casino.commission.cont_4")
                }), e("li", {
                    children: a("page.casino.commission.cont_5")
                }), e("li", {
                    children: a("page.casino.commission.cont_6")
                }), e("li", {
                    children: a("page.casino.commission.cont_7")
                }), e("li", {
                    children: a("page.casino.commission.cont_8")
                })]
            }), e("div", {
                children: a("page.casino.commission.cont_9")
            }), e("div", {
                children: a("page.casino.commission.cont_a")
            })]
        })
    })
}
N({
    cl1: [n("#99a4b0", .8), n("#5f6975", .8)]
});
const Pe = "c14mhnhz";

function Ve() {
    L.push(e(M, {
        title: "Commissions Rules",
        className: "casino-commission-rules",
        children: e(Se, {})
    }))
}

function We() {
    const a = v();
    return e($, {
        className: De,
        children: i("pre", {
            className: "affiliate-terms",
            children: [e("p", {
                children: a("page.casion.affiliate.tit_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_2.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_2.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_2.cont_3")
            }), e("p", {
                children: a("page.casion.affiliate.tit_3")
            }), e("p", {
                children: a("page.casion.affiliate.tit_4")
            }), e("div", {
                children: a("page.casion.affiliate.tit_4.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_4.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_4.cont_3")
            }), e("p", {
                children: a("page.casion.affiliate.tit_5")
            }), e("div", {
                children: a("page.casion.affiliate.tit_5.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_6")
            }), e("div", {
                children: a("page.casion.affiliate.tit_6.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_6.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_6.cont_3")
            }), e("div", {
                children: a("page.casion.affiliate.tit_6.cont_4")
            }), e("div", {
                children: a("page.casion.affiliate.tit_6.cont_5")
            }), e("div", {
                children: a("page.casion.affiliate.tit_6.cont_6")
            }), e("p", {
                children: a("page.casion.affiliate.tit_7")
            }), e("div", {
                children: a("page.casion.affiliate.tit_7.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_7.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_7.cont_3")
            }), e("p", {
                children: a("page.casion.affiliate.tit_8")
            }), e("div", {
                children: a("page.casion.affiliate.tit_8.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_8.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_8.cont_3")
            }), e("div", {
                children: a("page.casion.affiliate.tit_8.cont_4")
            }), e("div", {
                children: a("page.casion.affiliate.tit_8.cont_5")
            }), e("p", {
                children: a("page.casion.affiliate.tit_9")
            }), e("div", {
                children: a("page.casion.affiliate.tit_9.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_9.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_9.cont_3")
            }), e("div", {
                children: a("page.casion.affiliate.tit_9.cont_4")
            }), e("p", {
                children: a("page.casion.affiliate.tit_a")
            }), e("p", {
                children: a("page.casion.affiliate.tit_b")
            }), e("p", {
                children: a("page.casion.affiliate.tit_c")
            }), e("div", {
                children: a("page.casion.affiliate.tit_c.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_c.cont_2")
            }), e("p", {
                children: a("page.casion.affiliate.tit_d")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_3")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_4")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_5")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_6")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_7")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_8")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_9")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_a")
            }), e("div", {
                children: a("page.casion.affiliate.tit_d.cont_b")
            }), e("p", {
                children: a("page.casion.affiliate.tit_f")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_3")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_4")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_5")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_6")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_7")
            }), e("div", {
                children: a("page.casion.affiliate.tit_f.cont_8")
            }), e("p", {
                children: a("page.casion.affiliate.tit_11")
            }), e("div", {
                children: a("page.casion.affiliate.tit_11.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_11.cont_2")
            }), e("p", {
                children: a("page.casion.affiliate.tit_12")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_2")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_3")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_4")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_5")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_6")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_7")
            }), e("div", {
                children: a("page.casion.affiliate.tit_12.cont_8")
            }), e("p", {
                children: a("page.casion.affiliate.tit_13")
            }), e("p", {
                children: a("page.casion.affiliate.tit_14")
            }), e("p", {
                children: a("page.casion.affiliate.tit_15")
            }), e("div", {
                children: a("page.casion.affiliate.tit_15.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_16")
            }), e("div", {
                children: a("page.casion.affiliate.tit_16.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_17")
            }), e("div", {
                children: a("page.casion.affiliate.tit_17.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_17.cont_2")
            }), e("p", {
                children: a("page.casion.affiliate.tit_18")
            }), e("div", {
                children: a("page.casion.affiliate.tit_18.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_19")
            }), e("div", {
                children: a("page.casion.affiliate.tit_19.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_1a")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1a.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_1b")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1b.cont_1")
            }), e("p", {
                children: a("page.casion.affiliate.tit_1c")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1c.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1c.cont_2")
            }), e("p", {
                children: a("page.casion.affiliate.tit_1d")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1d.cont_1")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1d.cont_2")
            }), e("p", {
                children: a("page.casion.affiliate.tit_1e")
            }), e("div", {
                children: a("page.casion.affiliate.tit_1e.cont")
            })]
        })
    })
}
N({
    cl1: [n("#99a4b0", .8), n("#5f6975", .8)]
});
const De = "a789veo";

function Le() {
    L.push(e(M, {
        title: "Affiliate Program Rules",
        className: "casino-affiliate-terms",
        children: e(We, {})
    }))
}

function Me({
    links: a
}) {
    const c = v(),
        {
            isMobile: s
        } = V,
        r = `https://forum.bc.game/${D.login?"?haslogin=1":""}`;
    return e("div", {
        className: _(Te, "casino-header"),
        children: i("div", {
            className: "header-sub flex-center",
            children: [i("div", {
                className: "left flex-center",
                children: [i("div", {
                    className: "m-item rules",
                    onClick: Ve,
                    children: [e(u, {
                        name: "Rules"
                    }), e("span", {
                        children: c(s ? "page.casino.rules" : "page.casino.commission_rules")
                    })]
                }), i("div", {
                    className: "m-item terms",
                    onClick: Le,
                    children: [e(u, {
                        name: "AffiliateTerms"
                    }), e("span", {
                        children: c(s ? "page.casino.terms" : "page.casino.affiliate_terms")
                    })]
                })]
            }), e("div", {
                className: "right flex-center",
                children: i("div", {
                    className: "m-item forum",
                    onClick: () => location.href = r,
                    children: [e(u, {
                        name: "Forum"
                    }), e("span", {
                        children: c("common.forum")
                    })]
                })
            })]
        })
    })
}
var $e = x(Me);
const Te = "c145kwpx";

function Q(a, c) {
    try {
        he(a), J(c)
    } catch (s) {
        J(s)
    }
}

function ze(a) {
    const c = v(),
        {
            showWelcome: s,
            links: d,
            info: r,
            handleCreateCasino: l,
            className: y
        } = a,
        t = () => Q(r.code, c("common.messages.copy_success")),
        I = () => Q(r.link, c("common.messages.copy_success"));
    return e("div", {
        className: `${Ee} my-casino ${y||""}`,
        children: i("div", {
            className: "m-casino",
            children: [i("div", {
                className: "tip ttu",
                children: [c("page.casino.tip_1"), e("br", {}), i("span", {
                    className: "theme",
                    children: [e(f, {
                        amount: 100
                    }), " "]
                }), c("page.casino.tip_2")]
            }), !s && i("div", {
                className: "result-item",
                children: [e("div", {
                    className: "label ttu",
                    children: c("page.casino.code")
                }), i("div", {
                    className: "value",
                    children: [e("span", {
                        className: "maxlength",
                        children: r.code
                    }), e("span", {
                        className: "copy",
                        onClick: t
                    })]
                })]
            }), !s && i("div", {
                className: "result-item",
                children: [e("div", {
                    className: "label ttu",
                    children: c("page.casino.link")
                }), i("div", {
                    className: "value",
                    children: [e("span", {
                        className: "maxlength",
                        children: r.link
                    }), e("span", {
                        className: "copy",
                        onClick: I
                    })]
                })]
            }), !s && e("button", {
                className: "new",
                onClick: () => location.href = d.createCode,
                children: c("page.casino.create_more")
            }), s && e("button", {
                className: "new spec",
                onClick: l,
                children: c("page.casino.create")
            })]
        })
    })
}
var X = x(ze);
const Ee = "mbdj4p1";

function He() {
    const a = v();
    return i("div", {
        className: _(qe, "why-casino"),
        children: [i("div", {
            className: "left",
            children: [e("div", {
                className: "title theme",
                children: e(g, {
                    k: "page.casino.why.left.title",
                    children: e("br", {})
                })
            }), e("div", {
                className: "desc",
                children: a("page.casino.why.left.content_1")
            }), e("div", {
                className: "desc",
                children: e(g, {
                    k: "page.casino.why.left.content_2",
                    children: e("span", {
                        className: "theme",
                        children: "BC.GAME"
                    })
                })
            })]
        }), i("div", {
            className: "right",
            children: [e("div", {
                className: "title theme",
                children: e(g, {
                    k: "page.casino.why.right.title",
                    children: e("br", {})
                })
            }), e("div", {
                className: "desc",
                children: a("page.casino.why.right.content_1")
            }), e("div", {
                className: "desc",
                children: e(g, {
                    k: "page.casino.why.right.content_2",
                    children: e("a", {
                        href: "mailto:Affiliate@bc.game",
                        className: "theme",
                        children: "Affiliate@bc.game"
                    })
                })
            })]
        })]
    })
}
N({
    cl1: ["#1e2024", "#ffffff"],
    cl2: ["#99a4b0", n("#5f6975", .8)],
    cl3: ['url("../assets/why.left.png")', 'url("../assets/why.left-w.png")'],
    cl4: ['url("../assets/why.right.png")', 'url("../assets/why.right-w.png")']
});
const qe = "wk68fie";

function je() {
    const a = v();

    function c(s) {
        const d = document.getElementById(s);
        d && d.scrollIntoView({
            block: "center"
        })
    }
    return i("div", {
        className: _(Fe, "rewards-graph"),
        children: [e("div", {
            className: "title",
            children: a("page.casino.rewards.title")
        }), i("div", {
            className: "rewards-wrap",
            children: [i("a", {
                className: "item-rewards",
                onClick: () => c("system-rewards"),
                children: [e("div", {
                    className: "type ttu",
                    children: a("page.casino.rewards.system.usd.title")
                }), e("div", {
                    className: "tip-detail",
                    children: a("page.casino.rewards.system.click")
                })]
            }), i("a", {
                className: "item-commission",
                onClick: () => c("system-commission"),
                children: [e("div", {
                    className: "type",
                    children: a("page.casino.rewards.system.commission.title")
                }), e("div", {
                    className: "tip-detail",
                    children: a("page.casino.rewards.system.click")
                })]
            })]
        })]
    })
}
N({
    cl1: ["#ffffff", "#31373d"],
    cl2: ["#1e2024", "#ffffff"],
    cl3: ["#1c2933", "#f5f6fa"],
    cl4: ["#1e2024", "#ffffff"],
    cl5: ["#24262b", "#f5f6fa"],
    cl6: ["#fff", n("#5f6975", .8)]
});
const Fe = "mdrv6zu";
var Z = "/assets/rewards.dadef713.png";

function Be() {
    const a = v();
    return i("div", {
        className: _(Ge, "rewards-wrap"),
        children: [i("div", {
            className: "rewards item",
            children: [i("div", {
                className: "system",
                style: {
                    backgroundImage: `url(${Z})`
                },
                children: [e("div", {
                    className: "title theme ttu",
                    children: a("page.casino.rewards.system.usd.title")
                }), e("div", {
                    className: "desc",
                    children: a("page.casino.rewards.system.usd.content")
                }), i("div", {
                    className: "flex",
                    children: [e("div", {
                        className: "amount",
                        children: e(f, {
                            amount: 100
                        })
                    }), e("a", {
                        className: "hover theme",
                        onClick: H,
                        children: a("page.casino.rewards.system.usd.rules")
                    }), e(u, {
                        name: "Arrow",
                        className: "arrow"
                    })]
                })]
            }), e("div", {
                className: "graph",
                id: "system-rewards"
            }), i("div", {
                className: "footer",
                children: [e("p", {
                    className: "text",
                    children: a("page.casino.rewards.system.usd.contact")
                }), i("a", {
                    href: "https://t.me/joinchat/L5YyYla7--Arsls3DgAgdw",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    className: "contact",
                    children: [e("div", {
                        className: "icon-box",
                        children: e(u, {
                            name: "Send",
                            className: "icon"
                        })
                    }), e("span", {
                        children: a("page.casino.contactus")
                    })]
                })]
            })]
        }), i("div", {
            className: "commission item",
            children: [i("div", {
                className: "system",
                style: {
                    backgroundImage: `url(${Z})`
                },
                children: [e("div", {
                    className: "title theme ttu",
                    children: a("page.casino.rewards.system.commission.title")
                }), e("div", {
                    className: "desc",
                    children: a("page.casino.rewards.system.commission.content")
                })]
            }), e("div", {
                className: "graph",
                id: "system-commission"
            }), e("div", {
                className: "footer"
            })]
        })]
    })
}
N({
    cl1: ["#1e2024", "#ffffff"],
    cl2: ["#1e2024", "transparent"],
    cl3: ["#f5f6f7", n("#5f6975", .8)],
    cl4: ["#f5f6f7", n("#5f6975", .6)],
    cl5: ["#17181b", "#f5f6fa"],
    cl6: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl7: ["#eaeaea", n("#5f6975", .8)],
    cl8: ["#17181b", "transparent"],
    cl9: ['url("../assets/rewards-arrow.png")', 'url("../assets/rewards-arrow-w.png")'],
    cl10: ['url("../assets/graph.line.png")', 'url("../assets/graph.line-w.png")'],
    cl11: ['url("../assets/graph.pit.png")', 'url("../assets/graph.pit-w.png")']
});
const Ge = "r1vr6hbq";

function Oe({
    data: a,
    links: c
}) {
    const s = v(),
        [d, r] = b.exports.useState(!1),
        l = fe(() => r(!1));

    function y(t) {
        const S = t / 22;
        return S >= 1 ? {
            width: "100%"
        } : {
            width: S * 100 + "%"
        }
    }
    return i("div", {
        className: _(Je, "my-rewards"),
        children: [i("div", {
            className: "rewards-item rewards",
            children: [i("div", {
                className: "common",
                children: [i("div", {
                    className: "title ttu",
                    children: [i("span", {
                        children: [s("page.casino.extra"), "\xA0"]
                    }), e("span", {
                        className: "type theme",
                        children: s("page.casino.rewards.system.usd.title")
                    })]
                }), i("div", {
                    className: "hover",
                    children: [e("a", {
                        className: "theme",
                        onClick: H,
                        children: s("page.casino.rewards.system.usd.rules")
                    }), e(u, {
                        name: "Arrow",
                        className: "arrow"
                    })]
                }), i("div", {
                    className: "amount-wrap",
                    children: [e("div", {
                        className: "amount",
                        children: e(f, {
                            amount: a.dashboard.availableRewardUsd
                        })
                    }), e("div", {
                        className: "desc",
                        children: s("page.casino.rewards.usd.newly")
                    })]
                }), i("div", {
                    className: "tips",
                    children: [i("div", {
                        className: "tips_flex",
                        children: [i("div", {
                            children: [s("page.casino.received"), ":\xA0", e("span", {
                                className: "theme",
                                children: e(f, {
                                    amount: a.dashboard.rewardUsd
                                })
                            })]
                        }), i("div", {
                            className: "question-box",
                            children: [e(u, {
                                name: "Inform",
                                className: "question",
                                onClick: () => r(!0)
                            }), d && i("div", {
                                className: "question-content",
                                ref: l,
                                children: [i("div", {
                                    className: "fc",
                                    children: [i("div", {
                                        children: [s("page.casino.tips.referrals"), ":\xA0", e("span", {
                                            className: "theme",
                                            children: a.dashboard.friendNumber
                                        })]
                                    }), i("div", {
                                        children: [e(g, {
                                            k: "page.casino.tips.total",
                                            children: i("span", {
                                                className: "yellow ttu",
                                                children: [s("page.casino.rewards.system.usd.title"), ":\xA0"]
                                            })
                                        }), i("span", {
                                            className: "theme",
                                            children: [a.dashboard.friendNumber, "*", P.amount2locale(100, "USD").toFixed(2)]
                                        })]
                                    })]
                                }), i("div", {
                                    className: "unlocked",
                                    children: [s("page.casino.tips.unlocked"), ":\xA0", e(f, {
                                        amount: a.dashboard.rewardUsd
                                    })]
                                }), i("div", {
                                    className: "locked",
                                    children: ["Locked ", e("span", {
                                        className: "yellow",
                                        children: "USD"
                                    }), ":\xA0", i("span", {
                                        className: "theme",
                                        children: [a.dashboard.friendNumber, "*", P.amount2locale(100, "USD").toFixed(2), "-", a.dashboard.rewardUsd, " = \xA0", P.toLocaleCurrency(a.dashboard.remainingRewardUsd, "USD")]
                                    })]
                                }), e("hr", {
                                    className: "hr"
                                }), e("div", {
                                    children: e(g, {
                                        k: "page.casino.tips.desc",
                                        children: i("a", {
                                            onClick: H,
                                            className: "theme",
                                            children: ["\xA0", s("page.casino.rewards.system.usd.rules")]
                                        })
                                    })
                                })]
                            })]
                        }), i("div", {
                            children: [s("wallet.bcd.dialog.locked"), ":\xA0", e("span", {
                                className: "theme",
                                children: e(f, {
                                    amount: a.dashboard.remainingRewardUsd
                                })
                            })]
                        })]
                    }), e("div", {
                        children: s("page.casino.rewards.usd.desc")
                    })]
                }), e("a", {
                    className: "withdraw",
                    href: c.rewardWithdraw,
                    children: s("title.wallet_withdraw")
                })]
            }), i("div", {
                className: `${a.topRewards.length?"":"nothing "}list-group`,
                children: [!a.topRewards.length && e("div", {
                    className: "nothing-tip",
                    children: e(g, {
                        k: "page.casino.noting",
                        children: e("br", {})
                    })
                }), e("div", {
                    className: "list-header",
                    children: i("div", {
                        className: "list-header_friends",
                        children: [e("span", {
                            children: s("page.casino.all_friends")
                        }), e("span", {
                            className: "value",
                            children: a.dashboard.friendNumber
                        })]
                    })
                }), i("div", {
                    className: "list-content",
                    children: [a.topRewards.length > 0 && i("div", {
                        className: "fc thead",
                        children: [e("div", {
                            className: "th",
                            children: s("page.casino.my_top3_friends")
                        }), e("div", {
                            className: "th",
                            children: s("page.casino.vip_level")
                        }), e("div", {
                            className: "th",
                            children: s("page.casino.earned_me")
                        })]
                    }), a.topRewards.map(t => i("div", {
                        className: "tr fc",
                        children: [i("div", {
                            className: "td fc",
                            children: [e(pe, {
                                userId: t.userId,
                                name: t.userName,
                                className: "user-avatar"
                            }), e("div", {
                                className: "nickanme",
                                children: t.userName
                            })]
                        }), i("div", {
                            className: "td fc",
                            children: [e("div", {
                                className: "bar",
                                children: e("div", {
                                    className: "bar-cover",
                                    style: y(t.userLevel)
                                })
                            }), i("div", {
                                className: "level",
                                children: ["V", t.userLevel]
                            })]
                        }), e("div", {
                            className: "td fc yellow",
                            children: e(f, {
                                amount: Number(t.rewardUsd)
                            })
                        })]
                    }, t.userId))]
                }), i("a", {
                    className: "list-footer",
                    href: c.rewardDetails,
                    children: [e("span", {
                        children: s("page.casino.view_more")
                    }), e(u, {
                        name: "Arrow",
                        className: "arrow"
                    })]
                })]
            })]
        }), i("div", {
            className: "rewards-item commission",
            children: [i("div", {
                className: "common",
                children: [e("div", {
                    className: "title ttu",
                    children: e(g, {
                        k: "page.casino.rewards.commission.title",
                        children: e("span", {
                            className: "type theme",
                            children: s("page.casino.rewards.system.commission.title")
                        })
                    })
                }), i("div", {
                    className: "hover",
                    children: [e("a", {
                        className: "theme",
                        onClick: Ae,
                        children: s("page.casino.rewards.system.commission.rules")
                    }), e(u, {
                        name: "Arrow",
                        className: "arrow"
                    })]
                }), i("div", {
                    className: "amount-wrap",
                    children: [e("div", {
                        className: "amount",
                        children: e(f, {
                            amount: a.dashboard.availableCommissionUsd
                        })
                    }), e("div", {
                        className: "desc",
                        children: s("page.casino.rewards.commission.newly")
                    })]
                }), i("div", {
                    className: "total-commission",
                    children: [i("div", {
                        className: "commission-desc",
                        children: [e(g, {
                            k: "page.casino.rewards.commission.received",
                            children: e("span", {
                                className: "theme",
                                children: s("page.casino.commission")
                            })
                        }), ":"]
                    }), e("div", {
                        className: "commission-amount",
                        children: e(f, {
                            amount: a.dashboard.commissionUsd
                        })
                    })]
                }), e("a", {
                    className: "withdraw",
                    href: c.commissionWithdraw,
                    children: s("title.wallet_withdraw")
                })]
            }), i("div", {
                className: `${a.topCommissions.length?"":"nothing "}list-group`,
                children: [!a.topCommissions.length && e("div", {
                    className: "nothing-tip",
                    children: e(g, {
                        k: "page.casino.noting",
                        children: e("br", {})
                    })
                }), e("div", {
                    className: "list-header",
                    children: e("div", {
                        children: s("page.casino.rewards.commission.info")
                    })
                }), i("div", {
                    className: "list-content",
                    children: [a.topCommissions.length > 0 && i("div", {
                        className: "fc thead",
                        children: [e("div", {
                            className: "th",
                            children: s("page.casino.commission")
                        }), e("div", {
                            className: "th",
                            children: s("page.casino.rewards.commission.received_in_total")
                        }), e("div", {
                            className: "th",
                            children: s("page.casino.rewards.commission.usd_value")
                        })]
                    }), a.topCommissions.map((t, I) => i("div", {
                        className: "tr fc",
                        children: [i("div", {
                            className: "td fc",
                            children: [e(ee, {
                                name: t.currencyName,
                                className: "currency-icon"
                            }), e("span", {
                                className: "currency-name",
                                children: P.getAlias(t.currencyName)
                            }), i("span", {
                                className: "currency-fullname",
                                children: ["(", t.fullName, ")"]
                            })]
                        }), e("div", {
                            className: "td fc yellow",
                            children: e(ae, {
                                name: t.currencyName,
                                amount: +t.commissionAmount
                            })
                        }), e("div", {
                            className: "td fc yellow",
                            children: e(f, {
                                amount: Number(t.commissionUsd)
                            })
                        })]
                    }, I))]
                }), i("a", {
                    className: "list-footer",
                    href: c.commissionWithdraw,
                    children: [e("span", {
                        children: s("page.casino.view_more")
                    }), e(u, {
                        name: "Arrow",
                        className: "arrow"
                    })]
                })]
            })]
        })]
    })
}
var Ye = x(Oe);
N({
    cl1: ["#1e2024", "#ffffff"],
    cl2: ["#f5f6f7", n("#5f6975", .8)],
    cl3: [n("#17181b", .7), "#ffffff"],
    cl4: ["#1e2024", "#f5f6fa"],
    cl5: ["#f5f6f7", n("#5f6975", .6)],
    cl6: ["#31343c", n("#6b7180", .6)],
    cl7: ["#5da000", "#f5f6f7"],
    cl8: ["#1e2024", "#f5f6fa"],
    cl9: [n("#3e484f", .3), "#e9eaf2"],
    cl10: ["#17181b", "#ffffff"],
    cl11: ["#0d1216", "#e9eaf2"],
    cl12: ["#17181b", "#ffffff"],
    cl13: ["transparent", n("#5f6975", .13)],
    cl14: [n("#99a4b0", .6), n("#5f6975", .6)],
    cl15: ["#17181b", "#f5f6fa"],
    cl16: ["#31343c", "#dde0e6"],
    cl17: ["#5da000", "#7bc514"],
    cl18: [n("#5da000", .11), n("#7bc514", .11)],
    cl19: ["#31343c", n("#6b7180", .6)],
    cl20: ["inherit", "#31373d"],
    cl21: ['url("../assets/rewards-arrow.png")', 'url("../assets/rewards-arrow-w.png")'],
    cl22: ['url("../assets/rewards.png")', 'url("../assets/rewards_w.png")'],
    cl23: ['url("../assets/commission.png")', 'url("../assets/commission-w.png")'],
    cl24: ['url("../assets/friends.svg")', 'url("../assets/friends-w.svg")']
});
const Je = "m1hx8gfu";

function Ke(a) {
    const c = v(),
        {
            rewardUsd: s = 0,
            commissionUsd: d = 0
        } = a;
    return e("div", {
        className: _(Xe, "platform-rewards"),
        children: V.isMobile ? i("div", {
            className: "is-mobile",
            children: [e("div", {
                className: "title ttu",
                children: c("page.casino.rewards.platform.total")
            }), i("div", {
                className: "fc",
                children: [i("div", {
                    className: "rewards",
                    children: [e("div", {
                        className: "desc",
                        children: c("page.casino.rewards.platform.usd")
                    }), e("div", {
                        className: "number-wrap",
                        children: e(f, {
                            amount: s
                        })
                    })]
                }), i("div", {
                    className: "commission",
                    children: [e("div", {
                        className: "desc",
                        children: c("page.casino.rewards.platform.commission")
                    }), e("div", {
                        className: "number-wrap",
                        children: e(f, {
                            amount: d
                        })
                    })]
                })]
            })]
        }) : i("div", {
            className: "is-pc",
            children: [e("div", {
                className: "title ttu",
                children: c("page.casino.rewards.platform.total")
            }), i("div", {
                className: "fc",
                children: [i("div", {
                    className: "rewards",
                    children: [e("div", {
                        className: "desc",
                        children: c("page.casino.rewards.platform.usd")
                    }), e("div", {
                        className: "number-wrap",
                        children: e(f, {
                            amount: s
                        })
                    })]
                }), i("div", {
                    className: "commission",
                    children: [e("div", {
                        className: "desc",
                        children: c("page.casino.rewards.platform.commission")
                    }), e("div", {
                        className: "number-wrap",
                        children: e(f, {
                            amount: d
                        })
                    })]
                })]
            })]
        })
    })
}
var Qe = x(Ke);
N({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl3: [n("#17181b", .7), "#f5f6fa"],
    cl4: ["#1e2024", "#ffffff"]
});
const Xe = "p1g1o16r";

function Ze({
    links: a
}) {
    const c = v(),
        s = c("common.share"),
        {
            data: d
        } = ge(() => ve({
            title: c("page.casino.my_casino"),
            content: s
        }));
    return d ? i("div", {
        className: _(aa, "share-casino"),
        children: [e("div", {
            className: "title ttu",
            children: i(g, {
                k: "page.casino.share.title",
                children: [e("span", {
                    className: "theme",
                    children: c("page.casino.my_casino")
                }), V.isMobile ? e("br", {}) : ""]
            })
        }), i("div", {
            className: "content",
            children: [e("div", {
                className: "share-wrap",
                children: e("div", {
                    className: "absolute",
                    children: d.map((r, l) => r.src ? e("a", {
                        href: r.src,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "share-item enabled",
                        children: e("img", {
                            className: "icon",
                            src: r.icon
                        })
                    }, l) : e("div", {
                        className: "share-item disabled",
                        children: e("img", {
                            className: "icon",
                            src: r.icon
                        })
                    }, l))
                })
            }), e("div", {
                className: "download-wrap",
                children: e("div", {
                    className: "absolute",
                    children: e(E, {
                        type: "conic",
                        className: "download",
                        children: e("a", {
                            href: a.downloadBanner,
                            download: "material.zip",
                            children: c("page.casino.share.download")
                        })
                    })
                })
            })]
        })]
    }) : null
}
var ea = x(Ze);
N({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: ["#1e2024", "#ffffff"],
    cl3: ["#181a1d", n("#e9eaf2", .6)],
    cl4: ["#181a1d", "#ffffff"],
    cl5: ['url("../assets/share1.png")', 'url("../assets/share1-w.png")']
});
const aa = "ssbndvp";

function ia({
    info: a
}) {
    const c = v();
    return e(ue, {
        children: e("div", {
            className: sa,
            children: i("div", {
                className: "table",
                children: [e("div", {
                    className: "thead",
                    children: i("div", {
                        className: "tr fc",
                        children: [e("div", {
                            className: "th",
                            children: c("common.player")
                        }), e("div", {
                            className: "th",
                            children: c("page.casino.rewards.platfrom.commission_rewards")
                        })]
                    })
                }), e("div", {
                    className: "tbody",
                    children: a && a.map((s, d) => i("div", {
                        className: "tr fc",
                        children: [e("div", {
                            className: "td fc player",
                            children: e("span", {
                                className: "nickname",
                                children: s.userName
                            })
                        }), e("div", {
                            className: "td fc commission",
                            children: e(ae, {
                                name: s.currencyName,
                                amount: +s.amount,
                                icon: !0
                            })
                        })]
                    }, d))
                })]
            })
        })
    })
}
var z = x(ia);
N({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl3: ["#1e2024", "#ffffff"]
});
const sa = "c10g25c5";
const U = `//mycasino.${V.domain}`,
    A = {
        management: U + "/",
        createCode: U + "/mycasino/referral",
        rewardWithdraw: U + "/mycasino/rewards",
        commissionWithdraw: U + "/mycasino/commissions",
        rewardDetails: U + "/mycasino/rewards",
        commissionDetails: U + "/mycasino/commissions",
        downloadBanner: "https://res.bc.game/material.zip?md5=69dc359c0de077f93b62da3bc3e5520d"
    };

function ca() {
    const a = v(),
        c = Ne(),
        s = V.isMobile,
        d = D.login,
        r = we(),
        [l, y] = b.exports.useState(!0),
        [t, I] = b.exports.useState(!1),
        [S, ie] = b.exports.useState(null),
        [q, se] = b.exports.useState({
            code: "",
            link: ""
        }),
        [w, T] = b.exports.useState({
            list: [],
            left: [],
            right: [],
            commissionUsd: "",
            rewardUsd: ""
        });
    b.exports.useEffect(() => (F(!1), document.documentElement.classList.add("scroll-behavior"), () => {
        document.documentElement.classList.remove("scroll-behavior")
    }), []), b.exports.useEffect(() => {
        !D.login || (_e().then(o => {
            const {
                invitationCode: p,
                invitationUrl: m,
                activateTime: h
            } = o;
            !r() || (se({
                code: p,
                link: m
            }), h > 0 && y(!1))
        }), be().then(o => {
            !r() || (o && o.topCommissions && o.topCommissions.forEach(p => {
                let m = P.dict[p.currencyName];
                m && (p.fullName = m.fullName)
            }), ie(o))
        }))
    }, [D.login]);

    function W() {
        d ? (window.scrollTo(0, 0), y(!1), I(!1), Ce()) : c("/login")
    }

    function ce(o) {
        const p = s ? 11 : 22,
            m = o.slice(0, p);
        T(h => {
            let R = [...h.left],
                B = [...h.right];
            return s ? k(C({}, h), {
                list: m
            }) : (m.forEach((G, le) => {
                (le + 1) % 2 === 0 ? R.unshift(G) : B.unshift(G)
            }), k(C({}, h), {
                left: R,
                right: B
            }))
        }), j(o.slice(p, o.length), 5e3)
    }

    function j(o, p) {
        setTimeout(() => {
            if (!!r()) {
                if (o.length < 2) {
                    F(!0);
                    return
                }
                T(m => {
                    if (s) {
                        let h = [...m.list];
                        return h.pop(), h.unshift(o.shift()), k(C({}, m), {
                            list: h
                        })
                    } else {
                        let h = [...m.left],
                            R = [...m.right];
                        return h.pop(), R.pop(), h.unshift(o.shift()), R.unshift(o.shift()), k(C({}, m), {
                            left: h,
                            right: R
                        })
                    }
                }), j(o, 2e3)
            }
        }, p)
    }

    function F(o) {
        ye().then(p => {
            !r() || (T(m => o ? k(C({}, m), {
                list: [],
                left: [],
                right: []
            }) : k(C({}, m), {
                commissionUsd: p.commissionUsd,
                rewardUsd: p.rewardUsd
            })), ce(p.list))
        })
    }

    function ne() {
        d ? location.href = A.management : c("/login")
    }
    return e("div", {
        className: _(na, s && " mobile"),
        children: i("div", {
            className: _(la, l && "welcome"),
            children: [e($e, {
                links: A
            }), i("div", {
                className: "banner",
                children: [!s && e("div", {
                    className: "bokeh banner-layer"
                }), !s && !l && e("div", {
                    className: "character banner-layer"
                }), !s && e(K, {
                    children: e(X, {
                        info: q,
                        showWelcome: l,
                        links: A,
                        handleCreateCasino: W,
                        className: `${t?"animate__backInLeft":""}`
                    })
                }), !s && l && e("div", {
                    className: `character banner-layer ${l?"welcome":""}`
                }), !s && !l && i(K, {
                    children: [e("div", {
                        className: "hand banner-layer"
                    }), e("div", {
                        className: "chips banner-layer"
                    })]
                }), i("button", {
                    className: "management",
                    onClick: ne,
                    children: [e(u, {
                        name: "Management"
                    }), !s && e("span", {
                        children: a("page.casino.affiliate_dashboard")
                    })]
                })]
            }), l && !s && e("div", {
                className: "button-create",
                children: e(E, {
                    className: "button",
                    type: "conic",
                    onClick: W,
                    children: a("page.casino.create")
                })
            }), i("div", {
                className: "container",
                children: [s && e(X, {
                    info: q,
                    showWelcome: l,
                    links: A,
                    handleCreateCasino: W,
                    className: `${t?"animate__backInLeft":""}`
                }), l && i("div", {
                    className: "section why",
                    children: [e("div", {
                        className: "title ttu",
                        children: a("page.casino.why.title")
                    }), e("div", {
                        className: "content",
                        children: e(He, {})
                    })]
                }), l && i("div", {
                    className: "section rewards-system",
                    children: [e("div", {
                        className: "title ttu",
                        children: e(g, {
                            k: "page.casino.rewards.system.title",
                            children: e("span", {
                                className: "theme",
                                children: a("common.affiliate_myCasino")
                            })
                        })
                    }), e("div", {
                        className: "tip",
                        children: e(g, {
                            k: "page.casino.rewards.system.tip",
                            children: i("span", {
                                children: ['"', a("page.casino.create"), '"']
                            })
                        })
                    })]
                }), s && l && e("div", {
                    className: "section",
                    children: e(je, {})
                }), l ? i("div", {
                    className: "section",
                    children: [s ? e("div", {
                        className: "title ttu",
                        children: a("page.casino.rewards.title")
                    }) : e("div", {
                        className: "title pc-spec",
                        children: a("page.casino.rewards.title")
                    }), e("div", {
                        className: "content",
                        children: e(Be, {})
                    })]
                }) : i("div", {
                    className: "section",
                    children: [s ? e("div", {
                        className: "title ttu",
                        children: a("page.casino.rewards.title")
                    }) : e("div", {
                        className: "title pc-spec",
                        children: a("page.casino.rewards.title")
                    }), e("div", {
                        className: "content",
                        children: S && e(Ye, {
                            data: S,
                            links: A
                        })
                    })]
                }), e("div", {
                    className: "section",
                    children: w.rewardUsd && e(Qe, {
                        rewardUsd: +w.rewardUsd,
                        commissionUsd: +w.commissionUsd
                    })
                }), !l && e("div", {
                    className: "section",
                    children: e(ea, {
                        links: A
                    })
                }), i("div", {
                    className: "section",
                    children: [e("div", {
                        className: "title ttu",
                        children: a("page.casino.rewards.platfrom.title")
                    }), e("div", {
                        className: "content",
                        children: s && w.list.length > 0 ? e(z, {
                            info: w.list
                        }) : i("div", {
                            className: "flex",
                            children: [w.left.length > 0 && e("div", {
                                className: "flex-left",
                                children: e(z, {
                                    info: w.left
                                })
                            }), w.right.length > 0 && e("div", {
                                className: "flex-right",
                                children: e(z, {
                                    info: w.right
                                })
                            })]
                        })
                    })]
                }), l && e(E, {
                    type: "conic",
                    className: "button",
                    onClick: W,
                    children: a("page.casino.create")
                })]
            })]
        })
    })
}
var da = x(ca);
const na = "cxsv5d7",
    la = "cykikzk";
export {
    da as
    default
};
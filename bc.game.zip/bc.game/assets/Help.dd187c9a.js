var R = Object.defineProperty,
    I = Object.defineProperties;
var T = Object.getOwnPropertyDescriptors;
var m = Object.getOwnPropertySymbols;
var v = Object.prototype.hasOwnProperty,
    L = Object.prototype.propertyIsEnumerable;
var f = (e, a, t) => a in e ? R(e, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : e[a] = t,
    g = (e, a) => {
        for (var t in a || (a = {})) v.call(a, t) && f(e, t, a[t]);
        if (m)
            for (var t of m(a)) L.call(a, t) && f(e, t, a[t]);
        return e
    },
    P = (e, a) => I(e, T(a));
var E = (e, a) => {
    var t = {};
    for (var l in e) v.call(e, l) && a.indexOf(l) < 0 && (t[l] = e[l]);
    if (e != null && m)
        for (var l of m(e)) a.indexOf(l) < 0 && L.call(e, l) && (t[l] = e[l]);
    return t
};
import {
    as as s,
    at as n,
    au as x,
    ao as O,
    r,
    av as b,
    u as D,
    aw as V,
    j as p,
    a as o,
    ax as w,
    a5 as d,
    e as y,
    a4 as C,
    F as G,
    b as N,
    t as S,
    q as F,
    l as z,
    ay as B,
    az as j,
    A as q,
    C as M
} from "./index.28e31dff.js";
const W = s(() => n(() =>
        import ("./index.c8a864a4.js"), ["assets/index.c8a864a4.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    H = s(() => n(() =>
        import ("./index.ed0db0b9.js"), ["assets/index.ed0db0b9.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    U = s(() => n(() =>
        import ("./index.c3d61975.js"), ["assets/index.c3d61975.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    J = s(() => n(() =>
        import ("./index.1d91c250.js"), ["assets/index.1d91c250.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    K = s(() => n(() =>
        import ("./index.30808893.js"), ["assets/index.30808893.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    k = s(() => n(() =>
        import ("./index.b6c7c78d.js"), ["assets/index.b6c7c78d.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    Q = s(() => n(() =>
        import ("./index.d9c02263.js"), ["assets/index.d9c02263.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    X = s(() => n(() =>
        import ("./index.da5fdc94.js"), ["assets/index.da5fdc94.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    Y = s(() => n(() =>
        import ("./index.d23d7335.js"), ["assets/index.d23d7335.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    Z = s(() => n(() =>
        import ("./index.d5d1b45a.js"), ["assets/index.d5d1b45a.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    $ = s(() => n(() =>
        import ("./index.1d4ca725.js"), ["assets/index.1d4ca725.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    ee = s(() => n(() =>
        import ("./index.86423bc9.js"), ["assets/index.86423bc9.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    te = s(() => n(() =>
        import ("./index.7a795d57.js"), ["assets/index.7a795d57.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    ae = s(() => n(() =>
        import ("./index.ce1a2023.js"), ["assets/index.ce1a2023.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"])),
    oe = s(() => n(() =>
        import ("./index.0875c685.js"), ["assets/index.0875c685.js", "assets/HelpPage.5a10ddbc.js", "assets/HelpPage.c5d03e05.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css"]));

function le(e) {
    const a = x(),
        [t, l] = O({
            loading: !0,
            fairLinkDom: null,
            validateLink: ""
        });
    return r.exports.useEffect(() => {
        l({
            loading: !0
        });
        try {
            const i = b(a.routes, {
                pathname: e
            });
            if (i && i.length > 0) {
                const _ = i.length;
                i[_ - 1].route.element.props.children.props.game().then(c => {
                    const h = b(a.routes, {
                        pathname: c.config.fairLink
                    });
                    if (h && h.length > 0) {
                        const A = h[0].route.element.props.children;
                        l({
                            loading: !1,
                            fairLinkDom: A,
                            validateLink: c.config.validateLink
                        })
                    }
                })
            } else l({
                loading: !1,
                fairLinkDom: null,
                validateLink: ""
            })
        } catch (i) {
            l({
                loading: !1,
                fairLinkDom: null,
                validateLink: ""
            })
        }
    }, [e]), t
}
const se = /^http.*/;

function ne() {
    const e = D(),
        {
            gameList: a
        } = V(),
        [t, l] = r.exports.useState(""),
        [i, _] = r.exports.useState([]);
    return r.exports.useEffect(() => {
        if (a.length > 0) {
            const u = a.map(c => ({
                label: c.fullName,
                value: c.gameUrl
            }));
            _(u), l(u[0].value)
        }
    }, [a]), a.length === 0 || !t ? null : p("div", {
        className: re,
        children: [o("p", {
            className: "title",
            children: e("page.share.game_label")
        }), o(w, {
            value: t,
            onChange: l,
            options: i
        }), o("p", {
            className: "title",
            children: e("common.fairness")
        }), o(ie, {
            path: t
        })]
    })
}
const ie = d.memo(function({
    path: e
}) {
    const a = y(),
        t = le(e);
    if (t.loading) return null;
    const l = i => {
        se.test(i) ? window.open(i) : a(i)
    };
    return !t.fairLinkDom || !t.validateLink ? o(C, {}) : p(G, {
        children: [d.cloneElement(t.fairLinkDom, P(g({}, t.fairLinkDom.props), {
            bodyLock: !1
        })), o(N, {
            type: "conic2",
            onClick: () => l(t.validateLink),
            children: "Validate"
        })]
    })
});
S({
    cl1: ["#dfe3e6", "#31373d"],
    cl2: [F("#24262b", .5), "#f5f6fa"]
});
const re = "s8vbee2";
const ce = d.forwardRef((l, t) => {
        var i = l,
            {
                className: e
            } = i,
            a = E(i, ["className"]);
        return o("div", g({
            ref: t,
            className: z(pe, e)
        }, a))
    }),
    pe = "g10v6xhz";

function ue() {
    const e = D(),
        a = y(),
        t = B();
    r.exports.useEffect(() => {
        t.pathname === "/help" && a("/help/provably-fair", {
            replace: !0
        })
    }, [t.pathname]);
    const l = r.exports.useMemo(() => o(j, {
        prex: "/help/",
        routes: [{
            label: e("common.faq_fairness"),
            path: "provably-fair",
            element: o(ne, {})
        }, {
            label: e("title.help_terms"),
            path: "terms-service",
            element: o(oe, {})
        }, {
            label: e("title.terms_sports"),
            path: "terms-sports",
            element: o(ae, {})
        }, {
            label: e("title.deposit_bonus_terms"),
            path: "bonus",
            element: o(H, {})
        }, {
            label: "Coin Accuracy Limit",
            path: "coinlimit",
            element: o(U, {})
        }, {
            label: e("title.help_contactus"),
            path: "contactus",
            element: o(J, {})
        }, {
            label: e("title.help_fee"),
            path: "fee",
            element: o(K, {})
        }, {
            label: e("title.help_googlecheck"),
            path: "googlecheck",
            element: o(Q, {})
        }, {
            label: e("title.help_normalpro"),
            path: "faq",
            element: o(X, {})
        }, {
            label: e("title.help_passcurrency"),
            path: "passcurrency",
            element: o(Y, {})
        }, {
            label: e("title.help_reglog"),
            path: "reglog",
            element: o($, {})
        }, {
            label: e("title.help_swappolicy"),
            path: "swappolicy",
            element: o(te, {})
        }, {
            label: e("title.help_gamebleaware"),
            path: "gameble-aware",
            element: o(k, {})
        }, {
            label: e("title.help_protectminors"),
            path: "protect-minors",
            element: o(k, {})
        }, {
            label: e("title.providers"),
            path: "providers",
            element: o(Z, {})
        }, {
            label: e("title.help_aml"),
            path: "aml",
            element: o(W, {})
        }, {
            label: e("title.help_selfexclusion"),
            path: "self-exclusion",
            element: o(ee, {})
        }]
    }), []);
    return p("div", {
        id: "helpcenter",
        children: [p(ce, {
            children: [p("p", {
                className: "title",
                children: [o(q, {
                    name: "Fairness"
                }), o("span", {
                    className: "ttc",
                    children: e("title.user_agreement").toLowerCase()
                })]
            }), o(M, {
                onClick: () => a(-1)
            })]
        }), l]
    })
}
export {
    ue as
    default
};
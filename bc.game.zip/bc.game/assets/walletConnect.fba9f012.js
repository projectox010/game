import {
    aM as Le,
    aN as ni,
    y as ra
} from "./index.28e31dff.js";
import {
    b as ia
} from "./index.21cf2e94.js";
import {
    d as oa
} from "./dijkstra.47a9ffea.js";
var Qn = {},
    ee = {};
Object.defineProperty(ee, "__esModule", {
    value: !0
});
var ri = ee.getLocalStorage = pi = ee.getLocalStorageOrThrow = di = ee.getCrypto = hi = ee.getCryptoOrThrow = ui = ee.getLocation = fi = ee.getLocationOrThrow = ci = ee.getNavigator = li = ee.getNavigatorOrThrow = si = ee.getDocument = ai = ee.getDocumentOrThrow = oi = ee.getFromWindowOrThrow = ii = ee.getFromWindow = void 0;

function wt(t) {
    let e;
    return typeof window < "u" && typeof window[t] < "u" && (e = window[t]), e
}
var ii = ee.getFromWindow = wt;

function Nt(t) {
    const e = wt(t);
    if (!e) throw new Error(`${t} is not defined in Window`);
    return e
}
var oi = ee.getFromWindowOrThrow = Nt;

function aa() {
    return Nt("document")
}
var ai = ee.getDocumentOrThrow = aa;

function sa() {
    return wt("document")
}
var si = ee.getDocument = sa;

function la() {
    return Nt("navigator")
}
var li = ee.getNavigatorOrThrow = la;

function ca() {
    return wt("navigator")
}
var ci = ee.getNavigator = ca;

function fa() {
    return Nt("location")
}
var fi = ee.getLocationOrThrow = fa;

function ua() {
    return wt("location")
}
var ui = ee.getLocation = ua;

function ha() {
    return Nt("crypto")
}
var hi = ee.getCryptoOrThrow = ha;

function da() {
    return wt("crypto")
}
var di = ee.getCrypto = da;

function pa() {
    return Nt("localStorage")
}
var pi = ee.getLocalStorageOrThrow = pa;

function ga() {
    return wt("localStorage")
}
ri = ee.getLocalStorage = ga;
Object.defineProperty(Qn, "__esModule", {
    value: !0
});
var gi = Qn.getWindowMetadata = void 0;
const br = ee;

function _a() {
    let t, e;
    try {
        t = br.getDocumentOrThrow(), e = br.getLocationOrThrow()
    } catch (I) {
        return null
    }

    function n() {
        const I = t.getElementsByTagName("link"),
            B = [];
        for (let P = 0; P < I.length; P++) {
            const N = I[P],
                D = N.getAttribute("rel");
            if (D && D.toLowerCase().indexOf("icon") > -1) {
                const b = N.getAttribute("href");
                if (b)
                    if (b.toLowerCase().indexOf("https:") === -1 && b.toLowerCase().indexOf("http:") === -1 && b.indexOf("//") !== 0) {
                        let S = e.protocol + "//" + e.host;
                        if (b.indexOf("/") === 0) S += b;
                        else {
                            const C = e.pathname.split("/");
                            C.pop(), S += C.join("/") + "/" + b
                        }
                        B.push(S)
                    } else if (b.indexOf("//") === 0) {
                    const S = e.protocol + b;
                    B.push(S)
                } else B.push(b)
            }
        }
        return B
    }

    function r(...I) {
        const B = t.getElementsByTagName("meta");
        for (let P = 0; P < B.length; P++) {
            const N = B[P],
                D = ["itemprop", "property", "name"].map(b => N.getAttribute(b)).filter(b => b ? I.includes(b) : !1);
            if (D.length && D) {
                const b = N.getAttribute("content");
                if (b) return b
            }
        }
        return ""
    }

    function s() {
        let I = r("name", "og:site_name", "og:title", "twitter:title");
        return I || (I = t.title), I
    }

    function o() {
        return r("description", "og:description", "twitter:description", "keywords")
    }
    const h = s(),
        m = o(),
        v = e.origin,
        M = n();
    return {
        description: m,
        url: v,
        icons: M,
        name: h
    }
}
gi = Qn.getWindowMetadata = _a;
var ma = globalThis && globalThis.__spreadArrays || function() {
        for (var t = 0, e = 0, n = arguments.length; e < n; e++) t += arguments[e].length;
        for (var r = Array(t), s = 0, e = 0; e < n; e++)
            for (var o = arguments[e], h = 0, m = o.length; h < m; h++, s++) r[s] = o[h];
        return r
    },
    va = function() {
        function t(e, n, r) {
            this.name = e, this.version = n, this.os = r, this.type = "browser"
        }
        return t
    }(),
    wa = function() {
        function t(e) {
            this.version = e, this.type = "node", this.name = "node", this.os = process.platform
        }
        return t
    }(),
    ya = function() {
        function t(e, n, r, s) {
            this.name = e, this.version = n, this.os = r, this.bot = s, this.type = "bot-device"
        }
        return t
    }(),
    ba = function() {
        function t() {
            this.type = "bot", this.bot = !0, this.name = "bot", this.version = null, this.os = null
        }
        return t
    }(),
    Ma = function() {
        function t() {
            this.type = "react-native", this.name = "react-native", this.version = null, this.os = null
        }
        return t
    }(),
    xa = /alexa|bot|crawl(er|ing)|facebookexternalhit|feedburner|google web preview|nagios|postrank|pingdom|slurp|spider|yahoo!|yandex/,
    Sa = /(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask\ Jeeves\/Teoma|ia_archiver)/,
    Mr = 3,
    Ea = [
        ["aol", /AOLShield\/([0-9\._]+)/],
        ["edge", /Edge\/([0-9\._]+)/],
        ["edge-ios", /EdgiOS\/([0-9\._]+)/],
        ["yandexbrowser", /YaBrowser\/([0-9\._]+)/],
        ["kakaotalk", /KAKAOTALK\s([0-9\.]+)/],
        ["samsung", /SamsungBrowser\/([0-9\.]+)/],
        ["silk", /\bSilk\/([0-9._-]+)\b/],
        ["miui", /MiuiBrowser\/([0-9\.]+)$/],
        ["beaker", /BeakerBrowser\/([0-9\.]+)/],
        ["edge-chromium", /EdgA?\/([0-9\.]+)/],
        ["chromium-webview", /(?!Chrom.*OPR)wv\).*Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
        ["chrome", /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
        ["phantomjs", /PhantomJS\/([0-9\.]+)(:?\s|$)/],
        ["crios", /CriOS\/([0-9\.]+)(:?\s|$)/],
        ["firefox", /Firefox\/([0-9\.]+)(?:\s|$)/],
        ["fxios", /FxiOS\/([0-9\.]+)/],
        ["opera-mini", /Opera Mini.*Version\/([0-9\.]+)/],
        ["opera", /Opera\/([0-9\.]+)(?:\s|$)/],
        ["opera", /OPR\/([0-9\.]+)(:?\s|$)/],
        ["ie", /Trident\/7\.0.*rv\:([0-9\.]+).*\).*Gecko$/],
        ["ie", /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
        ["ie", /MSIE\s(7\.0)/],
        ["bb10", /BB10;\sTouch.*Version\/([0-9\.]+)/],
        ["android", /Android\s([0-9\.]+)/],
        ["ios", /Version\/([0-9\._]+).*Mobile.*Safari.*/],
        ["safari", /Version\/([0-9\._]+).*Safari/],
        ["facebook", /FBAV\/([0-9\.]+)/],
        ["instagram", /Instagram\s([0-9\.]+)/],
        ["ios-webview", /AppleWebKit\/([0-9\.]+).*Mobile/],
        ["ios-webview", /AppleWebKit\/([0-9\.]+).*Gecko\)$/],
        ["searchbot", xa]
    ],
    xr = [
        ["iOS", /iP(hone|od|ad)/],
        ["Android OS", /Android/],
        ["BlackBerry OS", /BlackBerry|BB10/],
        ["Windows Mobile", /IEMobile/],
        ["Amazon OS", /Kindle/],
        ["Windows 3.11", /Win16/],
        ["Windows 95", /(Windows 95)|(Win95)|(Windows_95)/],
        ["Windows 98", /(Windows 98)|(Win98)/],
        ["Windows 2000", /(Windows NT 5.0)|(Windows 2000)/],
        ["Windows XP", /(Windows NT 5.1)|(Windows XP)/],
        ["Windows Server 2003", /(Windows NT 5.2)/],
        ["Windows Vista", /(Windows NT 6.0)/],
        ["Windows 7", /(Windows NT 6.1)/],
        ["Windows 8", /(Windows NT 6.2)/],
        ["Windows 8.1", /(Windows NT 6.3)/],
        ["Windows 10", /(Windows NT 10.0)/],
        ["Windows ME", /Windows ME/],
        ["Open BSD", /OpenBSD/],
        ["Sun OS", /SunOS/],
        ["Chrome OS", /CrOS/],
        ["Linux", /(Linux)|(X11)/],
        ["Mac OS", /(Mac_PowerPC)|(Macintosh)/],
        ["QNX", /QNX/],
        ["BeOS", /BeOS/],
        ["OS/2", /OS\/2/]
    ];

function Ca(t) {
    return t ? Sr(t) : typeof document > "u" && typeof navigator < "u" && navigator.product === "ReactNative" ? new Ma : typeof navigator < "u" ? Sr(navigator.userAgent) : Aa()
}

function ka(t) {
    return t !== "" && Ea.reduce(function(e, n) {
        var r = n[0],
            s = n[1];
        if (e) return e;
        var o = s.exec(t);
        return !!o && [r, o]
    }, !1)
}

function Sr(t) {
    var e = ka(t);
    if (!e) return null;
    var n = e[0],
        r = e[1];
    if (n === "searchbot") return new ba;
    var s = r[1] && r[1].split(/[._]/).slice(0, 3);
    s ? s.length < Mr && (s = ma(s, Ta(Mr - s.length))) : s = [];
    var o = s.join("."),
        h = Ra(t),
        m = Sa.exec(t);
    return m && m[1] ? new ya(n, o, h, m[1]) : new va(n, o, h)
}

function Ra(t) {
    for (var e = 0, n = xr.length; e < n; e++) {
        var r = xr[e],
            s = r[0],
            o = r[1],
            h = o.exec(t);
        if (h) return s
    }
    return null
}

function Aa() {
    var t = typeof process < "u" && process.version;
    return t ? new wa(process.version.slice(1)) : null
}

function Ta(t) {
    for (var e = [], n = 0; n < t; n++) e.push("0");
    return e
}

function nn(t) {
    return Ca(t)
}

function rn() {
    const t = nn();
    return t && t.os ? t.os : void 0
}

function _i() {
    const t = rn();
    return t ? t.toLowerCase().includes("android") : !1
}

function mi() {
    const t = rn();
    return t ? t.toLowerCase().includes("ios") || t.toLowerCase().includes("mac") && navigator.maxTouchPoints > 1 : !1
}

function vi() {
    return rn() ? _i() || mi() : !1
}

function wi() {
    const t = nn();
    return t && t.name ? t.name.toLowerCase() === "node" : !1
}

function yi() {
    return !wi() && !!bi()
}
const Ia = ii,
    Na = oi,
    Oa = ai,
    Ba = si,
    La = li,
    bi = ci,
    Pa = fi,
    Mi = ui,
    Fa = hi,
    Ua = di,
    Da = pi,
    on = ri;

function Ln() {
    return gi()
}

function qa(t) {
    if (typeof t != "string") throw new Error(`Cannot safe json parse value of type ${typeof t}`);
    try {
        return JSON.parse(t)
    } catch (e) {
        return t
    }
}

function $a(t) {
    return typeof t == "string" ? t : JSON.stringify(t)
}
const xi = qa,
    Si = $a;

function Gn(t, e) {
    const n = Si(e),
        r = on();
    r && r.setItem(t, n)
}

function Zn(t) {
    let e = null,
        n = null;
    const r = on();
    return r && (n = r.getItem(t)), e = n && xi(n), e
}

function Xn(t) {
    const e = on();
    e && e.removeItem(t)
}
const Yt = "WALLETCONNECT_DEEPLINK_CHOICE";

function Wa(t, e) {
    const n = encodeURIComponent(t);
    return e.universalLink ? `${e.universalLink}/wc?uri=${n}` : e.deepLink ? `${e.deepLink}${e.deepLink.endsWith(":")?"//":"/"}wc?uri=${n}` : ""
}

function Ha(t) {
    const e = t.href.split("?")[0];
    Gn(Yt, Object.assign(Object.assign({}, t), {
        href: e
    }))
}

function Ei(t, e) {
    return t.filter(n => n.name.toLowerCase().includes(e.toLowerCase()))[0]
}

function za(t, e) {
    let n = t;
    return e && (n = e.map(r => Ei(t, r)).filter(Boolean)), n
}
const Ci = "https://registry.walletconnect.com";

function ja() {
    return Ci + "/api/v2/wallets"
}

function Ka() {
    return Ci + "/api/v2/dapps"
}

function ki(t, e = "mobile") {
    var n;
    return {
        name: t.name || "",
        shortName: t.metadata.shortName || "",
        color: t.metadata.colors.primary || "",
        logo: (n = t.image_url.sm) !== null && n !== void 0 ? n : "",
        universalLink: t[e].universal || "",
        deepLink: t[e].native || ""
    }
}

function Ja(t, e = "mobile") {
    return Object.values(t).filter(n => !!n[e].universal || !!n[e].native).map(n => ki(n, e))
}
var Va = Object.freeze(Object.defineProperty({
    __proto__: null,
    detectEnv: nn,
    detectOS: rn,
    isAndroid: _i,
    isIOS: mi,
    isMobile: vi,
    isNode: wi,
    isBrowser: yi,
    getFromWindow: Ia,
    getFromWindowOrThrow: Na,
    getDocumentOrThrow: Oa,
    getDocument: Ba,
    getNavigatorOrThrow: La,
    getNavigator: bi,
    getLocationOrThrow: Pa,
    getLocation: Mi,
    getCryptoOrThrow: Fa,
    getCrypto: Ua,
    getLocalStorageOrThrow: Da,
    getLocalStorage: on,
    getClientMeta: Ln,
    safeJsonParse: xi,
    safeJsonStringify: Si,
    setLocal: Gn,
    getLocal: Zn,
    removeLocal: Xn,
    mobileLinkChoiceKey: Yt,
    formatIOSMobile: Wa,
    saveMobileLinkInfo: Ha,
    getMobileRegistryEntry: Ei,
    getMobileLinkRegistry: za,
    getWalletRegistryUrl: ja,
    getDappRegistryUrl: Ka,
    formatMobileRegistryEntry: ki,
    formatMobileRegistry: Ja
}, Symbol.toStringTag, {
    value: "Module"
}));
const Ya = ["session_request", "session_update", "exchange_key", "connect", "disconnect", "display_uri", "modal_closed", "transport_open", "transport_close", "transport_error"],
    Ri = ["eth_sendTransaction", "eth_signTransaction", "eth_sign", "eth_signTypedData", "eth_signTypedData_v1", "eth_signTypedData_v2", "eth_signTypedData_v3", "eth_signTypedData_v4", "personal_sign", "wallet_addEthereumChain", "wallet_switchEthereumChain", "wallet_getPermissions", "wallet_requestPermissions", "wallet_registerOnboarding", "wallet_watchAsset", "wallet_scanQRCode"];
var Ai = {
    exports: {}
};
(function(t) {
    (function(e, n) {
        function r(_, i) {
            if (!_) throw new Error(i || "Assertion failed")
        }

        function s(_, i) {
            _.super_ = i;
            var l = function() {};
            l.prototype = i.prototype, _.prototype = new l, _.prototype.constructor = _
        }

        function o(_, i, l) {
            if (o.isBN(_)) return _;
            this.negative = 0, this.words = null, this.length = 0, this.red = null, _ !== null && ((i === "le" || i === "be") && (l = i, i = 10), this._init(_ || 0, i || 10, l || "be"))
        }
        typeof e == "object" ? e.exports = o : n.BN = o, o.BN = o, o.wordSize = 26;
        var h;
        try {
            h = require("buffer").Buffer
        } catch (_) {}
        o.isBN = function(i) {
            return i instanceof o ? !0 : i !== null && typeof i == "object" && i.constructor.wordSize === o.wordSize && Array.isArray(i.words)
        }, o.max = function(i, l) {
            return i.cmp(l) > 0 ? i : l
        }, o.min = function(i, l) {
            return i.cmp(l) < 0 ? i : l
        }, o.prototype._init = function(i, l, f) {
            if (typeof i == "number") return this._initNumber(i, l, f);
            if (typeof i == "object") return this._initArray(i, l, f);
            l === "hex" && (l = 16), r(l === (l | 0) && l >= 2 && l <= 36), i = i.toString().replace(/\s+/g, "");
            var u = 0;
            i[0] === "-" && u++, l === 16 ? this._parseHex(i, u) : this._parseBase(i, l, u), i[0] === "-" && (this.negative = 1), this.strip(), f === "le" && this._initArray(this.toArray(), l, f)
        }, o.prototype._initNumber = function(i, l, f) {
            i < 0 && (this.negative = 1, i = -i), i < 67108864 ? (this.words = [i & 67108863], this.length = 1) : i < 4503599627370496 ? (this.words = [i & 67108863, i / 67108864 & 67108863], this.length = 2) : (r(i < 9007199254740992), this.words = [i & 67108863, i / 67108864 & 67108863, 1], this.length = 3), f === "le" && this._initArray(this.toArray(), l, f)
        }, o.prototype._initArray = function(i, l, f) {
            if (r(typeof i.length == "number"), i.length <= 0) return this.words = [0], this.length = 1, this;
            this.length = Math.ceil(i.length / 3), this.words = new Array(this.length);
            for (var u = 0; u < this.length; u++) this.words[u] = 0;
            var g, w, x = 0;
            if (f === "be")
                for (u = i.length - 1, g = 0; u >= 0; u -= 3) w = i[u] | i[u - 1] << 8 | i[u - 2] << 16, this.words[g] |= w << x & 67108863, this.words[g + 1] = w >>> 26 - x & 67108863, x += 24, x >= 26 && (x -= 26, g++);
            else if (f === "le")
                for (u = 0, g = 0; u < i.length; u += 3) w = i[u] | i[u + 1] << 8 | i[u + 2] << 16, this.words[g] |= w << x & 67108863, this.words[g + 1] = w >>> 26 - x & 67108863, x += 24, x >= 26 && (x -= 26, g++);
            return this.strip()
        };

        function m(_, i, l) {
            for (var f = 0, u = Math.min(_.length, l), g = i; g < u; g++) {
                var w = _.charCodeAt(g) - 48;
                f <<= 4, w >= 49 && w <= 54 ? f |= w - 49 + 10 : w >= 17 && w <= 22 ? f |= w - 17 + 10 : f |= w & 15
            }
            return f
        }
        o.prototype._parseHex = function(i, l) {
            this.length = Math.ceil((i.length - l) / 6), this.words = new Array(this.length);
            for (var f = 0; f < this.length; f++) this.words[f] = 0;
            var u, g, w = 0;
            for (f = i.length - 6, u = 0; f >= l; f -= 6) g = m(i, f, f + 6), this.words[u] |= g << w & 67108863, this.words[u + 1] |= g >>> 26 - w & 4194303, w += 24, w >= 26 && (w -= 26, u++);
            f + 6 !== l && (g = m(i, l, f + 6), this.words[u] |= g << w & 67108863, this.words[u + 1] |= g >>> 26 - w & 4194303), this.strip()
        };

        function v(_, i, l, f) {
            for (var u = 0, g = Math.min(_.length, l), w = i; w < g; w++) {
                var x = _.charCodeAt(w) - 48;
                u *= f, x >= 49 ? u += x - 49 + 10 : x >= 17 ? u += x - 17 + 10 : u += x
            }
            return u
        }
        o.prototype._parseBase = function(i, l, f) {
            this.words = [0], this.length = 1;
            for (var u = 0, g = 1; g <= 67108863; g *= l) u++;
            u--, g = g / l | 0;
            for (var w = i.length - f, x = w % u, d = Math.min(w, w - x) + f, a = 0, p = f; p < d; p += u) a = v(i, p, p + u, l), this.imuln(g), this.words[0] + a < 67108864 ? this.words[0] += a : this._iaddn(a);
            if (x !== 0) {
                var H = 1;
                for (a = v(i, p, i.length, l), p = 0; p < x; p++) H *= l;
                this.imuln(H), this.words[0] + a < 67108864 ? this.words[0] += a : this._iaddn(a)
            }
        }, o.prototype.copy = function(i) {
            i.words = new Array(this.length);
            for (var l = 0; l < this.length; l++) i.words[l] = this.words[l];
            i.length = this.length, i.negative = this.negative, i.red = this.red
        }, o.prototype.clone = function() {
            var i = new o(null);
            return this.copy(i), i
        }, o.prototype._expand = function(i) {
            for (; this.length < i;) this.words[this.length++] = 0;
            return this
        }, o.prototype.strip = function() {
            for (; this.length > 1 && this.words[this.length - 1] === 0;) this.length--;
            return this._normSign()
        }, o.prototype._normSign = function() {
            return this.length === 1 && this.words[0] === 0 && (this.negative = 0), this
        }, o.prototype.inspect = function() {
            return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">"
        };
        var M = ["", "0", "00", "000", "0000", "00000", "000000", "0000000", "00000000", "000000000", "0000000000", "00000000000", "000000000000", "0000000000000", "00000000000000", "000000000000000", "0000000000000000", "00000000000000000", "000000000000000000", "0000000000000000000", "00000000000000000000", "000000000000000000000", "0000000000000000000000", "00000000000000000000000", "000000000000000000000000", "0000000000000000000000000"],
            y = [0, 0, 25, 16, 12, 11, 10, 9, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
            I = [0, 0, 33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216, 43046721, 1e7, 19487171, 35831808, 62748517, 7529536, 11390625, 16777216, 24137569, 34012224, 47045881, 64e6, 4084101, 5153632, 6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149, 243e5, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176];
        o.prototype.toString = function(i, l) {
            i = i || 10, l = l | 0 || 1;
            var f;
            if (i === 16 || i === "hex") {
                f = "";
                for (var u = 0, g = 0, w = 0; w < this.length; w++) {
                    var x = this.words[w],
                        d = ((x << u | g) & 16777215).toString(16);
                    g = x >>> 24 - u & 16777215, g !== 0 || w !== this.length - 1 ? f = M[6 - d.length] + d + f : f = d + f, u += 2, u >= 26 && (u -= 26, w--)
                }
                for (g !== 0 && (f = g.toString(16) + f); f.length % l !== 0;) f = "0" + f;
                return this.negative !== 0 && (f = "-" + f), f
            }
            if (i === (i | 0) && i >= 2 && i <= 36) {
                var a = y[i],
                    p = I[i];
                f = "";
                var H = this.clone();
                for (H.negative = 0; !H.isZero();) {
                    var L = H.modn(p).toString(i);
                    H = H.idivn(p), H.isZero() ? f = L + f : f = M[a - L.length] + L + f
                }
                for (this.isZero() && (f = "0" + f); f.length % l !== 0;) f = "0" + f;
                return this.negative !== 0 && (f = "-" + f), f
            }
            r(!1, "Base should be between 2 and 36")
        }, o.prototype.toNumber = function() {
            var i = this.words[0];
            return this.length === 2 ? i += this.words[1] * 67108864 : this.length === 3 && this.words[2] === 1 ? i += 4503599627370496 + this.words[1] * 67108864 : this.length > 2 && r(!1, "Number can only safely store up to 53 bits"), this.negative !== 0 ? -i : i
        }, o.prototype.toJSON = function() {
            return this.toString(16)
        }, o.prototype.toBuffer = function(i, l) {
            return r(typeof h < "u"), this.toArrayLike(h, i, l)
        }, o.prototype.toArray = function(i, l) {
            return this.toArrayLike(Array, i, l)
        }, o.prototype.toArrayLike = function(i, l, f) {
            var u = this.byteLength(),
                g = f || Math.max(1, u);
            r(u <= g, "byte array longer than desired length"), r(g > 0, "Requested array length <= 0"), this.strip();
            var w = l === "le",
                x = new i(g),
                d, a, p = this.clone();
            if (w) {
                for (a = 0; !p.isZero(); a++) d = p.andln(255), p.iushrn(8), x[a] = d;
                for (; a < g; a++) x[a] = 0
            } else {
                for (a = 0; a < g - u; a++) x[a] = 0;
                for (a = 0; !p.isZero(); a++) d = p.andln(255), p.iushrn(8), x[g - a - 1] = d
            }
            return x
        }, Math.clz32 ? o.prototype._countBits = function(i) {
            return 32 - Math.clz32(i)
        } : o.prototype._countBits = function(i) {
            var l = i,
                f = 0;
            return l >= 4096 && (f += 13, l >>>= 13), l >= 64 && (f += 7, l >>>= 7), l >= 8 && (f += 4, l >>>= 4), l >= 2 && (f += 2, l >>>= 2), f + l
        }, o.prototype._zeroBits = function(i) {
            if (i === 0) return 26;
            var l = i,
                f = 0;
            return (l & 8191) === 0 && (f += 13, l >>>= 13), (l & 127) === 0 && (f += 7, l >>>= 7), (l & 15) === 0 && (f += 4, l >>>= 4), (l & 3) === 0 && (f += 2, l >>>= 2), (l & 1) === 0 && f++, f
        }, o.prototype.bitLength = function() {
            var i = this.words[this.length - 1],
                l = this._countBits(i);
            return (this.length - 1) * 26 + l
        };

        function B(_) {
            for (var i = new Array(_.bitLength()), l = 0; l < i.length; l++) {
                var f = l / 26 | 0,
                    u = l % 26;
                i[l] = (_.words[f] & 1 << u) >>> u
            }
            return i
        }
        o.prototype.zeroBits = function() {
            if (this.isZero()) return 0;
            for (var i = 0, l = 0; l < this.length; l++) {
                var f = this._zeroBits(this.words[l]);
                if (i += f, f !== 26) break
            }
            return i
        }, o.prototype.byteLength = function() {
            return Math.ceil(this.bitLength() / 8)
        }, o.prototype.toTwos = function(i) {
            return this.negative !== 0 ? this.abs().inotn(i).iaddn(1) : this.clone()
        }, o.prototype.fromTwos = function(i) {
            return this.testn(i - 1) ? this.notn(i).iaddn(1).ineg() : this.clone()
        }, o.prototype.isNeg = function() {
            return this.negative !== 0
        }, o.prototype.neg = function() {
            return this.clone().ineg()
        }, o.prototype.ineg = function() {
            return this.isZero() || (this.negative ^= 1), this
        }, o.prototype.iuor = function(i) {
            for (; this.length < i.length;) this.words[this.length++] = 0;
            for (var l = 0; l < i.length; l++) this.words[l] = this.words[l] | i.words[l];
            return this.strip()
        }, o.prototype.ior = function(i) {
            return r((this.negative | i.negative) === 0), this.iuor(i)
        }, o.prototype.or = function(i) {
            return this.length > i.length ? this.clone().ior(i) : i.clone().ior(this)
        }, o.prototype.uor = function(i) {
            return this.length > i.length ? this.clone().iuor(i) : i.clone().iuor(this)
        }, o.prototype.iuand = function(i) {
            var l;
            this.length > i.length ? l = i : l = this;
            for (var f = 0; f < l.length; f++) this.words[f] = this.words[f] & i.words[f];
            return this.length = l.length, this.strip()
        }, o.prototype.iand = function(i) {
            return r((this.negative | i.negative) === 0), this.iuand(i)
        }, o.prototype.and = function(i) {
            return this.length > i.length ? this.clone().iand(i) : i.clone().iand(this)
        }, o.prototype.uand = function(i) {
            return this.length > i.length ? this.clone().iuand(i) : i.clone().iuand(this)
        }, o.prototype.iuxor = function(i) {
            var l, f;
            this.length > i.length ? (l = this, f = i) : (l = i, f = this);
            for (var u = 0; u < f.length; u++) this.words[u] = l.words[u] ^ f.words[u];
            if (this !== l)
                for (; u < l.length; u++) this.words[u] = l.words[u];
            return this.length = l.length, this.strip()
        }, o.prototype.ixor = function(i) {
            return r((this.negative | i.negative) === 0), this.iuxor(i)
        }, o.prototype.xor = function(i) {
            return this.length > i.length ? this.clone().ixor(i) : i.clone().ixor(this)
        }, o.prototype.uxor = function(i) {
            return this.length > i.length ? this.clone().iuxor(i) : i.clone().iuxor(this)
        }, o.prototype.inotn = function(i) {
            r(typeof i == "number" && i >= 0);
            var l = Math.ceil(i / 26) | 0,
                f = i % 26;
            this._expand(l), f > 0 && l--;
            for (var u = 0; u < l; u++) this.words[u] = ~this.words[u] & 67108863;
            return f > 0 && (this.words[u] = ~this.words[u] & 67108863 >> 26 - f), this.strip()
        }, o.prototype.notn = function(i) {
            return this.clone().inotn(i)
        }, o.prototype.setn = function(i, l) {
            r(typeof i == "number" && i >= 0);
            var f = i / 26 | 0,
                u = i % 26;
            return this._expand(f + 1), l ? this.words[f] = this.words[f] | 1 << u : this.words[f] = this.words[f] & ~(1 << u), this.strip()
        }, o.prototype.iadd = function(i) {
            var l;
            if (this.negative !== 0 && i.negative === 0) return this.negative = 0, l = this.isub(i), this.negative ^= 1, this._normSign();
            if (this.negative === 0 && i.negative !== 0) return i.negative = 0, l = this.isub(i), i.negative = 1, l._normSign();
            var f, u;
            this.length > i.length ? (f = this, u = i) : (f = i, u = this);
            for (var g = 0, w = 0; w < u.length; w++) l = (f.words[w] | 0) + (u.words[w] | 0) + g, this.words[w] = l & 67108863, g = l >>> 26;
            for (; g !== 0 && w < f.length; w++) l = (f.words[w] | 0) + g, this.words[w] = l & 67108863, g = l >>> 26;
            if (this.length = f.length, g !== 0) this.words[this.length] = g, this.length++;
            else if (f !== this)
                for (; w < f.length; w++) this.words[w] = f.words[w];
            return this
        }, o.prototype.add = function(i) {
            var l;
            return i.negative !== 0 && this.negative === 0 ? (i.negative = 0, l = this.sub(i), i.negative ^= 1, l) : i.negative === 0 && this.negative !== 0 ? (this.negative = 0, l = i.sub(this), this.negative = 1, l) : this.length > i.length ? this.clone().iadd(i) : i.clone().iadd(this)
        }, o.prototype.isub = function(i) {
            if (i.negative !== 0) {
                i.negative = 0;
                var l = this.iadd(i);
                return i.negative = 1, l._normSign()
            } else if (this.negative !== 0) return this.negative = 0, this.iadd(i), this.negative = 1, this._normSign();
            var f = this.cmp(i);
            if (f === 0) return this.negative = 0, this.length = 1, this.words[0] = 0, this;
            var u, g;
            f > 0 ? (u = this, g = i) : (u = i, g = this);
            for (var w = 0, x = 0; x < g.length; x++) l = (u.words[x] | 0) - (g.words[x] | 0) + w, w = l >> 26, this.words[x] = l & 67108863;
            for (; w !== 0 && x < u.length; x++) l = (u.words[x] | 0) + w, w = l >> 26, this.words[x] = l & 67108863;
            if (w === 0 && x < u.length && u !== this)
                for (; x < u.length; x++) this.words[x] = u.words[x];
            return this.length = Math.max(this.length, x), u !== this && (this.negative = 1), this.strip()
        }, o.prototype.sub = function(i) {
            return this.clone().isub(i)
        };

        function P(_, i, l) {
            l.negative = i.negative ^ _.negative;
            var f = _.length + i.length | 0;
            l.length = f, f = f - 1 | 0;
            var u = _.words[0] | 0,
                g = i.words[0] | 0,
                w = u * g,
                x = w & 67108863,
                d = w / 67108864 | 0;
            l.words[0] = x;
            for (var a = 1; a < f; a++) {
                for (var p = d >>> 26, H = d & 67108863, L = Math.min(a, i.length - 1), j = Math.max(0, a - _.length + 1); j <= L; j++) {
                    var V = a - j | 0;
                    u = _.words[V] | 0, g = i.words[j] | 0, w = u * g + H, p += w / 67108864 | 0, H = w & 67108863
                }
                l.words[a] = H | 0, d = p | 0
            }
            return d !== 0 ? l.words[a] = d | 0 : l.length--, l.strip()
        }
        var N = function(i, l, f) {
            var u = i.words,
                g = l.words,
                w = f.words,
                x = 0,
                d, a, p, H = u[0] | 0,
                L = H & 8191,
                j = H >>> 13,
                V = u[1] | 0,
                c = V & 8191,
                k = V >>> 13,
                T = u[2] | 0,
                A = T & 8191,
                O = T >>> 13,
                K = u[3] | 0,
                q = K & 8191,
                F = K >>> 13,
                Ie = u[4] | 0,
                $ = Ie & 8191,
                G = Ie >>> 13,
                rt = u[5] | 0,
                te = rt & 8191,
                ne = rt >>> 13,
                it = u[6] | 0,
                re = it & 8191,
                ie = it >>> 13,
                ot = u[7] | 0,
                oe = ot & 8191,
                ae = ot >>> 13,
                at = u[8] | 0,
                se = at & 8191,
                le = at >>> 13,
                st = u[9] | 0,
                ce = st & 8191,
                fe = st >>> 13,
                lt = g[0] | 0,
                ue = lt & 8191,
                he = lt >>> 13,
                ct = g[1] | 0,
                de = ct & 8191,
                pe = ct >>> 13,
                ft = g[2] | 0,
                ge = ft & 8191,
                _e = ft >>> 13,
                ut = g[3] | 0,
                me = ut & 8191,
                ve = ut >>> 13,
                ht = g[4] | 0,
                we = ht & 8191,
                ye = ht >>> 13,
                dt = g[5] | 0,
                be = dt & 8191,
                Me = dt >>> 13,
                pt = g[6] | 0,
                xe = pt & 8191,
                Se = pt >>> 13,
                gt = g[7] | 0,
                Ee = gt & 8191,
                Ce = gt >>> 13,
                _t = g[8] | 0,
                ke = _t & 8191,
                Re = _t >>> 13,
                mt = g[9] | 0,
                Ae = mt & 8191,
                Te = mt >>> 13;
            f.negative = i.negative ^ l.negative, f.length = 19, d = Math.imul(L, ue), a = Math.imul(L, he), a = a + Math.imul(j, ue) | 0, p = Math.imul(j, he);
            var $e = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + ($e >>> 26) | 0, $e &= 67108863, d = Math.imul(c, ue), a = Math.imul(c, he), a = a + Math.imul(k, ue) | 0, p = Math.imul(k, he), d = d + Math.imul(L, de) | 0, a = a + Math.imul(L, pe) | 0, a = a + Math.imul(j, de) | 0, p = p + Math.imul(j, pe) | 0;
            var We = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (We >>> 26) | 0, We &= 67108863, d = Math.imul(A, ue), a = Math.imul(A, he), a = a + Math.imul(O, ue) | 0, p = Math.imul(O, he), d = d + Math.imul(c, de) | 0, a = a + Math.imul(c, pe) | 0, a = a + Math.imul(k, de) | 0, p = p + Math.imul(k, pe) | 0, d = d + Math.imul(L, ge) | 0, a = a + Math.imul(L, _e) | 0, a = a + Math.imul(j, ge) | 0, p = p + Math.imul(j, _e) | 0;
            var He = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (He >>> 26) | 0, He &= 67108863, d = Math.imul(q, ue), a = Math.imul(q, he), a = a + Math.imul(F, ue) | 0, p = Math.imul(F, he), d = d + Math.imul(A, de) | 0, a = a + Math.imul(A, pe) | 0, a = a + Math.imul(O, de) | 0, p = p + Math.imul(O, pe) | 0, d = d + Math.imul(c, ge) | 0, a = a + Math.imul(c, _e) | 0, a = a + Math.imul(k, ge) | 0, p = p + Math.imul(k, _e) | 0, d = d + Math.imul(L, me) | 0, a = a + Math.imul(L, ve) | 0, a = a + Math.imul(j, me) | 0, p = p + Math.imul(j, ve) | 0;
            var ze = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (ze >>> 26) | 0, ze &= 67108863, d = Math.imul($, ue), a = Math.imul($, he), a = a + Math.imul(G, ue) | 0, p = Math.imul(G, he), d = d + Math.imul(q, de) | 0, a = a + Math.imul(q, pe) | 0, a = a + Math.imul(F, de) | 0, p = p + Math.imul(F, pe) | 0, d = d + Math.imul(A, ge) | 0, a = a + Math.imul(A, _e) | 0, a = a + Math.imul(O, ge) | 0, p = p + Math.imul(O, _e) | 0, d = d + Math.imul(c, me) | 0, a = a + Math.imul(c, ve) | 0, a = a + Math.imul(k, me) | 0, p = p + Math.imul(k, ve) | 0, d = d + Math.imul(L, we) | 0, a = a + Math.imul(L, ye) | 0, a = a + Math.imul(j, we) | 0, p = p + Math.imul(j, ye) | 0;
            var je = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (je >>> 26) | 0, je &= 67108863, d = Math.imul(te, ue), a = Math.imul(te, he), a = a + Math.imul(ne, ue) | 0, p = Math.imul(ne, he), d = d + Math.imul($, de) | 0, a = a + Math.imul($, pe) | 0, a = a + Math.imul(G, de) | 0, p = p + Math.imul(G, pe) | 0, d = d + Math.imul(q, ge) | 0, a = a + Math.imul(q, _e) | 0, a = a + Math.imul(F, ge) | 0, p = p + Math.imul(F, _e) | 0, d = d + Math.imul(A, me) | 0, a = a + Math.imul(A, ve) | 0, a = a + Math.imul(O, me) | 0, p = p + Math.imul(O, ve) | 0, d = d + Math.imul(c, we) | 0, a = a + Math.imul(c, ye) | 0, a = a + Math.imul(k, we) | 0, p = p + Math.imul(k, ye) | 0, d = d + Math.imul(L, be) | 0, a = a + Math.imul(L, Me) | 0, a = a + Math.imul(j, be) | 0, p = p + Math.imul(j, Me) | 0;
            var Ke = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (Ke >>> 26) | 0, Ke &= 67108863, d = Math.imul(re, ue), a = Math.imul(re, he), a = a + Math.imul(ie, ue) | 0, p = Math.imul(ie, he), d = d + Math.imul(te, de) | 0, a = a + Math.imul(te, pe) | 0, a = a + Math.imul(ne, de) | 0, p = p + Math.imul(ne, pe) | 0, d = d + Math.imul($, ge) | 0, a = a + Math.imul($, _e) | 0, a = a + Math.imul(G, ge) | 0, p = p + Math.imul(G, _e) | 0, d = d + Math.imul(q, me) | 0, a = a + Math.imul(q, ve) | 0, a = a + Math.imul(F, me) | 0, p = p + Math.imul(F, ve) | 0, d = d + Math.imul(A, we) | 0, a = a + Math.imul(A, ye) | 0, a = a + Math.imul(O, we) | 0, p = p + Math.imul(O, ye) | 0, d = d + Math.imul(c, be) | 0, a = a + Math.imul(c, Me) | 0, a = a + Math.imul(k, be) | 0, p = p + Math.imul(k, Me) | 0, d = d + Math.imul(L, xe) | 0, a = a + Math.imul(L, Se) | 0, a = a + Math.imul(j, xe) | 0, p = p + Math.imul(j, Se) | 0;
            var Je = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (Je >>> 26) | 0, Je &= 67108863, d = Math.imul(oe, ue), a = Math.imul(oe, he), a = a + Math.imul(ae, ue) | 0, p = Math.imul(ae, he), d = d + Math.imul(re, de) | 0, a = a + Math.imul(re, pe) | 0, a = a + Math.imul(ie, de) | 0, p = p + Math.imul(ie, pe) | 0, d = d + Math.imul(te, ge) | 0, a = a + Math.imul(te, _e) | 0, a = a + Math.imul(ne, ge) | 0, p = p + Math.imul(ne, _e) | 0, d = d + Math.imul($, me) | 0, a = a + Math.imul($, ve) | 0, a = a + Math.imul(G, me) | 0, p = p + Math.imul(G, ve) | 0, d = d + Math.imul(q, we) | 0, a = a + Math.imul(q, ye) | 0, a = a + Math.imul(F, we) | 0, p = p + Math.imul(F, ye) | 0, d = d + Math.imul(A, be) | 0, a = a + Math.imul(A, Me) | 0, a = a + Math.imul(O, be) | 0, p = p + Math.imul(O, Me) | 0, d = d + Math.imul(c, xe) | 0, a = a + Math.imul(c, Se) | 0, a = a + Math.imul(k, xe) | 0, p = p + Math.imul(k, Se) | 0, d = d + Math.imul(L, Ee) | 0, a = a + Math.imul(L, Ce) | 0, a = a + Math.imul(j, Ee) | 0, p = p + Math.imul(j, Ce) | 0;
            var Ve = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (Ve >>> 26) | 0, Ve &= 67108863, d = Math.imul(se, ue), a = Math.imul(se, he), a = a + Math.imul(le, ue) | 0, p = Math.imul(le, he), d = d + Math.imul(oe, de) | 0, a = a + Math.imul(oe, pe) | 0, a = a + Math.imul(ae, de) | 0, p = p + Math.imul(ae, pe) | 0, d = d + Math.imul(re, ge) | 0, a = a + Math.imul(re, _e) | 0, a = a + Math.imul(ie, ge) | 0, p = p + Math.imul(ie, _e) | 0, d = d + Math.imul(te, me) | 0, a = a + Math.imul(te, ve) | 0, a = a + Math.imul(ne, me) | 0, p = p + Math.imul(ne, ve) | 0, d = d + Math.imul($, we) | 0, a = a + Math.imul($, ye) | 0, a = a + Math.imul(G, we) | 0, p = p + Math.imul(G, ye) | 0, d = d + Math.imul(q, be) | 0, a = a + Math.imul(q, Me) | 0, a = a + Math.imul(F, be) | 0, p = p + Math.imul(F, Me) | 0, d = d + Math.imul(A, xe) | 0, a = a + Math.imul(A, Se) | 0, a = a + Math.imul(O, xe) | 0, p = p + Math.imul(O, Se) | 0, d = d + Math.imul(c, Ee) | 0, a = a + Math.imul(c, Ce) | 0, a = a + Math.imul(k, Ee) | 0, p = p + Math.imul(k, Ce) | 0, d = d + Math.imul(L, ke) | 0, a = a + Math.imul(L, Re) | 0, a = a + Math.imul(j, ke) | 0, p = p + Math.imul(j, Re) | 0;
            var pn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (pn >>> 26) | 0, pn &= 67108863, d = Math.imul(ce, ue), a = Math.imul(ce, he), a = a + Math.imul(fe, ue) | 0, p = Math.imul(fe, he), d = d + Math.imul(se, de) | 0, a = a + Math.imul(se, pe) | 0, a = a + Math.imul(le, de) | 0, p = p + Math.imul(le, pe) | 0, d = d + Math.imul(oe, ge) | 0, a = a + Math.imul(oe, _e) | 0, a = a + Math.imul(ae, ge) | 0, p = p + Math.imul(ae, _e) | 0, d = d + Math.imul(re, me) | 0, a = a + Math.imul(re, ve) | 0, a = a + Math.imul(ie, me) | 0, p = p + Math.imul(ie, ve) | 0, d = d + Math.imul(te, we) | 0, a = a + Math.imul(te, ye) | 0, a = a + Math.imul(ne, we) | 0, p = p + Math.imul(ne, ye) | 0, d = d + Math.imul($, be) | 0, a = a + Math.imul($, Me) | 0, a = a + Math.imul(G, be) | 0, p = p + Math.imul(G, Me) | 0, d = d + Math.imul(q, xe) | 0, a = a + Math.imul(q, Se) | 0, a = a + Math.imul(F, xe) | 0, p = p + Math.imul(F, Se) | 0, d = d + Math.imul(A, Ee) | 0, a = a + Math.imul(A, Ce) | 0, a = a + Math.imul(O, Ee) | 0, p = p + Math.imul(O, Ce) | 0, d = d + Math.imul(c, ke) | 0, a = a + Math.imul(c, Re) | 0, a = a + Math.imul(k, ke) | 0, p = p + Math.imul(k, Re) | 0, d = d + Math.imul(L, Ae) | 0, a = a + Math.imul(L, Te) | 0, a = a + Math.imul(j, Ae) | 0, p = p + Math.imul(j, Te) | 0;
            var gn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (gn >>> 26) | 0, gn &= 67108863, d = Math.imul(ce, de), a = Math.imul(ce, pe), a = a + Math.imul(fe, de) | 0, p = Math.imul(fe, pe), d = d + Math.imul(se, ge) | 0, a = a + Math.imul(se, _e) | 0, a = a + Math.imul(le, ge) | 0, p = p + Math.imul(le, _e) | 0, d = d + Math.imul(oe, me) | 0, a = a + Math.imul(oe, ve) | 0, a = a + Math.imul(ae, me) | 0, p = p + Math.imul(ae, ve) | 0, d = d + Math.imul(re, we) | 0, a = a + Math.imul(re, ye) | 0, a = a + Math.imul(ie, we) | 0, p = p + Math.imul(ie, ye) | 0, d = d + Math.imul(te, be) | 0, a = a + Math.imul(te, Me) | 0, a = a + Math.imul(ne, be) | 0, p = p + Math.imul(ne, Me) | 0, d = d + Math.imul($, xe) | 0, a = a + Math.imul($, Se) | 0, a = a + Math.imul(G, xe) | 0, p = p + Math.imul(G, Se) | 0, d = d + Math.imul(q, Ee) | 0, a = a + Math.imul(q, Ce) | 0, a = a + Math.imul(F, Ee) | 0, p = p + Math.imul(F, Ce) | 0, d = d + Math.imul(A, ke) | 0, a = a + Math.imul(A, Re) | 0, a = a + Math.imul(O, ke) | 0, p = p + Math.imul(O, Re) | 0, d = d + Math.imul(c, Ae) | 0, a = a + Math.imul(c, Te) | 0, a = a + Math.imul(k, Ae) | 0, p = p + Math.imul(k, Te) | 0;
            var _n = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (_n >>> 26) | 0, _n &= 67108863, d = Math.imul(ce, ge), a = Math.imul(ce, _e), a = a + Math.imul(fe, ge) | 0, p = Math.imul(fe, _e), d = d + Math.imul(se, me) | 0, a = a + Math.imul(se, ve) | 0, a = a + Math.imul(le, me) | 0, p = p + Math.imul(le, ve) | 0, d = d + Math.imul(oe, we) | 0, a = a + Math.imul(oe, ye) | 0, a = a + Math.imul(ae, we) | 0, p = p + Math.imul(ae, ye) | 0, d = d + Math.imul(re, be) | 0, a = a + Math.imul(re, Me) | 0, a = a + Math.imul(ie, be) | 0, p = p + Math.imul(ie, Me) | 0, d = d + Math.imul(te, xe) | 0, a = a + Math.imul(te, Se) | 0, a = a + Math.imul(ne, xe) | 0, p = p + Math.imul(ne, Se) | 0, d = d + Math.imul($, Ee) | 0, a = a + Math.imul($, Ce) | 0, a = a + Math.imul(G, Ee) | 0, p = p + Math.imul(G, Ce) | 0, d = d + Math.imul(q, ke) | 0, a = a + Math.imul(q, Re) | 0, a = a + Math.imul(F, ke) | 0, p = p + Math.imul(F, Re) | 0, d = d + Math.imul(A, Ae) | 0, a = a + Math.imul(A, Te) | 0, a = a + Math.imul(O, Ae) | 0, p = p + Math.imul(O, Te) | 0;
            var mn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (mn >>> 26) | 0, mn &= 67108863, d = Math.imul(ce, me), a = Math.imul(ce, ve), a = a + Math.imul(fe, me) | 0, p = Math.imul(fe, ve), d = d + Math.imul(se, we) | 0, a = a + Math.imul(se, ye) | 0, a = a + Math.imul(le, we) | 0, p = p + Math.imul(le, ye) | 0, d = d + Math.imul(oe, be) | 0, a = a + Math.imul(oe, Me) | 0, a = a + Math.imul(ae, be) | 0, p = p + Math.imul(ae, Me) | 0, d = d + Math.imul(re, xe) | 0, a = a + Math.imul(re, Se) | 0, a = a + Math.imul(ie, xe) | 0, p = p + Math.imul(ie, Se) | 0, d = d + Math.imul(te, Ee) | 0, a = a + Math.imul(te, Ce) | 0, a = a + Math.imul(ne, Ee) | 0, p = p + Math.imul(ne, Ce) | 0, d = d + Math.imul($, ke) | 0, a = a + Math.imul($, Re) | 0, a = a + Math.imul(G, ke) | 0, p = p + Math.imul(G, Re) | 0, d = d + Math.imul(q, Ae) | 0, a = a + Math.imul(q, Te) | 0, a = a + Math.imul(F, Ae) | 0, p = p + Math.imul(F, Te) | 0;
            var vn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (vn >>> 26) | 0, vn &= 67108863, d = Math.imul(ce, we), a = Math.imul(ce, ye), a = a + Math.imul(fe, we) | 0, p = Math.imul(fe, ye), d = d + Math.imul(se, be) | 0, a = a + Math.imul(se, Me) | 0, a = a + Math.imul(le, be) | 0, p = p + Math.imul(le, Me) | 0, d = d + Math.imul(oe, xe) | 0, a = a + Math.imul(oe, Se) | 0, a = a + Math.imul(ae, xe) | 0, p = p + Math.imul(ae, Se) | 0, d = d + Math.imul(re, Ee) | 0, a = a + Math.imul(re, Ce) | 0, a = a + Math.imul(ie, Ee) | 0, p = p + Math.imul(ie, Ce) | 0, d = d + Math.imul(te, ke) | 0, a = a + Math.imul(te, Re) | 0, a = a + Math.imul(ne, ke) | 0, p = p + Math.imul(ne, Re) | 0, d = d + Math.imul($, Ae) | 0, a = a + Math.imul($, Te) | 0, a = a + Math.imul(G, Ae) | 0, p = p + Math.imul(G, Te) | 0;
            var wn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (wn >>> 26) | 0, wn &= 67108863, d = Math.imul(ce, be), a = Math.imul(ce, Me), a = a + Math.imul(fe, be) | 0, p = Math.imul(fe, Me), d = d + Math.imul(se, xe) | 0, a = a + Math.imul(se, Se) | 0, a = a + Math.imul(le, xe) | 0, p = p + Math.imul(le, Se) | 0, d = d + Math.imul(oe, Ee) | 0, a = a + Math.imul(oe, Ce) | 0, a = a + Math.imul(ae, Ee) | 0, p = p + Math.imul(ae, Ce) | 0, d = d + Math.imul(re, ke) | 0, a = a + Math.imul(re, Re) | 0, a = a + Math.imul(ie, ke) | 0, p = p + Math.imul(ie, Re) | 0, d = d + Math.imul(te, Ae) | 0, a = a + Math.imul(te, Te) | 0, a = a + Math.imul(ne, Ae) | 0, p = p + Math.imul(ne, Te) | 0;
            var yn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (yn >>> 26) | 0, yn &= 67108863, d = Math.imul(ce, xe), a = Math.imul(ce, Se), a = a + Math.imul(fe, xe) | 0, p = Math.imul(fe, Se), d = d + Math.imul(se, Ee) | 0, a = a + Math.imul(se, Ce) | 0, a = a + Math.imul(le, Ee) | 0, p = p + Math.imul(le, Ce) | 0, d = d + Math.imul(oe, ke) | 0, a = a + Math.imul(oe, Re) | 0, a = a + Math.imul(ae, ke) | 0, p = p + Math.imul(ae, Re) | 0, d = d + Math.imul(re, Ae) | 0, a = a + Math.imul(re, Te) | 0, a = a + Math.imul(ie, Ae) | 0, p = p + Math.imul(ie, Te) | 0;
            var bn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (bn >>> 26) | 0, bn &= 67108863, d = Math.imul(ce, Ee), a = Math.imul(ce, Ce), a = a + Math.imul(fe, Ee) | 0, p = Math.imul(fe, Ce), d = d + Math.imul(se, ke) | 0, a = a + Math.imul(se, Re) | 0, a = a + Math.imul(le, ke) | 0, p = p + Math.imul(le, Re) | 0, d = d + Math.imul(oe, Ae) | 0, a = a + Math.imul(oe, Te) | 0, a = a + Math.imul(ae, Ae) | 0, p = p + Math.imul(ae, Te) | 0;
            var Mn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (Mn >>> 26) | 0, Mn &= 67108863, d = Math.imul(ce, ke), a = Math.imul(ce, Re), a = a + Math.imul(fe, ke) | 0, p = Math.imul(fe, Re), d = d + Math.imul(se, Ae) | 0, a = a + Math.imul(se, Te) | 0, a = a + Math.imul(le, Ae) | 0, p = p + Math.imul(le, Te) | 0;
            var xn = (x + d | 0) + ((a & 8191) << 13) | 0;
            x = (p + (a >>> 13) | 0) + (xn >>> 26) | 0, xn &= 67108863, d = Math.imul(ce, Ae), a = Math.imul(ce, Te), a = a + Math.imul(fe, Ae) | 0, p = Math.imul(fe, Te);
            var Sn = (x + d | 0) + ((a & 8191) << 13) | 0;
            return x = (p + (a >>> 13) | 0) + (Sn >>> 26) | 0, Sn &= 67108863, w[0] = $e, w[1] = We, w[2] = He, w[3] = ze, w[4] = je, w[5] = Ke, w[6] = Je, w[7] = Ve, w[8] = pn, w[9] = gn, w[10] = _n, w[11] = mn, w[12] = vn, w[13] = wn, w[14] = yn, w[15] = bn, w[16] = Mn, w[17] = xn, w[18] = Sn, x !== 0 && (w[19] = x, f.length++), f
        };
        Math.imul || (N = P);

        function D(_, i, l) {
            l.negative = i.negative ^ _.negative, l.length = _.length + i.length;
            for (var f = 0, u = 0, g = 0; g < l.length - 1; g++) {
                var w = u;
                u = 0;
                for (var x = f & 67108863, d = Math.min(g, i.length - 1), a = Math.max(0, g - _.length + 1); a <= d; a++) {
                    var p = g - a,
                        H = _.words[p] | 0,
                        L = i.words[a] | 0,
                        j = H * L,
                        V = j & 67108863;
                    w = w + (j / 67108864 | 0) | 0, V = V + x | 0, x = V & 67108863, w = w + (V >>> 26) | 0, u += w >>> 26, w &= 67108863
                }
                l.words[g] = x, f = w, w = u
            }
            return f !== 0 ? l.words[g] = f : l.length--, l.strip()
        }

        function b(_, i, l) {
            var f = new S;
            return f.mulp(_, i, l)
        }
        o.prototype.mulTo = function(i, l) {
            var f, u = this.length + i.length;
            return this.length === 10 && i.length === 10 ? f = N(this, i, l) : u < 63 ? f = P(this, i, l) : u < 1024 ? f = D(this, i, l) : f = b(this, i, l), f
        };

        function S(_, i) {
            this.x = _, this.y = i
        }
        S.prototype.makeRBT = function(i) {
            for (var l = new Array(i), f = o.prototype._countBits(i) - 1, u = 0; u < i; u++) l[u] = this.revBin(u, f, i);
            return l
        }, S.prototype.revBin = function(i, l, f) {
            if (i === 0 || i === f - 1) return i;
            for (var u = 0, g = 0; g < l; g++) u |= (i & 1) << l - g - 1, i >>= 1;
            return u
        }, S.prototype.permute = function(i, l, f, u, g, w) {
            for (var x = 0; x < w; x++) u[x] = l[i[x]], g[x] = f[i[x]]
        }, S.prototype.transform = function(i, l, f, u, g, w) {
            this.permute(w, i, l, f, u, g);
            for (var x = 1; x < g; x <<= 1)
                for (var d = x << 1, a = Math.cos(2 * Math.PI / d), p = Math.sin(2 * Math.PI / d), H = 0; H < g; H += d)
                    for (var L = a, j = p, V = 0; V < x; V++) {
                        var c = f[H + V],
                            k = u[H + V],
                            T = f[H + V + x],
                            A = u[H + V + x],
                            O = L * T - j * A;
                        A = L * A + j * T, T = O, f[H + V] = c + T, u[H + V] = k + A, f[H + V + x] = c - T, u[H + V + x] = k - A, V !== d && (O = a * L - p * j, j = a * j + p * L, L = O)
                    }
        }, S.prototype.guessLen13b = function(i, l) {
            var f = Math.max(l, i) | 1,
                u = f & 1,
                g = 0;
            for (f = f / 2 | 0; f; f = f >>> 1) g++;
            return 1 << g + 1 + u
        }, S.prototype.conjugate = function(i, l, f) {
            if (!(f <= 1))
                for (var u = 0; u < f / 2; u++) {
                    var g = i[u];
                    i[u] = i[f - u - 1], i[f - u - 1] = g, g = l[u], l[u] = -l[f - u - 1], l[f - u - 1] = -g
                }
        }, S.prototype.normalize13b = function(i, l) {
            for (var f = 0, u = 0; u < l / 2; u++) {
                var g = Math.round(i[2 * u + 1] / l) * 8192 + Math.round(i[2 * u] / l) + f;
                i[u] = g & 67108863, g < 67108864 ? f = 0 : f = g / 67108864 | 0
            }
            return i
        }, S.prototype.convert13b = function(i, l, f, u) {
            for (var g = 0, w = 0; w < l; w++) g = g + (i[w] | 0), f[2 * w] = g & 8191, g = g >>> 13, f[2 * w + 1] = g & 8191, g = g >>> 13;
            for (w = 2 * l; w < u; ++w) f[w] = 0;
            r(g === 0), r((g & -8192) === 0)
        }, S.prototype.stub = function(i) {
            for (var l = new Array(i), f = 0; f < i; f++) l[f] = 0;
            return l
        }, S.prototype.mulp = function(i, l, f) {
            var u = 2 * this.guessLen13b(i.length, l.length),
                g = this.makeRBT(u),
                w = this.stub(u),
                x = new Array(u),
                d = new Array(u),
                a = new Array(u),
                p = new Array(u),
                H = new Array(u),
                L = new Array(u),
                j = f.words;
            j.length = u, this.convert13b(i.words, i.length, x, u), this.convert13b(l.words, l.length, p, u), this.transform(x, w, d, a, u, g), this.transform(p, w, H, L, u, g);
            for (var V = 0; V < u; V++) {
                var c = d[V] * H[V] - a[V] * L[V];
                a[V] = d[V] * L[V] + a[V] * H[V], d[V] = c
            }
            return this.conjugate(d, a, u), this.transform(d, a, j, w, u, g), this.conjugate(j, w, u), this.normalize13b(j, u), f.negative = i.negative ^ l.negative, f.length = i.length + l.length, f.strip()
        }, o.prototype.mul = function(i) {
            var l = new o(null);
            return l.words = new Array(this.length + i.length), this.mulTo(i, l)
        }, o.prototype.mulf = function(i) {
            var l = new o(null);
            return l.words = new Array(this.length + i.length), b(this, i, l)
        }, o.prototype.imul = function(i) {
            return this.clone().mulTo(i, this)
        }, o.prototype.imuln = function(i) {
            r(typeof i == "number"), r(i < 67108864);
            for (var l = 0, f = 0; f < this.length; f++) {
                var u = (this.words[f] | 0) * i,
                    g = (u & 67108863) + (l & 67108863);
                l >>= 26, l += u / 67108864 | 0, l += g >>> 26, this.words[f] = g & 67108863
            }
            return l !== 0 && (this.words[f] = l, this.length++), this
        }, o.prototype.muln = function(i) {
            return this.clone().imuln(i)
        }, o.prototype.sqr = function() {
            return this.mul(this)
        }, o.prototype.isqr = function() {
            return this.imul(this.clone())
        }, o.prototype.pow = function(i) {
            var l = B(i);
            if (l.length === 0) return new o(1);
            for (var f = this, u = 0; u < l.length && l[u] === 0; u++, f = f.sqr());
            if (++u < l.length)
                for (var g = f.sqr(); u < l.length; u++, g = g.sqr()) l[u] !== 0 && (f = f.mul(g));
            return f
        }, o.prototype.iushln = function(i) {
            r(typeof i == "number" && i >= 0);
            var l = i % 26,
                f = (i - l) / 26,
                u = 67108863 >>> 26 - l << 26 - l,
                g;
            if (l !== 0) {
                var w = 0;
                for (g = 0; g < this.length; g++) {
                    var x = this.words[g] & u,
                        d = (this.words[g] | 0) - x << l;
                    this.words[g] = d | w, w = x >>> 26 - l
                }
                w && (this.words[g] = w, this.length++)
            }
            if (f !== 0) {
                for (g = this.length - 1; g >= 0; g--) this.words[g + f] = this.words[g];
                for (g = 0; g < f; g++) this.words[g] = 0;
                this.length += f
            }
            return this.strip()
        }, o.prototype.ishln = function(i) {
            return r(this.negative === 0), this.iushln(i)
        }, o.prototype.iushrn = function(i, l, f) {
            r(typeof i == "number" && i >= 0);
            var u;
            l ? u = (l - l % 26) / 26 : u = 0;
            var g = i % 26,
                w = Math.min((i - g) / 26, this.length),
                x = 67108863 ^ 67108863 >>> g << g,
                d = f;
            if (u -= w, u = Math.max(0, u), d) {
                for (var a = 0; a < w; a++) d.words[a] = this.words[a];
                d.length = w
            }
            if (w !== 0)
                if (this.length > w)
                    for (this.length -= w, a = 0; a < this.length; a++) this.words[a] = this.words[a + w];
                else this.words[0] = 0, this.length = 1;
            var p = 0;
            for (a = this.length - 1; a >= 0 && (p !== 0 || a >= u); a--) {
                var H = this.words[a] | 0;
                this.words[a] = p << 26 - g | H >>> g, p = H & x
            }
            return d && p !== 0 && (d.words[d.length++] = p), this.length === 0 && (this.words[0] = 0, this.length = 1), this.strip()
        }, o.prototype.ishrn = function(i, l, f) {
            return r(this.negative === 0), this.iushrn(i, l, f)
        }, o.prototype.shln = function(i) {
            return this.clone().ishln(i)
        }, o.prototype.ushln = function(i) {
            return this.clone().iushln(i)
        }, o.prototype.shrn = function(i) {
            return this.clone().ishrn(i)
        }, o.prototype.ushrn = function(i) {
            return this.clone().iushrn(i)
        }, o.prototype.testn = function(i) {
            r(typeof i == "number" && i >= 0);
            var l = i % 26,
                f = (i - l) / 26,
                u = 1 << l;
            if (this.length <= f) return !1;
            var g = this.words[f];
            return !!(g & u)
        }, o.prototype.imaskn = function(i) {
            r(typeof i == "number" && i >= 0);
            var l = i % 26,
                f = (i - l) / 26;
            if (r(this.negative === 0, "imaskn works only with positive numbers"), this.length <= f) return this;
            if (l !== 0 && f++, this.length = Math.min(f, this.length), l !== 0) {
                var u = 67108863 ^ 67108863 >>> l << l;
                this.words[this.length - 1] &= u
            }
            return this.strip()
        }, o.prototype.maskn = function(i) {
            return this.clone().imaskn(i)
        }, o.prototype.iaddn = function(i) {
            return r(typeof i == "number"), r(i < 67108864), i < 0 ? this.isubn(-i) : this.negative !== 0 ? this.length === 1 && (this.words[0] | 0) < i ? (this.words[0] = i - (this.words[0] | 0), this.negative = 0, this) : (this.negative = 0, this.isubn(i), this.negative = 1, this) : this._iaddn(i)
        }, o.prototype._iaddn = function(i) {
            this.words[0] += i;
            for (var l = 0; l < this.length && this.words[l] >= 67108864; l++) this.words[l] -= 67108864, l === this.length - 1 ? this.words[l + 1] = 1 : this.words[l + 1]++;
            return this.length = Math.max(this.length, l + 1), this
        }, o.prototype.isubn = function(i) {
            if (r(typeof i == "number"), r(i < 67108864), i < 0) return this.iaddn(-i);
            if (this.negative !== 0) return this.negative = 0, this.iaddn(i), this.negative = 1, this;
            if (this.words[0] -= i, this.length === 1 && this.words[0] < 0) this.words[0] = -this.words[0], this.negative = 1;
            else
                for (var l = 0; l < this.length && this.words[l] < 0; l++) this.words[l] += 67108864, this.words[l + 1] -= 1;
            return this.strip()
        }, o.prototype.addn = function(i) {
            return this.clone().iaddn(i)
        }, o.prototype.subn = function(i) {
            return this.clone().isubn(i)
        }, o.prototype.iabs = function() {
            return this.negative = 0, this
        }, o.prototype.abs = function() {
            return this.clone().iabs()
        }, o.prototype._ishlnsubmul = function(i, l, f) {
            var u = i.length + f,
                g;
            this._expand(u);
            var w, x = 0;
            for (g = 0; g < i.length; g++) {
                w = (this.words[g + f] | 0) + x;
                var d = (i.words[g] | 0) * l;
                w -= d & 67108863, x = (w >> 26) - (d / 67108864 | 0), this.words[g + f] = w & 67108863
            }
            for (; g < this.length - f; g++) w = (this.words[g + f] | 0) + x, x = w >> 26, this.words[g + f] = w & 67108863;
            if (x === 0) return this.strip();
            for (r(x === -1), x = 0, g = 0; g < this.length; g++) w = -(this.words[g] | 0) + x, x = w >> 26, this.words[g] = w & 67108863;
            return this.negative = 1, this.strip()
        }, o.prototype._wordDiv = function(i, l) {
            var f = this.length - i.length,
                u = this.clone(),
                g = i,
                w = g.words[g.length - 1] | 0,
                x = this._countBits(w);
            f = 26 - x, f !== 0 && (g = g.ushln(f), u.iushln(f), w = g.words[g.length - 1] | 0);
            var d = u.length - g.length,
                a;
            if (l !== "mod") {
                a = new o(null), a.length = d + 1, a.words = new Array(a.length);
                for (var p = 0; p < a.length; p++) a.words[p] = 0
            }
            var H = u.clone()._ishlnsubmul(g, 1, d);
            H.negative === 0 && (u = H, a && (a.words[d] = 1));
            for (var L = d - 1; L >= 0; L--) {
                var j = (u.words[g.length + L] | 0) * 67108864 + (u.words[g.length + L - 1] | 0);
                for (j = Math.min(j / w | 0, 67108863), u._ishlnsubmul(g, j, L); u.negative !== 0;) j--, u.negative = 0, u._ishlnsubmul(g, 1, L), u.isZero() || (u.negative ^= 1);
                a && (a.words[L] = j)
            }
            return a && a.strip(), u.strip(), l !== "div" && f !== 0 && u.iushrn(f), {
                div: a || null,
                mod: u
            }
        }, o.prototype.divmod = function(i, l, f) {
            if (r(!i.isZero()), this.isZero()) return {
                div: new o(0),
                mod: new o(0)
            };
            var u, g, w;
            return this.negative !== 0 && i.negative === 0 ? (w = this.neg().divmod(i, l), l !== "mod" && (u = w.div.neg()), l !== "div" && (g = w.mod.neg(), f && g.negative !== 0 && g.iadd(i)), {
                div: u,
                mod: g
            }) : this.negative === 0 && i.negative !== 0 ? (w = this.divmod(i.neg(), l), l !== "mod" && (u = w.div.neg()), {
                div: u,
                mod: w.mod
            }) : (this.negative & i.negative) !== 0 ? (w = this.neg().divmod(i.neg(), l), l !== "div" && (g = w.mod.neg(), f && g.negative !== 0 && g.isub(i)), {
                div: w.div,
                mod: g
            }) : i.length > this.length || this.cmp(i) < 0 ? {
                div: new o(0),
                mod: this
            } : i.length === 1 ? l === "div" ? {
                div: this.divn(i.words[0]),
                mod: null
            } : l === "mod" ? {
                div: null,
                mod: new o(this.modn(i.words[0]))
            } : {
                div: this.divn(i.words[0]),
                mod: new o(this.modn(i.words[0]))
            } : this._wordDiv(i, l)
        }, o.prototype.div = function(i) {
            return this.divmod(i, "div", !1).div
        }, o.prototype.mod = function(i) {
            return this.divmod(i, "mod", !1).mod
        }, o.prototype.umod = function(i) {
            return this.divmod(i, "mod", !0).mod
        }, o.prototype.divRound = function(i) {
            var l = this.divmod(i);
            if (l.mod.isZero()) return l.div;
            var f = l.div.negative !== 0 ? l.mod.isub(i) : l.mod,
                u = i.ushrn(1),
                g = i.andln(1),
                w = f.cmp(u);
            return w < 0 || g === 1 && w === 0 ? l.div : l.div.negative !== 0 ? l.div.isubn(1) : l.div.iaddn(1)
        }, o.prototype.modn = function(i) {
            r(i <= 67108863);
            for (var l = (1 << 26) % i, f = 0, u = this.length - 1; u >= 0; u--) f = (l * f + (this.words[u] | 0)) % i;
            return f
        }, o.prototype.idivn = function(i) {
            r(i <= 67108863);
            for (var l = 0, f = this.length - 1; f >= 0; f--) {
                var u = (this.words[f] | 0) + l * 67108864;
                this.words[f] = u / i | 0, l = u % i
            }
            return this.strip()
        }, o.prototype.divn = function(i) {
            return this.clone().idivn(i)
        }, o.prototype.egcd = function(i) {
            r(i.negative === 0), r(!i.isZero());
            var l = this,
                f = i.clone();
            l.negative !== 0 ? l = l.umod(i) : l = l.clone();
            for (var u = new o(1), g = new o(0), w = new o(0), x = new o(1), d = 0; l.isEven() && f.isEven();) l.iushrn(1), f.iushrn(1), ++d;
            for (var a = f.clone(), p = l.clone(); !l.isZero();) {
                for (var H = 0, L = 1;
                    (l.words[0] & L) === 0 && H < 26; ++H, L <<= 1);
                if (H > 0)
                    for (l.iushrn(H); H-- > 0;)(u.isOdd() || g.isOdd()) && (u.iadd(a), g.isub(p)), u.iushrn(1), g.iushrn(1);
                for (var j = 0, V = 1;
                    (f.words[0] & V) === 0 && j < 26; ++j, V <<= 1);
                if (j > 0)
                    for (f.iushrn(j); j-- > 0;)(w.isOdd() || x.isOdd()) && (w.iadd(a), x.isub(p)), w.iushrn(1), x.iushrn(1);
                l.cmp(f) >= 0 ? (l.isub(f), u.isub(w), g.isub(x)) : (f.isub(l), w.isub(u), x.isub(g))
            }
            return {
                a: w,
                b: x,
                gcd: f.iushln(d)
            }
        }, o.prototype._invmp = function(i) {
            r(i.negative === 0), r(!i.isZero());
            var l = this,
                f = i.clone();
            l.negative !== 0 ? l = l.umod(i) : l = l.clone();
            for (var u = new o(1), g = new o(0), w = f.clone(); l.cmpn(1) > 0 && f.cmpn(1) > 0;) {
                for (var x = 0, d = 1;
                    (l.words[0] & d) === 0 && x < 26; ++x, d <<= 1);
                if (x > 0)
                    for (l.iushrn(x); x-- > 0;) u.isOdd() && u.iadd(w), u.iushrn(1);
                for (var a = 0, p = 1;
                    (f.words[0] & p) === 0 && a < 26; ++a, p <<= 1);
                if (a > 0)
                    for (f.iushrn(a); a-- > 0;) g.isOdd() && g.iadd(w), g.iushrn(1);
                l.cmp(f) >= 0 ? (l.isub(f), u.isub(g)) : (f.isub(l), g.isub(u))
            }
            var H;
            return l.cmpn(1) === 0 ? H = u : H = g, H.cmpn(0) < 0 && H.iadd(i), H
        }, o.prototype.gcd = function(i) {
            if (this.isZero()) return i.abs();
            if (i.isZero()) return this.abs();
            var l = this.clone(),
                f = i.clone();
            l.negative = 0, f.negative = 0;
            for (var u = 0; l.isEven() && f.isEven(); u++) l.iushrn(1), f.iushrn(1);
            do {
                for (; l.isEven();) l.iushrn(1);
                for (; f.isEven();) f.iushrn(1);
                var g = l.cmp(f);
                if (g < 0) {
                    var w = l;
                    l = f, f = w
                } else if (g === 0 || f.cmpn(1) === 0) break;
                l.isub(f)
            } while (!0);
            return f.iushln(u)
        }, o.prototype.invm = function(i) {
            return this.egcd(i).a.umod(i)
        }, o.prototype.isEven = function() {
            return (this.words[0] & 1) === 0
        }, o.prototype.isOdd = function() {
            return (this.words[0] & 1) === 1
        }, o.prototype.andln = function(i) {
            return this.words[0] & i
        }, o.prototype.bincn = function(i) {
            r(typeof i == "number");
            var l = i % 26,
                f = (i - l) / 26,
                u = 1 << l;
            if (this.length <= f) return this._expand(f + 1), this.words[f] |= u, this;
            for (var g = u, w = f; g !== 0 && w < this.length; w++) {
                var x = this.words[w] | 0;
                x += g, g = x >>> 26, x &= 67108863, this.words[w] = x
            }
            return g !== 0 && (this.words[w] = g, this.length++), this
        }, o.prototype.isZero = function() {
            return this.length === 1 && this.words[0] === 0
        }, o.prototype.cmpn = function(i) {
            var l = i < 0;
            if (this.negative !== 0 && !l) return -1;
            if (this.negative === 0 && l) return 1;
            this.strip();
            var f;
            if (this.length > 1) f = 1;
            else {
                l && (i = -i), r(i <= 67108863, "Number is too big");
                var u = this.words[0] | 0;
                f = u === i ? 0 : u < i ? -1 : 1
            }
            return this.negative !== 0 ? -f | 0 : f
        }, o.prototype.cmp = function(i) {
            if (this.negative !== 0 && i.negative === 0) return -1;
            if (this.negative === 0 && i.negative !== 0) return 1;
            var l = this.ucmp(i);
            return this.negative !== 0 ? -l | 0 : l
        }, o.prototype.ucmp = function(i) {
            if (this.length > i.length) return 1;
            if (this.length < i.length) return -1;
            for (var l = 0, f = this.length - 1; f >= 0; f--) {
                var u = this.words[f] | 0,
                    g = i.words[f] | 0;
                if (u !== g) {
                    u < g ? l = -1 : u > g && (l = 1);
                    break
                }
            }
            return l
        }, o.prototype.gtn = function(i) {
            return this.cmpn(i) === 1
        }, o.prototype.gt = function(i) {
            return this.cmp(i) === 1
        }, o.prototype.gten = function(i) {
            return this.cmpn(i) >= 0
        }, o.prototype.gte = function(i) {
            return this.cmp(i) >= 0
        }, o.prototype.ltn = function(i) {
            return this.cmpn(i) === -1
        }, o.prototype.lt = function(i) {
            return this.cmp(i) === -1
        }, o.prototype.lten = function(i) {
            return this.cmpn(i) <= 0
        }, o.prototype.lte = function(i) {
            return this.cmp(i) <= 0
        }, o.prototype.eqn = function(i) {
            return this.cmpn(i) === 0
        }, o.prototype.eq = function(i) {
            return this.cmp(i) === 0
        }, o.red = function(i) {
            return new J(i)
        }, o.prototype.toRed = function(i) {
            return r(!this.red, "Already a number in reduction context"), r(this.negative === 0, "red works only with positives"), i.convertTo(this)._forceRed(i)
        }, o.prototype.fromRed = function() {
            return r(this.red, "fromRed works only with numbers in reduction context"), this.red.convertFrom(this)
        }, o.prototype._forceRed = function(i) {
            return this.red = i, this
        }, o.prototype.forceRed = function(i) {
            return r(!this.red, "Already a number in reduction context"), this._forceRed(i)
        }, o.prototype.redAdd = function(i) {
            return r(this.red, "redAdd works only with red numbers"), this.red.add(this, i)
        }, o.prototype.redIAdd = function(i) {
            return r(this.red, "redIAdd works only with red numbers"), this.red.iadd(this, i)
        }, o.prototype.redSub = function(i) {
            return r(this.red, "redSub works only with red numbers"), this.red.sub(this, i)
        }, o.prototype.redISub = function(i) {
            return r(this.red, "redISub works only with red numbers"), this.red.isub(this, i)
        }, o.prototype.redShl = function(i) {
            return r(this.red, "redShl works only with red numbers"), this.red.shl(this, i)
        }, o.prototype.redMul = function(i) {
            return r(this.red, "redMul works only with red numbers"), this.red._verify2(this, i), this.red.mul(this, i)
        }, o.prototype.redIMul = function(i) {
            return r(this.red, "redMul works only with red numbers"), this.red._verify2(this, i), this.red.imul(this, i)
        }, o.prototype.redSqr = function() {
            return r(this.red, "redSqr works only with red numbers"), this.red._verify1(this), this.red.sqr(this)
        }, o.prototype.redISqr = function() {
            return r(this.red, "redISqr works only with red numbers"), this.red._verify1(this), this.red.isqr(this)
        }, o.prototype.redSqrt = function() {
            return r(this.red, "redSqrt works only with red numbers"), this.red._verify1(this), this.red.sqrt(this)
        }, o.prototype.redInvm = function() {
            return r(this.red, "redInvm works only with red numbers"), this.red._verify1(this), this.red.invm(this)
        }, o.prototype.redNeg = function() {
            return r(this.red, "redNeg works only with red numbers"), this.red._verify1(this), this.red.neg(this)
        }, o.prototype.redPow = function(i) {
            return r(this.red && !i.red, "redPow(normalNum)"), this.red._verify1(this), this.red.pow(this, i)
        };
        var C = {
            k256: null,
            p224: null,
            p192: null,
            p25519: null
        };

        function E(_, i) {
            this.name = _, this.p = new o(i, 16), this.n = this.p.bitLength(), this.k = new o(1).iushln(this.n).isub(this.p), this.tmp = this._tmp()
        }
        E.prototype._tmp = function() {
            var i = new o(null);
            return i.words = new Array(Math.ceil(this.n / 13)), i
        }, E.prototype.ireduce = function(i) {
            var l = i,
                f;
            do this.split(l, this.tmp), l = this.imulK(l), l = l.iadd(this.tmp), f = l.bitLength(); while (f > this.n);
            var u = f < this.n ? -1 : l.ucmp(this.p);
            return u === 0 ? (l.words[0] = 0, l.length = 1) : u > 0 ? l.isub(this.p) : l.strip(), l
        }, E.prototype.split = function(i, l) {
            i.iushrn(this.n, 0, l)
        }, E.prototype.imulK = function(i) {
            return i.imul(this.k)
        };

        function R() {
            E.call(this, "k256", "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f")
        }
        s(R, E), R.prototype.split = function(i, l) {
            for (var f = 4194303, u = Math.min(i.length, 9), g = 0; g < u; g++) l.words[g] = i.words[g];
            if (l.length = u, i.length <= 9) {
                i.words[0] = 0, i.length = 1;
                return
            }
            var w = i.words[9];
            for (l.words[l.length++] = w & f, g = 10; g < i.length; g++) {
                var x = i.words[g] | 0;
                i.words[g - 10] = (x & f) << 4 | w >>> 22, w = x
            }
            w >>>= 22, i.words[g - 10] = w, w === 0 && i.length > 10 ? i.length -= 10 : i.length -= 9
        }, R.prototype.imulK = function(i) {
            i.words[i.length] = 0, i.words[i.length + 1] = 0, i.length += 2;
            for (var l = 0, f = 0; f < i.length; f++) {
                var u = i.words[f] | 0;
                l += u * 977, i.words[f] = l & 67108863, l = u * 64 + (l / 67108864 | 0)
            }
            return i.words[i.length - 1] === 0 && (i.length--, i.words[i.length - 1] === 0 && i.length--), i
        };

        function z() {
            E.call(this, "p224", "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001")
        }
        s(z, E);

        function W() {
            E.call(this, "p192", "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff")
        }
        s(W, E);

        function Q() {
            E.call(this, "25519", "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed")
        }
        s(Q, E), Q.prototype.imulK = function(i) {
            for (var l = 0, f = 0; f < i.length; f++) {
                var u = (i.words[f] | 0) * 19 + l,
                    g = u & 67108863;
                u >>>= 26, i.words[f] = g, l = u
            }
            return l !== 0 && (i.words[i.length++] = l), i
        }, o._prime = function(i) {
            if (C[i]) return C[i];
            var l;
            if (i === "k256") l = new R;
            else if (i === "p224") l = new z;
            else if (i === "p192") l = new W;
            else if (i === "p25519") l = new Q;
            else throw new Error("Unknown prime " + i);
            return C[i] = l, l
        };

        function J(_) {
            if (typeof _ == "string") {
                var i = o._prime(_);
                this.m = i.p, this.prime = i
            } else r(_.gtn(1), "modulus must be greater than 1"), this.m = _, this.prime = null
        }
        J.prototype._verify1 = function(i) {
            r(i.negative === 0, "red works only with positives"), r(i.red, "red works only with red numbers")
        }, J.prototype._verify2 = function(i, l) {
            r((i.negative | l.negative) === 0, "red works only with positives"), r(i.red && i.red === l.red, "red works only with red numbers")
        }, J.prototype.imod = function(i) {
            return this.prime ? this.prime.ireduce(i)._forceRed(this) : i.umod(this.m)._forceRed(this)
        }, J.prototype.neg = function(i) {
            return i.isZero() ? i.clone() : this.m.sub(i)._forceRed(this)
        }, J.prototype.add = function(i, l) {
            this._verify2(i, l);
            var f = i.add(l);
            return f.cmp(this.m) >= 0 && f.isub(this.m), f._forceRed(this)
        }, J.prototype.iadd = function(i, l) {
            this._verify2(i, l);
            var f = i.iadd(l);
            return f.cmp(this.m) >= 0 && f.isub(this.m), f
        }, J.prototype.sub = function(i, l) {
            this._verify2(i, l);
            var f = i.sub(l);
            return f.cmpn(0) < 0 && f.iadd(this.m), f._forceRed(this)
        }, J.prototype.isub = function(i, l) {
            this._verify2(i, l);
            var f = i.isub(l);
            return f.cmpn(0) < 0 && f.iadd(this.m), f
        }, J.prototype.shl = function(i, l) {
            return this._verify1(i), this.imod(i.ushln(l))
        }, J.prototype.imul = function(i, l) {
            return this._verify2(i, l), this.imod(i.imul(l))
        }, J.prototype.mul = function(i, l) {
            return this._verify2(i, l), this.imod(i.mul(l))
        }, J.prototype.isqr = function(i) {
            return this.imul(i, i.clone())
        }, J.prototype.sqr = function(i) {
            return this.mul(i, i)
        }, J.prototype.sqrt = function(i) {
            if (i.isZero()) return i.clone();
            var l = this.m.andln(3);
            if (r(l % 2 === 1), l === 3) {
                var f = this.m.add(new o(1)).iushrn(2);
                return this.pow(i, f)
            }
            for (var u = this.m.subn(1), g = 0; !u.isZero() && u.andln(1) === 0;) g++, u.iushrn(1);
            r(!u.isZero());
            var w = new o(1).toRed(this),
                x = w.redNeg(),
                d = this.m.subn(1).iushrn(1),
                a = this.m.bitLength();
            for (a = new o(2 * a * a).toRed(this); this.pow(a, d).cmp(x) !== 0;) a.redIAdd(x);
            for (var p = this.pow(a, u), H = this.pow(i, u.addn(1).iushrn(1)), L = this.pow(i, u), j = g; L.cmp(w) !== 0;) {
                for (var V = L, c = 0; V.cmp(w) !== 0; c++) V = V.redSqr();
                r(c < j);
                var k = this.pow(p, new o(1).iushln(j - c - 1));
                H = H.redMul(k), p = k.redSqr(), L = L.redMul(p), j = c
            }
            return H
        }, J.prototype.invm = function(i) {
            var l = i._invmp(this.m);
            return l.negative !== 0 ? (l.negative = 0, this.imod(l).redNeg()) : this.imod(l)
        }, J.prototype.pow = function(i, l) {
            if (l.isZero()) return new o(1).toRed(this);
            if (l.cmpn(1) === 0) return i.clone();
            var f = 4,
                u = new Array(1 << f);
            u[0] = new o(1).toRed(this), u[1] = i;
            for (var g = 2; g < u.length; g++) u[g] = this.mul(u[g - 1], i);
            var w = u[0],
                x = 0,
                d = 0,
                a = l.bitLength() % 26;
            for (a === 0 && (a = 26), g = l.length - 1; g >= 0; g--) {
                for (var p = l.words[g], H = a - 1; H >= 0; H--) {
                    var L = p >> H & 1;
                    if (w !== u[0] && (w = this.sqr(w)), L === 0 && x === 0) {
                        d = 0;
                        continue
                    }
                    x <<= 1, x |= L, d++, !(d !== f && (g !== 0 || H !== 0)) && (w = this.mul(w, u[x]), d = 0, x = 0)
                }
                a = 26
            }
            return w
        }, J.prototype.convertTo = function(i) {
            var l = i.umod(this.m);
            return l === i ? l.clone() : l
        }, J.prototype.convertFrom = function(i) {
            var l = i.clone();
            return l.red = null, l
        }, o.mont = function(i) {
            return new X(i)
        };

        function X(_) {
            J.call(this, _), this.shift = this.m.bitLength(), this.shift % 26 !== 0 && (this.shift += 26 - this.shift % 26), this.r = new o(1).iushln(this.shift), this.r2 = this.imod(this.r.sqr()), this.rinv = this.r._invmp(this.m), this.minv = this.rinv.mul(this.r).isubn(1).div(this.m), this.minv = this.minv.umod(this.r), this.minv = this.r.sub(this.minv)
        }
        s(X, J), X.prototype.convertTo = function(i) {
            return this.imod(i.ushln(this.shift))
        }, X.prototype.convertFrom = function(i) {
            var l = this.imod(i.mul(this.rinv));
            return l.red = null, l
        }, X.prototype.imul = function(i, l) {
            if (i.isZero() || l.isZero()) return i.words[0] = 0, i.length = 1, i;
            var f = i.imul(l),
                u = f.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m),
                g = f.isub(u).iushrn(this.shift),
                w = g;
            return g.cmp(this.m) >= 0 ? w = g.isub(this.m) : g.cmpn(0) < 0 && (w = g.iadd(this.m)), w._forceRed(this)
        }, X.prototype.mul = function(i, l) {
            if (i.isZero() || l.isZero()) return new o(0)._forceRed(this);
            var f = i.mul(l),
                u = f.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m),
                g = f.isub(u).iushrn(this.shift),
                w = g;
            return g.cmp(this.m) >= 0 ? w = g.isub(this.m) : g.cmpn(0) < 0 && (w = g.iadd(this.m)), w._forceRed(this)
        }, X.prototype.invm = function(i) {
            var l = this.imod(i._invmp(this.m).mul(this.r2));
            return l._forceRed(this)
        }
    })(t, Le)
})(Ai);
var Qa = Ai.exports,
    Ga = er;
er.strict = Ti;
er.loose = Ii;
var Za = Object.prototype.toString,
    Xa = {
        "[object Int8Array]": !0,
        "[object Int16Array]": !0,
        "[object Int32Array]": !0,
        "[object Uint8Array]": !0,
        "[object Uint8ClampedArray]": !0,
        "[object Uint16Array]": !0,
        "[object Uint32Array]": !0,
        "[object Float32Array]": !0,
        "[object Float64Array]": !0
    };

function er(t) {
    return Ti(t) || Ii(t)
}

function Ti(t) {
    return t instanceof Int8Array || t instanceof Int16Array || t instanceof Int32Array || t instanceof Uint8Array || t instanceof Uint8ClampedArray || t instanceof Uint16Array || t instanceof Uint32Array || t instanceof Float32Array || t instanceof Float64Array
}

function Ii(t) {
    return Xa[Za.call(t)]
}
var es = Ga.strict,
    ts = function(e) {
        if (es(e)) {
            var n = Buffer.from(e.buffer);
            return e.byteLength !== e.buffer.byteLength && (n = n.slice(e.byteOffset, e.byteOffset + e.byteLength)), n
        } else return Buffer.from(e)
    };
const Ni = "hex",
    Oi = "utf8",
    an = "0";

function Et(t) {
    return new Uint8Array(t)
}

function Bi(t, e = !1) {
    const n = t.toString(Ni);
    return e ? Ot(n) : n
}

function ns(t) {
    return t.toString(Oi)
}

function sn(t) {
    return ts(t)
}

function xt(t, e = !1) {
    return Bi(sn(t), e)
}

function rs(t) {
    return ns(sn(t))
}

function is(t) {
    return Buffer.from(Xe(t), Ni)
}

function St(t) {
    return Et(is(t))
}

function tr(t) {
    return Buffer.from(t, Oi)
}

function Li(t) {
    return Et(tr(t))
}

function os(t, e = !1) {
    return Bi(tr(t), e)
}

function as(t, e) {
    return !(typeof t != "string" || !t.match(/^0x[0-9A-Fa-f]*$/) || e && t.length !== 2 + 2 * e)
}

function Pi(...t) {
    let e = [];
    return t.forEach(n => e = e.concat(Array.from(n))), new Uint8Array([...e])
}

function ss(t, e = 8) {
    const n = t % e;
    return n ? (t - n) / e * e + e : t
}

function ls(t, e = 8, n = an) {
    return cs(t, ss(t.length, e), n)
}

function cs(t, e, n = an) {
    return us(t, e, !0, n)
}

function Xe(t) {
    return t.replace(/^0x/, "")
}

function Ot(t) {
    return t.startsWith("0x") ? t : `0x${t}`
}

function Fi(t) {
    return t = Xe(t), t = ls(t, 2), t && (t = Ot(t)), t
}

function fs(t) {
    const e = t.startsWith("0x");
    return t = Xe(t), t = t.startsWith(an) ? t.substring(1) : t, e ? Ot(t) : t
}

function us(t, e, n, r = an) {
    const s = e - t.length;
    let o = t;
    if (s > 0) {
        const h = r.repeat(s);
        o = n ? h + t : t + h
    }
    return o
}

function Pn(t) {
    return sn(new Uint8Array(t))
}

function hs(t, e) {
    return xt(new Uint8Array(t), !e)
}

function ds(t) {
    return Et(t).buffer
}

function ps(t) {
    return Li(t).buffer
}

function gs(t) {
    return tr(t)
}

function _s(t, e) {
    return os(t, !e)
}

function ms(t) {
    return St(t).buffer
}

function Ui(t, e) {
    const n = Xe(Fi(new Qa(t).toString(16)));
    return e ? n : Ot(n)
}
var Di = {
    exports: {}
};
/**
 * [js-sha3]{@link https://github.com/emn178/js-sha3}
 *
 * @version 0.8.0
 * @author Chen, Yi-Cyuan [emn178@gmail.com]
 * @copyright Chen, Yi-Cyuan 2015-2018
 * @license MIT
 */
(function(t) {
    (function() {
        var e = "input is invalid type",
            n = "finalize already called",
            r = typeof window == "object",
            s = r ? window : {};
        s.JS_SHA3_NO_WINDOW && (r = !1);
        var o = !r && typeof self == "object",
            h = !s.JS_SHA3_NO_NODE_JS && typeof process == "object" && process.versions && process.versions.node;
        h ? s = Le : o && (s = self);
        var m = !s.JS_SHA3_NO_COMMON_JS && !0 && t.exports,
            v = !s.JS_SHA3_NO_ARRAY_BUFFER && typeof ArrayBuffer < "u",
            M = "0123456789abcdef".split(""),
            y = [31, 7936, 2031616, 520093696],
            I = [4, 1024, 262144, 67108864],
            B = [1, 256, 65536, 16777216],
            P = [6, 1536, 393216, 100663296],
            N = [0, 8, 16, 24],
            D = [1, 0, 32898, 0, 32906, 2147483648, 2147516416, 2147483648, 32907, 0, 2147483649, 0, 2147516545, 2147483648, 32777, 2147483648, 138, 0, 136, 0, 2147516425, 0, 2147483658, 0, 2147516555, 0, 139, 2147483648, 32905, 2147483648, 32771, 2147483648, 32770, 2147483648, 128, 2147483648, 32778, 0, 2147483658, 2147483648, 2147516545, 2147483648, 32896, 2147483648, 2147483649, 0, 2147516424, 2147483648],
            b = [224, 256, 384, 512],
            S = [128, 256],
            C = ["hex", "buffer", "arrayBuffer", "array", "digest"],
            E = {
                "128": 168,
                "256": 136
            };
        (s.JS_SHA3_NO_NODE_JS || !Array.isArray) && (Array.isArray = function(c) {
            return Object.prototype.toString.call(c) === "[object Array]"
        }), v && (s.JS_SHA3_NO_ARRAY_BUFFER_IS_VIEW || !ArrayBuffer.isView) && (ArrayBuffer.isView = function(c) {
            return typeof c == "object" && c.buffer && c.buffer.constructor === ArrayBuffer
        });
        for (var R = function(c, k, T) {
                return function(A) {
                    return new L(c, k, c).update(A)[T]()
                }
            }, z = function(c, k, T) {
                return function(A, O) {
                    return new L(c, k, O).update(A)[T]()
                }
            }, W = function(c, k, T) {
                return function(A, O, K, q) {
                    return u["cshake" + c].update(A, O, K, q)[T]()
                }
            }, Q = function(c, k, T) {
                return function(A, O, K, q) {
                    return u["kmac" + c].update(A, O, K, q)[T]()
                }
            }, J = function(c, k, T, A) {
                for (var O = 0; O < C.length; ++O) {
                    var K = C[O];
                    c[K] = k(T, A, K)
                }
                return c
            }, X = function(c, k) {
                var T = R(c, k, "hex");
                return T.create = function() {
                    return new L(c, k, c)
                }, T.update = function(A) {
                    return T.create().update(A)
                }, J(T, R, c, k)
            }, _ = function(c, k) {
                var T = z(c, k, "hex");
                return T.create = function(A) {
                    return new L(c, k, A)
                }, T.update = function(A, O) {
                    return T.create(O).update(A)
                }, J(T, z, c, k)
            }, i = function(c, k) {
                var T = E[c],
                    A = W(c, k, "hex");
                return A.create = function(O, K, q) {
                    return !K && !q ? u["shake" + c].create(O) : new L(c, k, O).bytepad([K, q], T)
                }, A.update = function(O, K, q, F) {
                    return A.create(K, q, F).update(O)
                }, J(A, W, c, k)
            }, l = function(c, k) {
                var T = E[c],
                    A = Q(c, k, "hex");
                return A.create = function(O, K, q) {
                    return new j(c, k, K).bytepad(["KMAC", q], T).bytepad([O], T)
                }, A.update = function(O, K, q, F) {
                    return A.create(O, q, F).update(K)
                }, J(A, Q, c, k)
            }, f = [{
                name: "keccak",
                padding: B,
                bits: b,
                createMethod: X
            }, {
                name: "sha3",
                padding: P,
                bits: b,
                createMethod: X
            }, {
                name: "shake",
                padding: y,
                bits: S,
                createMethod: _
            }, {
                name: "cshake",
                padding: I,
                bits: S,
                createMethod: i
            }, {
                name: "kmac",
                padding: I,
                bits: S,
                createMethod: l
            }], u = {}, g = [], w = 0; w < f.length; ++w)
            for (var x = f[w], d = x.bits, a = 0; a < d.length; ++a) {
                var p = x.name + "_" + d[a];
                if (g.push(p), u[p] = x.createMethod(d[a], x.padding), x.name !== "sha3") {
                    var H = x.name + d[a];
                    g.push(H), u[H] = u[p]
                }
            }

        function L(c, k, T) {
            this.blocks = [], this.s = [], this.padding = k, this.outputBits = T, this.reset = !0, this.finalized = !1, this.block = 0, this.start = 0, this.blockCount = 1600 - (c << 1) >> 5, this.byteCount = this.blockCount << 2, this.outputBlocks = T >> 5, this.extraBytes = (T & 31) >> 3;
            for (var A = 0; A < 50; ++A) this.s[A] = 0
        }
        L.prototype.update = function(c) {
            if (this.finalized) throw new Error(n);
            var k, T = typeof c;
            if (T !== "string") {
                if (T === "object") {
                    if (c === null) throw new Error(e);
                    if (v && c.constructor === ArrayBuffer) c = new Uint8Array(c);
                    else if (!Array.isArray(c) && (!v || !ArrayBuffer.isView(c))) throw new Error(e)
                } else throw new Error(e);
                k = !0
            }
            for (var A = this.blocks, O = this.byteCount, K = c.length, q = this.blockCount, F = 0, Ie = this.s, $, G; F < K;) {
                if (this.reset)
                    for (this.reset = !1, A[0] = this.block, $ = 1; $ < q + 1; ++$) A[$] = 0;
                if (k)
                    for ($ = this.start; F < K && $ < O; ++F) A[$ >> 2] |= c[F] << N[$++ & 3];
                else
                    for ($ = this.start; F < K && $ < O; ++F) G = c.charCodeAt(F), G < 128 ? A[$ >> 2] |= G << N[$++ & 3] : G < 2048 ? (A[$ >> 2] |= (192 | G >> 6) << N[$++ & 3], A[$ >> 2] |= (128 | G & 63) << N[$++ & 3]) : G < 55296 || G >= 57344 ? (A[$ >> 2] |= (224 | G >> 12) << N[$++ & 3], A[$ >> 2] |= (128 | G >> 6 & 63) << N[$++ & 3], A[$ >> 2] |= (128 | G & 63) << N[$++ & 3]) : (G = 65536 + ((G & 1023) << 10 | c.charCodeAt(++F) & 1023), A[$ >> 2] |= (240 | G >> 18) << N[$++ & 3], A[$ >> 2] |= (128 | G >> 12 & 63) << N[$++ & 3], A[$ >> 2] |= (128 | G >> 6 & 63) << N[$++ & 3], A[$ >> 2] |= (128 | G & 63) << N[$++ & 3]);
                if (this.lastByteIndex = $, $ >= O) {
                    for (this.start = $ - O, this.block = A[q], $ = 0; $ < q; ++$) Ie[$] ^= A[$];
                    V(Ie), this.reset = !0
                } else this.start = $
            }
            return this
        }, L.prototype.encode = function(c, k) {
            var T = c & 255,
                A = 1,
                O = [T];
            for (c = c >> 8, T = c & 255; T > 0;) O.unshift(T), c = c >> 8, T = c & 255, ++A;
            return k ? O.push(A) : O.unshift(A), this.update(O), O.length
        }, L.prototype.encodeString = function(c) {
            var k, T = typeof c;
            if (T !== "string") {
                if (T === "object") {
                    if (c === null) throw new Error(e);
                    if (v && c.constructor === ArrayBuffer) c = new Uint8Array(c);
                    else if (!Array.isArray(c) && (!v || !ArrayBuffer.isView(c))) throw new Error(e)
                } else throw new Error(e);
                k = !0
            }
            var A = 0,
                O = c.length;
            if (k) A = O;
            else
                for (var K = 0; K < c.length; ++K) {
                    var q = c.charCodeAt(K);
                    q < 128 ? A += 1 : q < 2048 ? A += 2 : q < 55296 || q >= 57344 ? A += 3 : (q = 65536 + ((q & 1023) << 10 | c.charCodeAt(++K) & 1023), A += 4)
                }
            return A += this.encode(A * 8), this.update(c), A
        }, L.prototype.bytepad = function(c, k) {
            for (var T = this.encode(k), A = 0; A < c.length; ++A) T += this.encodeString(c[A]);
            var O = k - T % k,
                K = [];
            return K.length = O, this.update(K), this
        }, L.prototype.finalize = function() {
            if (!this.finalized) {
                this.finalized = !0;
                var c = this.blocks,
                    k = this.lastByteIndex,
                    T = this.blockCount,
                    A = this.s;
                if (c[k >> 2] |= this.padding[k & 3], this.lastByteIndex === this.byteCount)
                    for (c[0] = c[T], k = 1; k < T + 1; ++k) c[k] = 0;
                for (c[T - 1] |= 2147483648, k = 0; k < T; ++k) A[k] ^= c[k];
                V(A)
            }
        }, L.prototype.toString = L.prototype.hex = function() {
            this.finalize();
            for (var c = this.blockCount, k = this.s, T = this.outputBlocks, A = this.extraBytes, O = 0, K = 0, q = "", F; K < T;) {
                for (O = 0; O < c && K < T; ++O, ++K) F = k[O], q += M[F >> 4 & 15] + M[F & 15] + M[F >> 12 & 15] + M[F >> 8 & 15] + M[F >> 20 & 15] + M[F >> 16 & 15] + M[F >> 28 & 15] + M[F >> 24 & 15];
                K % c === 0 && (V(k), O = 0)
            }
            return A && (F = k[O], q += M[F >> 4 & 15] + M[F & 15], A > 1 && (q += M[F >> 12 & 15] + M[F >> 8 & 15]), A > 2 && (q += M[F >> 20 & 15] + M[F >> 16 & 15])), q
        }, L.prototype.arrayBuffer = function() {
            this.finalize();
            var c = this.blockCount,
                k = this.s,
                T = this.outputBlocks,
                A = this.extraBytes,
                O = 0,
                K = 0,
                q = this.outputBits >> 3,
                F;
            A ? F = new ArrayBuffer(T + 1 << 2) : F = new ArrayBuffer(q);
            for (var Ie = new Uint32Array(F); K < T;) {
                for (O = 0; O < c && K < T; ++O, ++K) Ie[K] = k[O];
                K % c === 0 && V(k)
            }
            return A && (Ie[O] = k[O], F = F.slice(0, q)), F
        }, L.prototype.buffer = L.prototype.arrayBuffer, L.prototype.digest = L.prototype.array = function() {
            this.finalize();
            for (var c = this.blockCount, k = this.s, T = this.outputBlocks, A = this.extraBytes, O = 0, K = 0, q = [], F, Ie; K < T;) {
                for (O = 0; O < c && K < T; ++O, ++K) F = K << 2, Ie = k[O], q[F] = Ie & 255, q[F + 1] = Ie >> 8 & 255, q[F + 2] = Ie >> 16 & 255, q[F + 3] = Ie >> 24 & 255;
                K % c === 0 && V(k)
            }
            return A && (F = K << 2, Ie = k[O], q[F] = Ie & 255, A > 1 && (q[F + 1] = Ie >> 8 & 255), A > 2 && (q[F + 2] = Ie >> 16 & 255)), q
        };

        function j(c, k, T) {
            L.call(this, c, k, T)
        }
        j.prototype = new L, j.prototype.finalize = function() {
            return this.encode(this.outputBits, !0), L.prototype.finalize.call(this)
        };
        var V = function(c) {
            var k, T, A, O, K, q, F, Ie, $, G, rt, te, ne, it, re, ie, ot, oe, ae, at, se, le, st, ce, fe, lt, ue, he, ct, de, pe, ft, ge, _e, ut, me, ve, ht, we, ye, dt, be, Me, pt, xe, Se, gt, Ee, Ce, _t, ke, Re, mt, Ae, Te, $e, We, He, ze, je, Ke, Je, Ve;
            for (A = 0; A < 48; A += 2) O = c[0] ^ c[10] ^ c[20] ^ c[30] ^ c[40], K = c[1] ^ c[11] ^ c[21] ^ c[31] ^ c[41], q = c[2] ^ c[12] ^ c[22] ^ c[32] ^ c[42], F = c[3] ^ c[13] ^ c[23] ^ c[33] ^ c[43], Ie = c[4] ^ c[14] ^ c[24] ^ c[34] ^ c[44], $ = c[5] ^ c[15] ^ c[25] ^ c[35] ^ c[45], G = c[6] ^ c[16] ^ c[26] ^ c[36] ^ c[46], rt = c[7] ^ c[17] ^ c[27] ^ c[37] ^ c[47], te = c[8] ^ c[18] ^ c[28] ^ c[38] ^ c[48], ne = c[9] ^ c[19] ^ c[29] ^ c[39] ^ c[49], k = te ^ (q << 1 | F >>> 31), T = ne ^ (F << 1 | q >>> 31), c[0] ^= k, c[1] ^= T, c[10] ^= k, c[11] ^= T, c[20] ^= k, c[21] ^= T, c[30] ^= k, c[31] ^= T, c[40] ^= k, c[41] ^= T, k = O ^ (Ie << 1 | $ >>> 31), T = K ^ ($ << 1 | Ie >>> 31), c[2] ^= k, c[3] ^= T, c[12] ^= k, c[13] ^= T, c[22] ^= k, c[23] ^= T, c[32] ^= k, c[33] ^= T, c[42] ^= k, c[43] ^= T, k = q ^ (G << 1 | rt >>> 31), T = F ^ (rt << 1 | G >>> 31), c[4] ^= k, c[5] ^= T, c[14] ^= k, c[15] ^= T, c[24] ^= k, c[25] ^= T, c[34] ^= k, c[35] ^= T, c[44] ^= k, c[45] ^= T, k = Ie ^ (te << 1 | ne >>> 31), T = $ ^ (ne << 1 | te >>> 31), c[6] ^= k, c[7] ^= T, c[16] ^= k, c[17] ^= T, c[26] ^= k, c[27] ^= T, c[36] ^= k, c[37] ^= T, c[46] ^= k, c[47] ^= T, k = G ^ (O << 1 | K >>> 31), T = rt ^ (K << 1 | O >>> 31), c[8] ^= k, c[9] ^= T, c[18] ^= k, c[19] ^= T, c[28] ^= k, c[29] ^= T, c[38] ^= k, c[39] ^= T, c[48] ^= k, c[49] ^= T, it = c[0], re = c[1], Se = c[11] << 4 | c[10] >>> 28, gt = c[10] << 4 | c[11] >>> 28, he = c[20] << 3 | c[21] >>> 29, ct = c[21] << 3 | c[20] >>> 29, je = c[31] << 9 | c[30] >>> 23, Ke = c[30] << 9 | c[31] >>> 23, be = c[40] << 18 | c[41] >>> 14, Me = c[41] << 18 | c[40] >>> 14, _e = c[2] << 1 | c[3] >>> 31, ut = c[3] << 1 | c[2] >>> 31, ie = c[13] << 12 | c[12] >>> 20, ot = c[12] << 12 | c[13] >>> 20, Ee = c[22] << 10 | c[23] >>> 22, Ce = c[23] << 10 | c[22] >>> 22, de = c[33] << 13 | c[32] >>> 19, pe = c[32] << 13 | c[33] >>> 19, Je = c[42] << 2 | c[43] >>> 30, Ve = c[43] << 2 | c[42] >>> 30, Ae = c[5] << 30 | c[4] >>> 2, Te = c[4] << 30 | c[5] >>> 2, me = c[14] << 6 | c[15] >>> 26, ve = c[15] << 6 | c[14] >>> 26, oe = c[25] << 11 | c[24] >>> 21, ae = c[24] << 11 | c[25] >>> 21, _t = c[34] << 15 | c[35] >>> 17, ke = c[35] << 15 | c[34] >>> 17, ft = c[45] << 29 | c[44] >>> 3, ge = c[44] << 29 | c[45] >>> 3, ce = c[6] << 28 | c[7] >>> 4, fe = c[7] << 28 | c[6] >>> 4, $e = c[17] << 23 | c[16] >>> 9, We = c[16] << 23 | c[17] >>> 9, ht = c[26] << 25 | c[27] >>> 7, we = c[27] << 25 | c[26] >>> 7, at = c[36] << 21 | c[37] >>> 11, se = c[37] << 21 | c[36] >>> 11, Re = c[47] << 24 | c[46] >>> 8, mt = c[46] << 24 | c[47] >>> 8, pt = c[8] << 27 | c[9] >>> 5, xe = c[9] << 27 | c[8] >>> 5, lt = c[18] << 20 | c[19] >>> 12, ue = c[19] << 20 | c[18] >>> 12, He = c[29] << 7 | c[28] >>> 25, ze = c[28] << 7 | c[29] >>> 25, ye = c[38] << 8 | c[39] >>> 24, dt = c[39] << 8 | c[38] >>> 24, le = c[48] << 14 | c[49] >>> 18, st = c[49] << 14 | c[48] >>> 18, c[0] = it ^ ~ie & oe, c[1] = re ^ ~ot & ae, c[10] = ce ^ ~lt & he, c[11] = fe ^ ~ue & ct, c[20] = _e ^ ~me & ht, c[21] = ut ^ ~ve & we, c[30] = pt ^ ~Se & Ee, c[31] = xe ^ ~gt & Ce, c[40] = Ae ^ ~$e & He, c[41] = Te ^ ~We & ze, c[2] = ie ^ ~oe & at, c[3] = ot ^ ~ae & se, c[12] = lt ^ ~he & de, c[13] = ue ^ ~ct & pe, c[22] = me ^ ~ht & ye, c[23] = ve ^ ~we & dt, c[32] = Se ^ ~Ee & _t, c[33] = gt ^ ~Ce & ke, c[42] = $e ^ ~He & je, c[43] = We ^ ~ze & Ke, c[4] = oe ^ ~at & le, c[5] = ae ^ ~se & st, c[14] = he ^ ~de & ft, c[15] = ct ^ ~pe & ge, c[24] = ht ^ ~ye & be, c[25] = we ^ ~dt & Me, c[34] = Ee ^ ~_t & Re, c[35] = Ce ^ ~ke & mt, c[44] = He ^ ~je & Je, c[45] = ze ^ ~Ke & Ve, c[6] = at ^ ~le & it, c[7] = se ^ ~st & re, c[16] = de ^ ~ft & ce, c[17] = pe ^ ~ge & fe, c[26] = ye ^ ~be & _e, c[27] = dt ^ ~Me & ut, c[36] = _t ^ ~Re & pt, c[37] = ke ^ ~mt & xe, c[46] = je ^ ~Je & Ae, c[47] = Ke ^ ~Ve & Te, c[8] = le ^ ~it & ie, c[9] = st ^ ~re & ot, c[18] = ft ^ ~ce & lt, c[19] = ge ^ ~fe & ue, c[28] = be ^ ~_e & me, c[29] = Me ^ ~ut & ve, c[38] = Re ^ ~pt & Se, c[39] = mt ^ ~xe & gt, c[48] = Je ^ ~Ae & $e, c[49] = Ve ^ ~Te & We, c[0] ^= D[A], c[1] ^= D[A + 1]
        };
        if (m) t.exports = u;
        else
            for (w = 0; w < g.length; ++w) s[g[w]] = u[g[w]]
    })()
})(Di);
var Bt = {},
    Qe = {};
Object.defineProperty(Qe, "__esModule", {
    value: !0
});
Qe.isBrowserCryptoAvailable = Qe.getSubtleCrypto = Qe.getBrowerCrypto = void 0;

function nr() {
    return (Le === null || Le === void 0 ? void 0 : Le.crypto) || (Le === null || Le === void 0 ? void 0 : Le.msCrypto) || {}
}
Qe.getBrowerCrypto = nr;

function qi() {
    const t = nr();
    return t.subtle || t.webkitSubtle
}
Qe.getSubtleCrypto = qi;

function vs() {
    return !!nr() && !!qi()
}
Qe.isBrowserCryptoAvailable = vs;
var Ge = {};
Object.defineProperty(Ge, "__esModule", {
    value: !0
});
Ge.isBrowser = Ge.isNode = Ge.isReactNative = void 0;

function $i() {
    return typeof document > "u" && typeof navigator < "u" && navigator.product === "ReactNative"
}
Ge.isReactNative = $i;

function Wi() {
    return typeof process < "u" && typeof process.versions < "u" && typeof process.versions.node < "u"
}
Ge.isNode = Wi;

function ws() {
    return !$i() && !Wi()
}
Ge.isBrowser = ws;
(function(t) {
    var e = Le && Le.__createBinding || (Object.create ? function(r, s, o, h) {
            h === void 0 && (h = o), Object.defineProperty(r, h, {
                enumerable: !0,
                get: function() {
                    return s[o]
                }
            })
        } : function(r, s, o, h) {
            h === void 0 && (h = o), r[h] = s[o]
        }),
        n = Le && Le.__exportStar || function(r, s) {
            for (var o in r) o !== "default" && !s.hasOwnProperty(o) && e(s, r, o)
        };
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), n(Qe, t), n(Ge, t)
})(Bt);

function ys() {
    const t = Date.now() * Math.pow(10, 3),
        e = Math.floor(Math.random() * Math.pow(10, 3));
    return t + e
}

function jt(t) {
    return Fi(t)
}

function bs(t) {
    return fs(Ot(t))
}
const Ms = ys;

function En() {
    return ((e, n) => {
        for (n = e = ""; e++ < 36; n += e * 51 & 52 ? (e ^ 15 ? 8 ^ Math.random() * (e ^ 20 ? 16 : 4) : 4).toString(16) : "-");
        return n
    })()
}

function xs(t) {
    return t === "" || typeof t == "string" && t.trim() === ""
}

function Ss(t) {
    return !(t && t.length)
}

function Hi(t, e) {
    return as(t, e)
}

function Es(t) {
    return typeof t.method < "u"
}

function Fn(t) {
    return typeof t.result < "u"
}

function Qt(t) {
    return typeof t.error < "u"
}

function Er(t) {
    return typeof t.event < "u"
}

function Cs(t) {
    return Ya.includes(t) || t.startsWith("wc_")
}

function ks(t) {
    return t.method.startsWith("wc_") ? !0 : !Ri.includes(t.method)
}

function Rs(t) {
    t = Xe(t.toLowerCase());
    const e = Xe(Di.exports.keccak_256(gs(t)));
    let n = "";
    for (let r = 0; r < t.length; r++) parseInt(e[r], 16) > 7 ? n += t[r].toUpperCase() : n += t[r];
    return Ot(n)
}
const As = t => t ? t.toLowerCase().substring(0, 2) !== "0x" ? !1 : /^(0x)?[0-9a-f]{40}$/i.test(t) ? /^(0x)?[0-9a-f]{40}$/.test(t) || /^(0x)?[0-9A-F]{40}$/.test(t) ? !0 : t === Rs(t) : !1 : !1;

function Cr(t) {
    return !Ss(t) && !Hi(t[0]) && (t[0] = _s(t[0])), t
}

function Cn(t) {
    if (typeof t.type < "u" && t.type !== "0") return t;
    if (typeof t.from > "u" || !As(t.from)) throw new Error("Transaction object must include a valid 'from' value.");

    function e(s) {
        let o = s;
        return (typeof s == "number" || typeof s == "string" && !xs(s)) && (Hi(s) ? typeof s == "string" && (o = jt(s)) : o = Ui(s)), typeof o == "string" && (o = bs(o)), o
    }
    const n = {
            from: jt(t.from),
            to: typeof t.to > "u" ? "" : jt(t.to),
            gasPrice: typeof t.gasPrice > "u" ? "" : e(t.gasPrice),
            gas: typeof t.gas > "u" ? typeof t.gasLimit > "u" ? "" : e(t.gasLimit) : e(t.gas),
            value: typeof t.value > "u" ? "" : e(t.value),
            nonce: typeof t.nonce > "u" ? "" : e(t.nonce),
            data: typeof t.data > "u" ? "" : jt(t.data) || "0x"
        },
        r = ["gasPrice", "gas", "value", "nonce"];
    return Object.keys(n).forEach(s => {
        !n[s].trim().length && r.includes(s) && delete n[s]
    }), n
}

function Ts(t) {
    const e = t.message || "Failed or Rejected Request";
    let n = -32e3;
    if (t && !t.code) switch (e) {
        case "Parse error":
            n = -32700;
            break;
        case "Invalid request":
            n = -32600;
            break;
        case "Method not found":
            n = -32601;
            break;
        case "Invalid params":
            n = -32602;
            break;
        case "Internal error":
            n = -32603;
            break;
        default:
            n = -32e3;
            break
    }
    return {
        code: n,
        message: e
    }
}
var rr = {},
    Is = t => encodeURIComponent(t).replace(/[!'()*]/g, e => `%${e.charCodeAt(0).toString(16).toUpperCase()}`),
    zi = "%[a-f0-9]{2}",
    kr = new RegExp(zi, "gi"),
    Rr = new RegExp("(" + zi + ")+", "gi");

function Un(t, e) {
    try {
        return decodeURIComponent(t.join(""))
    } catch (s) {}
    if (t.length === 1) return t;
    e = e || 1;
    var n = t.slice(0, e),
        r = t.slice(e);
    return Array.prototype.concat.call([], Un(n), Un(r))
}

function Ns(t) {
    try {
        return decodeURIComponent(t)
    } catch (r) {
        for (var e = t.match(kr), n = 1; n < e.length; n++) t = Un(e, n).join(""), e = t.match(kr);
        return t
    }
}

function Os(t) {
    for (var e = {
            "%FE%FF": "\uFFFD\uFFFD",
            "%FF%FE": "\uFFFD\uFFFD"
        }, n = Rr.exec(t); n;) {
        try {
            e[n[0]] = decodeURIComponent(n[0])
        } catch (m) {
            var r = Ns(n[0]);
            r !== n[0] && (e[n[0]] = r)
        }
        n = Rr.exec(t)
    }
    e["%C2"] = "\uFFFD";
    for (var s = Object.keys(e), o = 0; o < s.length; o++) {
        var h = s[o];
        t = t.replace(new RegExp(h, "g"), e[h])
    }
    return t
}
var Bs = function(t) {
        if (typeof t != "string") throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof t + "`");
        try {
            return t = t.replace(/\+/g, " "), decodeURIComponent(t)
        } catch (e) {
            return Os(t)
        }
    },
    Ls = (t, e) => {
        if (!(typeof t == "string" && typeof e == "string")) throw new TypeError("Expected the arguments to be of type `string`");
        if (e === "") return [t];
        const n = t.indexOf(e);
        return n === -1 ? [t] : [t.slice(0, n), t.slice(n + e.length)]
    };
(function(t) {
    const e = Is,
        n = Bs,
        r = Ls,
        s = b => b == null;

    function o(b) {
        switch (b.arrayFormat) {
            case "index":
                return S => (C, E) => {
                    const R = C.length;
                    return E === void 0 || b.skipNull && E === null || b.skipEmptyString && E === "" ? C : E === null ? [...C, [v(S, b), "[", R, "]"].join("")] : [...C, [v(S, b), "[", v(R, b), "]=", v(E, b)].join("")]
                };
            case "bracket":
                return S => (C, E) => E === void 0 || b.skipNull && E === null || b.skipEmptyString && E === "" ? C : E === null ? [...C, [v(S, b), "[]"].join("")] : [...C, [v(S, b), "[]=", v(E, b)].join("")];
            case "comma":
            case "separator":
                return S => (C, E) => E == null || E.length === 0 ? C : C.length === 0 ? [
                    [v(S, b), "=", v(E, b)].join("")
                ] : [
                    [C, v(E, b)].join(b.arrayFormatSeparator)
                ];
            default:
                return S => (C, E) => E === void 0 || b.skipNull && E === null || b.skipEmptyString && E === "" ? C : E === null ? [...C, v(S, b)] : [...C, [v(S, b), "=", v(E, b)].join("")]
        }
    }

    function h(b) {
        let S;
        switch (b.arrayFormat) {
            case "index":
                return (C, E, R) => {
                    if (S = /\[(\d*)\]$/.exec(C), C = C.replace(/\[\d*\]$/, ""), !S) {
                        R[C] = E;
                        return
                    }
                    R[C] === void 0 && (R[C] = {}), R[C][S[1]] = E
                };
            case "bracket":
                return (C, E, R) => {
                    if (S = /(\[\])$/.exec(C), C = C.replace(/\[\]$/, ""), !S) {
                        R[C] = E;
                        return
                    }
                    if (R[C] === void 0) {
                        R[C] = [E];
                        return
                    }
                    R[C] = [].concat(R[C], E)
                };
            case "comma":
            case "separator":
                return (C, E, R) => {
                    const W = typeof E == "string" && E.split("").indexOf(b.arrayFormatSeparator) > -1 ? E.split(b.arrayFormatSeparator).map(Q => M(Q, b)) : E === null ? E : M(E, b);
                    R[C] = W
                };
            default:
                return (C, E, R) => {
                    if (R[C] === void 0) {
                        R[C] = E;
                        return
                    }
                    R[C] = [].concat(R[C], E)
                }
        }
    }

    function m(b) {
        if (typeof b != "string" || b.length !== 1) throw new TypeError("arrayFormatSeparator must be single character string")
    }

    function v(b, S) {
        return S.encode ? S.strict ? e(b) : encodeURIComponent(b) : b
    }

    function M(b, S) {
        return S.decode ? n(b) : b
    }

    function y(b) {
        return Array.isArray(b) ? b.sort() : typeof b == "object" ? y(Object.keys(b)).sort((S, C) => Number(S) - Number(C)).map(S => b[S]) : b
    }

    function I(b) {
        const S = b.indexOf("#");
        return S !== -1 && (b = b.slice(0, S)), b
    }

    function B(b) {
        let S = "";
        const C = b.indexOf("#");
        return C !== -1 && (S = b.slice(C)), S
    }

    function P(b) {
        b = I(b);
        const S = b.indexOf("?");
        return S === -1 ? "" : b.slice(S + 1)
    }

    function N(b, S) {
        return S.parseNumbers && !Number.isNaN(Number(b)) && typeof b == "string" && b.trim() !== "" ? b = Number(b) : S.parseBooleans && b !== null && (b.toLowerCase() === "true" || b.toLowerCase() === "false") && (b = b.toLowerCase() === "true"), b
    }

    function D(b, S) {
        S = Object.assign({
            decode: !0,
            sort: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ",",
            parseNumbers: !1,
            parseBooleans: !1
        }, S), m(S.arrayFormatSeparator);
        const C = h(S),
            E = Object.create(null);
        if (typeof b != "string" || (b = b.trim().replace(/^[?#&]/, ""), !b)) return E;
        for (const R of b.split("&")) {
            let [z, W] = r(S.decode ? R.replace(/\+/g, " ") : R, "=");
            W = W === void 0 ? null : ["comma", "separator"].includes(S.arrayFormat) ? W : M(W, S), C(M(z, S), W, E)
        }
        for (const R of Object.keys(E)) {
            const z = E[R];
            if (typeof z == "object" && z !== null)
                for (const W of Object.keys(z)) z[W] = N(z[W], S);
            else E[R] = N(z, S)
        }
        return S.sort === !1 ? E : (S.sort === !0 ? Object.keys(E).sort() : Object.keys(E).sort(S.sort)).reduce((R, z) => {
            const W = E[z];
            return Boolean(W) && typeof W == "object" && !Array.isArray(W) ? R[z] = y(W) : R[z] = W, R
        }, Object.create(null))
    }
    t.extract = P, t.parse = D, t.stringify = (b, S) => {
        if (!b) return "";
        S = Object.assign({
            encode: !0,
            strict: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ","
        }, S), m(S.arrayFormatSeparator);
        const C = W => S.skipNull && s(b[W]) || S.skipEmptyString && b[W] === "",
            E = o(S),
            R = {};
        for (const W of Object.keys(b)) C(W) || (R[W] = b[W]);
        const z = Object.keys(R);
        return S.sort !== !1 && z.sort(S.sort), z.map(W => {
            const Q = b[W];
            return Q === void 0 ? "" : Q === null ? v(W, S) : Array.isArray(Q) ? Q.reduce(E(W), []).join("&") : v(W, S) + "=" + v(Q, S)
        }).filter(W => W.length > 0).join("&")
    }, t.parseUrl = (b, S) => {
        S = Object.assign({
            decode: !0
        }, S);
        const [C, E] = r(b, "#");
        return Object.assign({
            url: C.split("?")[0] || "",
            query: D(P(b), S)
        }, S && S.parseFragmentIdentifier && E ? {
            fragmentIdentifier: M(E, S)
        } : {})
    }, t.stringifyUrl = (b, S) => {
        S = Object.assign({
            encode: !0,
            strict: !0
        }, S);
        const C = I(b.url).split("?")[0] || "",
            E = t.extract(b.url),
            R = t.parse(E, {
                sort: !1
            }),
            z = Object.assign(R, b.query);
        let W = t.stringify(z, S);
        W && (W = `?${W}`);
        let Q = B(b.url);
        return b.fragmentIdentifier && (Q = `#${v(b.fragmentIdentifier,S)}`), `${C}${W}${Q}`
    }
})(rr);

function Ps(t) {
    const e = t.indexOf("?") !== -1 ? t.indexOf("?") : void 0;
    return typeof e < "u" ? t.substr(e) : ""
}

function Fs(t, e) {
    let n = ji(t);
    return n = Object.assign(Object.assign({}, n), e), t = Us(n), t
}

function ji(t) {
    return rr.parse(t)
}

function Us(t) {
    return rr.stringify(t)
}

function Ds(t) {
    return typeof t.bridge < "u"
}

function qs(t) {
    const e = t.indexOf(":"),
        n = t.indexOf("?") !== -1 ? t.indexOf("?") : void 0,
        r = t.substring(0, e),
        s = t.substring(e + 1, n);

    function o(I) {
        const B = "@",
            P = I.split(B);
        return {
            handshakeTopic: P[0],
            version: parseInt(P[1], 10)
        }
    }
    const h = o(s),
        m = typeof n < "u" ? t.substr(n) : "";

    function v(I) {
        const B = ji(I);
        return {
            key: B.key || "",
            bridge: B.bridge || ""
        }
    }
    const M = v(m);
    return Object.assign(Object.assign({
        protocol: r
    }, h), M)
}
class $s {
    constructor() {
        this._eventEmitters = [], typeof window < "u" && typeof window.addEventListener < "u" && (window.addEventListener("online", () => this.trigger("online")), window.addEventListener("offline", () => this.trigger("offline")))
    }
    on(e, n) {
        this._eventEmitters.push({
            event: e,
            callback: n
        })
    }
    trigger(e) {
        let n = [];
        e && (n = this._eventEmitters.filter(r => r.event === e)), n.forEach(r => {
            r.callback()
        })
    }
}
const Ws = typeof global.WebSocket < "u" ? global.WebSocket : require("ws");
class Hs {
    constructor(e) {
        if (this.opts = e, this._queue = [], this._events = [], this._subscriptions = [], this._protocol = e.protocol, this._version = e.version, this._url = "", this._netMonitor = null, this._socket = null, this._nextSocket = null, this._subscriptions = e.subscriptions || [], this._netMonitor = e.netMonitor || new $s, !e.url || typeof e.url != "string") throw new Error("Missing or invalid WebSocket url");
        this._url = e.url, this._netMonitor.on("online", () => this._socketCreate())
    }
    set readyState(e) {}
    get readyState() {
        return this._socket ? this._socket.readyState : -1
    }
    set connecting(e) {}
    get connecting() {
        return this.readyState === 0
    }
    set connected(e) {}
    get connected() {
        return this.readyState === 1
    }
    set closing(e) {}
    get closing() {
        return this.readyState === 2
    }
    set closed(e) {}
    get closed() {
        return this.readyState === 3
    }
    open() {
        this._socketCreate()
    }
    close() {
        this._socketClose()
    }
    send(e, n, r) {
        if (!n || typeof n != "string") throw new Error("Missing or invalid topic field");
        this._socketSend({
            topic: n,
            type: "pub",
            payload: e,
            silent: !!r
        })
    }
    subscribe(e) {
        this._socketSend({
            topic: e,
            type: "sub",
            payload: "",
            silent: !0
        })
    }
    on(e, n) {
        this._events.push({
            event: e,
            callback: n
        })
    }
    _socketCreate() {
        if (this._nextSocket) return;
        const e = zs(this._url, this._protocol, this._version);
        if (this._nextSocket = new Ws(e), !this._nextSocket) throw new Error("Failed to create socket");
        this._nextSocket.onmessage = n => this._socketReceive(n), this._nextSocket.onopen = () => this._socketOpen(), this._nextSocket.onerror = n => this._socketError(n), this._nextSocket.onclose = () => {
            setTimeout(() => {
                this._nextSocket = null, this._socketCreate()
            }, 1e3)
        }
    }
    _socketOpen() {
        this._socketClose(), this._socket = this._nextSocket, this._nextSocket = null, this._queueSubscriptions(), this._pushQueue()
    }
    _socketClose() {
        this._socket && (this._socket.onclose = () => {}, this._socket.close())
    }
    _socketSend(e) {
        const n = JSON.stringify(e);
        this._socket && this._socket.readyState === 1 ? this._socket.send(n) : (this._setToQueue(e), this._socketCreate())
    }
    async _socketReceive(e) {
        let n;
        try {
            n = JSON.parse(e.data)
        } catch (r) {
            return
        }
        if (this._socketSend({
                topic: n.topic,
                type: "ack",
                payload: "",
                silent: !0
            }), this._socket && this._socket.readyState === 1) {
            const r = this._events.filter(s => s.event === "message");
            r && r.length && r.forEach(s => s.callback(n))
        }
    }
    _socketError(e) {
        const n = this._events.filter(r => r.event === "error");
        n && n.length && n.forEach(r => r.callback(e))
    }
    _queueSubscriptions() {
        this._subscriptions.forEach(n => this._queue.push({
            topic: n,
            type: "sub",
            payload: "",
            silent: !0
        })), this._subscriptions = this.opts.subscriptions || []
    }
    _setToQueue(e) {
        this._queue.push(e)
    }
    _pushQueue() {
        this._queue.forEach(n => this._socketSend(n)), this._queue = []
    }
}

function zs(t, e, n) {
    var r, s;
    const h = (t.startsWith("https") ? t.replace("https", "wss") : t.startsWith("http") ? t.replace("http", "ws") : t).split("?"),
        m = yi() ? {
            protocol: e,
            version: n,
            env: "browser",
            host: ((r = Mi()) === null || r === void 0 ? void 0 : r.host) || ""
        } : {
            protocol: e,
            version: n,
            env: ((s = nn()) === null || s === void 0 ? void 0 : s.name) || ""
        },
        v = Fs(Ps(h[1] || ""), m);
    return h[0] + "?" + v
}
const kn = "Session currently connected",
    vt = "Session currently disconnected",
    js = "Session Rejected",
    Ks = "Missing JSON RPC response",
    Js = 'JSON-RPC success response must include "result" field',
    Vs = 'JSON-RPC error response must include "error" field',
    Ys = 'JSON RPC request must have valid "method" value',
    Qs = 'JSON RPC request must have valid "id" value',
    Gs = "Missing one of the required parameters: bridge / uri / session",
    Ar = "JSON RPC response format is invalid",
    Zs = "URI format is invalid",
    Xs = "QRCode Modal not provided",
    Tr = "User close QRCode Modal";
class el {
    constructor() {
        this._eventEmitters = []
    }
    subscribe(e) {
        this._eventEmitters.push(e)
    }
    unsubscribe(e) {
        this._eventEmitters = this._eventEmitters.filter(n => n.event !== e)
    }
    trigger(e) {
        let n = [],
            r;
        Es(e) ? r = e.method : Fn(e) || Qt(e) ? r = `response:${e.id}` : Er(e) ? r = e.event : r = "", r && (n = this._eventEmitters.filter(s => s.event === r)), (!n || !n.length) && !Cs(r) && !Er(r) && (n = this._eventEmitters.filter(s => s.event === "call_request")), n.forEach(s => {
            if (Qt(e)) {
                const o = new Error(e.error.message);
                s.callback(o, null)
            } else s.callback(null, e)
        })
    }
}
class tl {
    constructor(e = "walletconnect") {
        this.storageId = e
    }
    getSession() {
        let e = null;
        const n = Zn(this.storageId);
        return n && Ds(n) && (e = n), e
    }
    setSession(e) {
        return Gn(this.storageId, e), e
    }
    removeSession() {
        Xn(this.storageId)
    }
}
const nl = "walletconnect.org",
    rl = "abcdefghijklmnopqrstuvwxyz0123456789",
    Ki = rl.split("").map(t => `https://${t}.bridge.walletconnect.org`);

function il(t) {
    let e = t.indexOf("//") > -1 ? t.split("/")[2] : t.split("/")[0];
    return e = e.split(":")[0], e = e.split("?")[0], e
}

function ol(t) {
    return il(t).split(".").slice(-2).join(".")
}

function al() {
    return Math.floor(Math.random() * Ki.length)
}

function sl() {
    return Ki[al()]
}

function ll(t) {
    return ol(t) === nl
}

function cl(t) {
    return ll(t) ? sl() : t
}
class fl {
    constructor(e) {
        if (this.protocol = "wc", this.version = 1, this._bridge = "", this._key = null, this._clientId = "", this._clientMeta = null, this._peerId = "", this._peerMeta = null, this._handshakeId = 0, this._handshakeTopic = "", this._connected = !1, this._accounts = [], this._chainId = 0, this._networkId = 0, this._rpcUrl = "", this._eventManager = new el, this._clientMeta = Ln() || e.connectorOpts.clientMeta || null, this._cryptoLib = e.cryptoLib, this._sessionStorage = e.sessionStorage || new tl(e.connectorOpts.storageId), this._qrcodeModal = e.connectorOpts.qrcodeModal, this._qrcodeModalOptions = e.connectorOpts.qrcodeModalOptions, this._signingMethods = [...Ri, ...e.connectorOpts.signingMethods || []], !e.connectorOpts.bridge && !e.connectorOpts.uri && !e.connectorOpts.session) throw new Error(Gs);
        e.connectorOpts.bridge && (this.bridge = cl(e.connectorOpts.bridge)), e.connectorOpts.uri && (this.uri = e.connectorOpts.uri);
        const n = e.connectorOpts.session || this._getStorageSession();
        n && (this.session = n), this.handshakeId && this._subscribeToSessionResponse(this.handshakeId, "Session request rejected"), this._transport = e.transport || new Hs({
            protocol: this.protocol,
            version: this.version,
            url: this.bridge,
            subscriptions: [this.clientId]
        }), this._subscribeToInternalEvents(), this._initTransport(), e.connectorOpts.uri && this._subscribeToSessionRequest(), e.pushServerOpts && this._registerPushServer(e.pushServerOpts)
    }
    set bridge(e) {
        !e || (this._bridge = e)
    }
    get bridge() {
        return this._bridge
    }
    set key(e) {
        if (!e) return;
        const n = ms(e);
        this._key = n
    }
    get key() {
        return this._key ? hs(this._key, !0) : ""
    }
    set clientId(e) {
        !e || (this._clientId = e)
    }
    get clientId() {
        let e = this._clientId;
        return e || (e = this._clientId = En()), this._clientId
    }
    set peerId(e) {
        !e || (this._peerId = e)
    }
    get peerId() {
        return this._peerId
    }
    set clientMeta(e) {}
    get clientMeta() {
        let e = this._clientMeta;
        return e || (e = this._clientMeta = Ln()), e
    }
    set peerMeta(e) {
        this._peerMeta = e
    }
    get peerMeta() {
        return this._peerMeta
    }
    set handshakeTopic(e) {
        !e || (this._handshakeTopic = e)
    }
    get handshakeTopic() {
        return this._handshakeTopic
    }
    set handshakeId(e) {
        !e || (this._handshakeId = e)
    }
    get handshakeId() {
        return this._handshakeId
    }
    get uri() {
        return this._formatUri()
    }
    set uri(e) {
        if (!e) return;
        const {
            handshakeTopic: n,
            bridge: r,
            key: s
        } = this._parseUri(e);
        this.handshakeTopic = n, this.bridge = r, this.key = s
    }
    set chainId(e) {
        this._chainId = e
    }
    get chainId() {
        return this._chainId
    }
    set networkId(e) {
        this._networkId = e
    }
    get networkId() {
        return this._networkId
    }
    set accounts(e) {
        this._accounts = e
    }
    get accounts() {
        return this._accounts
    }
    set rpcUrl(e) {
        this._rpcUrl = e
    }
    get rpcUrl() {
        return this._rpcUrl
    }
    set connected(e) {}
    get connected() {
        return this._connected
    }
    set pending(e) {}
    get pending() {
        return !!this._handshakeTopic
    }
    get session() {
        return {
            connected: this.connected,
            accounts: this.accounts,
            chainId: this.chainId,
            bridge: this.bridge,
            key: this.key,
            clientId: this.clientId,
            clientMeta: this.clientMeta,
            peerId: this.peerId,
            peerMeta: this.peerMeta,
            handshakeId: this.handshakeId,
            handshakeTopic: this.handshakeTopic
        }
    }
    set session(e) {
        !e || (this._connected = e.connected, this.accounts = e.accounts, this.chainId = e.chainId, this.bridge = e.bridge, this.key = e.key, this.clientId = e.clientId, this.clientMeta = e.clientMeta, this.peerId = e.peerId, this.peerMeta = e.peerMeta, this.handshakeId = e.handshakeId, this.handshakeTopic = e.handshakeTopic)
    }
    on(e, n) {
        const r = {
            event: e,
            callback: n
        };
        this._eventManager.subscribe(r)
    }
    off(e) {
        this._eventManager.unsubscribe(e)
    }
    async createInstantRequest(e) {
        this._key = await this._generateKey();
        const n = this._formatRequest({
            method: "wc_instantRequest",
            params: [{
                peerId: this.clientId,
                peerMeta: this.clientMeta,
                request: this._formatRequest(e)
            }]
        });
        this.handshakeId = n.id, this.handshakeTopic = En(), this._eventManager.trigger({
            event: "display_uri",
            params: [this.uri]
        }), this.on("modal_closed", () => {
            throw new Error(Tr)
        });
        const r = () => {
            this.killSession()
        };
        try {
            const s = await this._sendCallRequest(n);
            return s && r(), s
        } catch (s) {
            throw r(), s
        }
    }
    async connect(e) {
        if (!this._qrcodeModal) throw new Error(Xs);
        return this.connected ? {
            chainId: this.chainId,
            accounts: this.accounts
        } : (await this.createSession(e), new Promise(async (n, r) => {
            this.on("modal_closed", () => r(new Error(Tr))), this.on("connect", (s, o) => {
                if (s) return r(s);
                n(o.params[0])
            })
        }))
    }
    async createSession(e) {
        if (this._connected) throw new Error(kn);
        if (this.pending) return;
        this._key = await this._generateKey();
        const n = this._formatRequest({
            method: "wc_sessionRequest",
            params: [{
                peerId: this.clientId,
                peerMeta: this.clientMeta,
                chainId: e && e.chainId ? e.chainId : null
            }]
        });
        this.handshakeId = n.id, this.handshakeTopic = En(), this._sendSessionRequest(n, "Session update rejected", {
            topic: this.handshakeTopic
        }), this._eventManager.trigger({
            event: "display_uri",
            params: [this.uri]
        })
    }
    approveSession(e) {
        if (this._connected) throw new Error(kn);
        this.chainId = e.chainId, this.accounts = e.accounts, this.networkId = e.networkId || 0, this.rpcUrl = e.rpcUrl || "";
        const n = {
                approved: !0,
                chainId: this.chainId,
                networkId: this.networkId,
                accounts: this.accounts,
                rpcUrl: this.rpcUrl,
                peerId: this.clientId,
                peerMeta: this.clientMeta
            },
            r = {
                id: this.handshakeId,
                jsonrpc: "2.0",
                result: n
            };
        this._sendResponse(r), this._connected = !0, this._setStorageSession(), this._eventManager.trigger({
            event: "connect",
            params: [{
                peerId: this.peerId,
                peerMeta: this.peerMeta,
                chainId: this.chainId,
                accounts: this.accounts
            }]
        })
    }
    rejectSession(e) {
        if (this._connected) throw new Error(kn);
        const n = e && e.message ? e.message : js,
            r = this._formatResponse({
                id: this.handshakeId,
                error: {
                    message: n
                }
            });
        this._sendResponse(r), this._connected = !1, this._eventManager.trigger({
            event: "disconnect",
            params: [{
                message: n
            }]
        }), this._removeStorageSession()
    }
    updateSession(e) {
        if (!this._connected) throw new Error(vt);
        this.chainId = e.chainId, this.accounts = e.accounts, this.networkId = e.networkId || 0, this.rpcUrl = e.rpcUrl || "";
        const n = {
                approved: !0,
                chainId: this.chainId,
                networkId: this.networkId,
                accounts: this.accounts,
                rpcUrl: this.rpcUrl
            },
            r = this._formatRequest({
                method: "wc_sessionUpdate",
                params: [n]
            });
        this._sendSessionRequest(r, "Session update rejected"), this._eventManager.trigger({
            event: "session_update",
            params: [{
                chainId: this.chainId,
                accounts: this.accounts
            }]
        }), this._manageStorageSession()
    }
    async killSession(e) {
        const n = e ? e.message : "Session Disconnected",
            r = {
                approved: !1,
                chainId: null,
                networkId: null,
                accounts: null
            },
            s = this._formatRequest({
                method: "wc_sessionUpdate",
                params: [r]
            });
        await this._sendRequest(s), this._handleSessionDisconnect(n)
    }
    async sendTransaction(e) {
        if (!this._connected) throw new Error(vt);
        const n = Cn(e),
            r = this._formatRequest({
                method: "eth_sendTransaction",
                params: [n]
            });
        return await this._sendCallRequest(r)
    }
    async signTransaction(e) {
        if (!this._connected) throw new Error(vt);
        const n = Cn(e),
            r = this._formatRequest({
                method: "eth_signTransaction",
                params: [n]
            });
        return await this._sendCallRequest(r)
    }
    async signMessage(e) {
        if (!this._connected) throw new Error(vt);
        const n = this._formatRequest({
            method: "eth_sign",
            params: e
        });
        return await this._sendCallRequest(n)
    }
    async signPersonalMessage(e) {
        if (!this._connected) throw new Error(vt);
        e = Cr(e);
        const n = this._formatRequest({
            method: "personal_sign",
            params: e
        });
        return await this._sendCallRequest(n)
    }
    async signTypedData(e) {
        if (!this._connected) throw new Error(vt);
        const n = this._formatRequest({
            method: "eth_signTypedData",
            params: e
        });
        return await this._sendCallRequest(n)
    }
    async updateChain(e) {
        if (!this._connected) throw new Error("Session currently disconnected");
        const n = this._formatRequest({
            method: "wallet_updateChain",
            params: [e]
        });
        return await this._sendCallRequest(n)
    }
    unsafeSend(e, n) {
        return this._sendRequest(e, n), this._eventManager.trigger({
            event: "call_request_sent",
            params: [{
                request: e,
                options: n
            }]
        }), new Promise((r, s) => {
            this._subscribeToResponse(e.id, (o, h) => {
                if (o) {
                    s(o);
                    return
                }
                if (!h) throw new Error(Ks);
                r(h)
            })
        })
    }
    async sendCustomRequest(e, n) {
        if (!this._connected) throw new Error(vt);
        switch (e.method) {
            case "eth_accounts":
                return this.accounts;
            case "eth_chainId":
                return Ui(this.chainId);
            case "eth_sendTransaction":
            case "eth_signTransaction":
                e.params && (e.params[0] = Cn(e.params[0]));
                break;
            case "personal_sign":
                e.params && (e.params = Cr(e.params));
                break
        }
        const r = this._formatRequest(e);
        return await this._sendCallRequest(r, n)
    }
    approveRequest(e) {
        if (Fn(e)) {
            const n = this._formatResponse(e);
            this._sendResponse(n)
        } else throw new Error(Js)
    }
    rejectRequest(e) {
        if (Qt(e)) {
            const n = this._formatResponse(e);
            this._sendResponse(n)
        } else throw new Error(Vs)
    }
    transportClose() {
        this._transport.close()
    }
    async _sendRequest(e, n) {
        const r = this._formatRequest(e),
            s = await this._encrypt(r),
            o = typeof(n == null ? void 0 : n.topic) < "u" ? n.topic : this.peerId,
            h = JSON.stringify(s),
            m = typeof(n == null ? void 0 : n.forcePushNotification) < "u" ? !n.forcePushNotification : ks(r);
        this._transport.send(h, o, m)
    }
    async _sendResponse(e) {
        const n = await this._encrypt(e),
            r = this.peerId,
            s = JSON.stringify(n),
            o = !0;
        this._transport.send(s, r, o)
    }
    async _sendSessionRequest(e, n, r) {
        this._sendRequest(e, r), this._subscribeToSessionResponse(e.id, n)
    }
    _sendCallRequest(e, n) {
        return this._sendRequest(e, n), this._eventManager.trigger({
            event: "call_request_sent",
            params: [{
                request: e,
                options: n
            }]
        }), this._subscribeToCallResponse(e.id)
    }
    _formatRequest(e) {
        if (typeof e.method > "u") throw new Error(Ys);
        return {
            id: typeof e.id > "u" ? Ms() : e.id,
            jsonrpc: "2.0",
            method: e.method,
            params: typeof e.params > "u" ? [] : e.params
        }
    }
    _formatResponse(e) {
        if (typeof e.id > "u") throw new Error(Qs);
        const n = {
            id: e.id,
            jsonrpc: "2.0"
        };
        if (Qt(e)) {
            const r = Ts(e.error);
            return Object.assign(Object.assign(Object.assign({}, n), e), {
                error: r
            })
        } else if (Fn(e)) return Object.assign(Object.assign({}, n), e);
        throw new Error(Ar)
    }
    _handleSessionDisconnect(e) {
        const n = e || "Session Disconnected";
        this._connected || (this._qrcodeModal && this._qrcodeModal.close(), Xn(Yt)), this._connected && (this._connected = !1), this._handshakeId && (this._handshakeId = 0), this._handshakeTopic && (this._handshakeTopic = ""), this._peerId && (this._peerId = ""), this._eventManager.trigger({
            event: "disconnect",
            params: [{
                message: n
            }]
        }), this._removeStorageSession(), this.transportClose()
    }
    _handleSessionResponse(e, n) {
        n ? n.approved ? (this._connected ? (n.chainId && (this.chainId = n.chainId), n.accounts && (this.accounts = n.accounts), this._eventManager.trigger({
            event: "session_update",
            params: [{
                chainId: this.chainId,
                accounts: this.accounts
            }]
        })) : (this._connected = !0, n.chainId && (this.chainId = n.chainId), n.accounts && (this.accounts = n.accounts), n.peerId && !this.peerId && (this.peerId = n.peerId), n.peerMeta && !this.peerMeta && (this.peerMeta = n.peerMeta), this._eventManager.trigger({
            event: "connect",
            params: [{
                peerId: this.peerId,
                peerMeta: this.peerMeta,
                chainId: this.chainId,
                accounts: this.accounts
            }]
        })), this._manageStorageSession()) : this._handleSessionDisconnect(e) : this._handleSessionDisconnect(e)
    }
    async _handleIncomingMessages(e) {
        if (![this.clientId, this.handshakeTopic].includes(e.topic)) return;
        let r;
        try {
            r = JSON.parse(e.payload)
        } catch (o) {
            return
        }
        const s = await this._decrypt(r);
        s && this._eventManager.trigger(s)
    }
    _subscribeToSessionRequest() {
        this._transport.subscribe(this.handshakeTopic)
    }
    _subscribeToResponse(e, n) {
        this.on(`response:${e}`, n)
    }
    _subscribeToSessionResponse(e, n) {
        this._subscribeToResponse(e, (r, s) => {
            if (r) {
                this._handleSessionResponse(r.message);
                return
            }
            s.result ? this._handleSessionResponse(n, s.result) : s.error && s.error.message ? this._handleSessionResponse(s.error.message) : this._handleSessionResponse(n)
        })
    }
    _subscribeToCallResponse(e) {
        return new Promise((n, r) => {
            this._subscribeToResponse(e, (s, o) => {
                if (s) {
                    r(s);
                    return
                }
                o.result ? n(o.result) : o.error && o.error.message ? r(new Error(o.error.message)) : r(new Error(Ar))
            })
        })
    }
    _subscribeToInternalEvents() {
        this.on("display_uri", () => {
            this._qrcodeModal && this._qrcodeModal.open(this.uri, () => {
                this._eventManager.trigger({
                    event: "modal_closed",
                    params: []
                })
            }, this._qrcodeModalOptions)
        }), this.on("connect", () => {
            this._qrcodeModal && this._qrcodeModal.close()
        }), this.on("call_request_sent", (e, n) => {
            const {
                request: r
            } = n.params[0];
            if (vi() && this._signingMethods.includes(r.method)) {
                const s = Zn(Yt);
                s && (window.location.href = s.href)
            }
        }), this.on("wc_sessionRequest", (e, n) => {
            e && this._eventManager.trigger({
                event: "error",
                params: [{
                    code: "SESSION_REQUEST_ERROR",
                    message: e.toString()
                }]
            }), this.handshakeId = n.id, this.peerId = n.params[0].peerId, this.peerMeta = n.params[0].peerMeta;
            const r = Object.assign(Object.assign({}, n), {
                method: "session_request"
            });
            this._eventManager.trigger(r)
        }), this.on("wc_sessionUpdate", (e, n) => {
            e && this._handleSessionResponse(e.message), this._handleSessionResponse("Session disconnected", n.params[0])
        })
    }
    _initTransport() {
        this._transport.on("message", e => this._handleIncomingMessages(e)), this._transport.on("open", () => this._eventManager.trigger({
            event: "transport_open",
            params: []
        })), this._transport.on("close", () => this._eventManager.trigger({
            event: "transport_close",
            params: []
        })), this._transport.on("error", () => this._eventManager.trigger({
            event: "transport_error",
            params: ["Websocket connection failed"]
        })), this._transport.open()
    }
    _formatUri() {
        const e = this.protocol,
            n = this.handshakeTopic,
            r = this.version,
            s = encodeURIComponent(this.bridge),
            o = this.key;
        return `${e}:${n}@${r}?bridge=${s}&key=${o}`
    }
    _parseUri(e) {
        const n = qs(e);
        if (n.protocol === this.protocol) {
            if (!n.handshakeTopic) throw Error("Invalid or missing handshakeTopic parameter value");
            const r = n.handshakeTopic;
            if (!n.bridge) throw Error("Invalid or missing bridge url parameter value");
            const s = decodeURIComponent(n.bridge);
            if (!n.key) throw Error("Invalid or missing key parameter value");
            const o = n.key;
            return {
                handshakeTopic: r,
                bridge: s,
                key: o
            }
        } else throw new Error(Zs)
    }
    async _generateKey() {
        return this._cryptoLib ? await this._cryptoLib.generateKey() : null
    }
    async _encrypt(e) {
        const n = this._key;
        return this._cryptoLib && n ? await this._cryptoLib.encrypt(e, n) : null
    }
    async _decrypt(e) {
        const n = this._key;
        return this._cryptoLib && n ? await this._cryptoLib.decrypt(e, n) : null
    }
    _getStorageSession() {
        let e = null;
        return this._sessionStorage && (e = this._sessionStorage.getSession()), e
    }
    _setStorageSession() {
        this._sessionStorage && this._sessionStorage.setSession(this.session)
    }
    _removeStorageSession() {
        this._sessionStorage && this._sessionStorage.removeSession()
    }
    _manageStorageSession() {
        this._connected ? this._setStorageSession() : this._removeStorageSession()
    }
    _registerPushServer(e) {
        if (!e.url || typeof e.url != "string") throw Error("Invalid or missing pushServerOpts.url parameter value");
        if (!e.type || typeof e.type != "string") throw Error("Invalid or missing pushServerOpts.type parameter value");
        if (!e.token || typeof e.token != "string") throw Error("Invalid or missing pushServerOpts.token parameter value");
        const n = {
            bridge: this.bridge,
            topic: this.clientId,
            type: e.type,
            token: e.token,
            peerName: "",
            language: e.language || ""
        };
        this.on("connect", async (r, s) => {
            if (r) throw r;
            if (e.peerMeta) {
                const o = s.params[0].peerMeta.name;
                n.peerName = o
            }
            try {
                if (!(await (await fetch(`${e.url}/new`, {
                        method: "POST",
                        headers: {
                            Accept: "application/json",
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(n)
                    })).json()).success) throw Error("Failed to register in Push Server")
            } catch (o) {
                throw Error("Failed to register in Push Server")
            }
        })
    }
}

function ul(t) {
    return Bt.getBrowerCrypto().getRandomValues(new Uint8Array(t))
}
const Ji = 256,
    Vi = Ji,
    hl = Ji,
    et = "AES-CBC",
    dl = `SHA-${Vi}`,
    Dn = "HMAC",
    pl = "encrypt",
    gl = "decrypt",
    _l = "sign",
    ml = "verify";

function vl(t) {
    return t === et ? {
        length: Vi,
        name: et
    } : {
        hash: {
            name: dl
        },
        name: Dn
    }
}

function wl(t) {
    return t === et ? [pl, gl] : [_l, ml]
}
async function ir(t, e = et) {
    return Bt.getSubtleCrypto().importKey("raw", t, vl(e), !0, wl(e))
}
async function yl(t, e, n) {
    const r = Bt.getSubtleCrypto(),
        s = await ir(e, et),
        o = await r.encrypt({
            iv: t,
            name: et
        }, s, n);
    return new Uint8Array(o)
}
async function bl(t, e, n) {
    const r = Bt.getSubtleCrypto(),
        s = await ir(e, et),
        o = await r.decrypt({
            iv: t,
            name: et
        }, s, n);
    return new Uint8Array(o)
}
async function Ml(t, e) {
    const n = Bt.getSubtleCrypto(),
        r = await ir(t, Dn),
        s = await n.sign({
            length: hl,
            name: Dn
        }, r, e);
    return new Uint8Array(s)
}

function xl(t, e, n) {
    return yl(t, e, n)
}

function Sl(t, e, n) {
    return bl(t, e, n)
}
async function Yi(t, e) {
    return await Ml(t, e)
}
async function Qi(t) {
    const e = (t || 256) / 8,
        n = ul(e);
    return ds(sn(n))
}
async function Gi(t, e) {
    const n = St(t.data),
        r = St(t.iv),
        s = St(t.hmac),
        o = xt(s, !1),
        h = Pi(n, r),
        m = await Yi(e, h),
        v = xt(m, !1);
    return Xe(o) === Xe(v)
}
async function El(t, e, n) {
    const r = Et(Pn(e)),
        s = n || await Qi(128),
        o = Et(Pn(s)),
        h = xt(o, !1),
        m = JSON.stringify(t),
        v = Li(m),
        M = await xl(o, r, v),
        y = xt(M, !1),
        I = Pi(M, o),
        B = await Yi(r, I),
        P = xt(B, !1);
    return {
        data: y,
        hmac: P,
        iv: h
    }
}
async function Cl(t, e) {
    const n = Et(Pn(e));
    if (!n) throw new Error("Missing key: required for decryption");
    if (!await Gi(t, n)) return null;
    const s = St(t.data),
        o = St(t.iv),
        h = await Sl(o, n, s),
        m = rs(h);
    let v;
    try {
        v = JSON.parse(m)
    } catch (M) {
        return null
    }
    return v
}
var kl = Object.freeze(Object.defineProperty({
    __proto__: null,
    generateKey: Qi,
    verifyHmac: Gi,
    encrypt: El,
    decrypt: Cl
}, Symbol.toStringTag, {
    value: "Module"
}));
class Rl extends fl {
    constructor(e, n) {
        super({
            cryptoLib: kl,
            connectorOpts: e,
            pushServerOpts: n
        })
    }
}
var Al = ni(Va),
    Wt = {},
    Tl = function() {
        return typeof Promise == "function" && Promise.prototype && Promise.prototype.then
    },
    Zi = {},
    tt = {},
    Il = {}.toString,
    or = Array.isArray || function(t) {
        return Il.call(t) == "[object Array]"
    },
    Nl = or;

function Ol() {
    try {
        var t = new Uint8Array(1);
        return t.__proto__ = {
            __proto__: Uint8Array.prototype,
            foo: function() {
                return 42
            }
        }, t.foo() === 42
    } catch (e) {
        return !1
    }
}
Z.TYPED_ARRAY_SUPPORT = Ol();
var Ir = Z.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;

function Z(t, e, n) {
    return !Z.TYPED_ARRAY_SUPPORT && !(this instanceof Z) ? new Z(t, e, n) : typeof t == "number" ? Xi(this, t) : ql(this, t, e, n)
}
Z.TYPED_ARRAY_SUPPORT && (Z.prototype.__proto__ = Uint8Array.prototype, Z.__proto__ = Uint8Array, typeof Symbol < "u" && Symbol.species && Z[Symbol.species] === Z && Object.defineProperty(Z, Symbol.species, {
    value: null,
    configurable: !0,
    enumerable: !1,
    writable: !1
}));

function ar(t) {
    if (t >= Ir) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + Ir.toString(16) + " bytes");
    return t | 0
}

function Bl(t) {
    return t !== t
}

function Ct(t, e) {
    var n;
    return Z.TYPED_ARRAY_SUPPORT ? (n = new Uint8Array(e), n.__proto__ = Z.prototype) : (n = t, n === null && (n = new Z(e)), n.length = e), n
}

function Xi(t, e) {
    var n = Ct(t, e < 0 ? 0 : ar(e) | 0);
    if (!Z.TYPED_ARRAY_SUPPORT)
        for (var r = 0; r < e; ++r) n[r] = 0;
    return n
}

function Ll(t, e) {
    var n = to(e) | 0,
        r = Ct(t, n),
        s = r.write(e);
    return s !== n && (r = r.slice(0, s)), r
}

function qn(t, e) {
    for (var n = e.length < 0 ? 0 : ar(e.length) | 0, r = Ct(t, n), s = 0; s < n; s += 1) r[s] = e[s] & 255;
    return r
}

function Pl(t, e, n, r) {
    if (n < 0 || e.byteLength < n) throw new RangeError("'offset' is out of bounds");
    if (e.byteLength < n + (r || 0)) throw new RangeError("'length' is out of bounds");
    var s;
    return n === void 0 && r === void 0 ? s = new Uint8Array(e) : r === void 0 ? s = new Uint8Array(e, n) : s = new Uint8Array(e, n, r), Z.TYPED_ARRAY_SUPPORT ? s.__proto__ = Z.prototype : s = qn(t, s), s
}

function Fl(t, e) {
    if (Z.isBuffer(e)) {
        var n = ar(e.length) | 0,
            r = Ct(t, n);
        return r.length === 0 || e.copy(r, 0, 0, n), r
    }
    if (e) {
        if (typeof ArrayBuffer < "u" && e.buffer instanceof ArrayBuffer || "length" in e) return typeof e.length != "number" || Bl(e.length) ? Ct(t, 0) : qn(t, e);
        if (e.type === "Buffer" && Array.isArray(e.data)) return qn(t, e.data)
    }
    throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")
}

function eo(t, e) {
    e = e || 1 / 0;
    for (var n, r = t.length, s = null, o = [], h = 0; h < r; ++h) {
        if (n = t.charCodeAt(h), n > 55295 && n < 57344) {
            if (!s) {
                if (n > 56319) {
                    (e -= 3) > -1 && o.push(239, 191, 189);
                    continue
                } else if (h + 1 === r) {
                    (e -= 3) > -1 && o.push(239, 191, 189);
                    continue
                }
                s = n;
                continue
            }
            if (n < 56320) {
                (e -= 3) > -1 && o.push(239, 191, 189), s = n;
                continue
            }
            n = (s - 55296 << 10 | n - 56320) + 65536
        } else s && (e -= 3) > -1 && o.push(239, 191, 189);
        if (s = null, n < 128) {
            if ((e -= 1) < 0) break;
            o.push(n)
        } else if (n < 2048) {
            if ((e -= 2) < 0) break;
            o.push(n >> 6 | 192, n & 63 | 128)
        } else if (n < 65536) {
            if ((e -= 3) < 0) break;
            o.push(n >> 12 | 224, n >> 6 & 63 | 128, n & 63 | 128)
        } else if (n < 1114112) {
            if ((e -= 4) < 0) break;
            o.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, n & 63 | 128)
        } else throw new Error("Invalid code point")
    }
    return o
}

function to(t) {
    if (Z.isBuffer(t)) return t.length;
    if (typeof ArrayBuffer < "u" && typeof ArrayBuffer.isView == "function" && (ArrayBuffer.isView(t) || t instanceof ArrayBuffer)) return t.byteLength;
    typeof t != "string" && (t = "" + t);
    var e = t.length;
    return e === 0 ? 0 : eo(t).length
}

function Ul(t, e, n, r) {
    for (var s = 0; s < r && !(s + n >= e.length || s >= t.length); ++s) e[s + n] = t[s];
    return s
}

function Dl(t, e, n, r) {
    return Ul(eo(e, t.length - n), t, n, r)
}

function ql(t, e, n, r) {
    if (typeof e == "number") throw new TypeError('"value" argument must not be a number');
    return typeof ArrayBuffer < "u" && e instanceof ArrayBuffer ? Pl(t, e, n, r) : typeof e == "string" ? Ll(t, e) : Fl(t, e)
}
Z.prototype.write = function(e, n, r) {
    n === void 0 ? (r = this.length, n = 0) : r === void 0 && typeof n == "string" ? (r = this.length, n = 0) : isFinite(n) && (n = n | 0, isFinite(r) ? r = r | 0 : r = void 0);
    var s = this.length - n;
    if ((r === void 0 || r > s) && (r = s), e.length > 0 && (r < 0 || n < 0) || n > this.length) throw new RangeError("Attempt to write outside buffer bounds");
    return Dl(this, e, n, r)
};
Z.prototype.slice = function(e, n) {
    var r = this.length;
    e = ~~e, n = n === void 0 ? r : ~~n, e < 0 ? (e += r, e < 0 && (e = 0)) : e > r && (e = r), n < 0 ? (n += r, n < 0 && (n = 0)) : n > r && (n = r), n < e && (n = e);
    var s;
    if (Z.TYPED_ARRAY_SUPPORT) s = this.subarray(e, n), s.__proto__ = Z.prototype;
    else {
        var o = n - e;
        s = new Z(o, void 0);
        for (var h = 0; h < o; ++h) s[h] = this[h + e]
    }
    return s
};
Z.prototype.copy = function(e, n, r, s) {
    if (r || (r = 0), !s && s !== 0 && (s = this.length), n >= e.length && (n = e.length), n || (n = 0), s > 0 && s < r && (s = r), s === r || e.length === 0 || this.length === 0) return 0;
    if (n < 0) throw new RangeError("targetStart out of bounds");
    if (r < 0 || r >= this.length) throw new RangeError("sourceStart out of bounds");
    if (s < 0) throw new RangeError("sourceEnd out of bounds");
    s > this.length && (s = this.length), e.length - n < s - r && (s = e.length - n + r);
    var o = s - r,
        h;
    if (this === e && r < n && n < s)
        for (h = o - 1; h >= 0; --h) e[h + n] = this[h + r];
    else if (o < 1e3 || !Z.TYPED_ARRAY_SUPPORT)
        for (h = 0; h < o; ++h) e[h + n] = this[h + r];
    else Uint8Array.prototype.set.call(e, this.subarray(r, r + o), n);
    return o
};
Z.prototype.fill = function(e, n, r) {
    if (typeof e == "string") {
        if (typeof n == "string" ? (n = 0, r = this.length) : typeof r == "string" && (r = this.length), e.length === 1) {
            var s = e.charCodeAt(0);
            s < 256 && (e = s)
        }
    } else typeof e == "number" && (e = e & 255);
    if (n < 0 || this.length < n || this.length < r) throw new RangeError("Out of range index");
    if (r <= n) return this;
    n = n >>> 0, r = r === void 0 ? this.length : r >>> 0, e || (e = 0);
    var o;
    if (typeof e == "number")
        for (o = n; o < r; ++o) this[o] = e;
    else {
        var h = Z.isBuffer(e) ? e : new Z(e),
            m = h.length;
        for (o = 0; o < r - n; ++o) this[o + n] = h[o % m]
    }
    return this
};
Z.concat = function(e, n) {
    if (!Nl(e)) throw new TypeError('"list" argument must be an Array of Buffers');
    if (e.length === 0) return Ct(null, 0);
    var r;
    if (n === void 0)
        for (n = 0, r = 0; r < e.length; ++r) n += e[r].length;
    var s = Xi(null, n),
        o = 0;
    for (r = 0; r < e.length; ++r) {
        var h = e[r];
        if (!Z.isBuffer(h)) throw new TypeError('"list" argument must be an Array of Buffers');
        h.copy(s, o), o += h.length
    }
    return s
};
Z.byteLength = to;
Z.prototype._isBuffer = !0;
Z.isBuffer = function(e) {
    return !!(e != null && e._isBuffer)
};
tt.alloc = function(t) {
    var e = new Z(t);
    return e.fill(0), e
};
tt.from = function(t) {
    return new Z(t)
};
var Be = {},
    sr, $l = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706];
Be.getSymbolSize = function(e) {
    if (!e) throw new Error('"version" cannot be null or undefined');
    if (e < 1 || e > 40) throw new Error('"version" should be in range from 1 to 40');
    return e * 4 + 17
};
Be.getSymbolTotalCodewords = function(e) {
    return $l[e]
};
Be.getBCHDigit = function(t) {
    for (var e = 0; t !== 0;) e++, t >>>= 1;
    return e
};
Be.setToSJISFunction = function(e) {
    if (typeof e != "function") throw new Error('"toSJISFunc" is not a valid function.');
    sr = e
};
Be.isKanjiModeEnabled = function() {
    return typeof sr < "u"
};
Be.toSJIS = function(e) {
    return sr(e)
};
var ln = {};
(function(t) {
    t.L = {
        bit: 1
    }, t.M = {
        bit: 0
    }, t.Q = {
        bit: 3
    }, t.H = {
        bit: 2
    };

    function e(n) {
        if (typeof n != "string") throw new Error("Param is not a string");
        var r = n.toLowerCase();
        switch (r) {
            case "l":
            case "low":
                return t.L;
            case "m":
            case "medium":
                return t.M;
            case "q":
            case "quartile":
                return t.Q;
            case "h":
            case "high":
                return t.H;
            default:
                throw new Error("Unknown EC Level: " + n)
        }
    }
    t.isValid = function(r) {
        return r && typeof r.bit < "u" && r.bit >= 0 && r.bit < 4
    }, t.from = function(r, s) {
        if (t.isValid(r)) return r;
        try {
            return e(r)
        } catch (o) {
            return s
        }
    }
})(ln);

function no() {
    this.buffer = [], this.length = 0
}
no.prototype = {
    get: function(t) {
        var e = Math.floor(t / 8);
        return (this.buffer[e] >>> 7 - t % 8 & 1) === 1
    },
    put: function(t, e) {
        for (var n = 0; n < e; n++) this.putBit((t >>> e - n - 1 & 1) === 1)
    },
    getLengthInBits: function() {
        return this.length
    },
    putBit: function(t) {
        var e = Math.floor(this.length / 8);
        this.buffer.length <= e && this.buffer.push(0), t && (this.buffer[e] |= 128 >>> this.length % 8), this.length++
    }
};
var Wl = no,
    Nr = tt;

function Ht(t) {
    if (!t || t < 1) throw new Error("BitMatrix size must be defined and greater than 0");
    this.size = t, this.data = Nr.alloc(t * t), this.reservedBit = Nr.alloc(t * t)
}
Ht.prototype.set = function(t, e, n, r) {
    var s = t * this.size + e;
    this.data[s] = n, r && (this.reservedBit[s] = !0)
};
Ht.prototype.get = function(t, e) {
    return this.data[t * this.size + e]
};
Ht.prototype.xor = function(t, e, n) {
    this.data[t * this.size + e] ^= n
};
Ht.prototype.isReserved = function(t, e) {
    return this.reservedBit[t * this.size + e]
};
var Hl = Ht,
    ro = {};
(function(t) {
    var e = Be.getSymbolSize;
    t.getRowColCoords = function(r) {
        if (r === 1) return [];
        for (var s = Math.floor(r / 7) + 2, o = e(r), h = o === 145 ? 26 : Math.ceil((o - 13) / (2 * s - 2)) * 2, m = [o - 7], v = 1; v < s - 1; v++) m[v] = m[v - 1] - h;
        return m.push(6), m.reverse()
    }, t.getPositions = function(r) {
        for (var s = [], o = t.getRowColCoords(r), h = o.length, m = 0; m < h; m++)
            for (var v = 0; v < h; v++) m === 0 && v === 0 || m === 0 && v === h - 1 || m === h - 1 && v === 0 || s.push([o[m], o[v]]);
        return s
    }
})(ro);
var io = {},
    zl = Be.getSymbolSize,
    Or = 7;
io.getPositions = function(e) {
    var n = zl(e);
    return [
        [0, 0],
        [n - Or, 0],
        [0, n - Or]
    ]
};
var oo = {};
(function(t) {
    t.Patterns = {
        PATTERN000: 0,
        PATTERN001: 1,
        PATTERN010: 2,
        PATTERN011: 3,
        PATTERN100: 4,
        PATTERN101: 5,
        PATTERN110: 6,
        PATTERN111: 7
    };
    var e = {
        N1: 3,
        N2: 3,
        N3: 40,
        N4: 10
    };
    t.isValid = function(s) {
        return s != null && s !== "" && !isNaN(s) && s >= 0 && s <= 7
    }, t.from = function(s) {
        return t.isValid(s) ? parseInt(s, 10) : void 0
    }, t.getPenaltyN1 = function(s) {
        for (var o = s.size, h = 0, m = 0, v = 0, M = null, y = null, I = 0; I < o; I++) {
            m = v = 0, M = y = null;
            for (var B = 0; B < o; B++) {
                var P = s.get(I, B);
                P === M ? m++ : (m >= 5 && (h += e.N1 + (m - 5)), M = P, m = 1), P = s.get(B, I), P === y ? v++ : (v >= 5 && (h += e.N1 + (v - 5)), y = P, v = 1)
            }
            m >= 5 && (h += e.N1 + (m - 5)), v >= 5 && (h += e.N1 + (v - 5))
        }
        return h
    }, t.getPenaltyN2 = function(s) {
        for (var o = s.size, h = 0, m = 0; m < o - 1; m++)
            for (var v = 0; v < o - 1; v++) {
                var M = s.get(m, v) + s.get(m, v + 1) + s.get(m + 1, v) + s.get(m + 1, v + 1);
                (M === 4 || M === 0) && h++
            }
        return h * e.N2
    }, t.getPenaltyN3 = function(s) {
        for (var o = s.size, h = 0, m = 0, v = 0, M = 0; M < o; M++) {
            m = v = 0;
            for (var y = 0; y < o; y++) m = m << 1 & 2047 | s.get(M, y), y >= 10 && (m === 1488 || m === 93) && h++, v = v << 1 & 2047 | s.get(y, M), y >= 10 && (v === 1488 || v === 93) && h++
        }
        return h * e.N3
    }, t.getPenaltyN4 = function(s) {
        for (var o = 0, h = s.data.length, m = 0; m < h; m++) o += s.data[m];
        var v = Math.abs(Math.ceil(o * 100 / h / 5) - 10);
        return v * e.N4
    };

    function n(r, s, o) {
        switch (r) {
            case t.Patterns.PATTERN000:
                return (s + o) % 2 === 0;
            case t.Patterns.PATTERN001:
                return s % 2 === 0;
            case t.Patterns.PATTERN010:
                return o % 3 === 0;
            case t.Patterns.PATTERN011:
                return (s + o) % 3 === 0;
            case t.Patterns.PATTERN100:
                return (Math.floor(s / 2) + Math.floor(o / 3)) % 2 === 0;
            case t.Patterns.PATTERN101:
                return s * o % 2 + s * o % 3 === 0;
            case t.Patterns.PATTERN110:
                return (s * o % 2 + s * o % 3) % 2 === 0;
            case t.Patterns.PATTERN111:
                return (s * o % 3 + (s + o) % 2) % 2 === 0;
            default:
                throw new Error("bad maskPattern:" + r)
        }
    }
    t.applyMask = function(s, o) {
        for (var h = o.size, m = 0; m < h; m++)
            for (var v = 0; v < h; v++) o.isReserved(v, m) || o.xor(v, m, n(s, v, m))
    }, t.getBestMask = function(s, o) {
        for (var h = Object.keys(t.Patterns).length, m = 0, v = 1 / 0, M = 0; M < h; M++) {
            o(M), t.applyMask(M, s);
            var y = t.getPenaltyN1(s) + t.getPenaltyN2(s) + t.getPenaltyN3(s) + t.getPenaltyN4(s);
            t.applyMask(M, s), y < v && (v = y, m = M)
        }
        return m
    }
})(oo);
var cn = {},
    Ye = ln,
    Kt = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 4, 2, 4, 6, 5, 2, 4, 6, 6, 2, 5, 8, 8, 4, 5, 8, 8, 4, 5, 8, 11, 4, 8, 10, 11, 4, 9, 12, 16, 4, 9, 16, 16, 6, 10, 12, 18, 6, 10, 17, 16, 6, 11, 16, 19, 6, 13, 18, 21, 7, 14, 21, 25, 8, 16, 20, 25, 8, 17, 23, 25, 9, 17, 23, 34, 9, 18, 25, 30, 10, 20, 27, 32, 12, 21, 29, 35, 12, 23, 34, 37, 12, 25, 34, 40, 13, 26, 35, 42, 14, 28, 38, 45, 15, 29, 40, 48, 16, 31, 43, 51, 17, 33, 45, 54, 18, 35, 48, 57, 19, 37, 51, 60, 19, 38, 53, 63, 20, 40, 56, 66, 21, 43, 59, 70, 22, 45, 62, 74, 24, 47, 65, 77, 25, 49, 68, 81],
    Jt = [7, 10, 13, 17, 10, 16, 22, 28, 15, 26, 36, 44, 20, 36, 52, 64, 26, 48, 72, 88, 36, 64, 96, 112, 40, 72, 108, 130, 48, 88, 132, 156, 60, 110, 160, 192, 72, 130, 192, 224, 80, 150, 224, 264, 96, 176, 260, 308, 104, 198, 288, 352, 120, 216, 320, 384, 132, 240, 360, 432, 144, 280, 408, 480, 168, 308, 448, 532, 180, 338, 504, 588, 196, 364, 546, 650, 224, 416, 600, 700, 224, 442, 644, 750, 252, 476, 690, 816, 270, 504, 750, 900, 300, 560, 810, 960, 312, 588, 870, 1050, 336, 644, 952, 1110, 360, 700, 1020, 1200, 390, 728, 1050, 1260, 420, 784, 1140, 1350, 450, 812, 1200, 1440, 480, 868, 1290, 1530, 510, 924, 1350, 1620, 540, 980, 1440, 1710, 570, 1036, 1530, 1800, 570, 1064, 1590, 1890, 600, 1120, 1680, 1980, 630, 1204, 1770, 2100, 660, 1260, 1860, 2220, 720, 1316, 1950, 2310, 750, 1372, 2040, 2430];
cn.getBlocksCount = function(e, n) {
    switch (n) {
        case Ye.L:
            return Kt[(e - 1) * 4 + 0];
        case Ye.M:
            return Kt[(e - 1) * 4 + 1];
        case Ye.Q:
            return Kt[(e - 1) * 4 + 2];
        case Ye.H:
            return Kt[(e - 1) * 4 + 3];
        default:
            return
    }
};
cn.getTotalCodewordsCount = function(e, n) {
    switch (n) {
        case Ye.L:
            return Jt[(e - 1) * 4 + 0];
        case Ye.M:
            return Jt[(e - 1) * 4 + 1];
        case Ye.Q:
            return Jt[(e - 1) * 4 + 2];
        case Ye.H:
            return Jt[(e - 1) * 4 + 3];
        default:
            return
    }
};
var ao = {},
    fn = {},
    so = tt,
    Pt = so.alloc(512),
    Gt = so.alloc(256);
(function() {
    for (var e = 1, n = 0; n < 255; n++) Pt[n] = e, Gt[e] = n, e <<= 1, e & 256 && (e ^= 285);
    for (n = 255; n < 512; n++) Pt[n] = Pt[n - 255]
})();
fn.log = function(e) {
    if (e < 1) throw new Error("log(" + e + ")");
    return Gt[e]
};
fn.exp = function(e) {
    return Pt[e]
};
fn.mul = function(e, n) {
    return e === 0 || n === 0 ? 0 : Pt[Gt[e] + Gt[n]]
};
(function(t) {
    var e = tt,
        n = fn;
    t.mul = function(s, o) {
        for (var h = e.alloc(s.length + o.length - 1), m = 0; m < s.length; m++)
            for (var v = 0; v < o.length; v++) h[m + v] ^= n.mul(s[m], o[v]);
        return h
    }, t.mod = function(s, o) {
        for (var h = e.from(s); h.length - o.length >= 0;) {
            for (var m = h[0], v = 0; v < o.length; v++) h[v] ^= n.mul(o[v], m);
            for (var M = 0; M < h.length && h[M] === 0;) M++;
            h = h.slice(M)
        }
        return h
    }, t.generateECPolynomial = function(s) {
        for (var o = e.from([1]), h = 0; h < s; h++) o = t.mul(o, [1, n.exp(h)]);
        return o
    }
})(ao);
var Br = tt,
    lo = ao,
    jl = ia.Buffer;

function lr(t) {
    this.genPoly = void 0, this.degree = t, this.degree && this.initialize(this.degree)
}
lr.prototype.initialize = function(e) {
    this.degree = e, this.genPoly = lo.generateECPolynomial(this.degree)
};
lr.prototype.encode = function(e) {
    if (!this.genPoly) throw new Error("Encoder not initialized");
    var n = Br.alloc(this.degree),
        r = jl.concat([e, n], e.length + this.degree),
        s = lo.mod(r, this.genPoly),
        o = this.degree - s.length;
    if (o > 0) {
        var h = Br.alloc(this.degree);
        return s.copy(h, o), h
    }
    return s
};
var Kl = lr,
    co = {},
    nt = {},
    cr = {};
cr.isValid = function(e) {
    return !isNaN(e) && e >= 1 && e <= 40
};
var Fe = {},
    fo = "[0-9]+",
    Jl = "[A-Z $%*+\\-./:]+",
    Dt = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+";
Dt = Dt.replace(/u/g, "\\u");
var Vl = "(?:(?![A-Z0-9 $%*+\\-./:]|" + Dt + `)(?:.|[\r
]))+`;
Fe.KANJI = new RegExp(Dt, "g");
Fe.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g");
Fe.BYTE = new RegExp(Vl, "g");
Fe.NUMERIC = new RegExp(fo, "g");
Fe.ALPHANUMERIC = new RegExp(Jl, "g");
var Yl = new RegExp("^" + Dt + "$"),
    Ql = new RegExp("^" + fo + "$"),
    Gl = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
Fe.testKanji = function(e) {
    return Yl.test(e)
};
Fe.testNumeric = function(e) {
    return Ql.test(e)
};
Fe.testAlphanumeric = function(e) {
    return Gl.test(e)
};
(function(t) {
    var e = cr,
        n = Fe;
    t.NUMERIC = {
        id: "Numeric",
        bit: 1 << 0,
        ccBits: [10, 12, 14]
    }, t.ALPHANUMERIC = {
        id: "Alphanumeric",
        bit: 1 << 1,
        ccBits: [9, 11, 13]
    }, t.BYTE = {
        id: "Byte",
        bit: 1 << 2,
        ccBits: [8, 16, 16]
    }, t.KANJI = {
        id: "Kanji",
        bit: 1 << 3,
        ccBits: [8, 10, 12]
    }, t.MIXED = {
        bit: -1
    }, t.getCharCountIndicator = function(o, h) {
        if (!o.ccBits) throw new Error("Invalid mode: " + o);
        if (!e.isValid(h)) throw new Error("Invalid version: " + h);
        return h >= 1 && h < 10 ? o.ccBits[0] : h < 27 ? o.ccBits[1] : o.ccBits[2]
    }, t.getBestModeForData = function(o) {
        return n.testNumeric(o) ? t.NUMERIC : n.testAlphanumeric(o) ? t.ALPHANUMERIC : n.testKanji(o) ? t.KANJI : t.BYTE
    }, t.toString = function(o) {
        if (o && o.id) return o.id;
        throw new Error("Invalid mode")
    }, t.isValid = function(o) {
        return o && o.bit && o.ccBits
    };

    function r(s) {
        if (typeof s != "string") throw new Error("Param is not a string");
        var o = s.toLowerCase();
        switch (o) {
            case "numeric":
                return t.NUMERIC;
            case "alphanumeric":
                return t.ALPHANUMERIC;
            case "kanji":
                return t.KANJI;
            case "byte":
                return t.BYTE;
            default:
                throw new Error("Unknown mode: " + s)
        }
    }
    t.from = function(o, h) {
        if (t.isValid(o)) return o;
        try {
            return r(o)
        } catch (m) {
            return h
        }
    }
})(nt);
(function(t) {
    var e = Be,
        n = cn,
        r = ln,
        s = nt,
        o = cr,
        h = or,
        m = 1 << 12 | 1 << 11 | 1 << 10 | 1 << 9 | 1 << 8 | 1 << 5 | 1 << 2 | 1 << 0,
        v = e.getBCHDigit(m);

    function M(P, N, D) {
        for (var b = 1; b <= 40; b++)
            if (N <= t.getCapacity(b, D, P)) return b
    }

    function y(P, N) {
        return s.getCharCountIndicator(P, N) + 4
    }

    function I(P, N) {
        var D = 0;
        return P.forEach(function(b) {
            var S = y(b.mode, N);
            D += S + b.getBitsLength()
        }), D
    }

    function B(P, N) {
        for (var D = 1; D <= 40; D++) {
            var b = I(P, D);
            if (b <= t.getCapacity(D, N, s.MIXED)) return D
        }
    }
    t.from = function(N, D) {
        return o.isValid(N) ? parseInt(N, 10) : D
    }, t.getCapacity = function(N, D, b) {
        if (!o.isValid(N)) throw new Error("Invalid QR Code version");
        typeof b > "u" && (b = s.BYTE);
        var S = e.getSymbolTotalCodewords(N),
            C = n.getTotalCodewordsCount(N, D),
            E = (S - C) * 8;
        if (b === s.MIXED) return E;
        var R = E - y(b, N);
        switch (b) {
            case s.NUMERIC:
                return Math.floor(R / 10 * 3);
            case s.ALPHANUMERIC:
                return Math.floor(R / 11 * 2);
            case s.KANJI:
                return Math.floor(R / 13);
            case s.BYTE:
            default:
                return Math.floor(R / 8)
        }
    }, t.getBestVersionForData = function(N, D) {
        var b, S = r.from(D, r.M);
        if (h(N)) {
            if (N.length > 1) return B(N, S);
            if (N.length === 0) return 1;
            b = N[0]
        } else b = N;
        return M(b.mode, b.getLength(), S)
    }, t.getEncodedBits = function(N) {
        if (!o.isValid(N) || N < 7) throw new Error("Invalid QR Code version");
        for (var D = N << 12; e.getBCHDigit(D) - v >= 0;) D ^= m << e.getBCHDigit(D) - v;
        return N << 12 | D
    }
})(co);
var uo = {},
    $n = Be,
    ho = 1 << 10 | 1 << 8 | 1 << 5 | 1 << 4 | 1 << 2 | 1 << 1 | 1 << 0,
    Zl = 1 << 14 | 1 << 12 | 1 << 10 | 1 << 4 | 1 << 1,
    Lr = $n.getBCHDigit(ho);
uo.getEncodedBits = function(e, n) {
    for (var r = e.bit << 3 | n, s = r << 10; $n.getBCHDigit(s) - Lr >= 0;) s ^= ho << $n.getBCHDigit(s) - Lr;
    return (r << 10 | s) ^ Zl
};
var po = {},
    Xl = nt;

function kt(t) {
    this.mode = Xl.NUMERIC, this.data = t.toString()
}
kt.getBitsLength = function(e) {
    return 10 * Math.floor(e / 3) + (e % 3 ? e % 3 * 3 + 1 : 0)
};
kt.prototype.getLength = function() {
    return this.data.length
};
kt.prototype.getBitsLength = function() {
    return kt.getBitsLength(this.data.length)
};
kt.prototype.write = function(e) {
    var n, r, s;
    for (n = 0; n + 3 <= this.data.length; n += 3) r = this.data.substr(n, 3), s = parseInt(r, 10), e.put(s, 10);
    var o = this.data.length - n;
    o > 0 && (r = this.data.substr(n), s = parseInt(r, 10), e.put(s, o * 3 + 1))
};
var ec = kt,
    tc = nt,
    Rn = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "$", "%", "*", "+", "-", ".", "/", ":"];

function Rt(t) {
    this.mode = tc.ALPHANUMERIC, this.data = t
}
Rt.getBitsLength = function(e) {
    return 11 * Math.floor(e / 2) + 6 * (e % 2)
};
Rt.prototype.getLength = function() {
    return this.data.length
};
Rt.prototype.getBitsLength = function() {
    return Rt.getBitsLength(this.data.length)
};
Rt.prototype.write = function(e) {
    var n;
    for (n = 0; n + 2 <= this.data.length; n += 2) {
        var r = Rn.indexOf(this.data[n]) * 45;
        r += Rn.indexOf(this.data[n + 1]), e.put(r, 11)
    }
    this.data.length % 2 && e.put(Rn.indexOf(this.data[n]), 6)
};
var nc = Rt,
    rc = tt,
    ic = nt;

function At(t) {
    this.mode = ic.BYTE, this.data = rc.from(t)
}
At.getBitsLength = function(e) {
    return e * 8
};
At.prototype.getLength = function() {
    return this.data.length
};
At.prototype.getBitsLength = function() {
    return At.getBitsLength(this.data.length)
};
At.prototype.write = function(t) {
    for (var e = 0, n = this.data.length; e < n; e++) t.put(this.data[e], 8)
};
var oc = At,
    ac = nt,
    sc = Be;

function Tt(t) {
    this.mode = ac.KANJI, this.data = t
}
Tt.getBitsLength = function(e) {
    return e * 13
};
Tt.prototype.getLength = function() {
    return this.data.length
};
Tt.prototype.getBitsLength = function() {
    return Tt.getBitsLength(this.data.length)
};
Tt.prototype.write = function(t) {
    var e;
    for (e = 0; e < this.data.length; e++) {
        var n = sc.toSJIS(this.data[e]);
        if (n >= 33088 && n <= 40956) n -= 33088;
        else if (n >= 57408 && n <= 60351) n -= 49472;
        else throw new Error("Invalid SJIS character: " + this.data[e] + `
Make sure your charset is UTF-8`);
        n = (n >>> 8 & 255) * 192 + (n & 255), t.put(n, 13)
    }
};
var lc = Tt;
(function(t) {
    var e = nt,
        n = ec,
        r = nc,
        s = oc,
        o = lc,
        h = Fe,
        m = Be,
        v = oa.exports;

    function M(S) {
        return unescape(encodeURIComponent(S)).length
    }

    function y(S, C, E) {
        for (var R = [], z;
            (z = S.exec(E)) !== null;) R.push({
            data: z[0],
            index: z.index,
            mode: C,
            length: z[0].length
        });
        return R
    }

    function I(S) {
        var C = y(h.NUMERIC, e.NUMERIC, S),
            E = y(h.ALPHANUMERIC, e.ALPHANUMERIC, S),
            R, z;
        m.isKanjiModeEnabled() ? (R = y(h.BYTE, e.BYTE, S), z = y(h.KANJI, e.KANJI, S)) : (R = y(h.BYTE_KANJI, e.BYTE, S), z = []);
        var W = C.concat(E, R, z);
        return W.sort(function(Q, J) {
            return Q.index - J.index
        }).map(function(Q) {
            return {
                data: Q.data,
                mode: Q.mode,
                length: Q.length
            }
        })
    }

    function B(S, C) {
        switch (C) {
            case e.NUMERIC:
                return n.getBitsLength(S);
            case e.ALPHANUMERIC:
                return r.getBitsLength(S);
            case e.KANJI:
                return o.getBitsLength(S);
            case e.BYTE:
                return s.getBitsLength(S)
        }
    }

    function P(S) {
        return S.reduce(function(C, E) {
            var R = C.length - 1 >= 0 ? C[C.length - 1] : null;
            return R && R.mode === E.mode ? (C[C.length - 1].data += E.data, C) : (C.push(E), C)
        }, [])
    }

    function N(S) {
        for (var C = [], E = 0; E < S.length; E++) {
            var R = S[E];
            switch (R.mode) {
                case e.NUMERIC:
                    C.push([R, {
                        data: R.data,
                        mode: e.ALPHANUMERIC,
                        length: R.length
                    }, {
                        data: R.data,
                        mode: e.BYTE,
                        length: R.length
                    }]);
                    break;
                case e.ALPHANUMERIC:
                    C.push([R, {
                        data: R.data,
                        mode: e.BYTE,
                        length: R.length
                    }]);
                    break;
                case e.KANJI:
                    C.push([R, {
                        data: R.data,
                        mode: e.BYTE,
                        length: M(R.data)
                    }]);
                    break;
                case e.BYTE:
                    C.push([{
                        data: R.data,
                        mode: e.BYTE,
                        length: M(R.data)
                    }])
            }
        }
        return C
    }

    function D(S, C) {
        for (var E = {}, R = {
                start: {}
            }, z = ["start"], W = 0; W < S.length; W++) {
            for (var Q = S[W], J = [], X = 0; X < Q.length; X++) {
                var _ = Q[X],
                    i = "" + W + X;
                J.push(i), E[i] = {
                    node: _,
                    lastCount: 0
                }, R[i] = {};
                for (var l = 0; l < z.length; l++) {
                    var f = z[l];
                    E[f] && E[f].node.mode === _.mode ? (R[f][i] = B(E[f].lastCount + _.length, _.mode) - B(E[f].lastCount, _.mode), E[f].lastCount += _.length) : (E[f] && (E[f].lastCount = _.length), R[f][i] = B(_.length, _.mode) + 4 + e.getCharCountIndicator(_.mode, C))
                }
            }
            z = J
        }
        for (l = 0; l < z.length; l++) R[z[l]].end = 0;
        return {
            map: R,
            table: E
        }
    }

    function b(S, C) {
        var E, R = e.getBestModeForData(S);
        if (E = e.from(C, R), E !== e.BYTE && E.bit < R.bit) throw new Error('"' + S + '" cannot be encoded with mode ' + e.toString(E) + `.
 Suggested mode is: ` + e.toString(R));
        switch (E === e.KANJI && !m.isKanjiModeEnabled() && (E = e.BYTE), E) {
            case e.NUMERIC:
                return new n(S);
            case e.ALPHANUMERIC:
                return new r(S);
            case e.KANJI:
                return new o(S);
            case e.BYTE:
                return new s(S)
        }
    }
    t.fromArray = function(C) {
        return C.reduce(function(E, R) {
            return typeof R == "string" ? E.push(b(R, null)) : R.data && E.push(b(R.data, R.mode)), E
        }, [])
    }, t.fromString = function(C, E) {
        for (var R = I(C, m.isKanjiModeEnabled()), z = N(R), W = D(z, E), Q = v.find_path(W.map, "start", "end"), J = [], X = 1; X < Q.length - 1; X++) J.push(W.table[Q[X]].node);
        return t.fromArray(P(J))
    }, t.rawSplit = function(C) {
        return t.fromArray(I(C, m.isKanjiModeEnabled()))
    }
})(po);
var Pr = tt,
    un = Be,
    An = ln,
    cc = Wl,
    fc = Hl,
    uc = ro,
    hc = io,
    Wn = oo,
    Hn = cn,
    dc = Kl,
    Zt = co,
    pc = uo,
    gc = nt,
    Tn = po,
    _c = or;

function mc(t, e) {
    for (var n = t.size, r = hc.getPositions(e), s = 0; s < r.length; s++)
        for (var o = r[s][0], h = r[s][1], m = -1; m <= 7; m++)
            if (!(o + m <= -1 || n <= o + m))
                for (var v = -1; v <= 7; v++) h + v <= -1 || n <= h + v || (m >= 0 && m <= 6 && (v === 0 || v === 6) || v >= 0 && v <= 6 && (m === 0 || m === 6) || m >= 2 && m <= 4 && v >= 2 && v <= 4 ? t.set(o + m, h + v, !0, !0) : t.set(o + m, h + v, !1, !0))
}

function vc(t) {
    for (var e = t.size, n = 8; n < e - 8; n++) {
        var r = n % 2 === 0;
        t.set(n, 6, r, !0), t.set(6, n, r, !0)
    }
}

function wc(t, e) {
    for (var n = uc.getPositions(e), r = 0; r < n.length; r++)
        for (var s = n[r][0], o = n[r][1], h = -2; h <= 2; h++)
            for (var m = -2; m <= 2; m++) h === -2 || h === 2 || m === -2 || m === 2 || h === 0 && m === 0 ? t.set(s + h, o + m, !0, !0) : t.set(s + h, o + m, !1, !0)
}

function yc(t, e) {
    for (var n = t.size, r = Zt.getEncodedBits(e), s, o, h, m = 0; m < 18; m++) s = Math.floor(m / 3), o = m % 3 + n - 8 - 3, h = (r >> m & 1) === 1, t.set(s, o, h, !0), t.set(o, s, h, !0)
}

function In(t, e, n) {
    var r = t.size,
        s = pc.getEncodedBits(e, n),
        o, h;
    for (o = 0; o < 15; o++) h = (s >> o & 1) === 1, o < 6 ? t.set(o, 8, h, !0) : o < 8 ? t.set(o + 1, 8, h, !0) : t.set(r - 15 + o, 8, h, !0), o < 8 ? t.set(8, r - o - 1, h, !0) : o < 9 ? t.set(8, 15 - o - 1 + 1, h, !0) : t.set(8, 15 - o - 1, h, !0);
    t.set(r - 8, 8, 1, !0)
}

function bc(t, e) {
    for (var n = t.size, r = -1, s = n - 1, o = 7, h = 0, m = n - 1; m > 0; m -= 2)
        for (m === 6 && m--;;) {
            for (var v = 0; v < 2; v++)
                if (!t.isReserved(s, m - v)) {
                    var M = !1;
                    h < e.length && (M = (e[h] >>> o & 1) === 1), t.set(s, m - v, M), o--, o === -1 && (h++, o = 7)
                }
            if (s += r, s < 0 || n <= s) {
                s -= r, r = -r;
                break
            }
        }
}

function Mc(t, e, n) {
    var r = new cc;
    n.forEach(function(M) {
        r.put(M.mode.bit, 4), r.put(M.getLength(), gc.getCharCountIndicator(M.mode, t)), M.write(r)
    });
    var s = un.getSymbolTotalCodewords(t),
        o = Hn.getTotalCodewordsCount(t, e),
        h = (s - o) * 8;
    for (r.getLengthInBits() + 4 <= h && r.put(0, 4); r.getLengthInBits() % 8 !== 0;) r.putBit(0);
    for (var m = (h - r.getLengthInBits()) / 8, v = 0; v < m; v++) r.put(v % 2 ? 17 : 236, 8);
    return xc(r, t, e)
}

function xc(t, e, n) {
    for (var r = un.getSymbolTotalCodewords(e), s = Hn.getTotalCodewordsCount(e, n), o = r - s, h = Hn.getBlocksCount(e, n), m = r % h, v = h - m, M = Math.floor(r / h), y = Math.floor(o / h), I = y + 1, B = M - y, P = new dc(B), N = 0, D = new Array(h), b = new Array(h), S = 0, C = Pr.from(t.buffer), E = 0; E < h; E++) {
        var R = E < v ? y : I;
        D[E] = C.slice(N, N + R), b[E] = P.encode(D[E]), N += R, S = Math.max(S, R)
    }
    var z = Pr.alloc(r),
        W = 0,
        Q, J;
    for (Q = 0; Q < S; Q++)
        for (J = 0; J < h; J++) Q < D[J].length && (z[W++] = D[J][Q]);
    for (Q = 0; Q < B; Q++)
        for (J = 0; J < h; J++) z[W++] = b[J][Q];
    return z
}

function Sc(t, e, n, r) {
    var s;
    if (_c(t)) s = Tn.fromArray(t);
    else if (typeof t == "string") {
        var o = e;
        if (!o) {
            var h = Tn.rawSplit(t);
            o = Zt.getBestVersionForData(h, n)
        }
        s = Tn.fromString(t, o || 40)
    } else throw new Error("Invalid data");
    var m = Zt.getBestVersionForData(s, n);
    if (!m) throw new Error("The amount of data is too big to be stored in a QR Code");
    if (!e) e = m;
    else if (e < m) throw new Error(`
The chosen QR Code version cannot contain this amount of data.
Minimum version required to store current data is: ` + m + `.
`);
    var v = Mc(e, n, s),
        M = un.getSymbolSize(e),
        y = new fc(M);
    return mc(y, e), vc(y), wc(y, e), In(y, n, 0), e >= 7 && yc(y, e), bc(y, v), isNaN(r) && (r = Wn.getBestMask(y, In.bind(null, y, n))), Wn.applyMask(r, y), In(y, n, r), {
        modules: y,
        version: e,
        errorCorrectionLevel: n,
        maskPattern: r,
        segments: s
    }
}
Zi.create = function(e, n) {
    if (typeof e > "u" || e === "") throw new Error("No input text");
    var r = An.M,
        s, o;
    return typeof n < "u" && (r = An.from(n.errorCorrectionLevel, An.M), s = Zt.from(n.version), o = Wn.from(n.maskPattern), n.toSJISFunc && un.setToSJISFunction(n.toSJISFunc)), Sc(e, s, r, o)
};
var go = {},
    fr = {};
(function(t) {
    function e(n) {
        if (typeof n == "number" && (n = n.toString()), typeof n != "string") throw new Error("Color should be defined as hex string");
        var r = n.slice().replace("#", "").split("");
        if (r.length < 3 || r.length === 5 || r.length > 8) throw new Error("Invalid hex color: " + n);
        (r.length === 3 || r.length === 4) && (r = Array.prototype.concat.apply([], r.map(function(o) {
            return [o, o]
        }))), r.length === 6 && r.push("F", "F");
        var s = parseInt(r.join(""), 16);
        return {
            r: s >> 24 & 255,
            g: s >> 16 & 255,
            b: s >> 8 & 255,
            a: s & 255,
            hex: "#" + r.slice(0, 6).join("")
        }
    }
    t.getOptions = function(r) {
        r || (r = {}), r.color || (r.color = {});
        var s = typeof r.margin > "u" || r.margin === null || r.margin < 0 ? 4 : r.margin,
            o = r.width && r.width >= 21 ? r.width : void 0,
            h = r.scale || 4;
        return {
            width: o,
            scale: o ? 4 : h,
            margin: s,
            color: {
                dark: e(r.color.dark || "#000000ff"),
                light: e(r.color.light || "#ffffffff")
            },
            type: r.type,
            rendererOpts: r.rendererOpts || {}
        }
    }, t.getScale = function(r, s) {
        return s.width && s.width >= r + s.margin * 2 ? s.width / (r + s.margin * 2) : s.scale
    }, t.getImageWidth = function(r, s) {
        var o = t.getScale(r, s);
        return Math.floor((r + s.margin * 2) * o)
    }, t.qrToImageData = function(r, s, o) {
        for (var h = s.modules.size, m = s.modules.data, v = t.getScale(h, o), M = Math.floor((h + o.margin * 2) * v), y = o.margin * v, I = [o.color.light, o.color.dark], B = 0; B < M; B++)
            for (var P = 0; P < M; P++) {
                var N = (B * M + P) * 4,
                    D = o.color.light;
                if (B >= y && P >= y && B < M - y && P < M - y) {
                    var b = Math.floor((B - y) / v),
                        S = Math.floor((P - y) / v);
                    D = I[m[b * h + S] ? 1 : 0]
                }
                r[N++] = D.r, r[N++] = D.g, r[N++] = D.b, r[N] = D.a
            }
    }
})(fr);
(function(t) {
    var e = fr;

    function n(s, o, h) {
        s.clearRect(0, 0, o.width, o.height), o.style || (o.style = {}), o.height = h, o.width = h, o.style.height = h + "px", o.style.width = h + "px"
    }

    function r() {
        try {
            return document.createElement("canvas")
        } catch (s) {
            throw new Error("You need to specify a canvas element")
        }
    }
    t.render = function(o, h, m) {
        var v = m,
            M = h;
        typeof v > "u" && (!h || !h.getContext) && (v = h, h = void 0), h || (M = r()), v = e.getOptions(v);
        var y = e.getImageWidth(o.modules.size, v),
            I = M.getContext("2d"),
            B = I.createImageData(y, y);
        return e.qrToImageData(B.data, o, v), n(I, M, y), I.putImageData(B, 0, 0), M
    }, t.renderToDataURL = function(o, h, m) {
        var v = m;
        typeof v > "u" && (!h || !h.getContext) && (v = h, h = void 0), v || (v = {});
        var M = t.render(o, h, v),
            y = v.type || "image/png",
            I = v.rendererOpts || {};
        return M.toDataURL(y, I.quality)
    }
})(go);
var _o = {},
    Ec = fr;

function Fr(t, e) {
    var n = t.a / 255,
        r = e + '="' + t.hex + '"';
    return n < 1 ? r + " " + e + '-opacity="' + n.toFixed(2).slice(1) + '"' : r
}

function Nn(t, e, n) {
    var r = t + e;
    return typeof n < "u" && (r += " " + n), r
}

function Cc(t, e, n) {
    for (var r = "", s = 0, o = !1, h = 0, m = 0; m < t.length; m++) {
        var v = Math.floor(m % e),
            M = Math.floor(m / e);
        !v && !o && (o = !0), t[m] ? (h++, m > 0 && v > 0 && t[m - 1] || (r += o ? Nn("M", v + n, .5 + M + n) : Nn("m", s, 0), s = 0, o = !1), v + 1 < e && t[m + 1] || (r += Nn("h", h), h = 0)) : s++
    }
    return r
}
_o.render = function(e, n, r) {
    var s = Ec.getOptions(n),
        o = e.modules.size,
        h = e.modules.data,
        m = o + s.margin * 2,
        v = s.color.light.a ? "<path " + Fr(s.color.light, "fill") + ' d="M0 0h' + m + "v" + m + 'H0z"/>' : "",
        M = "<path " + Fr(s.color.dark, "stroke") + ' d="' + Cc(h, o, s.margin) + '"/>',
        y = 'viewBox="0 0 ' + m + " " + m + '"',
        I = s.width ? 'width="' + s.width + '" height="' + s.width + '" ' : "",
        B = '<svg xmlns="http://www.w3.org/2000/svg" ' + I + y + ' shape-rendering="crispEdges">' + v + M + `</svg>
`;
    return typeof r == "function" && r(null, B), B
};
var kc = Tl,
    zn = Zi,
    mo = go,
    Rc = _o;

function ur(t, e, n, r, s) {
    var o = [].slice.call(arguments, 1),
        h = o.length,
        m = typeof o[h - 1] == "function";
    if (!m && !kc()) throw new Error("Callback required as last argument");
    if (m) {
        if (h < 2) throw new Error("Too few arguments provided");
        h === 2 ? (s = n, n = e, e = r = void 0) : h === 3 && (e.getContext && typeof s > "u" ? (s = r, r = void 0) : (s = r, r = n, n = e, e = void 0))
    } else {
        if (h < 1) throw new Error("Too few arguments provided");
        return h === 1 ? (n = e, e = r = void 0) : h === 2 && !e.getContext && (r = n, n = e, e = void 0), new Promise(function(M, y) {
            try {
                var I = zn.create(n, r);
                M(t(I, e, r))
            } catch (B) {
                y(B)
            }
        })
    }
    try {
        var v = zn.create(n, r);
        s(null, t(v, e, r))
    } catch (M) {
        s(M)
    }
}
Wt.create = zn.create;
Wt.toCanvas = ur.bind(null, mo.render);
Wt.toDataURL = ur.bind(null, mo.renderToDataURL);
Wt.toString = ur.bind(null, function(t, e, n) {
    return Rc.render(t, n)
});
var Ac = function() {
        var t = document.getSelection();
        if (!t.rangeCount) return function() {};
        for (var e = document.activeElement, n = [], r = 0; r < t.rangeCount; r++) n.push(t.getRangeAt(r));
        switch (e.tagName.toUpperCase()) {
            case "INPUT":
            case "TEXTAREA":
                e.blur();
                break;
            default:
                e = null;
                break
        }
        return t.removeAllRanges(),
            function() {
                t.type === "Caret" && t.removeAllRanges(), t.rangeCount || n.forEach(function(s) {
                    t.addRange(s)
                }), e && e.focus()
            }
    },
    Tc = Ac,
    Ur = {
        "text/plain": "Text",
        "text/html": "Url",
        default: "Text"
    },
    Ic = "Copy to clipboard: #{key}, Enter";

function Nc(t) {
    var e = (/mac os x/i.test(navigator.userAgent) ? "\u2318" : "Ctrl") + "+C";
    return t.replace(/#{\s*key\s*}/g, e)
}

function Oc(t, e) {
    var n, r, s, o, h, m, v = !1;
    e || (e = {}), n = e.debug || !1;
    try {
        s = Tc(), o = document.createRange(), h = document.getSelection(), m = document.createElement("span"), m.textContent = t, m.style.all = "unset", m.style.position = "fixed", m.style.top = 0, m.style.clip = "rect(0, 0, 0, 0)", m.style.whiteSpace = "pre", m.style.webkitUserSelect = "text", m.style.MozUserSelect = "text", m.style.msUserSelect = "text", m.style.userSelect = "text", m.addEventListener("copy", function(y) {
            if (y.stopPropagation(), e.format)
                if (y.preventDefault(), typeof y.clipboardData > "u") {
                    n && console.warn("unable to use e.clipboardData"), n && console.warn("trying IE specific stuff"), window.clipboardData.clearData();
                    var I = Ur[e.format] || Ur.default;
                    window.clipboardData.setData(I, t)
                } else y.clipboardData.clearData(), y.clipboardData.setData(e.format, t);
            e.onCopy && (y.preventDefault(), e.onCopy(y.clipboardData))
        }), document.body.appendChild(m), o.selectNodeContents(m), h.addRange(o);
        var M = document.execCommand("copy");
        if (!M) throw new Error("copy command was unsuccessful");
        v = !0
    } catch (y) {
        n && console.error("unable to copy using execCommand: ", y), n && console.warn("trying IE specific stuff");
        try {
            window.clipboardData.setData(e.format || "text", t), e.onCopy && e.onCopy(window.clipboardData), v = !0
        } catch (I) {
            n && console.error("unable to copy using clipboardData: ", I), n && console.error("falling back to prompt"), r = Nc("message" in e ? e.message : Ic), window.prompt(r, t)
        }
    } finally {
        h && (typeof h.removeRange == "function" ? h.removeRange(o) : h.removeAllRanges()), m && document.body.removeChild(m), s()
    }
    return v
}
var Bc = Oc,
    Y, Ft, hr, vo, Dr, dr, wo, De = {},
    hn = [],
    Lc = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord/i;

function Ue(t, e) {
    for (var n in e) t[n] = e[n];
    return t
}

function yo(t) {
    var e = t.parentNode;
    e && e.removeChild(t)
}

function qe(t, e, n) {
    var r, s = arguments,
        o = {};
    for (r in e) r !== "key" && r !== "ref" && (o[r] = e[r]);
    if (arguments.length > 3)
        for (n = [n], r = 3; r < arguments.length; r++) n.push(s[r]);
    if (n != null && (o.children = n), typeof t == "function" && t.defaultProps != null)
        for (r in t.defaultProps) o[r] === void 0 && (o[r] = t.defaultProps[r]);
    return Xt(t, o, e && e.key, e && e.ref, null)
}

function Xt(t, e, n, r, s) {
    var o = {
        type: t,
        props: e,
        key: n,
        ref: r,
        __k: null,
        __: null,
        __b: 0,
        __e: null,
        __d: void 0,
        __c: null,
        constructor: void 0,
        __v: s
    };
    return s == null && (o.__v = o), Y.vnode && Y.vnode(o), o
}

function bo() {
    return {}
}

function zt(t) {
    return t.children
}

function Pe(t, e) {
    this.props = t, this.context = e
}

function qt(t, e) {
    if (e == null) return t.__ ? qt(t.__, t.__.__k.indexOf(t) + 1) : null;
    for (var n; e < t.__k.length; e++)
        if ((n = t.__k[e]) != null && n.__e != null) return n.__e;
    return typeof t.type == "function" ? qt(t) : null
}

function Mo(t) {
    var e, n;
    if ((t = t.__) != null && t.__c != null) {
        for (t.__e = t.__c.base = null, e = 0; e < t.__k.length; e++)
            if ((n = t.__k[e]) != null && n.__e != null) {
                t.__e = t.__c.base = n.__e;
                break
            }
        return Mo(t)
    }
}

function Vt(t) {
    (!t.__d && (t.__d = !0) && Ft.push(t) && !hr++ || Dr !== Y.debounceRendering) && ((Dr = Y.debounceRendering) || vo)(Pc)
}

function Pc() {
    for (var t; hr = Ft.length;) t = Ft.sort(function(e, n) {
        return e.__v.__b - n.__v.__b
    }), Ft = [], t.some(function(e) {
        var n, r, s, o, h, m, v;
        e.__d && (m = (h = (n = e).__v).__e, (v = n.__P) && (r = [], (s = Ue({}, h)).__v = s, o = pr(v, h, s, n.__n, v.ownerSVGElement !== void 0, null, r, m == null ? qt(h) : m), So(r, h), o != m && Mo(h)))
    })
}

function xo(t, e, n, r, s, o, h, m, v) {
    var M, y, I, B, P, N, D, b = n && n.__k || hn,
        S = b.length;
    if (m == De && (m = o != null ? o[0] : S ? qt(n, 0) : null), M = 0, e.__k = Ze(e.__k, function(C) {
            if (C != null) {
                if (C.__ = e, C.__b = e.__b + 1, (I = b[M]) === null || I && C.key == I.key && C.type === I.type) b[M] = void 0;
                else
                    for (y = 0; y < S; y++) {
                        if ((I = b[y]) && C.key == I.key && C.type === I.type) {
                            b[y] = void 0;
                            break
                        }
                        I = null
                    }
                if (B = pr(t, C, I = I || De, r, s, o, h, m, v), (y = C.ref) && I.ref != y && (D || (D = []), I.ref && D.push(I.ref, null, C), D.push(y, C.__c || B, C)), B != null) {
                    var E;
                    if (N == null && (N = B), C.__d !== void 0) E = C.__d, C.__d = void 0;
                    else if (o == I || B != m || B.parentNode == null) {
                        e: if (m == null || m.parentNode !== t) t.appendChild(B), E = null;
                            else {
                                for (P = m, y = 0;
                                    (P = P.nextSibling) && y < S; y += 2)
                                    if (P == B) break e;
                                t.insertBefore(B, m), E = m
                            }e.type == "option" && (t.value = "")
                    }
                    m = E !== void 0 ? E : B.nextSibling, typeof e.type == "function" && (e.__d = m)
                } else m && I.__e == m && m.parentNode != t && (m = qt(I))
            }
            return M++, C
        }), e.__e = N, o != null && typeof e.type != "function")
        for (M = o.length; M--;) o[M] != null && yo(o[M]);
    for (M = S; M--;) b[M] != null && Ut(b[M], b[M]);
    if (D)
        for (M = 0; M < D.length; M++) Eo(D[M], D[++M], D[++M])
}

function Ze(t, e, n) {
    if (n == null && (n = []), t == null || typeof t == "boolean") e && n.push(e(null));
    else if (Array.isArray(t))
        for (var r = 0; r < t.length; r++) Ze(t[r], e, n);
    else n.push(e ? e(typeof t == "string" || typeof t == "number" ? Xt(null, t, null, null, t) : t.__e != null || t.__c != null ? Xt(t.type, t.props, t.key, null, t.__v) : t) : t);
    return n
}

function Fc(t, e, n, r, s) {
    var o;
    for (o in n) o === "children" || o === "key" || o in e || en(t, o, null, n[o], r);
    for (o in e) s && typeof e[o] != "function" || o === "children" || o === "key" || o === "value" || o === "checked" || n[o] === e[o] || en(t, o, e[o], n[o], r)
}

function qr(t, e, n) {
    e[0] === "-" ? t.setProperty(e, n) : t[e] = typeof n == "number" && Lc.test(e) === !1 ? n + "px" : n == null ? "" : n
}

function en(t, e, n, r, s) {
    var o, h, m, v, M;
    if (s ? e === "className" && (e = "class") : e === "class" && (e = "className"), e === "style")
        if (o = t.style, typeof n == "string") o.cssText = n;
        else {
            if (typeof r == "string" && (o.cssText = "", r = null), r)
                for (v in r) n && v in n || qr(o, v, "");
            if (n)
                for (M in n) r && n[M] === r[M] || qr(o, M, n[M])
        }
    else e[0] === "o" && e[1] === "n" ? (h = e !== (e = e.replace(/Capture$/, "")), m = e.toLowerCase(), e = (m in t ? m : e).slice(2), n ? (r || t.addEventListener(e, $r, h), (t.l || (t.l = {}))[e] = n) : t.removeEventListener(e, $r, h)) : e !== "list" && e !== "tagName" && e !== "form" && e !== "type" && e !== "size" && !s && e in t ? t[e] = n == null ? "" : n : typeof n != "function" && e !== "dangerouslySetInnerHTML" && (e !== (e = e.replace(/^xlink:?/, "")) ? n == null || n === !1 ? t.removeAttributeNS("http://www.w3.org/1999/xlink", e.toLowerCase()) : t.setAttributeNS("http://www.w3.org/1999/xlink", e.toLowerCase(), n) : n == null || n === !1 && !/^ar/.test(e) ? t.removeAttribute(e) : t.setAttribute(e, n))
}

function $r(t) {
    this.l[t.type](Y.event ? Y.event(t) : t)
}

function pr(t, e, n, r, s, o, h, m, v) {
    var M, y, I, B, P, N, D, b, S, C, E = e.type;
    if (e.constructor !== void 0) return null;
    (M = Y.__b) && M(e);
    try {
        e: if (typeof E == "function") {
            if (b = e.props, S = (M = E.contextType) && r[M.__c], C = M ? S ? S.props.value : M.__ : r, n.__c ? D = (y = e.__c = n.__c).__ = y.__E : ("prototype" in E && E.prototype.render ? e.__c = y = new E(b, C) : (e.__c = y = new Pe(b, C), y.constructor = E, y.render = Dc), S && S.sub(y), y.props = b, y.state || (y.state = {}), y.context = C, y.__n = r, I = y.__d = !0, y.__h = []), y.__s == null && (y.__s = y.state), E.getDerivedStateFromProps != null && (y.__s == y.state && (y.__s = Ue({}, y.__s)), Ue(y.__s, E.getDerivedStateFromProps(b, y.__s))), B = y.props, P = y.state, I) E.getDerivedStateFromProps == null && y.componentWillMount != null && y.componentWillMount(), y.componentDidMount != null && y.__h.push(y.componentDidMount);
            else {
                if (E.getDerivedStateFromProps == null && b !== B && y.componentWillReceiveProps != null && y.componentWillReceiveProps(b, C), !y.__e && y.shouldComponentUpdate != null && y.shouldComponentUpdate(b, y.__s, C) === !1 || e.__v === n.__v && !y.__) {
                    for (y.props = b, y.state = y.__s, e.__v !== n.__v && (y.__d = !1), y.__v = e, e.__e = n.__e, e.__k = n.__k, y.__h.length && h.push(y), M = 0; M < e.__k.length; M++) e.__k[M] && (e.__k[M].__ = e);
                    break e
                }
                y.componentWillUpdate != null && y.componentWillUpdate(b, y.__s, C), y.componentDidUpdate != null && y.__h.push(function() {
                    y.componentDidUpdate(B, P, N)
                })
            }
            y.context = C, y.props = b, y.state = y.__s, (M = Y.__r) && M(e), y.__d = !1, y.__v = e, y.__P = t, M = y.render(y.props, y.state, y.context), e.__k = M != null && M.type == zt && M.key == null ? M.props.children : Array.isArray(M) ? M : [M], y.getChildContext != null && (r = Ue(Ue({}, r), y.getChildContext())), I || y.getSnapshotBeforeUpdate == null || (N = y.getSnapshotBeforeUpdate(B, P)), xo(t, e, n, r, s, o, h, m, v), y.base = e.__e, y.__h.length && h.push(y), D && (y.__E = y.__ = null), y.__e = !1
        } else o == null && e.__v === n.__v ? (e.__k = n.__k, e.__e = n.__e) : e.__e = Uc(n.__e, e, n, r, s, o, h, v);
        (M = Y.diffed) && M(e)
    }
    catch (R) {
        e.__v = null, Y.__e(R, e, n)
    }
    return e.__e
}

function So(t, e) {
    Y.__c && Y.__c(e, t), t.some(function(n) {
        try {
            t = n.__h, n.__h = [], t.some(function(r) {
                r.call(n)
            })
        } catch (r) {
            Y.__e(r, n.__v)
        }
    })
}

function Uc(t, e, n, r, s, o, h, m) {
    var v, M, y, I, B, P = n.props,
        N = e.props;
    if (s = e.type === "svg" || s, o != null) {
        for (v = 0; v < o.length; v++)
            if ((M = o[v]) != null && ((e.type === null ? M.nodeType === 3 : M.localName === e.type) || t == M)) {
                t = M, o[v] = null;
                break
            }
    }
    if (t == null) {
        if (e.type === null) return document.createTextNode(N);
        t = s ? document.createElementNS("http://www.w3.org/2000/svg", e.type) : document.createElement(e.type, N.is && {
            is: N.is
        }), o = null, m = !1
    }
    if (e.type === null) P !== N && t.data != N && (t.data = N);
    else {
        if (o != null && (o = hn.slice.call(t.childNodes)), y = (P = n.props || De).dangerouslySetInnerHTML, I = N.dangerouslySetInnerHTML, !m) {
            if (P === De)
                for (P = {}, B = 0; B < t.attributes.length; B++) P[t.attributes[B].name] = t.attributes[B].value;
            (I || y) && (I && y && I.__html == y.__html || (t.innerHTML = I && I.__html || ""))
        }
        Fc(t, N, P, s, m), I ? e.__k = [] : (e.__k = e.props.children, xo(t, e, n, r, e.type !== "foreignObject" && s, o, h, De, m)), m || ("value" in N && (v = N.value) !== void 0 && v !== t.value && en(t, "value", v, P.value, !1), "checked" in N && (v = N.checked) !== void 0 && v !== t.checked && en(t, "checked", v, P.checked, !1))
    }
    return t
}

function Eo(t, e, n) {
    try {
        typeof t == "function" ? t(e) : t.current = e
    } catch (r) {
        Y.__e(r, n)
    }
}

function Ut(t, e, n) {
    var r, s, o;
    if (Y.unmount && Y.unmount(t), (r = t.ref) && (r.current && r.current !== t.__e || Eo(r, null, e)), n || typeof t.type == "function" || (n = (s = t.__e) != null), t.__e = t.__d = void 0, (r = t.__c) != null) {
        if (r.componentWillUnmount) try {
            r.componentWillUnmount()
        } catch (h) {
            Y.__e(h, e)
        }
        r.base = r.__P = null
    }
    if (r = t.__k)
        for (o = 0; o < r.length; o++) r[o] && Ut(r[o], e, n);
    s != null && yo(s)
}

function Dc(t, e, n) {
    return this.constructor(t, n)
}

function $t(t, e, n) {
    var r, s, o;
    Y.__ && Y.__(t, e), s = (r = n === dr) ? null : n && n.__k || e.__k, t = qe(zt, null, [t]), o = [], pr(e, (r ? e : n || e).__k = t, s || De, De, e.ownerSVGElement !== void 0, n && !r ? [n] : s ? null : hn.slice.call(e.childNodes), o, n || De, r), So(o, t)
}

function Co(t, e) {
    $t(t, e, dr)
}

function qc(t, e) {
    var n, r;
    for (r in e = Ue(Ue({}, t.props), e), arguments.length > 2 && (e.children = hn.slice.call(arguments, 2)), n = {}, e) r !== "key" && r !== "ref" && (n[r] = e[r]);
    return Xt(t.type, n, e.key || t.key, e.ref || t.ref, null)
}

function ko(t) {
    var e = {},
        n = {
            __c: "__cC" + wo++,
            __: t,
            Consumer: function(r, s) {
                return r.children(s)
            },
            Provider: function(r) {
                var s, o = this;
                return this.getChildContext || (s = [], this.getChildContext = function() {
                    return e[n.__c] = o, e
                }, this.shouldComponentUpdate = function(h) {
                    o.props.value !== h.value && s.some(function(m) {
                        m.context = h.value, Vt(m)
                    })
                }, this.sub = function(h) {
                    s.push(h);
                    var m = h.componentWillUnmount;
                    h.componentWillUnmount = function() {
                        s.splice(s.indexOf(h), 1), m && m.call(h)
                    }
                }), r.children
            }
        };
    return n.Consumer.contextType = n, n.Provider.__ = n, n
}
Y = {
    __e: function(t, e) {
        for (var n, r; e = e.__;)
            if ((n = e.__c) && !n.__) try {
                if (n.constructor && n.constructor.getDerivedStateFromError != null && (r = !0, n.setState(n.constructor.getDerivedStateFromError(t))), n.componentDidCatch != null && (r = !0, n.componentDidCatch(t)), r) return Vt(n.__E = n)
            } catch (s) {
                t = s
            }
        throw t
    }
}, Pe.prototype.setState = function(t, e) {
    var n;
    n = this.__s !== this.state ? this.__s : this.__s = Ue({}, this.state), typeof t == "function" && (t = t(n, this.props)), t && Ue(n, t), t != null && this.__v && (e && this.__h.push(e), Vt(this))
}, Pe.prototype.forceUpdate = function(t) {
    this.__v && (this.__e = !0, t && this.__h.push(t), Vt(this))
}, Pe.prototype.render = zt, Ft = [], hr = 0, vo = typeof Promise == "function" ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, dr = De, wo = 0;
var yt, Oe, Wr, It = 0,
    jn = [],
    Hr = Y.__r,
    zr = Y.diffed,
    jr = Y.__c,
    Kr = Y.unmount;

function Lt(t, e) {
    Y.__h && Y.__h(Oe, t, It || e), It = 0;
    var n = Oe.__H || (Oe.__H = {
        __: [],
        __h: []
    });
    return t >= n.__.length && n.__.push({}), n.__[t]
}

function gr(t) {
    return It = 1, _r(Bo, t)
}

function _r(t, e, n) {
    var r = Lt(yt++, 2);
    return r.__c || (r.__c = Oe, r.__ = [n ? n(e) : Bo(void 0, e), function(s) {
        var o = t(r.__[0], s);
        r.__[0] !== o && (r.__[0] = o, r.__c.setState({}))
    }]), r.__
}

function Ro(t, e) {
    var n = Lt(yt++, 3);
    !Y.__s && vr(n.__H, e) && (n.__ = t, n.__H = e, Oe.__H.__h.push(n))
}

function mr(t, e) {
    var n = Lt(yt++, 4);
    !Y.__s && vr(n.__H, e) && (n.__ = t, n.__H = e, Oe.__h.push(n))
}

function Ao(t) {
    return It = 5, dn(function() {
        return {
            current: t
        }
    }, [])
}

function To(t, e, n) {
    It = 6, mr(function() {
        typeof t == "function" ? t(e()) : t && (t.current = e())
    }, n == null ? n : n.concat(t))
}

function dn(t, e) {
    var n = Lt(yt++, 7);
    return vr(n.__H, e) ? (n.__H = e, n.__h = t, n.__ = t()) : n.__
}

function Io(t, e) {
    return It = 8, dn(function() {
        return t
    }, e)
}

function No(t) {
    var e = Oe.context[t.__c],
        n = Lt(yt++, 9);
    return n.__c = t, e ? (n.__ == null && (n.__ = !0, e.sub(Oe)), e.props.value) : t.__
}

function Oo(t, e) {
    Y.useDebugValue && Y.useDebugValue(e ? e(t) : t)
}

function $c(t) {
    var e = Lt(yt++, 10),
        n = gr();
    return e.__ = t, Oe.componentDidCatch || (Oe.componentDidCatch = function(r) {
        e.__ && e.__(r), n[1](r)
    }), [n[0], function() {
        n[1](void 0)
    }]
}

function Wc() {
    jn.some(function(t) {
        if (t.__P) try {
            t.__H.__h.forEach(Kn), t.__H.__h.forEach(Jn), t.__H.__h = []
        } catch (e) {
            return t.__H.__h = [], Y.__e(e, t.__v), !0
        }
    }), jn = []
}

function Kn(t) {
    t.t && t.t()
}

function Jn(t) {
    var e = t.__();
    typeof e == "function" && (t.t = e)
}

function vr(t, e) {
    return !t || e.some(function(n, r) {
        return n !== t[r]
    })
}

function Bo(t, e) {
    return typeof e == "function" ? e(t) : e
}
Y.__r = function(t) {
    Hr && Hr(t), yt = 0, (Oe = t.__c).__H && (Oe.__H.__h.forEach(Kn), Oe.__H.__h.forEach(Jn), Oe.__H.__h = [])
}, Y.diffed = function(t) {
    zr && zr(t);
    var e = t.__c;
    if (e) {
        var n = e.__H;
        n && n.__h.length && (jn.push(e) !== 1 && Wr === Y.requestAnimationFrame || ((Wr = Y.requestAnimationFrame) || function(r) {
            var s, o = function() {
                    clearTimeout(h), cancelAnimationFrame(s), setTimeout(r)
                },
                h = setTimeout(o, 100);
            typeof window < "u" && (s = requestAnimationFrame(o))
        })(Wc))
    }
}, Y.__c = function(t, e) {
    e.some(function(n) {
        try {
            n.__h.forEach(Kn), n.__h = n.__h.filter(function(r) {
                return !r.__ || Jn(r)
            })
        } catch (r) {
            e.some(function(s) {
                s.__h && (s.__h = [])
            }), e = [], Y.__e(r, n.__v)
        }
    }), jr && jr(t, e)
}, Y.unmount = function(t) {
    Kr && Kr(t);
    var e = t.__c;
    if (e) {
        var n = e.__H;
        if (n) try {
            n.__.forEach(function(r) {
                return r.t && r.t()
            })
        } catch (r) {
            Y.__e(r, e.__v)
        }
    }
};

function wr(t, e) {
    for (var n in e) t[n] = e[n];
    return t
}

function Vn(t, e) {
    for (var n in t)
        if (n !== "__source" && !(n in e)) return !0;
    for (var r in e)
        if (r !== "__source" && t[r] !== e[r]) return !0;
    return !1
}
var Lo = function(t) {
    var e, n;

    function r(s) {
        var o;
        return (o = t.call(this, s) || this).isPureReactComponent = !0, o
    }
    return n = t, (e = r).prototype = Object.create(n.prototype), e.prototype.constructor = e, e.__proto__ = n, r.prototype.shouldComponentUpdate = function(s, o) {
        return Vn(this.props, s) || Vn(this.state, o)
    }, r
}(Pe);

function Po(t, e) {
    function n(s) {
        var o = this.props.ref,
            h = o == s.ref;
        return !h && o && (o.call ? o(null) : o.current = null), e ? !e(this.props, s) || !h : Vn(this.props, s)
    }

    function r(s) {
        return this.shouldComponentUpdate = n, qe(t, wr({}, s))
    }
    return r.prototype.isReactComponent = !0, r.displayName = "Memo(" + (t.displayName || t.name) + ")", r.t = !0, r
}
var Jr = Y.__b;

function Fo(t) {
    function e(n) {
        var r = wr({}, n);
        return delete r.ref, t(r, n.ref)
    }
    return e.prototype.isReactComponent = e.t = !0, e.displayName = "ForwardRef(" + (t.displayName || t.name) + ")", e
}
Y.__b = function(t) {
    t.type && t.type.t && t.ref && (t.props.ref = t.ref, t.ref = null), Jr && Jr(t)
};
var Vr = function(t, e) {
        return t ? Ze(t).reduce(function(n, r, s) {
            return n.concat(e(r, s))
        }, []) : null
    },
    Uo = {
        map: Vr,
        forEach: Vr,
        count: function(t) {
            return t ? Ze(t).length : 0
        },
        only: function(t) {
            if ((t = Ze(t)).length !== 1) throw new Error("Children.only() expects only one child.");
            return t[0]
        },
        toArray: Ze
    },
    Hc = Y.__e;

function Do(t) {
    return t && ((t = wr({}, t)).__c = null, t.__k = t.__k && t.__k.map(Do)), t
}

function tn() {
    this.__u = 0, this.o = null, this.__b = null
}

function qo(t) {
    var e = t.__.__c;
    return e && e.u && e.u(t)
}

function $o(t) {
    var e, n, r;

    function s(o) {
        if (e || (e = t()).then(function(h) {
                n = h.default || h
            }, function(h) {
                r = h
            }), r) throw r;
        if (!n) throw e;
        return qe(n, o)
    }
    return s.displayName = "Lazy", s.t = !0, s
}

function Mt() {
    this.i = null, this.l = null
}
Y.__e = function(t, e, n) {
    if (t.then) {
        for (var r, s = e; s = s.__;)
            if ((r = s.__c) && r.__c) return r.__c(t, e.__c)
    }
    Hc(t, e, n)
}, (tn.prototype = new Pe).__c = function(t, e) {
    var n = this;
    n.o == null && (n.o = []), n.o.push(e);
    var r = qo(n.__v),
        s = !1,
        o = function() {
            s || (s = !0, r ? r(h) : h())
        };
    e.__c = e.componentWillUnmount, e.componentWillUnmount = function() {
        o(), e.__c && e.__c()
    };
    var h = function() {
        var m;
        if (!--n.__u)
            for (n.__v.__k[0] = n.state.u, n.setState({
                    u: n.__b = null
                }); m = n.o.pop();) m.forceUpdate()
    };
    n.__u++ || n.setState({
        u: n.__b = n.__v.__k[0]
    }), t.then(o, o)
}, tn.prototype.render = function(t, e) {
    return this.__b && (this.__v.__k[0] = Do(this.__b), this.__b = null), [qe(Pe, null, e.u ? null : t.children), e.u && t.fallback]
};
var Yr = function(t, e, n) {
    if (++n[1] === n[0] && t.l.delete(e), t.props.revealOrder && (t.props.revealOrder[0] !== "t" || !t.l.size))
        for (n = t.i; n;) {
            for (; n.length > 3;) n.pop()();
            if (n[1] < n[0]) break;
            t.i = n = n[2]
        }
};
(Mt.prototype = new Pe).u = function(t) {
    var e = this,
        n = qo(e.__v),
        r = e.l.get(t);
    return r[0]++,
        function(s) {
            var o = function() {
                e.props.revealOrder ? (r.push(s), Yr(e, t, r)) : s()
            };
            n ? n(o) : o()
        }
}, Mt.prototype.render = function(t) {
    this.i = null, this.l = new Map;
    var e = Ze(t.children);
    t.revealOrder && t.revealOrder[0] === "b" && e.reverse();
    for (var n = e.length; n--;) this.l.set(e[n], this.i = [1, 0, this.i]);
    return t.children
}, Mt.prototype.componentDidUpdate = Mt.prototype.componentDidMount = function() {
    var t = this;
    t.l.forEach(function(e, n) {
        Yr(t, n, e)
    })
};
var zc = function() {
    function t() {}
    var e = t.prototype;
    return e.getChildContext = function() {
        return this.props.context
    }, e.render = function(n) {
        return n.children
    }, t
}();

function jc(t) {
    var e = this,
        n = t.container,
        r = qe(zc, {
            context: e.context
        }, t.vnode);
    return e.s && e.s !== n && (e.v.parentNode && e.s.removeChild(e.v), Ut(e.h), e.p = !1), t.vnode ? e.p ? (n.__k = e.__k, $t(r, n), e.__k = n.__k) : (e.v = document.createTextNode(""), Co("", n), n.appendChild(e.v), e.p = !0, e.s = n, $t(r, n, e.v), e.__k = e.v.__k) : e.p && (e.v.parentNode && e.s.removeChild(e.v), Ut(e.h)), e.h = r, e.componentWillUnmount = function() {
        e.v.parentNode && e.s.removeChild(e.v), Ut(e.h)
    }, null
}

function Wo(t, e) {
    return qe(jc, {
        vnode: t,
        container: e
    })
}
var Qr = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
Pe.prototype.isReactComponent = {};
var Ho = typeof Symbol < "u" && Symbol.for && Symbol.for("react.element") || 60103;

function Yn(t, e, n) {
    if (e.__k == null)
        for (; e.firstChild;) e.removeChild(e.firstChild);
    return $t(t, e), typeof n == "function" && n(), t ? t.__c : null
}

function Kc(t, e, n) {
    return Co(t, e), typeof n == "function" && n(), t ? t.__c : null
}
var Gr = Y.event;

function On(t, e) {
    t["UNSAFE_" + e] && !t[e] && Object.defineProperty(t, e, {
        configurable: !1,
        get: function() {
            return this["UNSAFE_" + e]
        },
        set: function(n) {
            this["UNSAFE_" + e] = n
        }
    })
}
Y.event = function(t) {
    Gr && (t = Gr(t)), t.persist = function() {};
    var e = !1,
        n = !1,
        r = t.stopPropagation;
    t.stopPropagation = function() {
        r.call(t), e = !0
    };
    var s = t.preventDefault;
    return t.preventDefault = function() {
        s.call(t), n = !0
    }, t.isPropagationStopped = function() {
        return e
    }, t.isDefaultPrevented = function() {
        return n
    }, t.nativeEvent = t
};
var Zr = {
        configurable: !0,
        get: function() {
            return this.class
        }
    },
    Xr = Y.vnode;
Y.vnode = function(t) {
    t.$$typeof = Ho;
    var e = t.type,
        n = t.props;
    if (e) {
        if (n.class != n.className && (Zr.enumerable = "className" in n, n.className != null && (n.class = n.className), Object.defineProperty(n, "className", Zr)), typeof e != "function") {
            var r, s, o;
            for (o in n.defaultValue && n.value !== void 0 && (n.value || n.value === 0 || (n.value = n.defaultValue), delete n.defaultValue), Array.isArray(n.value) && n.multiple && e === "select" && (Ze(n.children).forEach(function(h) {
                    n.value.indexOf(h.props.value) != -1 && (h.props.selected = !0)
                }), delete n.value), n)
                if (r = Qr.test(o)) break;
            if (r)
                for (o in s = t.props = {}, n) s[Qr.test(o) ? o.replace(/[A-Z0-9]/, "-$&").toLowerCase() : o] = n[o]
        }(function(h) {
            var m = t.type,
                v = t.props;
            if (v && typeof m == "string") {
                var M = {};
                for (var y in v) /^on(Ani|Tra|Tou)/.test(y) && (v[y.toLowerCase()] = v[y], delete v[y]), M[y.toLowerCase()] = y;
                if (M.ondoubleclick && (v.ondblclick = v[M.ondoubleclick], delete v[M.ondoubleclick]), M.onbeforeinput && (v.onbeforeinput = v[M.onbeforeinput], delete v[M.onbeforeinput]), M.onchange && (m === "textarea" || m.toLowerCase() === "input" && !/^fil|che|ra/i.test(v.type))) {
                    var I = M.oninput || "oninput";
                    v[I] || (v[I] = v[M.onchange], delete v[M.onchange])
                }
            }
        })(), typeof e == "function" && !e.m && e.prototype && (On(e.prototype, "componentWillMount"), On(e.prototype, "componentWillReceiveProps"), On(e.prototype, "componentWillUpdate"), e.m = !0)
    }
    Xr && Xr(t)
};
var Jc = "16.8.0";

function zo(t) {
    return qe.bind(null, t)
}

function yr(t) {
    return !!t && t.$$typeof === Ho
}

function jo(t) {
    return yr(t) ? qc.apply(null, arguments) : t
}

function Ko(t) {
    return !!t.__k && ($t(null, t), !0)
}

function Jo(t) {
    return t && (t.base || t.nodeType === 1 && t) || null
}
var Vo = function(t, e) {
        return t(e)
    },
    Vc = {
        useState: gr,
        useReducer: _r,
        useEffect: Ro,
        useLayoutEffect: mr,
        useRef: Ao,
        useImperativeHandle: To,
        useMemo: dn,
        useCallback: Io,
        useContext: No,
        useDebugValue: Oo,
        version: "16.8.0",
        Children: Uo,
        render: Yn,
        hydrate: Yn,
        unmountComponentAtNode: Ko,
        createPortal: Wo,
        createElement: qe,
        createContext: ko,
        createFactory: zo,
        cloneElement: jo,
        createRef: bo,
        Fragment: zt,
        isValidElement: yr,
        findDOMNode: Jo,
        Component: Pe,
        PureComponent: Lo,
        memo: Po,
        forwardRef: Fo,
        unstable_batchedUpdates: Vo,
        Suspense: tn,
        SuspenseList: Mt,
        lazy: $o
    },
    Yc = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Vc,
        version: Jc,
        Children: Uo,
        render: Yn,
        hydrate: Kc,
        unmountComponentAtNode: Ko,
        createPortal: Wo,
        createFactory: zo,
        cloneElement: jo,
        isValidElement: yr,
        findDOMNode: Jo,
        PureComponent: Lo,
        memo: Po,
        forwardRef: Fo,
        unstable_batchedUpdates: Vo,
        Suspense: tn,
        SuspenseList: Mt,
        lazy: $o,
        createElement: qe,
        createContext: ko,
        createRef: bo,
        Fragment: zt,
        Component: Pe,
        useState: gr,
        useReducer: _r,
        useEffect: Ro,
        useLayoutEffect: mr,
        useRef: Ao,
        useImperativeHandle: To,
        useMemo: dn,
        useCallback: Io,
        useContext: No,
        useDebugValue: Oo,
        useErrorBoundary: $c
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Qc = ni(Yc);

function Yo(t) {
    return t && typeof t == "object" && "default" in t ? t.default : t
}
var Ne = Al,
    Qo = Yo(Wt),
    Gc = Yo(Bc),
    U = Qc;

function Zc(t) {
    Qo.toString(t, {
        type: "terminal"
    }).then(console.log)
}
var Xc = `:root {
  --animation-duration: 300ms;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes fadeOut {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
  }
}

.animated {
  animation-duration: var(--animation-duration);
  animation-fill-mode: both;
}

.fadeIn {
  animation-name: fadeIn;
}

.fadeOut {
  animation-name: fadeOut;
}

#walletconnect-wrapper {
  -webkit-user-select: none;
  align-items: center;
  display: flex;
  height: 100%;
  justify-content: center;
  left: 0;
  pointer-events: none;
  position: fixed;
  top: 0;
  user-select: none;
  width: 100%;
  z-index: 99999999999999;
}

.walletconnect-modal__headerLogo {
  height: 21px;
}

.walletconnect-modal__header p {
  color: #ffffff;
  font-size: 20px;
  font-weight: 600;
  margin: 0;
  align-items: flex-start;
  display: flex;
  flex: 1;
  margin-left: 5px;
}

.walletconnect-modal__close__wrapper {
  position: absolute;
  top: 0px;
  right: 0px;
  z-index: 10000;
  background: white;
  border-radius: 26px;
  padding: 6px;
  box-sizing: border-box;
  width: 26px;
  height: 26px;
  cursor: pointer;
}

.walletconnect-modal__close__icon {
  position: relative;
  top: 7px;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: rotate(45deg);
}

.walletconnect-modal__close__line1 {
  position: absolute;
  width: 100%;
  border: 1px solid rgb(48, 52, 59);
}

.walletconnect-modal__close__line2 {
  position: absolute;
  width: 100%;
  border: 1px solid rgb(48, 52, 59);
  transform: rotate(90deg);
}

.walletconnect-qrcode__base {
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  background: rgba(37, 41, 46, 0.95);
  height: 100%;
  left: 0;
  pointer-events: auto;
  position: fixed;
  top: 0;
  transition: 0.4s cubic-bezier(0.19, 1, 0.22, 1);
  width: 100%;
  will-change: opacity;
  padding: 40px;
  box-sizing: border-box;
}

.walletconnect-qrcode__text {
  color: rgba(60, 66, 82, 0.6);
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 0;
  line-height: 1.1875em;
  margin: 10px 0 20px 0;
  text-align: center;
  width: 100%;
}

@media only screen and (max-width: 768px) {
  .walletconnect-qrcode__text {
    font-size: 4vw;
  }
}

@media only screen and (max-width: 320px) {
  .walletconnect-qrcode__text {
    font-size: 14px;
  }
}

.walletconnect-qrcode__image {
  width: calc(100% - 30px);
  box-sizing: border-box;
  cursor: none;
  margin: 0 auto;
}

.walletconnect-qrcode__notification {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  font-size: 16px;
  padding: 16px 20px;
  border-radius: 16px;
  text-align: center;
  transition: all 0.1s ease-in-out;
  background: white;
  color: black;
  margin-bottom: -60px;
  opacity: 0;
}

.walletconnect-qrcode__notification.notification__show {
  opacity: 1;
}

@media only screen and (max-width: 768px) {
  .walletconnect-modal__header {
    height: 130px;
  }
  .walletconnect-modal__base {
    overflow: auto;
  }
}

@media only screen and (min-device-width: 415px) and (max-width: 768px) {
  #content {
    max-width: 768px;
    box-sizing: border-box;
  }
}

@media only screen and (min-width: 375px) and (max-width: 415px) {
  #content {
    max-width: 414px;
    box-sizing: border-box;
  }
}

@media only screen and (min-width: 320px) and (max-width: 375px) {
  #content {
    max-width: 375px;
    box-sizing: border-box;
  }
}

@media only screen and (max-width: 320px) {
  #content {
    max-width: 320px;
    box-sizing: border-box;
  }
}

.walletconnect-modal__base {
  -webkit-font-smoothing: antialiased;
  background: #ffffff;
  border-radius: 24px;
  box-shadow: 0 10px 50px 5px rgba(0, 0, 0, 0.4);
  font-family: ui-rounded, "SF Pro Rounded", "SF Pro Text", medium-content-sans-serif-font,
    -apple-system, BlinkMacSystemFont, ui-sans-serif, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell,
    "Open Sans", "Helvetica Neue", sans-serif;
  margin-top: 41px;
  padding: 24px 24px 22px;
  pointer-events: auto;
  position: relative;
  text-align: center;
  transition: 0.4s cubic-bezier(0.19, 1, 0.22, 1);
  will-change: transform;
  overflow: visible;
  transform: translateY(-50%);
  top: 50%;
  max-width: 500px;
  margin: auto;
}

@media only screen and (max-width: 320px) {
  .walletconnect-modal__base {
    padding: 24px 12px;
  }
}

.walletconnect-modal__base .hidden {
  transform: translateY(150%);
  transition: 0.125s cubic-bezier(0.4, 0, 1, 1);
}

.walletconnect-modal__header {
  align-items: center;
  display: flex;
  height: 26px;
  left: 0;
  justify-content: space-between;
  position: absolute;
  top: -42px;
  width: 100%;
}

.walletconnect-modal__base .wc-logo {
  align-items: center;
  display: flex;
  height: 26px;
  margin-top: 15px;
  padding-bottom: 15px;
  pointer-events: auto;
}

.walletconnect-modal__base .wc-logo div {
  background-color: #3399ff;
  height: 21px;
  margin-right: 5px;
  mask-image: url("images/wc-logo.svg") center no-repeat;
  width: 32px;
}

.walletconnect-modal__base .wc-logo p {
  color: #ffffff;
  font-size: 20px;
  font-weight: 600;
  margin: 0;
}

.walletconnect-modal__base h2 {
  color: rgba(60, 66, 82, 0.6);
  font-size: 16px;
  font-weight: 600;
  letter-spacing: 0;
  line-height: 1.1875em;
  margin: 0 0 19px 0;
  text-align: center;
  width: 100%;
}

.walletconnect-modal__base__row {
  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
  align-items: center;
  border-radius: 20px;
  cursor: pointer;
  display: flex;
  height: 56px;
  justify-content: space-between;
  padding: 0 15px;
  position: relative;
  margin: 0px 0px 8px;
  text-align: left;
  transition: 0.15s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  will-change: transform;
  text-decoration: none;
}

.walletconnect-modal__base__row:hover {
  background: rgba(60, 66, 82, 0.06);
}

.walletconnect-modal__base__row:active {
  background: rgba(60, 66, 82, 0.06);
  transform: scale(0.975);
  transition: 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.walletconnect-modal__base__row__h3 {
  color: #25292e;
  font-size: 20px;
  font-weight: 700;
  margin: 0;
  padding-bottom: 3px;
}

.walletconnect-modal__base__row__right {
  align-items: center;
  display: flex;
  justify-content: center;
}

.walletconnect-modal__base__row__right__app-icon {
  border-radius: 8px;
  height: 34px;
  margin: 0 11px 2px 0;
  width: 34px;
  background-size: 100%;
  box-shadow: 0 4px 12px 0 rgba(37, 41, 46, 0.25);
}

.walletconnect-modal__base__row__right__caret {
  height: 18px;
  opacity: 0.3;
  transition: 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94);
  width: 8px;
  will-change: opacity;
}

.walletconnect-modal__base__row:hover .caret,
.walletconnect-modal__base__row:active .caret {
  opacity: 0.6;
}

.walletconnect-modal__mobile__toggle {
  width: 80%;
  display: flex;
  margin: 0 auto;
  position: relative;
  overflow: hidden;
  border-radius: 8px;
  margin-bottom: 18px;
  background: #d4d5d9;
}

.walletconnect-modal__single_wallet {
  display: flex;
  justify-content: center;
  margin-top: 7px;
  margin-bottom: 18px;
}

.walletconnect-modal__single_wallet a {
  cursor: pointer;
  color: rgb(64, 153, 255);
  font-size: 21px;
  font-weight: 800;
  text-decoration: none !important;
  margin: 0 auto;
}

.walletconnect-modal__mobile__toggle_selector {
  width: calc(50% - 8px);
  background: white;
  position: absolute;
  border-radius: 5px;
  height: calc(100% - 8px);
  top: 4px;
  transition: all 0.2s ease-in-out;
  transform: translate3d(4px, 0, 0);
}

.walletconnect-modal__mobile__toggle.right__selected .walletconnect-modal__mobile__toggle_selector {
  transform: translate3d(calc(100% + 12px), 0, 0);
}

.walletconnect-modal__mobile__toggle a {
  font-size: 12px;
  width: 50%;
  text-align: center;
  padding: 8px;
  margin: 0;
  font-weight: 600;
  z-index: 1;
}

.walletconnect-modal__footer {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

@media only screen and (max-width: 768px) {
  .walletconnect-modal__footer {
    margin-top: 5vw;
  }
}

.walletconnect-modal__footer a {
  cursor: pointer;
  color: #898d97;
  font-size: 15px;
  margin: 0 auto;
}

@media only screen and (max-width: 320px) {
  .walletconnect-modal__footer a {
    font-size: 14px;
  }
}

.walletconnect-connect__buttons__wrapper {
  max-height: 44vh;
}

.walletconnect-connect__buttons__wrapper__android {
  margin: 50% 0;
}

.walletconnect-connect__buttons__wrapper__wrap {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  margin: 10px 0;
}

@media only screen and (min-width: 768px) {
  .walletconnect-connect__buttons__wrapper__wrap {
    margin-top: 40px;
  }
}

.walletconnect-connect__button {
  background-color: rgb(64, 153, 255);
  padding: 12px;
  border-radius: 8px;
  text-decoration: none;
  color: rgb(255, 255, 255);
  font-weight: 500;
}

.walletconnect-connect__button__icon_anchor {
  cursor: pointer;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin: 8px;
  width: 42px;
  justify-self: center;
  flex-direction: column;
  text-decoration: none !important;
}

@media only screen and (max-width: 320px) {
  .walletconnect-connect__button__icon_anchor {
    margin: 4px;
  }
}

.walletconnect-connect__button__icon {
  border-radius: 10px;
  height: 42px;
  margin: 0;
  width: 42px;
  background-size: cover !important;
  box-shadow: 0 4px 12px 0 rgba(37, 41, 46, 0.25);
}

.walletconnect-connect__button__text {
  color: #424952;
  font-size: 2.7vw;
  text-decoration: none !important;
  padding: 0;
  margin-top: 1.8vw;
  font-weight: 600;
}

@media only screen and (min-width: 768px) {
  .walletconnect-connect__button__text {
    font-size: 16px;
    margin-top: 12px;
  }
}

.walletconnect-search__input {
  border: none;
  background: #d4d5d9;
  border-style: none;
  padding: 8px 16px;
  outline: none;
  font-style: normal;
  font-stretch: normal;
  font-size: 16px;
  font-style: normal;
  font-stretch: normal;
  line-height: normal;
  letter-spacing: normal;
  text-align: left;
  border-radius: 8px;
  width: calc(100% - 16px);
  margin: 0;
  margin-bottom: 8px;
}
`;
typeof Symbol < "u" && (Symbol.iterator || (Symbol.iterator = Symbol("Symbol.iterator")));
typeof Symbol < "u" && (Symbol.asyncIterator || (Symbol.asyncIterator = Symbol("Symbol.asyncIterator")));

function ef(t, e) {
    try {
        var n = t()
    } catch (r) {
        return e(r)
    }
    return n && n.then ? n.then(void 0, e) : n
}
var tf = "data:image/svg+xml,%3Csvg height='185' viewBox='0 0 300 185' width='300' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='m61.4385429 36.2562612c48.9112241-47.8881663 128.2119871-47.8881663 177.1232091 0l5.886545 5.7634174c2.445561 2.3944081 2.445561 6.2765112 0 8.6709204l-20.136695 19.715503c-1.222781 1.1972051-3.2053 1.1972051-4.428081 0l-8.100584-7.9311479c-34.121692-33.4079817-89.443886-33.4079817-123.5655788 0l-8.6750562 8.4936051c-1.2227816 1.1972041-3.205301 1.1972041-4.4280806 0l-20.1366949-19.7155031c-2.4455612-2.3944092-2.4455612-6.2765122 0-8.6709204zm218.7677961 40.7737449 17.921697 17.546897c2.445549 2.3943969 2.445563 6.2764769.000031 8.6708899l-80.810171 79.121134c-2.445544 2.394426-6.410582 2.394453-8.85616.000062-.00001-.00001-.000022-.000022-.000032-.000032l-57.354143-56.154572c-.61139-.598602-1.60265-.598602-2.21404 0-.000004.000004-.000007.000008-.000011.000011l-57.3529212 56.154531c-2.4455368 2.394432-6.4105755 2.394472-8.8561612.000087-.0000143-.000014-.0000296-.000028-.0000449-.000044l-80.81241943-79.122185c-2.44556021-2.394408-2.44556021-6.2765115 0-8.6709197l17.92172963-17.5468673c2.4455602-2.3944082 6.4105989-2.3944082 8.8561602 0l57.3549775 56.155357c.6113908.598602 1.602649.598602 2.2140398 0 .0000092-.000009.0000174-.000017.0000265-.000024l57.3521031-56.155333c2.445505-2.3944633 6.410544-2.3945531 8.856161-.0002.000034.0000336.000068.0000673.000101.000101l57.354902 56.155432c.61139.598601 1.60265.598601 2.21404 0l57.353975-56.1543249c2.445561-2.3944092 6.410599-2.3944092 8.85616 0z' fill='%233b99fc'/%3E%3C/svg%3E",
    nf = "WalletConnect",
    rf = 300,
    of = "rgb(64, 153, 255)",
    Go = "walletconnect-wrapper",
    ei = "walletconnect-style-sheet",
    Zo = "walletconnect-qrcode-modal",
    af = "walletconnect-qrcode-close",
    Xo = "walletconnect-qrcode-text",
    sf = "walletconnect-connect-button";

function lf(t) {
    return U.createElement("div", {
        className: "walletconnect-modal__header"
    }, U.createElement("img", {
        src: tf,
        className: "walletconnect-modal__headerLogo"
    }), U.createElement("p", null, nf), U.createElement("div", {
        className: "walletconnect-modal__close__wrapper",
        onClick: t.onClose
    }, U.createElement("div", {
        id: af,
        className: "walletconnect-modal__close__icon"
    }, U.createElement("div", {
        className: "walletconnect-modal__close__line1"
    }), U.createElement("div", {
        className: "walletconnect-modal__close__line2"
    }))))
}

function cf(t) {
    return U.createElement("a", {
        className: "walletconnect-connect__button",
        href: t.href,
        id: sf + "-" + t.name,
        onClick: t.onClick,
        rel: "noopener noreferrer",
        style: {
            backgroundColor: t.color
        },
        target: "_blank"
    }, t.name)
}
var ff = "data:image/svg+xml,%3Csvg fill='none' height='18' viewBox='0 0 8 18' width='8' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath clip-rule='evenodd' d='m.586301.213898c-.435947.33907-.5144813.967342-.175411 1.403292l4.87831 6.27212c.28087.36111.28087.86677 0 1.22788l-4.878311 6.27211c-.33907.436-.260536 1.0642.175412 1.4033.435949.3391 1.064219.2605 1.403289-.1754l4.87832-6.2721c.84259-1.08336.84259-2.60034 0-3.68367l-4.87832-6.27212c-.33907-.4359474-.96734-.514482-1.403289-.175412z' fill='%233c4252' fill-rule='evenodd'/%3E%3C/svg%3E";

function uf(t) {
    var e = t.color,
        n = t.href,
        r = t.name,
        s = t.logo,
        o = t.onClick;
    return U.createElement("a", {
        className: "walletconnect-modal__base__row",
        href: n,
        onClick: o,
        rel: "noopener noreferrer",
        target: "_blank"
    }, U.createElement("h3", {
        className: "walletconnect-modal__base__row__h3"
    }, r), U.createElement("div", {
        className: "walletconnect-modal__base__row__right"
    }, U.createElement("div", {
        className: "walletconnect-modal__base__row__right__app-icon",
        style: {
            background: "url('" + s + "') " + e,
            backgroundSize: "100%"
        }
    }), U.createElement("img", {
        src: ff,
        className: "walletconnect-modal__base__row__right__caret"
    })))
}

function hf(t) {
    var e = t.color,
        n = t.href,
        r = t.name,
        s = t.logo,
        o = t.onClick,
        h = window.innerWidth < 768 ? (r.length > 8 ? 2.5 : 2.7) + "vw" : "inherit";
    return U.createElement("a", {
        className: "walletconnect-connect__button__icon_anchor",
        href: n,
        onClick: o,
        rel: "noopener noreferrer",
        target: "_blank"
    }, U.createElement("div", {
        className: "walletconnect-connect__button__icon",
        style: {
            background: "url('" + s + "') " + e,
            backgroundSize: "100%"
        }
    }), U.createElement("div", {
        style: {
            fontSize: h
        },
        className: "walletconnect-connect__button__text"
    }, r))
}
var df = 5,
    Bn = 12;

function pf(t) {
    var e = Ne.isAndroid(),
        n = U.useState(""),
        r = n[0],
        s = n[1],
        o = U.useState(""),
        h = o[0],
        m = o[1],
        v = U.useState(1),
        M = v[0],
        y = v[1],
        I = h ? t.links.filter(function(R) {
            return R.name.toLowerCase().includes(h.toLowerCase())
        }) : t.links,
        B = t.errorMessage,
        P = h || I.length > df,
        N = Math.ceil(I.length / Bn),
        D = [(M - 1) * Bn + 1, M * Bn],
        b = I.length ? I.filter(function(R, z) {
            return z + 1 >= D[0] && z + 1 <= D[1]
        }) : [],
        S = !e && N > 1,
        C = void 0;

    function E(R) {
        s(R.target.value), clearTimeout(C), R.target.value ? C = setTimeout(function() {
            m(R.target.value), y(1)
        }, 1e3) : (s(""), m(""), y(1))
    }
    return U.createElement("div", null, U.createElement("p", {
        id: Xo,
        className: "walletconnect-qrcode__text"
    }, e ? t.text.connect_mobile_wallet : t.text.choose_preferred_wallet), !e && U.createElement("input", {
        className: "walletconnect-search__input",
        placeholder: "Search",
        value: r,
        onChange: E
    }), U.createElement("div", {
        className: "walletconnect-connect__buttons__wrapper" + (e ? "__android" : P && I.length ? "__wrap" : "")
    }, e ? U.createElement(cf, {
        name: t.text.connect,
        color: of ,
        href: t.uri,
        onClick: U.useCallback(function() {
            Ne.saveMobileLinkInfo({
                name: "Unknown",
                href: t.uri
            })
        }, [])
    }) : b.length ? b.map(function(R) {
        var z = R.color,
            W = R.name,
            Q = R.shortName,
            J = R.logo,
            X = Ne.formatIOSMobile(t.uri, R),
            _ = U.useCallback(function() {
                Ne.saveMobileLinkInfo({
                    name: W,
                    href: X
                })
            }, [b]);
        return P ? U.createElement(hf, {
            color: z,
            href: X,
            name: Q || W,
            logo: J,
            onClick: _
        }) : U.createElement(uf, {
            color: z,
            href: X,
            name: W,
            logo: J,
            onClick: _
        })
    }) : U.createElement(U.Fragment, null, U.createElement("p", null, B.length ? t.errorMessage : !!t.links.length && !I.length ? t.text.no_wallets_found : t.text.loading))), S && U.createElement("div", {
        className: "walletconnect-modal__footer"
    }, Array(N).fill(0).map(function(R, z) {
        var W = z + 1,
            Q = M === W;
        return U.createElement("a", {
            style: {
                margin: "auto 10px",
                fontWeight: Q ? "bold" : "normal"
            },
            onClick: function() {
                return y(W)
            }
        }, W)
    })))
}

function gf(t) {
    var e = !!t.message.trim();
    return U.createElement("div", {
        className: "walletconnect-qrcode__notification" + (e ? " notification__show" : "")
    }, t.message)
}
var _f = function(t) {
    try {
        var e = "";
        return Promise.resolve(Qo.toString(t, {
            margin: 0,
            type: "svg"
        })).then(function(n) {
            return typeof n == "string" && (e = n.replace("<svg", '<svg class="walletconnect-qrcode__image"')), e
        })
    } catch (n) {
        return Promise.reject(n)
    }
};

function mf(t) {
    var e = U.useState(""),
        n = e[0],
        r = e[1],
        s = U.useState(""),
        o = s[0],
        h = s[1];
    U.useEffect(function() {
        try {
            return Promise.resolve(_f(t.uri)).then(function(v) {
                h(v)
            })
        } catch (v) {
            Promise.reject(v)
        }
    }, []);
    var m = function() {
        var v = Gc(t.uri);
        v ? (r(t.text.copied_to_clipboard), setInterval(function() {
            return r("")
        }, 1200)) : (r("Error"), setInterval(function() {
            return r("")
        }, 1200))
    };
    return U.createElement("div", null, U.createElement("p", {
        id: Xo,
        className: "walletconnect-qrcode__text"
    }, t.text.scan_qrcode_with_wallet), U.createElement("div", {
        dangerouslySetInnerHTML: {
            __html: o
        }
    }), U.createElement("div", {
        className: "walletconnect-modal__footer"
    }, U.createElement("a", {
        onClick: m
    }, t.text.copy_to_clipboard)), U.createElement(gf, {
        message: n
    }))
}

function vf(t) {
    var e = Ne.isAndroid(),
        n = Ne.isMobile(),
        r = n ? t.qrcodeModalOptions && t.qrcodeModalOptions.mobileLinks ? t.qrcodeModalOptions.mobileLinks : void 0 : t.qrcodeModalOptions && t.qrcodeModalOptions.desktopLinks ? t.qrcodeModalOptions.desktopLinks : void 0,
        s = U.useState(!1),
        o = s[0],
        h = s[1],
        m = U.useState(!1),
        v = m[0],
        M = m[1],
        y = U.useState(!n),
        I = y[0],
        B = y[1],
        P = {
            mobile: n,
            text: t.text,
            uri: t.uri,
            qrcodeModalOptions: t.qrcodeModalOptions
        },
        N = U.useState(""),
        D = N[0],
        b = N[1],
        S = U.useState(!1),
        C = S[0],
        E = S[1],
        R = U.useState([]),
        z = R[0],
        W = R[1],
        Q = U.useState(""),
        J = Q[0],
        X = Q[1],
        _ = function() {
            v || o || r && !r.length || z.length > 0 || U.useEffect(function() {
                var l = function() {
                    try {
                        if (e) return Promise.resolve();
                        h(!0);
                        var f = ef(function() {
                            var u = t.qrcodeModalOptions && t.qrcodeModalOptions.registryUrl ? t.qrcodeModalOptions.registryUrl : Ne.getWalletRegistryUrl();
                            return Promise.resolve(fetch(u)).then(function(g) {
                                return Promise.resolve(g.json()).then(function(w) {
                                    var x = w.listings,
                                        d = n ? "mobile" : "desktop",
                                        a = Ne.getMobileLinkRegistry(Ne.formatMobileRegistry(x, d), r);
                                    h(!1), M(!0), X(a.length ? "" : t.text.no_supported_wallets), W(a);
                                    var p = a.length === 1;
                                    p && (b(Ne.formatIOSMobile(t.uri, a[0])), B(!0)), E(p)
                                })
                            })
                        }, function(u) {
                            h(!1), M(!0), X(t.text.something_went_wrong), console.error(u)
                        });
                        return Promise.resolve(f && f.then ? f.then(function() {}) : void 0)
                    } catch (u) {
                        return Promise.reject(u)
                    }
                };
                l()
            })
        };
    _();
    var i = n ? I : !I;
    return U.createElement("div", {
        id: Zo,
        className: "walletconnect-qrcode__base animated fadeIn"
    }, U.createElement("div", {
        className: "walletconnect-modal__base"
    }, U.createElement(lf, {
        onClose: t.onClose
    }), C && I ? U.createElement("div", {
        className: "walletconnect-modal__single_wallet"
    }, U.createElement("a", {
        onClick: function() {
            return Ne.saveMobileLinkInfo({
                name: z[0].name,
                href: D
            })
        },
        href: D,
        rel: "noopener noreferrer",
        target: "_blank"
    }, t.text.connect_with + " " + (C ? z[0].name : "") + " \u203A")) : e || o || !o && z.length ? U.createElement("div", {
        className: "walletconnect-modal__mobile__toggle" + (i ? " right__selected" : "")
    }, U.createElement("div", {
        className: "walletconnect-modal__mobile__toggle_selector"
    }), n ? U.createElement(U.Fragment, null, U.createElement("a", {
        onClick: function() {
            return B(!1), _()
        }
    }, t.text.mobile), U.createElement("a", {
        onClick: function() {
            return B(!0)
        }
    }, t.text.qrcode)) : U.createElement(U.Fragment, null, U.createElement("a", {
        onClick: function() {
            return B(!0)
        }
    }, t.text.qrcode), U.createElement("a", {
        onClick: function() {
            return B(!1), _()
        }
    }, t.text.desktop))) : null, U.createElement("div", null, I || !e && !o && !z.length ? U.createElement(mf, Object.assign({}, P)) : U.createElement(pf, Object.assign({}, P, {
        links: z,
        errorMessage: J
    })))))
}
var wf = {
        choose_preferred_wallet: "W\xE4hle bevorzugte Wallet",
        connect_mobile_wallet: "Verbinde mit Mobile Wallet",
        scan_qrcode_with_wallet: "Scanne den QR-code mit einer WalletConnect kompatiblen Wallet",
        connect: "Verbinden",
        qrcode: "QR-Code",
        mobile: "Mobile",
        desktop: "Desktop",
        copy_to_clipboard: "In die Zwischenablage kopieren",
        copied_to_clipboard: "In die Zwischenablage kopiert!",
        connect_with: "Verbinden mit Hilfe von",
        loading: "Laden...",
        something_went_wrong: "Etwas ist schief gelaufen",
        no_supported_wallets: "Es gibt noch keine unterst\xFCtzten Wallet",
        no_wallets_found: "keine Wallet gefunden"
    },
    yf = {
        choose_preferred_wallet: "Choose your preferred wallet",
        connect_mobile_wallet: "Connect to Mobile Wallet",
        scan_qrcode_with_wallet: "Scan QR code with a WalletConnect-compatible wallet",
        connect: "Connect",
        qrcode: "QR Code",
        mobile: "Mobile",
        desktop: "Desktop",
        copy_to_clipboard: "Copy to clipboard",
        copied_to_clipboard: "Copied to clipboard!",
        connect_with: "Connect with",
        loading: "Loading...",
        something_went_wrong: "Something went wrong",
        no_supported_wallets: "There are no supported wallets yet",
        no_wallets_found: "No wallets found"
    },
    bf = {
        choose_preferred_wallet: "Elige tu billetera preferida",
        connect_mobile_wallet: "Conectar a billetera m\xF3vil",
        scan_qrcode_with_wallet: "Escanea el c\xF3digo QR con una billetera compatible con WalletConnect",
        connect: "Conectar",
        qrcode: "C\xF3digo QR",
        mobile: "M\xF3vil",
        desktop: "Desktop",
        copy_to_clipboard: "Copiar",
        copied_to_clipboard: "Copiado!",
        connect_with: "Conectar mediante",
        loading: "Cargando...",
        something_went_wrong: "Algo sali\xF3 mal",
        no_supported_wallets: "Todav\xEDa no hay billeteras compatibles",
        no_wallets_found: "No se encontraron billeteras"
    },
    Mf = {
        choose_preferred_wallet: "Choisissez votre portefeuille pr\xE9f\xE9r\xE9",
        connect_mobile_wallet: "Se connecter au portefeuille mobile",
        scan_qrcode_with_wallet: "Scannez le QR code avec un portefeuille compatible WalletConnect",
        connect: "Se connecter",
        qrcode: "QR Code",
        mobile: "Mobile",
        desktop: "Desktop",
        copy_to_clipboard: "Copier",
        copied_to_clipboard: "Copi\xE9!",
        connect_with: "Connectez-vous \xE0 l'aide de",
        loading: "Chargement...",
        something_went_wrong: "Quelque chose a mal tourn\xE9",
        no_supported_wallets: "Il n'y a pas encore de portefeuilles pris en charge",
        no_wallets_found: "Aucun portefeuille trouv\xE9"
    },
    xf = {
        choose_preferred_wallet: "\uC6D0\uD558\uB294 \uC9C0\uAC11\uC744 \uC120\uD0DD\uD558\uC138\uC694",
        connect_mobile_wallet: "\uBAA8\uBC14\uC77C \uC9C0\uAC11\uACFC \uC5F0\uACB0",
        scan_qrcode_with_wallet: "WalletConnect \uC9C0\uC6D0 \uC9C0\uAC11\uC5D0\uC11C QR\uCF54\uB4DC\uB97C \uC2A4\uCE94\uD558\uC138\uC694",
        connect: "\uC5F0\uACB0",
        qrcode: "QR \uCF54\uB4DC",
        mobile: "\uBAA8\uBC14\uC77C",
        desktop: "\uB370\uC2A4\uD06C\uD0D1",
        copy_to_clipboard: "\uD074\uB9BD\uBCF4\uB4DC\uC5D0 \uBCF5\uC0AC",
        copied_to_clipboard: "\uD074\uB9BD\uBCF4\uB4DC\uC5D0 \uBCF5\uC0AC\uB418\uC5C8\uC2B5\uB2C8\uB2E4!",
        connect_with: "\uC640 \uC5F0\uACB0\uD558\uB2E4",
        loading: "\uB85C\uB4DC \uC911...",
        something_went_wrong: "\uBB38\uC81C\uAC00 \uBC1C\uC0DD\uD588\uC2B5\uB2C8\uB2E4.",
        no_supported_wallets: "\uC544\uC9C1 \uC9C0\uC6D0\uB418\uB294 \uC9C0\uAC11\uC774 \uC5C6\uC2B5\uB2C8\uB2E4",
        no_wallets_found: "\uC9C0\uAC11\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4"
    },
    Sf = {
        choose_preferred_wallet: "Escolha sua carteira preferida",
        connect_mobile_wallet: "Conectar-se \xE0 carteira m\xF3vel",
        scan_qrcode_with_wallet: "Ler o c\xF3digo QR com uma carteira compat\xEDvel com WalletConnect",
        connect: "Conectar",
        qrcode: "C\xF3digo QR",
        mobile: "M\xF3vel",
        desktop: "Desktop",
        copy_to_clipboard: "Copiar",
        copied_to_clipboard: "Copiado!",
        connect_with: "Ligar por meio de",
        loading: "Carregamento...",
        something_went_wrong: "Algo correu mal",
        no_supported_wallets: "Ainda n\xE3o h\xE1 carteiras suportadas",
        no_wallets_found: "Nenhuma carteira encontrada"
    },
    Ef = {
        choose_preferred_wallet: "\u9009\u62E9\u4F60\u7684\u94B1\u5305",
        connect_mobile_wallet: "\u8FDE\u63A5\u81F3\u79FB\u52A8\u7AEF\u94B1\u5305",
        scan_qrcode_with_wallet: "\u4F7F\u7528\u517C\u5BB9 WalletConnect \u7684\u94B1\u5305\u626B\u63CF\u4E8C\u7EF4\u7801",
        connect: "\u8FDE\u63A5",
        qrcode: "\u4E8C\u7EF4\u7801",
        mobile: "\u79FB\u52A8",
        desktop: "\u684C\u9762",
        copy_to_clipboard: "\u590D\u5236\u5230\u526A\u8D34\u677F",
        copied_to_clipboard: "\u590D\u5236\u5230\u526A\u8D34\u677F\u6210\u529F\uFF01",
        connect_with: "\u901A\u8FC7\u4EE5\u4E0B\u65B9\u5F0F\u8FDE\u63A5",
        loading: "\u6B63\u5728\u52A0\u8F7D...",
        something_went_wrong: "\u51FA\u4E86\u95EE\u9898",
        no_supported_wallets: "\u76EE\u524D\u8FD8\u6CA1\u6709\u652F\u6301\u7684\u94B1\u5305",
        no_wallets_found: "\u6CA1\u6709\u627E\u5230\u94B1\u5305"
    },
    Cf = {
        choose_preferred_wallet: "\u06A9\u06CC\u0641 \u067E\u0648\u0644 \u0645\u0648\u0631\u062F \u0646\u0638\u0631 \u062E\u0648\u062F \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F",
        connect_mobile_wallet: "\u0628\u0647 \u06A9\u06CC\u0641 \u067E\u0648\u0644 \u0645\u0648\u0628\u0627\u06CC\u0644 \u0648\u0635\u0644 \u0634\u0648\u06CC\u062F",
        scan_qrcode_with_wallet: "\u06A9\u062F QR \u0631\u0627 \u0628\u0627 \u06CC\u06A9 \u06A9\u06CC\u0641 \u067E\u0648\u0644 \u0633\u0627\u0632\u06AF\u0627\u0631 \u0628\u0627 WalletConnect \u0627\u0633\u06A9\u0646 \u06A9\u0646\u06CC\u062F",
        connect: "\u0627\u062A\u0635\u0627\u0644",
        qrcode: "\u06A9\u062F QR",
        mobile: "\u0633\u06CC\u0627\u0631",
        desktop: "\u062F\u0633\u06A9\u062A\u0627\u067E",
        copy_to_clipboard: "\u06A9\u067E\u06CC \u0628\u0647 \u06A9\u0644\u06CC\u067E \u0628\u0648\u0631\u062F",
        copied_to_clipboard: "\u062F\u0631 \u06A9\u0644\u06CC\u067E \u0628\u0648\u0631\u062F \u06A9\u067E\u06CC \u0634\u062F!",
        connect_with: "\u0627\u0631\u062A\u0628\u0627\u0637 \u0628\u0627",
        loading: "...\u0628\u0627\u0631\u06AF\u0630\u0627\u0631\u06CC",
        something_went_wrong: "\u0645\u0634\u06A9\u0644\u06CC \u067E\u06CC\u0634 \u0622\u0645\u062F",
        no_supported_wallets: "\u0647\u0646\u0648\u0632 \u0647\u06CC\u0686 \u06A9\u06CC\u0641 \u067E\u0648\u0644 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0634\u062F\u0647 \u0627\u06CC \u0648\u062C\u0648\u062F \u0646\u062F\u0627\u0631\u062F",
        no_wallets_found: "\u0647\u06CC\u0686 \u06A9\u06CC\u0641 \u067E\u0648\u0644\u06CC \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F"
    },
    ti = {
        de: wf,
        en: yf,
        es: bf,
        fr: Mf,
        ko: xf,
        pt: Sf,
        zh: Ef,
        fa: Cf
    };

function kf() {
    var t = Ne.getDocumentOrThrow(),
        e = t.getElementById(ei);
    e && t.head.removeChild(e);
    var n = t.createElement("style");
    n.setAttribute("id", ei), n.innerText = Xc, t.head.appendChild(n)
}

function Rf() {
    var t = Ne.getDocumentOrThrow(),
        e = t.createElement("div");
    return e.setAttribute("id", Go), t.body.appendChild(e), e
}

function ea() {
    var t = Ne.getDocumentOrThrow(),
        e = t.getElementById(Zo);
    e && (e.className = e.className.replace("fadeIn", "fadeOut"), setTimeout(function() {
        var n = t.getElementById(Go);
        n && t.body.removeChild(n)
    }, rf))
}

function Af(t) {
    return function() {
        ea(), t && t()
    }
}

function Tf() {
    var t = Ne.getNavigatorOrThrow().language.split("-")[0] || "en";
    return ti[t] || ti.en
}

function If(t, e, n) {
    kf();
    var r = Rf();
    U.render(U.createElement(vf, {
        text: Tf(),
        uri: t,
        onClose: Af(e),
        qrcodeModalOptions: n
    }), r)
}

function Nf() {
    ea()
}
var ta = function() {
    return typeof process < "u" && typeof process.versions < "u" && typeof process.versions.node < "u"
};

function Of(t, e, n) {
    console.log(t), ta() ? Zc(t) : If(t, e, n)
}

function Bf() {
    ta() || Nf()
}
var Lf = {
        open: Of,
        close: Bf
    },
    Pf = Lf;
let bt = null;

function na() {
    return new Promise((t, e) => {
        if (bt) return t(bt); {
            const n = new Rl({
                bridge: "https://bridge.walletconnect.org",
                qrcodeModal: Pf
            });
            window.conn = n, n.connected ? (bt = n, t(n)) : n.createSession(), n.on("connect", r => {
                r ? e(r) : (bt = n, t(bt))
            }), n.on("disconnect", r => {
                r || (bt = null)
            })
        }
    })
}
async function Wf(t) {
    const e = await na(),
        n = e.accounts[0];
    return {
        signature: await e.signPersonalMessage([ps(t), n]),
        publicAddress: n
    }
}
const Ff = Math.pow(10, 18);

function Uf(t) {
    return new ra(t).mul(Ff).toNumber()
}
async function Hf(t, e) {
    const n = await na();
    return n.sendTransaction({
        from: n.accounts[0],
        to: t,
        value: `0x${Uf(e).toString(16)}`
    })
}
export {
    Hf as sendTransaction, Wf as signPersonalMessage
};
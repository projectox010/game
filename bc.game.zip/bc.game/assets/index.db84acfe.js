import {
    u as d,
    a as e,
    D as h,
    dx as w,
    j as l,
    a5 as b,
    du as g,
    r as u,
    dy as y,
    dD as _,
    dZ as G,
    eO as A,
    dE as D,
    d as p,
    d_ as V,
    s as f,
    y as x,
    n as B,
    a2 as F,
    bo as N,
    F as I
} from "./index.28e31dff.js";
import {
    s as c
} from "./index.dd8128e8.js";
import {
    S as k
} from "./SlotsILayout.a8936350.js";
const $ = () => {
        const a = d();
        return e(h, {
            title: a("common.game_intro"),
            children: e(w, {
                children: l("div", {
                    className: "item",
                    children: [e("h2", {
                        children: "What Is Saviour Sword?"
                    }), e("p", {
                        children: "With the power of the Saviour Sword, Hal Green will be able to defeat the evil."
                    }), e("p", {
                        children: "Saviour Sword is a 5-reel, 1-row video slot game featuring Lucky Spin and Bonus Respin.players stand a chance to multiply their wins or win respins!"
                    })]
                })
            })
        })
    },
    H = ({
        bodyLock: a
    }) => {
        const t = d();
        return e(h, {
            title: t("common.fairness"),
            children: e(w, {
                bodyLock: a,
                children: l("div", {
                    className: "item",
                    children: [e("h2", {
                        children: "Fairness Verification"
                    }), e("p", {
                        children: "To get the results:"
                    }), l("ul", {
                        children: [e("li", {
                            children: "First, hash = HMAC_SHA512(clientSeed:nonce:round, serverSeed)"
                        }), e("li", {
                            children: "Finally, we get 8 characters of the hash, and convert them to an int32 value. Then we divide the converted value by 0x100000000 and multiply weight, so that the resulting number conforms to the constraints of the range."
                        })]
                    }), e("p", {
                        children: "Note: For more details, please go to My Bet -> Choose Game ID -> Verify."
                    })]
                })
            })
        })
    };
var P = H;
const R = b.memo(() => {
    const a = d(),
        t = g(),
        n = u.exports.useRef(null);
    u.exports.useEffect(() => {
        const r = n.current;
        if (r) {
            const i = m => {
                const o = j(m);
                t.handleBet(o.betAmount, o)
            };
            return r.on("betSuccess", i), () => {
                r.off("betSuccess", i)
            }
        }
    }, []);
    const s = [{
        title: a("common.game_intro"),
        node: e($, {})
    }, {
        title: a("common.fairness"),
        node: e(P, {})
    }, {
        title: a("common.max_profits"),
        node: e(y, {
            game: t,
            title: a("common.max_profits")
        })
    }];
    return e(k, {
        src: t.gameUrl,
        ref: n,
        actions: [e(_, {}), e(G, {}), e(A, {}), e(D, {
            list: s
        })],
        banner: t.gameInfo.cover,
        tabs: [{
            label: a("common.all_bet"),
            value: c.AllBet
        }, {
            label: a("common.my_bet"),
            value: c.MyBet
        }]
    })
});

function j(a) {
    const {
        betAmount: t,
        betId: n,
        betTime: s,
        currencyName: r,
        nonce: i,
        odds: m,
        winAmount: o,
        gameValue: S
    } = a;
    return {
        userId: p.userId,
        nickName: p.name,
        betAmount: t,
        betId: n,
        betTime: s,
        currencyName: r,
        nonce: i,
        odds: m,
        winAmount: o,
        profitAmount: o - t,
        gameValue: S
    }
}
class L extends V {
    constructor() {
        super({
            name: "SlotsSword",
            namespace: "/g/ss",
            fairLink: "/sword_help/fairness",
            validateLink: "/sword_help/validate"
        }, R), this.gameUrl = f.isDev ? "http://sword.bc.com/" : `//sword.${f.domain}`
    }
    betValue() {
        return new Uint8Array
    }
    async handleBet(t, n) {
        this.addMyBet(n), this.emit("betEnd", {
            amount: new x(n.betAmount),
            odds: n.odds,
            currencyName: n.currencyName
        })
    }
}
const v = new L;
var Q = v;
window.sg = v;
const M = (a, t, n) => {
        B(`/sword_help/validate/${a}/${t}/${n}`)
    },
    U = c.withSingleDetail({
        onValidate: M
    });
var X = U,
    E = "/assets/m_banner.7aa62263.png",
    T = "/assets/banner_a1.0147d5cb.png",
    C = "/assets/banner_a2.56172789.png",
    W = "/assets/icon.cdcb5b45.png",
    O = "/assets/play_now.864421c1.png";
const Z = {
        m_banner: E,
        banner_a1: T,
        banner_a2: C,
        play_now: O,
        icon: W,
        verify_pdf: "https://bcgame-project.github.io/verify/saviourSword.pdf"
    },
    q = () => {
        const a = F(),
            t = N(a),
            n = d(),
            s = c.GameValidate;
        return e(h, {
            title: n("common.fairness"),
            children: e(s, {
                serverSeed: t[0],
                clientSeed: t[1],
                nonce: Number(t[2]),
                modulusList: Array(5).fill(1),
                hasRound: !0,
                children: () => l(I, {
                    children: [e("p", {
                        children: e("br", {})
                    }), e("p", {
                        children: "Please check the following documents for verification method and comparison table"
                    }), e("p", {
                        children: e("a", {
                            className: "cl-primary",
                            href: Z.verify_pdf,
                            target: "_blank",
                            children: "SaviourSword.pdf"
                        })
                    })]
                })
            })
        })
    };
var Y = q;
export {
    X as Detail, P as Fairness, Q as Game, Y as Validate
};
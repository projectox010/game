var p = Object.getOwnPropertySymbols;
var j = Object.prototype.hasOwnProperty,
    y = Object.prototype.propertyIsEnumerable;
var G = (e, m) => {
    var c = {};
    for (var s in e) j.call(e, s) && m.indexOf(s) < 0 && (c[s] = e[s]);
    if (e != null && p)
        for (var s of p(e)) m.indexOf(s) < 0 && y.call(e, s) && (c[s] = e[s]);
    return c
};
import {
    c5 as v,
    r as E,
    a as i,
    c6 as o,
    c7 as I,
    j as N,
    c8 as L,
    c9 as A,
    l as V,
    a4 as W
} from "./index.28e31dff.js";

function D(k) {
    var d = k,
        {
            list: e,
            header: m,
            className: c,
            loadingSize: s,
            isMakeup: h,
            onCallBack: u
        } = d,
        g = G(d, ["list", "header", "className", "loadingSize", "isMakeup", "onCallBack"]);
    const {
        ref: f,
        num: a
    } = v();
    E.exports.useEffect(() => {
        a && u && u(a)
    }, [a]);
    const w = s != null ? s : a;
    let n;
    if (e && e.length === 0) n = i("div", {
        className: "grid-list",
        children: i(W, {})
    });
    else if (!e) n = i(o, {
        ref: f,
        num: a,
        className: "grid-list",
        children: new Array(w).fill(null).map((l, t) => i(I, {}, t))
    });
    else {
        let l = 0;
        if (h) {
            const t = e.filter(x => x.iconWide).length,
                r = (e.length + t) % a;
            l = r && a - r
        }
        n = N(o, {
            ref: f,
            num: a,
            className: "grid-list",
            children: [e && e.map((t, r) => i(L, {
                data: Object.assign(t, g)
            }, r)), l > 0 && new Array(l).fill(null).map((t, r) => i(A, {}, r))]
        })
    }
    return m ? N("div", {
        className: V(b, c),
        children: [m, n]
    }) : n
}
const b = "l1autedk";
export {
    D as G
};
import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as e
} from "./index.28e31dff.js";
var n = `<section>
  <h2>Gamble Aware & Protecting Minors</h2>
  <p>Betting at an online casino is primarily done for recreational purposes. However, a small percentage of people experience a loss of control of themselves while gambling. Before beginning to play, it is critical to understand that gaming should not be regarded as a source of revenue or a means of debt repayment. It is beneficial to keep track of the amount of time and money spent at an online casino on a daily basis.</p>
  <p>BC.GAME only accepts players who are at least 18 years old and employs all applicable methods to prevent underage people from registering and playing at our casino. The casino holds the right to request identification, and if the player is not of legal gambling age, access to the website will be refused. However, we recognize that due to the widespread availability of the Internet, people under the age of 18 can still sign up and play at an online casino. As a result, we strongly encourage parents to work together to protect their children from free access to betting websites. There is specialized software available to assist in this situation. 
    For more information, please see the websites listed below.</p>
  <p><a class="cl-primary" href="http://www.cyberpatrol.com/" target="_blank">\u2022 http://www.cyberpatrol.com/</a></p>
  <p><a class="cl-primary" href="http://www.gamblock.com/" target="_blank">\u2022 http://www.gamblock.com/</a></p>
</section>`,
    t = `<section>\r
  <h2>Aposte com consci\xEAnciae &amp; Protegendo Menores</h2>\r
  <p>As apostas em um cassino online s\xE3o feitas principalmente para fins recreativos. No entanto, uma pequena porcentagem de pessoas experimenta uma perda de controle de si mesmas enquanto joga. Antes de come\xE7ar a jogar, \xE9 fundamental entender que o jogo n\xE3o deve ser visto como uma fonte de receita ou meio de pagamento de d\xEDvidas. \xC9 ben\xE9fico acompanhar a quantidade de tempo e dinheiro gasto em um cassino online diariamente.</p>\r
  <p>BC.GAME s\xF3 aceita jogadores com pelo menos 18 anos e emprega todos os m\xE9todos aplic\xE1veis para impedir que menores de idade se registrem e joguem em nosso cassino. O casino tem o direito de solicitar a identifica\xE7\xE3o e, se o jogador n\xE3o tiver idade legal para jogar, o acesso ao site ser\xE1 recusado. No entanto, reconhecemos que, devido \xE0 ampla disponibilidade da Internet, pessoas com menos de 18 anos ainda podem se inscrever e jogar em um cassino online. Como resultado, incentivamos fortemente os pais a trabalharem juntos para proteger seus filhos do acesso gratuito a sites de apostas. Existe um software especializado dispon\xEDvel para ajudar nesta situa\xE7\xE3o.\r
     Para obter mais informa\xE7\xF5es, consulte os sites listados abaixo.</p>\r
  <p><a class="cl-primary" href="http://www.cyberpatrol.com/" target="_blank">\u2022 http://www.cyberpatrol.com/</a></p>\r
  <p><a class="cl-primary" href="http://www.gamblock.com/" target="_blank">\u2022 http://www.gamblock.com/</a></p>\r
</section>`,
    i = `<section>
  <h2>Sadar Berjudi & Melindungi Anak di Bawah Umur</h2>
  <p>Bertaruh di kasino online terutama dilakukan untuk tujuan rekreasi. Namun, sebagian kecil orang mengalami kehilangan kendali atas diri mereka sendiri saat berjudi. Sebelum mulai bermain, penting untuk dipahami bahwa bermain game tidak boleh dianggap sebagai sumber pendapatan atau alat pembayaran hutang. Sangat bermanfaat untuk melacak jumlah waktu dan uang yang dihabiskan di kasino online setiap hari.</p>
  <p>BC.GAME hanya menerima pemain yang berusia setidaknya 18 tahun dan menggunakan semua metode yang berlaku untuk mencegah orang di bawah umur mendaftar dan bermain di kasino kami. Kasino memiliki hak untuk meminta identifikasi, dan jika pemain tersebut bukan usia perjudian yang sah, akses ke situs web akan ditolak. Namun, kami menyadari bahwa karena ketersediaan Internet yang luas, orang-orang di bawah usia 18 tahun masih dapat mendaftar dan bermain di kasino online. Oleh karena itu, kami sangat menganjurkan orang tua untuk bekerja sama melindungi anak-anak mereka dari akses gratis ke situs web taruhan. Ada software khusus yang tersedia untuk membantu dalam situasi ini.
    Untuk informasi lebih lanjut, silakan lihat situs-situs yang terdaftar di bawah ini.</p>
  <p><a class="cl-primary" href="http://www.cyberpatrol.com/" target="_blank">\u2022 http://www.cyberpatrol.com/</a></p>
  <p><a class="cl-primary" href="http://www.gamblock.com/" target="_blank">\u2022 http://www.gamblock.com/</a></p>
</section>`;

function r() {
    return e(a, {
        br: t,
        en: n,
        id: i
    })
}
export {
    r as
    default
};
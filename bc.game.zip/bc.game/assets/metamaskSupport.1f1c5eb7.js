import {
    at as Ne
} from "./index.28e31dff.js";
var Oe = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i,
    ae = Math.ceil,
    X = Math.floor,
    y = "[BigNumber Error] ",
    we = y + "Number primitive has more than 15 significant digits: ",
    $ = 1e14,
    E = 14,
    he = 9007199254740991,
    pe = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13],
    J = 1e7,
    P = 1e9;

function me(g) {
    var m, N, v, p = h.prototype = {
            constructor: h,
            toString: null,
            valueOf: null
        },
        M = new h(1),
        x = 20,
        T = 4,
        U = -7,
        L = 21,
        Q = -1e7,
        H = 1e7,
        Z = !1,
        b = 1,
        Y = 0,
        fe = {
            prefix: "",
            groupSize: 3,
            secondaryGroupSize: 0,
            groupSeparator: ",",
            decimalSeparator: ".",
            fractionGroupSize: 0,
            fractionGroupSeparator: "\xA0",
            suffix: ""
        },
        K = "0123456789abcdefghijklmnopqrstuvwxyz",
        oe = !0;

    function h(e, r) {
        var i, c, t, o, u, n, f, l, s = this;
        if (!(s instanceof h)) return new h(e, r);
        if (r == null) {
            if (e && e._isBigNumber === !0) {
                s.s = e.s, !e.c || e.e > H ? s.c = s.e = null : e.e < Q ? s.c = [s.e = 0] : (s.e = e.e, s.c = e.c.slice());
                return
            }
            if ((n = typeof e == "number") && e * 0 == 0) {
                if (s.s = 1 / e < 0 ? (e = -e, -1) : 1, e === ~~e) {
                    for (o = 0, u = e; u >= 10; u /= 10, o++);
                    o > H ? s.c = s.e = null : (s.e = o, s.c = [e]);
                    return
                }
                l = String(e)
            } else {
                if (!Oe.test(l = String(e))) return v(s, l, n);
                s.s = l.charCodeAt(0) == 45 ? (l = l.slice(1), -1) : 1
            }(o = l.indexOf(".")) > -1 && (l = l.replace(".", "")), (u = l.search(/e/i)) > 0 ? (o < 0 && (o = u), o += +l.slice(u + 1), l = l.substring(0, u)) : o < 0 && (o = l.length)
        } else {
            if (I(r, 2, K.length, "Base"), r == 10 && oe) return s = new h(e), k(s, x + s.e + 1, T);
            if (l = String(e), n = typeof e == "number") {
                if (e * 0 != 0) return v(s, l, n, r);
                if (s.s = 1 / e < 0 ? (l = l.slice(1), -1) : 1, h.DEBUG && l.replace(/^0\.0*|\./, "").length > 15) throw Error(we + e)
            } else s.s = l.charCodeAt(0) === 45 ? (l = l.slice(1), -1) : 1;
            for (i = K.slice(0, r), o = u = 0, f = l.length; u < f; u++)
                if (i.indexOf(c = l.charAt(u)) < 0) {
                    if (c == ".") {
                        if (u > o) {
                            o = f;
                            continue
                        }
                    } else if (!t && (l == l.toUpperCase() && (l = l.toLowerCase()) || l == l.toLowerCase() && (l = l.toUpperCase()))) {
                        t = !0, u = -1, o = 0;
                        continue
                    }
                    return v(s, String(e), n, r)
                }
            n = !1, l = N(l, r, 10, s.s), (o = l.indexOf(".")) > -1 ? l = l.replace(".", "") : o = l.length
        }
        for (u = 0; l.charCodeAt(u) === 48; u++);
        for (f = l.length; l.charCodeAt(--f) === 48;);
        if (l = l.slice(u, ++f)) {
            if (f -= u, n && h.DEBUG && f > 15 && (e > he || e !== X(e))) throw Error(we + s.s * e);
            if ((o = o - u - 1) > H) s.c = s.e = null;
            else if (o < Q) s.c = [s.e = 0];
            else {
                if (s.e = o, s.c = [], u = (o + 1) % E, o < 0 && (u += E), u < f) {
                    for (u && s.c.push(+l.slice(0, u)), f -= E; u < f;) s.c.push(+l.slice(u, u += E));
                    u = E - (l = l.slice(u)).length
                } else u -= f;
                for (; u--; l += "0");
                s.c.push(+l)
            }
        } else s.c = [s.e = 0]
    }
    h.clone = me, h.ROUND_UP = 0, h.ROUND_DOWN = 1, h.ROUND_CEIL = 2, h.ROUND_FLOOR = 3, h.ROUND_HALF_UP = 4, h.ROUND_HALF_DOWN = 5, h.ROUND_HALF_EVEN = 6, h.ROUND_HALF_CEIL = 7, h.ROUND_HALF_FLOOR = 8, h.EUCLID = 9, h.config = h.set = function(e) {
        var r, i;
        if (e != null)
            if (typeof e == "object") {
                if (e.hasOwnProperty(r = "DECIMAL_PLACES") && (i = e[r], I(i, 0, P, r), x = i), e.hasOwnProperty(r = "ROUNDING_MODE") && (i = e[r], I(i, 0, 8, r), T = i), e.hasOwnProperty(r = "EXPONENTIAL_AT") && (i = e[r], i && i.pop ? (I(i[0], -P, 0, r), I(i[1], 0, P, r), U = i[0], L = i[1]) : (I(i, -P, P, r), U = -(L = i < 0 ? -i : i))), e.hasOwnProperty(r = "RANGE"))
                    if (i = e[r], i && i.pop) I(i[0], -P, -1, r), I(i[1], 1, P, r), Q = i[0], H = i[1];
                    else if (I(i, -P, P, r), i) Q = -(H = i < 0 ? -i : i);
                else throw Error(y + r + " cannot be zero: " + i);
                if (e.hasOwnProperty(r = "CRYPTO"))
                    if (i = e[r], i === !!i)
                        if (i)
                            if (typeof crypto < "u" && crypto && (crypto.getRandomValues || crypto.randomBytes)) Z = i;
                            else throw Z = !i, Error(y + "crypto unavailable");
                else Z = i;
                else throw Error(y + r + " not true or false: " + i);
                if (e.hasOwnProperty(r = "MODULO_MODE") && (i = e[r], I(i, 0, 9, r), b = i), e.hasOwnProperty(r = "POW_PRECISION") && (i = e[r], I(i, 0, P, r), Y = i), e.hasOwnProperty(r = "FORMAT"))
                    if (i = e[r], typeof i == "object") fe = i;
                    else throw Error(y + r + " not an object: " + i);
                if (e.hasOwnProperty(r = "ALPHABET"))
                    if (i = e[r], typeof i == "string" && !/^.?$|[+\-.\s]|(.).*\1/.test(i)) oe = i.slice(0, 10) == "0123456789", K = i;
                    else throw Error(y + r + " invalid: " + i)
            } else throw Error(y + "Object expected: " + e);
        return {
            DECIMAL_PLACES: x,
            ROUNDING_MODE: T,
            EXPONENTIAL_AT: [U, L],
            RANGE: [Q, H],
            CRYPTO: Z,
            MODULO_MODE: b,
            POW_PRECISION: Y,
            FORMAT: fe,
            ALPHABET: K
        }
    }, h.isBigNumber = function(e) {
        if (!e || e._isBigNumber !== !0) return !1;
        if (!h.DEBUG) return !0;
        var r, i, c = e.c,
            t = e.e,
            o = e.s;
        e: if ({}.toString.call(c) == "[object Array]") {
            if ((o === 1 || o === -1) && t >= -P && t <= P && t === X(t)) {
                if (c[0] === 0) {
                    if (t === 0 && c.length === 1) return !0;
                    break e
                }
                if (r = (t + 1) % E, r < 1 && (r += E), String(c[0]).length == r) {
                    for (r = 0; r < c.length; r++)
                        if (i = c[r], i < 0 || i >= $ || i !== X(i)) break e;
                    if (i !== 0) return !0
                }
            }
        } else
        if (c === null && t === null && (o === null || o === 1 || o === -1)) return !0;
        throw Error(y + "Invalid BigNumber: " + e)
    }, h.maximum = h.max = function() {
        return ge(arguments, p.lt)
    }, h.minimum = h.min = function() {
        return ge(arguments, p.gt)
    }, h.random = function() {
        var e = 9007199254740992,
            r = Math.random() * e & 2097151 ? function() {
                return X(Math.random() * e)
            } : function() {
                return (Math.random() * 1073741824 | 0) * 8388608 + (Math.random() * 8388608 | 0)
            };
        return function(i) {
            var c, t, o, u, n, f = 0,
                l = [],
                s = new h(M);
            if (i == null ? i = x : I(i, 0, P), u = ae(i / E), Z)
                if (crypto.getRandomValues) {
                    for (c = crypto.getRandomValues(new Uint32Array(u *= 2)); f < u;) n = c[f] * 131072 + (c[f + 1] >>> 11), n >= 9e15 ? (t = crypto.getRandomValues(new Uint32Array(2)), c[f] = t[0], c[f + 1] = t[1]) : (l.push(n % 1e14), f += 2);
                    f = u / 2
                } else if (crypto.randomBytes) {
                for (c = crypto.randomBytes(u *= 7); f < u;) n = (c[f] & 31) * 281474976710656 + c[f + 1] * 1099511627776 + c[f + 2] * 4294967296 + c[f + 3] * 16777216 + (c[f + 4] << 16) + (c[f + 5] << 8) + c[f + 6], n >= 9e15 ? crypto.randomBytes(7).copy(c, f) : (l.push(n % 1e14), f += 7);
                f = u / 7
            } else throw Z = !1, Error(y + "crypto unavailable");
            if (!Z)
                for (; f < u;) n = r(), n < 9e15 && (l[f++] = n % 1e14);
            for (u = l[--f], i %= E, u && i && (n = pe[E - i], l[f] = X(u / n) * n); l[f] === 0; l.pop(), f--);
            if (f < 0) l = [o = 0];
            else {
                for (o = -1; l[0] === 0; l.splice(0, 1), o -= E);
                for (f = 1, n = l[0]; n >= 10; n /= 10, f++);
                f < E && (o -= E - f)
            }
            return s.e = o, s.c = l, s
        }
    }(), h.sum = function() {
        for (var e = 1, r = arguments, i = new h(r[0]); e < r.length;) i = i.plus(r[e++]);
        return i
    }, N = function() {
        var e = "0123456789";

        function r(i, c, t, o) {
            for (var u, n = [0], f, l = 0, s = i.length; l < s;) {
                for (f = n.length; f--; n[f] *= c);
                for (n[0] += o.indexOf(i.charAt(l++)), u = 0; u < n.length; u++) n[u] > t - 1 && (n[u + 1] == null && (n[u + 1] = 0), n[u + 1] += n[u] / t | 0, n[u] %= t)
            }
            return n.reverse()
        }
        return function(i, c, t, o, u) {
            var n, f, l, s, a, w, d, A, B = i.indexOf("."),
                C = x,
                O = T;
            for (B >= 0 && (s = Y, Y = 0, i = i.replace(".", ""), A = new h(c), w = A.pow(i.length - B), Y = s, A.c = r(W(G(w.c), w.e, "0"), 10, t, e), A.e = A.c.length), d = r(i, c, t, u ? (n = K, e) : (n = e, K)), l = s = d.length; d[--s] == 0; d.pop());
            if (!d[0]) return n.charAt(0);
            if (B < 0 ? --l : (w.c = d, w.e = l, w.s = o, w = m(w, A, C, O, t), d = w.c, a = w.r, l = w.e), f = l + C + 1, B = d[f], s = t / 2, a = a || f < 0 || d[f + 1] != null, a = O < 4 ? (B != null || a) && (O == 0 || O == (w.s < 0 ? 3 : 2)) : B > s || B == s && (O == 4 || a || O == 6 && d[f - 1] & 1 || O == (w.s < 0 ? 8 : 7)), f < 1 || !d[0]) i = a ? W(n.charAt(1), -C, n.charAt(0)) : n.charAt(0);
            else {
                if (d.length = f, a)
                    for (--t; ++d[--f] > t;) d[f] = 0, f || (++l, d = [1].concat(d));
                for (s = d.length; !d[--s];);
                for (B = 0, i = ""; B <= s; i += n.charAt(d[B++]));
                i = W(i, l, n.charAt(0))
            }
            return i
        }
    }(), m = function() {
        function e(c, t, o) {
            var u, n, f, l, s = 0,
                a = c.length,
                w = t % J,
                d = t / J | 0;
            for (c = c.slice(); a--;) f = c[a] % J, l = c[a] / J | 0, u = d * f + l * w, n = w * f + u % J * J + s, s = (n / o | 0) + (u / J | 0) + d * l, c[a] = n % o;
            return s && (c = [s].concat(c)), c
        }

        function r(c, t, o, u) {
            var n, f;
            if (o != u) f = o > u ? 1 : -1;
            else
                for (n = f = 0; n < o; n++)
                    if (c[n] != t[n]) {
                        f = c[n] > t[n] ? 1 : -1;
                        break
                    } return f
        }

        function i(c, t, o, u) {
            for (var n = 0; o--;) c[o] -= n, n = c[o] < t[o] ? 1 : 0, c[o] = n * u + c[o] - t[o];
            for (; !c[0] && c.length > 1; c.splice(0, 1));
        }
        return function(c, t, o, u, n) {
            var f, l, s, a, w, d, A, B, C, O, _, R, re, le, ue, z, ee, q = c.s == t.s ? 1 : -1,
                D = c.c,
                S = t.c;
            if (!D || !D[0] || !S || !S[0]) return new h(!c.s || !t.s || (D ? S && D[0] == S[0] : !S) ? NaN : D && D[0] == 0 || !S ? q * 0 : q / 0);
            for (B = new h(q), C = B.c = [], l = c.e - t.e, q = o + l + 1, n || (n = $, l = F(c.e / E) - F(t.e / E), q = q / E | 0), s = 0; S[s] == (D[s] || 0); s++);
            if (S[s] > (D[s] || 0) && l--, q < 0) C.push(1), a = !0;
            else {
                for (le = D.length, z = S.length, s = 0, q += 2, w = X(n / (S[0] + 1)), w > 1 && (S = e(S, w, n), D = e(D, w, n), z = S.length, le = D.length), re = z, O = D.slice(0, z), _ = O.length; _ < z; O[_++] = 0);
                ee = S.slice(), ee = [0].concat(ee), ue = S[0], S[1] >= n / 2 && ue++;
                do {
                    if (w = 0, f = r(S, O, z, _), f < 0) {
                        if (R = O[0], z != _ && (R = R * n + (O[1] || 0)), w = X(R / ue), w > 1)
                            for (w >= n && (w = n - 1), d = e(S, w, n), A = d.length, _ = O.length; r(d, O, A, _) == 1;) w--, i(d, z < A ? ee : S, A, n), A = d.length, f = 1;
                        else w == 0 && (f = w = 1), d = S.slice(), A = d.length;
                        if (A < _ && (d = [0].concat(d)), i(O, d, _, n), _ = O.length, f == -1)
                            for (; r(S, O, z, _) < 1;) w++, i(O, z < _ ? ee : S, _, n), _ = O.length
                    } else f === 0 && (w++, O = [0]);
                    C[s++] = w, O[0] ? O[_++] = D[re] || 0 : (O = [D[re]], _ = 1)
                } while ((re++ < le || O[0] != null) && q--);
                a = O[0] != null, C[0] || C.splice(0, 1)
            }
            if (n == $) {
                for (s = 1, q = C[0]; q >= 10; q /= 10, s++);
                k(B, o + (B.e = s + l * E - 1) + 1, u, a)
            } else B.e = l, B.r = +a;
            return B
        }
    }();

    function se(e, r, i, c) {
        var t, o, u, n, f;
        if (i == null ? i = T : I(i, 0, 8), !e.c) return e.toString();
        if (t = e.c[0], u = e.e, r == null) f = G(e.c), f = c == 1 || c == 2 && (u <= U || u >= L) ? ne(f, u) : W(f, u, "0");
        else if (e = k(new h(e), r, i), o = e.e, f = G(e.c), n = f.length, c == 1 || c == 2 && (r <= o || o <= U)) {
            for (; n < r; f += "0", n++);
            f = ne(f, o)
        } else if (r -= u, f = W(f, o, "0"), o + 1 > n) {
            if (--r > 0)
                for (f += "."; r--; f += "0");
        } else if (r += o - n, r > 0)
            for (o + 1 == n && (f += "."); r--; f += "0");
        return e.s < 0 && t ? "-" + f : f
    }

    function ge(e, r) {
        for (var i, c = 1, t = new h(e[0]); c < e.length; c++)
            if (i = new h(e[c]), i.s) r.call(t, i) && (t = i);
            else {
                t = i;
                break
            }
        return t
    }

    function ce(e, r, i) {
        for (var c = 1, t = r.length; !r[--t]; r.pop());
        for (t = r[0]; t >= 10; t /= 10, c++);
        return (i = c + i * E - 1) > H ? e.c = e.e = null : i < Q ? e.c = [e.e = 0] : (e.e = i, e.c = r), e
    }
    v = function() {
        var e = /^(-?)0([xbo])(?=\w[\w.]*$)/i,
            r = /^([^.]+)\.$/,
            i = /^\.([^.]+)$/,
            c = /^-?(Infinity|NaN)$/,
            t = /^\s*\+(?=[\w.])|^\s+|\s+$/g;
        return function(o, u, n, f) {
            var l, s = n ? u : u.replace(t, "");
            if (c.test(s)) o.s = isNaN(s) ? null : s < 0 ? -1 : 1;
            else {
                if (!n && (s = s.replace(e, function(a, w, d) {
                        return l = (d = d.toLowerCase()) == "x" ? 16 : d == "b" ? 2 : 8, !f || f == l ? w : a
                    }), f && (l = f, s = s.replace(r, "$1").replace(i, "0.$1")), u != s)) return new h(s, l);
                if (h.DEBUG) throw Error(y + "Not a" + (f ? " base " + f : "") + " number: " + u);
                o.s = null
            }
            o.c = o.e = null
        }
    }();

    function k(e, r, i, c) {
        var t, o, u, n, f, l, s, a = e.c,
            w = pe;
        if (a) {
            e: {
                for (t = 1, n = a[0]; n >= 10; n /= 10, t++);
                if (o = r - t, o < 0) o += E,
                u = r,
                f = a[l = 0],
                s = f / w[t - u - 1] % 10 | 0;
                else if (l = ae((o + 1) / E), l >= a.length)
                    if (c) {
                        for (; a.length <= l; a.push(0));
                        f = s = 0, t = 1, o %= E, u = o - E + 1
                    } else break e;
                else {
                    for (f = n = a[l], t = 1; n >= 10; n /= 10, t++);
                    o %= E, u = o - E + t, s = u < 0 ? 0 : f / w[t - u - 1] % 10 | 0
                }
                if (c = c || r < 0 || a[l + 1] != null || (u < 0 ? f : f % w[t - u - 1]), c = i < 4 ? (s || c) && (i == 0 || i == (e.s < 0 ? 3 : 2)) : s > 5 || s == 5 && (i == 4 || c || i == 6 && (o > 0 ? u > 0 ? f / w[t - u] : 0 : a[l - 1]) % 10 & 1 || i == (e.s < 0 ? 8 : 7)), r < 1 || !a[0]) return a.length = 0, c ? (r -= e.e + 1, a[0] = w[(E - r % E) % E], e.e = -r || 0) : a[0] = e.e = 0, e;
                if (o == 0 ? (a.length = l, n = 1, l--) : (a.length = l + 1, n = w[E - o], a[l] = u > 0 ? X(f / w[t - u] % w[u]) * n : 0), c)
                    for (;;)
                        if (l == 0) {
                            for (o = 1, u = a[0]; u >= 10; u /= 10, o++);
                            for (u = a[0] += n, n = 1; u >= 10; u /= 10, n++);
                            o != n && (e.e++, a[0] == $ && (a[0] = 1));
                            break
                        } else {
                            if (a[l] += n, a[l] != $) break;
                            a[l--] = 0, n = 1
                        }
                for (o = a.length; a[--o] === 0; a.pop());
            }
            e.e > H ? e.c = e.e = null : e.e < Q && (e.c = [e.e = 0])
        }
        return e
    }

    function V(e) {
        var r, i = e.e;
        return i === null ? e.toString() : (r = G(e.c), r = i <= U || i >= L ? ne(r, i) : W(r, i, "0"), e.s < 0 ? "-" + r : r)
    }
    return p.absoluteValue = p.abs = function() {
        var e = new h(this);
        return e.s < 0 && (e.s = 1), e
    }, p.comparedTo = function(e, r) {
        return j(this, new h(e, r))
    }, p.decimalPlaces = p.dp = function(e, r) {
        var i, c, t, o = this;
        if (e != null) return I(e, 0, P), r == null ? r = T : I(r, 0, 8), k(new h(o), e + o.e + 1, r);
        if (!(i = o.c)) return null;
        if (c = ((t = i.length - 1) - F(this.e / E)) * E, t = i[t])
            for (; t % 10 == 0; t /= 10, c--);
        return c < 0 && (c = 0), c
    }, p.dividedBy = p.div = function(e, r) {
        return m(this, new h(e, r), x, T)
    }, p.dividedToIntegerBy = p.idiv = function(e, r) {
        return m(this, new h(e, r), 0, 1)
    }, p.exponentiatedBy = p.pow = function(e, r) {
        var i, c, t, o, u, n, f, l, s, a = this;
        if (e = new h(e), e.c && !e.isInteger()) throw Error(y + "Exponent not an integer: " + V(e));
        if (r != null && (r = new h(r)), n = e.e > 14, !a.c || !a.c[0] || a.c[0] == 1 && !a.e && a.c.length == 1 || !e.c || !e.c[0]) return s = new h(Math.pow(+V(a), n ? 2 - ie(e) : +V(e))), r ? s.mod(r) : s;
        if (f = e.s < 0, r) {
            if (r.c ? !r.c[0] : !r.s) return new h(NaN);
            c = !f && a.isInteger() && r.isInteger(), c && (a = a.mod(r))
        } else {
            if (e.e > 9 && (a.e > 0 || a.e < -1 || (a.e == 0 ? a.c[0] > 1 || n && a.c[1] >= 24e7 : a.c[0] < 8e13 || n && a.c[0] <= 9999975e7))) return o = a.s < 0 && ie(e) ? -0 : 0, a.e > -1 && (o = 1 / o), new h(f ? 1 / o : o);
            Y && (o = ae(Y / E + 2))
        }
        for (n ? (i = new h(.5), f && (e.s = 1), l = ie(e)) : (t = Math.abs(+V(e)), l = t % 2), s = new h(M);;) {
            if (l) {
                if (s = s.times(a), !s.c) break;
                o ? s.c.length > o && (s.c.length = o) : c && (s = s.mod(r))
            }
            if (t) {
                if (t = X(t / 2), t === 0) break;
                l = t % 2
            } else if (e = e.times(i), k(e, e.e + 1, 1), e.e > 14) l = ie(e);
            else {
                if (t = +V(e), t === 0) break;
                l = t % 2
            }
            a = a.times(a), o ? a.c && a.c.length > o && (a.c.length = o) : c && (a = a.mod(r))
        }
        return c ? s : (f && (s = M.div(s)), r ? s.mod(r) : o ? k(s, Y, T, u) : s)
    }, p.integerValue = function(e) {
        var r = new h(this);
        return e == null ? e = T : I(e, 0, 8), k(r, r.e + 1, e)
    }, p.isEqualTo = p.eq = function(e, r) {
        return j(this, new h(e, r)) === 0
    }, p.isFinite = function() {
        return !!this.c
    }, p.isGreaterThan = p.gt = function(e, r) {
        return j(this, new h(e, r)) > 0
    }, p.isGreaterThanOrEqualTo = p.gte = function(e, r) {
        return (r = j(this, new h(e, r))) === 1 || r === 0
    }, p.isInteger = function() {
        return !!this.c && F(this.e / E) > this.c.length - 2
    }, p.isLessThan = p.lt = function(e, r) {
        return j(this, new h(e, r)) < 0
    }, p.isLessThanOrEqualTo = p.lte = function(e, r) {
        return (r = j(this, new h(e, r))) === -1 || r === 0
    }, p.isNaN = function() {
        return !this.s
    }, p.isNegative = function() {
        return this.s < 0
    }, p.isPositive = function() {
        return this.s > 0
    }, p.isZero = function() {
        return !!this.c && this.c[0] == 0
    }, p.minus = function(e, r) {
        var i, c, t, o, u = this,
            n = u.s;
        if (e = new h(e, r), r = e.s, !n || !r) return new h(NaN);
        if (n != r) return e.s = -r, u.plus(e);
        var f = u.e / E,
            l = e.e / E,
            s = u.c,
            a = e.c;
        if (!f || !l) {
            if (!s || !a) return s ? (e.s = -r, e) : new h(a ? u : NaN);
            if (!s[0] || !a[0]) return a[0] ? (e.s = -r, e) : new h(s[0] ? u : T == 3 ? -0 : 0)
        }
        if (f = F(f), l = F(l), s = s.slice(), n = f - l) {
            for ((o = n < 0) ? (n = -n, t = s) : (l = f, t = a), t.reverse(), r = n; r--; t.push(0));
            t.reverse()
        } else
            for (c = (o = (n = s.length) < (r = a.length)) ? n : r, n = r = 0; r < c; r++)
                if (s[r] != a[r]) {
                    o = s[r] < a[r];
                    break
                } if (o && (t = s, s = a, a = t, e.s = -e.s), r = (c = a.length) - (i = s.length), r > 0)
            for (; r--; s[i++] = 0);
        for (r = $ - 1; c > n;) {
            if (s[--c] < a[c]) {
                for (i = c; i && !s[--i]; s[i] = r);
                --s[i], s[c] += $
            }
            s[c] -= a[c]
        }
        for (; s[0] == 0; s.splice(0, 1), --l);
        return s[0] ? ce(e, s, l) : (e.s = T == 3 ? -1 : 1, e.c = [e.e = 0], e)
    }, p.modulo = p.mod = function(e, r) {
        var i, c, t = this;
        return e = new h(e, r), !t.c || !e.s || e.c && !e.c[0] ? new h(NaN) : !e.c || t.c && !t.c[0] ? new h(t) : (b == 9 ? (c = e.s, e.s = 1, i = m(t, e, 0, 3), e.s = c, i.s *= c) : i = m(t, e, 0, b), e = t.minus(i.times(e)), !e.c[0] && b == 1 && (e.s = t.s), e)
    }, p.multipliedBy = p.times = function(e, r) {
        var i, c, t, o, u, n, f, l, s, a, w, d, A, B, C, O = this,
            _ = O.c,
            R = (e = new h(e, r)).c;
        if (!_ || !R || !_[0] || !R[0]) return !O.s || !e.s || _ && !_[0] && !R || R && !R[0] && !_ ? e.c = e.e = e.s = null : (e.s *= O.s, !_ || !R ? e.c = e.e = null : (e.c = [0], e.e = 0)), e;
        for (c = F(O.e / E) + F(e.e / E), e.s *= O.s, f = _.length, a = R.length, f < a && (A = _, _ = R, R = A, t = f, f = a, a = t), t = f + a, A = []; t--; A.push(0));
        for (B = $, C = J, t = a; --t >= 0;) {
            for (i = 0, w = R[t] % C, d = R[t] / C | 0, u = f, o = t + u; o > t;) l = _[--u] % C, s = _[u] / C | 0, n = d * l + s * w, l = w * l + n % C * C + A[o] + i, i = (l / B | 0) + (n / C | 0) + d * s, A[o--] = l % B;
            A[o] = i
        }
        return i ? ++c : A.splice(0, 1), ce(e, A, c)
    }, p.negated = function() {
        var e = new h(this);
        return e.s = -e.s || null, e
    }, p.plus = function(e, r) {
        var i, c = this,
            t = c.s;
        if (e = new h(e, r), r = e.s, !t || !r) return new h(NaN);
        if (t != r) return e.s = -r, c.minus(e);
        var o = c.e / E,
            u = e.e / E,
            n = c.c,
            f = e.c;
        if (!o || !u) {
            if (!n || !f) return new h(t / 0);
            if (!n[0] || !f[0]) return f[0] ? e : new h(n[0] ? c : t * 0)
        }
        if (o = F(o), u = F(u), n = n.slice(), t = o - u) {
            for (t > 0 ? (u = o, i = f) : (t = -t, i = n), i.reverse(); t--; i.push(0));
            i.reverse()
        }
        for (t = n.length, r = f.length, t - r < 0 && (i = f, f = n, n = i, r = t), t = 0; r;) t = (n[--r] = n[r] + f[r] + t) / $ | 0, n[r] = $ === n[r] ? 0 : n[r] % $;
        return t && (n = [t].concat(n), ++u), ce(e, n, u)
    }, p.precision = p.sd = function(e, r) {
        var i, c, t, o = this;
        if (e != null && e !== !!e) return I(e, 1, P), r == null ? r = T : I(r, 0, 8), k(new h(o), e, r);
        if (!(i = o.c)) return null;
        if (t = i.length - 1, c = t * E + 1, t = i[t]) {
            for (; t % 10 == 0; t /= 10, c--);
            for (t = i[0]; t >= 10; t /= 10, c++);
        }
        return e && o.e + 1 > c && (c = o.e + 1), c
    }, p.shiftedBy = function(e) {
        return I(e, -he, he), this.times("1e" + e)
    }, p.squareRoot = p.sqrt = function() {
        var e, r, i, c, t, o = this,
            u = o.c,
            n = o.s,
            f = o.e,
            l = x + 4,
            s = new h("0.5");
        if (n !== 1 || !u || !u[0]) return new h(!n || n < 0 && (!u || u[0]) ? NaN : u ? o : 1 / 0);
        if (n = Math.sqrt(+V(o)), n == 0 || n == 1 / 0 ? (r = G(u), (r.length + f) % 2 == 0 && (r += "0"), n = Math.sqrt(+r), f = F((f + 1) / 2) - (f < 0 || f % 2), n == 1 / 0 ? r = "5e" + f : (r = n.toExponential(), r = r.slice(0, r.indexOf("e") + 1) + f), i = new h(r)) : i = new h(n + ""), i.c[0]) {
            for (f = i.e, n = f + l, n < 3 && (n = 0);;)
                if (t = i, i = s.times(t.plus(m(o, t, l, 1))), G(t.c).slice(0, n) === (r = G(i.c)).slice(0, n))
                    if (i.e < f && --n, r = r.slice(n - 3, n + 1), r == "9999" || !c && r == "4999") {
                        if (!c && (k(t, t.e + x + 2, 0), t.times(t).eq(o))) {
                            i = t;
                            break
                        }
                        l += 4, n += 4, c = 1
                    } else {
                        (!+r || !+r.slice(1) && r.charAt(0) == "5") && (k(i, i.e + x + 2, 1), e = !i.times(i).eq(o));
                        break
                    }
        }
        return k(i, i.e + x + 1, T, e)
    }, p.toExponential = function(e, r) {
        return e != null && (I(e, 0, P), e++), se(this, e, r, 1)
    }, p.toFixed = function(e, r) {
        return e != null && (I(e, 0, P), e = e + this.e + 1), se(this, e, r)
    }, p.toFormat = function(e, r, i) {
        var c, t = this;
        if (i == null) e != null && r && typeof r == "object" ? (i = r, r = null) : e && typeof e == "object" ? (i = e, e = r = null) : i = fe;
        else if (typeof i != "object") throw Error(y + "Argument not an object: " + i);
        if (c = t.toFixed(e, r), t.c) {
            var o, u = c.split("."),
                n = +i.groupSize,
                f = +i.secondaryGroupSize,
                l = i.groupSeparator || "",
                s = u[0],
                a = u[1],
                w = t.s < 0,
                d = w ? s.slice(1) : s,
                A = d.length;
            if (f && (o = n, n = f, f = o, A -= o), n > 0 && A > 0) {
                for (o = A % n || n, s = d.substr(0, o); o < A; o += n) s += l + d.substr(o, n);
                f > 0 && (s += l + d.slice(o)), w && (s = "-" + s)
            }
            c = a ? s + (i.decimalSeparator || "") + ((f = +i.fractionGroupSize) ? a.replace(new RegExp("\\d{" + f + "}\\B", "g"), "$&" + (i.fractionGroupSeparator || "")) : a) : s
        }
        return (i.prefix || "") + c + (i.suffix || "")
    }, p.toFraction = function(e) {
        var r, i, c, t, o, u, n, f, l, s, a, w, d = this,
            A = d.c;
        if (e != null && (n = new h(e), !n.isInteger() && (n.c || n.s !== 1) || n.lt(M))) throw Error(y + "Argument " + (n.isInteger() ? "out of range: " : "not an integer: ") + V(n));
        if (!A) return new h(d);
        for (r = new h(M), l = i = new h(M), c = f = new h(M), w = G(A), o = r.e = w.length - d.e - 1, r.c[0] = pe[(u = o % E) < 0 ? E + u : u], e = !e || n.comparedTo(r) > 0 ? o > 0 ? r : l : n, u = H, H = 1 / 0, n = new h(w), f.c[0] = 0; s = m(n, r, 0, 1), t = i.plus(s.times(c)), t.comparedTo(e) != 1;) i = c, c = t, l = f.plus(s.times(t = l)), f = t, r = n.minus(s.times(t = r)), n = t;
        return t = m(e.minus(i), c, 0, 1), f = f.plus(t.times(l)), i = i.plus(t.times(c)), f.s = l.s = d.s, o = o * 2, a = m(l, c, o, T).minus(d).abs().comparedTo(m(f, i, o, T).minus(d).abs()) < 1 ? [l, c] : [f, i], H = u, a
    }, p.toNumber = function() {
        return +V(this)
    }, p.toPrecision = function(e, r) {
        return e != null && I(e, 1, P), se(this, e, r, 2)
    }, p.toString = function(e) {
        var r, i = this,
            c = i.s,
            t = i.e;
        return t === null ? c ? (r = "Infinity", c < 0 && (r = "-" + r)) : r = "NaN" : (e == null ? r = t <= U || t >= L ? ne(G(i.c), t) : W(G(i.c), t, "0") : e === 10 && oe ? (i = k(new h(i), x + t + 1, T), r = W(G(i.c), i.e, "0")) : (I(e, 2, K.length, "Base"), r = N(W(G(i.c), t, "0"), 10, e, c, !0)), c < 0 && i.c[0] && (r = "-" + r)), r
    }, p.valueOf = p.toJSON = function() {
        return V(this)
    }, p._isBigNumber = !0, p[Symbol.toStringTag] = "BigNumber", p[Symbol.for("nodejs.util.inspect.custom")] = p.valueOf, g != null && h.set(g), h
}

function F(g) {
    var m = g | 0;
    return g > 0 || g === m ? m : m - 1
}

function G(g) {
    for (var m, N, v = 1, p = g.length, M = g[0] + ""; v < p;) {
        for (m = g[v++] + "", N = E - m.length; N--; m = "0" + m);
        M += m
    }
    for (p = M.length; M.charCodeAt(--p) === 48;);
    return M.slice(0, p + 1 || 1)
}

function j(g, m) {
    var N, v, p = g.c,
        M = m.c,
        x = g.s,
        T = m.s,
        U = g.e,
        L = m.e;
    if (!x || !T) return null;
    if (N = p && !p[0], v = M && !M[0], N || v) return N ? v ? 0 : -T : x;
    if (x != T) return x;
    if (N = x < 0, v = U == L, !p || !M) return v ? 0 : !p ^ N ? 1 : -1;
    if (!v) return U > L ^ N ? 1 : -1;
    for (T = (U = p.length) < (L = M.length) ? U : L, x = 0; x < T; x++)
        if (p[x] != M[x]) return p[x] > M[x] ^ N ? 1 : -1;
    return U == L ? 0 : U > L ^ N ? 1 : -1
}

function I(g, m, N, v) {
    if (g < m || g > N || g !== X(g)) throw Error(y + (v || "Argument") + (typeof g == "number" ? g < m || g > N ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(g))
}

function ie(g) {
    var m = g.c.length - 1;
    return F(g.e / E) == m && g.c[m] % 2 != 0
}

function ne(g, m) {
    return (g.length > 1 ? g.charAt(0) + "." + g.slice(1) : g) + (m < 0 ? "e" : "e+") + m
}

function W(g, m, N) {
    var v, p;
    if (m < 0) {
        for (p = N + "."; ++m; p += N);
        g = p + g
    } else if (v = g.length, ++m > v) {
        for (p = N, m -= v; --m; p += N);
        g += p
    } else m < v && (g = g.slice(0, m) + "." + g.slice(m));
    return g
}
var Ae = me();
const ve = () => Ne(() =>
    import ("./index.28d31fd3.js").then(function(g) {
        return g.i
    }), []).then(g => g.default);
async function te() {
    const m = await (await ve())();
    if (m) return m;
    throw new Error("No MetaMask Extension!")
}
async function de() {
    const g = await te();
    return await g.request({
        method: "eth_requestAccounts"
    }), g.request({
        method: "eth_accounts"
    })
}
const _e = {
    ETH: {
        chainId: "0x1",
        rpcUrls: ["https://mainnet.infura.io/v3/"],
        chainName: "Ethereum Mainnet",
        nativeCurrency: {
            name: "Ether",
            decimals: 18,
            symbol: "ETH"
        },
        blockExplorerUrls: ["https://etherscan.io"]
    },
    BNB: {
        chainId: "0x38",
        rpcUrls: ["https://bsc-dataseed1.binance.org"],
        chainName: "Smart Chain",
        nativeCurrency: {
            name: "Binance Chain Native Token",
            symbol: "BNB",
            decimals: 18
        },
        blockExplorerUrls: ["https://bscscan.com"]
    },
    MATIC: {
        chainId: "0x89",
        rpcUrls: ["https://polygon-rpc.com/", "https://rpc-mainnet.matic.network"],
        chainName: "Polygon Mainnet",
        nativeCurrency: {
            name: "MATIC",
            symbol: "MATIC",
            decimals: 18
        },
        blockExplorerUrls: ["https://polygonscan.com/"]
    }
};
async function Ee(g = "ETH") {
    const m = await te(),
        N = _e[g];
    if (N.chainId !== m.chainId) try {
        await m.request({
            method: "wallet_switchEthereumChain",
            params: [{
                chainId: N.chainId
            }]
        })
    } catch (v) {
        if (v.code === 4902) try {
            return await m.request({
                method: "wallet_addEthereumChain",
                params: [N]
            }), Ee(g)
        } catch (p) {
            throw new Error(p.message)
        } else throw new Error(v.message)
    }
    return N
}
async function Ie(g, m, N = "ETH") {
    const v = await te(),
        p = await de(),
        M = await Ee(N);
    try {
        return await v.request({
            method: "eth_sendTransaction",
            params: [{
                to: g,
                value: new Ae(m).multipliedBy("1000000000000000000").toString(16),
                from: p[0],
                chainId: M.chainId
            }]
        })
    } catch (x) {
        throw new Error(x.message)
    }
}
async function Te(g) {
    const m = await te(),
        [N] = await de(),
        v = await m.request({
            method: "personal_sign",
            params: [g, N]
        });
    return {
        publicAddress: N,
        signature: v
    }
}
export {
    Te as s, Ie as t
};
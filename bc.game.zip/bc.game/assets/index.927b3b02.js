import {
    u as d,
    a as e,
    D as h,
    dx as v,
    j as m,
    a5 as S,
    du as A,
    r as g,
    dy as E,
    dD as N,
    dZ as w,
    eO as _,
    dE as k,
    d as f,
    d_ as G,
    s as y,
    y as D,
    n as V,
    o as C,
    a2 as I,
    bo as x,
    S as B,
    am as p
} from "./index.28e31dff.js";
import {
    s as u
} from "./index.dd8128e8.js";
import {
    S as $
} from "./SlotsILayout.a8936350.js";
import {
    u as P
} from "./useLocalStore.f739c306.js";
const F = () => {
        const t = d();
        return e(h, {
            title: t("common.game_intro"),
            children: e(v, {
                children: m("div", {
                    className: "item",
                    children: [e("h2", {
                        children: "What is Egyptian Adventure?"
                    }), e("div", {
                        className: "help-content",
                        children: e("p", {
                            children: "Egyptian Adventure is a slots game and of course is provably fair like all our original games."
                        })
                    }), e("h2", {
                        children: "How to play Egyptian Adventure?"
                    }), m("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "Click spin button in the bottom right corner to start the game. Click \u201CAUTO\u201D button to activate auto menu."
                        }), m("p", {
                            children: [" ", "Click sound button in the bottom left corner to switch sound. Click menu button upper the sound button to view rules in more details."]
                        })]
                    }), e("h2", {
                        children: "What is the return rate of Egyptian Adventure?"
                    }), e("div", {
                        className: "help-content",
                        children: e("p", {
                            children: "RTP is 97.51%."
                        })
                    })]
                })
            })
        })
    },
    j = S.memo(() => {
        const t = d(),
            n = A(),
            a = g.exports.useRef(null);
        g.exports.useEffect(() => {
            const i = a.current;
            if (i) {
                const o = c => {
                    const s = U(c);
                    n.handleBet(s.betAmount, s)
                };
                return i.on("betSuccess", o), () => {
                    i.off("betSuccess", o)
                }
            }
        }, []);
        const l = [{
            title: t("common.game_intro"),
            node: e(F, {})
        }, {
            title: t("common.fairness"),
            node: "/egyptian_help/fairness"
        }, {
            title: t("common.max_profits"),
            node: e(E, {
                game: n,
                title: t("common.max_profits")
            })
        }];
        return e($, {
            src: n.gameUrl,
            ref: a,
            actions: [e(N, {}), e(w, {}), e(_, {}), e(k, {
                list: l
            })],
            banner: n.gameInfo.cover,
            tabs: [{
                label: t("common.all_bet"),
                value: u.AllBet
            }, {
                label: t("common.my_bet"),
                value: u.MyBet
            }]
        })
    });

function U(t) {
    const {
        betAmount: n,
        betId: a,
        betTime: l,
        currencyName: i,
        nonce: o,
        odds: c,
        winAmount: s,
        gameValue: r
    } = t;
    return {
        userId: f.userId,
        nickName: f.name,
        betAmount: n,
        betId: a,
        betTime: l,
        currencyName: i,
        nonce: o,
        odds: c,
        winAmount: s,
        profitAmount: s - n,
        gameValue: r
    }
}
class H extends G {
    constructor() {
        super({
            name: "SlotsEgyptianAdventure",
            namespace: "/g/ea",
            fairLink: "/egyptian_help/fairness",
            validateLink: "/egyptian_help/validate"
        }, j), this.gameUrl = y.isDev ? "http://sea.bc.com/" : `//sea.${y.domain}`
    }
    betValue() {
        return new Uint8Array
    }
    async handleBet(n, a) {
        this.addMyBet(a), this.emit("betEnd", {
            amount: new D(a.betAmount),
            odds: a.odds,
            currencyName: a.currencyName
        })
    }
}
const b = new H;
var J = b;
window.sea = b;
const R = (t, n, a) => {
        V(`/egyptian_help/validate/${t}/${n}/${a}`)
    },
    L = u.withSingleDetail({
        onValidate: R
    });
var K = L;
const M = ({
    bodyLock: t
}) => {
    const n = d();
    return e(h, {
        title: n("common.fairness"),
        children: e(v, {
            bodyLock: t,
            children: m("div", {
                className: "item",
                children: [e("h2", {
                    children: "Fairness Verification"
                }), e("p", {
                    children: "Note: For more details, please go to My Bet -> Choose Game ID -> Verify."
                }), e("p", {
                    children: "Please check the following documents for verification method and comparison table"
                }), e("p", {
                    children: e("a", {
                        className: "cl-primary",
                        href: "https://bcgame-project.github.io/verify/egyptianAdventure.pdf",
                        target: "_blank",
                        children: "EgyptianAdventure.pdf"
                    })
                })]
            })
        })
    })
};
var Q = M;
const T = C(function() {
    const n = I(),
        a = x(n),
        l = d(),
        i = P(() => ({
            serverSeed: a[0],
            clientSeed: a[1],
            nonce: parseInt(a[2]) || 0
        })),
        {
            serverSeed: o,
            clientSeed: c,
            nonce: s
        } = i;
    return e(h, {
        title: l("common.fairness"),
        children: m(B, {
            className: W,
            children: [e("h2", {
                children: "Input"
            }), e(p, {
                label: "Server Seed",
                value: o,
                onChange: r => i.serverSeed = r
            }), e(p, {
                label: "Client Seed",
                value: c,
                onChange: r => i.clientSeed = r
            }), e(p, {
                label: "Nonce",
                value: s,
                onChange: r => i.nonce = Number(r) || 0
            }), e("p", {
                children: e("br", {})
            }), e("p", {
                children: "Please check the following documents for verification method and comparison table"
            }), e("p", {
                children: e("a", {
                    className: "cl-primary",
                    href: "https://bcgame-project.github.io/verify/egyptianAdventure.pdf",
                    target: "_blank",
                    children: "EgyptianAdventure.pdf"
                })
            })]
        })
    })
});
var X = T;
const W = "vybof6r";
export {
    K as Detail, Q as Fairness, J as Game, X as Validate
};
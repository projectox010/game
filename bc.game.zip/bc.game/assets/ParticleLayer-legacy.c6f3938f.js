! function() {
    var e = document.createElement("style");
    e.innerHTML = ".p1wqymdo{position:absolute;top:0;left:0;right:0;z-index:1;overflow:hidden}\n", document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js", "./usePixiGsap-legacy.c051c439.js"], (function(e) {
        "use strict";
        var t, i, a, n;
        return {
            setters: [function(e) {
                t = e.a5, i = e.a
            }, function(e) {
                a = e.P, n = e.a
            }],
            execute: function() {
                var c = {
                    alpha: {
                        list: [{
                            value: 0,
                            time: 0
                        }, {
                            value: 1,
                            time: .5
                        }, {
                            value: 0,
                            time: 1
                        }],
                        isStepped: !1
                    },
                    scale: {
                        list: [{
                            value: .05,
                            time: 0
                        }, {
                            value: .3,
                            time: 1
                        }],
                        isStepped: !1,
                        minimumScaleMultiplier: 2
                    },
                    color: {
                        start: "#3c5653",
                        end: "#6dcaa4"
                    },
                    speed: {
                        start: 10,
                        end: 20,
                        minimumSpeedMultiplier: 1.3
                    },
                    acceleration: {
                        x: 0,
                        y: 0
                    },
                    maxSpeed: 0,
                    startRotation: {
                        min: 0,
                        max: 260
                    },
                    noRotation: !1,
                    rotationSpeed: {
                        min: 0,
                        max: 0
                    },
                    lifetime: {
                        min: 8,
                        max: 12
                    },
                    blendMode: "normal",
                    frequency: .5,
                    emitterLifetime: -1,
                    maxParticles: 500,
                    pos: {
                        x: 0,
                        y: 0
                    },
                    addAtBack: !1,
                    spawnType: "rect",
                    spawnRect: {
                        x: 0,
                        y: 0,
                        w: 464,
                        h: 300
                    },
                    emit: !0,
                    autoUpdate: !0
                };
                e("P", t.memo((function({
                    config: e = {}
                }) {
                    const t = Object.assign(JSON.parse(JSON.stringify(c)), e);
                    return i("div", {
                        className: `${s} particle-layer`,
                        children: i(a, {
                            width: t.spawnRect.w,
                            height: t.spawnRect.h,
                            fps: 30,
                            children: i(n, {
                                textures: "/assets/circle.f7cb4038.png",
                                config: t
                            })
                        })
                    })
                })));
                const s = "p1wqymdo"
            }
        }
    }))
}();
! function() {
    var t = document.createElement("style");
    t.innerHTML = ".sjrjgcq{position:relative;width:13.125rem}.sjrjgcq .bg{width:13.125rem;position:relative}@-webkit-keyframes ani-bgposition-sjrjgcq{0%{background-position:center 0}to{background-position:center -2250rem}}@keyframes ani-bgposition-sjrjgcq{0%{background-position:center 0}to{background-position:center -2250rem}}.sjrjgcq .bubble{position:absolute;width:5.625rem;height:5.625rem;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGIAAAC2BAMAAADQJEUEAAAAHlBMVEUAAAD/k37/k3//k37/lID/moT/k33/k37/k37/kn3o8PUlAAAACXRSTlMAzVh5NRPxpJAL3w5XAAAA/UlEQVRo3u3aMUsDQRDF8WfOGEsFRdIlhcV1KbSwOwko6YKgYKd219lY2B0WActTuPD/tulT5UESUrxfP+zswg7D7Moyfp/IUsBSllegkqMEJnZE42fl79w/3YhNTG/kOYVGljv4l2UIrSw1dLteo4Q/u2o18jxdKyIiIiIiIiLWzOXpL9qRLEf2+KKEzsvrF6j8CDsrWQbwIc/4qlLEgZv+yFPApSwze27/DdgzTOxC08nyYJe/Xk0jz3GmnhGxZ8X5rSz9Ie3cfS/j0204eZPjxI4YAGdeia6hkuWeC5meFQfq0W3te3bn8LKHPxt+xAwYuberlWfB19buygpBJFZpOY73qgAAAABJRU5ErkJggg==) repeat-y;left:50%;margin-left:-2.8125rem;top:1.25rem;background-position:center 0;-webkit-animation:ani-bgposition-sjrjgcq 1000s infinite linear;animation:ani-bgposition-sjrjgcq 1000s infinite linear;opacity:.5;background-size:70%}@-webkit-keyframes ani-coin-sjrjgcq{0%{-webkit-transform:translateY(0) scale(1);-ms-transform:translateY(0) scale(1);transform:translateY(0) scale(1)}50%{-webkit-transform:translateY(-20px) scale(1);-ms-transform:translateY(-20px) scale(1);transform:translateY(-20px) scale(1)}to{-webkit-transform:translateY(0) scale(1);-ms-transform:translateY(0) scale(1);transform:translateY(0) scale(1)}}@keyframes ani-coin-sjrjgcq{0%{-webkit-transform:translateY(0) scale(1);-ms-transform:translateY(0) scale(1);transform:translateY(0) scale(1)}50%{-webkit-transform:translateY(-20px) scale(1);-ms-transform:translateY(-20px) scale(1);transform:translateY(-20px) scale(1)}to{-webkit-transform:translateY(0) scale(1);-ms-transform:translateY(0) scale(1);transform:translateY(0) scale(1)}}.sjrjgcq .coin{position:absolute;-webkit-animation:ani-coin-sjrjgcq 3s infinite linear;animation:ani-coin-sjrjgcq 3s infinite linear;width:3.125rem;left:50%;margin-left:-1.5625rem;top:3.625rem}.sjrjgcq .mark{position:absolute;width:6.125rem;height:6.125rem;left:50%;top:2.5rem;margin-left:-3.0625rem;z-index:11}.s1b4lpsd{position:relative;width:12.5rem}.s1b4lpsd .bg{width:12.5rem;position:relative}@-webkit-keyframes ani_rotate-s1b4lpsd{0%{-webkit-transform:rotate(0deg);-ms-transform:rotate(0deg);transform:rotate(0)}to{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg)}}@keyframes ani_rotate-s1b4lpsd{0%{-webkit-transform:rotate(0deg);-ms-transform:rotate(0deg);transform:rotate(0)}to{-webkit-transform:rotate(360deg);-ms-transform:rotate(360deg);transform:rotate(360deg)}}.s1b4lpsd .light-bg{position:absolute;width:140%;height:80%;overflow:hidden;left:-20%}.s1b4lpsd .light-bg img{position:absolute;width:100%;-webkit-animation:ani_rotate-s1b4lpsd 6s infinite linear;animation:ani_rotate-s1b4lpsd 6s infinite linear;top:0;left:0}\n", document.head.appendChild(t), System.register(["./index-legacy.1416f96c.js"], (function(t) {
        "use strict";
        var e, s, a, r, n, i;
        return {
            setters: [function(t) {
                e = t.a5, s = t.a, a = t.s, r = t.j, n = t.l, i = t.B
            }],
            execute: function() {
                function o({
                    className: t
                }) {
                    const e = a.isDarken;
                    return r("div", {
                        className: n(c, t),
                        children: [s("img", {
                            src: e ? i.status_bg : i.status_bg_w,
                            className: "bg",
                            alt: ""
                        }), s("div", {
                            className: "bubble"
                        })]
                    })
                }

                function l({
                    className: t
                }) {
                    const e = a.isDarken;
                    return r("div", {
                        className: n(c, t),
                        children: [s("img", {
                            src: e ? i.status_bg2 : i.status_bg2_w,
                            className: "bg",
                            alt: ""
                        }), s("div", {
                            className: "bubble"
                        }), s("img", {
                            src: i.status_coin,
                            className: "coin",
                            alt: ""
                        }), s("img", {
                            src: i.status_mark,
                            className: "mark",
                            alt: ""
                        })]
                    })
                }

                function m({
                    className: t
                }) {
                    const e = a.isDarken;
                    return r("div", {
                        className: n(c, g, t),
                        children: [s("div", {
                            className: "light-bg",
                            children: s("img", {
                                className: "light",
                                src: i.status_light,
                                alt: ""
                            })
                        }), s("img", {
                            src: e ? i.status_bg3 : i.status_bg3_w,
                            className: "bg",
                            alt: ""
                        })]
                    })
                }
                t("B", e.memo((function(t) {
                    const e = Number(t.bonusAmount),
                        a = Number(t.bonusThreshold);
                    return s(0 === e ? o : e >= a ? m : l, {
                        className: t.className
                    })
                })));
                const c = "sjrjgcq",
                    g = "s1b4lpsd"
            }
        }
    }))
}();
! function() {
    var e = document.createElement("style");
    e.innerHTML = '.hbmsw65{color:rgba(153,164,176,.8)}.hbmsw65 h3{margin-top:0;margin-bottom:.5rem}.hbmsw65 p{margin:0 0 1.875rem}.hbmsw65 ul{list-style:none}.hbmsw65 li{margin:0;padding:0}.a1cogifu{--bii9bj:linear-gradient(151deg,#6dafac 4%,#90c0c0 11%,#e9eaf2 29%);--1qpuh8a:#fff;--whdmoy:#31373d;--1yhspeg:rgba(95,105,117,.8);--vv18os:#f5f6fa;--njpvpw:#31373d;--1q605xi:#dadde6;--10qstuv:rgba(107,113,128,.4);--yqqx8g:#fff;--cqo7o4:linear-gradient(to right,rgba(98,192,183,.2),rgba(245,246,250,.2) 30%,#f5f6fa);min-height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column}.darken .a1cogifu{--bii9bj:linear-gradient(151deg,#007c6f 2%,#183333 23%,#1e2024 33%);--1qpuh8a:#c5c5c5;--whdmoy:#f5f6f7;--1yhspeg:rgba(153,164,176,.6);--vv18os:rgba(45,48,53,.5);--njpvpw:#fff;--1q605xi:#2d3035;--10qstuv:rgba(107,113,128,.6);--yqqx8g:#f5f6f7;--cqo7o4:linear-gradient(to right,rgba(0,124,111,.47),rgba(45,48,53,.5) 30%,#2d3035)}.a1cogifu .recharge-wrap{-webkit-flex:auto;-ms-flex:auto;flex:auto;border-radius:1.25rem;background-image:var(--bii9bj);padding-bottom:4.625rem;position:relative;z-index:1}.a1cogifu .recharge-wrap .question{position:absolute;top:1.25rem;right:1.25rem;fill:var(--primary-color);cursor:pointer;z-index:10}.a1cogifu .bg{padding:0 1.875rem}.a1cogifu .status-box{position:relative;z-index:2;height:18.75rem}.a1cogifu .status-box .charging{width:100%;height:100%;background-repeat:no-repeat;background-position:center;background-size:contain;position:absolute;left:0;top:0;z-index:5}.a1cogifu .current-box{position:absolute;top:42%;left:50%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:3.375rem;height:3.375rem;border-radius:50%;background-image:linear-gradient(to bottom,#fbfbfb,var(--1qpuh8a));display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-flow:column;-ms-flex-flow:column;flex-flow:column;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;line-height:1;z-index:10}.a1cogifu .title-box{text-align:center;color:var(--whdmoy);font-size:1.5rem;font-weight:600}.a1cogifu .title-box .title-sub{font-size:1rem;color:var(--1yhspeg);padding:0 1.5rem;font-weight:500}.a1cogifu .conditions{margin-top:2.1875rem}.a1cogifu .conditions .item{height:3.5rem;border-radius:1.25rem;background:var(--vv18os);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;color:var(--njpvpw);padding:0 1.25rem;margin-top:.875rem;border:1px solid var(--1q605xi);opacity:.5;font-size:.875rem}.a1cogifu .conditions .icon-status{width:.875rem;height:.875rem;border-radius:50%;background:var(--1q605xi);border:2px solid transparent}.a1cogifu .conditions .desc{-webkit-flex:1;-ms-flex:1;flex:1;padding:0 .875rem;word-break:break-word}.a1cogifu .conditions .vip,.a1cogifu .conditions .amount{font-weight:600}.a1cogifu .ready.item{opacity:1;border-color:#007c6f;background:var(--cqo7o4)}.a1cogifu .ready .icon-status{border-color:rgba(112,179,22,.26);box-shadow:0 0 0 2px rgba(112,179,22,.16);background:#70b316}.a1cogifu .ready .vip,.a1cogifu .ready .amount{color:#70b317}.a1cogifu .ready .current-box{background-image:linear-gradient(169deg,#4aeb96 -9%,#1dbd66 81%)}.a1cogifu .claim{width:13.5rem;height:3rem;margin:0 auto}.a1cogifu .claim:disabled{background:var(--10qstuv);color:var(--yqqx8g);opacity:.7}.a1cogifu .countdown-box{margin:1.5rem 0;font-size:.75rem;color:var(--1yhspeg)}.a1cogifu .countdown-box .circle-countdown{width:.75rem;height:.75rem;margin-left:.25rem}.a1cogifu .countdown-box .time{width:2.125rem;margin-left:.25rem}.c1xpoiva{--1slxu8h:rgba(95,105,117,.8);--njpvpw:#31373d;--4bqxt6:rgba(95,105,117,.3);--1do0ydi:linear-gradient(to bottom,#dadde6,#dadde6 50%,rgba(95,105,117,.57) 50%,rgba(95,105,117,0));width:15.125rem;margin:0 auto 1.125rem;text-align:center}.darken .c1xpoiva{--1slxu8h:rgba(104,110,120,.6);--njpvpw:#fff;--4bqxt6:transparent;--1do0ydi:rgba(23,24,27,.45)}.c1xpoiva .title{color:var(--1slxu8h);font-size:.75rem;margin-bottom:.5rem}.c1xpoiva .flex{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}.c1xpoiva .flex .item{width:4.125rem;height:4.8125rem;border-radius:.5rem;padding:.5rem;color:var(--njpvpw);border:1px solid var(--4bqxt6);background:var(--1do0ydi)}.c1xpoiva .flex .desc{opacity:.6;font-size:1.25rem;zoom:.5}.c1xpoiva .flex .time{font-size:1.75rem;font-weight:600;line-height:normal}.c1xpoiva .flex .spec{position:relative}.c1xpoiva .flex .spec:before,.c1xpoiva .flex .spec:after{content:":";position:absolute;bottom:1.375rem;left:-.8125rem;font-size:1.75rem;font-weight:600;line-height:normal}.c1xpoiva .flex .spec:after{left:unset;right:-.8125rem}.w9devxj{--1qpuh8a:#fff;position:relative;z-index:4}.darken .w9devxj{--1qpuh8a:#c5c5c5}.w9devxj .status-box{position:relative;height:18.75rem}.w9devxj .status-box .charging{width:100%;height:100%;background-repeat:no-repeat;background-position:center;background-size:contain;position:absolute;left:0;top:0;z-index:5}.w9devxj .status-box .current-box{position:absolute;top:42%;left:50%;-webkit-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:3.375rem;height:3.375rem;border-radius:50%;background-image:linear-gradient(to bottom,#fbfbfb,var(--1qpuh8a) 87%);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-flow:column;-ms-flex-flow:column;flex-flow:column;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;color:#000;line-height:1;z-index:10}.w9devxj .status-box .current-box.ready{background-image:linear-gradient(169deg,#4aeb96 -9%,#1dbd66 81%);color:#fff}.w9devxj .status-box .current-box .current{font-weight:600;font-size:1.75rem}.w9devxj .status-box .current-box .percent{opacity:.5;font-size:.75rem}.c1c62uq1{-webkit-flex-flow:column;-ms-flex-flow:column;flex-flow:column}.c1c62uq1 .title{font-size:1.125rem;color:#fff;text-transform:uppercase;margin:2em 0 1em}.c1c62uq1 .content{font-size:.75rem;color:rgba(153,164,176,.6)}.i1h7yuwk{--1uvkmwv:#5f6975;--2vljes:#e9eaf2}.darken .i1h7yuwk{--1uvkmwv:#f5f6f7;--2vljes:#2d3035}.i1h7yuwk .interval-select{width:13rem}.i1h7yuwk .options .flex{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.i1h7yuwk .options .icon{width:1em;height:1em;background:url(/assets/disabled.872efa0c.svg) no-repeat center;background-size:auto 100%;margin-right:.5em}.i1h7yuwk .select-trigger{-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;color:var(--1uvkmwv);background:var(--2vljes)}.c1veba8h{--whdmoy:#31373d;--mgi7ei:#f5f6fa;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;margin-bottom:2.375rem}.darken .c1veba8h{--whdmoy:#f5f6f7;--mgi7ei:#2d3035}.c1veba8h .ui-select{width:14.375rem;margin-left:.5rem}.c1veba8h .select-trigger{color:var(--whdmoy);background:var(--mgi7ei);font-size:1rem}.c1veba8h .select-trigger .name{color:rgba(153,164,176,.6);font-weight:600}.r1bii1g0{--13gcsn8:linear-gradient(150deg,#801aff -23%,#ffffff 44%);--njpvpw:#31373d;max-width:25.875rem;width:25.875rem;height:36.25rem;border-radius:1.25rem;background-image:var(--13gcsn8);padding:19.25rem 3.125rem 2.8125rem;text-align:center;font-weight:600;color:var(--njpvpw);font-size:1.625rem;line-height:normal;position:relative}.darken .r1bii1g0{--13gcsn8:linear-gradient(142deg,#403151 -7%,#1e2024 36%);--njpvpw:#fff}.r1bii1g0 .lottie-wrap{width:27.5rem;height:23.4375rem;position:absolute;top:-5.625rem;left:-.8125rem;z-index:2}.r1bii1g0 .partical-layer{bottom:0;border-radius:1.25rem}.r1bii1g0 .front{position:relative;z-index:3}.r1bii1g0 .recharge{font-size:2.375rem;margin-bottom:1.5rem}.r1bii1g0 .amount{color:#f6c722;margin-right:.5rem}.r1bii1g0 .ui-button{margin-top:1.75rem;font-size:1.125rem}.h1sznhdr{--bii9bj:linear-gradient(151deg,#6dafac 4%,#90c0c0 11%,#e9eaf2 29%);--1rep5cp:transparent;--arx5t4:rgba(218,221,230,.6);--1yhspeg:rgba(95,105,117,.8);--njpvpw:#31373d;--1fcbjpl:rgba(95,105,7,.13);--jsseh5:#7BC514;--10qstuv:rgba(107,113,128,.4);--yqqx8g:#fff}.darken .h1sznhdr{--bii9bj:linear-gradient(151deg,#007c6f 2%,#183333 23%,#1e2024 33%);--1rep5cp:#2d3035;--arx5t4:rgba(45,48,53,.5);--1yhspeg:rgba(153,164,176,.6);--njpvpw:#fff;--1fcbjpl:rgba(107,114,124,.3);--jsseh5:#70b317;--10qstuv:rgba(107,113,128,.6);--yqqx8g:#f5f6f7}.h1sznhdr .recharge-wrap{border-radius:1.25rem;background-image:var(--bii9bj);padding-bottom:4.625rem;position:relative;z-index:1}.h1sznhdr .recharge-wrap .question{position:absolute;top:1.25rem;right:1.25rem;fill:var(--primary-color);cursor:pointer;z-index:10}.h1sznhdr .fg{position:relative;z-index:1}.h1sznhdr .bg{padding:0 1.875rem}.h1sznhdr .bg .details{border-radius:1.25rem;border:1px solid var(--1rep5cp);background:var(--arx5t4);padding:1.875rem 1.25rem;text-align:center;font-size:.75rem;color:var(--1yhspeg)}.h1sznhdr .bg .item{-webkit-flex:0 0 50%;-ms-flex:0 0 50%;flex:0 0 50%}.h1sznhdr .bg .bold{font-size:1.5rem;font-weight:600;color:var(--njpvpw);white-space:nowrap}.h1sznhdr .bg .br{border-right:1px solid var(--1fcbjpl)}.h1sznhdr .bg .time{font-size:.875rem;font-weight:600;color:var(--jsseh5);margin-top:1.875rem}.h1sznhdr .claim{width:13.5rem;height:3rem;margin:1.875rem auto 0}.h1sznhdr .claim:disabled{background:var(--10qstuv);color:var(--yqqx8g);opacity:.7}.h1sznhdr .contact{text-align:center;margin-top:1.25rem}.rnkdh93{margin:0 .5rem;padding-bottom:.5rem;border-radius:1.25rem}\n', document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js", "./ParticleLayer-legacy.c6f3938f.js", "./recaptcha-legacy.8aca4e99.js", "./usePixiGsap-legacy.c051c439.js"], (function(e) {
        "use strict";
        var r, a, i, t, n, c, s, o, l, d, g, m, f, h, u, p, b, v, x, w, y, k, N, j, z, q, _, L, $, R, E, M, C, D;
        return {
            setters: [function(e) {
                r = e.v, a = e.a, i = e.u, t = e.D, n = e.S, c = e.j, s = e.s, o = e.o, l = e.t, d = e.q, g = e.aA, m = e.A, f = e.I, h = e.b, u = e.r, p = e.aB, b = e.ab, v = e.aC, x = e.d, w = e.P, y = e.F, k = e.ax, N = e.p, j = e.aD, z = e.J, q = e.M, _ = e.aE, L = e.ak, $ = e.L, R = e.al, E = e.aF, M = e.a3
            }, function(e) {
                C = e.P
            }, function(e) {
                D = e.r
            }, function() {}],
            execute: function() {
                function I() {
                    const e = i();
                    return a(t, {
                        title: e("page.recharge.about"),
                        children: a(n, {
                            className: S,
                            children: c("ul", {
                                children: [c("li", {
                                    children: [a("h3", {
                                        children: e("page.recharge.about.tit_1")
                                    }), a("p", {
                                        children: e("page.recharge.about.desc_1")
                                    })]
                                }), c("li", {
                                    children: [a("h3", {
                                        children: e("page.recharge.about.tit_2")
                                    }), a("p", {
                                        dangerouslySetInnerHTML: {
                                            __html: e("page.recharge.about.desc_2")
                                        }
                                    })]
                                }), c("li", {
                                    children: [a("h3", {
                                        children: e("page.recharge.about.tit_3")
                                    }), a("p", {
                                        children: e("page.recharge.about.desc_3")
                                    })]
                                }), c("li", {
                                    children: [a("h3", {
                                        children: e("page.recharge.about.tit_4")
                                    }), a("p", {
                                        children: e("page.recharge.about.desc_4")
                                    })]
                                })]
                            })
                        })
                    })
                }
                const U = () => {
                        r.push(a(I, {}))
                    },
                    S = "hbmsw65";

                function A(e) {
                    return e < 25 ? s.isDarken ? "/assets/recharge-0.86e44653.png" : "/assets/recharge-0-white.bba84859.png" : e < 50 ? s.isDarken ? "/assets/recharge-25.00a320b4.png" : "/assets/recharge-25-white.95bcca03.png" : e < 75 ? s.isDarken ? "/assets/recharge-50.e17fcb0e.png" : "/assets/recharge-50-white.707cf11a.png" : e < 100 ? s.isDarken ? "/assets/recharge-75.65f4c194.png" : "/assets/recharge-75-white.f019d73c.png" : s.isDarken ? "/assets/recharge-100.22090dcd.png" : "/assets/recharge-100-white.6da3ced4.png"
                }
                var B = {
                    disabled: "/assets/disabled.872efa0c.svg",
                    rechargeLottile: s.isDarken ? "/assets/recharge.586261e1.json" : "/assets/rechargew-white.fe1cd6d5.json",
                    rechargeReward: "/assets/recharge_reward.6fe75678.json"
                };

                function T({
                    isRech: e
                }) {
                    const r = u.exports.useRef(null);
                    u.exports.useEffect((() => {
                        var e;
                        null === (e = r.current) || void 0 === e || e.play(0)
                    }), []);
                    const i = A(e ? 100 : 50);
                    return c("div", {
                        className: e ? "ready status-box" : "status-box",
                        children: [a(p, {
                            className: "charging",
                            ref: r,
                            loop: !0,
                            style: {
                                backgroundImage: `url(${i})`
                            }
                        }), a("div", {
                            className: "current-box",
                            children: a("svg", {
                                width: "26",
                                height: "40",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: a("path", {
                                    d: "M0 22.89L17.013 0v16.855H26L8.86 40V22.89z",
                                    fill: e ? "#ffffff" : "#20A75E"
                                })
                            })
                        })]
                    })
                }

                function H() {
                    b.trackEvent("recharge_request"), v().then((() => {
                        g.forceUpdate(), r.close()
                    })), x.emit("openLiveSupport"), window.$crisp && (window.$crisp.push(["set", "session:segments", [
                        ["start-vip"]
                    ]]), window.$crisp.push(["do", "message:send", ["text", "⚡️🔋Recharge activate🔋⚡️"]]))
                }
                window.$crisp && window.$crisp.push("on", "chat:closed", (() => {
                    window.$crisp.push(["set", "session:segments", [
                        [""]
                    ]], !0)
                }));
                var P = o((function() {
                    const e = i(),
                        r = {
                            vipLevel: g.data.vipLevel,
                            turnover: Number(g.data.lastBetUsd.length > 8 ? g.data.lastBetUsd.slice(0, 8) : g.data.lastBetUsd)
                        },
                        t = g.conditions;
                    g.lastSyncTime;
                    const n = g.conditionsOn;
                    return a("div", {
                        className: O,
                        children: c("div", {
                            className: "recharge-wrap",
                            children: [a(m, {
                                name: "Help",
                                className: "question",
                                onClick: U
                            }), c("div", {
                                className: "fg",
                                children: [a(C, {}), a(T, {
                                    isRech: n
                                }), c("div", {
                                    className: "title-box",
                                    children: [a("div", {
                                        className: "title",
                                        children: e(n ? "page.recharge.title.ready" : "page.recharge.title.wait")
                                    }), a("div", {
                                        className: "title-sub",
                                        children: e(n ? "page.recharge.desc.ready" : "page.recharge.desc.wait")
                                    })]
                                })]
                            }), c("div", {
                                className: "bg",
                                children: [c("div", {
                                    className: "conditions",
                                    children: [c("div", {
                                        className: r.vipLevel >= t.vipLevel ? "ready item" : "item",
                                        children: [a("div", {
                                            className: "icon-status"
                                        }), a("div", {
                                            className: "desc",
                                            children: a(f, {
                                                k: "page.recharge.conditions.vip",
                                                children: t.vipLevel
                                            })
                                        }), a("div", {
                                            className: "current",
                                            children: c("div", {
                                                className: "vip",
                                                children: [e("page.recharge.vip"), " ", r.vipLevel]
                                            })
                                        })]
                                    }), c("div", {
                                        className: r.turnover >= t.turnover ? "ready item" : "item",
                                        children: [a("div", {
                                            className: "icon-status"
                                        }), a("div", {
                                            className: "desc",
                                            children: a(f, {
                                                k: "page.recharge.conditions.wager",
                                                children: t.turnover
                                            })
                                        }), a("div", {
                                            className: "current",
                                            children: a("div", {
                                                className: "amount",
                                                children: r.turnover > t.turnover ? t.turnover + "+" : r.turnover.toFixed(2)
                                            })
                                        })]
                                    })]
                                }), a("div", {
                                    className: "countdown-box flex-center",
                                    children: e("page.recharge.apply.countdown")
                                }), a(h, {
                                    className: "claim",
                                    disabled: !n,
                                    type: "conic",
                                    onClick: H,
                                    children: e("page.recharge.request")
                                })]
                            })]
                        })
                    })
                }));
                l({
                    cl1: ["linear-gradient(151deg, #007c6f 2%, #183333 23%, #1e2024 33%)", "linear-gradient(151deg, #6dafac 4%, #90c0c0 11%, #e9eaf2 29%)"],
                    cl2: ["#c5c5c5", "#fff"],
                    cl3: ["#f5f6f7", "#31373d"],
                    cl4: [d("#99a4b0", .6), d("#5f6975", .8)],
                    cl5: [d("#2d3035", .5), "#f5f6fa"],
                    cl6: ["#fff", "#31373d"],
                    cl7: ["#2d3035", "#dadde6"],
                    cl8: [d("#6b7180", .6), d("#6b7180", .4)],
                    cl9: ["#f5f6f7", "#fff"],
                    gd1: [`linear-gradient(to right, ${d("#007c6f",.47)}, ${d("#2d3035",.5)} 30%, #2d3035)`, `linear-gradient(to right, ${d("#62c0b7",.2)}, ${d("#f5f6fa",.2)} 30%, #f5f6fa)`]
                });
                const O = "a1cogifu";

                function F(e) {
                    let r = Math.floor(e / 1e3 % 60),
                        a = Math.floor(e / 1e3 / 60 % 60),
                        i = Math.floor(e / 1e3 / 60 / 60 % 24);
                    return r < 10 && (r = "0" + r), a < 10 && (a = "0" + a), i < 10 && (i = "0" + i), {
                        sec: r,
                        min: a,
                        hour: i
                    }
                }

                function G({
                    ms: e
                }) {
                    const r = i(),
                        [t, n] = u.exports.useState(F(e)),
                        s = w();
                    return u.exports.useEffect((() => {
                        let r = e,
                            a = setInterval((() => {
                                g.isRech || (r = Math.max(r - 1e3, 0), 0 === r && (clearInterval(a), g.forceUpdate()), s() && n(F(r)))
                            }), 1e3);
                        return () => {
                            clearInterval(a)
                        }
                    }), [e]), a("div", {
                        className: J,
                        children: g.isRech ? a("div", {
                            className: "ready",
                            children: r("page.recharge.recharge_ready")
                        }) : c(y, {
                            children: [a("div", {
                                className: "title",
                                children: r("page.recharge.recharge_in")
                            }), c("div", {
                                className: "flex",
                                children: [c("div", {
                                    className: "item",
                                    children: [a("div", {
                                        className: "desc",
                                        children: "Hours"
                                    }), a("div", {
                                        className: "time",
                                        children: t.hour
                                    })]
                                }), c("div", {
                                    className: "item spec",
                                    children: [a("div", {
                                        className: "desc",
                                        children: "Minutes"
                                    }), a("div", {
                                        className: "time",
                                        children: t.min
                                    })]
                                }), c("div", {
                                    className: "item",
                                    children: [a("div", {
                                        className: "desc",
                                        children: "Seconds"
                                    }), a("div", {
                                        className: "time",
                                        children: t.sec
                                    })]
                                })]
                            })]
                        })
                    })
                }
                l({
                    cl1: [d("#686e78", .6), d("#5f6975", .8)],
                    cl2: ["#fff", "#31373d"],
                    cl3: ["transparent", d("#5f6975", .3)],
                    cl4: [d("#17181b", .45), `linear-gradient(to bottom, #dadde6, #dadde6 50%, ${d("#5f6975",.57)} 50%, ${d("#5f6975",0)})`]
                });
                const J = "c1xpoiva";
                var V = o((function() {
                    const {
                        nextReceiveTime: e
                    } = g.data;
                    return c("div", {
                        className: W,
                        children: [a(K, {}), a(G, {
                            ms: Math.max(new Date(e).getTime() - Date.now(), 0)
                        })]
                    })
                }));
                const K = o((function() {
                        const {
                            percent: e,
                            isRech: r
                        } = g, {
                            intervalTime: i
                        } = g.data, t = i > 36e5 ? i / 36e5 : i / 6e4, n = Math.floor(t * e / 100);
                        return c("div", {
                            className: "status-box",
                            children: [a(Q, {}), c("div", {
                                className: "current-box " + (r ? "ready" : ""),
                                children: [a("div", {
                                    className: "current",
                                    children: n
                                }), c("div", {
                                    className: "percent",
                                    children: [Math.floor(e), "%"]
                                })]
                            })]
                        })
                    })),
                    Q = o((function() {
                        const {
                            percent: e
                        } = g, r = u.exports.useRef(null);
                        return u.exports.useEffect((() => {
                            var e;
                            null === (e = r.current) || void 0 === e || e.play(0)
                        }), []), a(p, {
                            className: "charging",
                            ref: r,
                            path: B.rechargeLottile,
                            loop: !0,
                            style: {
                                backgroundImage: `url(${A(e)})`
                            }
                        })
                    })),
                    W = "w9devxj";
                var X = o((function() {
                    const e = i();
                    return a("div", {
                        className: Z,
                        children: a(k, {
                            options: g.intervalOptions,
                            value: g.currentInterval,
                            onChange: function(r) {
                                N.confirm(c("div", {
                                    className: `${Y} message`,
                                    children: [a("div", {
                                        className: "title",
                                        children: e("page.recharge.interval.title")
                                    }), a("div", {
                                        className: "content",
                                        children: e("page.recharge.interval.desc")
                                    })]
                                })).then((e => {
                                    e && j(r).then((() => {
                                        g.currentInterval = r, g.forceUpdate()
                                    }))
                                }))
                            },
                            renderOption: function(e) {
                                return c("div", {
                                    className: "flex",
                                    children: [e.disabled && a("div", {
                                        className: "icon"
                                    }), e.label]
                                })
                            },
                            className: "interval-select"
                        })
                    })
                }));
                const Y = "c1c62uq1",
                    Z = "i1h7yuwk";
                var ee = o((function() {
                    const e = i(),
                        r = g.data.rewards.map((e => ({
                            label: z.getAlias(e.currencyName),
                            value: e.currencyName,
                            amount: +e.amount
                        })));
                    return c("div", {
                        className: re,
                        children: [a("div", {
                            className: "type",
                            children: e("common.currency")
                        }), a(k, {
                            className: "recharge-currency",
                            value: g.currencyName,
                            options: r,
                            onChange: function(e) {
                                g.currencyName = e
                            },
                            disabled: g.isAnimation,
                            top: !0,
                            renderLabel: e => a(q, {
                                name: e.value,
                                disableLocal: !0,
                                amount: e.amount,
                                icon: !0
                            }),
                            renderOption: e => a(q, {
                                name: e.value,
                                disableLocal: !0,
                                amount: e.amount,
                                icon: !0
                            })
                        })]
                    })
                }));
                const re = "c1veba8h";
                const ae = {
                    scale: {
                        list: [{
                            value: 1,
                            time: 0
                        }, {
                            value: 1.5,
                            time: 1
                        }]
                    },
                    color: {
                        start: "#892aff",
                        end: "#892aff"
                    },
                    maxParticles: 8,
                    spawnRect: {
                        w: 414,
                        h: 580
                    }
                };

                function ie({
                    amount: e,
                    currencyName: r
                }) {
                    const t = i(),
                        n = u.exports.useRef(null);
                    return u.exports.useEffect((() => {
                        setTimeout((() => {
                            var e;
                            null === (e = n.current) || void 0 === e || e.play(0)
                        }), 300)
                    }), []), c("div", {
                        className: `result-pop ${te}`,
                        children: [a(p, {
                            className: "lottie-wrap",
                            ref: n,
                            path: B.rechargeReward
                        }), a(C, {
                            config: ae
                        }), c("div", {
                            className: "front",
                            children: [a("div", {
                                className: "recharge",
                                children: t("page.recharge.recharge")
                            }), a("div", {
                                className: "text",
                                children: t("page.recharge.result")
                            }), c("div", {
                                className: "result-value flex-center",
                                children: [a("div", {
                                    className: "amount",
                                    children: e
                                }), a("div", {
                                    className: "currency-name",
                                    children: z.getAlias(r)
                                })]
                            }), a(h, {
                                onClick: () => N.close(),
                                type: "conic",
                                children: t("common.actions.confirm")
                            })]
                        })]
                    })
                }
                const te = "r1bii1g0";
                const ne = new _({
                    src: "/assets/recharge_success.b0813da2.mp3"
                });
                var ce = o((function() {
                    const e = i(),
                        {
                            isAnimation: r,
                            isRech: t,
                            data: n
                        } = g,
                        [o, l] = u.exports.useState(!1);
                    return u.exports.useEffect((() => () => {
                        g.isAnimation && (g.isAnimation = !1)
                    }), []), a("div", {
                        className: se,
                        children: c("div", {
                            className: "recharge-wrap",
                            children: [a(L, {
                                children: a(X, {})
                            }), a(m, {
                                name: "Help",
                                className: "question",
                                onClick: U
                            }), c("div", {
                                className: "fg",
                                children: [a(C, {}), a(V, {})]
                            }), c("div", {
                                className: "bg",
                                children: [c("div", {
                                    className: "details",
                                    children: [a(ee, {}), c("div", {
                                        className: "flex-center",
                                        children: [c("div", {
                                            className: "item br",
                                            children: [a("div", {
                                                className: "bold",
                                                children: a($, {
                                                    amount: Number(n.receiveUsd)
                                                })
                                            }), a("div", {
                                                children: e("page.recharge.total_claimed")
                                            })]
                                        }), c("div", {
                                            className: "item",
                                            children: [a("div", {
                                                className: "bold",
                                                children: a($, {
                                                    amount: Number(n.nextBetUsd)
                                                })
                                            }), a("div", {
                                                children: e("page.recharge.new_wagered")
                                            })]
                                        })]
                                    }), a("div", {
                                        className: "time",
                                        children: new Date(n.endTime).toLocaleString()
                                    }), a("div", {
                                        children: e("page.recharge.expires")
                                    })]
                                }), a(h, {
                                    className: "claim",
                                    loading: o,
                                    onClick: function() {
                                        const e = g.data.rewards.find((e => e.currencyName === g.currencyName));
                                        e && (l(!0), D("login").then((e => E(g.currencyName, e))).then((() => {
                                            l(!1), g.forceUpdate(),
                                                function() {
                                                    if (s.settings.soundEffectEnable) try {
                                                        ne.play()
                                                    } catch (e) {}
                                                }(), N.push(a(ie, {
                                                    amount: e.amount,
                                                    currencyName: e.currencyName
                                                }))
                                        })).catch((() => {
                                            l(!1)
                                        })))
                                    },
                                    type: "conic",
                                    disabled: !t || r || o,
                                    children: e("page.recharge.claim_recharge")
                                }), 0 !== n.viphostUserId && a("div", {
                                    className: "contact",
                                    children: a(f, {
                                        k: "page.recharge.contact_host",
                                        children: a(R, {
                                            to: `/chat/${n.viphostUserId}${n.isSendBonus?"?phrase=claim_weekly":""}`,
                                            children: e("common.viphost")
                                        })
                                    })
                                })]
                            })]
                        })
                    })
                }));
                l({
                    gd1: ["linear-gradient(151deg, #007c6f 2%, #183333 23%, #1e2024 33%)", "linear-gradient(151deg, #6dafac 4%, #90c0c0 11%, #e9eaf2 29%)"],
                    cl1: ["#2d3035", "transparent"],
                    cl2: [d("#2d3035", .5), d("#dadde6", .6)],
                    cl3: [d("#99a4b0", .6), d("#5f6975", .8)],
                    cl4: ["#fff", "#31373d"],
                    cl5: [d("#6b727c", .3), d("#5f697", .13)],
                    cl6: ["#70b317", "#7BC514"],
                    cl7: [d("#6b7180", .6), d("#6b7180", .4)],
                    cl8: ["#f5f6f7", "#fff"]
                });
                const se = "h1sznhdr";
                e("default", o((function() {
                    const e = i();
                    return u.exports.useEffect((() => () => {
                        g.destory()
                    }), []), a(t, {
                        title: e("page.recharge.recharge"),
                        size: [464, 830],
                        nostyle: !0,
                        children: a(n, {
                            className: oe,
                            children: a(M, {
                                pms: g.init(),
                                children: () => g.data.status < 2 ? a(P, {}) : a(ce, {})
                            })
                        })
                    })
                })));
                const oe = "rnkdh93"
            }
        }
    }))
}();
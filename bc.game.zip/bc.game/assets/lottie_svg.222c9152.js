import {
    aM as commonjsGlobal
} from "./index.28e31dff.js";

function _mergeNamespaces(t, e) {
    return e.forEach(function(r) {
        r && typeof r != "string" && !Array.isArray(r) && Object.keys(r).forEach(function(i) {
            if (i !== "default" && !(i in t)) {
                var s = Object.getOwnPropertyDescriptor(r, i);
                Object.defineProperty(t, i, s.get ? s : {
                    enumerable: !0,
                    get: function() {
                        return r[i]
                    }
                })
            }
        })
    }), Object.freeze(Object.defineProperty(t, Symbol.toStringTag, {
        value: "Module"
    }))
}
var lottie_svg$2 = {
    exports: {}
};
(function(module, exports) {
    typeof navigator < "u" && function(t, e) {
        module.exports = e()
    }(commonjsGlobal, function() {
        var svgNS = "http://www.w3.org/2000/svg",
            locationHref = "",
            _useWebWorker = !1,
            initialDefaultFrame = -999999,
            setWebWorker = function(e) {
                _useWebWorker = !!e
            },
            getWebWorker = function() {
                return _useWebWorker
            },
            setLocationHref = function(e) {
                locationHref = e
            },
            getLocationHref = function() {
                return locationHref
            };

        function createTag(t) {
            return document.createElement(t)
        }

        function extendPrototype(t, e) {
            var r, i = t.length,
                s;
            for (r = 0; r < i; r += 1) {
                s = t[r].prototype;
                for (var n in s) Object.prototype.hasOwnProperty.call(s, n) && (e.prototype[n] = s[n])
            }
        }

        function getDescriptor(t, e) {
            return Object.getOwnPropertyDescriptor(t, e)
        }

        function createProxyFunction(t) {
            function e() {}
            return e.prototype = t, e
        }
        var audioControllerFactory = function() {
                function t(e) {
                    this.audios = [], this.audioFactory = e, this._volume = 1, this._isMuted = !1
                }
                return t.prototype = {
                        addAudio: function(r) {
                            this.audios.push(r)
                        },
                        pause: function() {
                            var r, i = this.audios.length;
                            for (r = 0; r < i; r += 1) this.audios[r].pause()
                        },
                        resume: function() {
                            var r, i = this.audios.length;
                            for (r = 0; r < i; r += 1) this.audios[r].resume()
                        },
                        setRate: function(r) {
                            var i, s = this.audios.length;
                            for (i = 0; i < s; i += 1) this.audios[i].setRate(r)
                        },
                        createAudio: function(r) {
                            return this.audioFactory ? this.audioFactory(r) : window.Howl ? new window.Howl({
                                src: [r]
                            }) : {
                                isPlaying: !1,
                                play: function() {
                                    this.isPlaying = !0
                                },
                                seek: function() {
                                    this.isPlaying = !1
                                },
                                playing: function() {},
                                rate: function() {},
                                setVolume: function() {}
                            }
                        },
                        setAudioFactory: function(r) {
                            this.audioFactory = r
                        },
                        setVolume: function(r) {
                            this._volume = r, this._updateVolume()
                        },
                        mute: function() {
                            this._isMuted = !0, this._updateVolume()
                        },
                        unmute: function() {
                            this._isMuted = !1, this._updateVolume()
                        },
                        getVolume: function() {
                            return this._volume
                        },
                        _updateVolume: function() {
                            var r, i = this.audios.length;
                            for (r = 0; r < i; r += 1) this.audios[r].volume(this._volume * (this._isMuted ? 0 : 1))
                        }
                    },
                    function() {
                        return new t
                    }
            }(),
            createTypedArray = function() {
                function t(r, i) {
                    var s = 0,
                        n = [],
                        f;
                    switch (r) {
                        case "int16":
                        case "uint8c":
                            f = 1;
                            break;
                        default:
                            f = 1.1;
                            break
                    }
                    for (s = 0; s < i; s += 1) n.push(f);
                    return n
                }

                function e(r, i) {
                    return r === "float32" ? new Float32Array(i) : r === "int16" ? new Int16Array(i) : r === "uint8c" ? new Uint8ClampedArray(i) : t(r, i)
                }
                return typeof Uint8ClampedArray == "function" && typeof Float32Array == "function" ? e : t
            }();

        function createSizedArray(t) {
            return Array.apply(null, {
                length: t
            })
        }

        function _typeof$6(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof$6 = function(r) {
                return typeof r
            } : _typeof$6 = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof$6(t)
        }
        var subframeEnabled = !0,
            expressionsPlugin = null,
            idPrefix = "",
            isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent),
            bmPow = Math.pow,
            bmSqrt = Math.sqrt,
            bmFloor = Math.floor,
            bmMin = Math.min,
            BMMath = {};
        (function() {
            var t = ["abs", "acos", "acosh", "asin", "asinh", "atan", "atanh", "atan2", "ceil", "cbrt", "expm1", "clz32", "cos", "cosh", "exp", "floor", "fround", "hypot", "imul", "log", "log1p", "log2", "log10", "max", "min", "pow", "random", "round", "sign", "sin", "sinh", "sqrt", "tan", "tanh", "trunc", "E", "LN10", "LN2", "LOG10E", "LOG2E", "PI", "SQRT1_2", "SQRT2"],
                e, r = t.length;
            for (e = 0; e < r; e += 1) BMMath[t[e]] = Math[t[e]]
        })(), BMMath.random = Math.random, BMMath.abs = function(t) {
            var e = _typeof$6(t);
            if (e === "object" && t.length) {
                var r = createSizedArray(t.length),
                    i, s = t.length;
                for (i = 0; i < s; i += 1) r[i] = Math.abs(t[i]);
                return r
            }
            return Math.abs(t)
        };
        var defaultCurveSegments = 150,
            degToRads = Math.PI / 180,
            roundCorner = .5519;

        function BMEnterFrameEvent(t, e, r, i) {
            this.type = t, this.currentTime = e, this.totalTime = r, this.direction = i < 0 ? -1 : 1
        }

        function BMCompleteEvent(t, e) {
            this.type = t, this.direction = e < 0 ? -1 : 1
        }

        function BMCompleteLoopEvent(t, e, r, i) {
            this.type = t, this.currentLoop = r, this.totalLoops = e, this.direction = i < 0 ? -1 : 1
        }

        function BMSegmentStartEvent(t, e, r) {
            this.type = t, this.firstFrame = e, this.totalFrames = r
        }

        function BMDestroyEvent(t, e) {
            this.type = t, this.target = e
        }

        function BMRenderFrameErrorEvent(t, e) {
            this.type = "renderFrameError", this.nativeError = t, this.currentTime = e
        }

        function BMConfigErrorEvent(t) {
            this.type = "configError", this.nativeError = t
        }
        var createElementID = function() {
            var t = 0;
            return function() {
                return t += 1, idPrefix + "__lottie_element_" + t
            }
        }();

        function HSVtoRGB(t, e, r) {
            var i, s, n, f, P, d, _, E;
            switch (f = Math.floor(t * 6), P = t * 6 - f, d = r * (1 - e), _ = r * (1 - P * e), E = r * (1 - (1 - P) * e), f % 6) {
                case 0:
                    i = r, s = E, n = d;
                    break;
                case 1:
                    i = _, s = r, n = d;
                    break;
                case 2:
                    i = d, s = r, n = E;
                    break;
                case 3:
                    i = d, s = _, n = r;
                    break;
                case 4:
                    i = E, s = d, n = r;
                    break;
                case 5:
                    i = r, s = d, n = _;
                    break
            }
            return [i, s, n]
        }

        function RGBtoHSV(t, e, r) {
            var i = Math.max(t, e, r),
                s = Math.min(t, e, r),
                n = i - s,
                f, P = i === 0 ? 0 : n / i,
                d = i / 255;
            switch (i) {
                case s:
                    f = 0;
                    break;
                case t:
                    f = e - r + n * (e < r ? 6 : 0), f /= 6 * n;
                    break;
                case e:
                    f = r - t + n * 2, f /= 6 * n;
                    break;
                case r:
                    f = t - e + n * 4, f /= 6 * n;
                    break
            }
            return [f, P, d]
        }

        function addSaturationToRGB(t, e) {
            var r = RGBtoHSV(t[0] * 255, t[1] * 255, t[2] * 255);
            return r[1] += e, r[1] > 1 ? r[1] = 1 : r[1] <= 0 && (r[1] = 0), HSVtoRGB(r[0], r[1], r[2])
        }

        function addBrightnessToRGB(t, e) {
            var r = RGBtoHSV(t[0] * 255, t[1] * 255, t[2] * 255);
            return r[2] += e, r[2] > 1 ? r[2] = 1 : r[2] < 0 && (r[2] = 0), HSVtoRGB(r[0], r[1], r[2])
        }

        function addHueToRGB(t, e) {
            var r = RGBtoHSV(t[0] * 255, t[1] * 255, t[2] * 255);
            return r[0] += e / 360, r[0] > 1 ? r[0] -= 1 : r[0] < 0 && (r[0] += 1), HSVtoRGB(r[0], r[1], r[2])
        }
        var rgbToHex = function() {
                var t = [],
                    e, r;
                for (e = 0; e < 256; e += 1) r = e.toString(16), t[e] = r.length === 1 ? "0" + r : r;
                return function(i, s, n) {
                    return i < 0 && (i = 0), s < 0 && (s = 0), n < 0 && (n = 0), "#" + t[i] + t[s] + t[n]
                }
            }(),
            setSubframeEnabled = function(e) {
                subframeEnabled = !!e
            },
            getSubframeEnabled = function() {
                return subframeEnabled
            },
            setExpressionsPlugin = function(e) {
                expressionsPlugin = e
            },
            getExpressionsPlugin = function() {
                return expressionsPlugin
            },
            setDefaultCurveSegments = function(e) {
                defaultCurveSegments = e
            },
            getDefaultCurveSegments = function() {
                return defaultCurveSegments
            },
            setIdPrefix = function(e) {
                idPrefix = e
            };

        function createNS(t) {
            return document.createElementNS(svgNS, t)
        }

        function _typeof$5(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof$5 = function(r) {
                return typeof r
            } : _typeof$5 = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof$5(t)
        }
        var dataManager = function() {
                var t = 1,
                    e = [],
                    r, i, s = {
                        onmessage: function() {},
                        postMessage: function(g) {
                            r({
                                data: g
                            })
                        }
                    },
                    n = {
                        postMessage: function(g) {
                            s.onmessage({
                                data: g
                            })
                        }
                    };

                function f(u) {
                    if (window.Worker && window.Blob && getWebWorker()) {
                        var g = new Blob(["var _workerSelf = self; self.onmessage = ", u.toString()], {
                                type: "text/javascript"
                            }),
                            v = URL.createObjectURL(g);
                        return new Worker(v)
                    }
                    return r = u, s
                }

                function P() {
                    i || (i = f(function(g) {
                        function v() {
                            function S(C, F) {
                                var x, y, T = C.length,
                                    V, M, D, N;
                                for (y = 0; y < T; y += 1)
                                    if (x = C[y], "ks" in x && !x.completed) {
                                        if (x.completed = !0, x.tt && (C[y - 1].td = x.tt), x.hasMask) {
                                            var z = x.masksProperties;
                                            for (M = z.length, V = 0; V < M; V += 1)
                                                if (z[V].pt.k.i) p(z[V].pt.k);
                                                else
                                                    for (N = z[V].pt.k.length, D = 0; D < N; D += 1) z[V].pt.k[D].s && p(z[V].pt.k[D].s[0]), z[V].pt.k[D].e && p(z[V].pt.k[D].e[0])
                                        }
                                        x.ty === 0 ? (x.layers = a(x.refId, F), S(x.layers, F)) : x.ty === 4 ? h(x.shapes) : x.ty === 5 && G(x)
                                    }
                            }

                            function o(C, F) {
                                if (C) {
                                    var x = 0,
                                        y = C.length;
                                    for (x = 0; x < y; x += 1) C[x].t === 1 && (C[x].data.layers = a(C[x].data.refId, F), S(C[x].data.layers, F))
                                }
                            }

                            function l(C, F) {
                                for (var x = 0, y = F.length; x < y;) {
                                    if (F[x].id === C) return F[x];
                                    x += 1
                                }
                                return null
                            }

                            function a(C, F) {
                                var x = l(C, F);
                                return x ? x.layers.__used ? JSON.parse(JSON.stringify(x.layers)) : (x.layers.__used = !0, x.layers) : null
                            }

                            function h(C) {
                                var F, x = C.length,
                                    y, T;
                                for (F = x - 1; F >= 0; F -= 1)
                                    if (C[F].ty === "sh")
                                        if (C[F].ks.k.i) p(C[F].ks.k);
                                        else
                                            for (T = C[F].ks.k.length, y = 0; y < T; y += 1) C[F].ks.k[y].s && p(C[F].ks.k[y].s[0]), C[F].ks.k[y].e && p(C[F].ks.k[y].e[0]);
                                else C[F].ty === "gr" && h(C[F].it)
                            }

                            function p(C) {
                                var F, x = C.i.length;
                                for (F = 0; F < x; F += 1) C.i[F][0] += C.v[F][0], C.i[F][1] += C.v[F][1], C.o[F][0] += C.v[F][0], C.o[F][1] += C.v[F][1]
                            }

                            function c(C, F) {
                                var x = F ? F.split(".") : [100, 100, 100];
                                return C[0] > x[0] ? !0 : x[0] > C[0] ? !1 : C[1] > x[1] ? !0 : x[1] > C[1] ? !1 : C[2] > x[2] ? !0 : x[2] > C[2] ? !1 : null
                            }
                            var b = function() {
                                    var C = [4, 4, 14];

                                    function F(y) {
                                        var T = y.t.d;
                                        y.t.d = {
                                            k: [{
                                                s: T,
                                                t: 0
                                            }]
                                        }
                                    }

                                    function x(y) {
                                        var T, V = y.length;
                                        for (T = 0; T < V; T += 1) y[T].ty === 5 && F(y[T])
                                    }
                                    return function(y) {
                                        if (c(C, y.v) && (x(y.layers), y.assets)) {
                                            var T, V = y.assets.length;
                                            for (T = 0; T < V; T += 1) y.assets[T].layers && x(y.assets[T].layers)
                                        }
                                    }
                                }(),
                                A = function() {
                                    var C = [4, 7, 99];
                                    return function(F) {
                                        if (F.chars && !c(C, F.v)) {
                                            var x, y = F.chars.length;
                                            for (x = 0; x < y; x += 1) {
                                                var T = F.chars[x];
                                                T.data && T.data.shapes && (h(T.data.shapes), T.data.ip = 0, T.data.op = 99999, T.data.st = 0, T.data.sr = 1, T.data.ks = {
                                                    p: {
                                                        k: [0, 0],
                                                        a: 0
                                                    },
                                                    s: {
                                                        k: [100, 100],
                                                        a: 0
                                                    },
                                                    a: {
                                                        k: [0, 0],
                                                        a: 0
                                                    },
                                                    r: {
                                                        k: 0,
                                                        a: 0
                                                    },
                                                    o: {
                                                        k: 100,
                                                        a: 0
                                                    }
                                                }, F.chars[x].t || (T.data.shapes.push({
                                                    ty: "no"
                                                }), T.data.shapes[0].it.push({
                                                    p: {
                                                        k: [0, 0],
                                                        a: 0
                                                    },
                                                    s: {
                                                        k: [100, 100],
                                                        a: 0
                                                    },
                                                    a: {
                                                        k: [0, 0],
                                                        a: 0
                                                    },
                                                    r: {
                                                        k: 0,
                                                        a: 0
                                                    },
                                                    o: {
                                                        k: 100,
                                                        a: 0
                                                    },
                                                    sk: {
                                                        k: 0,
                                                        a: 0
                                                    },
                                                    sa: {
                                                        k: 0,
                                                        a: 0
                                                    },
                                                    ty: "tr"
                                                })))
                                            }
                                        }
                                    }
                                }(),
                                I = function() {
                                    var C = [5, 7, 15];

                                    function F(y) {
                                        var T = y.t.p;
                                        typeof T.a == "number" && (T.a = {
                                            a: 0,
                                            k: T.a
                                        }), typeof T.p == "number" && (T.p = {
                                            a: 0,
                                            k: T.p
                                        }), typeof T.r == "number" && (T.r = {
                                            a: 0,
                                            k: T.r
                                        })
                                    }

                                    function x(y) {
                                        var T, V = y.length;
                                        for (T = 0; T < V; T += 1) y[T].ty === 5 && F(y[T])
                                    }
                                    return function(y) {
                                        if (c(C, y.v) && (x(y.layers), y.assets)) {
                                            var T, V = y.assets.length;
                                            for (T = 0; T < V; T += 1) y.assets[T].layers && x(y.assets[T].layers)
                                        }
                                    }
                                }(),
                                R = function() {
                                    var C = [4, 1, 9];

                                    function F(y) {
                                        var T, V = y.length,
                                            M, D;
                                        for (T = 0; T < V; T += 1)
                                            if (y[T].ty === "gr") F(y[T].it);
                                            else if (y[T].ty === "fl" || y[T].ty === "st")
                                            if (y[T].c.k && y[T].c.k[0].i)
                                                for (D = y[T].c.k.length, M = 0; M < D; M += 1) y[T].c.k[M].s && (y[T].c.k[M].s[0] /= 255, y[T].c.k[M].s[1] /= 255, y[T].c.k[M].s[2] /= 255, y[T].c.k[M].s[3] /= 255), y[T].c.k[M].e && (y[T].c.k[M].e[0] /= 255, y[T].c.k[M].e[1] /= 255, y[T].c.k[M].e[2] /= 255, y[T].c.k[M].e[3] /= 255);
                                            else y[T].c.k[0] /= 255, y[T].c.k[1] /= 255, y[T].c.k[2] /= 255, y[T].c.k[3] /= 255
                                    }

                                    function x(y) {
                                        var T, V = y.length;
                                        for (T = 0; T < V; T += 1) y[T].ty === 4 && F(y[T].shapes)
                                    }
                                    return function(y) {
                                        if (c(C, y.v) && (x(y.layers), y.assets)) {
                                            var T, V = y.assets.length;
                                            for (T = 0; T < V; T += 1) y.assets[T].layers && x(y.assets[T].layers)
                                        }
                                    }
                                }(),
                                L = function() {
                                    var C = [4, 4, 18];

                                    function F(y) {
                                        var T, V = y.length,
                                            M, D;
                                        for (T = V - 1; T >= 0; T -= 1)
                                            if (y[T].ty === "sh")
                                                if (y[T].ks.k.i) y[T].ks.k.c = y[T].closed;
                                                else
                                                    for (D = y[T].ks.k.length, M = 0; M < D; M += 1) y[T].ks.k[M].s && (y[T].ks.k[M].s[0].c = y[T].closed), y[T].ks.k[M].e && (y[T].ks.k[M].e[0].c = y[T].closed);
                                        else y[T].ty === "gr" && F(y[T].it)
                                    }

                                    function x(y) {
                                        var T, V, M = y.length,
                                            D, N, z, H;
                                        for (V = 0; V < M; V += 1) {
                                            if (T = y[V], T.hasMask) {
                                                var j = T.masksProperties;
                                                for (N = j.length, D = 0; D < N; D += 1)
                                                    if (j[D].pt.k.i) j[D].pt.k.c = j[D].cl;
                                                    else
                                                        for (H = j[D].pt.k.length, z = 0; z < H; z += 1) j[D].pt.k[z].s && (j[D].pt.k[z].s[0].c = j[D].cl), j[D].pt.k[z].e && (j[D].pt.k[z].e[0].c = j[D].cl)
                                            }
                                            T.ty === 4 && F(T.shapes)
                                        }
                                    }
                                    return function(y) {
                                        if (c(C, y.v) && (x(y.layers), y.assets)) {
                                            var T, V = y.assets.length;
                                            for (T = 0; T < V; T += 1) y.assets[T].layers && x(y.assets[T].layers)
                                        }
                                    }
                                }();

                            function w(C) {
                                C.__complete || (R(C), b(C), A(C), I(C), L(C), S(C.layers, C.assets), o(C.chars, C.assets), C.__complete = !0)
                            }

                            function G(C) {
                                C.t.a.length === 0 && "m" in C.t.p
                            }
                            var B = {};
                            return B.completeData = w, B.checkColors = R, B.checkChars = A, B.checkPathProperties = I, B.checkShapes = L, B.completeLayers = S, B
                        }
                        if (n.dataManager || (n.dataManager = v()), n.assetLoader || (n.assetLoader = function() {
                                function S(l) {
                                    var a = l.getResponseHeader("content-type");
                                    return a && l.responseType === "json" && a.indexOf("json") !== -1 || l.response && _typeof$5(l.response) === "object" ? l.response : l.response && typeof l.response == "string" ? JSON.parse(l.response) : l.responseText ? JSON.parse(l.responseText) : null
                                }

                                function o(l, a, h, p) {
                                    var c, b = new XMLHttpRequest;
                                    try {
                                        b.responseType = "json"
                                    } catch (A) {}
                                    b.onreadystatechange = function() {
                                        if (b.readyState === 4)
                                            if (b.status === 200) c = S(b), h(c);
                                            else try {
                                                c = S(b), h(c)
                                            } catch (A) {
                                                p && p(A)
                                            }
                                    };
                                    try {
                                        b.open("GET", l, !0)
                                    } catch (A) {
                                        b.open("GET", a + "/" + l, !0)
                                    }
                                    b.send()
                                }
                                return {
                                    load: o
                                }
                            }()), g.data.type === "loadAnimation") n.assetLoader.load(g.data.path, g.data.fullPath, function(S) {
                            n.dataManager.completeData(S), n.postMessage({
                                id: g.data.id,
                                payload: S,
                                status: "success"
                            })
                        }, function() {
                            n.postMessage({
                                id: g.data.id,
                                status: "error"
                            })
                        });
                        else if (g.data.type === "complete") {
                            var m = g.data.animation;
                            n.dataManager.completeData(m), n.postMessage({
                                id: g.data.id,
                                payload: m,
                                status: "success"
                            })
                        } else g.data.type === "loadData" && n.assetLoader.load(g.data.path, g.data.fullPath, function(S) {
                            n.postMessage({
                                id: g.data.id,
                                payload: S,
                                status: "success"
                            })
                        }, function() {
                            n.postMessage({
                                id: g.data.id,
                                status: "error"
                            })
                        })
                    }), i.onmessage = function(u) {
                        var g = u.data,
                            v = g.id,
                            m = e[v];
                        e[v] = null, g.status === "success" ? m.onComplete(g.payload) : m.onError && m.onError()
                    })
                }

                function d(u, g) {
                    t += 1;
                    var v = "processId_" + t;
                    return e[v] = {
                        onComplete: u,
                        onError: g
                    }, v
                }

                function _(u, g, v) {
                    P();
                    var m = d(g, v);
                    i.postMessage({
                        type: "loadAnimation",
                        path: u,
                        fullPath: window.location.origin + window.location.pathname,
                        id: m
                    })
                }

                function E(u, g, v) {
                    P();
                    var m = d(g, v);
                    i.postMessage({
                        type: "loadData",
                        path: u,
                        fullPath: window.location.origin + window.location.pathname,
                        id: m
                    })
                }

                function k(u, g, v) {
                    P();
                    var m = d(g, v);
                    i.postMessage({
                        type: "complete",
                        animation: u,
                        id: m
                    })
                }
                return {
                    loadAnimation: _,
                    loadData: E,
                    completeAnimation: k
                }
            }(),
            ImagePreloader = function() {
                var t = function() {
                    var o = createTag("canvas");
                    o.width = 1, o.height = 1;
                    var l = o.getContext("2d");
                    return l.fillStyle = "rgba(0,0,0,0)", l.fillRect(0, 0, 1, 1), o
                }();

                function e() {
                    this.loadedAssets += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                }

                function r() {
                    this.loadedFootagesCount += 1, this.loadedAssets === this.totalImages && this.loadedFootagesCount === this.totalFootages && this.imagesLoadedCb && this.imagesLoadedCb(null)
                }

                function i(o, l, a) {
                    var h = "";
                    if (o.e) h = o.p;
                    else if (l) {
                        var p = o.p;
                        p.indexOf("images/") !== -1 && (p = p.split("/")[1]), h = l + p
                    } else h = a, h += o.u ? o.u : "", h += o.p;
                    return h
                }

                function s(o) {
                    var l = 0,
                        a = setInterval(function() {
                            var h = o.getBBox();
                            (h.width || l > 500) && (this._imageLoaded(), clearInterval(a)), l += 1
                        }.bind(this), 50)
                }

                function n(o) {
                    var l = i(o, this.assetsPath, this.path),
                        a = createNS("image");
                    isSafari ? this.testImageLoaded(a) : a.addEventListener("load", this._imageLoaded, !1), a.addEventListener("error", function() {
                        h.img = t, this._imageLoaded()
                    }.bind(this), !1), a.setAttributeNS("http://www.w3.org/1999/xlink", "href", l), this._elementHelper.append ? this._elementHelper.append(a) : this._elementHelper.appendChild(a);
                    var h = {
                        img: a,
                        assetData: o
                    };
                    return h
                }

                function f(o) {
                    var l = i(o, this.assetsPath, this.path),
                        a = createTag("img");
                    a.crossOrigin = "anonymous", a.addEventListener("load", this._imageLoaded, !1), a.addEventListener("error", function() {
                        h.img = t, this._imageLoaded()
                    }.bind(this), !1), a.src = l;
                    var h = {
                        img: a,
                        assetData: o
                    };
                    return h
                }

                function P(o) {
                    var l = {
                            assetData: o
                        },
                        a = i(o, this.assetsPath, this.path);
                    return dataManager.loadData(a, function(h) {
                        l.img = h, this._footageLoaded()
                    }.bind(this), function() {
                        l.img = {}, this._footageLoaded()
                    }.bind(this)), l
                }

                function d(o, l) {
                    this.imagesLoadedCb = l;
                    var a, h = o.length;
                    for (a = 0; a < h; a += 1) o[a].layers || (!o[a].t || o[a].t === "seq" ? (this.totalImages += 1, this.images.push(this._createImageData(o[a]))) : o[a].t === 3 && (this.totalFootages += 1, this.images.push(this.createFootageData(o[a]))))
                }

                function _(o) {
                    this.path = o || ""
                }

                function E(o) {
                    this.assetsPath = o || ""
                }

                function k(o) {
                    for (var l = 0, a = this.images.length; l < a;) {
                        if (this.images[l].assetData === o) return this.images[l].img;
                        l += 1
                    }
                    return null
                }

                function u() {
                    this.imagesLoadedCb = null, this.images.length = 0
                }

                function g() {
                    return this.totalImages === this.loadedAssets
                }

                function v() {
                    return this.totalFootages === this.loadedFootagesCount
                }

                function m(o, l) {
                    o === "svg" ? (this._elementHelper = l, this._createImageData = this.createImageData.bind(this)) : this._createImageData = this.createImgData.bind(this)
                }

                function S() {
                    this._imageLoaded = e.bind(this), this._footageLoaded = r.bind(this), this.testImageLoaded = s.bind(this), this.createFootageData = P.bind(this), this.assetsPath = "", this.path = "", this.totalImages = 0, this.totalFootages = 0, this.loadedAssets = 0, this.loadedFootagesCount = 0, this.imagesLoadedCb = null, this.images = []
                }
                return S.prototype = {
                    loadAssets: d,
                    setAssetsPath: E,
                    setPath: _,
                    loadedImages: g,
                    loadedFootages: v,
                    destroy: u,
                    getAsset: k,
                    createImgData: f,
                    createImageData: n,
                    imageLoaded: e,
                    footageLoaded: r,
                    setCacheType: m
                }, S
            }();

        function BaseEvent() {}
        BaseEvent.prototype = {
            triggerEvent: function(e, r) {
                if (this._cbs[e])
                    for (var i = this._cbs[e], s = 0; s < i.length; s += 1) i[s](r)
            },
            addEventListener: function(e, r) {
                return this._cbs[e] || (this._cbs[e] = []), this._cbs[e].push(r),
                    function() {
                        this.removeEventListener(e, r)
                    }.bind(this)
            },
            removeEventListener: function(e, r) {
                if (!r) this._cbs[e] = null;
                else if (this._cbs[e]) {
                    for (var i = 0, s = this._cbs[e].length; i < s;) this._cbs[e][i] === r && (this._cbs[e].splice(i, 1), i -= 1, s -= 1), i += 1;
                    this._cbs[e].length || (this._cbs[e] = null)
                }
            }
        };
        var markerParser = function() {
                function t(e) {
                    for (var r = e.split(`\r
`), i = {}, s, n = 0, f = 0; f < r.length; f += 1) s = r[f].split(":"), s.length === 2 && (i[s[0]] = s[1].trim(), n += 1);
                    if (n === 0) throw new Error;
                    return i
                }
                return function(e) {
                    for (var r = [], i = 0; i < e.length; i += 1) {
                        var s = e[i],
                            n = {
                                time: s.tm,
                                duration: s.dr
                            };
                        try {
                            n.payload = JSON.parse(e[i].cm)
                        } catch (f) {
                            try {
                                n.payload = t(e[i].cm)
                            } catch (P) {
                                n.payload = {
                                    name: e[i]
                                }
                            }
                        }
                        r.push(n)
                    }
                    return r
                }
            }(),
            ProjectInterface = function() {
                function t(e) {
                    this.compositions.push(e)
                }
                return function() {
                    function e(r) {
                        for (var i = 0, s = this.compositions.length; i < s;) {
                            if (this.compositions[i].data && this.compositions[i].data.nm === r) return this.compositions[i].prepareFrame && this.compositions[i].data.xt && this.compositions[i].prepareFrame(this.currentFrame), this.compositions[i].compInterface;
                            i += 1
                        }
                        return null
                    }
                    return e.compositions = [], e.currentFrame = 0, e.registerComposition = t, e
                }
            }(),
            renderers = {},
            registerRenderer = function(e, r) {
                renderers[e] = r
            };

        function getRenderer(t) {
            return renderers[t]
        }

        function _typeof$4(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof$4 = function(r) {
                return typeof r
            } : _typeof$4 = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof$4(t)
        }
        var AnimationItem = function() {
            this._cbs = [], this.name = "", this.path = "", this.isLoaded = !1, this.currentFrame = 0, this.currentRawFrame = 0, this.firstFrame = 0, this.totalFrames = 0, this.frameRate = 0, this.frameMult = 0, this.playSpeed = 1, this.playDirection = 1, this.playCount = 0, this.animationData = {}, this.assets = [], this.isPaused = !0, this.autoplay = !1, this.loop = !0, this.renderer = null, this.animationID = createElementID(), this.assetsPath = "", this.timeCompleted = 0, this.segmentPos = 0, this.isSubframeEnabled = getSubframeEnabled(), this.segments = [], this._idle = !0, this._completedLoop = !1, this.projectInterface = ProjectInterface(), this.imagePreloader = new ImagePreloader, this.audioController = audioControllerFactory(), this.markers = [], this.configAnimation = this.configAnimation.bind(this), this.onSetupError = this.onSetupError.bind(this), this.onSegmentComplete = this.onSegmentComplete.bind(this)
        };
        extendPrototype([BaseEvent], AnimationItem), AnimationItem.prototype.setParams = function(t) {
            (t.wrapper || t.container) && (this.wrapper = t.wrapper || t.container);
            var e = "svg";
            t.animType ? e = t.animType : t.renderer && (e = t.renderer);
            var r = getRenderer(e);
            this.renderer = new r(this, t.rendererSettings), this.imagePreloader.setCacheType(e, this.renderer.globalData.defs), this.renderer.setProjectInterface(this.projectInterface), this.animType = e, t.loop === "" || t.loop === null || t.loop === void 0 || t.loop === !0 ? this.loop = !0 : t.loop === !1 ? this.loop = !1 : this.loop = parseInt(t.loop, 10), this.autoplay = "autoplay" in t ? t.autoplay : !0, this.name = t.name ? t.name : "", this.autoloadSegments = Object.prototype.hasOwnProperty.call(t, "autoloadSegments") ? t.autoloadSegments : !0, this.assetsPath = t.assetsPath, this.initialSegment = t.initialSegment, t.audioFactory && this.audioController.setAudioFactory(t.audioFactory), t.animationData ? this.setupAnimation(t.animationData) : t.path && (t.path.lastIndexOf("\\") !== -1 ? this.path = t.path.substr(0, t.path.lastIndexOf("\\") + 1) : this.path = t.path.substr(0, t.path.lastIndexOf("/") + 1), this.fileName = t.path.substr(t.path.lastIndexOf("/") + 1), this.fileName = this.fileName.substr(0, this.fileName.lastIndexOf(".json")), dataManager.loadAnimation(t.path, this.configAnimation, this.onSetupError))
        }, AnimationItem.prototype.onSetupError = function() {
            this.trigger("data_failed")
        }, AnimationItem.prototype.setupAnimation = function(t) {
            dataManager.completeAnimation(t, this.configAnimation)
        }, AnimationItem.prototype.setData = function(t, e) {
            e && _typeof$4(e) !== "object" && (e = JSON.parse(e));
            var r = {
                    wrapper: t,
                    animationData: e
                },
                i = t.attributes;
            r.path = i.getNamedItem("data-animation-path") ? i.getNamedItem("data-animation-path").value : i.getNamedItem("data-bm-path") ? i.getNamedItem("data-bm-path").value : i.getNamedItem("bm-path") ? i.getNamedItem("bm-path").value : "", r.animType = i.getNamedItem("data-anim-type") ? i.getNamedItem("data-anim-type").value : i.getNamedItem("data-bm-type") ? i.getNamedItem("data-bm-type").value : i.getNamedItem("bm-type") ? i.getNamedItem("bm-type").value : i.getNamedItem("data-bm-renderer") ? i.getNamedItem("data-bm-renderer").value : i.getNamedItem("bm-renderer") ? i.getNamedItem("bm-renderer").value : "canvas";
            var s = i.getNamedItem("data-anim-loop") ? i.getNamedItem("data-anim-loop").value : i.getNamedItem("data-bm-loop") ? i.getNamedItem("data-bm-loop").value : i.getNamedItem("bm-loop") ? i.getNamedItem("bm-loop").value : "";
            s === "false" ? r.loop = !1 : s === "true" ? r.loop = !0 : s !== "" && (r.loop = parseInt(s, 10));
            var n = i.getNamedItem("data-anim-autoplay") ? i.getNamedItem("data-anim-autoplay").value : i.getNamedItem("data-bm-autoplay") ? i.getNamedItem("data-bm-autoplay").value : i.getNamedItem("bm-autoplay") ? i.getNamedItem("bm-autoplay").value : !0;
            r.autoplay = n !== "false", r.name = i.getNamedItem("data-name") ? i.getNamedItem("data-name").value : i.getNamedItem("data-bm-name") ? i.getNamedItem("data-bm-name").value : i.getNamedItem("bm-name") ? i.getNamedItem("bm-name").value : "";
            var f = i.getNamedItem("data-anim-prerender") ? i.getNamedItem("data-anim-prerender").value : i.getNamedItem("data-bm-prerender") ? i.getNamedItem("data-bm-prerender").value : i.getNamedItem("bm-prerender") ? i.getNamedItem("bm-prerender").value : "";
            f === "false" && (r.prerender = !1), this.setParams(r)
        }, AnimationItem.prototype.includeLayers = function(t) {
            t.op > this.animationData.op && (this.animationData.op = t.op, this.totalFrames = Math.floor(t.op - this.animationData.ip));
            var e = this.animationData.layers,
                r, i = e.length,
                s = t.layers,
                n, f = s.length;
            for (n = 0; n < f; n += 1)
                for (r = 0; r < i;) {
                    if (e[r].id === s[n].id) {
                        e[r] = s[n];
                        break
                    }
                    r += 1
                }
            if ((t.chars || t.fonts) && (this.renderer.globalData.fontManager.addChars(t.chars), this.renderer.globalData.fontManager.addFonts(t.fonts, this.renderer.globalData.defs)), t.assets)
                for (i = t.assets.length, r = 0; r < i; r += 1) this.animationData.assets.push(t.assets[r]);
            this.animationData.__complete = !1, dataManager.completeAnimation(this.animationData, this.onSegmentComplete)
        }, AnimationItem.prototype.onSegmentComplete = function(t) {
            this.animationData = t;
            var e = getExpressionsPlugin();
            e && e.initExpressions(this), this.loadNextSegment()
        }, AnimationItem.prototype.loadNextSegment = function() {
            var t = this.animationData.segments;
            if (!t || t.length === 0 || !this.autoloadSegments) {
                this.trigger("data_ready"), this.timeCompleted = this.totalFrames;
                return
            }
            var e = t.shift();
            this.timeCompleted = e.time * this.frameRate;
            var r = this.path + this.fileName + "_" + this.segmentPos + ".json";
            this.segmentPos += 1, dataManager.loadData(r, this.includeLayers.bind(this), function() {
                this.trigger("data_failed")
            }.bind(this))
        }, AnimationItem.prototype.loadSegments = function() {
            var t = this.animationData.segments;
            t || (this.timeCompleted = this.totalFrames), this.loadNextSegment()
        }, AnimationItem.prototype.imagesLoaded = function() {
            this.trigger("loaded_images"), this.checkLoaded()
        }, AnimationItem.prototype.preloadImages = function() {
            this.imagePreloader.setAssetsPath(this.assetsPath), this.imagePreloader.setPath(this.path), this.imagePreloader.loadAssets(this.animationData.assets, this.imagesLoaded.bind(this))
        }, AnimationItem.prototype.configAnimation = function(t) {
            if (!!this.renderer) try {
                this.animationData = t, this.initialSegment ? (this.totalFrames = Math.floor(this.initialSegment[1] - this.initialSegment[0]), this.firstFrame = Math.round(this.initialSegment[0])) : (this.totalFrames = Math.floor(this.animationData.op - this.animationData.ip), this.firstFrame = Math.round(this.animationData.ip)), this.renderer.configAnimation(t), t.assets || (t.assets = []), this.assets = this.animationData.assets, this.frameRate = this.animationData.fr, this.frameMult = this.animationData.fr / 1e3, this.renderer.searchExtraCompositions(t.assets), this.markers = markerParser(t.markers || []), this.trigger("config_ready"), this.preloadImages(), this.loadSegments(), this.updaFrameModifier(), this.waitForFontsLoaded(), this.isPaused && this.audioController.pause()
            } catch (e) {
                this.triggerConfigError(e)
            }
        }, AnimationItem.prototype.waitForFontsLoaded = function() {
            !this.renderer || (this.renderer.globalData.fontManager.isLoaded ? this.checkLoaded() : setTimeout(this.waitForFontsLoaded.bind(this), 20))
        }, AnimationItem.prototype.checkLoaded = function() {
            if (!this.isLoaded && this.renderer.globalData.fontManager.isLoaded && (this.imagePreloader.loadedImages() || this.renderer.rendererType !== "canvas") && this.imagePreloader.loadedFootages()) {
                this.isLoaded = !0;
                var t = getExpressionsPlugin();
                t && t.initExpressions(this), this.renderer.initItems(), setTimeout(function() {
                    this.trigger("DOMLoaded")
                }.bind(this), 0), this.gotoFrame(), this.autoplay && this.play()
            }
        }, AnimationItem.prototype.resize = function() {
            this.renderer.updateContainerSize()
        }, AnimationItem.prototype.setSubframe = function(t) {
            this.isSubframeEnabled = !!t
        }, AnimationItem.prototype.gotoFrame = function() {
            this.currentFrame = this.isSubframeEnabled ? this.currentRawFrame : ~~this.currentRawFrame, this.timeCompleted !== this.totalFrames && this.currentFrame > this.timeCompleted && (this.currentFrame = this.timeCompleted), this.trigger("enterFrame"), this.renderFrame(), this.trigger("drawnFrame")
        }, AnimationItem.prototype.renderFrame = function() {
            if (!(this.isLoaded === !1 || !this.renderer)) try {
                this.renderer.renderFrame(this.currentFrame + this.firstFrame)
            } catch (t) {
                this.triggerRenderFrameError(t)
            }
        }, AnimationItem.prototype.play = function(t) {
            t && this.name !== t || this.isPaused === !0 && (this.isPaused = !1, this.audioController.resume(), this._idle && (this._idle = !1, this.trigger("_active")))
        }, AnimationItem.prototype.pause = function(t) {
            t && this.name !== t || this.isPaused === !1 && (this.isPaused = !0, this._idle = !0, this.trigger("_idle"), this.audioController.pause())
        }, AnimationItem.prototype.togglePause = function(t) {
            t && this.name !== t || (this.isPaused === !0 ? this.play() : this.pause())
        }, AnimationItem.prototype.stop = function(t) {
            t && this.name !== t || (this.pause(), this.playCount = 0, this._completedLoop = !1, this.setCurrentRawFrameValue(0))
        }, AnimationItem.prototype.getMarkerData = function(t) {
            for (var e, r = 0; r < this.markers.length; r += 1)
                if (e = this.markers[r], e.payload && e.payload.name.cm === t) return e;
            return null
        }, AnimationItem.prototype.goToAndStop = function(t, e, r) {
            if (!(r && this.name !== r)) {
                var i = Number(t);
                if (isNaN(i)) {
                    var s = this.getMarkerData(t);
                    s && this.goToAndStop(s.time, !0)
                } else e ? this.setCurrentRawFrameValue(t) : this.setCurrentRawFrameValue(t * this.frameModifier);
                this.pause()
            }
        }, AnimationItem.prototype.goToAndPlay = function(t, e, r) {
            if (!(r && this.name !== r)) {
                var i = Number(t);
                if (isNaN(i)) {
                    var s = this.getMarkerData(t);
                    s && (s.duration ? this.playSegments([s.time, s.time + s.duration], !0) : this.goToAndStop(s.time, !0))
                } else this.goToAndStop(i, e, r);
                this.play()
            }
        }, AnimationItem.prototype.advanceTime = function(t) {
            if (!(this.isPaused === !0 || this.isLoaded === !1)) {
                var e = this.currentRawFrame + t * this.frameModifier,
                    r = !1;
                e >= this.totalFrames - 1 && this.frameModifier > 0 ? !this.loop || this.playCount === this.loop ? this.checkSegments(e > this.totalFrames ? e % this.totalFrames : 0) || (r = !0, e = this.totalFrames - 1) : e >= this.totalFrames ? (this.playCount += 1, this.checkSegments(e % this.totalFrames) || (this.setCurrentRawFrameValue(e % this.totalFrames), this._completedLoop = !0, this.trigger("loopComplete"))) : this.setCurrentRawFrameValue(e) : e < 0 ? this.checkSegments(e % this.totalFrames) || (this.loop && !(this.playCount-- <= 0 && this.loop !== !0) ? (this.setCurrentRawFrameValue(this.totalFrames + e % this.totalFrames), this._completedLoop ? this.trigger("loopComplete") : this._completedLoop = !0) : (r = !0, e = 0)) : this.setCurrentRawFrameValue(e), r && (this.setCurrentRawFrameValue(e), this.pause(), this.trigger("complete"))
            }
        }, AnimationItem.prototype.adjustSegment = function(t, e) {
            this.playCount = 0, t[1] < t[0] ? (this.frameModifier > 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(-1)), this.totalFrames = t[0] - t[1], this.timeCompleted = this.totalFrames, this.firstFrame = t[1], this.setCurrentRawFrameValue(this.totalFrames - .001 - e)) : t[1] > t[0] && (this.frameModifier < 0 && (this.playSpeed < 0 ? this.setSpeed(-this.playSpeed) : this.setDirection(1)), this.totalFrames = t[1] - t[0], this.timeCompleted = this.totalFrames, this.firstFrame = t[0], this.setCurrentRawFrameValue(.001 + e)), this.trigger("segmentStart")
        }, AnimationItem.prototype.setSegment = function(t, e) {
            var r = -1;
            this.isPaused && (this.currentRawFrame + this.firstFrame < t ? r = t : this.currentRawFrame + this.firstFrame > e && (r = e - t)), this.firstFrame = t, this.totalFrames = e - t, this.timeCompleted = this.totalFrames, r !== -1 && this.goToAndStop(r, !0)
        }, AnimationItem.prototype.playSegments = function(t, e) {
            if (e && (this.segments.length = 0), _typeof$4(t[0]) === "object") {
                var r, i = t.length;
                for (r = 0; r < i; r += 1) this.segments.push(t[r])
            } else this.segments.push(t);
            this.segments.length && e && this.adjustSegment(this.segments.shift(), 0), this.isPaused && this.play()
        }, AnimationItem.prototype.resetSegments = function(t) {
            this.segments.length = 0, this.segments.push([this.animationData.ip, this.animationData.op]), t && this.checkSegments(0)
        }, AnimationItem.prototype.checkSegments = function(t) {
            return this.segments.length ? (this.adjustSegment(this.segments.shift(), t), !0) : !1
        }, AnimationItem.prototype.destroy = function(t) {
            t && this.name !== t || !this.renderer || (this.renderer.destroy(), this.imagePreloader.destroy(), this.trigger("destroy"), this._cbs = null, this.onEnterFrame = null, this.onLoopComplete = null, this.onComplete = null, this.onSegmentStart = null, this.onDestroy = null, this.renderer = null, this.renderer = null, this.imagePreloader = null, this.projectInterface = null)
        }, AnimationItem.prototype.setCurrentRawFrameValue = function(t) {
            this.currentRawFrame = t, this.gotoFrame()
        }, AnimationItem.prototype.setSpeed = function(t) {
            this.playSpeed = t, this.updaFrameModifier()
        }, AnimationItem.prototype.setDirection = function(t) {
            this.playDirection = t < 0 ? -1 : 1, this.updaFrameModifier()
        }, AnimationItem.prototype.setVolume = function(t, e) {
            e && this.name !== e || this.audioController.setVolume(t)
        }, AnimationItem.prototype.getVolume = function() {
            return this.audioController.getVolume()
        }, AnimationItem.prototype.mute = function(t) {
            t && this.name !== t || this.audioController.mute()
        }, AnimationItem.prototype.unmute = function(t) {
            t && this.name !== t || this.audioController.unmute()
        }, AnimationItem.prototype.updaFrameModifier = function() {
            this.frameModifier = this.frameMult * this.playSpeed * this.playDirection, this.audioController.setRate(this.playSpeed * this.playDirection)
        }, AnimationItem.prototype.getPath = function() {
            return this.path
        }, AnimationItem.prototype.getAssetsPath = function(t) {
            var e = "";
            if (t.e) e = t.p;
            else if (this.assetsPath) {
                var r = t.p;
                r.indexOf("images/") !== -1 && (r = r.split("/")[1]), e = this.assetsPath + r
            } else e = this.path, e += t.u ? t.u : "", e += t.p;
            return e
        }, AnimationItem.prototype.getAssetData = function(t) {
            for (var e = 0, r = this.assets.length; e < r;) {
                if (t === this.assets[e].id) return this.assets[e];
                e += 1
            }
            return null
        }, AnimationItem.prototype.hide = function() {
            this.renderer.hide()
        }, AnimationItem.prototype.show = function() {
            this.renderer.show()
        }, AnimationItem.prototype.getDuration = function(t) {
            return t ? this.totalFrames : this.totalFrames / this.frameRate
        }, AnimationItem.prototype.trigger = function(t) {
            if (this._cbs && this._cbs[t]) switch (t) {
                case "enterFrame":
                case "drawnFrame":
                    this.triggerEvent(t, new BMEnterFrameEvent(t, this.currentFrame, this.totalFrames, this.frameModifier));
                    break;
                case "loopComplete":
                    this.triggerEvent(t, new BMCompleteLoopEvent(t, this.loop, this.playCount, this.frameMult));
                    break;
                case "complete":
                    this.triggerEvent(t, new BMCompleteEvent(t, this.frameMult));
                    break;
                case "segmentStart":
                    this.triggerEvent(t, new BMSegmentStartEvent(t, this.firstFrame, this.totalFrames));
                    break;
                case "destroy":
                    this.triggerEvent(t, new BMDestroyEvent(t, this));
                    break;
                default:
                    this.triggerEvent(t)
            }
            t === "enterFrame" && this.onEnterFrame && this.onEnterFrame.call(this, new BMEnterFrameEvent(t, this.currentFrame, this.totalFrames, this.frameMult)), t === "loopComplete" && this.onLoopComplete && this.onLoopComplete.call(this, new BMCompleteLoopEvent(t, this.loop, this.playCount, this.frameMult)), t === "complete" && this.onComplete && this.onComplete.call(this, new BMCompleteEvent(t, this.frameMult)), t === "segmentStart" && this.onSegmentStart && this.onSegmentStart.call(this, new BMSegmentStartEvent(t, this.firstFrame, this.totalFrames)), t === "destroy" && this.onDestroy && this.onDestroy.call(this, new BMDestroyEvent(t, this))
        }, AnimationItem.prototype.triggerRenderFrameError = function(t) {
            var e = new BMRenderFrameErrorEvent(t, this.currentFrame);
            this.triggerEvent("error", e), this.onError && this.onError.call(this, e)
        }, AnimationItem.prototype.triggerConfigError = function(t) {
            var e = new BMConfigErrorEvent(t, this.currentFrame);
            this.triggerEvent("error", e), this.onError && this.onError.call(this, e)
        };
        var animationManager = function() {
                var t = {},
                    e = [],
                    r = 0,
                    i = 0,
                    s = 0,
                    n = !0,
                    f = !1;

                function P(F) {
                    for (var x = 0, y = F.target; x < i;) e[x].animation === y && (e.splice(x, 1), x -= 1, i -= 1, y.isPaused || k()), x += 1
                }

                function d(F, x) {
                    if (!F) return null;
                    for (var y = 0; y < i;) {
                        if (e[y].elem === F && e[y].elem !== null) return e[y].animation;
                        y += 1
                    }
                    var T = new AnimationItem;
                    return u(T, F), T.setData(F, x), T
                }

                function _() {
                    var F, x = e.length,
                        y = [];
                    for (F = 0; F < x; F += 1) y.push(e[F].animation);
                    return y
                }

                function E() {
                    s += 1, R()
                }

                function k() {
                    s -= 1
                }

                function u(F, x) {
                    F.addEventListener("destroy", P), F.addEventListener("_active", E), F.addEventListener("_idle", k), e.push({
                        elem: x,
                        animation: F
                    }), i += 1
                }

                function g(F) {
                    var x = new AnimationItem;
                    return u(x, null), x.setParams(F), x
                }

                function v(F, x) {
                    var y;
                    for (y = 0; y < i; y += 1) e[y].animation.setSpeed(F, x)
                }

                function m(F, x) {
                    var y;
                    for (y = 0; y < i; y += 1) e[y].animation.setDirection(F, x)
                }

                function S(F) {
                    var x;
                    for (x = 0; x < i; x += 1) e[x].animation.play(F)
                }

                function o(F) {
                    var x = F - r,
                        y;
                    for (y = 0; y < i; y += 1) e[y].animation.advanceTime(x);
                    r = F, s && !f ? window.requestAnimationFrame(o) : n = !0
                }

                function l(F) {
                    r = F, window.requestAnimationFrame(o)
                }

                function a(F) {
                    var x;
                    for (x = 0; x < i; x += 1) e[x].animation.pause(F)
                }

                function h(F, x, y) {
                    var T;
                    for (T = 0; T < i; T += 1) e[T].animation.goToAndStop(F, x, y)
                }

                function p(F) {
                    var x;
                    for (x = 0; x < i; x += 1) e[x].animation.stop(F)
                }

                function c(F) {
                    var x;
                    for (x = 0; x < i; x += 1) e[x].animation.togglePause(F)
                }

                function b(F) {
                    var x;
                    for (x = i - 1; x >= 0; x -= 1) e[x].animation.destroy(F)
                }

                function A(F, x, y) {
                    var T = [].concat([].slice.call(document.getElementsByClassName("lottie")), [].slice.call(document.getElementsByClassName("bodymovin"))),
                        V, M = T.length;
                    for (V = 0; V < M; V += 1) y && T[V].setAttribute("data-bm-type", y), d(T[V], F);
                    if (x && M === 0) {
                        y || (y = "svg");
                        var D = document.getElementsByTagName("body")[0];
                        D.innerText = "";
                        var N = createTag("div");
                        N.style.width = "100%", N.style.height = "100%", N.setAttribute("data-bm-type", y), D.appendChild(N), d(N, F)
                    }
                }

                function I() {
                    var F;
                    for (F = 0; F < i; F += 1) e[F].animation.resize()
                }

                function R() {
                    !f && s && n && (window.requestAnimationFrame(l), n = !1)
                }

                function L() {
                    f = !0
                }

                function w() {
                    f = !1, R()
                }

                function G(F, x) {
                    var y;
                    for (y = 0; y < i; y += 1) e[y].animation.setVolume(F, x)
                }

                function B(F) {
                    var x;
                    for (x = 0; x < i; x += 1) e[x].animation.mute(F)
                }

                function C(F) {
                    var x;
                    for (x = 0; x < i; x += 1) e[x].animation.unmute(F)
                }
                return t.registerAnimation = d, t.loadAnimation = g, t.setSpeed = v, t.setDirection = m, t.play = S, t.pause = a, t.stop = p, t.togglePause = c, t.searchAnimations = A, t.resize = I, t.goToAndStop = h, t.destroy = b, t.freeze = L, t.unfreeze = w, t.setVolume = G, t.mute = B, t.unmute = C, t.getRegisteredAnimations = _, t
            }(),
            BezierFactory = function() {
                var t = {};
                t.getBezierEasing = r;
                var e = {};

                function r(l, a, h, p, c) {
                    var b = c || ("bez_" + l + "_" + a + "_" + h + "_" + p).replace(/\./g, "p");
                    if (e[b]) return e[b];
                    var A = new o([l, a, h, p]);
                    return e[b] = A, A
                }
                var i = 4,
                    s = .001,
                    n = 1e-7,
                    f = 10,
                    P = 11,
                    d = 1 / (P - 1),
                    _ = typeof Float32Array == "function";

                function E(l, a) {
                    return 1 - 3 * a + 3 * l
                }

                function k(l, a) {
                    return 3 * a - 6 * l
                }

                function u(l) {
                    return 3 * l
                }

                function g(l, a, h) {
                    return ((E(a, h) * l + k(a, h)) * l + u(a)) * l
                }

                function v(l, a, h) {
                    return 3 * E(a, h) * l * l + 2 * k(a, h) * l + u(a)
                }

                function m(l, a, h, p, c) {
                    var b, A, I = 0;
                    do A = a + (h - a) / 2, b = g(A, p, c) - l, b > 0 ? h = A : a = A; while (Math.abs(b) > n && ++I < f);
                    return A
                }

                function S(l, a, h, p) {
                    for (var c = 0; c < i; ++c) {
                        var b = v(a, h, p);
                        if (b === 0) return a;
                        var A = g(a, h, p) - l;
                        a -= A / b
                    }
                    return a
                }

                function o(l) {
                    this._p = l, this._mSampleValues = _ ? new Float32Array(P) : new Array(P), this._precomputed = !1, this.get = this.get.bind(this)
                }
                return o.prototype = {
                    get: function(a) {
                        var h = this._p[0],
                            p = this._p[1],
                            c = this._p[2],
                            b = this._p[3];
                        return this._precomputed || this._precompute(), h === p && c === b ? a : a === 0 ? 0 : a === 1 ? 1 : g(this._getTForX(a), p, b)
                    },
                    _precompute: function() {
                        var a = this._p[0],
                            h = this._p[1],
                            p = this._p[2],
                            c = this._p[3];
                        this._precomputed = !0, (a !== h || p !== c) && this._calcSampleValues()
                    },
                    _calcSampleValues: function() {
                        for (var a = this._p[0], h = this._p[2], p = 0; p < P; ++p) this._mSampleValues[p] = g(p * d, a, h)
                    },
                    _getTForX: function(a) {
                        for (var h = this._p[0], p = this._p[2], c = this._mSampleValues, b = 0, A = 1, I = P - 1; A !== I && c[A] <= a; ++A) b += d;
                        --A;
                        var R = (a - c[A]) / (c[A + 1] - c[A]),
                            L = b + R * d,
                            w = v(L, h, p);
                        return w >= s ? S(a, L, h, p) : w === 0 ? L : m(a, b, b + d, h, p)
                    }
                }, t
            }(),
            pooling = function() {
                function t(e) {
                    return e.concat(createSizedArray(e.length))
                }
                return {
                    double: t
                }
            }(),
            poolFactory = function() {
                return function(t, e, r) {
                    var i = 0,
                        s = t,
                        n = createSizedArray(s),
                        f = {
                            newElement: P,
                            release: d
                        };

                    function P() {
                        var _;
                        return i ? (i -= 1, _ = n[i]) : _ = e(), _
                    }

                    function d(_) {
                        i === s && (n = pooling.double(n), s *= 2), r && r(_), n[i] = _, i += 1
                    }
                    return f
                }
            }(),
            bezierLengthPool = function() {
                function t() {
                    return {
                        addedLength: 0,
                        percents: createTypedArray("float32", getDefaultCurveSegments()),
                        lengths: createTypedArray("float32", getDefaultCurveSegments())
                    }
                }
                return poolFactory(8, t)
            }(),
            segmentsLengthPool = function() {
                function t() {
                    return {
                        lengths: [],
                        totalLength: 0
                    }
                }

                function e(r) {
                    var i, s = r.lengths.length;
                    for (i = 0; i < s; i += 1) bezierLengthPool.release(r.lengths[i]);
                    r.lengths.length = 0
                }
                return poolFactory(8, t, e)
            }();

        function bezFunction() {
            var t = Math;

            function e(u, g, v, m, S, o) {
                var l = u * m + g * S + v * o - S * m - o * u - v * g;
                return l > -.001 && l < .001
            }

            function r(u, g, v, m, S, o, l, a, h) {
                if (v === 0 && o === 0 && h === 0) return e(u, g, m, S, l, a);
                var p = t.sqrt(t.pow(m - u, 2) + t.pow(S - g, 2) + t.pow(o - v, 2)),
                    c = t.sqrt(t.pow(l - u, 2) + t.pow(a - g, 2) + t.pow(h - v, 2)),
                    b = t.sqrt(t.pow(l - m, 2) + t.pow(a - S, 2) + t.pow(h - o, 2)),
                    A;
                return p > c ? p > b ? A = p - c - b : A = b - c - p : b > c ? A = b - c - p : A = c - p - b, A > -1e-4 && A < 1e-4
            }
            var i = function() {
                return function(u, g, v, m) {
                    var S = getDefaultCurveSegments(),
                        o, l, a, h, p, c = 0,
                        b, A = [],
                        I = [],
                        R = bezierLengthPool.newElement();
                    for (a = v.length, o = 0; o < S; o += 1) {
                        for (p = o / (S - 1), b = 0, l = 0; l < a; l += 1) h = bmPow(1 - p, 3) * u[l] + 3 * bmPow(1 - p, 2) * p * v[l] + 3 * (1 - p) * bmPow(p, 2) * m[l] + bmPow(p, 3) * g[l], A[l] = h, I[l] !== null && (b += bmPow(A[l] - I[l], 2)), I[l] = A[l];
                        b && (b = bmSqrt(b), c += b), R.percents[o] = p, R.lengths[o] = c
                    }
                    return R.addedLength = c, R
                }
            }();

            function s(u) {
                var g = segmentsLengthPool.newElement(),
                    v = u.c,
                    m = u.v,
                    S = u.o,
                    o = u.i,
                    l, a = u._length,
                    h = g.lengths,
                    p = 0;
                for (l = 0; l < a - 1; l += 1) h[l] = i(m[l], m[l + 1], S[l], o[l + 1]), p += h[l].addedLength;
                return v && a && (h[l] = i(m[l], m[0], S[l], o[0]), p += h[l].addedLength), g.totalLength = p, g
            }

            function n(u) {
                this.segmentLength = 0, this.points = new Array(u)
            }

            function f(u, g) {
                this.partialLength = u, this.point = g
            }
            var P = function() {
                var u = {};
                return function(g, v, m, S) {
                    var o = (g[0] + "_" + g[1] + "_" + v[0] + "_" + v[1] + "_" + m[0] + "_" + m[1] + "_" + S[0] + "_" + S[1]).replace(/\./g, "p");
                    if (!u[o]) {
                        var l = getDefaultCurveSegments(),
                            a, h, p, c, b, A = 0,
                            I, R, L = null;
                        g.length === 2 && (g[0] !== v[0] || g[1] !== v[1]) && e(g[0], g[1], v[0], v[1], g[0] + m[0], g[1] + m[1]) && e(g[0], g[1], v[0], v[1], v[0] + S[0], v[1] + S[1]) && (l = 2);
                        var w = new n(l);
                        for (p = m.length, a = 0; a < l; a += 1) {
                            for (R = createSizedArray(p), b = a / (l - 1), I = 0, h = 0; h < p; h += 1) c = bmPow(1 - b, 3) * g[h] + 3 * bmPow(1 - b, 2) * b * (g[h] + m[h]) + 3 * (1 - b) * bmPow(b, 2) * (v[h] + S[h]) + bmPow(b, 3) * v[h], R[h] = c, L !== null && (I += bmPow(R[h] - L[h], 2));
                            I = bmSqrt(I), A += I, w.points[a] = new f(I, R), L = R
                        }
                        w.segmentLength = A, u[o] = w
                    }
                    return u[o]
                }
            }();

            function d(u, g) {
                var v = g.percents,
                    m = g.lengths,
                    S = v.length,
                    o = bmFloor((S - 1) * u),
                    l = u * g.addedLength,
                    a = 0;
                if (o === S - 1 || o === 0 || l === m[o]) return v[o];
                for (var h = m[o] > l ? -1 : 1, p = !0; p;)
                    if (m[o] <= l && m[o + 1] > l ? (a = (l - m[o]) / (m[o + 1] - m[o]), p = !1) : o += h, o < 0 || o >= S - 1) {
                        if (o === S - 1) return v[o];
                        p = !1
                    }
                return v[o] + (v[o + 1] - v[o]) * a
            }

            function _(u, g, v, m, S, o) {
                var l = d(S, o),
                    a = 1 - l,
                    h = t.round((a * a * a * u[0] + (l * a * a + a * l * a + a * a * l) * v[0] + (l * l * a + a * l * l + l * a * l) * m[0] + l * l * l * g[0]) * 1e3) / 1e3,
                    p = t.round((a * a * a * u[1] + (l * a * a + a * l * a + a * a * l) * v[1] + (l * l * a + a * l * l + l * a * l) * m[1] + l * l * l * g[1]) * 1e3) / 1e3;
                return [h, p]
            }
            var E = createTypedArray("float32", 8);

            function k(u, g, v, m, S, o, l) {
                S < 0 ? S = 0 : S > 1 && (S = 1);
                var a = d(S, l);
                o = o > 1 ? 1 : o;
                var h = d(o, l),
                    p, c = u.length,
                    b = 1 - a,
                    A = 1 - h,
                    I = b * b * b,
                    R = a * b * b * 3,
                    L = a * a * b * 3,
                    w = a * a * a,
                    G = b * b * A,
                    B = a * b * A + b * a * A + b * b * h,
                    C = a * a * A + b * a * h + a * b * h,
                    F = a * a * h,
                    x = b * A * A,
                    y = a * A * A + b * h * A + b * A * h,
                    T = a * h * A + b * h * h + a * A * h,
                    V = a * h * h,
                    M = A * A * A,
                    D = h * A * A + A * h * A + A * A * h,
                    N = h * h * A + A * h * h + h * A * h,
                    z = h * h * h;
                for (p = 0; p < c; p += 1) E[p * 4] = t.round((I * u[p] + R * v[p] + L * m[p] + w * g[p]) * 1e3) / 1e3, E[p * 4 + 1] = t.round((G * u[p] + B * v[p] + C * m[p] + F * g[p]) * 1e3) / 1e3, E[p * 4 + 2] = t.round((x * u[p] + y * v[p] + T * m[p] + V * g[p]) * 1e3) / 1e3, E[p * 4 + 3] = t.round((M * u[p] + D * v[p] + N * m[p] + z * g[p]) * 1e3) / 1e3;
                return E
            }
            return {
                getSegmentsLength: s,
                getNewSegment: k,
                getPointInSegment: _,
                buildBezierData: P,
                pointOnLine2D: e,
                pointOnLine3D: r
            }
        }
        var bez = bezFunction(),
            PropertyFactory = function() {
                var t = initialDefaultFrame,
                    e = Math.abs;

                function r(S, o) {
                    var l = this.offsetTime,
                        a;
                    this.propType === "multidimensional" && (a = createTypedArray("float32", this.pv.length));
                    for (var h = o.lastIndex, p = h, c = this.keyframes.length - 1, b = !0, A, I, R; b;) {
                        if (A = this.keyframes[p], I = this.keyframes[p + 1], p === c - 1 && S >= I.t - l) {
                            A.h && (A = I), h = 0;
                            break
                        }
                        if (I.t - l > S) {
                            h = p;
                            break
                        }
                        p < c - 1 ? p += 1 : (h = 0, b = !1)
                    }
                    R = this.keyframesMetadata[p] || {};
                    var L, w, G, B, C, F, x = I.t - l,
                        y = A.t - l,
                        T;
                    if (A.to) {
                        R.bezierData || (R.bezierData = bez.buildBezierData(A.s, I.s || A.e, A.to, A.ti));
                        var V = R.bezierData;
                        if (S >= x || S < y) {
                            var M = S >= x ? V.points.length - 1 : 0;
                            for (w = V.points[M].point.length, L = 0; L < w; L += 1) a[L] = V.points[M].point[L]
                        } else {
                            R.__fnct ? F = R.__fnct : (F = BezierFactory.getBezierEasing(A.o.x, A.o.y, A.i.x, A.i.y, A.n).get, R.__fnct = F), G = F((S - y) / (x - y));
                            var D = V.segmentLength * G,
                                N, z = o.lastFrame < S && o._lastKeyframeIndex === p ? o._lastAddedLength : 0;
                            for (C = o.lastFrame < S && o._lastKeyframeIndex === p ? o._lastPoint : 0, b = !0, B = V.points.length; b;) {
                                if (z += V.points[C].partialLength, D === 0 || G === 0 || C === V.points.length - 1) {
                                    for (w = V.points[C].point.length, L = 0; L < w; L += 1) a[L] = V.points[C].point[L];
                                    break
                                } else if (D >= z && D < z + V.points[C + 1].partialLength) {
                                    for (N = (D - z) / V.points[C + 1].partialLength, w = V.points[C].point.length, L = 0; L < w; L += 1) a[L] = V.points[C].point[L] + (V.points[C + 1].point[L] - V.points[C].point[L]) * N;
                                    break
                                }
                                C < B - 1 ? C += 1 : b = !1
                            }
                            o._lastPoint = C, o._lastAddedLength = z - V.points[C].partialLength, o._lastKeyframeIndex = p
                        }
                    } else {
                        var H, j, X, K, U;
                        if (c = A.s.length, T = I.s || A.e, this.sh && A.h !== 1)
                            if (S >= x) a[0] = T[0], a[1] = T[1], a[2] = T[2];
                            else if (S <= y) a[0] = A.s[0], a[1] = A.s[1], a[2] = A.s[2];
                        else {
                            var $ = n(A.s),
                                q = n(T),
                                Y = (S - y) / (x - y);
                            s(a, i($, q, Y))
                        } else
                            for (p = 0; p < c; p += 1) A.h !== 1 && (S >= x ? G = 1 : S < y ? G = 0 : (A.o.x.constructor === Array ? (R.__fnct || (R.__fnct = []), R.__fnct[p] ? F = R.__fnct[p] : (H = A.o.x[p] === void 0 ? A.o.x[0] : A.o.x[p], j = A.o.y[p] === void 0 ? A.o.y[0] : A.o.y[p], X = A.i.x[p] === void 0 ? A.i.x[0] : A.i.x[p], K = A.i.y[p] === void 0 ? A.i.y[0] : A.i.y[p], F = BezierFactory.getBezierEasing(H, j, X, K).get, R.__fnct[p] = F)) : R.__fnct ? F = R.__fnct : (H = A.o.x, j = A.o.y, X = A.i.x, K = A.i.y, F = BezierFactory.getBezierEasing(H, j, X, K).get, A.keyframeMetadata = F), G = F((S - y) / (x - y)))), T = I.s || A.e, U = A.h === 1 ? A.s[p] : A.s[p] + (T[p] - A.s[p]) * G, this.propType === "multidimensional" ? a[p] = U : a = U
                    }
                    return o.lastIndex = h, a
                }

                function i(S, o, l) {
                    var a = [],
                        h = S[0],
                        p = S[1],
                        c = S[2],
                        b = S[3],
                        A = o[0],
                        I = o[1],
                        R = o[2],
                        L = o[3],
                        w, G, B, C, F;
                    return G = h * A + p * I + c * R + b * L, G < 0 && (G = -G, A = -A, I = -I, R = -R, L = -L), 1 - G > 1e-6 ? (w = Math.acos(G), B = Math.sin(w), C = Math.sin((1 - l) * w) / B, F = Math.sin(l * w) / B) : (C = 1 - l, F = l), a[0] = C * h + F * A, a[1] = C * p + F * I, a[2] = C * c + F * R, a[3] = C * b + F * L, a
                }

                function s(S, o) {
                    var l = o[0],
                        a = o[1],
                        h = o[2],
                        p = o[3],
                        c = Math.atan2(2 * a * p - 2 * l * h, 1 - 2 * a * a - 2 * h * h),
                        b = Math.asin(2 * l * a + 2 * h * p),
                        A = Math.atan2(2 * l * p - 2 * a * h, 1 - 2 * l * l - 2 * h * h);
                    S[0] = c / degToRads, S[1] = b / degToRads, S[2] = A / degToRads
                }

                function n(S) {
                    var o = S[0] * degToRads,
                        l = S[1] * degToRads,
                        a = S[2] * degToRads,
                        h = Math.cos(o / 2),
                        p = Math.cos(l / 2),
                        c = Math.cos(a / 2),
                        b = Math.sin(o / 2),
                        A = Math.sin(l / 2),
                        I = Math.sin(a / 2),
                        R = h * p * c - b * A * I,
                        L = b * A * c + h * p * I,
                        w = b * p * c + h * A * I,
                        G = h * A * c - b * p * I;
                    return [L, w, G, R]
                }

                function f() {
                    var S = this.comp.renderedFrame - this.offsetTime,
                        o = this.keyframes[0].t - this.offsetTime,
                        l = this.keyframes[this.keyframes.length - 1].t - this.offsetTime;
                    if (!(S === this._caching.lastFrame || this._caching.lastFrame !== t && (this._caching.lastFrame >= l && S >= l || this._caching.lastFrame < o && S < o))) {
                        this._caching.lastFrame >= S && (this._caching._lastKeyframeIndex = -1, this._caching.lastIndex = 0);
                        var a = this.interpolateValue(S, this._caching);
                        this.pv = a
                    }
                    return this._caching.lastFrame = S, this.pv
                }

                function P(S) {
                    var o;
                    if (this.propType === "unidimensional") o = S * this.mult, e(this.v - o) > 1e-5 && (this.v = o, this._mdf = !0);
                    else
                        for (var l = 0, a = this.v.length; l < a;) o = S[l] * this.mult, e(this.v[l] - o) > 1e-5 && (this.v[l] = o, this._mdf = !0), l += 1
                }

                function d() {
                    if (!(this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length)) {
                        if (this.lock) {
                            this.setVValue(this.pv);
                            return
                        }
                        this.lock = !0, this._mdf = this._isFirstFrame;
                        var S, o = this.effectsSequence.length,
                            l = this.kf ? this.pv : this.data.k;
                        for (S = 0; S < o; S += 1) l = this.effectsSequence[S](l);
                        this.setVValue(l), this._isFirstFrame = !1, this.lock = !1, this.frameId = this.elem.globalData.frameId
                    }
                }

                function _(S) {
                    this.effectsSequence.push(S), this.container.addDynamicProperty(this)
                }

                function E(S, o, l, a) {
                    this.propType = "unidimensional", this.mult = l || 1, this.data = o, this.v = l ? o.k * l : o.k, this.pv = o.k, this._mdf = !1, this.elem = S, this.container = a, this.comp = S.comp, this.k = !1, this.kf = !1, this.vel = 0, this.effectsSequence = [], this._isFirstFrame = !0, this.getValue = d, this.setVValue = P, this.addEffect = _
                }

                function k(S, o, l, a) {
                    this.propType = "multidimensional", this.mult = l || 1, this.data = o, this._mdf = !1, this.elem = S, this.container = a, this.comp = S.comp, this.k = !1, this.kf = !1, this.frameId = -1;
                    var h, p = o.k.length;
                    for (this.v = createTypedArray("float32", p), this.pv = createTypedArray("float32", p), this.vel = createTypedArray("float32", p), h = 0; h < p; h += 1) this.v[h] = o.k[h] * this.mult, this.pv[h] = o.k[h];
                    this._isFirstFrame = !0, this.effectsSequence = [], this.getValue = d, this.setVValue = P, this.addEffect = _
                }

                function u(S, o, l, a) {
                    this.propType = "unidimensional", this.keyframes = o.k, this.keyframesMetadata = [], this.offsetTime = S.data.st, this.frameId = -1, this._caching = {
                        lastFrame: t,
                        lastIndex: 0,
                        value: 0,
                        _lastKeyframeIndex: -1
                    }, this.k = !0, this.kf = !0, this.data = o, this.mult = l || 1, this.elem = S, this.container = a, this.comp = S.comp, this.v = t, this.pv = t, this._isFirstFrame = !0, this.getValue = d, this.setVValue = P, this.interpolateValue = r, this.effectsSequence = [f.bind(this)], this.addEffect = _
                }

                function g(S, o, l, a) {
                    this.propType = "multidimensional";
                    var h, p = o.k.length,
                        c, b, A, I;
                    for (h = 0; h < p - 1; h += 1) o.k[h].to && o.k[h].s && o.k[h + 1] && o.k[h + 1].s && (c = o.k[h].s, b = o.k[h + 1].s, A = o.k[h].to, I = o.k[h].ti, (c.length === 2 && !(c[0] === b[0] && c[1] === b[1]) && bez.pointOnLine2D(c[0], c[1], b[0], b[1], c[0] + A[0], c[1] + A[1]) && bez.pointOnLine2D(c[0], c[1], b[0], b[1], b[0] + I[0], b[1] + I[1]) || c.length === 3 && !(c[0] === b[0] && c[1] === b[1] && c[2] === b[2]) && bez.pointOnLine3D(c[0], c[1], c[2], b[0], b[1], b[2], c[0] + A[0], c[1] + A[1], c[2] + A[2]) && bez.pointOnLine3D(c[0], c[1], c[2], b[0], b[1], b[2], b[0] + I[0], b[1] + I[1], b[2] + I[2])) && (o.k[h].to = null, o.k[h].ti = null), c[0] === b[0] && c[1] === b[1] && A[0] === 0 && A[1] === 0 && I[0] === 0 && I[1] === 0 && (c.length === 2 || c[2] === b[2] && A[2] === 0 && I[2] === 0) && (o.k[h].to = null, o.k[h].ti = null));
                    this.effectsSequence = [f.bind(this)], this.data = o, this.keyframes = o.k, this.keyframesMetadata = [], this.offsetTime = S.data.st, this.k = !0, this.kf = !0, this._isFirstFrame = !0, this.mult = l || 1, this.elem = S, this.container = a, this.comp = S.comp, this.getValue = d, this.setVValue = P, this.interpolateValue = r, this.frameId = -1;
                    var R = o.k[0].s.length;
                    for (this.v = createTypedArray("float32", R), this.pv = createTypedArray("float32", R), h = 0; h < R; h += 1) this.v[h] = t, this.pv[h] = t;
                    this._caching = {
                        lastFrame: t,
                        lastIndex: 0,
                        value: createTypedArray("float32", R)
                    }, this.addEffect = _
                }

                function v(S, o, l, a, h) {
                    var p;
                    if (!o.k.length) p = new E(S, o, a, h);
                    else if (typeof o.k[0] == "number") p = new k(S, o, a, h);
                    else switch (l) {
                        case 0:
                            p = new u(S, o, a, h);
                            break;
                        case 1:
                            p = new g(S, o, a, h);
                            break
                    }
                    return p.effectsSequence.length && h.addDynamicProperty(p), p
                }
                var m = {
                    getProp: v
                };
                return m
            }();

        function DynamicPropertyContainer() {}
        DynamicPropertyContainer.prototype = {
            addDynamicProperty: function(e) {
                this.dynamicProperties.indexOf(e) === -1 && (this.dynamicProperties.push(e), this.container.addDynamicProperty(this), this._isAnimated = !0)
            },
            iterateDynamicProperties: function() {
                this._mdf = !1;
                var e, r = this.dynamicProperties.length;
                for (e = 0; e < r; e += 1) this.dynamicProperties[e].getValue(), this.dynamicProperties[e]._mdf && (this._mdf = !0)
            },
            initDynamicPropertyContainer: function(e) {
                this.container = e, this.dynamicProperties = [], this._mdf = !1, this._isAnimated = !1
            }
        };
        var pointPool = function() {
            function t() {
                return createTypedArray("float32", 2)
            }
            return poolFactory(8, t)
        }();

        function ShapePath() {
            this.c = !1, this._length = 0, this._maxLength = 8, this.v = createSizedArray(this._maxLength), this.o = createSizedArray(this._maxLength), this.i = createSizedArray(this._maxLength)
        }
        ShapePath.prototype.setPathData = function(t, e) {
            this.c = t, this.setLength(e);
            for (var r = 0; r < e;) this.v[r] = pointPool.newElement(), this.o[r] = pointPool.newElement(), this.i[r] = pointPool.newElement(), r += 1
        }, ShapePath.prototype.setLength = function(t) {
            for (; this._maxLength < t;) this.doubleArrayLength();
            this._length = t
        }, ShapePath.prototype.doubleArrayLength = function() {
            this.v = this.v.concat(createSizedArray(this._maxLength)), this.i = this.i.concat(createSizedArray(this._maxLength)), this.o = this.o.concat(createSizedArray(this._maxLength)), this._maxLength *= 2
        }, ShapePath.prototype.setXYAt = function(t, e, r, i, s) {
            var n;
            switch (this._length = Math.max(this._length, i + 1), this._length >= this._maxLength && this.doubleArrayLength(), r) {
                case "v":
                    n = this.v;
                    break;
                case "i":
                    n = this.i;
                    break;
                case "o":
                    n = this.o;
                    break;
                default:
                    n = [];
                    break
            }(!n[i] || n[i] && !s) && (n[i] = pointPool.newElement()), n[i][0] = t, n[i][1] = e
        }, ShapePath.prototype.setTripleAt = function(t, e, r, i, s, n, f, P) {
            this.setXYAt(t, e, "v", f, P), this.setXYAt(r, i, "o", f, P), this.setXYAt(s, n, "i", f, P)
        }, ShapePath.prototype.reverse = function() {
            var t = new ShapePath;
            t.setPathData(this.c, this._length);
            var e = this.v,
                r = this.o,
                i = this.i,
                s = 0;
            this.c && (t.setTripleAt(e[0][0], e[0][1], i[0][0], i[0][1], r[0][0], r[0][1], 0, !1), s = 1);
            var n = this._length - 1,
                f = this._length,
                P;
            for (P = s; P < f; P += 1) t.setTripleAt(e[n][0], e[n][1], i[n][0], i[n][1], r[n][0], r[n][1], P, !1), n -= 1;
            return t
        };
        var shapePool = function() {
            function t() {
                return new ShapePath
            }

            function e(s) {
                var n = s._length,
                    f;
                for (f = 0; f < n; f += 1) pointPool.release(s.v[f]), pointPool.release(s.i[f]), pointPool.release(s.o[f]), s.v[f] = null, s.i[f] = null, s.o[f] = null;
                s._length = 0, s.c = !1
            }

            function r(s) {
                var n = i.newElement(),
                    f, P = s._length === void 0 ? s.v.length : s._length;
                for (n.setLength(P), n.c = s.c, f = 0; f < P; f += 1) n.setTripleAt(s.v[f][0], s.v[f][1], s.o[f][0], s.o[f][1], s.i[f][0], s.i[f][1], f);
                return n
            }
            var i = poolFactory(4, t, e);
            return i.clone = r, i
        }();

        function ShapeCollection() {
            this._length = 0, this._maxLength = 4, this.shapes = createSizedArray(this._maxLength)
        }
        ShapeCollection.prototype.addShape = function(t) {
            this._length === this._maxLength && (this.shapes = this.shapes.concat(createSizedArray(this._maxLength)), this._maxLength *= 2), this.shapes[this._length] = t, this._length += 1
        }, ShapeCollection.prototype.releaseShapes = function() {
            var t;
            for (t = 0; t < this._length; t += 1) shapePool.release(this.shapes[t]);
            this._length = 0
        };
        var shapeCollectionPool = function() {
                var t = {
                        newShapeCollection: s,
                        release: n
                    },
                    e = 0,
                    r = 4,
                    i = createSizedArray(r);

                function s() {
                    var f;
                    return e ? (e -= 1, f = i[e]) : f = new ShapeCollection, f
                }

                function n(f) {
                    var P, d = f._length;
                    for (P = 0; P < d; P += 1) shapePool.release(f.shapes[P]);
                    f._length = 0, e === r && (i = pooling.double(i), r *= 2), i[e] = f, e += 1
                }
                return t
            }(),
            ShapePropertyFactory = function() {
                var t = -999999;

                function e(o, l, a) {
                    var h = a.lastIndex,
                        p, c, b, A, I, R, L, w, G, B = this.keyframes;
                    if (o < B[0].t - this.offsetTime) p = B[0].s[0], b = !0, h = 0;
                    else if (o >= B[B.length - 1].t - this.offsetTime) p = B[B.length - 1].s ? B[B.length - 1].s[0] : B[B.length - 2].e[0], b = !0;
                    else {
                        for (var C = h, F = B.length - 1, x = !0, y, T, V; x && (y = B[C], T = B[C + 1], !(T.t - this.offsetTime > o));) C < F - 1 ? C += 1 : x = !1;
                        if (V = this.keyframesMetadata[C] || {}, b = y.h === 1, h = C, !b) {
                            if (o >= T.t - this.offsetTime) w = 1;
                            else if (o < y.t - this.offsetTime) w = 0;
                            else {
                                var M;
                                V.__fnct ? M = V.__fnct : (M = BezierFactory.getBezierEasing(y.o.x, y.o.y, y.i.x, y.i.y).get, V.__fnct = M), w = M((o - (y.t - this.offsetTime)) / (T.t - this.offsetTime - (y.t - this.offsetTime)))
                            }
                            c = T.s ? T.s[0] : y.e[0]
                        }
                        p = y.s[0]
                    }
                    for (R = l._length, L = p.i[0].length, a.lastIndex = h, A = 0; A < R; A += 1)
                        for (I = 0; I < L; I += 1) G = b ? p.i[A][I] : p.i[A][I] + (c.i[A][I] - p.i[A][I]) * w, l.i[A][I] = G, G = b ? p.o[A][I] : p.o[A][I] + (c.o[A][I] - p.o[A][I]) * w, l.o[A][I] = G, G = b ? p.v[A][I] : p.v[A][I] + (c.v[A][I] - p.v[A][I]) * w, l.v[A][I] = G
                }

                function r() {
                    var o = this.comp.renderedFrame - this.offsetTime,
                        l = this.keyframes[0].t - this.offsetTime,
                        a = this.keyframes[this.keyframes.length - 1].t - this.offsetTime,
                        h = this._caching.lastFrame;
                    return h !== t && (h < l && o < l || h > a && o > a) || (this._caching.lastIndex = h < o ? this._caching.lastIndex : 0, this.interpolateShape(o, this.pv, this._caching)), this._caching.lastFrame = o, this.pv
                }

                function i() {
                    this.paths = this.localShapeCollection
                }

                function s(o, l) {
                    if (o._length !== l._length || o.c !== l.c) return !1;
                    var a, h = o._length;
                    for (a = 0; a < h; a += 1)
                        if (o.v[a][0] !== l.v[a][0] || o.v[a][1] !== l.v[a][1] || o.o[a][0] !== l.o[a][0] || o.o[a][1] !== l.o[a][1] || o.i[a][0] !== l.i[a][0] || o.i[a][1] !== l.i[a][1]) return !1;
                    return !0
                }

                function n(o) {
                    s(this.v, o) || (this.v = shapePool.clone(o), this.localShapeCollection.releaseShapes(), this.localShapeCollection.addShape(this.v), this._mdf = !0, this.paths = this.localShapeCollection)
                }

                function f() {
                    if (this.elem.globalData.frameId !== this.frameId) {
                        if (!this.effectsSequence.length) {
                            this._mdf = !1;
                            return
                        }
                        if (this.lock) {
                            this.setVValue(this.pv);
                            return
                        }
                        this.lock = !0, this._mdf = !1;
                        var o;
                        this.kf ? o = this.pv : this.data.ks ? o = this.data.ks.k : o = this.data.pt.k;
                        var l, a = this.effectsSequence.length;
                        for (l = 0; l < a; l += 1) o = this.effectsSequence[l](o);
                        this.setVValue(o), this.lock = !1, this.frameId = this.elem.globalData.frameId
                    }
                }

                function P(o, l, a) {
                    this.propType = "shape", this.comp = o.comp, this.container = o, this.elem = o, this.data = l, this.k = !1, this.kf = !1, this._mdf = !1;
                    var h = a === 3 ? l.pt.k : l.ks.k;
                    this.v = shapePool.clone(h), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.reset = i, this.effectsSequence = []
                }

                function d(o) {
                    this.effectsSequence.push(o), this.container.addDynamicProperty(this)
                }
                P.prototype.interpolateShape = e, P.prototype.getValue = f, P.prototype.setVValue = n, P.prototype.addEffect = d;

                function _(o, l, a) {
                    this.propType = "shape", this.comp = o.comp, this.elem = o, this.container = o, this.offsetTime = o.data.st, this.keyframes = a === 3 ? l.pt.k : l.ks.k, this.keyframesMetadata = [], this.k = !0, this.kf = !0;
                    var h = this.keyframes[0].s[0].i.length;
                    this.v = shapePool.newElement(), this.v.setPathData(this.keyframes[0].s[0].c, h), this.pv = shapePool.clone(this.v), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.paths.addShape(this.v), this.lastFrame = t, this.reset = i, this._caching = {
                        lastFrame: t,
                        lastIndex: 0
                    }, this.effectsSequence = [r.bind(this)]
                }
                _.prototype.getValue = f, _.prototype.interpolateShape = e, _.prototype.setVValue = n, _.prototype.addEffect = d;
                var E = function() {
                        var o = roundCorner;

                        function l(a, h) {
                            this.v = shapePool.newElement(), this.v.setPathData(!0, 4), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.paths = this.localShapeCollection, this.localShapeCollection.addShape(this.v), this.d = h.d, this.elem = a, this.comp = a.comp, this.frameId = -1, this.initDynamicPropertyContainer(a), this.p = PropertyFactory.getProp(a, h.p, 1, 0, this), this.s = PropertyFactory.getProp(a, h.s, 1, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertEllToPath())
                        }
                        return l.prototype = {
                            reset: i,
                            getValue: function() {
                                this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertEllToPath())
                            },
                            convertEllToPath: function() {
                                var h = this.p.v[0],
                                    p = this.p.v[1],
                                    c = this.s.v[0] / 2,
                                    b = this.s.v[1] / 2,
                                    A = this.d !== 3,
                                    I = this.v;
                                I.v[0][0] = h, I.v[0][1] = p - b, I.v[1][0] = A ? h + c : h - c, I.v[1][1] = p, I.v[2][0] = h, I.v[2][1] = p + b, I.v[3][0] = A ? h - c : h + c, I.v[3][1] = p, I.i[0][0] = A ? h - c * o : h + c * o, I.i[0][1] = p - b, I.i[1][0] = A ? h + c : h - c, I.i[1][1] = p - b * o, I.i[2][0] = A ? h + c * o : h - c * o, I.i[2][1] = p + b, I.i[3][0] = A ? h - c : h + c, I.i[3][1] = p + b * o, I.o[0][0] = A ? h + c * o : h - c * o, I.o[0][1] = p - b, I.o[1][0] = A ? h + c : h - c, I.o[1][1] = p + b * o, I.o[2][0] = A ? h - c * o : h + c * o, I.o[2][1] = p + b, I.o[3][0] = A ? h - c : h + c, I.o[3][1] = p - b * o
                            }
                        }, extendPrototype([DynamicPropertyContainer], l), l
                    }(),
                    k = function() {
                        function o(l, a) {
                            this.v = shapePool.newElement(), this.v.setPathData(!0, 0), this.elem = l, this.comp = l.comp, this.data = a, this.frameId = -1, this.d = a.d, this.initDynamicPropertyContainer(l), a.sy === 1 ? (this.ir = PropertyFactory.getProp(l, a.ir, 0, 0, this), this.is = PropertyFactory.getProp(l, a.is, 0, .01, this), this.convertToPath = this.convertStarToPath) : this.convertToPath = this.convertPolygonToPath, this.pt = PropertyFactory.getProp(l, a.pt, 0, 0, this), this.p = PropertyFactory.getProp(l, a.p, 1, 0, this), this.r = PropertyFactory.getProp(l, a.r, 0, degToRads, this), this.or = PropertyFactory.getProp(l, a.or, 0, 0, this), this.os = PropertyFactory.getProp(l, a.os, 0, .01, this), this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertToPath())
                        }
                        return o.prototype = {
                            reset: i,
                            getValue: function() {
                                this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertToPath())
                            },
                            convertStarToPath: function() {
                                var a = Math.floor(this.pt.v) * 2,
                                    h = Math.PI * 2 / a,
                                    p = !0,
                                    c = this.or.v,
                                    b = this.ir.v,
                                    A = this.os.v,
                                    I = this.is.v,
                                    R = 2 * Math.PI * c / (a * 2),
                                    L = 2 * Math.PI * b / (a * 2),
                                    w, G, B, C, F = -Math.PI / 2;
                                F += this.r.v;
                                var x = this.data.d === 3 ? -1 : 1;
                                for (this.v._length = 0, w = 0; w < a; w += 1) {
                                    G = p ? c : b, B = p ? A : I, C = p ? R : L;
                                    var y = G * Math.cos(F),
                                        T = G * Math.sin(F),
                                        V = y === 0 && T === 0 ? 0 : T / Math.sqrt(y * y + T * T),
                                        M = y === 0 && T === 0 ? 0 : -y / Math.sqrt(y * y + T * T);
                                    y += +this.p.v[0], T += +this.p.v[1], this.v.setTripleAt(y, T, y - V * C * B * x, T - M * C * B * x, y + V * C * B * x, T + M * C * B * x, w, !0), p = !p, F += h * x
                                }
                            },
                            convertPolygonToPath: function() {
                                var a = Math.floor(this.pt.v),
                                    h = Math.PI * 2 / a,
                                    p = this.or.v,
                                    c = this.os.v,
                                    b = 2 * Math.PI * p / (a * 4),
                                    A, I = -Math.PI * .5,
                                    R = this.data.d === 3 ? -1 : 1;
                                for (I += this.r.v, this.v._length = 0, A = 0; A < a; A += 1) {
                                    var L = p * Math.cos(I),
                                        w = p * Math.sin(I),
                                        G = L === 0 && w === 0 ? 0 : w / Math.sqrt(L * L + w * w),
                                        B = L === 0 && w === 0 ? 0 : -L / Math.sqrt(L * L + w * w);
                                    L += +this.p.v[0], w += +this.p.v[1], this.v.setTripleAt(L, w, L - G * b * c * R, w - B * b * c * R, L + G * b * c * R, w + B * b * c * R, A, !0), I += h * R
                                }
                                this.paths.length = 0, this.paths[0] = this.v
                            }
                        }, extendPrototype([DynamicPropertyContainer], o), o
                    }(),
                    u = function() {
                        function o(l, a) {
                            this.v = shapePool.newElement(), this.v.c = !0, this.localShapeCollection = shapeCollectionPool.newShapeCollection(), this.localShapeCollection.addShape(this.v), this.paths = this.localShapeCollection, this.elem = l, this.comp = l.comp, this.frameId = -1, this.d = a.d, this.initDynamicPropertyContainer(l), this.p = PropertyFactory.getProp(l, a.p, 1, 0, this), this.s = PropertyFactory.getProp(l, a.s, 1, 0, this), this.r = PropertyFactory.getProp(l, a.r, 0, 0, this), this.dynamicProperties.length ? this.k = !0 : (this.k = !1, this.convertRectToPath())
                        }
                        return o.prototype = {
                            convertRectToPath: function() {
                                var a = this.p.v[0],
                                    h = this.p.v[1],
                                    p = this.s.v[0] / 2,
                                    c = this.s.v[1] / 2,
                                    b = bmMin(p, c, this.r.v),
                                    A = b * (1 - roundCorner);
                                this.v._length = 0, this.d === 2 || this.d === 1 ? (this.v.setTripleAt(a + p, h - c + b, a + p, h - c + b, a + p, h - c + A, 0, !0), this.v.setTripleAt(a + p, h + c - b, a + p, h + c - A, a + p, h + c - b, 1, !0), b !== 0 ? (this.v.setTripleAt(a + p - b, h + c, a + p - b, h + c, a + p - A, h + c, 2, !0), this.v.setTripleAt(a - p + b, h + c, a - p + A, h + c, a - p + b, h + c, 3, !0), this.v.setTripleAt(a - p, h + c - b, a - p, h + c - b, a - p, h + c - A, 4, !0), this.v.setTripleAt(a - p, h - c + b, a - p, h - c + A, a - p, h - c + b, 5, !0), this.v.setTripleAt(a - p + b, h - c, a - p + b, h - c, a - p + A, h - c, 6, !0), this.v.setTripleAt(a + p - b, h - c, a + p - A, h - c, a + p - b, h - c, 7, !0)) : (this.v.setTripleAt(a - p, h + c, a - p + A, h + c, a - p, h + c, 2), this.v.setTripleAt(a - p, h - c, a - p, h - c + A, a - p, h - c, 3))) : (this.v.setTripleAt(a + p, h - c + b, a + p, h - c + A, a + p, h - c + b, 0, !0), b !== 0 ? (this.v.setTripleAt(a + p - b, h - c, a + p - b, h - c, a + p - A, h - c, 1, !0), this.v.setTripleAt(a - p + b, h - c, a - p + A, h - c, a - p + b, h - c, 2, !0), this.v.setTripleAt(a - p, h - c + b, a - p, h - c + b, a - p, h - c + A, 3, !0), this.v.setTripleAt(a - p, h + c - b, a - p, h + c - A, a - p, h + c - b, 4, !0), this.v.setTripleAt(a - p + b, h + c, a - p + b, h + c, a - p + A, h + c, 5, !0), this.v.setTripleAt(a + p - b, h + c, a + p - A, h + c, a + p - b, h + c, 6, !0), this.v.setTripleAt(a + p, h + c - b, a + p, h + c - b, a + p, h + c - A, 7, !0)) : (this.v.setTripleAt(a - p, h - c, a - p + A, h - c, a - p, h - c, 1, !0), this.v.setTripleAt(a - p, h + c, a - p, h + c - A, a - p, h + c, 2, !0), this.v.setTripleAt(a + p, h + c, a + p - A, h + c, a + p, h + c, 3, !0)))
                            },
                            getValue: function() {
                                this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf && this.convertRectToPath())
                            },
                            reset: i
                        }, extendPrototype([DynamicPropertyContainer], o), o
                    }();

                function g(o, l, a) {
                    var h;
                    if (a === 3 || a === 4) {
                        var p = a === 3 ? l.pt : l.ks,
                            c = p.k;
                        c.length ? h = new _(o, l, a) : h = new P(o, l, a)
                    } else a === 5 ? h = new u(o, l) : a === 6 ? h = new E(o, l) : a === 7 && (h = new k(o, l));
                    return h.k && o.addDynamicProperty(h), h
                }

                function v() {
                    return P
                }

                function m() {
                    return _
                }
                var S = {};
                return S.getShapeProp = g, S.getConstructorFunction = v, S.getKeyframedConstructorFunction = m, S
            }();
        /*!
         Transformation Matrix v2.0
         (c) Epistemex 2014-2015
         www.epistemex.com
         By Ken Fyrstenberg
         Contributions by leeoniya.
         License: MIT, header required.
         */
        var Matrix = function() {
            var t = Math.cos,
                e = Math.sin,
                r = Math.tan,
                i = Math.round;

            function s() {
                return this.props[0] = 1, this.props[1] = 0, this.props[2] = 0, this.props[3] = 0, this.props[4] = 0, this.props[5] = 1, this.props[6] = 0, this.props[7] = 0, this.props[8] = 0, this.props[9] = 0, this.props[10] = 1, this.props[11] = 0, this.props[12] = 0, this.props[13] = 0, this.props[14] = 0, this.props[15] = 1, this
            }

            function n(x) {
                if (x === 0) return this;
                var y = t(x),
                    T = e(x);
                return this._t(y, -T, 0, 0, T, y, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
            }

            function f(x) {
                if (x === 0) return this;
                var y = t(x),
                    T = e(x);
                return this._t(1, 0, 0, 0, 0, y, -T, 0, 0, T, y, 0, 0, 0, 0, 1)
            }

            function P(x) {
                if (x === 0) return this;
                var y = t(x),
                    T = e(x);
                return this._t(y, 0, T, 0, 0, 1, 0, 0, -T, 0, y, 0, 0, 0, 0, 1)
            }

            function d(x) {
                if (x === 0) return this;
                var y = t(x),
                    T = e(x);
                return this._t(y, -T, 0, 0, T, y, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
            }

            function _(x, y) {
                return this._t(1, y, x, 1, 0, 0)
            }

            function E(x, y) {
                return this.shear(r(x), r(y))
            }

            function k(x, y) {
                var T = t(y),
                    V = e(y);
                return this._t(T, V, 0, 0, -V, T, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(1, 0, 0, 0, r(x), 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)._t(T, -V, 0, 0, V, T, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1)
            }

            function u(x, y, T) {
                return !T && T !== 0 && (T = 1), x === 1 && y === 1 && T === 1 ? this : this._t(x, 0, 0, 0, 0, y, 0, 0, 0, 0, T, 0, 0, 0, 0, 1)
            }

            function g(x, y, T, V, M, D, N, z, H, j, X, K, U, $, q, Y) {
                return this.props[0] = x, this.props[1] = y, this.props[2] = T, this.props[3] = V, this.props[4] = M, this.props[5] = D, this.props[6] = N, this.props[7] = z, this.props[8] = H, this.props[9] = j, this.props[10] = X, this.props[11] = K, this.props[12] = U, this.props[13] = $, this.props[14] = q, this.props[15] = Y, this
            }

            function v(x, y, T) {
                return T = T || 0, x !== 0 || y !== 0 || T !== 0 ? this._t(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, x, y, T, 1) : this
            }

            function m(x, y, T, V, M, D, N, z, H, j, X, K, U, $, q, Y) {
                var O = this.props;
                if (x === 1 && y === 0 && T === 0 && V === 0 && M === 0 && D === 1 && N === 0 && z === 0 && H === 0 && j === 0 && X === 1 && K === 0) return O[12] = O[12] * x + O[15] * U, O[13] = O[13] * D + O[15] * $, O[14] = O[14] * X + O[15] * q, O[15] *= Y, this._identityCalculated = !1, this;
                var W = O[0],
                    et = O[1],
                    nt = O[2],
                    rt = O[3],
                    tt = O[4],
                    it = O[5],
                    st = O[6],
                    Z = O[7],
                    at = O[8],
                    ot = O[9],
                    J = O[10],
                    ht = O[11],
                    Q = O[12],
                    lt = O[13],
                    ft = O[14],
                    pt = O[15];
                return O[0] = W * x + et * M + nt * H + rt * U, O[1] = W * y + et * D + nt * j + rt * $, O[2] = W * T + et * N + nt * X + rt * q, O[3] = W * V + et * z + nt * K + rt * Y, O[4] = tt * x + it * M + st * H + Z * U, O[5] = tt * y + it * D + st * j + Z * $, O[6] = tt * T + it * N + st * X + Z * q, O[7] = tt * V + it * z + st * K + Z * Y, O[8] = at * x + ot * M + J * H + ht * U, O[9] = at * y + ot * D + J * j + ht * $, O[10] = at * T + ot * N + J * X + ht * q, O[11] = at * V + ot * z + J * K + ht * Y, O[12] = Q * x + lt * M + ft * H + pt * U, O[13] = Q * y + lt * D + ft * j + pt * $, O[14] = Q * T + lt * N + ft * X + pt * q, O[15] = Q * V + lt * z + ft * K + pt * Y, this._identityCalculated = !1, this
            }

            function S() {
                return this._identityCalculated || (this._identity = !(this.props[0] !== 1 || this.props[1] !== 0 || this.props[2] !== 0 || this.props[3] !== 0 || this.props[4] !== 0 || this.props[5] !== 1 || this.props[6] !== 0 || this.props[7] !== 0 || this.props[8] !== 0 || this.props[9] !== 0 || this.props[10] !== 1 || this.props[11] !== 0 || this.props[12] !== 0 || this.props[13] !== 0 || this.props[14] !== 0 || this.props[15] !== 1), this._identityCalculated = !0), this._identity
            }

            function o(x) {
                for (var y = 0; y < 16;) {
                    if (x.props[y] !== this.props[y]) return !1;
                    y += 1
                }
                return !0
            }

            function l(x) {
                var y;
                for (y = 0; y < 16; y += 1) x.props[y] = this.props[y];
                return x
            }

            function a(x) {
                var y;
                for (y = 0; y < 16; y += 1) this.props[y] = x[y]
            }

            function h(x, y, T) {
                return {
                    x: x * this.props[0] + y * this.props[4] + T * this.props[8] + this.props[12],
                    y: x * this.props[1] + y * this.props[5] + T * this.props[9] + this.props[13],
                    z: x * this.props[2] + y * this.props[6] + T * this.props[10] + this.props[14]
                }
            }

            function p(x, y, T) {
                return x * this.props[0] + y * this.props[4] + T * this.props[8] + this.props[12]
            }

            function c(x, y, T) {
                return x * this.props[1] + y * this.props[5] + T * this.props[9] + this.props[13]
            }

            function b(x, y, T) {
                return x * this.props[2] + y * this.props[6] + T * this.props[10] + this.props[14]
            }

            function A() {
                var x = this.props[0] * this.props[5] - this.props[1] * this.props[4],
                    y = this.props[5] / x,
                    T = -this.props[1] / x,
                    V = -this.props[4] / x,
                    M = this.props[0] / x,
                    D = (this.props[4] * this.props[13] - this.props[5] * this.props[12]) / x,
                    N = -(this.props[0] * this.props[13] - this.props[1] * this.props[12]) / x,
                    z = new Matrix;
                return z.props[0] = y, z.props[1] = T, z.props[4] = V, z.props[5] = M, z.props[12] = D, z.props[13] = N, z
            }

            function I(x) {
                var y = this.getInverseMatrix();
                return y.applyToPointArray(x[0], x[1], x[2] || 0)
            }

            function R(x) {
                var y, T = x.length,
                    V = [];
                for (y = 0; y < T; y += 1) V[y] = I(x[y]);
                return V
            }

            function L(x, y, T) {
                var V = createTypedArray("float32", 6);
                if (this.isIdentity()) V[0] = x[0], V[1] = x[1], V[2] = y[0], V[3] = y[1], V[4] = T[0], V[5] = T[1];
                else {
                    var M = this.props[0],
                        D = this.props[1],
                        N = this.props[4],
                        z = this.props[5],
                        H = this.props[12],
                        j = this.props[13];
                    V[0] = x[0] * M + x[1] * N + H, V[1] = x[0] * D + x[1] * z + j, V[2] = y[0] * M + y[1] * N + H, V[3] = y[0] * D + y[1] * z + j, V[4] = T[0] * M + T[1] * N + H, V[5] = T[0] * D + T[1] * z + j
                }
                return V
            }

            function w(x, y, T) {
                var V;
                return this.isIdentity() ? V = [x, y, T] : V = [x * this.props[0] + y * this.props[4] + T * this.props[8] + this.props[12], x * this.props[1] + y * this.props[5] + T * this.props[9] + this.props[13], x * this.props[2] + y * this.props[6] + T * this.props[10] + this.props[14]], V
            }

            function G(x, y) {
                if (this.isIdentity()) return x + "," + y;
                var T = this.props;
                return Math.round((x * T[0] + y * T[4] + T[12]) * 100) / 100 + "," + Math.round((x * T[1] + y * T[5] + T[13]) * 100) / 100
            }

            function B() {
                for (var x = 0, y = this.props, T = "matrix3d(", V = 1e4; x < 16;) T += i(y[x] * V) / V, T += x === 15 ? ")" : ",", x += 1;
                return T
            }

            function C(x) {
                var y = 1e4;
                return x < 1e-6 && x > 0 || x > -1e-6 && x < 0 ? i(x * y) / y : x
            }

            function F() {
                var x = this.props,
                    y = C(x[0]),
                    T = C(x[1]),
                    V = C(x[4]),
                    M = C(x[5]),
                    D = C(x[12]),
                    N = C(x[13]);
                return "matrix(" + y + "," + T + "," + V + "," + M + "," + D + "," + N + ")"
            }
            return function() {
                this.reset = s, this.rotate = n, this.rotateX = f, this.rotateY = P, this.rotateZ = d, this.skew = E, this.skewFromAxis = k, this.shear = _, this.scale = u, this.setTransform = g, this.translate = v, this.transform = m, this.applyToPoint = h, this.applyToX = p, this.applyToY = c, this.applyToZ = b, this.applyToPointArray = w, this.applyToTriplePoints = L, this.applyToPointStringified = G, this.toCSS = B, this.to2dCSS = F, this.clone = l, this.cloneFromProps = a, this.equals = o, this.inversePoints = R, this.inversePoint = I, this.getInverseMatrix = A, this._t = this.transform, this.isIdentity = S, this._identity = !0, this._identityCalculated = !1, this.props = createTypedArray("float32", 16), this.reset()
            }
        }();

        function _typeof$3(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof$3 = function(r) {
                return typeof r
            } : _typeof$3 = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof$3(t)
        }
        var lottie = {};

        function setLocation(t) {
            setLocationHref(t)
        }

        function searchAnimations() {
            animationManager.searchAnimations()
        }

        function setSubframeRendering(t) {
            setSubframeEnabled(t)
        }

        function setPrefix(t) {
            setIdPrefix(t)
        }

        function loadAnimation(t) {
            return animationManager.loadAnimation(t)
        }

        function setQuality(t) {
            if (typeof t == "string") switch (t) {
                case "high":
                    setDefaultCurveSegments(200);
                    break;
                default:
                case "medium":
                    setDefaultCurveSegments(50);
                    break;
                case "low":
                    setDefaultCurveSegments(10);
                    break
            } else !isNaN(t) && t > 1 && setDefaultCurveSegments(t)
        }

        function inBrowser() {
            return typeof navigator < "u"
        }

        function installPlugin(t, e) {
            t === "expressions" && setExpressionsPlugin(e)
        }

        function getFactory(t) {
            switch (t) {
                case "propertyFactory":
                    return PropertyFactory;
                case "shapePropertyFactory":
                    return ShapePropertyFactory;
                case "matrix":
                    return Matrix;
                default:
                    return null
            }
        }
        lottie.play = animationManager.play, lottie.pause = animationManager.pause, lottie.setLocationHref = setLocation, lottie.togglePause = animationManager.togglePause, lottie.setSpeed = animationManager.setSpeed, lottie.setDirection = animationManager.setDirection, lottie.stop = animationManager.stop, lottie.searchAnimations = searchAnimations, lottie.registerAnimation = animationManager.registerAnimation, lottie.loadAnimation = loadAnimation, lottie.setSubframeRendering = setSubframeRendering, lottie.resize = animationManager.resize, lottie.goToAndStop = animationManager.goToAndStop, lottie.destroy = animationManager.destroy, lottie.setQuality = setQuality, lottie.inBrowser = inBrowser, lottie.installPlugin = installPlugin, lottie.freeze = animationManager.freeze, lottie.unfreeze = animationManager.unfreeze, lottie.setVolume = animationManager.setVolume, lottie.mute = animationManager.mute, lottie.unmute = animationManager.unmute, lottie.getRegisteredAnimations = animationManager.getRegisteredAnimations, lottie.useWebWorker = setWebWorker, lottie.setIDPrefix = setPrefix, lottie.__getFactory = getFactory, lottie.version = "5.9.2";

        function checkReady() {
            document.readyState === "complete" && (clearInterval(readyStateCheckInterval), searchAnimations())
        }

        function getQueryVariable(t) {
            for (var e = queryString.split("&"), r = 0; r < e.length; r += 1) {
                var i = e[r].split("=");
                if (decodeURIComponent(i[0]) == t) return decodeURIComponent(i[1])
            }
            return null
        }
        var queryString; {
            var scripts = document.getElementsByTagName("script"),
                index = scripts.length - 1,
                myScript = scripts[index] || {
                    src: ""
                };
            queryString = myScript.src.replace(/^[^\?]+\??/, ""), getQueryVariable("renderer")
        }
        var readyStateCheckInterval = setInterval(checkReady, 100);
        try {
            _typeof$3(exports) !== "object" && (window.bodymovin = lottie)
        } catch (t) {}
        var ShapeModifiers = function() {
            var t = {},
                e = {};
            t.registerModifier = r, t.getModifier = i;

            function r(s, n) {
                e[s] || (e[s] = n)
            }

            function i(s, n, f) {
                return new e[s](n, f)
            }
            return t
        }();

        function ShapeModifier() {}
        ShapeModifier.prototype.initModifierProperties = function() {}, ShapeModifier.prototype.addShapeToModifier = function() {}, ShapeModifier.prototype.addShape = function(t) {
            if (!this.closed) {
                t.sh.container.addDynamicProperty(t.sh);
                var e = {
                    shape: t.sh,
                    data: t,
                    localShapeCollection: shapeCollectionPool.newShapeCollection()
                };
                this.shapes.push(e), this.addShapeToModifier(e), this._isAnimated && t.setAsAnimated()
            }
        }, ShapeModifier.prototype.init = function(t, e) {
            this.shapes = [], this.elem = t, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e), this.frameId = initialDefaultFrame, this.closed = !1, this.k = !1, this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
        }, ShapeModifier.prototype.processKeys = function() {
            this.elem.globalData.frameId !== this.frameId && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties())
        }, extendPrototype([DynamicPropertyContainer], ShapeModifier);

        function TrimModifier() {}
        extendPrototype([ShapeModifier], TrimModifier), TrimModifier.prototype.initModifierProperties = function(t, e) {
            this.s = PropertyFactory.getProp(t, e.s, 0, .01, this), this.e = PropertyFactory.getProp(t, e.e, 0, .01, this), this.o = PropertyFactory.getProp(t, e.o, 0, 0, this), this.sValue = 0, this.eValue = 0, this.getValue = this.processKeys, this.m = e.m, this._isAnimated = !!this.s.effectsSequence.length || !!this.e.effectsSequence.length || !!this.o.effectsSequence.length
        }, TrimModifier.prototype.addShapeToModifier = function(t) {
            t.pathsData = []
        }, TrimModifier.prototype.calculateShapeEdges = function(t, e, r, i, s) {
            var n = [];
            e <= 1 ? n.push({
                s: t,
                e
            }) : t >= 1 ? n.push({
                s: t - 1,
                e: e - 1
            }) : (n.push({
                s: t,
                e: 1
            }), n.push({
                s: 0,
                e: e - 1
            }));
            var f = [],
                P, d = n.length,
                _;
            for (P = 0; P < d; P += 1)
                if (_ = n[P], !(_.e * s < i || _.s * s > i + r)) {
                    var E, k;
                    _.s * s <= i ? E = 0 : E = (_.s * s - i) / r, _.e * s >= i + r ? k = 1 : k = (_.e * s - i) / r, f.push([E, k])
                }
            return f.length || f.push([0, 0]), f
        }, TrimModifier.prototype.releasePathsData = function(t) {
            var e, r = t.length;
            for (e = 0; e < r; e += 1) segmentsLengthPool.release(t[e]);
            return t.length = 0, t
        }, TrimModifier.prototype.processShapes = function(t) {
            var e, r;
            if (this._mdf || t) {
                var i = this.o.v % 360 / 360;
                if (i < 0 && (i += 1), this.s.v > 1 ? e = 1 + i : this.s.v < 0 ? e = 0 + i : e = this.s.v + i, this.e.v > 1 ? r = 1 + i : this.e.v < 0 ? r = 0 + i : r = this.e.v + i, e > r) {
                    var s = e;
                    e = r, r = s
                }
                e = Math.round(e * 1e4) * 1e-4, r = Math.round(r * 1e4) * 1e-4, this.sValue = e, this.eValue = r
            } else e = this.sValue, r = this.eValue;
            var n, f, P = this.shapes.length,
                d, _, E, k, u, g = 0;
            if (r === e)
                for (f = 0; f < P; f += 1) this.shapes[f].localShapeCollection.releaseShapes(), this.shapes[f].shape._mdf = !0, this.shapes[f].shape.paths = this.shapes[f].localShapeCollection, this._mdf && (this.shapes[f].pathsData.length = 0);
            else if (r === 1 && e === 0 || r === 0 && e === 1) {
                if (this._mdf)
                    for (f = 0; f < P; f += 1) this.shapes[f].pathsData.length = 0, this.shapes[f].shape._mdf = !0
            } else {
                var v = [],
                    m, S;
                for (f = 0; f < P; f += 1)
                    if (m = this.shapes[f], !m.shape._mdf && !this._mdf && !t && this.m !== 2) m.shape.paths = m.localShapeCollection;
                    else {
                        if (n = m.shape.paths, _ = n._length, u = 0, !m.shape._mdf && m.pathsData.length) u = m.totalShapeLength;
                        else {
                            for (E = this.releasePathsData(m.pathsData), d = 0; d < _; d += 1) k = bez.getSegmentsLength(n.shapes[d]), E.push(k), u += k.totalLength;
                            m.totalShapeLength = u, m.pathsData = E
                        }
                        g += u, m.shape._mdf = !0
                    }
                var o = e,
                    l = r,
                    a = 0,
                    h;
                for (f = P - 1; f >= 0; f -= 1)
                    if (m = this.shapes[f], m.shape._mdf) {
                        for (S = m.localShapeCollection, S.releaseShapes(), this.m === 2 && P > 1 ? (h = this.calculateShapeEdges(e, r, m.totalShapeLength, a, g), a += m.totalShapeLength) : h = [
                                [o, l]
                            ], _ = h.length, d = 0; d < _; d += 1) {
                            o = h[d][0], l = h[d][1], v.length = 0, l <= 1 ? v.push({
                                s: m.totalShapeLength * o,
                                e: m.totalShapeLength * l
                            }) : o >= 1 ? v.push({
                                s: m.totalShapeLength * (o - 1),
                                e: m.totalShapeLength * (l - 1)
                            }) : (v.push({
                                s: m.totalShapeLength * o,
                                e: m.totalShapeLength
                            }), v.push({
                                s: 0,
                                e: m.totalShapeLength * (l - 1)
                            }));
                            var p = this.addShapes(m, v[0]);
                            if (v[0].s !== v[0].e) {
                                if (v.length > 1) {
                                    var c = m.shape.paths.shapes[m.shape.paths._length - 1];
                                    if (c.c) {
                                        var b = p.pop();
                                        this.addPaths(p, S), p = this.addShapes(m, v[1], b)
                                    } else this.addPaths(p, S), p = this.addShapes(m, v[1])
                                }
                                this.addPaths(p, S)
                            }
                        }
                        m.shape.paths = S
                    }
            }
        }, TrimModifier.prototype.addPaths = function(t, e) {
            var r, i = t.length;
            for (r = 0; r < i; r += 1) e.addShape(t[r])
        }, TrimModifier.prototype.addSegment = function(t, e, r, i, s, n, f) {
            s.setXYAt(e[0], e[1], "o", n), s.setXYAt(r[0], r[1], "i", n + 1), f && s.setXYAt(t[0], t[1], "v", n), s.setXYAt(i[0], i[1], "v", n + 1)
        }, TrimModifier.prototype.addSegmentFromArray = function(t, e, r, i) {
            e.setXYAt(t[1], t[5], "o", r), e.setXYAt(t[2], t[6], "i", r + 1), i && e.setXYAt(t[0], t[4], "v", r), e.setXYAt(t[3], t[7], "v", r + 1)
        }, TrimModifier.prototype.addShapes = function(t, e, r) {
            var i = t.pathsData,
                s = t.shape.paths.shapes,
                n, f = t.shape.paths._length,
                P, d, _ = 0,
                E, k, u, g, v = [],
                m, S = !0;
            for (r ? (k = r._length, m = r._length) : (r = shapePool.newElement(), k = 0, m = 0), v.push(r), n = 0; n < f; n += 1) {
                for (u = i[n].lengths, r.c = s[n].c, d = s[n].c ? u.length : u.length + 1, P = 1; P < d; P += 1)
                    if (E = u[P - 1], _ + E.addedLength < e.s) _ += E.addedLength, r.c = !1;
                    else if (_ > e.e) {
                    r.c = !1;
                    break
                } else e.s <= _ && e.e >= _ + E.addedLength ? (this.addSegment(s[n].v[P - 1], s[n].o[P - 1], s[n].i[P], s[n].v[P], r, k, S), S = !1) : (g = bez.getNewSegment(s[n].v[P - 1], s[n].v[P], s[n].o[P - 1], s[n].i[P], (e.s - _) / E.addedLength, (e.e - _) / E.addedLength, u[P - 1]), this.addSegmentFromArray(g, r, k, S), S = !1, r.c = !1), _ += E.addedLength, k += 1;
                if (s[n].c && u.length) {
                    if (E = u[P - 1], _ <= e.e) {
                        var o = u[P - 1].addedLength;
                        e.s <= _ && e.e >= _ + o ? (this.addSegment(s[n].v[P - 1], s[n].o[P - 1], s[n].i[0], s[n].v[0], r, k, S), S = !1) : (g = bez.getNewSegment(s[n].v[P - 1], s[n].v[0], s[n].o[P - 1], s[n].i[0], (e.s - _) / o, (e.e - _) / o, u[P - 1]), this.addSegmentFromArray(g, r, k, S), S = !1, r.c = !1)
                    } else r.c = !1;
                    _ += E.addedLength, k += 1
                }
                if (r._length && (r.setXYAt(r.v[m][0], r.v[m][1], "i", m), r.setXYAt(r.v[r._length - 1][0], r.v[r._length - 1][1], "o", r._length - 1)), _ > e.e) break;
                n < f - 1 && (r = shapePool.newElement(), S = !0, v.push(r), k = 0)
            }
            return v
        };

        function PuckerAndBloatModifier() {}
        extendPrototype([ShapeModifier], PuckerAndBloatModifier), PuckerAndBloatModifier.prototype.initModifierProperties = function(t, e) {
            this.getValue = this.processKeys, this.amount = PropertyFactory.getProp(t, e.a, 0, null, this), this._isAnimated = !!this.amount.effectsSequence.length
        }, PuckerAndBloatModifier.prototype.processPath = function(t, e) {
            var r = e / 100,
                i = [0, 0],
                s = t._length,
                n = 0;
            for (n = 0; n < s; n += 1) i[0] += t.v[n][0], i[1] += t.v[n][1];
            i[0] /= s, i[1] /= s;
            var f = shapePool.newElement();
            f.c = t.c;
            var P, d, _, E, k, u;
            for (n = 0; n < s; n += 1) P = t.v[n][0] + (i[0] - t.v[n][0]) * r, d = t.v[n][1] + (i[1] - t.v[n][1]) * r, _ = t.o[n][0] + (i[0] - t.o[n][0]) * -r, E = t.o[n][1] + (i[1] - t.o[n][1]) * -r, k = t.i[n][0] + (i[0] - t.i[n][0]) * -r, u = t.i[n][1] + (i[1] - t.i[n][1]) * -r, f.setTripleAt(P, d, _, E, k, u, n);
            return f
        }, PuckerAndBloatModifier.prototype.processShapes = function(t) {
            var e, r, i = this.shapes.length,
                s, n, f = this.amount.v;
            if (f !== 0) {
                var P, d;
                for (r = 0; r < i; r += 1) {
                    if (P = this.shapes[r], d = P.localShapeCollection, !(!P.shape._mdf && !this._mdf && !t))
                        for (d.releaseShapes(), P.shape._mdf = !0, e = P.shape.paths.shapes, n = P.shape.paths._length, s = 0; s < n; s += 1) d.addShape(this.processPath(e[s], f));
                    P.shape.paths = P.localShapeCollection
                }
            }
            this.dynamicProperties.length || (this._mdf = !1)
        };
        var TransformPropertyFactory = function() {
            var t = [0, 0];

            function e(d) {
                var _ = this._mdf;
                this.iterateDynamicProperties(), this._mdf = this._mdf || _, this.a && d.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.s && d.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && d.skewFromAxis(-this.sk.v, this.sa.v), this.r ? d.rotate(-this.r.v) : d.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.data.p.s ? this.data.p.z ? d.translate(this.px.v, this.py.v, -this.pz.v) : d.translate(this.px.v, this.py.v, 0) : d.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
            }

            function r(d) {
                if (this.elem.globalData.frameId !== this.frameId) {
                    if (this._isDirty && (this.precalculateMatrix(), this._isDirty = !1), this.iterateDynamicProperties(), this._mdf || d) {
                        var _;
                        if (this.v.cloneFromProps(this.pre.props), this.appliedTransformations < 1 && this.v.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations < 2 && this.v.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.sk && this.appliedTransformations < 3 && this.v.skewFromAxis(-this.sk.v, this.sa.v), this.r && this.appliedTransformations < 4 ? this.v.rotate(-this.r.v) : !this.r && this.appliedTransformations < 4 && this.v.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.autoOriented) {
                            var E, k;
                            if (_ = this.elem.globalData.frameRate, this.p && this.p.keyframes && this.p.getValueAtTime) this.p._caching.lastFrame + this.p.offsetTime <= this.p.keyframes[0].t ? (E = this.p.getValueAtTime((this.p.keyframes[0].t + .01) / _, 0), k = this.p.getValueAtTime(this.p.keyframes[0].t / _, 0)) : this.p._caching.lastFrame + this.p.offsetTime >= this.p.keyframes[this.p.keyframes.length - 1].t ? (E = this.p.getValueAtTime(this.p.keyframes[this.p.keyframes.length - 1].t / _, 0), k = this.p.getValueAtTime((this.p.keyframes[this.p.keyframes.length - 1].t - .05) / _, 0)) : (E = this.p.pv, k = this.p.getValueAtTime((this.p._caching.lastFrame + this.p.offsetTime - .01) / _, this.p.offsetTime));
                            else if (this.px && this.px.keyframes && this.py.keyframes && this.px.getValueAtTime && this.py.getValueAtTime) {
                                E = [], k = [];
                                var u = this.px,
                                    g = this.py;
                                u._caching.lastFrame + u.offsetTime <= u.keyframes[0].t ? (E[0] = u.getValueAtTime((u.keyframes[0].t + .01) / _, 0), E[1] = g.getValueAtTime((g.keyframes[0].t + .01) / _, 0), k[0] = u.getValueAtTime(u.keyframes[0].t / _, 0), k[1] = g.getValueAtTime(g.keyframes[0].t / _, 0)) : u._caching.lastFrame + u.offsetTime >= u.keyframes[u.keyframes.length - 1].t ? (E[0] = u.getValueAtTime(u.keyframes[u.keyframes.length - 1].t / _, 0), E[1] = g.getValueAtTime(g.keyframes[g.keyframes.length - 1].t / _, 0), k[0] = u.getValueAtTime((u.keyframes[u.keyframes.length - 1].t - .01) / _, 0), k[1] = g.getValueAtTime((g.keyframes[g.keyframes.length - 1].t - .01) / _, 0)) : (E = [u.pv, g.pv], k[0] = u.getValueAtTime((u._caching.lastFrame + u.offsetTime - .01) / _, u.offsetTime), k[1] = g.getValueAtTime((g._caching.lastFrame + g.offsetTime - .01) / _, g.offsetTime))
                            } else k = t, E = k;
                            this.v.rotate(-Math.atan2(E[1] - k[1], E[0] - k[0]))
                        }
                        this.data.p && this.data.p.s ? this.data.p.z ? this.v.translate(this.px.v, this.py.v, -this.pz.v) : this.v.translate(this.px.v, this.py.v, 0) : this.v.translate(this.p.v[0], this.p.v[1], -this.p.v[2])
                    }
                    this.frameId = this.elem.globalData.frameId
                }
            }

            function i() {
                if (!this.a.k) this.pre.translate(-this.a.v[0], -this.a.v[1], this.a.v[2]), this.appliedTransformations = 1;
                else return;
                if (!this.s.effectsSequence.length) this.pre.scale(this.s.v[0], this.s.v[1], this.s.v[2]), this.appliedTransformations = 2;
                else return;
                if (this.sk)
                    if (!this.sk.effectsSequence.length && !this.sa.effectsSequence.length) this.pre.skewFromAxis(-this.sk.v, this.sa.v), this.appliedTransformations = 3;
                    else return;
                this.r ? this.r.effectsSequence.length || (this.pre.rotate(-this.r.v), this.appliedTransformations = 4) : !this.rz.effectsSequence.length && !this.ry.effectsSequence.length && !this.rx.effectsSequence.length && !this.or.effectsSequence.length && (this.pre.rotateZ(-this.rz.v).rotateY(this.ry.v).rotateX(this.rx.v).rotateZ(-this.or.v[2]).rotateY(this.or.v[1]).rotateX(this.or.v[0]), this.appliedTransformations = 4)
            }

            function s() {}

            function n(d) {
                this._addDynamicProperty(d), this.elem.addDynamicProperty(d), this._isDirty = !0
            }

            function f(d, _, E) {
                if (this.elem = d, this.frameId = -1, this.propType = "transform", this.data = _, this.v = new Matrix, this.pre = new Matrix, this.appliedTransformations = 0, this.initDynamicPropertyContainer(E || d), _.p && _.p.s ? (this.px = PropertyFactory.getProp(d, _.p.x, 0, 0, this), this.py = PropertyFactory.getProp(d, _.p.y, 0, 0, this), _.p.z && (this.pz = PropertyFactory.getProp(d, _.p.z, 0, 0, this))) : this.p = PropertyFactory.getProp(d, _.p || {
                        k: [0, 0, 0]
                    }, 1, 0, this), _.rx) {
                    if (this.rx = PropertyFactory.getProp(d, _.rx, 0, degToRads, this), this.ry = PropertyFactory.getProp(d, _.ry, 0, degToRads, this), this.rz = PropertyFactory.getProp(d, _.rz, 0, degToRads, this), _.or.k[0].ti) {
                        var k, u = _.or.k.length;
                        for (k = 0; k < u; k += 1) _.or.k[k].to = null, _.or.k[k].ti = null
                    }
                    this.or = PropertyFactory.getProp(d, _.or, 1, degToRads, this), this.or.sh = !0
                } else this.r = PropertyFactory.getProp(d, _.r || {
                    k: 0
                }, 0, degToRads, this);
                _.sk && (this.sk = PropertyFactory.getProp(d, _.sk, 0, degToRads, this), this.sa = PropertyFactory.getProp(d, _.sa, 0, degToRads, this)), this.a = PropertyFactory.getProp(d, _.a || {
                    k: [0, 0, 0]
                }, 1, 0, this), this.s = PropertyFactory.getProp(d, _.s || {
                    k: [100, 100, 100]
                }, 1, .01, this), _.o ? this.o = PropertyFactory.getProp(d, _.o, 0, .01, d) : this.o = {
                    _mdf: !1,
                    v: 1
                }, this._isDirty = !0, this.dynamicProperties.length || this.getValue(!0)
            }
            f.prototype = {
                applyToMatrix: e,
                getValue: r,
                precalculateMatrix: i,
                autoOrient: s
            }, extendPrototype([DynamicPropertyContainer], f), f.prototype.addDynamicProperty = n, f.prototype._addDynamicProperty = DynamicPropertyContainer.prototype.addDynamicProperty;

            function P(d, _, E) {
                return new f(d, _, E)
            }
            return {
                getTransformProperty: P
            }
        }();

        function RepeaterModifier() {}
        extendPrototype([ShapeModifier], RepeaterModifier), RepeaterModifier.prototype.initModifierProperties = function(t, e) {
            this.getValue = this.processKeys, this.c = PropertyFactory.getProp(t, e.c, 0, null, this), this.o = PropertyFactory.getProp(t, e.o, 0, null, this), this.tr = TransformPropertyFactory.getTransformProperty(t, e.tr, this), this.so = PropertyFactory.getProp(t, e.tr.so, 0, .01, this), this.eo = PropertyFactory.getProp(t, e.tr.eo, 0, .01, this), this.data = e, this.dynamicProperties.length || this.getValue(!0), this._isAnimated = !!this.dynamicProperties.length, this.pMatrix = new Matrix, this.rMatrix = new Matrix, this.sMatrix = new Matrix, this.tMatrix = new Matrix, this.matrix = new Matrix
        }, RepeaterModifier.prototype.applyTransforms = function(t, e, r, i, s, n) {
            var f = n ? -1 : 1,
                P = i.s.v[0] + (1 - i.s.v[0]) * (1 - s),
                d = i.s.v[1] + (1 - i.s.v[1]) * (1 - s);
            t.translate(i.p.v[0] * f * s, i.p.v[1] * f * s, i.p.v[2]), e.translate(-i.a.v[0], -i.a.v[1], i.a.v[2]), e.rotate(-i.r.v * f * s), e.translate(i.a.v[0], i.a.v[1], i.a.v[2]), r.translate(-i.a.v[0], -i.a.v[1], i.a.v[2]), r.scale(n ? 1 / P : P, n ? 1 / d : d), r.translate(i.a.v[0], i.a.v[1], i.a.v[2])
        }, RepeaterModifier.prototype.init = function(t, e, r, i) {
            for (this.elem = t, this.arr = e, this.pos = r, this.elemsData = i, this._currentCopies = 0, this._elements = [], this._groups = [], this.frameId = -1, this.initDynamicPropertyContainer(t), this.initModifierProperties(t, e[r]); r > 0;) r -= 1, this._elements.unshift(e[r]);
            this.dynamicProperties.length ? this.k = !0 : this.getValue(!0)
        }, RepeaterModifier.prototype.resetElements = function(t) {
            var e, r = t.length;
            for (e = 0; e < r; e += 1) t[e]._processed = !1, t[e].ty === "gr" && this.resetElements(t[e].it)
        }, RepeaterModifier.prototype.cloneElements = function(t) {
            var e = JSON.parse(JSON.stringify(t));
            return this.resetElements(e), e
        }, RepeaterModifier.prototype.changeGroupRender = function(t, e) {
            var r, i = t.length;
            for (r = 0; r < i; r += 1) t[r]._render = e, t[r].ty === "gr" && this.changeGroupRender(t[r].it, e)
        }, RepeaterModifier.prototype.processShapes = function(t) {
            var e, r, i, s, n, f = !1;
            if (this._mdf || t) {
                var P = Math.ceil(this.c.v);
                if (this._groups.length < P) {
                    for (; this._groups.length < P;) {
                        var d = {
                            it: this.cloneElements(this._elements),
                            ty: "gr"
                        };
                        d.it.push({
                            a: {
                                a: 0,
                                ix: 1,
                                k: [0, 0]
                            },
                            nm: "Transform",
                            o: {
                                a: 0,
                                ix: 7,
                                k: 100
                            },
                            p: {
                                a: 0,
                                ix: 2,
                                k: [0, 0]
                            },
                            r: {
                                a: 1,
                                ix: 6,
                                k: [{
                                    s: 0,
                                    e: 0,
                                    t: 0
                                }, {
                                    s: 0,
                                    e: 0,
                                    t: 1
                                }]
                            },
                            s: {
                                a: 0,
                                ix: 3,
                                k: [100, 100]
                            },
                            sa: {
                                a: 0,
                                ix: 5,
                                k: 0
                            },
                            sk: {
                                a: 0,
                                ix: 4,
                                k: 0
                            },
                            ty: "tr"
                        }), this.arr.splice(0, 0, d), this._groups.splice(0, 0, d), this._currentCopies += 1
                    }
                    this.elem.reloadShapes(), f = !0
                }
                n = 0;
                var _;
                for (i = 0; i <= this._groups.length - 1; i += 1) {
                    if (_ = n < P, this._groups[i]._render = _, this.changeGroupRender(this._groups[i].it, _), !_) {
                        var E = this.elemsData[i].it,
                            k = E[E.length - 1];
                        k.transform.op.v !== 0 ? (k.transform.op._mdf = !0, k.transform.op.v = 0) : k.transform.op._mdf = !1
                    }
                    n += 1
                }
                this._currentCopies = P;
                var u = this.o.v,
                    g = u % 1,
                    v = u > 0 ? Math.floor(u) : Math.ceil(u),
                    m = this.pMatrix.props,
                    S = this.rMatrix.props,
                    o = this.sMatrix.props;
                this.pMatrix.reset(), this.rMatrix.reset(), this.sMatrix.reset(), this.tMatrix.reset(), this.matrix.reset();
                var l = 0;
                if (u > 0) {
                    for (; l < v;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), l += 1;
                    g && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, g, !1), l += g)
                } else if (u < 0) {
                    for (; l > v;) this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !0), l -= 1;
                    g && (this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, -g, !0), l -= g)
                }
                i = this.data.m === 1 ? 0 : this._currentCopies - 1, s = this.data.m === 1 ? 1 : -1, n = this._currentCopies;
                for (var a, h; n;) {
                    if (e = this.elemsData[i].it, r = e[e.length - 1].transform.mProps.v.props, h = r.length, e[e.length - 1].transform.mProps._mdf = !0, e[e.length - 1].transform.op._mdf = !0, e[e.length - 1].transform.op.v = this._currentCopies === 1 ? this.so.v : this.so.v + (this.eo.v - this.so.v) * (i / (this._currentCopies - 1)), l !== 0) {
                        for ((i !== 0 && s === 1 || i !== this._currentCopies - 1 && s === -1) && this.applyTransforms(this.pMatrix, this.rMatrix, this.sMatrix, this.tr, 1, !1), this.matrix.transform(S[0], S[1], S[2], S[3], S[4], S[5], S[6], S[7], S[8], S[9], S[10], S[11], S[12], S[13], S[14], S[15]), this.matrix.transform(o[0], o[1], o[2], o[3], o[4], o[5], o[6], o[7], o[8], o[9], o[10], o[11], o[12], o[13], o[14], o[15]), this.matrix.transform(m[0], m[1], m[2], m[3], m[4], m[5], m[6], m[7], m[8], m[9], m[10], m[11], m[12], m[13], m[14], m[15]), a = 0; a < h; a += 1) r[a] = this.matrix.props[a];
                        this.matrix.reset()
                    } else
                        for (this.matrix.reset(), a = 0; a < h; a += 1) r[a] = this.matrix.props[a];
                    l += 1, n -= 1, i += s
                }
            } else
                for (n = this._currentCopies, i = 0, s = 1; n;) e = this.elemsData[i].it, r = e[e.length - 1].transform.mProps.v.props, e[e.length - 1].transform.mProps._mdf = !1, e[e.length - 1].transform.op._mdf = !1, n -= 1, i += s;
            return f
        }, RepeaterModifier.prototype.addShape = function() {};

        function RoundCornersModifier() {}
        extendPrototype([ShapeModifier], RoundCornersModifier), RoundCornersModifier.prototype.initModifierProperties = function(t, e) {
            this.getValue = this.processKeys, this.rd = PropertyFactory.getProp(t, e.r, 0, null, this), this._isAnimated = !!this.rd.effectsSequence.length
        }, RoundCornersModifier.prototype.processPath = function(t, e) {
            var r = shapePool.newElement();
            r.c = t.c;
            var i, s = t._length,
                n, f, P, d, _, E, k = 0,
                u, g, v, m, S, o;
            for (i = 0; i < s; i += 1) n = t.v[i], P = t.o[i], f = t.i[i], n[0] === P[0] && n[1] === P[1] && n[0] === f[0] && n[1] === f[1] ? (i === 0 || i === s - 1) && !t.c ? (r.setTripleAt(n[0], n[1], P[0], P[1], f[0], f[1], k), k += 1) : (i === 0 ? d = t.v[s - 1] : d = t.v[i - 1], _ = Math.sqrt(Math.pow(n[0] - d[0], 2) + Math.pow(n[1] - d[1], 2)), E = _ ? Math.min(_ / 2, e) / _ : 0, S = n[0] + (d[0] - n[0]) * E, u = S, o = n[1] - (n[1] - d[1]) * E, g = o, v = u - (u - n[0]) * roundCorner, m = g - (g - n[1]) * roundCorner, r.setTripleAt(u, g, v, m, S, o, k), k += 1, i === s - 1 ? d = t.v[0] : d = t.v[i + 1], _ = Math.sqrt(Math.pow(n[0] - d[0], 2) + Math.pow(n[1] - d[1], 2)), E = _ ? Math.min(_ / 2, e) / _ : 0, v = n[0] + (d[0] - n[0]) * E, u = v, m = n[1] + (d[1] - n[1]) * E, g = m, S = u - (u - n[0]) * roundCorner, o = g - (g - n[1]) * roundCorner, r.setTripleAt(u, g, v, m, S, o, k), k += 1) : (r.setTripleAt(t.v[i][0], t.v[i][1], t.o[i][0], t.o[i][1], t.i[i][0], t.i[i][1], k), k += 1);
            return r
        }, RoundCornersModifier.prototype.processShapes = function(t) {
            var e, r, i = this.shapes.length,
                s, n, f = this.rd.v;
            if (f !== 0) {
                var P, d;
                for (r = 0; r < i; r += 1) {
                    if (P = this.shapes[r], d = P.localShapeCollection, !(!P.shape._mdf && !this._mdf && !t))
                        for (d.releaseShapes(), P.shape._mdf = !0, e = P.shape.paths.shapes, n = P.shape.paths._length, s = 0; s < n; s += 1) d.addShape(this.processPath(e[s], f));
                    P.shape.paths = P.localShapeCollection
                }
            }
            this.dynamicProperties.length || (this._mdf = !1)
        };

        function getFontProperties(t) {
            for (var e = t.fStyle ? t.fStyle.split(" ") : [], r = "normal", i = "normal", s = e.length, n, f = 0; f < s; f += 1) switch (n = e[f].toLowerCase(), n) {
                case "italic":
                    i = "italic";
                    break;
                case "bold":
                    r = "700";
                    break;
                case "black":
                    r = "900";
                    break;
                case "medium":
                    r = "500";
                    break;
                case "regular":
                case "normal":
                    r = "400";
                    break;
                case "light":
                case "thin":
                    r = "200";
                    break
            }
            return {
                style: i,
                weight: t.fWeight || r
            }
        }
        var FontManager = function() {
            var t = 5e3,
                e = {
                    w: 0,
                    size: 0,
                    shapes: [],
                    data: {
                        shapes: []
                    }
                },
                r = [];
            r = r.concat([2304, 2305, 2306, 2307, 2362, 2363, 2364, 2364, 2366, 2367, 2368, 2369, 2370, 2371, 2372, 2373, 2374, 2375, 2376, 2377, 2378, 2379, 2380, 2381, 2382, 2383, 2387, 2388, 2389, 2390, 2391, 2402, 2403]);
            var i = ["d83cdffb", "d83cdffc", "d83cdffd", "d83cdffe", "d83cdfff"],
                s = [65039, 8205];

            function n(h) {
                var p = h.split(","),
                    c, b = p.length,
                    A = [];
                for (c = 0; c < b; c += 1) p[c] !== "sans-serif" && p[c] !== "monospace" && A.push(p[c]);
                return A.join(",")
            }

            function f(h, p) {
                var c = createTag("span");
                c.setAttribute("aria-hidden", !0), c.style.fontFamily = p;
                var b = createTag("span");
                b.innerText = "giItT1WQy@!-/#", c.style.position = "absolute", c.style.left = "-10000px", c.style.top = "-10000px", c.style.fontSize = "300px", c.style.fontVariant = "normal", c.style.fontStyle = "normal", c.style.fontWeight = "normal", c.style.letterSpacing = "0", c.appendChild(b), document.body.appendChild(c);
                var A = b.offsetWidth;
                return b.style.fontFamily = n(h) + ", " + p, {
                    node: b,
                    w: A,
                    parent: c
                }
            }

            function P() {
                var h, p = this.fonts.length,
                    c, b, A = p;
                for (h = 0; h < p; h += 1) this.fonts[h].loaded ? A -= 1 : this.fonts[h].fOrigin === "n" || this.fonts[h].origin === 0 ? this.fonts[h].loaded = !0 : (c = this.fonts[h].monoCase.node, b = this.fonts[h].monoCase.w, c.offsetWidth !== b ? (A -= 1, this.fonts[h].loaded = !0) : (c = this.fonts[h].sansCase.node, b = this.fonts[h].sansCase.w, c.offsetWidth !== b && (A -= 1, this.fonts[h].loaded = !0)), this.fonts[h].loaded && (this.fonts[h].sansCase.parent.parentNode.removeChild(this.fonts[h].sansCase.parent), this.fonts[h].monoCase.parent.parentNode.removeChild(this.fonts[h].monoCase.parent)));
                A !== 0 && Date.now() - this.initTime < t ? setTimeout(this.checkLoadedFontsBinded, 20) : setTimeout(this.setIsLoadedBinded, 10)
            }

            function d(h, p) {
                var c = createNS("text");
                c.style.fontSize = "100px";
                var b = getFontProperties(p);
                c.setAttribute("font-family", p.fFamily), c.setAttribute("font-style", b.style), c.setAttribute("font-weight", b.weight), c.textContent = "1", p.fClass ? (c.style.fontFamily = "inherit", c.setAttribute("class", p.fClass)) : c.style.fontFamily = p.fFamily, h.appendChild(c);
                var A = createTag("canvas").getContext("2d");
                return A.font = p.fWeight + " " + p.fStyle + " 100px " + p.fFamily, c
            }

            function _(h, p) {
                if (!h) {
                    this.isLoaded = !0;
                    return
                }
                if (this.chars) {
                    this.isLoaded = !0, this.fonts = h.list;
                    return
                }
                var c = h.list,
                    b, A = c.length,
                    I = A;
                for (b = 0; b < A; b += 1) {
                    var R = !0,
                        L, w;
                    if (c[b].loaded = !1, c[b].monoCase = f(c[b].fFamily, "monospace"), c[b].sansCase = f(c[b].fFamily, "sans-serif"), !c[b].fPath) c[b].loaded = !0, I -= 1;
                    else if (c[b].fOrigin === "p" || c[b].origin === 3) {
                        if (L = document.querySelectorAll('style[f-forigin="p"][f-family="' + c[b].fFamily + '"], style[f-origin="3"][f-family="' + c[b].fFamily + '"]'), L.length > 0 && (R = !1), R) {
                            var G = createTag("style");
                            G.setAttribute("f-forigin", c[b].fOrigin), G.setAttribute("f-origin", c[b].origin), G.setAttribute("f-family", c[b].fFamily), G.type = "text/css", G.innerText = "@font-face {font-family: " + c[b].fFamily + "; font-style: normal; src: url('" + c[b].fPath + "');}", p.appendChild(G)
                        }
                    } else if (c[b].fOrigin === "g" || c[b].origin === 1) {
                        for (L = document.querySelectorAll('link[f-forigin="g"], link[f-origin="1"]'), w = 0; w < L.length; w += 1) L[w].href.indexOf(c[b].fPath) !== -1 && (R = !1);
                        if (R) {
                            var B = createTag("link");
                            B.setAttribute("f-forigin", c[b].fOrigin), B.setAttribute("f-origin", c[b].origin), B.type = "text/css", B.rel = "stylesheet", B.href = c[b].fPath, document.body.appendChild(B)
                        }
                    } else if (c[b].fOrigin === "t" || c[b].origin === 2) {
                        for (L = document.querySelectorAll('script[f-forigin="t"], script[f-origin="2"]'), w = 0; w < L.length; w += 1) c[b].fPath === L[w].src && (R = !1);
                        if (R) {
                            var C = createTag("link");
                            C.setAttribute("f-forigin", c[b].fOrigin), C.setAttribute("f-origin", c[b].origin), C.setAttribute("rel", "stylesheet"), C.setAttribute("href", c[b].fPath), p.appendChild(C)
                        }
                    }
                    c[b].helper = d(p, c[b]), c[b].cache = {}, this.fonts.push(c[b])
                }
                I === 0 ? this.isLoaded = !0 : setTimeout(this.checkLoadedFonts.bind(this), 100)
            }

            function E(h) {
                if (!!h) {
                    this.chars || (this.chars = []);
                    var p, c = h.length,
                        b, A = this.chars.length,
                        I;
                    for (p = 0; p < c; p += 1) {
                        for (b = 0, I = !1; b < A;) this.chars[b].style === h[p].style && this.chars[b].fFamily === h[p].fFamily && this.chars[b].ch === h[p].ch && (I = !0), b += 1;
                        I || (this.chars.push(h[p]), A += 1)
                    }
                }
            }

            function k(h, p, c) {
                for (var b = 0, A = this.chars.length; b < A;) {
                    if (this.chars[b].ch === h && this.chars[b].style === p && this.chars[b].fFamily === c) return this.chars[b];
                    b += 1
                }
                return (typeof h == "string" && h.charCodeAt(0) !== 13 || !h) && console && console.warn && !this._warned && (this._warned = !0, console.warn("Missing character from exported characters list: ", h, p, c)), e
            }

            function u(h, p, c) {
                var b = this.getFontByName(p),
                    A = h.charCodeAt(0);
                if (!b.cache[A + 1]) {
                    var I = b.helper;
                    if (h === " ") {
                        I.textContent = "|" + h + "|";
                        var R = I.getComputedTextLength();
                        I.textContent = "||";
                        var L = I.getComputedTextLength();
                        b.cache[A + 1] = (R - L) / 100
                    } else I.textContent = h, b.cache[A + 1] = I.getComputedTextLength() / 100
                }
                return b.cache[A + 1] * c
            }

            function g(h) {
                for (var p = 0, c = this.fonts.length; p < c;) {
                    if (this.fonts[p].fName === h) return this.fonts[p];
                    p += 1
                }
                return this.fonts[0]
            }

            function v(h, p) {
                var c = h.toString(16) + p.toString(16);
                return i.indexOf(c) !== -1
            }

            function m(h, p) {
                return p ? h === s[0] && p === s[1] : h === s[1]
            }

            function S(h) {
                return r.indexOf(h) !== -1
            }

            function o() {
                this.isLoaded = !0
            }
            var l = function() {
                this.fonts = [], this.chars = null, this.typekitLoaded = 0, this.isLoaded = !1, this._warned = !1, this.initTime = Date.now(), this.setIsLoadedBinded = this.setIsLoaded.bind(this), this.checkLoadedFontsBinded = this.checkLoadedFonts.bind(this)
            };
            l.isModifier = v, l.isZeroWidthJoiner = m, l.isCombinedCharacter = S;
            var a = {
                addChars: E,
                addFonts: _,
                getCharData: k,
                getFontByName: g,
                measureText: u,
                checkLoadedFonts: P,
                setIsLoaded: o
            };
            return l.prototype = a, l
        }();

        function RenderableElement() {}
        RenderableElement.prototype = {
            initRenderable: function() {
                this.isInRange = !1, this.hidden = !1, this.isTransparent = !1, this.renderableComponents = []
            },
            addRenderableComponent: function(e) {
                this.renderableComponents.indexOf(e) === -1 && this.renderableComponents.push(e)
            },
            removeRenderableComponent: function(e) {
                this.renderableComponents.indexOf(e) !== -1 && this.renderableComponents.splice(this.renderableComponents.indexOf(e), 1)
            },
            prepareRenderableFrame: function(e) {
                this.checkLayerLimits(e)
            },
            checkTransparency: function() {
                this.finalTransform.mProp.o.v <= 0 ? !this.isTransparent && this.globalData.renderConfig.hideOnTransparent && (this.isTransparent = !0, this.hide()) : this.isTransparent && (this.isTransparent = !1, this.show())
            },
            checkLayerLimits: function(e) {
                this.data.ip - this.data.st <= e && this.data.op - this.data.st > e ? this.isInRange !== !0 && (this.globalData._mdf = !0, this._mdf = !0, this.isInRange = !0, this.show()) : this.isInRange !== !1 && (this.globalData._mdf = !0, this.isInRange = !1, this.hide())
            },
            renderRenderable: function() {
                var e, r = this.renderableComponents.length;
                for (e = 0; e < r; e += 1) this.renderableComponents[e].renderFrame(this._isFirstFrame)
            },
            sourceRectAtTime: function() {
                return {
                    top: 0,
                    left: 0,
                    width: 100,
                    height: 100
                }
            },
            getLayerSize: function() {
                return this.data.ty === 5 ? {
                    w: this.data.textData.width,
                    h: this.data.textData.height
                } : {
                    w: this.data.width,
                    h: this.data.height
                }
            }
        };
        var MaskManagerInterface = function() {
                function t(r, i) {
                    this._mask = r, this._data = i
                }
                Object.defineProperty(t.prototype, "maskPath", {
                    get: function() {
                        return this._mask.prop.k && this._mask.prop.getValue(), this._mask.prop
                    }
                }), Object.defineProperty(t.prototype, "maskOpacity", {
                    get: function() {
                        return this._mask.op.k && this._mask.op.getValue(), this._mask.op.v * 100
                    }
                });
                var e = function(i) {
                    var s = createSizedArray(i.viewData.length),
                        n, f = i.viewData.length;
                    for (n = 0; n < f; n += 1) s[n] = new t(i.viewData[n], i.masksProperties[n]);
                    var P = function(_) {
                        for (n = 0; n < f;) {
                            if (i.masksProperties[n].nm === _) return s[n];
                            n += 1
                        }
                        return null
                    };
                    return P
                };
                return e
            }(),
            ExpressionPropertyInterface = function() {
                var t = {
                        pv: 0,
                        v: 0,
                        mult: 1
                    },
                    e = {
                        pv: [0, 0, 0],
                        v: [0, 0, 0],
                        mult: 1
                    };

                function r(f, P, d) {
                    Object.defineProperty(f, "velocity", {
                        get: function() {
                            return P.getVelocityAtTime(P.comp.currentFrame)
                        }
                    }), f.numKeys = P.keyframes ? P.keyframes.length : 0, f.key = function(_) {
                        if (!f.numKeys) return 0;
                        var E = "";
                        "s" in P.keyframes[_ - 1] ? E = P.keyframes[_ - 1].s : "e" in P.keyframes[_ - 2] ? E = P.keyframes[_ - 2].e : E = P.keyframes[_ - 2].s;
                        var k = d === "unidimensional" ? new Number(E) : Object.assign({}, E);
                        return k.time = P.keyframes[_ - 1].t / P.elem.comp.globalData.frameRate, k.value = d === "unidimensional" ? E[0] : E, k
                    }, f.valueAtTime = P.getValueAtTime, f.speedAtTime = P.getSpeedAtTime, f.velocityAtTime = P.getVelocityAtTime, f.propertyGroup = P.propertyGroup
                }

                function i(f) {
                    (!f || !("pv" in f)) && (f = t);
                    var P = 1 / f.mult,
                        d = f.pv * P,
                        _ = new Number(d);
                    return _.value = d, r(_, f, "unidimensional"),
                        function() {
                            return f.k && f.getValue(), d = f.v * P, _.value !== d && (_ = new Number(d), _.value = d, r(_, f, "unidimensional")), _
                        }
                }

                function s(f) {
                    (!f || !("pv" in f)) && (f = e);
                    var P = 1 / f.mult,
                        d = f.data && f.data.l || f.pv.length,
                        _ = createTypedArray("float32", d),
                        E = createTypedArray("float32", d);
                    return _.value = E, r(_, f, "multidimensional"),
                        function() {
                            f.k && f.getValue();
                            for (var k = 0; k < d; k += 1) E[k] = f.v[k] * P, _[k] = E[k];
                            return _
                        }
                }

                function n() {
                    return t
                }
                return function(f) {
                    return f ? f.propType === "unidimensional" ? i(f) : s(f) : n
                }
            }(),
            TransformExpressionInterface = function() {
                return function(t) {
                    function e(f) {
                        switch (f) {
                            case "scale":
                            case "Scale":
                            case "ADBE Scale":
                            case 6:
                                return e.scale;
                            case "rotation":
                            case "Rotation":
                            case "ADBE Rotation":
                            case "ADBE Rotate Z":
                            case 10:
                                return e.rotation;
                            case "ADBE Rotate X":
                                return e.xRotation;
                            case "ADBE Rotate Y":
                                return e.yRotation;
                            case "position":
                            case "Position":
                            case "ADBE Position":
                            case 2:
                                return e.position;
                            case "ADBE Position_0":
                                return e.xPosition;
                            case "ADBE Position_1":
                                return e.yPosition;
                            case "ADBE Position_2":
                                return e.zPosition;
                            case "anchorPoint":
                            case "AnchorPoint":
                            case "Anchor Point":
                            case "ADBE AnchorPoint":
                            case 1:
                                return e.anchorPoint;
                            case "opacity":
                            case "Opacity":
                            case 11:
                                return e.opacity;
                            default:
                                return null
                        }
                    }
                    Object.defineProperty(e, "rotation", {
                        get: ExpressionPropertyInterface(t.r || t.rz)
                    }), Object.defineProperty(e, "zRotation", {
                        get: ExpressionPropertyInterface(t.rz || t.r)
                    }), Object.defineProperty(e, "xRotation", {
                        get: ExpressionPropertyInterface(t.rx)
                    }), Object.defineProperty(e, "yRotation", {
                        get: ExpressionPropertyInterface(t.ry)
                    }), Object.defineProperty(e, "scale", {
                        get: ExpressionPropertyInterface(t.s)
                    });
                    var r, i, s, n;
                    return t.p ? n = ExpressionPropertyInterface(t.p) : (r = ExpressionPropertyInterface(t.px), i = ExpressionPropertyInterface(t.py), t.pz && (s = ExpressionPropertyInterface(t.pz))), Object.defineProperty(e, "position", {
                        get: function() {
                            return t.p ? n() : [r(), i(), s ? s() : 0]
                        }
                    }), Object.defineProperty(e, "xPosition", {
                        get: ExpressionPropertyInterface(t.px)
                    }), Object.defineProperty(e, "yPosition", {
                        get: ExpressionPropertyInterface(t.py)
                    }), Object.defineProperty(e, "zPosition", {
                        get: ExpressionPropertyInterface(t.pz)
                    }), Object.defineProperty(e, "anchorPoint", {
                        get: ExpressionPropertyInterface(t.a)
                    }), Object.defineProperty(e, "opacity", {
                        get: ExpressionPropertyInterface(t.o)
                    }), Object.defineProperty(e, "skew", {
                        get: ExpressionPropertyInterface(t.sk)
                    }), Object.defineProperty(e, "skewAxis", {
                        get: ExpressionPropertyInterface(t.sa)
                    }), Object.defineProperty(e, "orientation", {
                        get: ExpressionPropertyInterface(t.or)
                    }), e
                }
            }(),
            LayerExpressionInterface = function() {
                function t(_) {
                    var E = new Matrix;
                    if (_ !== void 0) {
                        var k = this._elem.finalTransform.mProp.getValueAtTime(_);
                        k.clone(E)
                    } else {
                        var u = this._elem.finalTransform.mProp;
                        u.applyToMatrix(E)
                    }
                    return E
                }

                function e(_, E) {
                    var k = this.getMatrix(E);
                    return k.props[12] = 0, k.props[13] = 0, k.props[14] = 0, this.applyPoint(k, _)
                }

                function r(_, E) {
                    var k = this.getMatrix(E);
                    return this.applyPoint(k, _)
                }

                function i(_, E) {
                    var k = this.getMatrix(E);
                    return k.props[12] = 0, k.props[13] = 0, k.props[14] = 0, this.invertPoint(k, _)
                }

                function s(_, E) {
                    var k = this.getMatrix(E);
                    return this.invertPoint(k, _)
                }

                function n(_, E) {
                    if (this._elem.hierarchy && this._elem.hierarchy.length) {
                        var k, u = this._elem.hierarchy.length;
                        for (k = 0; k < u; k += 1) this._elem.hierarchy[k].finalTransform.mProp.applyToMatrix(_)
                    }
                    return _.applyToPointArray(E[0], E[1], E[2] || 0)
                }

                function f(_, E) {
                    if (this._elem.hierarchy && this._elem.hierarchy.length) {
                        var k, u = this._elem.hierarchy.length;
                        for (k = 0; k < u; k += 1) this._elem.hierarchy[k].finalTransform.mProp.applyToMatrix(_)
                    }
                    return _.inversePoint(E)
                }

                function P(_) {
                    var E = new Matrix;
                    if (E.reset(), this._elem.finalTransform.mProp.applyToMatrix(E), this._elem.hierarchy && this._elem.hierarchy.length) {
                        var k, u = this._elem.hierarchy.length;
                        for (k = 0; k < u; k += 1) this._elem.hierarchy[k].finalTransform.mProp.applyToMatrix(E);
                        return E.inversePoint(_)
                    }
                    return E.inversePoint(_)
                }

                function d() {
                    return [1, 1, 1, 1]
                }
                return function(_) {
                    var E;

                    function k(m) {
                        g.mask = new MaskManagerInterface(m, _)
                    }

                    function u(m) {
                        g.effect = m
                    }

                    function g(m) {
                        switch (m) {
                            case "ADBE Root Vectors Group":
                            case "Contents":
                            case 2:
                                return g.shapeInterface;
                            case 1:
                            case 6:
                            case "Transform":
                            case "transform":
                            case "ADBE Transform Group":
                                return E;
                            case 4:
                            case "ADBE Effect Parade":
                            case "effects":
                            case "Effects":
                                return g.effect;
                            case "ADBE Text Properties":
                                return g.textInterface;
                            default:
                                return null
                        }
                    }
                    g.getMatrix = t, g.invertPoint = f, g.applyPoint = n, g.toWorld = r, g.toWorldVec = e, g.fromWorld = s, g.fromWorldVec = i, g.toComp = r, g.fromComp = P, g.sampleImage = d, g.sourceRectAtTime = _.sourceRectAtTime.bind(_), g._elem = _, E = TransformExpressionInterface(_.finalTransform.mProp);
                    var v = getDescriptor(E, "anchorPoint");
                    return Object.defineProperties(g, {
                        hasParent: {
                            get: function() {
                                return _.hierarchy.length
                            }
                        },
                        parent: {
                            get: function() {
                                return _.hierarchy[0].layerInterface
                            }
                        },
                        rotation: getDescriptor(E, "rotation"),
                        scale: getDescriptor(E, "scale"),
                        position: getDescriptor(E, "position"),
                        opacity: getDescriptor(E, "opacity"),
                        anchorPoint: v,
                        anchor_point: v,
                        transform: {
                            get: function() {
                                return E
                            }
                        },
                        active: {
                            get: function() {
                                return _.isInRange
                            }
                        }
                    }), g.startTime = _.data.st, g.index = _.data.ind, g.source = _.data.refId, g.height = _.data.ty === 0 ? _.data.h : 100, g.width = _.data.ty === 0 ? _.data.w : 100, g.inPoint = _.data.ip / _.comp.globalData.frameRate, g.outPoint = _.data.op / _.comp.globalData.frameRate, g._name = _.data.nm, g.registerMaskInterface = k, g.registerEffectsInterface = u, g
                }
            }(),
            propertyGroupFactory = function() {
                return function(t, e) {
                    return function(r) {
                        return r = r === void 0 ? 1 : r, r <= 0 ? t : e(r - 1)
                    }
                }
            }(),
            PropertyInterface = function() {
                return function(t, e) {
                    var r = {
                        _name: t
                    };

                    function i(s) {
                        return s = s === void 0 ? 1 : s, s <= 0 ? r : e(s - 1)
                    }
                    return i
                }
            }(),
            EffectsExpressionInterface = function() {
                var t = {
                    createEffectsInterface: e
                };

                function e(s, n) {
                    if (s.effectsManager) {
                        var f = [],
                            P = s.data.ef,
                            d, _ = s.effectsManager.effectElements.length;
                        for (d = 0; d < _; d += 1) f.push(r(P[d], s.effectsManager.effectElements[d], n, s));
                        var E = s.data.ef || [],
                            k = function(g) {
                                for (d = 0, _ = E.length; d < _;) {
                                    if (g === E[d].nm || g === E[d].mn || g === E[d].ix) return f[d];
                                    d += 1
                                }
                                return null
                            };
                        return Object.defineProperty(k, "numProperties", {
                            get: function() {
                                return E.length
                            }
                        }), k
                    }
                    return null
                }

                function r(s, n, f, P) {
                    function d(g) {
                        for (var v = s.ef, m = 0, S = v.length; m < S;) {
                            if (g === v[m].nm || g === v[m].mn || g === v[m].ix) return v[m].ty === 5 ? E[m] : E[m]();
                            m += 1
                        }
                        throw new Error
                    }
                    var _ = propertyGroupFactory(d, f),
                        E = [],
                        k, u = s.ef.length;
                    for (k = 0; k < u; k += 1) s.ef[k].ty === 5 ? E.push(r(s.ef[k], n.effectElements[k], n.effectElements[k].propertyGroup, P)) : E.push(i(n.effectElements[k], s.ef[k].ty, P, _));
                    return s.mn === "ADBE Color Control" && Object.defineProperty(d, "color", {
                        get: function() {
                            return E[0]()
                        }
                    }), Object.defineProperties(d, {
                        numProperties: {
                            get: function() {
                                return s.np
                            }
                        },
                        _name: {
                            value: s.nm
                        },
                        propertyGroup: {
                            value: _
                        }
                    }), d.enabled = s.en !== 0, d.active = d.enabled, d
                }

                function i(s, n, f, P) {
                    var d = ExpressionPropertyInterface(s.p);

                    function _() {
                        return n === 10 ? f.comp.compInterface(s.p.v) : d()
                    }
                    return s.p.setGroupProperty && s.p.setGroupProperty(PropertyInterface("", P)), _
                }
                return t
            }(),
            CompExpressionInterface = function() {
                return function(t) {
                    function e(r) {
                        for (var i = 0, s = t.layers.length; i < s;) {
                            if (t.layers[i].nm === r || t.layers[i].ind === r) return t.elements[i].layerInterface;
                            i += 1
                        }
                        return null
                    }
                    return Object.defineProperty(e, "_name", {
                        value: t.data.nm
                    }), e.layer = e, e.pixelAspect = 1, e.height = t.data.h || t.globalData.compSize.h, e.width = t.data.w || t.globalData.compSize.w, e.pixelAspect = 1, e.frameDuration = 1 / t.globalData.frameRate, e.displayStartTime = 0, e.numLayers = t.layers.length, e
                }
            }(),
            ShapePathInterface = function() {
                return function(e, r, i) {
                    var s = r.sh;

                    function n(P) {
                        return P === "Shape" || P === "shape" || P === "Path" || P === "path" || P === "ADBE Vector Shape" || P === 2 ? n.path : null
                    }
                    var f = propertyGroupFactory(n, i);
                    return s.setGroupProperty(PropertyInterface("Path", f)), Object.defineProperties(n, {
                        path: {
                            get: function() {
                                return s.k && s.getValue(), s
                            }
                        },
                        shape: {
                            get: function() {
                                return s.k && s.getValue(), s
                            }
                        },
                        _name: {
                            value: e.nm
                        },
                        ix: {
                            value: e.ix
                        },
                        propertyIndex: {
                            value: e.ix
                        },
                        mn: {
                            value: e.mn
                        },
                        propertyGroup: {
                            value: i
                        }
                    }), n
                }
            }(),
            ShapeExpressionInterface = function() {
                function t(v, m, S) {
                    var o = [],
                        l, a = v ? v.length : 0;
                    for (l = 0; l < a; l += 1) v[l].ty === "gr" ? o.push(r(v[l], m[l], S)) : v[l].ty === "fl" ? o.push(i(v[l], m[l], S)) : v[l].ty === "st" ? o.push(f(v[l], m[l], S)) : v[l].ty === "tm" ? o.push(P(v[l], m[l], S)) : v[l].ty === "tr" || (v[l].ty === "el" ? o.push(_(v[l], m[l], S)) : v[l].ty === "sr" ? o.push(E(v[l], m[l], S)) : v[l].ty === "sh" ? o.push(ShapePathInterface(v[l], m[l], S)) : v[l].ty === "rc" ? o.push(k(v[l], m[l], S)) : v[l].ty === "rd" ? o.push(u(v[l], m[l], S)) : v[l].ty === "rp" ? o.push(g(v[l], m[l], S)) : v[l].ty === "gf" ? o.push(s(v[l], m[l], S)) : o.push(n(v[l], m[l])));
                    return o
                }

                function e(v, m, S) {
                    var o, l = function(p) {
                        for (var c = 0, b = o.length; c < b;) {
                            if (o[c]._name === p || o[c].mn === p || o[c].propertyIndex === p || o[c].ix === p || o[c].ind === p) return o[c];
                            c += 1
                        }
                        return typeof p == "number" ? o[p - 1] : null
                    };
                    l.propertyGroup = propertyGroupFactory(l, S), o = t(v.it, m.it, l.propertyGroup), l.numProperties = o.length;
                    var a = d(v.it[v.it.length - 1], m.it[m.it.length - 1], l.propertyGroup);
                    return l.transform = a, l.propertyIndex = v.cix, l._name = v.nm, l
                }

                function r(v, m, S) {
                    var o = function(p) {
                        switch (p) {
                            case "ADBE Vectors Group":
                            case "Contents":
                            case 2:
                                return o.content;
                            default:
                                return o.transform
                        }
                    };
                    o.propertyGroup = propertyGroupFactory(o, S);
                    var l = e(v, m, o.propertyGroup),
                        a = d(v.it[v.it.length - 1], m.it[m.it.length - 1], o.propertyGroup);
                    return o.content = l, o.transform = a, Object.defineProperty(o, "_name", {
                        get: function() {
                            return v.nm
                        }
                    }), o.numProperties = v.np, o.propertyIndex = v.ix, o.nm = v.nm, o.mn = v.mn, o
                }

                function i(v, m, S) {
                    function o(l) {
                        return l === "Color" || l === "color" ? o.color : l === "Opacity" || l === "opacity" ? o.opacity : null
                    }
                    return Object.defineProperties(o, {
                        color: {
                            get: ExpressionPropertyInterface(m.c)
                        },
                        opacity: {
                            get: ExpressionPropertyInterface(m.o)
                        },
                        _name: {
                            value: v.nm
                        },
                        mn: {
                            value: v.mn
                        }
                    }), m.c.setGroupProperty(PropertyInterface("Color", S)), m.o.setGroupProperty(PropertyInterface("Opacity", S)), o
                }

                function s(v, m, S) {
                    function o(l) {
                        return l === "Start Point" || l === "start point" ? o.startPoint : l === "End Point" || l === "end point" ? o.endPoint : l === "Opacity" || l === "opacity" ? o.opacity : null
                    }
                    return Object.defineProperties(o, {
                        startPoint: {
                            get: ExpressionPropertyInterface(m.s)
                        },
                        endPoint: {
                            get: ExpressionPropertyInterface(m.e)
                        },
                        opacity: {
                            get: ExpressionPropertyInterface(m.o)
                        },
                        type: {
                            get: function() {
                                return "a"
                            }
                        },
                        _name: {
                            value: v.nm
                        },
                        mn: {
                            value: v.mn
                        }
                    }), m.s.setGroupProperty(PropertyInterface("Start Point", S)), m.e.setGroupProperty(PropertyInterface("End Point", S)), m.o.setGroupProperty(PropertyInterface("Opacity", S)), o
                }

                function n() {
                    function v() {
                        return null
                    }
                    return v
                }

                function f(v, m, S) {
                    var o = propertyGroupFactory(b, S),
                        l = propertyGroupFactory(c, o);

                    function a(A) {
                        Object.defineProperty(c, v.d[A].nm, {
                            get: ExpressionPropertyInterface(m.d.dataProps[A].p)
                        })
                    }
                    var h, p = v.d ? v.d.length : 0,
                        c = {};
                    for (h = 0; h < p; h += 1) a(h), m.d.dataProps[h].p.setGroupProperty(l);

                    function b(A) {
                        return A === "Color" || A === "color" ? b.color : A === "Opacity" || A === "opacity" ? b.opacity : A === "Stroke Width" || A === "stroke width" ? b.strokeWidth : null
                    }
                    return Object.defineProperties(b, {
                        color: {
                            get: ExpressionPropertyInterface(m.c)
                        },
                        opacity: {
                            get: ExpressionPropertyInterface(m.o)
                        },
                        strokeWidth: {
                            get: ExpressionPropertyInterface(m.w)
                        },
                        dash: {
                            get: function() {
                                return c
                            }
                        },
                        _name: {
                            value: v.nm
                        },
                        mn: {
                            value: v.mn
                        }
                    }), m.c.setGroupProperty(PropertyInterface("Color", o)), m.o.setGroupProperty(PropertyInterface("Opacity", o)), m.w.setGroupProperty(PropertyInterface("Stroke Width", o)), b
                }

                function P(v, m, S) {
                    function o(a) {
                        return a === v.e.ix || a === "End" || a === "end" ? o.end : a === v.s.ix ? o.start : a === v.o.ix ? o.offset : null
                    }
                    var l = propertyGroupFactory(o, S);
                    return o.propertyIndex = v.ix, m.s.setGroupProperty(PropertyInterface("Start", l)), m.e.setGroupProperty(PropertyInterface("End", l)), m.o.setGroupProperty(PropertyInterface("Offset", l)), o.propertyIndex = v.ix, o.propertyGroup = S, Object.defineProperties(o, {
                        start: {
                            get: ExpressionPropertyInterface(m.s)
                        },
                        end: {
                            get: ExpressionPropertyInterface(m.e)
                        },
                        offset: {
                            get: ExpressionPropertyInterface(m.o)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.mn = v.mn, o
                }

                function d(v, m, S) {
                    function o(a) {
                        return v.a.ix === a || a === "Anchor Point" ? o.anchorPoint : v.o.ix === a || a === "Opacity" ? o.opacity : v.p.ix === a || a === "Position" ? o.position : v.r.ix === a || a === "Rotation" || a === "ADBE Vector Rotation" ? o.rotation : v.s.ix === a || a === "Scale" ? o.scale : v.sk && v.sk.ix === a || a === "Skew" ? o.skew : v.sa && v.sa.ix === a || a === "Skew Axis" ? o.skewAxis : null
                    }
                    var l = propertyGroupFactory(o, S);
                    return m.transform.mProps.o.setGroupProperty(PropertyInterface("Opacity", l)), m.transform.mProps.p.setGroupProperty(PropertyInterface("Position", l)), m.transform.mProps.a.setGroupProperty(PropertyInterface("Anchor Point", l)), m.transform.mProps.s.setGroupProperty(PropertyInterface("Scale", l)), m.transform.mProps.r.setGroupProperty(PropertyInterface("Rotation", l)), m.transform.mProps.sk && (m.transform.mProps.sk.setGroupProperty(PropertyInterface("Skew", l)), m.transform.mProps.sa.setGroupProperty(PropertyInterface("Skew Angle", l))), m.transform.op.setGroupProperty(PropertyInterface("Opacity", l)), Object.defineProperties(o, {
                        opacity: {
                            get: ExpressionPropertyInterface(m.transform.mProps.o)
                        },
                        position: {
                            get: ExpressionPropertyInterface(m.transform.mProps.p)
                        },
                        anchorPoint: {
                            get: ExpressionPropertyInterface(m.transform.mProps.a)
                        },
                        scale: {
                            get: ExpressionPropertyInterface(m.transform.mProps.s)
                        },
                        rotation: {
                            get: ExpressionPropertyInterface(m.transform.mProps.r)
                        },
                        skew: {
                            get: ExpressionPropertyInterface(m.transform.mProps.sk)
                        },
                        skewAxis: {
                            get: ExpressionPropertyInterface(m.transform.mProps.sa)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.ty = "tr", o.mn = v.mn, o.propertyGroup = S, o
                }

                function _(v, m, S) {
                    function o(h) {
                        return v.p.ix === h ? o.position : v.s.ix === h ? o.size : null
                    }
                    var l = propertyGroupFactory(o, S);
                    o.propertyIndex = v.ix;
                    var a = m.sh.ty === "tm" ? m.sh.prop : m.sh;
                    return a.s.setGroupProperty(PropertyInterface("Size", l)), a.p.setGroupProperty(PropertyInterface("Position", l)), Object.defineProperties(o, {
                        size: {
                            get: ExpressionPropertyInterface(a.s)
                        },
                        position: {
                            get: ExpressionPropertyInterface(a.p)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.mn = v.mn, o
                }

                function E(v, m, S) {
                    function o(h) {
                        return v.p.ix === h ? o.position : v.r.ix === h ? o.rotation : v.pt.ix === h ? o.points : v.or.ix === h || h === "ADBE Vector Star Outer Radius" ? o.outerRadius : v.os.ix === h ? o.outerRoundness : v.ir && (v.ir.ix === h || h === "ADBE Vector Star Inner Radius") ? o.innerRadius : v.is && v.is.ix === h ? o.innerRoundness : null
                    }
                    var l = propertyGroupFactory(o, S),
                        a = m.sh.ty === "tm" ? m.sh.prop : m.sh;
                    return o.propertyIndex = v.ix, a.or.setGroupProperty(PropertyInterface("Outer Radius", l)), a.os.setGroupProperty(PropertyInterface("Outer Roundness", l)), a.pt.setGroupProperty(PropertyInterface("Points", l)), a.p.setGroupProperty(PropertyInterface("Position", l)), a.r.setGroupProperty(PropertyInterface("Rotation", l)), v.ir && (a.ir.setGroupProperty(PropertyInterface("Inner Radius", l)), a.is.setGroupProperty(PropertyInterface("Inner Roundness", l))), Object.defineProperties(o, {
                        position: {
                            get: ExpressionPropertyInterface(a.p)
                        },
                        rotation: {
                            get: ExpressionPropertyInterface(a.r)
                        },
                        points: {
                            get: ExpressionPropertyInterface(a.pt)
                        },
                        outerRadius: {
                            get: ExpressionPropertyInterface(a.or)
                        },
                        outerRoundness: {
                            get: ExpressionPropertyInterface(a.os)
                        },
                        innerRadius: {
                            get: ExpressionPropertyInterface(a.ir)
                        },
                        innerRoundness: {
                            get: ExpressionPropertyInterface(a.is)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.mn = v.mn, o
                }

                function k(v, m, S) {
                    function o(h) {
                        return v.p.ix === h ? o.position : v.r.ix === h ? o.roundness : v.s.ix === h || h === "Size" || h === "ADBE Vector Rect Size" ? o.size : null
                    }
                    var l = propertyGroupFactory(o, S),
                        a = m.sh.ty === "tm" ? m.sh.prop : m.sh;
                    return o.propertyIndex = v.ix, a.p.setGroupProperty(PropertyInterface("Position", l)), a.s.setGroupProperty(PropertyInterface("Size", l)), a.r.setGroupProperty(PropertyInterface("Rotation", l)), Object.defineProperties(o, {
                        position: {
                            get: ExpressionPropertyInterface(a.p)
                        },
                        roundness: {
                            get: ExpressionPropertyInterface(a.r)
                        },
                        size: {
                            get: ExpressionPropertyInterface(a.s)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.mn = v.mn, o
                }

                function u(v, m, S) {
                    function o(h) {
                        return v.r.ix === h || h === "Round Corners 1" ? o.radius : null
                    }
                    var l = propertyGroupFactory(o, S),
                        a = m;
                    return o.propertyIndex = v.ix, a.rd.setGroupProperty(PropertyInterface("Radius", l)), Object.defineProperties(o, {
                        radius: {
                            get: ExpressionPropertyInterface(a.rd)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.mn = v.mn, o
                }

                function g(v, m, S) {
                    function o(h) {
                        return v.c.ix === h || h === "Copies" ? o.copies : v.o.ix === h || h === "Offset" ? o.offset : null
                    }
                    var l = propertyGroupFactory(o, S),
                        a = m;
                    return o.propertyIndex = v.ix, a.c.setGroupProperty(PropertyInterface("Copies", l)), a.o.setGroupProperty(PropertyInterface("Offset", l)), Object.defineProperties(o, {
                        copies: {
                            get: ExpressionPropertyInterface(a.c)
                        },
                        offset: {
                            get: ExpressionPropertyInterface(a.o)
                        },
                        _name: {
                            value: v.nm
                        }
                    }), o.mn = v.mn, o
                }
                return function(v, m, S) {
                    var o;

                    function l(h) {
                        if (typeof h == "number") return h = h === void 0 ? 1 : h, h === 0 ? S : o[h - 1];
                        for (var p = 0, c = o.length; p < c;) {
                            if (o[p]._name === h) return o[p];
                            p += 1
                        }
                        return null
                    }

                    function a() {
                        return S
                    }
                    return l.propertyGroup = propertyGroupFactory(l, a), o = t(v, m, l.propertyGroup), l.numProperties = o.length, l._name = "Contents", l
                }
            }(),
            TextExpressionInterface = function() {
                return function(t) {
                    var e, r;

                    function i(s) {
                        switch (s) {
                            case "ADBE Text Document":
                                return i.sourceText;
                            default:
                                return null
                        }
                    }
                    return Object.defineProperty(i, "sourceText", {
                        get: function() {
                            t.textProperty.getValue();
                            var n = t.textProperty.currentData.t;
                            return n !== e && (t.textProperty.currentData.t = e, r = new String(n), r.value = n || new String(n)), r
                        }
                    }), i
                }
            }(),
            getBlendMode = function() {
                var t = {
                    0: "source-over",
                    1: "multiply",
                    2: "screen",
                    3: "overlay",
                    4: "darken",
                    5: "lighten",
                    6: "color-dodge",
                    7: "color-burn",
                    8: "hard-light",
                    9: "soft-light",
                    10: "difference",
                    11: "exclusion",
                    12: "hue",
                    13: "saturation",
                    14: "color",
                    15: "luminosity"
                };
                return function(e) {
                    return t[e] || ""
                }
            }();

        function SliderEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 0, 0, r)
        }

        function AngleEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 0, 0, r)
        }

        function ColorEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 1, 0, r)
        }

        function PointEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 1, 0, r)
        }

        function LayerIndexEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 0, 0, r)
        }

        function MaskIndexEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 0, 0, r)
        }

        function CheckboxEffect(t, e, r) {
            this.p = PropertyFactory.getProp(e, t.v, 0, 0, r)
        }

        function NoValueEffect() {
            this.p = {}
        }

        function EffectsManager(t, e) {
            var r = t.ef || [];
            this.effectElements = [];
            var i, s = r.length,
                n;
            for (i = 0; i < s; i += 1) n = new GroupEffect(r[i], e), this.effectElements.push(n)
        }

        function GroupEffect(t, e) {
            this.init(t, e)
        }
        extendPrototype([DynamicPropertyContainer], GroupEffect), GroupEffect.prototype.getValue = GroupEffect.prototype.iterateDynamicProperties, GroupEffect.prototype.init = function(t, e) {
            this.data = t, this.effectElements = [], this.initDynamicPropertyContainer(e);
            var r, i = this.data.ef.length,
                s, n = this.data.ef;
            for (r = 0; r < i; r += 1) {
                switch (s = null, n[r].ty) {
                    case 0:
                        s = new SliderEffect(n[r], e, this);
                        break;
                    case 1:
                        s = new AngleEffect(n[r], e, this);
                        break;
                    case 2:
                        s = new ColorEffect(n[r], e, this);
                        break;
                    case 3:
                        s = new PointEffect(n[r], e, this);
                        break;
                    case 4:
                    case 7:
                        s = new CheckboxEffect(n[r], e, this);
                        break;
                    case 10:
                        s = new LayerIndexEffect(n[r], e, this);
                        break;
                    case 11:
                        s = new MaskIndexEffect(n[r], e, this);
                        break;
                    case 5:
                        s = new EffectsManager(n[r], e, this);
                        break;
                    default:
                        s = new NoValueEffect(n[r], e, this);
                        break
                }
                s && this.effectElements.push(s)
            }
        };

        function BaseElement() {}
        BaseElement.prototype = {
            checkMasks: function() {
                if (!this.data.hasMask) return !1;
                for (var e = 0, r = this.data.masksProperties.length; e < r;) {
                    if (this.data.masksProperties[e].mode !== "n" && this.data.masksProperties[e].cl !== !1) return !0;
                    e += 1
                }
                return !1
            },
            initExpressions: function() {
                this.layerInterface = LayerExpressionInterface(this), this.data.hasMask && this.maskManager && this.layerInterface.registerMaskInterface(this.maskManager);
                var e = EffectsExpressionInterface.createEffectsInterface(this, this.layerInterface);
                this.layerInterface.registerEffectsInterface(e), this.data.ty === 0 || this.data.xt ? this.compInterface = CompExpressionInterface(this) : this.data.ty === 4 ? (this.layerInterface.shapeInterface = ShapeExpressionInterface(this.shapesData, this.itemsData, this.layerInterface), this.layerInterface.content = this.layerInterface.shapeInterface) : this.data.ty === 5 && (this.layerInterface.textInterface = TextExpressionInterface(this), this.layerInterface.text = this.layerInterface.textInterface)
            },
            setBlendMode: function() {
                var e = getBlendMode(this.data.bm),
                    r = this.baseElement || this.layerElement;
                r.style["mix-blend-mode"] = e
            },
            initBaseData: function(e, r, i) {
                this.globalData = r, this.comp = i, this.data = e, this.layerId = createElementID(), this.data.sr || (this.data.sr = 1), this.effectsManager = new EffectsManager(this.data, this, this.dynamicProperties)
            },
            getType: function() {
                return this.type
            },
            sourceRectAtTime: function() {}
        };

        function FrameElement() {}
        FrameElement.prototype = {
            initFrame: function() {
                this._isFirstFrame = !1, this.dynamicProperties = [], this._mdf = !1
            },
            prepareProperties: function(e, r) {
                var i, s = this.dynamicProperties.length;
                for (i = 0; i < s; i += 1)(r || this._isParent && this.dynamicProperties[i].propType === "transform") && (this.dynamicProperties[i].getValue(), this.dynamicProperties[i]._mdf && (this.globalData._mdf = !0, this._mdf = !0))
            },
            addDynamicProperty: function(e) {
                this.dynamicProperties.indexOf(e) === -1 && this.dynamicProperties.push(e)
            }
        };

        function _typeof$2(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof$2 = function(r) {
                return typeof r
            } : _typeof$2 = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof$2(t)
        }
        var FootageInterface = function() {
            var t = function(i) {
                    var s = "",
                        n = i.getFootageData();

                    function f() {
                        return s = "", n = i.getFootageData(), P
                    }

                    function P(d) {
                        if (n[d]) return s = d, n = n[d], _typeof$2(n) === "object" ? P : n;
                        var _ = d.indexOf(s);
                        if (_ !== -1) {
                            var E = parseInt(d.substr(_ + s.length), 10);
                            return n = n[E], _typeof$2(n) === "object" ? P : n
                        }
                        return ""
                    }
                    return f
                },
                e = function(i) {
                    function s(n) {
                        return n === "Outline" ? s.outlineInterface() : null
                    }
                    return s._name = "Outline", s.outlineInterface = t(i), s
                };
            return function(r) {
                function i(s) {
                    return s === "Data" ? i.dataInterface : null
                }
                return i._name = "Data", i.dataInterface = e(r), i
            }
        }();

        function FootageElement(t, e, r) {
            this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.footageData = e.imageLoader.getAsset(this.assetData), this.initBaseData(t, e, r)
        }
        FootageElement.prototype.prepareFrame = function() {}, extendPrototype([RenderableElement, BaseElement, FrameElement], FootageElement), FootageElement.prototype.getBaseElement = function() {
            return null
        }, FootageElement.prototype.renderFrame = function() {}, FootageElement.prototype.destroy = function() {}, FootageElement.prototype.initExpressions = function() {
            this.layerInterface = FootageInterface(this)
        }, FootageElement.prototype.getFootageData = function() {
            return this.footageData
        };

        function AudioElement(t, e, r) {
            this.initFrame(), this.initRenderable(), this.assetData = e.getAssetData(t.refId), this.initBaseData(t, e, r), this._isPlaying = !1, this._canPlay = !1;
            var i = this.globalData.getAssetsPath(this.assetData);
            this.audio = this.globalData.audioController.createAudio(i), this._currentTime = 0, this.globalData.audioController.addAudio(this), this.tm = t.tm ? PropertyFactory.getProp(this, t.tm, 0, e.frameRate, this) : {
                _placeholder: !0
            }
        }
        AudioElement.prototype.prepareFrame = function(t) {
            if (this.prepareRenderableFrame(t, !0), this.prepareProperties(t, !0), this.tm._placeholder) this._currentTime = t / this.data.sr;
            else {
                var e = this.tm.v;
                this._currentTime = e
            }
        }, extendPrototype([RenderableElement, BaseElement, FrameElement], AudioElement), AudioElement.prototype.renderFrame = function() {
            this.isInRange && this._canPlay && (this._isPlaying ? (!this.audio.playing() || Math.abs(this._currentTime / this.globalData.frameRate - this.audio.seek()) > .1) && this.audio.seek(this._currentTime / this.globalData.frameRate) : (this.audio.play(), this.audio.seek(this._currentTime / this.globalData.frameRate), this._isPlaying = !0))
        }, AudioElement.prototype.show = function() {}, AudioElement.prototype.hide = function() {
            this.audio.pause(), this._isPlaying = !1
        }, AudioElement.prototype.pause = function() {
            this.audio.pause(), this._isPlaying = !1, this._canPlay = !1
        }, AudioElement.prototype.resume = function() {
            this._canPlay = !0
        }, AudioElement.prototype.setRate = function(t) {
            this.audio.rate(t)
        }, AudioElement.prototype.volume = function(t) {
            this.audio.volume(t)
        }, AudioElement.prototype.getBaseElement = function() {
            return null
        }, AudioElement.prototype.destroy = function() {}, AudioElement.prototype.sourceRectAtTime = function() {}, AudioElement.prototype.initExpressions = function() {};

        function BaseRenderer() {}
        BaseRenderer.prototype.checkLayers = function(t) {
            var e, r = this.layers.length,
                i;
            for (this.completeLayers = !0, e = r - 1; e >= 0; e -= 1) this.elements[e] || (i = this.layers[e], i.ip - i.st <= t - this.layers[e].st && i.op - i.st > t - this.layers[e].st && this.buildItem(e)), this.completeLayers = this.elements[e] ? this.completeLayers : !1;
            this.checkPendingElements()
        }, BaseRenderer.prototype.createItem = function(t) {
            switch (t.ty) {
                case 2:
                    return this.createImage(t);
                case 0:
                    return this.createComp(t);
                case 1:
                    return this.createSolid(t);
                case 3:
                    return this.createNull(t);
                case 4:
                    return this.createShape(t);
                case 5:
                    return this.createText(t);
                case 6:
                    return this.createAudio(t);
                case 13:
                    return this.createCamera(t);
                case 15:
                    return this.createFootage(t);
                default:
                    return this.createNull(t)
            }
        }, BaseRenderer.prototype.createCamera = function() {
            throw new Error("You're using a 3d camera. Try the html renderer.")
        }, BaseRenderer.prototype.createAudio = function(t) {
            return new AudioElement(t, this.globalData, this)
        }, BaseRenderer.prototype.createFootage = function(t) {
            return new FootageElement(t, this.globalData, this)
        }, BaseRenderer.prototype.buildAllItems = function() {
            var t, e = this.layers.length;
            for (t = 0; t < e; t += 1) this.buildItem(t);
            this.checkPendingElements()
        }, BaseRenderer.prototype.includeLayers = function(t) {
            this.completeLayers = !1;
            var e, r = t.length,
                i, s = this.layers.length;
            for (e = 0; e < r; e += 1)
                for (i = 0; i < s;) {
                    if (this.layers[i].id === t[e].id) {
                        this.layers[i] = t[e];
                        break
                    }
                    i += 1
                }
        }, BaseRenderer.prototype.setProjectInterface = function(t) {
            this.globalData.projectInterface = t
        }, BaseRenderer.prototype.initItems = function() {
            this.globalData.progressiveLoad || this.buildAllItems()
        }, BaseRenderer.prototype.buildElementParenting = function(t, e, r) {
            for (var i = this.elements, s = this.layers, n = 0, f = s.length; n < f;) s[n].ind == e && (!i[n] || i[n] === !0 ? (this.buildItem(n), this.addPendingElement(t)) : (r.push(i[n]), i[n].setAsParent(), s[n].parent !== void 0 ? this.buildElementParenting(t, s[n].parent, r) : t.setHierarchy(r))), n += 1
        }, BaseRenderer.prototype.addPendingElement = function(t) {
            this.pendingElements.push(t)
        }, BaseRenderer.prototype.searchExtraCompositions = function(t) {
            var e, r = t.length;
            for (e = 0; e < r; e += 1)
                if (t[e].xt) {
                    var i = this.createComp(t[e]);
                    i.initExpressions(), this.globalData.projectInterface.registerComposition(i)
                }
        }, BaseRenderer.prototype.setupGlobalData = function(t, e) {
            this.globalData.fontManager = new FontManager, this.globalData.fontManager.addChars(t.chars), this.globalData.fontManager.addFonts(t.fonts, e), this.globalData.getAssetData = this.animationItem.getAssetData.bind(this.animationItem), this.globalData.getAssetsPath = this.animationItem.getAssetsPath.bind(this.animationItem), this.globalData.imageLoader = this.animationItem.imagePreloader, this.globalData.audioController = this.animationItem.audioController, this.globalData.frameId = 0, this.globalData.frameRate = t.fr, this.globalData.nm = t.nm, this.globalData.compSize = {
                w: t.w,
                h: t.h
            }
        };

        function TransformElement() {}
        TransformElement.prototype = {
            initTransform: function() {
                this.finalTransform = {
                    mProp: this.data.ks ? TransformPropertyFactory.getTransformProperty(this, this.data.ks, this) : {
                        o: 0
                    },
                    _matMdf: !1,
                    _opMdf: !1,
                    mat: new Matrix
                }, this.data.ao && (this.finalTransform.mProp.autoOriented = !0), this.data.ty
            },
            renderTransform: function() {
                if (this.finalTransform._opMdf = this.finalTransform.mProp.o._mdf || this._isFirstFrame, this.finalTransform._matMdf = this.finalTransform.mProp._mdf || this._isFirstFrame, this.hierarchy) {
                    var e, r = this.finalTransform.mat,
                        i = 0,
                        s = this.hierarchy.length;
                    if (!this.finalTransform._matMdf)
                        for (; i < s;) {
                            if (this.hierarchy[i].finalTransform.mProp._mdf) {
                                this.finalTransform._matMdf = !0;
                                break
                            }
                            i += 1
                        }
                    if (this.finalTransform._matMdf)
                        for (e = this.finalTransform.mProp.v.props, r.cloneFromProps(e), i = 0; i < s; i += 1) e = this.hierarchy[i].finalTransform.mProp.v.props, r.transform(e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], e[9], e[10], e[11], e[12], e[13], e[14], e[15])
                }
            },
            globalToLocal: function(e) {
                var r = [];
                r.push(this.finalTransform);
                for (var i = !0, s = this.comp; i;) s.finalTransform ? (s.data.hasMask && r.splice(0, 0, s.finalTransform), s = s.comp) : i = !1;
                var n, f = r.length,
                    P;
                for (n = 0; n < f; n += 1) P = r[n].mat.applyToPointArray(0, 0, 0), e = [e[0] - P[0], e[1] - P[1], 0];
                return e
            },
            mHelper: new Matrix
        };

        function MaskElement(t, e, r) {
            this.data = t, this.element = e, this.globalData = r, this.storedData = [], this.masksProperties = this.data.masksProperties || [], this.maskElement = null;
            var i = this.globalData.defs,
                s, n = this.masksProperties ? this.masksProperties.length : 0;
            this.viewData = createSizedArray(n), this.solidPath = "";
            var f, P = this.masksProperties,
                d = 0,
                _ = [],
                E, k, u = createElementID(),
                g, v, m, S, o = "clipPath",
                l = "clip-path";
            for (s = 0; s < n; s += 1)
                if ((P[s].mode !== "a" && P[s].mode !== "n" || P[s].inv || P[s].o.k !== 100 || P[s].o.x) && (o = "mask", l = "mask"), (P[s].mode === "s" || P[s].mode === "i") && d === 0 ? (g = createNS("rect"), g.setAttribute("fill", "#ffffff"), g.setAttribute("width", this.element.comp.data.w || 0), g.setAttribute("height", this.element.comp.data.h || 0), _.push(g)) : g = null, f = createNS("path"), P[s].mode === "n") this.viewData[s] = {
                    op: PropertyFactory.getProp(this.element, P[s].o, 0, .01, this.element),
                    prop: ShapePropertyFactory.getShapeProp(this.element, P[s], 3),
                    elem: f,
                    lastPath: ""
                }, i.appendChild(f);
                else {
                    d += 1, f.setAttribute("fill", P[s].mode === "s" ? "#000000" : "#ffffff"), f.setAttribute("clip-rule", "nonzero");
                    var a;
                    if (P[s].x.k !== 0 ? (o = "mask", l = "mask", S = PropertyFactory.getProp(this.element, P[s].x, 0, null, this.element), a = createElementID(), v = createNS("filter"), v.setAttribute("id", a), m = createNS("feMorphology"), m.setAttribute("operator", "erode"), m.setAttribute("in", "SourceGraphic"), m.setAttribute("radius", "0"), v.appendChild(m), i.appendChild(v), f.setAttribute("stroke", P[s].mode === "s" ? "#000000" : "#ffffff")) : (m = null, S = null), this.storedData[s] = {
                            elem: f,
                            x: S,
                            expan: m,
                            lastPath: "",
                            lastOperator: "",
                            filterId: a,
                            lastRadius: 0
                        }, P[s].mode === "i") {
                        k = _.length;
                        var h = createNS("g");
                        for (E = 0; E < k; E += 1) h.appendChild(_[E]);
                        var p = createNS("mask");
                        p.setAttribute("mask-type", "alpha"), p.setAttribute("id", u + "_" + d), p.appendChild(f), i.appendChild(p), h.setAttribute("mask", "url(" + getLocationHref() + "#" + u + "_" + d + ")"), _.length = 0, _.push(h)
                    } else _.push(f);
                    P[s].inv && !this.solidPath && (this.solidPath = this.createLayerSolidPath()), this.viewData[s] = {
                        elem: f,
                        lastPath: "",
                        op: PropertyFactory.getProp(this.element, P[s].o, 0, .01, this.element),
                        prop: ShapePropertyFactory.getShapeProp(this.element, P[s], 3),
                        invRect: g
                    }, this.viewData[s].prop.k || this.drawPath(P[s], this.viewData[s].prop.v, this.viewData[s])
                }
            for (this.maskElement = createNS(o), n = _.length, s = 0; s < n; s += 1) this.maskElement.appendChild(_[s]);
            d > 0 && (this.maskElement.setAttribute("id", u), this.element.maskedElement.setAttribute(l, "url(" + getLocationHref() + "#" + u + ")"), i.appendChild(this.maskElement)), this.viewData.length && this.element.addRenderableComponent(this)
        }
        MaskElement.prototype.getMaskProperty = function(t) {
            return this.viewData[t].prop
        }, MaskElement.prototype.renderFrame = function(t) {
            var e = this.element.finalTransform.mat,
                r, i = this.masksProperties.length;
            for (r = 0; r < i; r += 1)
                if ((this.viewData[r].prop._mdf || t) && this.drawPath(this.masksProperties[r], this.viewData[r].prop.v, this.viewData[r]), (this.viewData[r].op._mdf || t) && this.viewData[r].elem.setAttribute("fill-opacity", this.viewData[r].op.v), this.masksProperties[r].mode !== "n" && (this.viewData[r].invRect && (this.element.finalTransform.mProp._mdf || t) && this.viewData[r].invRect.setAttribute("transform", e.getInverseMatrix().to2dCSS()), this.storedData[r].x && (this.storedData[r].x._mdf || t))) {
                    var s = this.storedData[r].expan;
                    this.storedData[r].x.v < 0 ? (this.storedData[r].lastOperator !== "erode" && (this.storedData[r].lastOperator = "erode", this.storedData[r].elem.setAttribute("filter", "url(" + getLocationHref() + "#" + this.storedData[r].filterId + ")")), s.setAttribute("radius", -this.storedData[r].x.v)) : (this.storedData[r].lastOperator !== "dilate" && (this.storedData[r].lastOperator = "dilate", this.storedData[r].elem.setAttribute("filter", null)), this.storedData[r].elem.setAttribute("stroke-width", this.storedData[r].x.v * 2))
                }
        }, MaskElement.prototype.getMaskelement = function() {
            return this.maskElement
        }, MaskElement.prototype.createLayerSolidPath = function() {
            var t = "M0,0 ";
            return t += " h" + this.globalData.compSize.w, t += " v" + this.globalData.compSize.h, t += " h-" + this.globalData.compSize.w, t += " v-" + this.globalData.compSize.h + " ", t
        }, MaskElement.prototype.drawPath = function(t, e, r) {
            var i = " M" + e.v[0][0] + "," + e.v[0][1],
                s, n;
            for (n = e._length, s = 1; s < n; s += 1) i += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[s][0] + "," + e.i[s][1] + " " + e.v[s][0] + "," + e.v[s][1];
            if (e.c && n > 1 && (i += " C" + e.o[s - 1][0] + "," + e.o[s - 1][1] + " " + e.i[0][0] + "," + e.i[0][1] + " " + e.v[0][0] + "," + e.v[0][1]), r.lastPath !== i) {
                var f = "";
                r.elem && (e.c && (f = t.inv ? this.solidPath + i : i), r.elem.setAttribute("d", f)), r.lastPath = i
            }
        }, MaskElement.prototype.destroy = function() {
            this.element = null, this.globalData = null, this.maskElement = null, this.data = null, this.masksProperties = null
        };
        var filtersFactory = function() {
                var t = {};
                t.createFilter = e, t.createAlphaToLuminanceFilter = r;

                function e(i, s) {
                    var n = createNS("filter");
                    return n.setAttribute("id", i), s !== !0 && (n.setAttribute("filterUnits", "objectBoundingBox"), n.setAttribute("x", "0%"), n.setAttribute("y", "0%"), n.setAttribute("width", "100%"), n.setAttribute("height", "100%")), n
                }

                function r() {
                    var i = createNS("feColorMatrix");
                    return i.setAttribute("type", "matrix"), i.setAttribute("color-interpolation-filters", "sRGB"), i.setAttribute("values", "0 0 0 1 0  0 0 0 1 0  0 0 0 1 0  0 0 0 1 1"), i
                }
                return t
            }(),
            featureSupport = function() {
                var t = {
                    maskType: !0
                };
                return (/MSIE 10/i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(navigator.userAgent) || /Edge\/\d./i.test(navigator.userAgent)) && (t.maskType = !1), t
            }();

        function SVGTintFilter(t, e) {
            this.filterManager = e;
            var r = createNS("feColorMatrix");
            if (r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "linearRGB"), r.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), r.setAttribute("result", "f1"), t.appendChild(r), r = createNS("feColorMatrix"), r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "sRGB"), r.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), r.setAttribute("result", "f2"), t.appendChild(r), this.matrixFilter = r, e.effectElements[2].p.v !== 100 || e.effectElements[2].p.k) {
                var i = createNS("feMerge");
                t.appendChild(i);
                var s;
                s = createNS("feMergeNode"), s.setAttribute("in", "SourceGraphic"), i.appendChild(s), s = createNS("feMergeNode"), s.setAttribute("in", "f2"), i.appendChild(s)
            }
        }
        SVGTintFilter.prototype.renderFrame = function(t) {
            if (t || this.filterManager._mdf) {
                var e = this.filterManager.effectElements[0].p.v,
                    r = this.filterManager.effectElements[1].p.v,
                    i = this.filterManager.effectElements[2].p.v / 100;
                this.matrixFilter.setAttribute("values", r[0] - e[0] + " 0 0 0 " + e[0] + " " + (r[1] - e[1]) + " 0 0 0 " + e[1] + " " + (r[2] - e[2]) + " 0 0 0 " + e[2] + " 0 0 0 " + i + " 0")
            }
        };

        function SVGFillFilter(t, e) {
            this.filterManager = e;
            var r = createNS("feColorMatrix");
            r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "sRGB"), r.setAttribute("values", "1 0 0 0 0 0 1 0 0 0 0 0 1 0 0 0 0 0 1 0"), t.appendChild(r), this.matrixFilter = r
        }
        SVGFillFilter.prototype.renderFrame = function(t) {
            if (t || this.filterManager._mdf) {
                var e = this.filterManager.effectElements[2].p.v,
                    r = this.filterManager.effectElements[6].p.v;
                this.matrixFilter.setAttribute("values", "0 0 0 0 " + e[0] + " 0 0 0 0 " + e[1] + " 0 0 0 0 " + e[2] + " 0 0 0 " + r + " 0")
            }
        };

        function SVGStrokeEffect(t, e) {
            this.initialized = !1, this.filterManager = e, this.elem = t, this.paths = []
        }
        SVGStrokeEffect.prototype.initialize = function() {
            var t = this.elem.layerElement.children || this.elem.layerElement.childNodes,
                e, r, i, s;
            for (this.filterManager.effectElements[1].p.v === 1 ? (s = this.elem.maskManager.masksProperties.length, i = 0) : (i = this.filterManager.effectElements[0].p.v - 1, s = i + 1), r = createNS("g"), r.setAttribute("fill", "none"), r.setAttribute("stroke-linecap", "round"), r.setAttribute("stroke-dashoffset", 1), i; i < s; i += 1) e = createNS("path"), r.appendChild(e), this.paths.push({
                p: e,
                m: i
            });
            if (this.filterManager.effectElements[10].p.v === 3) {
                var n = createNS("mask"),
                    f = createElementID();
                n.setAttribute("id", f), n.setAttribute("mask-type", "alpha"), n.appendChild(r), this.elem.globalData.defs.appendChild(n);
                var P = createNS("g");
                for (P.setAttribute("mask", "url(" + getLocationHref() + "#" + f + ")"); t[0];) P.appendChild(t[0]);
                this.elem.layerElement.appendChild(P), this.masker = n, r.setAttribute("stroke", "#fff")
            } else if (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) {
                if (this.filterManager.effectElements[10].p.v === 2)
                    for (t = this.elem.layerElement.children || this.elem.layerElement.childNodes; t.length;) this.elem.layerElement.removeChild(t[0]);
                this.elem.layerElement.appendChild(r), this.elem.layerElement.removeAttribute("mask"), r.setAttribute("stroke", "#fff")
            }
            this.initialized = !0, this.pathMasker = r
        }, SVGStrokeEffect.prototype.renderFrame = function(t) {
            this.initialized || this.initialize();
            var e, r = this.paths.length,
                i, s;
            for (e = 0; e < r; e += 1)
                if (this.paths[e].m !== -1 && (i = this.elem.maskManager.viewData[this.paths[e].m], s = this.paths[e].p, (t || this.filterManager._mdf || i.prop._mdf) && s.setAttribute("d", i.lastPath), t || this.filterManager.effectElements[9].p._mdf || this.filterManager.effectElements[4].p._mdf || this.filterManager.effectElements[7].p._mdf || this.filterManager.effectElements[8].p._mdf || i.prop._mdf)) {
                    var n;
                    if (this.filterManager.effectElements[7].p.v !== 0 || this.filterManager.effectElements[8].p.v !== 100) {
                        var f = Math.min(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * .01,
                            P = Math.max(this.filterManager.effectElements[7].p.v, this.filterManager.effectElements[8].p.v) * .01,
                            d = s.getTotalLength();
                        n = "0 0 0 " + d * f + " ";
                        var _ = d * (P - f),
                            E = 1 + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * .01,
                            k = Math.floor(_ / E),
                            u;
                        for (u = 0; u < k; u += 1) n += "1 " + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * .01 + " ";
                        n += "0 " + d * 10 + " 0 0"
                    } else n = "1 " + this.filterManager.effectElements[4].p.v * 2 * this.filterManager.effectElements[9].p.v * .01;
                    s.setAttribute("stroke-dasharray", n)
                }
            if ((t || this.filterManager.effectElements[4].p._mdf) && this.pathMasker.setAttribute("stroke-width", this.filterManager.effectElements[4].p.v * 2), (t || this.filterManager.effectElements[6].p._mdf) && this.pathMasker.setAttribute("opacity", this.filterManager.effectElements[6].p.v), (this.filterManager.effectElements[10].p.v === 1 || this.filterManager.effectElements[10].p.v === 2) && (t || this.filterManager.effectElements[3].p._mdf)) {
                var g = this.filterManager.effectElements[3].p.v;
                this.pathMasker.setAttribute("stroke", "rgb(" + bmFloor(g[0] * 255) + "," + bmFloor(g[1] * 255) + "," + bmFloor(g[2] * 255) + ")")
            }
        };

        function SVGTritoneFilter(t, e) {
            this.filterManager = e;
            var r = createNS("feColorMatrix");
            r.setAttribute("type", "matrix"), r.setAttribute("color-interpolation-filters", "linearRGB"), r.setAttribute("values", "0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0"), r.setAttribute("result", "f1"), t.appendChild(r);
            var i = createNS("feComponentTransfer");
            i.setAttribute("color-interpolation-filters", "sRGB"), t.appendChild(i), this.matrixFilter = i;
            var s = createNS("feFuncR");
            s.setAttribute("type", "table"), i.appendChild(s), this.feFuncR = s;
            var n = createNS("feFuncG");
            n.setAttribute("type", "table"), i.appendChild(n), this.feFuncG = n;
            var f = createNS("feFuncB");
            f.setAttribute("type", "table"), i.appendChild(f), this.feFuncB = f
        }
        SVGTritoneFilter.prototype.renderFrame = function(t) {
            if (t || this.filterManager._mdf) {
                var e = this.filterManager.effectElements[0].p.v,
                    r = this.filterManager.effectElements[1].p.v,
                    i = this.filterManager.effectElements[2].p.v,
                    s = i[0] + " " + r[0] + " " + e[0],
                    n = i[1] + " " + r[1] + " " + e[1],
                    f = i[2] + " " + r[2] + " " + e[2];
                this.feFuncR.setAttribute("tableValues", s), this.feFuncG.setAttribute("tableValues", n), this.feFuncB.setAttribute("tableValues", f)
            }
        };

        function SVGProLevelsFilter(t, e) {
            this.filterManager = e;
            var r = this.filterManager.effectElements,
                i = createNS("feComponentTransfer");
            (r[10].p.k || r[10].p.v !== 0 || r[11].p.k || r[11].p.v !== 1 || r[12].p.k || r[12].p.v !== 1 || r[13].p.k || r[13].p.v !== 0 || r[14].p.k || r[14].p.v !== 1) && (this.feFuncR = this.createFeFunc("feFuncR", i)), (r[17].p.k || r[17].p.v !== 0 || r[18].p.k || r[18].p.v !== 1 || r[19].p.k || r[19].p.v !== 1 || r[20].p.k || r[20].p.v !== 0 || r[21].p.k || r[21].p.v !== 1) && (this.feFuncG = this.createFeFunc("feFuncG", i)), (r[24].p.k || r[24].p.v !== 0 || r[25].p.k || r[25].p.v !== 1 || r[26].p.k || r[26].p.v !== 1 || r[27].p.k || r[27].p.v !== 0 || r[28].p.k || r[28].p.v !== 1) && (this.feFuncB = this.createFeFunc("feFuncB", i)), (r[31].p.k || r[31].p.v !== 0 || r[32].p.k || r[32].p.v !== 1 || r[33].p.k || r[33].p.v !== 1 || r[34].p.k || r[34].p.v !== 0 || r[35].p.k || r[35].p.v !== 1) && (this.feFuncA = this.createFeFunc("feFuncA", i)), (this.feFuncR || this.feFuncG || this.feFuncB || this.feFuncA) && (i.setAttribute("color-interpolation-filters", "sRGB"), t.appendChild(i), i = createNS("feComponentTransfer")), (r[3].p.k || r[3].p.v !== 0 || r[4].p.k || r[4].p.v !== 1 || r[5].p.k || r[5].p.v !== 1 || r[6].p.k || r[6].p.v !== 0 || r[7].p.k || r[7].p.v !== 1) && (i.setAttribute("color-interpolation-filters", "sRGB"), t.appendChild(i), this.feFuncRComposed = this.createFeFunc("feFuncR", i), this.feFuncGComposed = this.createFeFunc("feFuncG", i), this.feFuncBComposed = this.createFeFunc("feFuncB", i))
        }
        SVGProLevelsFilter.prototype.createFeFunc = function(t, e) {
            var r = createNS(t);
            return r.setAttribute("type", "table"), e.appendChild(r), r
        }, SVGProLevelsFilter.prototype.getTableValue = function(t, e, r, i, s) {
            for (var n = 0, f = 256, P, d = Math.min(t, e), _ = Math.max(t, e), E = Array.call(null, {
                    length: f
                }), k, u = 0, g = s - i, v = e - t; n <= 256;) P = n / 256, P <= d ? k = v < 0 ? s : i : P >= _ ? k = v < 0 ? i : s : k = i + g * Math.pow((P - t) / v, 1 / r), E[u] = k, u += 1, n += 256 / (f - 1);
            return E.join(" ")
        }, SVGProLevelsFilter.prototype.renderFrame = function(t) {
            if (t || this.filterManager._mdf) {
                var e, r = this.filterManager.effectElements;
                this.feFuncRComposed && (t || r[3].p._mdf || r[4].p._mdf || r[5].p._mdf || r[6].p._mdf || r[7].p._mdf) && (e = this.getTableValue(r[3].p.v, r[4].p.v, r[5].p.v, r[6].p.v, r[7].p.v), this.feFuncRComposed.setAttribute("tableValues", e), this.feFuncGComposed.setAttribute("tableValues", e), this.feFuncBComposed.setAttribute("tableValues", e)), this.feFuncR && (t || r[10].p._mdf || r[11].p._mdf || r[12].p._mdf || r[13].p._mdf || r[14].p._mdf) && (e = this.getTableValue(r[10].p.v, r[11].p.v, r[12].p.v, r[13].p.v, r[14].p.v), this.feFuncR.setAttribute("tableValues", e)), this.feFuncG && (t || r[17].p._mdf || r[18].p._mdf || r[19].p._mdf || r[20].p._mdf || r[21].p._mdf) && (e = this.getTableValue(r[17].p.v, r[18].p.v, r[19].p.v, r[20].p.v, r[21].p.v), this.feFuncG.setAttribute("tableValues", e)), this.feFuncB && (t || r[24].p._mdf || r[25].p._mdf || r[26].p._mdf || r[27].p._mdf || r[28].p._mdf) && (e = this.getTableValue(r[24].p.v, r[25].p.v, r[26].p.v, r[27].p.v, r[28].p.v), this.feFuncB.setAttribute("tableValues", e)), this.feFuncA && (t || r[31].p._mdf || r[32].p._mdf || r[33].p._mdf || r[34].p._mdf || r[35].p._mdf) && (e = this.getTableValue(r[31].p.v, r[32].p.v, r[33].p.v, r[34].p.v, r[35].p.v), this.feFuncA.setAttribute("tableValues", e))
            }
        };

        function SVGDropShadowEffect(t, e) {
            var r = e.container.globalData.renderConfig.filterSize;
            t.setAttribute("x", r.x), t.setAttribute("y", r.y), t.setAttribute("width", r.width), t.setAttribute("height", r.height), this.filterManager = e;
            var i = createNS("feGaussianBlur");
            i.setAttribute("in", "SourceAlpha"), i.setAttribute("result", "drop_shadow_1"), i.setAttribute("stdDeviation", "0"), this.feGaussianBlur = i, t.appendChild(i);
            var s = createNS("feOffset");
            s.setAttribute("dx", "25"), s.setAttribute("dy", "0"), s.setAttribute("in", "drop_shadow_1"), s.setAttribute("result", "drop_shadow_2"), this.feOffset = s, t.appendChild(s);
            var n = createNS("feFlood");
            n.setAttribute("flood-color", "#00ff00"), n.setAttribute("flood-opacity", "1"), n.setAttribute("result", "drop_shadow_3"), this.feFlood = n, t.appendChild(n);
            var f = createNS("feComposite");
            f.setAttribute("in", "drop_shadow_3"), f.setAttribute("in2", "drop_shadow_2"), f.setAttribute("operator", "in"), f.setAttribute("result", "drop_shadow_4"), t.appendChild(f);
            var P = createNS("feMerge");
            t.appendChild(P);
            var d;
            d = createNS("feMergeNode"), P.appendChild(d), d = createNS("feMergeNode"), d.setAttribute("in", "SourceGraphic"), this.feMergeNode = d, this.feMerge = P, this.originalNodeAdded = !1, P.appendChild(d)
        }
        SVGDropShadowEffect.prototype.renderFrame = function(t) {
            if (t || this.filterManager._mdf) {
                if ((t || this.filterManager.effectElements[4].p._mdf) && this.feGaussianBlur.setAttribute("stdDeviation", this.filterManager.effectElements[4].p.v / 4), t || this.filterManager.effectElements[0].p._mdf) {
                    var e = this.filterManager.effectElements[0].p.v;
                    this.feFlood.setAttribute("flood-color", rgbToHex(Math.round(e[0] * 255), Math.round(e[1] * 255), Math.round(e[2] * 255)))
                }
                if ((t || this.filterManager.effectElements[1].p._mdf) && this.feFlood.setAttribute("flood-opacity", this.filterManager.effectElements[1].p.v / 255), t || this.filterManager.effectElements[2].p._mdf || this.filterManager.effectElements[3].p._mdf) {
                    var r = this.filterManager.effectElements[3].p.v,
                        i = (this.filterManager.effectElements[2].p.v - 90) * degToRads,
                        s = r * Math.cos(i),
                        n = r * Math.sin(i);
                    this.feOffset.setAttribute("dx", s), this.feOffset.setAttribute("dy", n)
                }
            }
        };
        var _svgMatteSymbols = [];

        function SVGMatte3Effect(t, e, r) {
            this.initialized = !1, this.filterManager = e, this.filterElem = t, this.elem = r, r.matteElement = createNS("g"), r.matteElement.appendChild(r.layerElement), r.matteElement.appendChild(r.transformedElement), r.baseElement = r.matteElement
        }
        SVGMatte3Effect.prototype.findSymbol = function(t) {
            for (var e = 0, r = _svgMatteSymbols.length; e < r;) {
                if (_svgMatteSymbols[e] === t) return _svgMatteSymbols[e];
                e += 1
            }
            return null
        }, SVGMatte3Effect.prototype.replaceInParent = function(t, e) {
            var r = t.layerElement.parentNode;
            if (!!r) {
                for (var i = r.children, s = 0, n = i.length; s < n && i[s] !== t.layerElement;) s += 1;
                var f;
                s <= n - 2 && (f = i[s + 1]);
                var P = createNS("use");
                P.setAttribute("href", "#" + e), f ? r.insertBefore(P, f) : r.appendChild(P)
            }
        }, SVGMatte3Effect.prototype.setElementAsMask = function(t, e) {
            if (!this.findSymbol(e)) {
                var r = createElementID(),
                    i = createNS("mask");
                i.setAttribute("id", e.layerId), i.setAttribute("mask-type", "alpha"), _svgMatteSymbols.push(e);
                var s = t.globalData.defs;
                s.appendChild(i);
                var n = createNS("symbol");
                n.setAttribute("id", r), this.replaceInParent(e, r), n.appendChild(e.layerElement), s.appendChild(n);
                var f = createNS("use");
                f.setAttribute("href", "#" + r), i.appendChild(f), e.data.hd = !1, e.show()
            }
            t.setMatte(e.layerId)
        }, SVGMatte3Effect.prototype.initialize = function() {
            for (var t = this.filterManager.effectElements[0].p.v, e = this.elem.comp.elements, r = 0, i = e.length; r < i;) e[r] && e[r].data.ind === t && this.setElementAsMask(this.elem, e[r]), r += 1;
            this.initialized = !0
        }, SVGMatte3Effect.prototype.renderFrame = function() {
            this.initialized || this.initialize()
        };

        function SVGGaussianBlurEffect(t, e) {
            t.setAttribute("x", "-100%"), t.setAttribute("y", "-100%"), t.setAttribute("width", "300%"), t.setAttribute("height", "300%"), this.filterManager = e;
            var r = createNS("feGaussianBlur");
            t.appendChild(r), this.feGaussianBlur = r
        }
        SVGGaussianBlurEffect.prototype.renderFrame = function(t) {
            if (t || this.filterManager._mdf) {
                var e = .3,
                    r = this.filterManager.effectElements[0].p.v * e,
                    i = this.filterManager.effectElements[1].p.v,
                    s = i == 3 ? 0 : r,
                    n = i == 2 ? 0 : r;
                this.feGaussianBlur.setAttribute("stdDeviation", s + " " + n);
                var f = this.filterManager.effectElements[2].p.v == 1 ? "wrap" : "duplicate";
                this.feGaussianBlur.setAttribute("edgeMode", f)
            }
        };
        var registeredEffects = {};

        function SVGEffects(t) {
            var e, r = t.data.ef ? t.data.ef.length : 0,
                i = createElementID(),
                s = filtersFactory.createFilter(i, !0),
                n = 0;
            this.filters = [];
            var f;
            for (e = 0; e < r; e += 1) {
                f = null;
                var P = t.data.ef[e].ty;
                if (registeredEffects[P]) {
                    var d = registeredEffects[P].effect;
                    f = new d(s, t.effectsManager.effectElements[e], t), registeredEffects[P].countsAsEffect && (n += 1)
                }
                t.data.ef[e].ty === 20 ? (n += 1, f = new SVGTintFilter(s, t.effectsManager.effectElements[e])) : t.data.ef[e].ty === 21 ? (n += 1, f = new SVGFillFilter(s, t.effectsManager.effectElements[e])) : t.data.ef[e].ty === 22 ? f = new SVGStrokeEffect(t, t.effectsManager.effectElements[e]) : t.data.ef[e].ty === 23 ? (n += 1, f = new SVGTritoneFilter(s, t.effectsManager.effectElements[e])) : t.data.ef[e].ty === 24 ? (n += 1, f = new SVGProLevelsFilter(s, t.effectsManager.effectElements[e])) : t.data.ef[e].ty === 25 ? (n += 1, f = new SVGDropShadowEffect(s, t.effectsManager.effectElements[e])) : t.data.ef[e].ty === 28 ? f = new SVGMatte3Effect(s, t.effectsManager.effectElements[e], t) : t.data.ef[e].ty === 29 && (n += 1, f = new SVGGaussianBlurEffect(s, t.effectsManager.effectElements[e])), f && this.filters.push(f)
            }
            n && (t.globalData.defs.appendChild(s), t.layerElement.setAttribute("filter", "url(" + getLocationHref() + "#" + i + ")")), this.filters.length && t.addRenderableComponent(this)
        }
        SVGEffects.prototype.renderFrame = function(t) {
            var e, r = this.filters.length;
            for (e = 0; e < r; e += 1) this.filters[e].renderFrame(t)
        };

        function registerEffect(t, e, r) {
            registeredEffects[t] = {
                effect: e,
                countsAsEffect: r
            }
        }

        function SVGBaseElement() {}
        SVGBaseElement.prototype = {
            initRendererElement: function() {
                this.layerElement = createNS("g")
            },
            createContainerElements: function() {
                this.matteElement = createNS("g"), this.transformedElement = this.layerElement, this.maskedElement = this.layerElement, this._sizeChanged = !1;
                var e = null,
                    r, i, s;
                if (this.data.td) {
                    if (this.data.td == 3 || this.data.td == 1) {
                        var n = createNS("mask");
                        n.setAttribute("id", this.layerId), n.setAttribute("mask-type", this.data.td == 3 ? "luminance" : "alpha"), n.appendChild(this.layerElement), e = n, this.globalData.defs.appendChild(n), !featureSupport.maskType && this.data.td == 1 && (n.setAttribute("mask-type", "luminance"), r = createElementID(), i = filtersFactory.createFilter(r), this.globalData.defs.appendChild(i), i.appendChild(filtersFactory.createAlphaToLuminanceFilter()), s = createNS("g"), s.appendChild(this.layerElement), e = s, n.appendChild(s), s.setAttribute("filter", "url(" + getLocationHref() + "#" + r + ")"))
                    } else if (this.data.td == 2) {
                        var f = createNS("mask");
                        f.setAttribute("id", this.layerId), f.setAttribute("mask-type", "alpha");
                        var P = createNS("g");
                        f.appendChild(P), r = createElementID(), i = filtersFactory.createFilter(r);
                        var d = createNS("feComponentTransfer");
                        d.setAttribute("in", "SourceGraphic"), i.appendChild(d);
                        var _ = createNS("feFuncA");
                        _.setAttribute("type", "table"), _.setAttribute("tableValues", "1.0 0.0"), d.appendChild(_), this.globalData.defs.appendChild(i);
                        var E = createNS("rect");
                        E.setAttribute("width", this.comp.data.w), E.setAttribute("height", this.comp.data.h), E.setAttribute("x", "0"), E.setAttribute("y", "0"), E.setAttribute("fill", "#ffffff"), E.setAttribute("opacity", "0"), P.setAttribute("filter", "url(" + getLocationHref() + "#" + r + ")"), P.appendChild(E), P.appendChild(this.layerElement), e = P, featureSupport.maskType || (f.setAttribute("mask-type", "luminance"), i.appendChild(filtersFactory.createAlphaToLuminanceFilter()), s = createNS("g"), P.appendChild(E), s.appendChild(this.layerElement), e = s, P.appendChild(s)), this.globalData.defs.appendChild(f)
                    }
                } else this.data.tt ? (this.matteElement.appendChild(this.layerElement), e = this.matteElement, this.baseElement = this.matteElement) : this.baseElement = this.layerElement;
                if (this.data.ln && this.layerElement.setAttribute("id", this.data.ln), this.data.cl && this.layerElement.setAttribute("class", this.data.cl), this.data.ty === 0 && !this.data.hd) {
                    var k = createNS("clipPath"),
                        u = createNS("path");
                    u.setAttribute("d", "M0,0 L" + this.data.w + ",0 L" + this.data.w + "," + this.data.h + " L0," + this.data.h + "z");
                    var g = createElementID();
                    if (k.setAttribute("id", g), k.appendChild(u), this.globalData.defs.appendChild(k), this.checkMasks()) {
                        var v = createNS("g");
                        v.setAttribute("clip-path", "url(" + getLocationHref() + "#" + g + ")"), v.appendChild(this.layerElement), this.transformedElement = v, e ? e.appendChild(this.transformedElement) : this.baseElement = this.transformedElement
                    } else this.layerElement.setAttribute("clip-path", "url(" + getLocationHref() + "#" + g + ")")
                }
                this.data.bm !== 0 && this.setBlendMode()
            },
            renderElement: function() {
                this.finalTransform._matMdf && this.transformedElement.setAttribute("transform", this.finalTransform.mat.to2dCSS()), this.finalTransform._opMdf && this.transformedElement.setAttribute("opacity", this.finalTransform.mProp.o.v)
            },
            destroyBaseElement: function() {
                this.layerElement = null, this.matteElement = null, this.maskManager.destroy()
            },
            getBaseElement: function() {
                return this.data.hd ? null : this.baseElement
            },
            createRenderableComponents: function() {
                this.maskManager = new MaskElement(this.data, this, this.globalData), this.renderableEffectsManager = new SVGEffects(this)
            },
            setMatte: function(e) {
                !this.matteElement || this.matteElement.setAttribute("mask", "url(" + getLocationHref() + "#" + e + ")")
            }
        };

        function HierarchyElement() {}
        HierarchyElement.prototype = {
            initHierarchy: function() {
                this.hierarchy = [], this._isParent = !1, this.checkParenting()
            },
            setHierarchy: function(e) {
                this.hierarchy = e
            },
            setAsParent: function() {
                this._isParent = !0
            },
            checkParenting: function() {
                this.data.parent !== void 0 && this.comp.buildElementParenting(this, this.data.parent, [])
            }
        };

        function RenderableDOMElement() {}(function() {
            var t = {
                initElement: function(r, i, s) {
                    this.initFrame(), this.initBaseData(r, i, s), this.initTransform(r, i, s), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide()
                },
                hide: function() {
                    if (!this.hidden && (!this.isInRange || this.isTransparent)) {
                        var r = this.baseElement || this.layerElement;
                        r.style.display = "none", this.hidden = !0
                    }
                },
                show: function() {
                    if (this.isInRange && !this.isTransparent) {
                        if (!this.data.hd) {
                            var r = this.baseElement || this.layerElement;
                            r.style.display = "block"
                        }
                        this.hidden = !1, this._isFirstFrame = !0
                    }
                },
                renderFrame: function() {
                    this.data.hd || this.hidden || (this.renderTransform(), this.renderRenderable(), this.renderElement(), this.renderInnerContent(), this._isFirstFrame && (this._isFirstFrame = !1))
                },
                renderInnerContent: function() {},
                prepareFrame: function(r) {
                    this._mdf = !1, this.prepareRenderableFrame(r), this.prepareProperties(r, this.isInRange), this.checkTransparency()
                },
                destroy: function() {
                    this.innerElem = null, this.destroyBaseElement()
                }
            };
            extendPrototype([RenderableElement, createProxyFunction(t)], RenderableDOMElement)
        })();

        function IImageElement(t, e, r) {
            this.assetData = e.getAssetData(t.refId), this.initElement(t, e, r), this.sourceRect = {
                top: 0,
                left: 0,
                width: this.assetData.w,
                height: this.assetData.h
            }
        }
        extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement], IImageElement), IImageElement.prototype.createContent = function() {
            var t = this.globalData.getAssetsPath(this.assetData);
            this.innerElem = createNS("image"), this.innerElem.setAttribute("width", this.assetData.w + "px"), this.innerElem.setAttribute("height", this.assetData.h + "px"), this.innerElem.setAttribute("preserveAspectRatio", this.assetData.pr || this.globalData.renderConfig.imagePreserveAspectRatio), this.innerElem.setAttributeNS("http://www.w3.org/1999/xlink", "href", t), this.layerElement.appendChild(this.innerElem)
        }, IImageElement.prototype.sourceRectAtTime = function() {
            return this.sourceRect
        };

        function ProcessedElement(t, e) {
            this.elem = t, this.pos = e
        }

        function IShapeElement() {}
        IShapeElement.prototype = {
            addShapeToModifiers: function(e) {
                var r, i = this.shapeModifiers.length;
                for (r = 0; r < i; r += 1) this.shapeModifiers[r].addShape(e)
            },
            isShapeInAnimatedModifiers: function(e) {
                for (var r = 0, i = this.shapeModifiers.length; r < i;)
                    if (this.shapeModifiers[r].isAnimatedWithShape(e)) return !0;
                return !1
            },
            renderModifiers: function() {
                if (!!this.shapeModifiers.length) {
                    var e, r = this.shapes.length;
                    for (e = 0; e < r; e += 1) this.shapes[e].sh.reset();
                    r = this.shapeModifiers.length;
                    var i;
                    for (e = r - 1; e >= 0 && (i = this.shapeModifiers[e].processShapes(this._isFirstFrame), !i); e -= 1);
                }
            },
            searchProcessedElement: function(e) {
                for (var r = this.processedElements, i = 0, s = r.length; i < s;) {
                    if (r[i].elem === e) return r[i].pos;
                    i += 1
                }
                return 0
            },
            addProcessedElement: function(e, r) {
                for (var i = this.processedElements, s = i.length; s;)
                    if (s -= 1, i[s].elem === e) {
                        i[s].pos = r;
                        return
                    }
                i.push(new ProcessedElement(e, r))
            },
            prepareFrame: function(e) {
                this.prepareRenderableFrame(e), this.prepareProperties(e, this.isInRange)
            }
        };
        var lineCapEnum = {
                1: "butt",
                2: "round",
                3: "square"
            },
            lineJoinEnum = {
                1: "miter",
                2: "round",
                3: "bevel"
            };

        function SVGShapeData(t, e, r) {
            this.caches = [], this.styles = [], this.transformers = t, this.lStr = "", this.sh = r, this.lvl = e, this._isAnimated = !!r.k;
            for (var i = 0, s = t.length; i < s;) {
                if (t[i].mProps.dynamicProperties.length) {
                    this._isAnimated = !0;
                    break
                }
                i += 1
            }
        }
        SVGShapeData.prototype.setAsAnimated = function() {
            this._isAnimated = !0
        };

        function SVGStyleData(t, e) {
            this.data = t, this.type = t.ty, this.d = "", this.lvl = e, this._mdf = !1, this.closed = t.hd === !0, this.pElem = createNS("path"), this.msElem = null
        }
        SVGStyleData.prototype.reset = function() {
            this.d = "", this._mdf = !1
        };

        function DashProperty(t, e, r, i) {
            this.elem = t, this.frameId = -1, this.dataProps = createSizedArray(e.length), this.renderer = r, this.k = !1, this.dashStr = "", this.dashArray = createTypedArray("float32", e.length ? e.length - 1 : 0), this.dashoffset = createTypedArray("float32", 1), this.initDynamicPropertyContainer(i);
            var s, n = e.length || 0,
                f;
            for (s = 0; s < n; s += 1) f = PropertyFactory.getProp(t, e[s].v, 0, 0, this), this.k = f.k || this.k, this.dataProps[s] = {
                n: e[s].n,
                p: f
            };
            this.k || this.getValue(!0), this._isAnimated = this.k
        }
        DashProperty.prototype.getValue = function(t) {
            if (!(this.elem.globalData.frameId === this.frameId && !t) && (this.frameId = this.elem.globalData.frameId, this.iterateDynamicProperties(), this._mdf = this._mdf || t, this._mdf)) {
                var e = 0,
                    r = this.dataProps.length;
                for (this.renderer === "svg" && (this.dashStr = ""), e = 0; e < r; e += 1) this.dataProps[e].n !== "o" ? this.renderer === "svg" ? this.dashStr += " " + this.dataProps[e].p.v : this.dashArray[e] = this.dataProps[e].p.v : this.dashoffset[0] = this.dataProps[e].p.v
            }
        }, extendPrototype([DynamicPropertyContainer], DashProperty);

        function SVGStrokeStyleData(t, e, r) {
            this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(t, e.o, 0, .01, this), this.w = PropertyFactory.getProp(t, e.w, 0, null, this), this.d = new DashProperty(t, e.d || {}, "svg", this), this.c = PropertyFactory.getProp(t, e.c, 1, 255, this), this.style = r, this._isAnimated = !!this._isAnimated
        }
        extendPrototype([DynamicPropertyContainer], SVGStrokeStyleData);

        function SVGFillStyleData(t, e, r) {
            this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.o = PropertyFactory.getProp(t, e.o, 0, .01, this), this.c = PropertyFactory.getProp(t, e.c, 1, 255, this), this.style = r
        }
        extendPrototype([DynamicPropertyContainer], SVGFillStyleData);

        function SVGNoStyleData(t, e, r) {
            this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.style = r
        }
        extendPrototype([DynamicPropertyContainer], SVGNoStyleData);

        function GradientProperty(t, e, r) {
            this.data = e, this.c = createTypedArray("uint8c", e.p * 4);
            var i = e.k.k[0].s ? e.k.k[0].s.length - e.p * 4 : e.k.k.length - e.p * 4;
            this.o = createTypedArray("float32", i), this._cmdf = !1, this._omdf = !1, this._collapsable = this.checkCollapsable(), this._hasOpacity = i, this.initDynamicPropertyContainer(r), this.prop = PropertyFactory.getProp(t, e.k, 1, null, this), this.k = this.prop.k, this.getValue(!0)
        }
        GradientProperty.prototype.comparePoints = function(t, e) {
            for (var r = 0, i = this.o.length / 2, s; r < i;) {
                if (s = Math.abs(t[r * 4] - t[e * 4 + r * 2]), s > .01) return !1;
                r += 1
            }
            return !0
        }, GradientProperty.prototype.checkCollapsable = function() {
            if (this.o.length / 2 !== this.c.length / 4) return !1;
            if (this.data.k.k[0].s)
                for (var t = 0, e = this.data.k.k.length; t < e;) {
                    if (!this.comparePoints(this.data.k.k[t].s, this.data.p)) return !1;
                    t += 1
                } else if (!this.comparePoints(this.data.k.k, this.data.p)) return !1;
            return !0
        }, GradientProperty.prototype.getValue = function(t) {
            if (this.prop.getValue(), this._mdf = !1, this._cmdf = !1, this._omdf = !1, this.prop._mdf || t) {
                var e, r = this.data.p * 4,
                    i, s;
                for (e = 0; e < r; e += 1) i = e % 4 === 0 ? 100 : 255, s = Math.round(this.prop.v[e] * i), this.c[e] !== s && (this.c[e] = s, this._cmdf = !t);
                if (this.o.length)
                    for (r = this.prop.v.length, e = this.data.p * 4; e < r; e += 1) i = e % 2 === 0 ? 100 : 1, s = e % 2 === 0 ? Math.round(this.prop.v[e] * 100) : this.prop.v[e], this.o[e - this.data.p * 4] !== s && (this.o[e - this.data.p * 4] = s, this._omdf = !t);
                this._mdf = !t
            }
        }, extendPrototype([DynamicPropertyContainer], GradientProperty);

        function SVGGradientFillStyleData(t, e, r) {
            this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.initGradientData(t, e, r)
        }
        SVGGradientFillStyleData.prototype.initGradientData = function(t, e, r) {
            this.o = PropertyFactory.getProp(t, e.o, 0, .01, this), this.s = PropertyFactory.getProp(t, e.s, 1, null, this), this.e = PropertyFactory.getProp(t, e.e, 1, null, this), this.h = PropertyFactory.getProp(t, e.h || {
                k: 0
            }, 0, .01, this), this.a = PropertyFactory.getProp(t, e.a || {
                k: 0
            }, 0, degToRads, this), this.g = new GradientProperty(t, e.g, this), this.style = r, this.stops = [], this.setGradientData(r.pElem, e), this.setGradientOpacity(e, r), this._isAnimated = !!this._isAnimated
        }, SVGGradientFillStyleData.prototype.setGradientData = function(t, e) {
            var r = createElementID(),
                i = createNS(e.t === 1 ? "linearGradient" : "radialGradient");
            i.setAttribute("id", r), i.setAttribute("spreadMethod", "pad"), i.setAttribute("gradientUnits", "userSpaceOnUse");
            var s = [],
                n, f, P;
            for (P = e.g.p * 4, f = 0; f < P; f += 4) n = createNS("stop"), i.appendChild(n), s.push(n);
            t.setAttribute(e.ty === "gf" ? "fill" : "stroke", "url(" + getLocationHref() + "#" + r + ")"), this.gf = i, this.cst = s
        }, SVGGradientFillStyleData.prototype.setGradientOpacity = function(t, e) {
            if (this.g._hasOpacity && !this.g._collapsable) {
                var r, i, s, n = createNS("mask"),
                    f = createNS("path");
                n.appendChild(f);
                var P = createElementID(),
                    d = createElementID();
                n.setAttribute("id", d);
                var _ = createNS(t.t === 1 ? "linearGradient" : "radialGradient");
                _.setAttribute("id", P), _.setAttribute("spreadMethod", "pad"), _.setAttribute("gradientUnits", "userSpaceOnUse"), s = t.g.k.k[0].s ? t.g.k.k[0].s.length : t.g.k.k.length;
                var E = this.stops;
                for (i = t.g.p * 4; i < s; i += 2) r = createNS("stop"), r.setAttribute("stop-color", "rgb(255,255,255)"), _.appendChild(r), E.push(r);
                f.setAttribute(t.ty === "gf" ? "fill" : "stroke", "url(" + getLocationHref() + "#" + P + ")"), t.ty === "gs" && (f.setAttribute("stroke-linecap", lineCapEnum[t.lc || 2]), f.setAttribute("stroke-linejoin", lineJoinEnum[t.lj || 2]), t.lj === 1 && f.setAttribute("stroke-miterlimit", t.ml)), this.of = _, this.ms = n, this.ost = E, this.maskId = d, e.msElem = f
            }
        }, extendPrototype([DynamicPropertyContainer], SVGGradientFillStyleData);

        function SVGGradientStrokeStyleData(t, e, r) {
            this.initDynamicPropertyContainer(t), this.getValue = this.iterateDynamicProperties, this.w = PropertyFactory.getProp(t, e.w, 0, null, this), this.d = new DashProperty(t, e.d || {}, "svg", this), this.initGradientData(t, e, r), this._isAnimated = !!this._isAnimated
        }
        extendPrototype([SVGGradientFillStyleData, DynamicPropertyContainer], SVGGradientStrokeStyleData);

        function ShapeGroupData() {
            this.it = [], this.prevViewData = [], this.gr = createNS("g")
        }

        function SVGTransformData(t, e, r) {
            this.transform = {
                mProps: t,
                op: e,
                container: r
            }, this.elements = [], this._isAnimated = this.transform.mProps.dynamicProperties.length || this.transform.op.effectsSequence.length
        }
        var buildShapeString = function(e, r, i, s) {
                if (r === 0) return "";
                var n = e.o,
                    f = e.i,
                    P = e.v,
                    d, _ = " M" + s.applyToPointStringified(P[0][0], P[0][1]);
                for (d = 1; d < r; d += 1) _ += " C" + s.applyToPointStringified(n[d - 1][0], n[d - 1][1]) + " " + s.applyToPointStringified(f[d][0], f[d][1]) + " " + s.applyToPointStringified(P[d][0], P[d][1]);
                return i && r && (_ += " C" + s.applyToPointStringified(n[d - 1][0], n[d - 1][1]) + " " + s.applyToPointStringified(f[0][0], f[0][1]) + " " + s.applyToPointStringified(P[0][0], P[0][1]), _ += "z"), _
            },
            SVGElementsRenderer = function() {
                var t = new Matrix,
                    e = new Matrix,
                    r = {
                        createRenderFunction: i
                    };

                function i(k) {
                    switch (k.ty) {
                        case "fl":
                            return P;
                        case "gf":
                            return _;
                        case "gs":
                            return d;
                        case "st":
                            return E;
                        case "sh":
                        case "el":
                        case "rc":
                        case "sr":
                            return f;
                        case "tr":
                            return s;
                        case "no":
                            return n;
                        default:
                            return null
                    }
                }

                function s(k, u, g) {
                    (g || u.transform.op._mdf) && u.transform.container.setAttribute("opacity", u.transform.op.v), (g || u.transform.mProps._mdf) && u.transform.container.setAttribute("transform", u.transform.mProps.v.to2dCSS())
                }

                function n() {}

                function f(k, u, g) {
                    var v, m, S, o, l, a, h = u.styles.length,
                        p = u.lvl,
                        c, b, A, I, R;
                    for (a = 0; a < h; a += 1) {
                        if (o = u.sh._mdf || g, u.styles[a].lvl < p) {
                            for (b = e.reset(), I = p - u.styles[a].lvl, R = u.transformers.length - 1; !o && I > 0;) o = u.transformers[R].mProps._mdf || o, I -= 1, R -= 1;
                            if (o)
                                for (I = p - u.styles[a].lvl, R = u.transformers.length - 1; I > 0;) A = u.transformers[R].mProps.v.props, b.transform(A[0], A[1], A[2], A[3], A[4], A[5], A[6], A[7], A[8], A[9], A[10], A[11], A[12], A[13], A[14], A[15]), I -= 1, R -= 1
                        } else b = t;
                        if (c = u.sh.paths, m = c._length, o) {
                            for (S = "", v = 0; v < m; v += 1) l = c.shapes[v], l && l._length && (S += buildShapeString(l, l._length, l.c, b));
                            u.caches[a] = S
                        } else S = u.caches[a];
                        u.styles[a].d += k.hd === !0 ? "" : S, u.styles[a]._mdf = o || u.styles[a]._mdf
                    }
                }

                function P(k, u, g) {
                    var v = u.style;
                    (u.c._mdf || g) && v.pElem.setAttribute("fill", "rgb(" + bmFloor(u.c.v[0]) + "," + bmFloor(u.c.v[1]) + "," + bmFloor(u.c.v[2]) + ")"), (u.o._mdf || g) && v.pElem.setAttribute("fill-opacity", u.o.v)
                }

                function d(k, u, g) {
                    _(k, u, g), E(k, u, g)
                }

                function _(k, u, g) {
                    var v = u.gf,
                        m = u.g._hasOpacity,
                        S = u.s.v,
                        o = u.e.v;
                    if (u.o._mdf || g) {
                        var l = k.ty === "gf" ? "fill-opacity" : "stroke-opacity";
                        u.style.pElem.setAttribute(l, u.o.v)
                    }
                    if (u.s._mdf || g) {
                        var a = k.t === 1 ? "x1" : "cx",
                            h = a === "x1" ? "y1" : "cy";
                        v.setAttribute(a, S[0]), v.setAttribute(h, S[1]), m && !u.g._collapsable && (u.of.setAttribute(a, S[0]), u.of.setAttribute(h, S[1]))
                    }
                    var p, c, b, A;
                    if (u.g._cmdf || g) {
                        p = u.cst;
                        var I = u.g.c;
                        for (b = p.length, c = 0; c < b; c += 1) A = p[c], A.setAttribute("offset", I[c * 4] + "%"), A.setAttribute("stop-color", "rgb(" + I[c * 4 + 1] + "," + I[c * 4 + 2] + "," + I[c * 4 + 3] + ")")
                    }
                    if (m && (u.g._omdf || g)) {
                        var R = u.g.o;
                        for (u.g._collapsable ? p = u.cst : p = u.ost, b = p.length, c = 0; c < b; c += 1) A = p[c], u.g._collapsable || A.setAttribute("offset", R[c * 2] + "%"), A.setAttribute("stop-opacity", R[c * 2 + 1])
                    }
                    if (k.t === 1)(u.e._mdf || g) && (v.setAttribute("x2", o[0]), v.setAttribute("y2", o[1]), m && !u.g._collapsable && (u.of.setAttribute("x2", o[0]), u.of.setAttribute("y2", o[1])));
                    else {
                        var L;
                        if ((u.s._mdf || u.e._mdf || g) && (L = Math.sqrt(Math.pow(S[0] - o[0], 2) + Math.pow(S[1] - o[1], 2)), v.setAttribute("r", L), m && !u.g._collapsable && u.of.setAttribute("r", L)), u.e._mdf || u.h._mdf || u.a._mdf || g) {
                            L || (L = Math.sqrt(Math.pow(S[0] - o[0], 2) + Math.pow(S[1] - o[1], 2)));
                            var w = Math.atan2(o[1] - S[1], o[0] - S[0]),
                                G = u.h.v;
                            G >= 1 ? G = .99 : G <= -1 && (G = -.99);
                            var B = L * G,
                                C = Math.cos(w + u.a.v) * B + S[0],
                                F = Math.sin(w + u.a.v) * B + S[1];
                            v.setAttribute("fx", C), v.setAttribute("fy", F), m && !u.g._collapsable && (u.of.setAttribute("fx", C), u.of.setAttribute("fy", F))
                        }
                    }
                }

                function E(k, u, g) {
                    var v = u.style,
                        m = u.d;
                    m && (m._mdf || g) && m.dashStr && (v.pElem.setAttribute("stroke-dasharray", m.dashStr), v.pElem.setAttribute("stroke-dashoffset", m.dashoffset[0])), u.c && (u.c._mdf || g) && v.pElem.setAttribute("stroke", "rgb(" + bmFloor(u.c.v[0]) + "," + bmFloor(u.c.v[1]) + "," + bmFloor(u.c.v[2]) + ")"), (u.o._mdf || g) && v.pElem.setAttribute("stroke-opacity", u.o.v), (u.w._mdf || g) && (v.pElem.setAttribute("stroke-width", u.w.v), v.msElem && v.msElem.setAttribute("stroke-width", u.w.v))
                }
                return r
            }();

        function SVGShapeElement(t, e, r) {
            this.shapes = [], this.shapesData = t.shapes, this.stylesList = [], this.shapeModifiers = [], this.itemsData = [], this.processedElements = [], this.animatedContents = [], this.initElement(t, e, r), this.prevViewData = []
        }
        extendPrototype([BaseElement, TransformElement, SVGBaseElement, IShapeElement, HierarchyElement, FrameElement, RenderableDOMElement], SVGShapeElement), SVGShapeElement.prototype.initSecondaryElement = function() {}, SVGShapeElement.prototype.identityMatrix = new Matrix, SVGShapeElement.prototype.buildExpressionInterface = function() {}, SVGShapeElement.prototype.createContent = function() {
            this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes()
        }, SVGShapeElement.prototype.filterUniqueShapes = function() {
            var t, e = this.shapes.length,
                r, i, s = this.stylesList.length,
                n, f = [],
                P = !1;
            for (i = 0; i < s; i += 1) {
                for (n = this.stylesList[i], P = !1, f.length = 0, t = 0; t < e; t += 1) r = this.shapes[t], r.styles.indexOf(n) !== -1 && (f.push(r), P = r._isAnimated || P);
                f.length > 1 && P && this.setShapesAsAnimated(f)
            }
        }, SVGShapeElement.prototype.setShapesAsAnimated = function(t) {
            var e, r = t.length;
            for (e = 0; e < r; e += 1) t[e].setAsAnimated()
        }, SVGShapeElement.prototype.createStyleElement = function(t, e) {
            var r, i = new SVGStyleData(t, e),
                s = i.pElem;
            if (t.ty === "st") r = new SVGStrokeStyleData(this, t, i);
            else if (t.ty === "fl") r = new SVGFillStyleData(this, t, i);
            else if (t.ty === "gf" || t.ty === "gs") {
                var n = t.ty === "gf" ? SVGGradientFillStyleData : SVGGradientStrokeStyleData;
                r = new n(this, t, i), this.globalData.defs.appendChild(r.gf), r.maskId && (this.globalData.defs.appendChild(r.ms), this.globalData.defs.appendChild(r.of), s.setAttribute("mask", "url(" + getLocationHref() + "#" + r.maskId + ")"))
            } else t.ty === "no" && (r = new SVGNoStyleData(this, t, i));
            return (t.ty === "st" || t.ty === "gs") && (s.setAttribute("stroke-linecap", lineCapEnum[t.lc || 2]), s.setAttribute("stroke-linejoin", lineJoinEnum[t.lj || 2]), s.setAttribute("fill-opacity", "0"), t.lj === 1 && s.setAttribute("stroke-miterlimit", t.ml)), t.r === 2 && s.setAttribute("fill-rule", "evenodd"), t.ln && s.setAttribute("id", t.ln), t.cl && s.setAttribute("class", t.cl), t.bm && (s.style["mix-blend-mode"] = getBlendMode(t.bm)), this.stylesList.push(i), this.addToAnimatedContents(t, r), r
        }, SVGShapeElement.prototype.createGroupElement = function(t) {
            var e = new ShapeGroupData;
            return t.ln && e.gr.setAttribute("id", t.ln), t.cl && e.gr.setAttribute("class", t.cl), t.bm && (e.gr.style["mix-blend-mode"] = getBlendMode(t.bm)), e
        }, SVGShapeElement.prototype.createTransformElement = function(t, e) {
            var r = TransformPropertyFactory.getTransformProperty(this, t, this),
                i = new SVGTransformData(r, r.o, e);
            return this.addToAnimatedContents(t, i), i
        }, SVGShapeElement.prototype.createShapeElement = function(t, e, r) {
            var i = 4;
            t.ty === "rc" ? i = 5 : t.ty === "el" ? i = 6 : t.ty === "sr" && (i = 7);
            var s = ShapePropertyFactory.getShapeProp(this, t, i, this),
                n = new SVGShapeData(e, r, s);
            return this.shapes.push(n), this.addShapeToModifiers(n), this.addToAnimatedContents(t, n), n
        }, SVGShapeElement.prototype.addToAnimatedContents = function(t, e) {
            for (var r = 0, i = this.animatedContents.length; r < i;) {
                if (this.animatedContents[r].element === e) return;
                r += 1
            }
            this.animatedContents.push({
                fn: SVGElementsRenderer.createRenderFunction(t),
                element: e,
                data: t
            })
        }, SVGShapeElement.prototype.setElementStyles = function(t) {
            var e = t.styles,
                r, i = this.stylesList.length;
            for (r = 0; r < i; r += 1) this.stylesList[r].closed || e.push(this.stylesList[r])
        }, SVGShapeElement.prototype.reloadShapes = function() {
            this._isFirstFrame = !0;
            var t, e = this.itemsData.length;
            for (t = 0; t < e; t += 1) this.prevViewData[t] = this.itemsData[t];
            for (this.searchShapes(this.shapesData, this.itemsData, this.prevViewData, this.layerElement, 0, [], !0), this.filterUniqueShapes(), e = this.dynamicProperties.length, t = 0; t < e; t += 1) this.dynamicProperties[t].getValue();
            this.renderModifiers()
        }, SVGShapeElement.prototype.searchShapes = function(t, e, r, i, s, n, f) {
            var P = [].concat(n),
                d, _ = t.length - 1,
                E, k, u = [],
                g = [],
                v, m, S;
            for (d = _; d >= 0; d -= 1) {
                if (S = this.searchProcessedElement(t[d]), S ? e[d] = r[S - 1] : t[d]._render = f, t[d].ty === "fl" || t[d].ty === "st" || t[d].ty === "gf" || t[d].ty === "gs" || t[d].ty === "no") S ? e[d].style.closed = !1 : e[d] = this.createStyleElement(t[d], s), t[d]._render && e[d].style.pElem.parentNode !== i && i.appendChild(e[d].style.pElem), u.push(e[d].style);
                else if (t[d].ty === "gr") {
                    if (!S) e[d] = this.createGroupElement(t[d]);
                    else
                        for (k = e[d].it.length, E = 0; E < k; E += 1) e[d].prevViewData[E] = e[d].it[E];
                    this.searchShapes(t[d].it, e[d].it, e[d].prevViewData, e[d].gr, s + 1, P, f), t[d]._render && e[d].gr.parentNode !== i && i.appendChild(e[d].gr)
                } else t[d].ty === "tr" ? (S || (e[d] = this.createTransformElement(t[d], i)), v = e[d].transform, P.push(v)) : t[d].ty === "sh" || t[d].ty === "rc" || t[d].ty === "el" || t[d].ty === "sr" ? (S || (e[d] = this.createShapeElement(t[d], P, s)), this.setElementStyles(e[d])) : t[d].ty === "tm" || t[d].ty === "rd" || t[d].ty === "ms" || t[d].ty === "pb" ? (S ? (m = e[d], m.closed = !1) : (m = ShapeModifiers.getModifier(t[d].ty), m.init(this, t[d]), e[d] = m, this.shapeModifiers.push(m)), g.push(m)) : t[d].ty === "rp" && (S ? (m = e[d], m.closed = !0) : (m = ShapeModifiers.getModifier(t[d].ty), e[d] = m, m.init(this, t, d, e), this.shapeModifiers.push(m), f = !1), g.push(m));
                this.addProcessedElement(t[d], d + 1)
            }
            for (_ = u.length, d = 0; d < _; d += 1) u[d].closed = !0;
            for (_ = g.length, d = 0; d < _; d += 1) g[d].closed = !0
        }, SVGShapeElement.prototype.renderInnerContent = function() {
            this.renderModifiers();
            var t, e = this.stylesList.length;
            for (t = 0; t < e; t += 1) this.stylesList[t].reset();
            for (this.renderShape(), t = 0; t < e; t += 1)(this.stylesList[t]._mdf || this._isFirstFrame) && (this.stylesList[t].msElem && (this.stylesList[t].msElem.setAttribute("d", this.stylesList[t].d), this.stylesList[t].d = "M0 0" + this.stylesList[t].d), this.stylesList[t].pElem.setAttribute("d", this.stylesList[t].d || "M0 0"))
        }, SVGShapeElement.prototype.renderShape = function() {
            var t, e = this.animatedContents.length,
                r;
            for (t = 0; t < e; t += 1) r = this.animatedContents[t], (this._isFirstFrame || r.element._isAnimated) && r.data !== !0 && r.fn(r.data, r.element, this._isFirstFrame)
        }, SVGShapeElement.prototype.destroy = function() {
            this.destroyBaseElement(), this.shapesData = null, this.itemsData = null
        };

        function LetterProps(t, e, r, i, s, n) {
            this.o = t, this.sw = e, this.sc = r, this.fc = i, this.m = s, this.p = n, this._mdf = {
                o: !0,
                sw: !!e,
                sc: !!r,
                fc: !!i,
                m: !0,
                p: !0
            }
        }
        LetterProps.prototype.update = function(t, e, r, i, s, n) {
            this._mdf.o = !1, this._mdf.sw = !1, this._mdf.sc = !1, this._mdf.fc = !1, this._mdf.m = !1, this._mdf.p = !1;
            var f = !1;
            return this.o !== t && (this.o = t, this._mdf.o = !0, f = !0), this.sw !== e && (this.sw = e, this._mdf.sw = !0, f = !0), this.sc !== r && (this.sc = r, this._mdf.sc = !0, f = !0), this.fc !== i && (this.fc = i, this._mdf.fc = !0, f = !0), this.m !== s && (this.m = s, this._mdf.m = !0, f = !0), n.length && (this.p[0] !== n[0] || this.p[1] !== n[1] || this.p[4] !== n[4] || this.p[5] !== n[5] || this.p[12] !== n[12] || this.p[13] !== n[13]) && (this.p = n, this._mdf.p = !0, f = !0), f
        };

        function TextProperty(t, e) {
            this._frameId = initialDefaultFrame, this.pv = "", this.v = "", this.kf = !1, this._isFirstFrame = !0, this._mdf = !1, this.data = e, this.elem = t, this.comp = this.elem.comp, this.keysIndex = 0, this.canResize = !1, this.minimumFontSize = 1, this.effectsSequence = [], this.currentData = {
                ascent: 0,
                boxWidth: this.defaultBoxWidth,
                f: "",
                fStyle: "",
                fWeight: "",
                fc: "",
                j: "",
                justifyOffset: "",
                l: [],
                lh: 0,
                lineWidths: [],
                ls: "",
                of: "",
                s: "",
                sc: "",
                sw: 0,
                t: 0,
                tr: 0,
                sz: 0,
                ps: null,
                fillColorAnim: !1,
                strokeColorAnim: !1,
                strokeWidthAnim: !1,
                yOffset: 0,
                finalSize: 0,
                finalText: [],
                finalLineHeight: 0,
                __complete: !1
            }, this.copyData(this.currentData, this.data.d.k[0].s), this.searchProperty() || this.completeTextData(this.currentData)
        }
        TextProperty.prototype.defaultBoxWidth = [0, 0], TextProperty.prototype.copyData = function(t, e) {
            for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t
        }, TextProperty.prototype.setCurrentData = function(t) {
            t.__complete || this.completeTextData(t), this.currentData = t, this.currentData.boxWidth = this.currentData.boxWidth || this.defaultBoxWidth, this._mdf = !0
        }, TextProperty.prototype.searchProperty = function() {
            return this.searchKeyframes()
        }, TextProperty.prototype.searchKeyframes = function() {
            return this.kf = this.data.d.k.length > 1, this.kf && this.addEffect(this.getKeyframeValue.bind(this)), this.kf
        }, TextProperty.prototype.addEffect = function(t) {
            this.effectsSequence.push(t), this.elem.addDynamicProperty(this)
        }, TextProperty.prototype.getValue = function(t) {
            if (!((this.elem.globalData.frameId === this.frameId || !this.effectsSequence.length) && !t)) {
                this.currentData.t = this.data.d.k[this.keysIndex].s.t;
                var e = this.currentData,
                    r = this.keysIndex;
                if (this.lock) {
                    this.setCurrentData(this.currentData);
                    return
                }
                this.lock = !0, this._mdf = !1;
                var i, s = this.effectsSequence.length,
                    n = t || this.data.d.k[this.keysIndex].s;
                for (i = 0; i < s; i += 1) r !== this.keysIndex ? n = this.effectsSequence[i](n, n.t) : n = this.effectsSequence[i](this.currentData, n.t);
                e !== n && this.setCurrentData(n), this.v = this.currentData, this.pv = this.v, this.lock = !1, this.frameId = this.elem.globalData.frameId
            }
        }, TextProperty.prototype.getKeyframeValue = function() {
            for (var t = this.data.d.k, e = this.elem.comp.renderedFrame, r = 0, i = t.length; r <= i - 1 && !(r === i - 1 || t[r + 1].t > e);) r += 1;
            return this.keysIndex !== r && (this.keysIndex = r), this.data.d.k[this.keysIndex].s
        }, TextProperty.prototype.buildFinalText = function(t) {
            for (var e = [], r = 0, i = t.length, s, n, f = !1; r < i;) s = t.charCodeAt(r), FontManager.isCombinedCharacter(s) ? e[e.length - 1] += t.charAt(r) : s >= 55296 && s <= 56319 ? (n = t.charCodeAt(r + 1), n >= 56320 && n <= 57343 ? (f || FontManager.isModifier(s, n) ? (e[e.length - 1] += t.substr(r, 2), f = !1) : e.push(t.substr(r, 2)), r += 1) : e.push(t.charAt(r))) : s > 56319 ? (n = t.charCodeAt(r + 1), FontManager.isZeroWidthJoiner(s, n) ? (f = !0, e[e.length - 1] += t.substr(r, 2), r += 1) : e.push(t.charAt(r))) : FontManager.isZeroWidthJoiner(s) ? (e[e.length - 1] += t.charAt(r), f = !0) : e.push(t.charAt(r)), r += 1;
            return e
        }, TextProperty.prototype.completeTextData = function(t) {
            t.__complete = !0;
            var e = this.elem.globalData.fontManager,
                r = this.data,
                i = [],
                s, n, f, P = 0,
                d, _ = r.m.g,
                E = 0,
                k = 0,
                u = 0,
                g = [],
                v = 0,
                m = 0,
                S, o, l = e.getFontByName(t.f),
                a, h = 0,
                p = getFontProperties(l);
            t.fWeight = p.weight, t.fStyle = p.style, t.finalSize = t.s, t.finalText = this.buildFinalText(t.t), n = t.finalText.length, t.finalLineHeight = t.lh;
            var c = t.tr / 1e3 * t.finalSize,
                b;
            if (t.sz)
                for (var A = !0, I = t.sz[0], R = t.sz[1], L, w; A;) {
                    w = this.buildFinalText(t.t), L = 0, v = 0, n = w.length, c = t.tr / 1e3 * t.finalSize;
                    var G = -1;
                    for (s = 0; s < n; s += 1) b = w[s].charCodeAt(0), f = !1, w[s] === " " ? G = s : (b === 13 || b === 3) && (v = 0, f = !0, L += t.finalLineHeight || t.finalSize * 1.2), e.chars ? (a = e.getCharData(w[s], l.fStyle, l.fFamily), h = f ? 0 : a.w * t.finalSize / 100) : h = e.measureText(w[s], t.f, t.finalSize), v + h > I && w[s] !== " " ? (G === -1 ? n += 1 : s = G, L += t.finalLineHeight || t.finalSize * 1.2, w.splice(s, G === s ? 1 : 0, "\r"), G = -1, v = 0) : (v += h, v += c);
                    L += l.ascent * t.finalSize / 100, this.canResize && t.finalSize > this.minimumFontSize && R < L ? (t.finalSize -= 1, t.finalLineHeight = t.finalSize * t.lh / t.s) : (t.finalText = w, n = t.finalText.length, A = !1)
                }
            v = -c, h = 0;
            var B = 0,
                C;
            for (s = 0; s < n; s += 1)
                if (f = !1, C = t.finalText[s], b = C.charCodeAt(0), b === 13 || b === 3 ? (B = 0, g.push(v), m = v > m ? v : m, v = -2 * c, d = "", f = !0, u += 1) : d = C, e.chars ? (a = e.getCharData(C, l.fStyle, e.getFontByName(t.f).fFamily), h = f ? 0 : a.w * t.finalSize / 100) : h = e.measureText(d, t.f, t.finalSize), C === " " ? B += h + c : (v += h + c + B, B = 0), i.push({
                        l: h,
                        an: h,
                        add: E,
                        n: f,
                        anIndexes: [],
                        val: d,
                        line: u,
                        animatorJustifyOffset: 0
                    }), _ == 2) {
                    if (E += h, d === "" || d === " " || s === n - 1) {
                        for ((d === "" || d === " ") && (E -= h); k <= s;) i[k].an = E, i[k].ind = P, i[k].extra = h, k += 1;
                        P += 1, E = 0
                    }
                } else if (_ == 3) {
                if (E += h, d === "" || s === n - 1) {
                    for (d === "" && (E -= h); k <= s;) i[k].an = E, i[k].ind = P, i[k].extra = h, k += 1;
                    E = 0, P += 1
                }
            } else i[P].ind = P, i[P].extra = 0, P += 1;
            if (t.l = i, m = v > m ? v : m, g.push(v), t.sz) t.boxWidth = t.sz[0], t.justifyOffset = 0;
            else switch (t.boxWidth = m, t.j) {
                case 1:
                    t.justifyOffset = -t.boxWidth;
                    break;
                case 2:
                    t.justifyOffset = -t.boxWidth / 2;
                    break;
                default:
                    t.justifyOffset = 0
            }
            t.lineWidths = g;
            var F = r.a,
                x, y;
            o = F.length;
            var T, V, M = [];
            for (S = 0; S < o; S += 1) {
                for (x = F[S], x.a.sc && (t.strokeColorAnim = !0), x.a.sw && (t.strokeWidthAnim = !0), (x.a.fc || x.a.fh || x.a.fs || x.a.fb) && (t.fillColorAnim = !0), V = 0, T = x.s.b, s = 0; s < n; s += 1) y = i[s], y.anIndexes[S] = V, (T == 1 && y.val !== "" || T == 2 && y.val !== "" && y.val !== " " || T == 3 && (y.n || y.val == " " || s == n - 1) || T == 4 && (y.n || s == n - 1)) && (x.s.rn === 1 && M.push(V), V += 1);
                r.a[S].s.totalChars = V;
                var D = -1,
                    N;
                if (x.s.rn === 1)
                    for (s = 0; s < n; s += 1) y = i[s], D != y.anIndexes[S] && (D = y.anIndexes[S], N = M.splice(Math.floor(Math.random() * M.length), 1)[0]), y.anIndexes[S] = N
            }
            t.yOffset = t.finalLineHeight || t.finalSize * 1.2, t.ls = t.ls || 0, t.ascent = l.ascent * t.finalSize / 100
        }, TextProperty.prototype.updateDocumentData = function(t, e) {
            e = e === void 0 ? this.keysIndex : e;
            var r = this.copyData({}, this.data.d.k[e].s);
            r = this.copyData(r, t), this.data.d.k[e].s = r, this.recalculate(e), this.elem.addDynamicProperty(this)
        }, TextProperty.prototype.recalculate = function(t) {
            var e = this.data.d.k[t].s;
            e.__complete = !1, this.keysIndex = 0, this._isFirstFrame = !0, this.getValue(e)
        }, TextProperty.prototype.canResizeFont = function(t) {
            this.canResize = t, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
        }, TextProperty.prototype.setMinimumFontSize = function(t) {
            this.minimumFontSize = Math.floor(t) || 1, this.recalculate(this.keysIndex), this.elem.addDynamicProperty(this)
        };
        var TextSelectorProp = function() {
            var t = Math.max,
                e = Math.min,
                r = Math.floor;

            function i(n, f) {
                this._currentTextLength = -1, this.k = !1, this.data = f, this.elem = n, this.comp = n.comp, this.finalS = 0, this.finalE = 0, this.initDynamicPropertyContainer(n), this.s = PropertyFactory.getProp(n, f.s || {
                    k: 0
                }, 0, 0, this), "e" in f ? this.e = PropertyFactory.getProp(n, f.e, 0, 0, this) : this.e = {
                    v: 100
                }, this.o = PropertyFactory.getProp(n, f.o || {
                    k: 0
                }, 0, 0, this), this.xe = PropertyFactory.getProp(n, f.xe || {
                    k: 0
                }, 0, 0, this), this.ne = PropertyFactory.getProp(n, f.ne || {
                    k: 0
                }, 0, 0, this), this.sm = PropertyFactory.getProp(n, f.sm || {
                    k: 100
                }, 0, 0, this), this.a = PropertyFactory.getProp(n, f.a, 0, .01, this), this.dynamicProperties.length || this.getValue()
            }
            i.prototype = {
                getMult: function(f) {
                    this._currentTextLength !== this.elem.textProperty.currentData.l.length && this.getValue();
                    var P = 0,
                        d = 0,
                        _ = 1,
                        E = 1;
                    this.ne.v > 0 ? P = this.ne.v / 100 : d = -this.ne.v / 100, this.xe.v > 0 ? _ = 1 - this.xe.v / 100 : E = 1 + this.xe.v / 100;
                    var k = BezierFactory.getBezierEasing(P, d, _, E).get,
                        u = 0,
                        g = this.finalS,
                        v = this.finalE,
                        m = this.data.sh;
                    if (m === 2) v === g ? u = f >= v ? 1 : 0 : u = t(0, e(.5 / (v - g) + (f - g) / (v - g), 1)), u = k(u);
                    else if (m === 3) v === g ? u = f >= v ? 0 : 1 : u = 1 - t(0, e(.5 / (v - g) + (f - g) / (v - g), 1)), u = k(u);
                    else if (m === 4) v === g ? u = 0 : (u = t(0, e(.5 / (v - g) + (f - g) / (v - g), 1)), u < .5 ? u *= 2 : u = 1 - 2 * (u - .5)), u = k(u);
                    else if (m === 5) {
                        if (v === g) u = 0;
                        else {
                            var S = v - g;
                            f = e(t(0, f + .5 - g), v - g);
                            var o = -S / 2 + f,
                                l = S / 2;
                            u = Math.sqrt(1 - o * o / (l * l))
                        }
                        u = k(u)
                    } else m === 6 ? (v === g ? u = 0 : (f = e(t(0, f + .5 - g), v - g), u = (1 + Math.cos(Math.PI + Math.PI * 2 * f / (v - g))) / 2), u = k(u)) : (f >= r(g) && (f - g < 0 ? u = t(0, e(e(v, 1) - (g - f), 1)) : u = t(0, e(v - f, 1))), u = k(u));
                    if (this.sm.v !== 100) {
                        var a = this.sm.v * .01;
                        a === 0 && (a = 1e-8);
                        var h = .5 - a * .5;
                        u < h ? u = 0 : (u = (u - h) / a, u > 1 && (u = 1))
                    }
                    return u * this.a.v
                },
                getValue: function(f) {
                    this.iterateDynamicProperties(), this._mdf = f || this._mdf, this._currentTextLength = this.elem.textProperty.currentData.l.length || 0, f && this.data.r === 2 && (this.e.v = this._currentTextLength);
                    var P = this.data.r === 2 ? 1 : 100 / this.data.totalChars,
                        d = this.o.v / P,
                        _ = this.s.v / P + d,
                        E = this.e.v / P + d;
                    if (_ > E) {
                        var k = _;
                        _ = E, E = k
                    }
                    this.finalS = _, this.finalE = E
                }
            }, extendPrototype([DynamicPropertyContainer], i);

            function s(n, f, P) {
                return new i(n, f, P)
            }
            return {
                getTextSelectorProp: s
            }
        }();

        function TextAnimatorDataProperty(t, e, r) {
            var i = {
                    propType: !1
                },
                s = PropertyFactory.getProp,
                n = e.a;
            this.a = {
                r: n.r ? s(t, n.r, 0, degToRads, r) : i,
                rx: n.rx ? s(t, n.rx, 0, degToRads, r) : i,
                ry: n.ry ? s(t, n.ry, 0, degToRads, r) : i,
                sk: n.sk ? s(t, n.sk, 0, degToRads, r) : i,
                sa: n.sa ? s(t, n.sa, 0, degToRads, r) : i,
                s: n.s ? s(t, n.s, 1, .01, r) : i,
                a: n.a ? s(t, n.a, 1, 0, r) : i,
                o: n.o ? s(t, n.o, 0, .01, r) : i,
                p: n.p ? s(t, n.p, 1, 0, r) : i,
                sw: n.sw ? s(t, n.sw, 0, 0, r) : i,
                sc: n.sc ? s(t, n.sc, 1, 0, r) : i,
                fc: n.fc ? s(t, n.fc, 1, 0, r) : i,
                fh: n.fh ? s(t, n.fh, 0, 0, r) : i,
                fs: n.fs ? s(t, n.fs, 0, .01, r) : i,
                fb: n.fb ? s(t, n.fb, 0, .01, r) : i,
                t: n.t ? s(t, n.t, 0, 0, r) : i
            }, this.s = TextSelectorProp.getTextSelectorProp(t, e.s, r), this.s.t = e.s.t
        }

        function TextAnimatorProperty(t, e, r) {
            this._isFirstFrame = !0, this._hasMaskedPath = !1, this._frameId = -1, this._textData = t, this._renderType = e, this._elem = r, this._animatorsData = createSizedArray(this._textData.a.length), this._pathData = {}, this._moreOptions = {
                alignment: {}
            }, this.renderedLetters = [], this.lettersChangedFlag = !1, this.initDynamicPropertyContainer(r)
        }
        TextAnimatorProperty.prototype.searchProperties = function() {
            var t, e = this._textData.a.length,
                r, i = PropertyFactory.getProp;
            for (t = 0; t < e; t += 1) r = this._textData.a[t], this._animatorsData[t] = new TextAnimatorDataProperty(this._elem, r, this);
            this._textData.p && "m" in this._textData.p ? (this._pathData = {
                a: i(this._elem, this._textData.p.a, 0, 0, this),
                f: i(this._elem, this._textData.p.f, 0, 0, this),
                l: i(this._elem, this._textData.p.l, 0, 0, this),
                r: i(this._elem, this._textData.p.r, 0, 0, this),
                p: i(this._elem, this._textData.p.p, 0, 0, this),
                m: this._elem.maskManager.getMaskProperty(this._textData.p.m)
            }, this._hasMaskedPath = !0) : this._hasMaskedPath = !1, this._moreOptions.alignment = i(this._elem, this._textData.m.a, 1, 0, this)
        }, TextAnimatorProperty.prototype.getMeasures = function(t, e) {
            if (this.lettersChangedFlag = e, !(!this._mdf && !this._isFirstFrame && !e && (!this._hasMaskedPath || !this._pathData.m._mdf))) {
                this._isFirstFrame = !1;
                var r = this._moreOptions.alignment.v,
                    i = this._animatorsData,
                    s = this._textData,
                    n = this.mHelper,
                    f = this._renderType,
                    P = this.renderedLetters.length,
                    d, _, E, k, u = t.l,
                    g, v, m, S, o, l, a, h, p, c, b, A, I, R, L;
                if (this._hasMaskedPath) {
                    if (L = this._pathData.m, !this._pathData.n || this._pathData._mdf) {
                        var w = L.v;
                        this._pathData.r.v && (w = w.reverse()), g = {
                            tLength: 0,
                            segments: []
                        }, k = w._length - 1;
                        var G;
                        for (A = 0, E = 0; E < k; E += 1) G = bez.buildBezierData(w.v[E], w.v[E + 1], [w.o[E][0] - w.v[E][0], w.o[E][1] - w.v[E][1]], [w.i[E + 1][0] - w.v[E + 1][0], w.i[E + 1][1] - w.v[E + 1][1]]), g.tLength += G.segmentLength, g.segments.push(G), A += G.segmentLength;
                        E = k, L.v.c && (G = bez.buildBezierData(w.v[E], w.v[0], [w.o[E][0] - w.v[E][0], w.o[E][1] - w.v[E][1]], [w.i[0][0] - w.v[0][0], w.i[0][1] - w.v[0][1]]), g.tLength += G.segmentLength, g.segments.push(G), A += G.segmentLength), this._pathData.pi = g
                    }
                    if (g = this._pathData.pi, v = this._pathData.f.v, a = 0, l = 1, S = 0, o = !0, c = g.segments, v < 0 && L.v.c)
                        for (g.tLength < Math.abs(v) && (v = -Math.abs(v) % g.tLength), a = c.length - 1, p = c[a].points, l = p.length - 1; v < 0;) v += p[l].partialLength, l -= 1, l < 0 && (a -= 1, p = c[a].points, l = p.length - 1);
                    p = c[a].points, h = p[l - 1], m = p[l], b = m.partialLength
                }
                k = u.length, d = 0, _ = 0;
                var B = t.finalSize * 1.2 * .714,
                    C = !0,
                    F, x, y, T, V;
                T = i.length;
                var M, D = -1,
                    N, z, H, j = v,
                    X = a,
                    K = l,
                    U = -1,
                    $, q, Y, O, W, et, nt, rt, tt = "",
                    it = this.defaultPropsArray,
                    st;
                if (t.j === 2 || t.j === 1) {
                    var Z = 0,
                        at = 0,
                        ot = t.j === 2 ? -.5 : -1,
                        J = 0,
                        ht = !0;
                    for (E = 0; E < k; E += 1)
                        if (u[E].n) {
                            for (Z && (Z += at); J < E;) u[J].animatorJustifyOffset = Z, J += 1;
                            Z = 0, ht = !0
                        } else {
                            for (y = 0; y < T; y += 1) F = i[y].a, F.t.propType && (ht && t.j === 2 && (at += F.t.v * ot), x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), M.length ? Z += F.t.v * M[0] * ot : Z += F.t.v * M * ot);
                            ht = !1
                        }
                    for (Z && (Z += at); J < E;) u[J].animatorJustifyOffset = Z, J += 1
                }
                for (E = 0; E < k; E += 1) {
                    if (n.reset(), $ = 1, u[E].n) d = 0, _ += t.yOffset, _ += C ? 1 : 0, v = j, C = !1, this._hasMaskedPath && (a = X, l = K, p = c[a].points, h = p[l - 1], m = p[l], b = m.partialLength, S = 0), tt = "", rt = "", et = "", st = "", it = this.defaultPropsArray;
                    else {
                        if (this._hasMaskedPath) {
                            if (U !== u[E].line) {
                                switch (t.j) {
                                    case 1:
                                        v += A - t.lineWidths[u[E].line];
                                        break;
                                    case 2:
                                        v += (A - t.lineWidths[u[E].line]) / 2;
                                        break
                                }
                                U = u[E].line
                            }
                            D !== u[E].ind && (u[D] && (v += u[D].extra), v += u[E].an / 2, D = u[E].ind), v += r[0] * u[E].an * .005;
                            var Q = 0;
                            for (y = 0; y < T; y += 1) F = i[y].a, F.p.propType && (x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), M.length ? Q += F.p.v[0] * M[0] : Q += F.p.v[0] * M), F.a.propType && (x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), M.length ? Q += F.a.v[0] * M[0] : Q += F.a.v[0] * M);
                            for (o = !0, this._pathData.a.v && (v = u[0].an * .5 + (A - this._pathData.f.v - u[0].an * .5 - u[u.length - 1].an * .5) * D / (k - 1), v += this._pathData.f.v); o;) S + b >= v + Q || !p ? (I = (v + Q - S) / m.partialLength, z = h.point[0] + (m.point[0] - h.point[0]) * I, H = h.point[1] + (m.point[1] - h.point[1]) * I, n.translate(-r[0] * u[E].an * .005, -(r[1] * B) * .01), o = !1) : p && (S += m.partialLength, l += 1, l >= p.length && (l = 0, a += 1, c[a] ? p = c[a].points : L.v.c ? (l = 0, a = 0, p = c[a].points) : (S -= m.partialLength, p = null)), p && (h = m, m = p[l], b = m.partialLength));
                            N = u[E].an / 2 - u[E].add, n.translate(-N, 0, 0)
                        } else N = u[E].an / 2 - u[E].add, n.translate(-N, 0, 0), n.translate(-r[0] * u[E].an * .005, -r[1] * B * .01, 0);
                        for (y = 0; y < T; y += 1) F = i[y].a, F.t.propType && (x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), (d !== 0 || t.j !== 0) && (this._hasMaskedPath ? M.length ? v += F.t.v * M[0] : v += F.t.v * M : M.length ? d += F.t.v * M[0] : d += F.t.v * M));
                        for (t.strokeWidthAnim && (Y = t.sw || 0), t.strokeColorAnim && (t.sc ? q = [t.sc[0], t.sc[1], t.sc[2]] : q = [0, 0, 0]), t.fillColorAnim && t.fc && (O = [t.fc[0], t.fc[1], t.fc[2]]), y = 0; y < T; y += 1) F = i[y].a, F.a.propType && (x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), M.length ? n.translate(-F.a.v[0] * M[0], -F.a.v[1] * M[1], F.a.v[2] * M[2]) : n.translate(-F.a.v[0] * M, -F.a.v[1] * M, F.a.v[2] * M));
                        for (y = 0; y < T; y += 1) F = i[y].a, F.s.propType && (x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), M.length ? n.scale(1 + (F.s.v[0] - 1) * M[0], 1 + (F.s.v[1] - 1) * M[1], 1) : n.scale(1 + (F.s.v[0] - 1) * M, 1 + (F.s.v[1] - 1) * M, 1));
                        for (y = 0; y < T; y += 1) {
                            if (F = i[y].a, x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), F.sk.propType && (M.length ? n.skewFromAxis(-F.sk.v * M[0], F.sa.v * M[1]) : n.skewFromAxis(-F.sk.v * M, F.sa.v * M)), F.r.propType && (M.length ? n.rotateZ(-F.r.v * M[2]) : n.rotateZ(-F.r.v * M)), F.ry.propType && (M.length ? n.rotateY(F.ry.v * M[1]) : n.rotateY(F.ry.v * M)), F.rx.propType && (M.length ? n.rotateX(F.rx.v * M[0]) : n.rotateX(F.rx.v * M)), F.o.propType && (M.length ? $ += (F.o.v * M[0] - $) * M[0] : $ += (F.o.v * M - $) * M), t.strokeWidthAnim && F.sw.propType && (M.length ? Y += F.sw.v * M[0] : Y += F.sw.v * M), t.strokeColorAnim && F.sc.propType)
                                for (W = 0; W < 3; W += 1) M.length ? q[W] += (F.sc.v[W] - q[W]) * M[0] : q[W] += (F.sc.v[W] - q[W]) * M;
                            if (t.fillColorAnim && t.fc) {
                                if (F.fc.propType)
                                    for (W = 0; W < 3; W += 1) M.length ? O[W] += (F.fc.v[W] - O[W]) * M[0] : O[W] += (F.fc.v[W] - O[W]) * M;
                                F.fh.propType && (M.length ? O = addHueToRGB(O, F.fh.v * M[0]) : O = addHueToRGB(O, F.fh.v * M)), F.fs.propType && (M.length ? O = addSaturationToRGB(O, F.fs.v * M[0]) : O = addSaturationToRGB(O, F.fs.v * M)), F.fb.propType && (M.length ? O = addBrightnessToRGB(O, F.fb.v * M[0]) : O = addBrightnessToRGB(O, F.fb.v * M))
                            }
                        }
                        for (y = 0; y < T; y += 1) F = i[y].a, F.p.propType && (x = i[y].s, M = x.getMult(u[E].anIndexes[y], s.a[y].s.totalChars), this._hasMaskedPath ? M.length ? n.translate(0, F.p.v[1] * M[0], -F.p.v[2] * M[1]) : n.translate(0, F.p.v[1] * M, -F.p.v[2] * M) : M.length ? n.translate(F.p.v[0] * M[0], F.p.v[1] * M[1], -F.p.v[2] * M[2]) : n.translate(F.p.v[0] * M, F.p.v[1] * M, -F.p.v[2] * M));
                        if (t.strokeWidthAnim && (et = Y < 0 ? 0 : Y), t.strokeColorAnim && (nt = "rgb(" + Math.round(q[0] * 255) + "," + Math.round(q[1] * 255) + "," + Math.round(q[2] * 255) + ")"), t.fillColorAnim && t.fc && (rt = "rgb(" + Math.round(O[0] * 255) + "," + Math.round(O[1] * 255) + "," + Math.round(O[2] * 255) + ")"), this._hasMaskedPath) {
                            if (n.translate(0, -t.ls), n.translate(0, r[1] * B * .01 + _, 0), this._pathData.p.v) {
                                R = (m.point[1] - h.point[1]) / (m.point[0] - h.point[0]);
                                var lt = Math.atan(R) * 180 / Math.PI;
                                m.point[0] < h.point[0] && (lt += 180), n.rotate(-lt * Math.PI / 180)
                            }
                            n.translate(z, H, 0), v -= r[0] * u[E].an * .005, u[E + 1] && D !== u[E + 1].ind && (v += u[E].an / 2, v += t.tr * .001 * t.finalSize)
                        } else {
                            switch (n.translate(d, _, 0), t.ps && n.translate(t.ps[0], t.ps[1] + t.ascent, 0), t.j) {
                                case 1:
                                    n.translate(u[E].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[u[E].line]), 0, 0);
                                    break;
                                case 2:
                                    n.translate(u[E].animatorJustifyOffset + t.justifyOffset + (t.boxWidth - t.lineWidths[u[E].line]) / 2, 0, 0);
                                    break
                            }
                            n.translate(0, -t.ls), n.translate(N, 0, 0), n.translate(r[0] * u[E].an * .005, r[1] * B * .01, 0), d += u[E].l + t.tr * .001 * t.finalSize
                        }
                        f === "html" ? tt = n.toCSS() : f === "svg" ? tt = n.to2dCSS() : it = [n.props[0], n.props[1], n.props[2], n.props[3], n.props[4], n.props[5], n.props[6], n.props[7], n.props[8], n.props[9], n.props[10], n.props[11], n.props[12], n.props[13], n.props[14], n.props[15]], st = $
                    }
                    P <= E ? (V = new LetterProps(st, et, nt, rt, tt, it), this.renderedLetters.push(V), P += 1, this.lettersChangedFlag = !0) : (V = this.renderedLetters[E], this.lettersChangedFlag = V.update(st, et, nt, rt, tt, it) || this.lettersChangedFlag)
                }
            }
        }, TextAnimatorProperty.prototype.getValue = function() {
            this._elem.globalData.frameId !== this._frameId && (this._frameId = this._elem.globalData.frameId, this.iterateDynamicProperties())
        }, TextAnimatorProperty.prototype.mHelper = new Matrix, TextAnimatorProperty.prototype.defaultPropsArray = [], extendPrototype([DynamicPropertyContainer], TextAnimatorProperty);

        function ITextElement() {}
        ITextElement.prototype.initElement = function(t, e, r) {
            this.lettersChangedFlag = !0, this.initFrame(), this.initBaseData(t, e, r), this.textProperty = new TextProperty(this, t.t, this.dynamicProperties), this.textAnimator = new TextAnimatorProperty(t.t, this.renderType, this), this.initTransform(t, e, r), this.initHierarchy(), this.initRenderable(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), this.createContent(), this.hide(), this.textAnimator.searchProperties(this.dynamicProperties)
        }, ITextElement.prototype.prepareFrame = function(t) {
            this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), (this.textProperty._mdf || this.textProperty._isFirstFrame) && (this.buildNewText(), this.textProperty._isFirstFrame = !1, this.textProperty._mdf = !1)
        }, ITextElement.prototype.createPathShape = function(t, e) {
            var r, i = e.length,
                s, n = "";
            for (r = 0; r < i; r += 1) e[r].ty === "sh" && (s = e[r].ks.k, n += buildShapeString(s, s.i.length, !0, t));
            return n
        }, ITextElement.prototype.updateDocumentData = function(t, e) {
            this.textProperty.updateDocumentData(t, e)
        }, ITextElement.prototype.canResizeFont = function(t) {
            this.textProperty.canResizeFont(t)
        }, ITextElement.prototype.setMinimumFontSize = function(t) {
            this.textProperty.setMinimumFontSize(t)
        }, ITextElement.prototype.applyTextPropertiesToMatrix = function(t, e, r, i, s) {
            switch (t.ps && e.translate(t.ps[0], t.ps[1] + t.ascent, 0), e.translate(0, -t.ls, 0), t.j) {
                case 1:
                    e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[r]), 0, 0);
                    break;
                case 2:
                    e.translate(t.justifyOffset + (t.boxWidth - t.lineWidths[r]) / 2, 0, 0);
                    break
            }
            e.translate(i, s, 0)
        }, ITextElement.prototype.buildColor = function(t) {
            return "rgb(" + Math.round(t[0] * 255) + "," + Math.round(t[1] * 255) + "," + Math.round(t[2] * 255) + ")"
        }, ITextElement.prototype.emptyProp = new LetterProps, ITextElement.prototype.destroy = function() {};
        var emptyShapeData = {
            shapes: []
        };

        function SVGTextLottieElement(t, e, r) {
            this.textSpans = [], this.renderType = "svg", this.initElement(t, e, r)
        }
        extendPrototype([BaseElement, TransformElement, SVGBaseElement, HierarchyElement, FrameElement, RenderableDOMElement, ITextElement], SVGTextLottieElement), SVGTextLottieElement.prototype.createContent = function() {
            this.data.singleShape && !this.globalData.fontManager.chars && (this.textContainer = createNS("text"))
        }, SVGTextLottieElement.prototype.buildTextContents = function(t) {
            for (var e = 0, r = t.length, i = [], s = ""; e < r;) t[e] === String.fromCharCode(13) || t[e] === String.fromCharCode(3) ? (i.push(s), s = "") : s += t[e], e += 1;
            return i.push(s), i
        }, SVGTextLottieElement.prototype.buildNewText = function() {
            this.addDynamicProperty(this);
            var t, e, r = this.textProperty.currentData;
            this.renderedLetters = createSizedArray(r ? r.l.length : 0), r.fc ? this.layerElement.setAttribute("fill", this.buildColor(r.fc)) : this.layerElement.setAttribute("fill", "rgba(0,0,0,0)"), r.sc && (this.layerElement.setAttribute("stroke", this.buildColor(r.sc)), this.layerElement.setAttribute("stroke-width", r.sw)), this.layerElement.setAttribute("font-size", r.finalSize);
            var i = this.globalData.fontManager.getFontByName(r.f);
            if (i.fClass) this.layerElement.setAttribute("class", i.fClass);
            else {
                this.layerElement.setAttribute("font-family", i.fFamily);
                var s = r.fWeight,
                    n = r.fStyle;
                this.layerElement.setAttribute("font-style", n), this.layerElement.setAttribute("font-weight", s)
            }
            this.layerElement.setAttribute("aria-label", r.t);
            var f = r.l || [],
                P = !!this.globalData.fontManager.chars;
            e = f.length;
            var d, _ = this.mHelper,
                E = "",
                k = this.data.singleShape,
                u = 0,
                g = 0,
                v = !0,
                m = r.tr * .001 * r.finalSize;
            if (k && !P && !r.sz) {
                var S = this.textContainer,
                    o = "start";
                switch (r.j) {
                    case 1:
                        o = "end";
                        break;
                    case 2:
                        o = "middle";
                        break;
                    default:
                        o = "start";
                        break
                }
                S.setAttribute("text-anchor", o), S.setAttribute("letter-spacing", m);
                var l = this.buildTextContents(r.finalText);
                for (e = l.length, g = r.ps ? r.ps[1] + r.ascent : 0, t = 0; t < e; t += 1) d = this.textSpans[t].span || createNS("tspan"), d.textContent = l[t], d.setAttribute("x", 0), d.setAttribute("y", g), d.style.display = "inherit", S.appendChild(d), this.textSpans[t] || (this.textSpans[t] = {
                    span: null,
                    glyph: null
                }), this.textSpans[t].span = d, g += r.finalLineHeight;
                this.layerElement.appendChild(S)
            } else {
                var a = this.textSpans.length,
                    h;
                for (t = 0; t < e; t += 1) {
                    if (this.textSpans[t] || (this.textSpans[t] = {
                            span: null,
                            childSpan: null,
                            glyph: null
                        }), !P || !k || t === 0) {
                        if (d = a > t ? this.textSpans[t].span : createNS(P ? "g" : "text"), a <= t) {
                            if (d.setAttribute("stroke-linecap", "butt"), d.setAttribute("stroke-linejoin", "round"), d.setAttribute("stroke-miterlimit", "4"), this.textSpans[t].span = d, P) {
                                var p = createNS("g");
                                d.appendChild(p), this.textSpans[t].childSpan = p
                            }
                            this.textSpans[t].span = d, this.layerElement.appendChild(d)
                        }
                        d.style.display = "inherit"
                    }
                    if (_.reset(), _.scale(r.finalSize / 100, r.finalSize / 100), k && (f[t].n && (u = -m, g += r.yOffset, g += v ? 1 : 0, v = !1), this.applyTextPropertiesToMatrix(r, _, f[t].line, u, g), u += f[t].l || 0, u += m), P) {
                        h = this.globalData.fontManager.getCharData(r.finalText[t], i.fStyle, this.globalData.fontManager.getFontByName(r.f).fFamily);
                        var c;
                        if (h.t === 1) c = new SVGCompElement(h.data, this.globalData, this);
                        else {
                            var b = emptyShapeData;
                            h.data && h.data.shapes && (b = h.data), c = new SVGShapeElement(b, this.globalData, this)
                        }
                        if (this.textSpans[t].glyph) {
                            var A = this.textSpans[t].glyph;
                            this.textSpans[t].childSpan.removeChild(A.layerElement), A.destroy()
                        }
                        this.textSpans[t].glyph = c, c._debug = !0, c.prepareFrame(0), c.renderFrame(), this.textSpans[t].childSpan.appendChild(c.layerElement), this.textSpans[t].childSpan.setAttribute("transform", "scale(" + r.finalSize / 100 + "," + r.finalSize / 100 + ")")
                    } else k && d.setAttribute("transform", "translate(" + _.props[12] + "," + _.props[13] + ")"), d.textContent = f[t].val, d.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve")
                }
                k && d && d.setAttribute("d", E)
            }
            for (; t < this.textSpans.length;) this.textSpans[t].span.style.display = "none", t += 1;
            this._sizeChanged = !0
        }, SVGTextLottieElement.prototype.sourceRectAtTime = function() {
            if (this.prepareFrame(this.comp.renderedFrame - this.data.st), this.renderInnerContent(), this._sizeChanged) {
                this._sizeChanged = !1;
                var t = this.layerElement.getBBox();
                this.bbox = {
                    top: t.y,
                    left: t.x,
                    width: t.width,
                    height: t.height
                }
            }
            return this.bbox
        }, SVGTextLottieElement.prototype.getValue = function() {
            var t, e = this.textSpans.length,
                r;
            for (this.renderedFrame = this.comp.renderedFrame, t = 0; t < e; t += 1) r = this.textSpans[t].glyph, r && (r.prepareFrame(this.comp.renderedFrame - this.data.st), r._mdf && (this._mdf = !0))
        }, SVGTextLottieElement.prototype.renderInnerContent = function() {
            if ((!this.data.singleShape || this._mdf) && (this.textAnimator.getMeasures(this.textProperty.currentData, this.lettersChangedFlag), this.lettersChangedFlag || this.textAnimator.lettersChangedFlag)) {
                this._sizeChanged = !0;
                var t, e, r = this.textAnimator.renderedLetters,
                    i = this.textProperty.currentData.l;
                e = i.length;
                var s, n, f;
                for (t = 0; t < e; t += 1) i[t].n || (s = r[t], n = this.textSpans[t].span, f = this.textSpans[t].glyph, f && f.renderFrame(), s._mdf.m && n.setAttribute("transform", s.m), s._mdf.o && n.setAttribute("opacity", s.o), s._mdf.sw && n.setAttribute("stroke-width", s.sw), s._mdf.sc && n.setAttribute("stroke", s.sc), s._mdf.fc && n.setAttribute("fill", s.fc))
            }
        };

        function ISolidElement(t, e, r) {
            this.initElement(t, e, r)
        }
        extendPrototype([IImageElement], ISolidElement), ISolidElement.prototype.createContent = function() {
            var t = createNS("rect");
            t.setAttribute("width", this.data.sw), t.setAttribute("height", this.data.sh), t.setAttribute("fill", this.data.sc), this.layerElement.appendChild(t)
        };

        function NullElement(t, e, r) {
            this.initFrame(), this.initBaseData(t, e, r), this.initFrame(), this.initTransform(t, e, r), this.initHierarchy()
        }
        NullElement.prototype.prepareFrame = function(t) {
            this.prepareProperties(t, !0)
        }, NullElement.prototype.renderFrame = function() {}, NullElement.prototype.getBaseElement = function() {
            return null
        }, NullElement.prototype.destroy = function() {}, NullElement.prototype.sourceRectAtTime = function() {}, NullElement.prototype.hide = function() {}, extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement], NullElement);

        function SVGRendererBase() {}
        extendPrototype([BaseRenderer], SVGRendererBase), SVGRendererBase.prototype.createNull = function(t) {
            return new NullElement(t, this.globalData, this)
        }, SVGRendererBase.prototype.createShape = function(t) {
            return new SVGShapeElement(t, this.globalData, this)
        }, SVGRendererBase.prototype.createText = function(t) {
            return new SVGTextLottieElement(t, this.globalData, this)
        }, SVGRendererBase.prototype.createImage = function(t) {
            return new IImageElement(t, this.globalData, this)
        }, SVGRendererBase.prototype.createSolid = function(t) {
            return new ISolidElement(t, this.globalData, this)
        }, SVGRendererBase.prototype.configAnimation = function(t) {
            this.svgElement.setAttribute("xmlns", "http://www.w3.org/2000/svg"), this.renderConfig.viewBoxSize ? this.svgElement.setAttribute("viewBox", this.renderConfig.viewBoxSize) : this.svgElement.setAttribute("viewBox", "0 0 " + t.w + " " + t.h), this.renderConfig.viewBoxOnly || (this.svgElement.setAttribute("width", t.w), this.svgElement.setAttribute("height", t.h), this.svgElement.style.width = "100%", this.svgElement.style.height = "100%", this.svgElement.style.transform = "translate3d(0,0,0)", this.svgElement.style.contentVisibility = this.renderConfig.contentVisibility), this.renderConfig.width && this.svgElement.setAttribute("width", this.renderConfig.width), this.renderConfig.height && this.svgElement.setAttribute("height", this.renderConfig.height), this.renderConfig.className && this.svgElement.setAttribute("class", this.renderConfig.className), this.renderConfig.id && this.svgElement.setAttribute("id", this.renderConfig.id), this.renderConfig.focusable !== void 0 && this.svgElement.setAttribute("focusable", this.renderConfig.focusable), this.svgElement.setAttribute("preserveAspectRatio", this.renderConfig.preserveAspectRatio), this.animationItem.wrapper.appendChild(this.svgElement);
            var e = this.globalData.defs;
            this.setupGlobalData(t, e), this.globalData.progressiveLoad = this.renderConfig.progressiveLoad, this.data = t;
            var r = createNS("clipPath"),
                i = createNS("rect");
            i.setAttribute("width", t.w), i.setAttribute("height", t.h), i.setAttribute("x", 0), i.setAttribute("y", 0);
            var s = createElementID();
            r.setAttribute("id", s), r.appendChild(i), this.layerElement.setAttribute("clip-path", "url(" + getLocationHref() + "#" + s + ")"), e.appendChild(r), this.layers = t.layers, this.elements = createSizedArray(t.layers.length)
        }, SVGRendererBase.prototype.destroy = function() {
            this.animationItem.wrapper && (this.animationItem.wrapper.innerText = ""), this.layerElement = null, this.globalData.defs = null;
            var t, e = this.layers ? this.layers.length : 0;
            for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy();
            this.elements.length = 0, this.destroyed = !0, this.animationItem = null
        }, SVGRendererBase.prototype.updateContainerSize = function() {}, SVGRendererBase.prototype.buildItem = function(t) {
            var e = this.elements;
            if (!(e[t] || this.layers[t].ty === 99)) {
                e[t] = !0;
                var r = this.createItem(this.layers[t]);
                e[t] = r, getExpressionsPlugin() && (this.layers[t].ty === 0 && this.globalData.projectInterface.registerComposition(r), r.initExpressions()), this.appendElementInPos(r, t), this.layers[t].tt && (!this.elements[t - 1] || this.elements[t - 1] === !0 ? (this.buildItem(t - 1), this.addPendingElement(r)) : r.setMatte(e[t - 1].layerId))
            }
        }, SVGRendererBase.prototype.checkPendingElements = function() {
            for (; this.pendingElements.length;) {
                var t = this.pendingElements.pop();
                if (t.checkParenting(), t.data.tt)
                    for (var e = 0, r = this.elements.length; e < r;) {
                        if (this.elements[e] === t) {
                            t.setMatte(this.elements[e - 1].layerId);
                            break
                        }
                        e += 1
                    }
            }
        }, SVGRendererBase.prototype.renderFrame = function(t) {
            if (!(this.renderedFrame === t || this.destroyed)) {
                t === null ? t = this.renderedFrame : this.renderedFrame = t, this.globalData.frameNum = t, this.globalData.frameId += 1, this.globalData.projectInterface.currentFrame = t, this.globalData._mdf = !1;
                var e, r = this.layers.length;
                for (this.completeLayers || this.checkLayers(t), e = r - 1; e >= 0; e -= 1)(this.completeLayers || this.elements[e]) && this.elements[e].prepareFrame(t - this.layers[e].st);
                if (this.globalData._mdf)
                    for (e = 0; e < r; e += 1)(this.completeLayers || this.elements[e]) && this.elements[e].renderFrame()
            }
        }, SVGRendererBase.prototype.appendElementInPos = function(t, e) {
            var r = t.getBaseElement();
            if (!!r) {
                for (var i = 0, s; i < e;) this.elements[i] && this.elements[i] !== !0 && this.elements[i].getBaseElement() && (s = this.elements[i].getBaseElement()), i += 1;
                s ? this.layerElement.insertBefore(r, s) : this.layerElement.appendChild(r)
            }
        }, SVGRendererBase.prototype.hide = function() {
            this.layerElement.style.display = "none"
        }, SVGRendererBase.prototype.show = function() {
            this.layerElement.style.display = "block"
        };

        function ICompElement() {}
        extendPrototype([BaseElement, TransformElement, HierarchyElement, FrameElement, RenderableDOMElement], ICompElement), ICompElement.prototype.initElement = function(t, e, r) {
            this.initFrame(), this.initBaseData(t, e, r), this.initTransform(t, e, r), this.initRenderable(), this.initHierarchy(), this.initRendererElement(), this.createContainerElements(), this.createRenderableComponents(), (this.data.xt || !e.progressiveLoad) && this.buildAllItems(), this.hide()
        }, ICompElement.prototype.prepareFrame = function(t) {
            if (this._mdf = !1, this.prepareRenderableFrame(t), this.prepareProperties(t, this.isInRange), !(!this.isInRange && !this.data.xt)) {
                if (this.tm._placeholder) this.renderedFrame = t / this.data.sr;
                else {
                    var e = this.tm.v;
                    e === this.data.op && (e = this.data.op - 1), this.renderedFrame = e
                }
                var r, i = this.elements.length;
                for (this.completeLayers || this.checkLayers(this.renderedFrame), r = i - 1; r >= 0; r -= 1)(this.completeLayers || this.elements[r]) && (this.elements[r].prepareFrame(this.renderedFrame - this.layers[r].st), this.elements[r]._mdf && (this._mdf = !0))
            }
        }, ICompElement.prototype.renderInnerContent = function() {
            var t, e = this.layers.length;
            for (t = 0; t < e; t += 1)(this.completeLayers || this.elements[t]) && this.elements[t].renderFrame()
        }, ICompElement.prototype.setElements = function(t) {
            this.elements = t
        }, ICompElement.prototype.getElements = function() {
            return this.elements
        }, ICompElement.prototype.destroyElements = function() {
            var t, e = this.layers.length;
            for (t = 0; t < e; t += 1) this.elements[t] && this.elements[t].destroy()
        }, ICompElement.prototype.destroy = function() {
            this.destroyElements(), this.destroyBaseElement()
        };

        function SVGCompElement(t, e, r) {
            this.layers = t.layers, this.supports3d = !0, this.completeLayers = !1, this.pendingElements = [], this.elements = this.layers ? createSizedArray(this.layers.length) : [], this.initElement(t, e, r), this.tm = t.tm ? PropertyFactory.getProp(this, t.tm, 0, e.frameRate, this) : {
                _placeholder: !0
            }
        }
        extendPrototype([SVGRendererBase, ICompElement, SVGBaseElement], SVGCompElement), SVGCompElement.prototype.createComp = function(t) {
            return new SVGCompElement(t, this.globalData, this)
        };

        function SVGRenderer(t, e) {
            this.animationItem = t, this.layers = null, this.renderedFrame = -1, this.svgElement = createNS("svg");
            var r = "";
            if (e && e.title) {
                var i = createNS("title"),
                    s = createElementID();
                i.setAttribute("id", s), i.textContent = e.title, this.svgElement.appendChild(i), r += s
            }
            if (e && e.description) {
                var n = createNS("desc"),
                    f = createElementID();
                n.setAttribute("id", f), n.textContent = e.description, this.svgElement.appendChild(n), r += " " + f
            }
            r && this.svgElement.setAttribute("aria-labelledby", r);
            var P = createNS("defs");
            this.svgElement.appendChild(P);
            var d = createNS("g");
            this.svgElement.appendChild(d), this.layerElement = d, this.renderConfig = {
                preserveAspectRatio: e && e.preserveAspectRatio || "xMidYMid meet",
                imagePreserveAspectRatio: e && e.imagePreserveAspectRatio || "xMidYMid slice",
                contentVisibility: e && e.contentVisibility || "visible",
                progressiveLoad: e && e.progressiveLoad || !1,
                hideOnTransparent: !(e && e.hideOnTransparent === !1),
                viewBoxOnly: e && e.viewBoxOnly || !1,
                viewBoxSize: e && e.viewBoxSize || !1,
                className: e && e.className || "",
                id: e && e.id || "",
                focusable: e && e.focusable,
                filterSize: {
                    width: e && e.filterSize && e.filterSize.width || "100%",
                    height: e && e.filterSize && e.filterSize.height || "100%",
                    x: e && e.filterSize && e.filterSize.x || "0%",
                    y: e && e.filterSize && e.filterSize.y || "0%"
                },
                width: e && e.width,
                height: e && e.height
            }, this.globalData = {
                _mdf: !1,
                frameNum: -1,
                defs: P,
                renderConfig: this.renderConfig
            }, this.elements = [], this.pendingElements = [], this.destroyed = !1, this.rendererType = "svg"
        }
        extendPrototype([SVGRendererBase], SVGRenderer), SVGRenderer.prototype.createComp = function(t) {
            return new SVGCompElement(t, this.globalData, this)
        }, registerRenderer("svg", SVGRenderer), ShapeModifiers.registerModifier("tm", TrimModifier), ShapeModifiers.registerModifier("pb", PuckerAndBloatModifier), ShapeModifiers.registerModifier("rp", RepeaterModifier), ShapeModifiers.registerModifier("rd", RoundCornersModifier);
        var Expressions = function() {
            var t = {};
            t.initExpressions = e;

            function e(r) {
                var i = 0,
                    s = [];

                function n() {
                    i += 1
                }

                function f() {
                    i -= 1, i === 0 && d()
                }

                function P(_) {
                    s.indexOf(_) === -1 && s.push(_)
                }

                function d() {
                    var _, E = s.length;
                    for (_ = 0; _ < E; _ += 1) s[_].release();
                    s.length = 0
                }
                r.renderer.compInterface = CompExpressionInterface(r.renderer), r.renderer.globalData.projectInterface.registerComposition(r.renderer), r.renderer.globalData.pushExpression = n, r.renderer.globalData.popExpression = f, r.renderer.globalData.registerExpressionProperty = P
            }
            return t
        }();

        function _typeof$1(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof$1 = function(r) {
                return typeof r
            } : _typeof$1 = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof$1(t)
        }

        function seedRandom(t, e) {
            var r = this,
                i = 256,
                s = 6,
                n = 52,
                f = "random",
                P = e.pow(i, s),
                d = e.pow(2, n),
                _ = d * 2,
                E = i - 1,
                k;

            function u(a, h, p) {
                var c = [];
                h = h === !0 ? {
                    entropy: !0
                } : h || {};
                var b = S(m(h.entropy ? [a, l(t)] : a === null ? o() : a, 3), c),
                    A = new g(c),
                    I = function() {
                        for (var L = A.g(s), w = P, G = 0; L < d;) L = (L + G) * i, w *= i, G = A.g(1);
                        for (; L >= _;) L /= 2, w /= 2, G >>>= 1;
                        return (L + G) / w
                    };
                return I.int32 = function() {
                    return A.g(4) | 0
                }, I.quick = function() {
                    return A.g(4) / 4294967296
                }, I.double = I, S(l(A.S), t), (h.pass || p || function(R, L, w, G) {
                    return G && (G.S && v(G, A), R.state = function() {
                        return v(A, {})
                    }), w ? (e[f] = R, L) : R
                })(I, b, "global" in h ? h.global : this == e, h.state)
            }
            e["seed" + f] = u;

            function g(a) {
                var h, p = a.length,
                    c = this,
                    b = 0,
                    A = c.i = c.j = 0,
                    I = c.S = [];
                for (p || (a = [p++]); b < i;) I[b] = b++;
                for (b = 0; b < i; b++) I[b] = I[A = E & A + a[b % p] + (h = I[b])], I[A] = h;
                c.g = function(R) {
                    for (var L, w = 0, G = c.i, B = c.j, C = c.S; R--;) L = C[G = E & G + 1], w = w * i + C[E & (C[G] = C[B = E & B + L]) + (C[B] = L)];
                    return c.i = G, c.j = B, w
                }
            }

            function v(a, h) {
                return h.i = a.i, h.j = a.j, h.S = a.S.slice(), h
            }

            function m(a, h) {
                var p = [],
                    c = _typeof$1(a),
                    b;
                if (h && c == "object")
                    for (b in a) try {
                        p.push(m(a[b], h - 1))
                    } catch (A) {}
                return p.length ? p : c == "string" ? a : a + "\0"
            }

            function S(a, h) {
                for (var p = a + "", c, b = 0; b < p.length;) h[E & b] = E & (c ^= h[E & b] * 19) + p.charCodeAt(b++);
                return l(h)
            }

            function o() {
                try {
                    var a = new Uint8Array(i);
                    return (r.crypto || r.msCrypto).getRandomValues(a), l(a)
                } catch (c) {
                    var h = r.navigator,
                        p = h && h.plugins;
                    return [+new Date, r, p, r.screen, l(t)]
                }
            }

            function l(a) {
                return String.fromCharCode.apply(0, a)
            }
            S(e.random(), t)
        }

        function initialize$2(t) {
            seedRandom([], t)
        }
        var propTypes = {
            SHAPE: "shape"
        };

        function _typeof(t) {
            return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? _typeof = function(r) {
                return typeof r
            } : _typeof = function(r) {
                return r && typeof Symbol == "function" && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r
            }, _typeof(t)
        }
        var ExpressionManager = function() {
                var ob = {},
                    Math = BMMath,
                    window = null,
                    document = null,
                    XMLHttpRequest = null,
                    fetch = null,
                    frames = null;
                initialize$2(BMMath);

                function $bm_isInstanceOfArray(t) {
                    return t.constructor === Array || t.constructor === Float32Array
                }

                function isNumerable(t, e) {
                    return t === "number" || t === "boolean" || t === "string" || e instanceof Number
                }

                function $bm_neg(t) {
                    var e = _typeof(t);
                    if (e === "number" || e === "boolean" || t instanceof Number) return -t;
                    if ($bm_isInstanceOfArray(t)) {
                        var r, i = t.length,
                            s = [];
                        for (r = 0; r < i; r += 1) s[r] = -t[r];
                        return s
                    }
                    return t.propType ? t.v : -t
                }
                var easeInBez = BezierFactory.getBezierEasing(.333, 0, .833, .833, "easeIn").get,
                    easeOutBez = BezierFactory.getBezierEasing(.167, .167, .667, 1, "easeOut").get,
                    easeInOutBez = BezierFactory.getBezierEasing(.33, 0, .667, 1, "easeInOut").get;

                function sum(t, e) {
                    var r = _typeof(t),
                        i = _typeof(e);
                    if (r === "string" || i === "string" || isNumerable(r, t) && isNumerable(i, e)) return t + e;
                    if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) return t = t.slice(0), t[0] += e, t;
                    if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) return e = e.slice(0), e[0] = t + e[0], e;
                    if ($bm_isInstanceOfArray(t) && $bm_isInstanceOfArray(e)) {
                        for (var s = 0, n = t.length, f = e.length, P = []; s < n || s < f;)(typeof t[s] == "number" || t[s] instanceof Number) && (typeof e[s] == "number" || e[s] instanceof Number) ? P[s] = t[s] + e[s] : P[s] = e[s] === void 0 ? t[s] : t[s] || e[s], s += 1;
                        return P
                    }
                    return 0
                }
                var add = sum;

                function sub(t, e) {
                    var r = _typeof(t),
                        i = _typeof(e);
                    if (isNumerable(r, t) && isNumerable(i, e)) return r === "string" && (t = parseInt(t, 10)), i === "string" && (e = parseInt(e, 10)), t - e;
                    if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) return t = t.slice(0), t[0] -= e, t;
                    if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) return e = e.slice(0), e[0] = t - e[0], e;
                    if ($bm_isInstanceOfArray(t) && $bm_isInstanceOfArray(e)) {
                        for (var s = 0, n = t.length, f = e.length, P = []; s < n || s < f;)(typeof t[s] == "number" || t[s] instanceof Number) && (typeof e[s] == "number" || e[s] instanceof Number) ? P[s] = t[s] - e[s] : P[s] = e[s] === void 0 ? t[s] : t[s] || e[s], s += 1;
                        return P
                    }
                    return 0
                }

                function mul(t, e) {
                    var r = _typeof(t),
                        i = _typeof(e),
                        s;
                    if (isNumerable(r, t) && isNumerable(i, e)) return t * e;
                    var n, f;
                    if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) {
                        for (f = t.length, s = createTypedArray("float32", f), n = 0; n < f; n += 1) s[n] = t[n] * e;
                        return s
                    }
                    if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) {
                        for (f = e.length, s = createTypedArray("float32", f), n = 0; n < f; n += 1) s[n] = t * e[n];
                        return s
                    }
                    return 0
                }

                function div(t, e) {
                    var r = _typeof(t),
                        i = _typeof(e),
                        s;
                    if (isNumerable(r, t) && isNumerable(i, e)) return t / e;
                    var n, f;
                    if ($bm_isInstanceOfArray(t) && isNumerable(i, e)) {
                        for (f = t.length, s = createTypedArray("float32", f), n = 0; n < f; n += 1) s[n] = t[n] / e;
                        return s
                    }
                    if (isNumerable(r, t) && $bm_isInstanceOfArray(e)) {
                        for (f = e.length, s = createTypedArray("float32", f), n = 0; n < f; n += 1) s[n] = t / e[n];
                        return s
                    }
                    return 0
                }

                function mod(t, e) {
                    return typeof t == "string" && (t = parseInt(t, 10)), typeof e == "string" && (e = parseInt(e, 10)), t % e
                }
                var $bm_sum = sum,
                    $bm_sub = sub,
                    $bm_mul = mul,
                    $bm_div = div,
                    $bm_mod = mod;

                function clamp(t, e, r) {
                    if (e > r) {
                        var i = r;
                        r = e, e = i
                    }
                    return Math.min(Math.max(t, e), r)
                }

                function radiansToDegrees(t) {
                    return t / degToRads
                }
                var radians_to_degrees = radiansToDegrees;

                function degreesToRadians(t) {
                    return t * degToRads
                }
                var degrees_to_radians = radiansToDegrees,
                    helperLengthArray = [0, 0, 0, 0, 0, 0];

                function length(t, e) {
                    if (typeof t == "number" || t instanceof Number) return e = e || 0, Math.abs(t - e);
                    e || (e = helperLengthArray);
                    var r, i = Math.min(t.length, e.length),
                        s = 0;
                    for (r = 0; r < i; r += 1) s += Math.pow(e[r] - t[r], 2);
                    return Math.sqrt(s)
                }

                function normalize(t) {
                    return div(t, length(t))
                }

                function rgbToHsl(t) {
                    var e = t[0],
                        r = t[1],
                        i = t[2],
                        s = Math.max(e, r, i),
                        n = Math.min(e, r, i),
                        f, P, d = (s + n) / 2;
                    if (s === n) f = 0, P = 0;
                    else {
                        var _ = s - n;
                        switch (P = d > .5 ? _ / (2 - s - n) : _ / (s + n), s) {
                            case e:
                                f = (r - i) / _ + (r < i ? 6 : 0);
                                break;
                            case r:
                                f = (i - e) / _ + 2;
                                break;
                            case i:
                                f = (e - r) / _ + 4;
                                break
                        }
                        f /= 6
                    }
                    return [f, P, d, t[3]]
                }

                function hue2rgb(t, e, r) {
                    return r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? t + (e - t) * 6 * r : r < 1 / 2 ? e : r < 2 / 3 ? t + (e - t) * (2 / 3 - r) * 6 : t
                }

                function hslToRgb(t) {
                    var e = t[0],
                        r = t[1],
                        i = t[2],
                        s, n, f;
                    if (r === 0) s = i, f = i, n = i;
                    else {
                        var P = i < .5 ? i * (1 + r) : i + r - i * r,
                            d = 2 * i - P;
                        s = hue2rgb(d, P, e + 1 / 3), n = hue2rgb(d, P, e), f = hue2rgb(d, P, e - 1 / 3)
                    }
                    return [s, n, f, t[3]]
                }

                function linear(t, e, r, i, s) {
                    if ((i === void 0 || s === void 0) && (i = e, s = r, e = 0, r = 1), r < e) {
                        var n = r;
                        r = e, e = n
                    }
                    if (t <= e) return i;
                    if (t >= r) return s;
                    var f = r === e ? 0 : (t - e) / (r - e);
                    if (!i.length) return i + (s - i) * f;
                    var P, d = i.length,
                        _ = createTypedArray("float32", d);
                    for (P = 0; P < d; P += 1) _[P] = i[P] + (s[P] - i[P]) * f;
                    return _
                }

                function random(t, e) {
                    if (e === void 0 && (t === void 0 ? (t = 0, e = 1) : (e = t, t = void 0)), e.length) {
                        var r, i = e.length;
                        t || (t = createTypedArray("float32", i));
                        var s = createTypedArray("float32", i),
                            n = BMMath.random();
                        for (r = 0; r < i; r += 1) s[r] = t[r] + n * (e[r] - t[r]);
                        return s
                    }
                    t === void 0 && (t = 0);
                    var f = BMMath.random();
                    return t + f * (e - t)
                }

                function createPath(t, e, r, i) {
                    var s, n = t.length,
                        f = shapePool.newElement();
                    f.setPathData(!!i, n);
                    var P = [0, 0],
                        d, _;
                    for (s = 0; s < n; s += 1) d = e && e[s] ? e[s] : P, _ = r && r[s] ? r[s] : P, f.setTripleAt(t[s][0], t[s][1], _[0] + t[s][0], _[1] + t[s][1], d[0] + t[s][0], d[1] + t[s][1], s, !0);
                    return f
                }

                function initiateExpression(elem, data, property) {
                    var val = data.x,
                        needsVelocity = /velocity(?![\w\d])/.test(val),
                        _needsRandom = val.indexOf("random") !== -1,
                        elemType = elem.data.ty,
                        transform, $bm_transform, content, effect, thisProperty = property;
                    thisProperty.valueAtTime = thisProperty.getValueAtTime, Object.defineProperty(thisProperty, "value", {
                        get: function() {
                            return thisProperty.v
                        }
                    }), elem.comp.frameDuration = 1 / elem.comp.globalData.frameRate, elem.comp.displayStartTime = 0;
                    var inPoint = elem.data.ip / elem.comp.globalData.frameRate,
                        outPoint = elem.data.op / elem.comp.globalData.frameRate,
                        width = elem.data.sw ? elem.data.sw : 0,
                        height = elem.data.sh ? elem.data.sh : 0,
                        name = elem.data.nm,
                        loopIn, loop_in, loopOut, loop_out, smooth, toWorld, fromWorld, fromComp, toComp, fromCompToSurface, position, rotation, anchorPoint, scale, thisLayer, thisComp, mask, valueAtTime, velocityAtTime, scoped_bm_rt, expression_function = eval("[function _expression_function(){" + val + ";scoped_bm_rt=$bm_rt}]")[0],
                        numKeys = property.kf ? data.k.length : 0,
                        active = !this.data || this.data.hd !== !0,
                        wiggle = function t(e, r) {
                            var i, s, n = this.pv.length ? this.pv.length : 1,
                                f = createTypedArray("float32", n);
                            e = 5;
                            var P = Math.floor(time * e);
                            for (i = 0, s = 0; i < P;) {
                                for (s = 0; s < n; s += 1) f[s] += -r + r * 2 * BMMath.random();
                                i += 1
                            }
                            var d = time * e,
                                _ = d - Math.floor(d),
                                E = createTypedArray("float32", n);
                            if (n > 1) {
                                for (s = 0; s < n; s += 1) E[s] = this.pv[s] + f[s] + (-r + r * 2 * BMMath.random()) * _;
                                return E
                            }
                            return this.pv + f[0] + (-r + r * 2 * BMMath.random()) * _
                        }.bind(this);
                    thisProperty.loopIn && (loopIn = thisProperty.loopIn.bind(thisProperty), loop_in = loopIn), thisProperty.loopOut && (loopOut = thisProperty.loopOut.bind(thisProperty), loop_out = loopOut), thisProperty.smooth && (smooth = thisProperty.smooth.bind(thisProperty));

                    function loopInDuration(t, e) {
                        return loopIn(t, e, !0)
                    }

                    function loopOutDuration(t, e) {
                        return loopOut(t, e, !0)
                    }
                    this.getValueAtTime && (valueAtTime = this.getValueAtTime.bind(this)), this.getVelocityAtTime && (velocityAtTime = this.getVelocityAtTime.bind(this));
                    var comp = elem.comp.globalData.projectInterface.bind(elem.comp.globalData.projectInterface);

                    function lookAt(t, e) {
                        var r = [e[0] - t[0], e[1] - t[1], e[2] - t[2]],
                            i = Math.atan2(r[0], Math.sqrt(r[1] * r[1] + r[2] * r[2])) / degToRads,
                            s = -Math.atan2(r[1], r[2]) / degToRads;
                        return [s, i, 0]
                    }

                    function easeOut(t, e, r, i, s) {
                        return applyEase(easeOutBez, t, e, r, i, s)
                    }

                    function easeIn(t, e, r, i, s) {
                        return applyEase(easeInBez, t, e, r, i, s)
                    }

                    function ease(t, e, r, i, s) {
                        return applyEase(easeInOutBez, t, e, r, i, s)
                    }

                    function applyEase(t, e, r, i, s, n) {
                        s === void 0 ? (s = r, n = i) : e = (e - r) / (i - r), e > 1 ? e = 1 : e < 0 && (e = 0);
                        var f = t(e);
                        if ($bm_isInstanceOfArray(s)) {
                            var P, d = s.length,
                                _ = createTypedArray("float32", d);
                            for (P = 0; P < d; P += 1) _[P] = (n[P] - s[P]) * f + s[P];
                            return _
                        }
                        return (n - s) * f + s
                    }

                    function nearestKey(t) {
                        var e, r = data.k.length,
                            i, s;
                        if (!data.k.length || typeof data.k[0] == "number") i = 0, s = 0;
                        else if (i = -1, t *= elem.comp.globalData.frameRate, t < data.k[0].t) i = 1, s = data.k[0].t;
                        else {
                            for (e = 0; e < r - 1; e += 1)
                                if (t === data.k[e].t) {
                                    i = e + 1, s = data.k[e].t;
                                    break
                                } else if (t > data.k[e].t && t < data.k[e + 1].t) {
                                t - data.k[e].t > data.k[e + 1].t - t ? (i = e + 2, s = data.k[e + 1].t) : (i = e + 1, s = data.k[e].t);
                                break
                            }
                            i === -1 && (i = e + 1, s = data.k[e].t)
                        }
                        var n = {};
                        return n.index = i, n.time = s / elem.comp.globalData.frameRate, n
                    }

                    function key(t) {
                        var e, r, i;
                        if (!data.k.length || typeof data.k[0] == "number") throw new Error("The property has no keyframe at index " + t);
                        t -= 1, e = {
                            time: data.k[t].t / elem.comp.globalData.frameRate,
                            value: []
                        };
                        var s = Object.prototype.hasOwnProperty.call(data.k[t], "s") ? data.k[t].s : data.k[t - 1].e;
                        for (i = s.length, r = 0; r < i; r += 1) e[r] = s[r], e.value[r] = s[r];
                        return e
                    }

                    function framesToTime(t, e) {
                        return e || (e = elem.comp.globalData.frameRate), t / e
                    }

                    function timeToFrames(t, e) {
                        return !t && t !== 0 && (t = time), e || (e = elem.comp.globalData.frameRate), t * e
                    }

                    function seedRandom(t) {
                        BMMath.seedrandom(randSeed + t)
                    }

                    function sourceRectAtTime() {
                        return elem.sourceRectAtTime()
                    }

                    function substring(t, e) {
                        return typeof value == "string" ? e === void 0 ? value.substring(t) : value.substring(t, e) : ""
                    }

                    function substr(t, e) {
                        return typeof value == "string" ? e === void 0 ? value.substr(t) : value.substr(t, e) : ""
                    }

                    function posterizeTime(t) {
                        time = t === 0 ? 0 : Math.floor(time * t) / t, value = valueAtTime(time)
                    }
                    var time, velocity, value, text, textIndex, textTotal, selectorValue, index = elem.data.ind,
                        hasParent = !!(elem.hierarchy && elem.hierarchy.length),
                        parent, randSeed = Math.floor(Math.random() * 1e6),
                        globalData = elem.globalData;

                    function executeExpression(t) {
                        return value = t, this.frameExpressionId === elem.globalData.frameId && this.propType !== "textSelector" ? value : (this.propType === "textSelector" && (textIndex = this.textIndex, textTotal = this.textTotal, selectorValue = this.selectorValue), thisLayer || (text = elem.layerInterface.text, thisLayer = elem.layerInterface, thisComp = elem.comp.compInterface, toWorld = thisLayer.toWorld.bind(thisLayer), fromWorld = thisLayer.fromWorld.bind(thisLayer), fromComp = thisLayer.fromComp.bind(thisLayer), toComp = thisLayer.toComp.bind(thisLayer), mask = thisLayer.mask ? thisLayer.mask.bind(thisLayer) : null, fromCompToSurface = fromComp), transform || (transform = elem.layerInterface("ADBE Transform Group"), $bm_transform = transform, transform && (anchorPoint = transform.anchorPoint)), elemType === 4 && !content && (content = thisLayer("ADBE Root Vectors Group")), effect || (effect = thisLayer(4)), hasParent = !!(elem.hierarchy && elem.hierarchy.length), hasParent && !parent && (parent = elem.hierarchy[0].layerInterface), time = this.comp.renderedFrame / this.comp.globalData.frameRate, _needsRandom && seedRandom(randSeed + time), needsVelocity && (velocity = velocityAtTime(time)), expression_function(), this.frameExpressionId = elem.globalData.frameId, scoped_bm_rt = scoped_bm_rt.propType === propTypes.SHAPE ? scoped_bm_rt.v : scoped_bm_rt, scoped_bm_rt)
                    }
                    return executeExpression.__preventDeadCodeRemoval = [$bm_transform, anchorPoint, time, velocity, inPoint, outPoint, width, height, name, loop_in, loop_out, smooth, toComp, fromCompToSurface, toWorld, fromWorld, mask, position, rotation, scale, thisComp, numKeys, active, wiggle, loopInDuration, loopOutDuration, comp, lookAt, easeOut, easeIn, ease, nearestKey, key, text, textIndex, textTotal, selectorValue, framesToTime, timeToFrames, sourceRectAtTime, substring, substr, posterizeTime, index, globalData], executeExpression
                }
                return ob.initiateExpression = initiateExpression, ob.__preventDeadCodeRemoval = [window, document, XMLHttpRequest, fetch, frames, $bm_neg, add, $bm_sum, $bm_sub, $bm_mul, $bm_div, $bm_mod, clamp, radians_to_degrees, degreesToRadians, degrees_to_radians, normalize, rgbToHsl, hslToRgb, linear, random, createPath], ob
            }(),
            expressionHelpers = function() {
                function t(f, P, d) {
                    P.x && (d.k = !0, d.x = !0, d.initiateExpression = ExpressionManager.initiateExpression, d.effectsSequence.push(d.initiateExpression(f, P, d).bind(d)))
                }

                function e(f) {
                    return f *= this.elem.globalData.frameRate, f -= this.offsetTime, f !== this._cachingAtTime.lastFrame && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastFrame < f ? this._cachingAtTime.lastIndex : 0, this._cachingAtTime.value = this.interpolateValue(f, this._cachingAtTime), this._cachingAtTime.lastFrame = f), this._cachingAtTime.value
                }

                function r(f) {
                    var P = -.01,
                        d = this.getValueAtTime(f),
                        _ = this.getValueAtTime(f + P),
                        E = 0;
                    if (d.length) {
                        var k;
                        for (k = 0; k < d.length; k += 1) E += Math.pow(_[k] - d[k], 2);
                        E = Math.sqrt(E) * 100
                    } else E = 0;
                    return E
                }

                function i(f) {
                    if (this.vel !== void 0) return this.vel;
                    var P = -.001,
                        d = this.getValueAtTime(f),
                        _ = this.getValueAtTime(f + P),
                        E;
                    if (d.length) {
                        E = createTypedArray("float32", d.length);
                        var k;
                        for (k = 0; k < d.length; k += 1) E[k] = (_[k] - d[k]) / P
                    } else E = (_ - d) / P;
                    return E
                }

                function s() {
                    return this.pv
                }

                function n(f) {
                    this.propertyGroup = f
                }
                return {
                    searchExpressions: t,
                    getSpeedAtTime: r,
                    getVelocityAtTime: i,
                    getValueAtTime: e,
                    getStaticValueAtTime: s,
                    setGroupProperty: n
                }
            }();

        function addPropertyDecorator() {
            function t(u, g, v) {
                if (!this.k || !this.keyframes) return this.pv;
                u = u ? u.toLowerCase() : "";
                var m = this.comp.renderedFrame,
                    S = this.keyframes,
                    o = S[S.length - 1].t;
                if (m <= o) return this.pv;
                var l, a;
                v ? (g ? l = Math.abs(o - this.elem.comp.globalData.frameRate * g) : l = Math.max(0, o - this.elem.data.ip), a = o - l) : ((!g || g > S.length - 1) && (g = S.length - 1), a = S[S.length - 1 - g].t, l = o - a);
                var h, p, c;
                if (u === "pingpong") {
                    var b = Math.floor((m - a) / l);
                    if (b % 2 !== 0) return this.getValueAtTime((l - (m - a) % l + a) / this.comp.globalData.frameRate, 0)
                } else if (u === "offset") {
                    var A = this.getValueAtTime(a / this.comp.globalData.frameRate, 0),
                        I = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        R = this.getValueAtTime(((m - a) % l + a) / this.comp.globalData.frameRate, 0),
                        L = Math.floor((m - a) / l);
                    if (this.pv.length) {
                        for (c = new Array(A.length), p = c.length, h = 0; h < p; h += 1) c[h] = (I[h] - A[h]) * L + R[h];
                        return c
                    }
                    return (I - A) * L + R
                } else if (u === "continue") {
                    var w = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        G = this.getValueAtTime((o - .001) / this.comp.globalData.frameRate, 0);
                    if (this.pv.length) {
                        for (c = new Array(w.length), p = c.length, h = 0; h < p; h += 1) c[h] = w[h] + (w[h] - G[h]) * ((m - o) / this.comp.globalData.frameRate) / 5e-4;
                        return c
                    }
                    return w + (w - G) * ((m - o) / .001)
                }
                return this.getValueAtTime(((m - a) % l + a) / this.comp.globalData.frameRate, 0)
            }

            function e(u, g, v) {
                if (!this.k) return this.pv;
                u = u ? u.toLowerCase() : "";
                var m = this.comp.renderedFrame,
                    S = this.keyframes,
                    o = S[0].t;
                if (m >= o) return this.pv;
                var l, a;
                v ? (g ? l = Math.abs(this.elem.comp.globalData.frameRate * g) : l = Math.max(0, this.elem.data.op - o), a = o + l) : ((!g || g > S.length - 1) && (g = S.length - 1), a = S[g].t, l = a - o);
                var h, p, c;
                if (u === "pingpong") {
                    var b = Math.floor((o - m) / l);
                    if (b % 2 === 0) return this.getValueAtTime(((o - m) % l + o) / this.comp.globalData.frameRate, 0)
                } else if (u === "offset") {
                    var A = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        I = this.getValueAtTime(a / this.comp.globalData.frameRate, 0),
                        R = this.getValueAtTime((l - (o - m) % l + o) / this.comp.globalData.frameRate, 0),
                        L = Math.floor((o - m) / l) + 1;
                    if (this.pv.length) {
                        for (c = new Array(A.length), p = c.length, h = 0; h < p; h += 1) c[h] = R[h] - (I[h] - A[h]) * L;
                        return c
                    }
                    return R - (I - A) * L
                } else if (u === "continue") {
                    var w = this.getValueAtTime(o / this.comp.globalData.frameRate, 0),
                        G = this.getValueAtTime((o + .001) / this.comp.globalData.frameRate, 0);
                    if (this.pv.length) {
                        for (c = new Array(w.length), p = c.length, h = 0; h < p; h += 1) c[h] = w[h] + (w[h] - G[h]) * (o - m) / .001;
                        return c
                    }
                    return w + (w - G) * (o - m) / .001
                }
                return this.getValueAtTime((l - ((o - m) % l + o)) / this.comp.globalData.frameRate, 0)
            }

            function r(u, g) {
                if (!this.k) return this.pv;
                if (u = (u || .4) * .5, g = Math.floor(g || 5), g <= 1) return this.pv;
                var v = this.comp.renderedFrame / this.comp.globalData.frameRate,
                    m = v - u,
                    S = v + u,
                    o = g > 1 ? (S - m) / (g - 1) : 1,
                    l = 0,
                    a = 0,
                    h;
                this.pv.length ? h = createTypedArray("float32", this.pv.length) : h = 0;
                for (var p; l < g;) {
                    if (p = this.getValueAtTime(m + l * o), this.pv.length)
                        for (a = 0; a < this.pv.length; a += 1) h[a] += p[a];
                    else h += p;
                    l += 1
                }
                if (this.pv.length)
                    for (a = 0; a < this.pv.length; a += 1) h[a] /= g;
                else h /= g;
                return h
            }

            function i(u) {
                this._transformCachingAtTime || (this._transformCachingAtTime = {
                    v: new Matrix
                });
                var g = this._transformCachingAtTime.v;
                if (g.cloneFromProps(this.pre.props), this.appliedTransformations < 1) {
                    var v = this.a.getValueAtTime(u);
                    g.translate(-v[0] * this.a.mult, -v[1] * this.a.mult, v[2] * this.a.mult)
                }
                if (this.appliedTransformations < 2) {
                    var m = this.s.getValueAtTime(u);
                    g.scale(m[0] * this.s.mult, m[1] * this.s.mult, m[2] * this.s.mult)
                }
                if (this.sk && this.appliedTransformations < 3) {
                    var S = this.sk.getValueAtTime(u),
                        o = this.sa.getValueAtTime(u);
                    g.skewFromAxis(-S * this.sk.mult, o * this.sa.mult)
                }
                if (this.r && this.appliedTransformations < 4) {
                    var l = this.r.getValueAtTime(u);
                    g.rotate(-l * this.r.mult)
                } else if (!this.r && this.appliedTransformations < 4) {
                    var a = this.rz.getValueAtTime(u),
                        h = this.ry.getValueAtTime(u),
                        p = this.rx.getValueAtTime(u),
                        c = this.or.getValueAtTime(u);
                    g.rotateZ(-a * this.rz.mult).rotateY(h * this.ry.mult).rotateX(p * this.rx.mult).rotateZ(-c[2] * this.or.mult).rotateY(c[1] * this.or.mult).rotateX(c[0] * this.or.mult)
                }
                if (this.data.p && this.data.p.s) {
                    var b = this.px.getValueAtTime(u),
                        A = this.py.getValueAtTime(u);
                    if (this.data.p.z) {
                        var I = this.pz.getValueAtTime(u);
                        g.translate(b * this.px.mult, A * this.py.mult, -I * this.pz.mult)
                    } else g.translate(b * this.px.mult, A * this.py.mult, 0)
                } else {
                    var R = this.p.getValueAtTime(u);
                    g.translate(R[0] * this.p.mult, R[1] * this.p.mult, -R[2] * this.p.mult)
                }
                return g
            }

            function s() {
                return this.v.clone(new Matrix)
            }
            var n = TransformPropertyFactory.getTransformProperty;
            TransformPropertyFactory.getTransformProperty = function(u, g, v) {
                var m = n(u, g, v);
                return m.dynamicProperties.length ? m.getValueAtTime = i.bind(m) : m.getValueAtTime = s.bind(m), m.setGroupProperty = expressionHelpers.setGroupProperty, m
            };
            var f = PropertyFactory.getProp;
            PropertyFactory.getProp = function(u, g, v, m, S) {
                var o = f(u, g, v, m, S);
                o.kf ? o.getValueAtTime = expressionHelpers.getValueAtTime.bind(o) : o.getValueAtTime = expressionHelpers.getStaticValueAtTime.bind(o), o.setGroupProperty = expressionHelpers.setGroupProperty, o.loopOut = t, o.loopIn = e, o.smooth = r, o.getVelocityAtTime = expressionHelpers.getVelocityAtTime.bind(o), o.getSpeedAtTime = expressionHelpers.getSpeedAtTime.bind(o), o.numKeys = g.a === 1 ? g.k.length : 0, o.propertyIndex = g.ix;
                var l = 0;
                return v !== 0 && (l = createTypedArray("float32", g.a === 1 ? g.k[0].s.length : g.k.length)), o._cachingAtTime = {
                    lastFrame: initialDefaultFrame,
                    lastIndex: 0,
                    value: l
                }, expressionHelpers.searchExpressions(u, g, o), o.k && S.addDynamicProperty(o), o
            };

            function P(u) {
                return this._cachingAtTime || (this._cachingAtTime = {
                    shapeValue: shapePool.clone(this.pv),
                    lastIndex: 0,
                    lastTime: initialDefaultFrame
                }), u *= this.elem.globalData.frameRate, u -= this.offsetTime, u !== this._cachingAtTime.lastTime && (this._cachingAtTime.lastIndex = this._cachingAtTime.lastTime < u ? this._caching.lastIndex : 0, this._cachingAtTime.lastTime = u, this.interpolateShape(u, this._cachingAtTime.shapeValue, this._cachingAtTime)), this._cachingAtTime.shapeValue
            }
            var d = ShapePropertyFactory.getConstructorFunction(),
                _ = ShapePropertyFactory.getKeyframedConstructorFunction();

            function E() {}
            E.prototype = {
                vertices: function(g, v) {
                    this.k && this.getValue();
                    var m = this.v;
                    v !== void 0 && (m = this.getValueAtTime(v, 0));
                    var S, o = m._length,
                        l = m[g],
                        a = m.v,
                        h = createSizedArray(o);
                    for (S = 0; S < o; S += 1) g === "i" || g === "o" ? h[S] = [l[S][0] - a[S][0], l[S][1] - a[S][1]] : h[S] = [l[S][0], l[S][1]];
                    return h
                },
                points: function(g) {
                    return this.vertices("v", g)
                },
                inTangents: function(g) {
                    return this.vertices("i", g)
                },
                outTangents: function(g) {
                    return this.vertices("o", g)
                },
                isClosed: function() {
                    return this.v.c
                },
                pointOnPath: function(g, v) {
                    var m = this.v;
                    v !== void 0 && (m = this.getValueAtTime(v, 0)), this._segmentsLength || (this._segmentsLength = bez.getSegmentsLength(m));
                    for (var S = this._segmentsLength, o = S.lengths, l = S.totalLength * g, a = 0, h = o.length, p = 0, c; a < h;) {
                        if (p + o[a].addedLength > l) {
                            var b = a,
                                A = m.c && a === h - 1 ? 0 : a + 1,
                                I = (l - p) / o[a].addedLength;
                            c = bez.getPointInSegment(m.v[b], m.v[A], m.o[b], m.i[A], I, o[a]);
                            break
                        } else p += o[a].addedLength;
                        a += 1
                    }
                    return c || (c = m.c ? [m.v[0][0], m.v[0][1]] : [m.v[m._length - 1][0], m.v[m._length - 1][1]]), c
                },
                vectorOnPath: function(g, v, m) {
                    g == 1 ? g = this.v.c : g == 0 && (g = .999);
                    var S = this.pointOnPath(g, v),
                        o = this.pointOnPath(g + .001, v),
                        l = o[0] - S[0],
                        a = o[1] - S[1],
                        h = Math.sqrt(Math.pow(l, 2) + Math.pow(a, 2));
                    if (h === 0) return [0, 0];
                    var p = m === "tangent" ? [l / h, a / h] : [-a / h, l / h];
                    return p
                },
                tangentOnPath: function(g, v) {
                    return this.vectorOnPath(g, v, "tangent")
                },
                normalOnPath: function(g, v) {
                    return this.vectorOnPath(g, v, "normal")
                },
                setGroupProperty: expressionHelpers.setGroupProperty,
                getValueAtTime: expressionHelpers.getStaticValueAtTime
            }, extendPrototype([E], d), extendPrototype([E], _), _.prototype.getValueAtTime = P, _.prototype.initiateExpression = ExpressionManager.initiateExpression;
            var k = ShapePropertyFactory.getShapeProp;
            ShapePropertyFactory.getShapeProp = function(u, g, v, m, S) {
                var o = k(u, g, v, m, S);
                return o.propertyIndex = g.ix, o.lock = !1, v === 3 ? expressionHelpers.searchExpressions(u, g.pt, o) : v === 4 && expressionHelpers.searchExpressions(u, g.ks, o), o.k && u.addDynamicProperty(o), o
            }
        }

        function initialize$1() {
            addPropertyDecorator()
        }

        function addDecorator() {
            function t() {
                return this.data.d.x ? (this.calculateExpression = ExpressionManager.initiateExpression.bind(this)(this.elem, this.data.d, this), this.addEffect(this.getExpressionValue.bind(this)), !0) : null
            }
            TextProperty.prototype.getExpressionValue = function(e, r) {
                var i = this.calculateExpression(r);
                if (e.t !== i) {
                    var s = {};
                    return this.copyData(s, e), s.t = i.toString(), s.__complete = !1, s
                }
                return e
            }, TextProperty.prototype.searchProperty = function() {
                var e = this.searchKeyframes(),
                    r = this.searchExpressions();
                return this.kf = e || r, this.kf
            }, TextProperty.prototype.searchExpressions = t
        }

        function initialize() {
            addDecorator()
        }
        return setExpressionsPlugin(Expressions), initialize$1(), initialize(), registerEffect(20, SVGTintFilter, !0), registerEffect(21, SVGFillFilter, !0), registerEffect(22, SVGStrokeEffect, !1), registerEffect(23, SVGTritoneFilter, !0), registerEffect(24, SVGProLevelsFilter, !0), registerEffect(25, SVGDropShadowEffect, !0), registerEffect(28, SVGMatte3Effect, !1), registerEffect(29, SVGGaussianBlurEffect, !0), lottie
    })
})(lottie_svg$2, lottie_svg$2.exports);
var lottie_svg = lottie_svg$2.exports,
    lottie_svg$1 = _mergeNamespaces({
        __proto__: null,
        default: lottie_svg
    }, [lottie_svg$2.exports]);
export {
    lottie_svg$1 as l
};
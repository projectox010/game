! function() {
    var e = document.createElement("style");
    e.innerHTML = '.nnhmmbc{--pwaeyx:#ffffff;--whdmoy:#31373d;--7gi6dg:#aeb3c2;height:4rem;position:relative;z-index:1;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;padding:0;background:var(--pwaeyx)}.darken .nnhmmbc{--pwaeyx:#1e2024;--whdmoy:#f5f6f7;--7gi6dg:#555b65}.nnhmmbc .title{color:var(--whdmoy);font-size:1rem;padding-left:1.25rem}.nnhmmbc .close-icon{width:2rem;height:2rem;margin-right:.625rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;cursor:pointer}.nnhmmbc .close-icon>svg{font-size:.625rem;-webkit-transition:-webkit-transform .5s cubic-bezier(.36,.66,.04,1);-webkit-transition:transform .5s cubic-bezier(.36,.66,.04,1);transition:transform .5s cubic-bezier(.36,.66,.04,1);fill:var(--7gi6dg)}.nnhmmbc .close-icon:hover>svg{-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg);fill:var(--primary-color)}@media screen and (max-width:621px){.nnhmmbc{position:fixed;top:0;left:0;right:0;z-index:11}}.sswsdjr{--j0tnut:rgba(233,234,242,.6);--17ynnc2:rgba(192,196,208,.3);--whdmoy:#31373d;--vpkcea:#5f6975;--tt26x0:rgba(95,105,117,.8);--loyv51:url(/assets/hand-w.391870da.svg);--1r8kt4k:#ffffff;--1uvkmwv:#5f6975;width:100%;background:var(--j0tnut);border-radius:1.25rem;padding:1.25rem 0;position:relative;margin-bottom:.5rem;word-break:break-word}.darken .sswsdjr{--j0tnut:rgba(45,48,53,.6);--17ynnc2:rgba(85,91,101,.2);--whdmoy:#f5f6f7;--vpkcea:rgba(153,164,176,.6);--tt26x0:rgba(153,164,176,.8);--loyv51:url(/assets/hand.1053c278.svg);--1r8kt4k:rgba(30,32,36,.7);--1uvkmwv:#f5f6f7}.sswsdjr.unread:after{content:"";width:.75rem;height:.75rem;border-radius:50%;background:var(--primary-color);position:absolute;top:.75rem;right:.5625rem}.sswsdjr .item-head{padding:0 .875rem;border-bottom:1px solid var(--17ynnc2)}.sswsdjr .item-head .title{font-size:1rem;color:var(--whdmoy);line-height:1.25;font-weight:600}.sswsdjr .item-head .base{color:var(--vpkcea);-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;padding:1rem 0 .625rem}.sswsdjr .item-head .avatar{width:1.625rem;height:1.625rem;margin-right:.375rem}.sswsdjr .item-head .user-name{font-size:.875rem}.sswsdjr .item-head .time{font-size:.75rem}.sswsdjr .item-content{font-size:.875rem;color:var(--tt26x0);padding:0 .875rem}.sswsdjr .item-content .welcome{font-weight:600;padding:1.25rem 2.1875rem;color:var(--whdmoy);background:var(--loyv51) no-repeat left center/ 1.6875rem 2.1875rem}.sswsdjr .item-content .p{margin:0 0 .875rem;white-space:pre-wrap}.sswsdjr .item-content .link-box{background:var(--1r8kt4k);border-radius:.625rem;padding:.625rem}.sswsdjr .item-content .link-box .tip{font-size:.875rem;color:var(--1uvkmwv)}.sswsdjr .item-content .hover{font-size:.75rem;color:var(--primary-color)}.sswsdjr .item-content .finger{padding-right:1.5rem;background:url(/assets/finger.1b642f84.svg) no-repeat right center/ .9375rem auto}.sswsdjr .item-content .image{width:100%;border-radius:.625rem}.rqldstm{--pwaeyx:#ffffff;--1vxeu33:rgba(0,0,0,.1);--7gi6dg:#aeb3c2;--1odrg3o:#6a6e73;position:absolute;left:0;right:0;top:0;bottom:0;height:2.5rem;background:var(--pwaeyx);box-shadow:0 2px 6px var(--1vxeu33);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:end;-webkit-justify-content:flex-end;-ms-flex-pack:end;justify-content:flex-end;padding-right:1.25rem;z-index:5}.darken .rqldstm{--pwaeyx:#1e2024;--1vxeu33:rgba(0,0,0,.19);--7gi6dg:#555b65;--1odrg3o:#d8d8d8}.rqldstm .icon{width:1rem;height:1rem;fill:var(--7gi6dg);cursor:pointer}.rqldstm .icon.active{fill:var(--1odrg3o)}.rqldstm .icon:last-child{margin-left:1.875rem}.r1wg44be{--7h9g04:#f5f6fa;--whdmoy:#31373d;--1uvkmwv:#5f6975;--1qjpy7t:#5f6975;--17ynnc2:rgba(192,196,208,.3);border-radius:1.25rem;background-color:var(--7h9g04);background-repeat:no-repeat;background-size:100% auto;background-position:left top;padding:1.5rem .875rem 0;margin-bottom:.625rem;position:relative}.darken .r1wg44be{--7h9g04:#17181b;--whdmoy:#f5f6f7;--1uvkmwv:#f5f6f7;--1qjpy7t:#ffffff;--17ynnc2:rgba(85,91,101,.2)}.r1wg44be .go-to-link{margin-top:.875rem}.r1wg44be .go-to-link:hover{-webkit-text-decoration:underline;text-decoration:underline}.r1wg44be .go-to-link a{font-size:.875rem;font-weight:400;color:var(--primary-color)}.r1wg44be .go-to-link .icon{font-size:.5625rem;margin-left:.1875rem;fill:var(--primary-color);margin-top:.125rem}.r1wg44be .tag-box{position:absolute;top:-.125rem;right:-.125rem;width:4.25rem;height:4.25rem;z-index:2;background:url(/assets/tag.5c01fd72.svg) no-repeat right top/auto 100%;color:#fff;font-size:.875rem;font-weight:600}.r1wg44be .tag-box .tag{text-transform:uppercase;width:140%;text-align:center;-webkit-transform:rotateZ(45deg) translateY(-1.375rem);-ms-transform:rotateZ(45deg) translateY(-1.375rem);transform:rotate(45deg) translateY(-1.375rem);-webkit-transform-origin:left top;-ms-transform-origin:left top;transform-origin:left top}.r1wg44be .title{font-size:1rem;font-weight:600;max-width:16.25rem;white-space:pre-wrap;color:var(--whdmoy);word-break:break-word;line-height:1.375rem}.r1wg44be .coin .coin-icon{width:1.5rem;height:1.5rem;margin-right:.5rem}.r1wg44be .coin .amount{color:var(--primary-color)}.r1wg44be .coin .name{color:var(--1uvkmwv)}.r1wg44be .claimed{color:var(--1qjpy7t);position:relative;padding-left:1.25rem;font-size:.875rem}.r1wg44be .claimed:before{content:"";position:absolute;top:.25rem;left:0;width:.875rem;height:.625rem;border-left:.1875rem solid var(--primary-color);border-bottom:.1875rem solid var(--primary-color);-webkit-transform:rotateZ(-45deg);-ms-transform:rotateZ(-45deg);transform:rotate(-45deg)}.r1wg44be .from{height:2.8125rem;color:#5f6975;position:relative}.r1wg44be .from:before{content:"";position:absolute;top:0;left:-.875rem;right:-.875rem;height:1px;background:var(--17ynnc2)}.r1wg44be .from .avatar{width:1.625rem;height:1.625rem;border-radius:50%;margin-right:.375rem}.r1wg44be .from .origin{font-size:.875rem;-webkit-flex:1;-ms-flex:1;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:.25rem}.r1wg44be .from .time{font-size:.75rem;color:rgba(95,105,117,.6);white-space:nowrap}.sas4pnf{--1kkbz59:#e9eaf2}.darken .sas4pnf{--1kkbz59:rgba(44,47,54,.4)}.sas4pnf.disabled{opacity:.7}.sas4pnf .go-to-link{margin-top:.125rem;height:1.125rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;width:100%}.sas4pnf .go-to-link:hover{-webkit-text-decoration:underline;text-decoration:underline}.sas4pnf .go-to-link a{font-size:.875rem;height:1.125rem;line-height:1.125rem;font-weight:400;color:var(--primary-color)}.sas4pnf .go-to-link .icon{font-size:.5625rem;margin-left:.1875rem;fill:var(--primary-color);margin-top:.125rem}.sas4pnf .status{min-height:4.25rem;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;padding:.875rem 0 1rem;font-weight:600;font-size:1rem}.sas4pnf .status .claim{width:auto;min-width:5rem;height:2.25rem;font-size:.875rem}.sas4pnf .rewards-wrap{position:relative}.sas4pnf .rewards-wrap.multiple{background:var(--1kkbz59);border-radius:1.125rem;padding:.75rem .625rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;margin-left:-.625rem}.sas4pnf .rewards-wrap .coin{margin-bottom:.625rem}.sas4pnf .rewards-wrap .coin:last-child{margin-bottom:0}.sas4pnf .rewards-wrap .effect-box{position:absolute;left:2.75rem;color:var(--primary-color);opacity:0}.sas4pnf .rewards-wrap .effect-box.effect{-webkit-animation:zoomOut-sas4pnf ease-out 1s;animation:zoomOut-sas4pnf ease-out 1s}@-webkit-keyframes zoomOut-sas4pnf{0%{-webkit-transform:scale(1) translateY(0);-ms-transform:scale(1) translateY(0);transform:scale(1) translateY(0);opacity:1}70%{opacity:1}to{-webkit-transform:scale(1.35) translateY(-50px);-ms-transform:scale(1.35) translateY(-50px);transform:scale(1.35) translateY(-50px);opacity:0}}@keyframes zoomOut-sas4pnf{0%{-webkit-transform:scale(1) translateY(0);-ms-transform:scale(1) translateY(0);transform:scale(1) translateY(0);opacity:1}70%{opacity:1}to{-webkit-transform:scale(1.35) translateY(-50px);-ms-transform:scale(1.35) translateY(-50px);transform:scale(1.35) translateY(-50px);opacity:0}}.f1fz82zo{--1wu1ftf:#e9eaf2}.darken .f1fz82zo{--1wu1ftf:#2c2f36}.f1fz82zo.disabled{opacity:.7}.f1fz82zo .flower{position:absolute;width:11.875rem;height:9.375rem;top:0;right:-1.25rem;z-index:1;background:url(/assets/flower.b78eecee.png) no-repeat center/ cover}.f1fz82zo .small-bg{position:absolute;width:9.375rem;height:9.375rem;top:0;right:0;z-index:2;background-repeat:no-repeat;background-position:right top;background-size:auto 100%}.f1fz82zo .title{max-width:12.5rem}.f1fz82zo .desc{font-size:.75rem;color:#5f6975;white-space:pre-wrap;word-break:break-word;max-width:11.25rem;line-height:normal;min-height:5.9375rem;padding:.625rem 0 2.1875rem}.f1fz82zo .main-box{position:relative;z-index:3;border-radius:1.25rem;background:var(--1wu1ftf);margin:0 -.875rem;padding:0 .875rem}.f1fz82zo .main-box .status{padding:1.375rem 0;font-weight:600;font-size:1rem}.f1fz82zo .main-box .coin-wrap{padding:1.375rem 0;background:url(/assets/coin-bg.b80f86d1.png) no-repeat center 0px / auto 0%}.f1fz82zo .main-box .coin-wrap .amount-str{width:auto}.f1fz82zo .main-box .coin-wrap.effect{-webkit-animation:identifier-f1fz82zo linear 1.1s;animation:identifier-f1fz82zo linear 1.1s}@-webkit-keyframes identifier-f1fz82zo{0%{background-size:auto 0%;background-position:center}50%{background-size:auto 40px;background-position:center -2px}55%{background-size:auto 45px;background-position:center -3px}65%{background-size:auto 50px;background-position:center 0}70%{background-size:auto 52px;background-position:center 2px}to{background-size:auto 60px;background-position:center 46px}}@keyframes identifier-f1fz82zo{0%{background-size:auto 0%;background-position:center}50%{background-size:auto 40px;background-position:center -2px}55%{background-size:auto 45px;background-position:center -3px}65%{background-size:auto 50px;background-position:center 0}70%{background-size:auto 52px;background-position:center 2px}to{background-size:auto 60px;background-position:center 46px}}.f1fz82zo .main-box .claim{height:2.75rem;width:auto;min-width:9.75rem;margin:0 auto}.f1fz82zo .main-box .claimed{padding-left:1.625rem}.f1fz82zo .rewards-wrap{width:15.625rem;margin:0 auto;border-radius:1.25rem;background-color:var(--1wu1ftf);padding:.875rem 0 .875rem 2rem}.f1fz82zo .rewards-wrap.single{border-radius:1.375rem;padding:0;height:2.75rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.f1fz82zo .rewards-wrap .coin{margin-bottom:.625rem}.f1fz82zo .rewards-wrap .coin:last-child{margin-bottom:0}.n1p5zyw1{padding-top:2.875rem;height:100%}.n1p5zyw1 .reward-container{padding-right:.125rem;margin-right:-.125rem;padding-top:.125rem;margin-top:-.125rem;padding-bottom:1.5rem;overflow:hidden;position:relative;z-index:2}.nz2bv4i{--pwaeyx:#ffffff;--14tbr77:linear-gradient(to bottom,#a5aeb8,rgba(197,203,213,0));--qf1vno:.15;--1qobehr:rgba(192,196,208,.6);--whdmoy:#31373d;--7gi6dg:#aeb3c2;-webkit-flex:1;-ms-flex:1;flex:1;background:var(--pwaeyx);overflow:hidden;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column}.darken .nz2bv4i{--pwaeyx:#1e2024;--14tbr77:linear-gradient(to bottom,#111415,rgba(17,20,21,0));--qf1vno:.44;--1qobehr:rgba(49,56,61,.6);--whdmoy:#f5f6f7;--7gi6dg:#555b65}.nz2bv4i .notice-tabs{height:3.4375rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;background-color:var(--pwaeyx);position:relative}.nz2bv4i .notice-tabs:before{content:"";position:absolute;top:0;left:0;right:0;height:.75rem;background-image:var(--14tbr77);opacity:var(--qf1vno)}.nz2bv4i .notice-tabs:after{content:"";position:absolute;bottom:0;left:0;right:0;height:1px;background:var(--1qobehr);z-index:11}.nz2bv4i .notice-tabs .tab{-webkit-flex:1;-ms-flex:1;flex:1;font-size:.875rem;color:rgba(95,105,117,.6);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;height:100%}.nz2bv4i .notice-tabs .tab.is-active{position:relative;color:var(--whdmoy);font-weight:600;background-image:linear-gradient(to top,rgba(91,174,28,.15),rgba(91,174,28,0) 60%)}.nz2bv4i .notice-tabs .tab.is-active:after{content:"";position:absolute;left:0;right:0;bottom:0;height:.125rem;background-color:var(--primary-color);z-index:12}.nz2bv4i .notice-tabs .tab .icon{width:1rem;height:1rem;margin-right:.375rem;fill:var(--7gi6dg)}.nz2bv4i .notice-tabs .tab .reward{width:1rem;height:1rem;margin-right:.375rem;background:url(/assets/gift.1d6007eb.svg) no-repeat center/auto 100%}.nz2bv4i .notice-tabs .label{position:relative}.nz2bv4i .notice-tabs .label .badge{font-weight:400;right:-.5rem}.nz2bv4i .scroll-wrap{overflow:hidden;-webkit-flex:1;-ms-flex:1;flex:1;position:relative}.nz2bv4i .notice-container{padding:.625rem}.nhencm8{width:100%;max-width:414px;height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;position:relative}\n', document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js"], (function(e) {
        "use strict";
        var t, r, a, i, n, o, s, c, l, d, m, f, b, g, p, u, w, h, x, v, k, y, z, N;
        return {
            setters: [function(e) {
                t = e.e, r = e.r, a = e.o, i = e.u, n = e.j, o = e.a, s = e.A, c = e.cC, l = e.dA, d = e.l, m = e.d, f = e.cQ, b = e.F, g = e.a4, p = e.t, u = e.q, w = e.s, h = e.al, x = e.v, v = e.M, k = e.b, y = e.cW, z = e.ck, N = e.S
            }],
            execute: function() {
                const j = /^\//;
                const I = a((function({
                        onClose: e
                    }) {
                        const t = i();
                        return n("div", {
                            className: C,
                            children: [o("div", {
                                className: "title",
                                children: t("page.notice.title")
                            }), o("div", {
                                className: "close-icon",
                                onClick: () => e(),
                                children: o(s, {
                                    name: "Close"
                                })
                            })]
                        })
                    })),
                    C = "nnhmmbc";
                var T = {
                    avatar: c.logo4,
                    avatarw: c.logo4_w,
                    hand: "/assets/hand.1053c278.svg",
                    handWhite: "/assets/hand-w.391870da.svg",
                    finger: "/assets/finger.1b642f84.svg",
                    flower: "/assets/flower.b78eecee.png",
                    coinBg: "/assets/coin-bg.b80f86d1.png",
                    tag: "/assets/tag.5c01fd72.svg",
                    gift: "/assets/gift.1d6007eb.svg"
                };

                function q(e) {
                    const t = new Date(e),
                        r = t.getFullYear();
                    let a = t.getMonth() + 1,
                        i = t.getDate(),
                        n = t.getHours(),
                        o = t.getMinutes(),
                        s = t.getSeconds(),
                        c = n >= 12 ? "PM" : "AM";
                    return n %= 12, n = n || 12, a = a < 10 ? `0${a}` : a, i = i < 10 ? `0${i}` : i, n = n < 10 ? `0${n}` : n, o = o < 10 ? `0${o}` : o, s = s < 10 ? `0${s}` : s, `${a}/${i}/${r} ${n}:${o}:${s} ${c}`
                }

                function Y(e) {
                    let t = [];
                    return e ? (e.split(/<\s?br\s?\/?\s?>/).map(((e, r) => {
                        r >= 1 && t.push(o("br", {}, r)), t.push(e)
                    })), t) : e
                }

                function $(e) {
                    return 1 === e.version ? o("div", {
                        className: "old",
                        dangerouslySetInnerHTML: {
                            __html: e.contentV1
                        }
                    }) : e.contentV2.map(((e, t) => {
                        switch (e.contentType) {
                            case 1:
                                return o("p", {
                                    className: "p",
                                    children: Y(e.content)
                                }, t);
                            case 2:
                                return n("div", {
                                    className: "p link-box",
                                    children: [o("div", {
                                        className: "flex",
                                        children: o("div", {
                                            className: "tip",
                                            children: o("span", {
                                                className: "finger",
                                                children: "Click here"
                                            })
                                        })
                                    }), o("div", {
                                        children: o("a", {
                                            className: "hover",
                                            href: e.content,
                                            children: e.desc
                                        })
                                    })]
                                }, t);
                            case 3:
                                return o("img", {
                                    src: e.content,
                                    alt: e.desc,
                                    className: "image p"
                                }, t);
                            default:
                                return null
                        }
                    }))
                }
                const E = a((function({
                        className: e = "",
                        data: t
                    }) {
                        const r = l();
                        return n("div", {
                            className: d(S, e),
                            children: [n("div", {
                                className: "item-head",
                                children: [o("div", {
                                    className: "title",
                                    children: t.title
                                }), n("div", {
                                    className: "base flex-center",
                                    children: [n("div", {
                                        className: "user flex-center",
                                        children: [o("img", {
                                            src: r ? T.avatar : T.avatarw,
                                            className: "avatar"
                                        }), o("div", {
                                            className: "user-name",
                                            children: "BC.GAME Official"
                                        })]
                                    }), o("div", {
                                        className: "time",
                                        children: q(t.createTime)
                                    })]
                                })]
                            }), n("div", {
                                className: "item-content",
                                children: [n("div", {
                                    className: "welcome",
                                    children: ["Hi ", m.name]
                                }), $(t)]
                            })]
                        })
                    })),
                    M = a((function() {
                        var e;
                        const t = f.systemData;
                        return null != t && null !== (e = t.afficheList) && void 0 !== e && e.length ? o(b, {
                            children: t.afficheList.map((e => o(E, {
                                data: e,
                                className: t.currentAfficheId < e.afficheId ? "unread" : ""
                            }, e.afficheId)))
                        }) : o(g, {})
                    }));
                p({
                    cl1: [u("#2d3035", .6), u("#e9eaf2", .6)],
                    cl2: [u("#555b65", .2), u("#c0c4d0", .3)],
                    cl3: ["#f5f6f7", "#31373d"],
                    cl4: [u("#99a4b0", .6), "#5f6975"],
                    cl5: [u("#99a4b0", .8), u("#5f6975", .8)],
                    cl6: ['url("../assets/hand.svg")', 'url("../assets/hand-w.svg")'],
                    cl7: [u("#1e2024", .7), "#ffffff"],
                    cl8: ["#f5f6f7", "#5f6975"]
                });
                const S = "sswsdjr";
                const A = a((function() {
                        return n("div", {
                            className: L,
                            children: [o(s, {
                                name: "Unfold",
                                className: f.rewardIsFold ? "" : "active",
                                onClick: () => f.rewardIsFold = !1
                            }), o(s, {
                                name: "Fold",
                                className: f.rewardIsFold ? "active" : "",
                                onClick: () => f.rewardIsFold = !0
                            })]
                        })
                    })),
                    D = a((function({
                        data: e,
                        zIndex: t
                    }) {
                        const a = i(),
                            c = l(),
                            m = 0 !== e.status,
                            b = w.rewardTypes[e.rewardType] || {},
                            g = b.bgBig ? {
                                backgroundImage: `url(${b.bgBig})`,
                                zIndex: t
                            } : {
                                zIndex: t
                            },
                            [p, u] = r.exports.useState(!1),
                            [y, z] = r.exports.useState(!1);
                        return r.exports.useEffect((() => {
                            m && p && z(!0)
                        }), [m]), n("div", {
                            className: d(H, B, m && "disabled"),
                            style: g,
                            children: [o("div", {
                                className: "tag-box",
                                children: o("div", {
                                    className: "tag",
                                    children: b.label
                                })
                            }), o("div", {
                                className: "title ttu",
                                children: e.title || b.title
                            }), m && e.url && n("div", {
                                className: "go-to-link",
                                children: [o(h, {
                                    to: e.url,
                                    onClick: () => {
                                        w.isMobile && (w.chatOrNtice = "", x.close())
                                    },
                                    children: e.urlDesc
                                }), o(s, {
                                    name: "Arrow"
                                })]
                            }), n("div", {
                                className: "flex-center status",
                                children: [n("div", {
                                    className: "monospace rewards-wrap " + (e.rewards.length > 1 ? "multiple" : ""),
                                    children: [(!m || p) && o("div", {
                                        className: "effect-box " + (y ? "effect" : ""),
                                        onAnimationEnd: () => {
                                            z(!1), u(!1)
                                        },
                                        children: e.rewards.map(((e, t) => o("div", {
                                            children: o(v, {
                                                name: e.name,
                                                amount: Number(e.amount),
                                                sign: !0
                                            })
                                        }, t)))
                                    }), e.rewards.map(((e, t) => o(v, {
                                        name: e.name,
                                        amount: Number(e.amount),
                                        icon: !0,
                                        sign: !0,
                                        showName: !0
                                    }, t)))]
                                }), m ? o("div", {
                                    className: "claimed",
                                    children: a("common.claimed")
                                }) : o(k, {
                                    type: "conic",
                                    className: "claim",
                                    disabled: p,
                                    onClick: () => {
                                        u(!0), f.receiveReward(e.rewardId)
                                    },
                                    children: a("page.task.receive")
                                })]
                            }), n("div", {
                                className: "flex-center from",
                                children: [o("img", {
                                    src: c ? T.avatar : T.avatarw,
                                    className: "avatar"
                                }), o("div", {
                                    className: "origin",
                                    children: b.name
                                }), o("div", {
                                    className: "time",
                                    children: q(e.createTime)
                                })]
                            })]
                        })
                    })),
                    F = a((function({
                        data: e
                    }) {
                        const t = i(),
                            a = l(),
                            c = 0 !== e.status,
                            m = w.rewardTypes[e.rewardType] || {},
                            g = m.bgBig ? {
                                backgroundImage: `url(${m.bgBig})`
                            } : {},
                            [p, u] = r.exports.useState(!1),
                            [y, z] = r.exports.useState(!1);
                        return r.exports.useEffect((() => {
                            y && c && u(!0)
                        }), [c]), n("div", {
                            style: g,
                            className: d(R, B, c && "disabled"),
                            children: [o("div", {
                                className: "tag-box",
                                children: o("div", {
                                    className: "tag",
                                    children: m.label
                                })
                            }), o("div", {
                                className: "flower"
                            }), o("div", {
                                className: "small-bg",
                                style: {
                                    backgroundImage: `url(${m.bgSmall})`
                                }
                            }), o("div", {
                                className: "title ttu",
                                children: e.title || m.title
                            }), o("div", {
                                className: "desc",
                                children: Y(e.content || m.desc)
                            }), n("div", {
                                className: "main-box",
                                children: [n("div", {
                                    className: "status",
                                    children: [o("div", {
                                        className: "flex-center coin-wrap " + (p ? "effect" : ""),
                                        onAnimationEnd: () => {
                                            u(!1), z(!1)
                                        },
                                        children: o("div", {
                                            className: "rewards-wrap monospace " + (1 === e.rewards.length ? "single" : ""),
                                            children: e.rewards.map(((e, t) => o(v, {
                                                name: e.name,
                                                amount: Number(e.amount),
                                                icon: !0,
                                                sign: !0,
                                                showName: !0
                                            }, t)))
                                        })
                                    }), c ? n(b, {
                                        children: [o("div", {
                                            className: "flex-center",
                                            children: o("div", {
                                                className: "claimed",
                                                children: t("common.claimed")
                                            })
                                        }), e.url && n("div", {
                                            className: "flex-center go-to-link",
                                            children: [o(h, {
                                                to: e.url,
                                                onClick: () => {
                                                    w.isMobile && (w.chatOrNtice = "", x.close())
                                                },
                                                children: e.urlDesc
                                            }), o(s, {
                                                name: "Arrow"
                                            })]
                                        })]
                                    }) : o(k, {
                                        type: "conic",
                                        className: "claim",
                                        disabled: y,
                                        onClick: () => {
                                            z(!0), f.receiveReward(e.rewardId)
                                        },
                                        children: t("common.claim_now")
                                    })]
                                }), n("div", {
                                    className: "flex-center from",
                                    children: [o("img", {
                                        src: a ? T.avatar : T.avatarw,
                                        className: "avatar"
                                    }), o("div", {
                                        className: "origin",
                                        children: m.name
                                    }), o("div", {
                                        className: "time",
                                        children: q(e.createTime)
                                    })]
                                })]
                            })]
                        })
                    })),
                    O = a((function() {
                        const {
                            rewardData: e
                        } = f;
                        return n("div", {
                            className: Z,
                            children: [o(A, {}), null != e && e.length ? o("div", {
                                className: "reward-container",
                                children: e.map(((t, r) => f.rewardIsFold ? o(D, {
                                    data: t,
                                    zIndex: e.length - r
                                }, t.rewardId) : o(F, {
                                    data: t
                                }, t.rewardId)))
                            }) : o(g, {})]
                        })
                    }));
                p({
                    cl1: ["#1e2024", "#ffffff"],
                    cl2: [u("#000000", .19), u("#000000", .1)],
                    cl3: ["#555b65", "#aeb3c2"],
                    cl4: ["#d8d8d8", "#6a6e73"]
                });
                const L = "rqldstm";
                p({
                    cl5: ["#17181b", "#f5f6fa"],
                    cl6: ["#f5f6f7", "#31373d"],
                    cl7: ["#f5f6f7", "#5f6975"],
                    cl8: ["#ffffff", "#5f6975"],
                    cl9: [u("#555b65", .2), u("#c0c4d0", .3)]
                });
                const B = "r1wg44be";
                p({
                    cla: [u("#2c2f36", .4), "#e9eaf2"]
                });
                const H = "sas4pnf",
                    R = "f1fz82zo",
                    Z = "n1p5zyw1";
                var _ = a((function() {
                    const {
                        systemUnreadCount: e,
                        rewardUnreadCount: a
                    } = f, c = i(), [l, d] = r.exports.useState({
                        system: 0,
                        reward: 0
                    }), m = [{
                        label: c("page.notice.tab.notice"),
                        value: 0
                    }, {
                        label: c("page.notice.tab.reward"),
                        value: 1
                    }], g = r.exports.useRef(null);
                    return function(e) {
                        const a = t();
                        r.exports.useEffect((() => {
                            const t = e.current;
                            if (t) {
                                const e = e => {
                                    let r = e.target;
                                    for (; r;) {
                                        if ("A" === r.tagName) {
                                            const t = r.getAttribute("href");
                                            j.test(t) && (e.preventDefault(), a(t));
                                            break
                                        }
                                        r = r.parentElement === t ? null : r.parentElement
                                    }
                                };
                                return t.addEventListener("click", e), () => {
                                    t.removeEventListener("click", e)
                                }
                            }
                        }), [e.current])
                    }(g), r.exports.useEffect((() => {
                        g.current && (0 === f.currentType ? g.current.scrollTop = l.system : g.current.scrollTop = l.reward)
                    }), [l]), n("div", {
                        className: U,
                        children: [o(y, {
                            className: "notice-tabs",
                            value: f.currentType,
                            options: m,
                            onChange: e => function(e) {
                                if (g.current) {
                                    let t = g.current.scrollTop;
                                    d(0 === e ? { ...l,
                                        reward: t
                                    } : { ...l,
                                        system: t
                                    })
                                }
                                f.currentType = e, 1 === e && f.clearSystemNotice(!0)
                            }(e),
                            children: ({
                                option: t,
                                active: r
                            }) => n("button", {
                                className: r ? "is-active tab" : "tab",
                                children: [1 === t.value && o(b, {
                                    children: r || a > 0 ? o("div", {
                                        className: "reward"
                                    }) : o(s, {
                                        name: "Reward"
                                    })
                                }), n("span", {
                                    className: "label",
                                    children: [t.label, o(z, {
                                        num: 0 === t.value ? e : a,
                                        className: "badge"
                                    })]
                                })]
                            })
                        }), o("div", {
                            className: "scroll-wrap",
                            children: o(N, {
                                className: "notice-container",
                                ref: g,
                                bodyLock: w.isMobile,
                                children: 0 === f.currentType ? o(M, {}) : o(O, {})
                            })
                        })]
                    })
                }));
                p({
                    cl1: ["#1e2024", "#ffffff"],
                    cl2: ["linear-gradient(to bottom, #111415, rgba(17, 20, 21, 0))", "linear-gradient(to bottom, #a5aeb8, rgba(197, 203, 213, 0))"],
                    cl3: ["0.44", "0.15"],
                    cl4: [u("#31383d", .6), u("#c0c4d0", .6)],
                    cl5: ["#f5f6f7", "#31373d"],
                    cl6: ["#555b65", "#aeb3c2"]
                });
                const U = "nz2bv4i";
                e("default", a((function({
                    className: e,
                    style: t,
                    onClose: a = (() => {})
                }) {
                    return r.exports.useEffect((() => (f.loadData(), () => {
                        f.clearSystemNotice(), w.isMobile && (w.chatOrNtice = "")
                    })), []), n("div", {
                        style: t,
                        className: d(e, V),
                        id: "notification",
                        children: [!w.isMobile && o(I, {
                            onClose: a
                        }), o(_, {})]
                    })
                })));
                const V = "nhencm8"
            }
        }
    }))
}();
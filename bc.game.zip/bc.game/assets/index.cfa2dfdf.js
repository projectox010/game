var Y = Object.defineProperty,
    Z = Object.defineProperties;
var ee = Object.getOwnPropertyDescriptors;
var y = Object.getOwnPropertySymbols;
var R = Object.prototype.hasOwnProperty,
    F = Object.prototype.propertyIsEnumerable;
var S = (s, t, a) => t in s ? Y(s, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : s[t] = a,
    w = (s, t) => {
        for (var a in t || (t = {})) R.call(t, a) && S(s, a, t[a]);
        if (y)
            for (var a of y(t)) F.call(t, a) && S(s, a, t[a]);
        return s
    },
    x = (s, t) => Z(s, ee(t));
var _ = (s, t) => {
    var a = {};
    for (var c in s) R.call(s, c) && t.indexOf(c) < 0 && (a[c] = s[c]);
    if (s != null && y)
        for (var c of y(s)) t.indexOf(c) < 0 && F.call(s, c) && (a[c] = s[c]);
    return a
};
import {
    t as C,
    q as u,
    u as N,
    j as i,
    a as e,
    m as X,
    b1 as A,
    I as se,
    F as p,
    r as d,
    y as ae,
    l as b,
    a5 as U,
    s as te,
    e as z,
    b2 as ce,
    v as O,
    A as D,
    aO as ie,
    D as Q,
    S as K,
    N as re,
    $ as j,
    a3 as $,
    a4 as M,
    aB as le,
    J as ne,
    b as G,
    d as oe,
    p as H,
    G as de,
    P as me,
    o as he,
    a2 as ge,
    b3 as k
} from "./index.28e31dff.js";
import {
    P as ue
} from "./ParticleLayer.e2a68149.js";
import "./usePixiGsap.bf451f35.js";
var fe = "/assets/tag.906aa227.png",
    ve = "/assets/point.886e9811.png",
    ke = "/assets/g2.5078033e.png",
    Ne = "/assets/g2k.e98d591d.png",
    we = "/assets/g5.e89ed5de.png",
    Ae = "/assets/g5k.c009779c.png",
    pe = "/assets/g8.2fcf8ab2.png",
    be = "/assets/g8k.d3d39f4e.png",
    ye = "/assets/g10.0767bbe0.png",
    xe = "/assets/g10k.8b941eb6.png",
    Te = "/assets/light.bff7a6fe.png",
    P = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAaVBMVEUAAAD/////+u////H/++7/++//+/D//PD/+vH///H///L/++7/++//++7/+u//++//++7/+u//++//+u7//O7///H///X/////++7/++7/+u7//O7/+/D/++//+vD/+/D/+/L///P/++4QcHxGAAAAInRSTlMAA84j8691YzUeE/fr49y7tqGPa0wrGQr2w6eXhn9mRToVFA8FOwAAAI1JREFUKM+lkEcOwzAQA9eymuUel/TG/z8ycWIjgrQ6ZY5DgABJf7GfE4EZEoFoeT8COeczAey4YABwKGI/SbzpstAXzeLjsnuNFfX0tFX4Ia/zulcLBLTafep1HQS93SaYytMnf6brNl2Nwe7+65s8euS4+HKiiLwEcCOGC6CIw0k8iOUsiMcaSuB//gKNBRERH0NSBwAAAABJRU5ErkJggg==",
    De = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAclBMVEUAAAD/wxv/tQT/tgT/twT/vAr/wzD/tgX/tgX/twb/twb/twf/ugb/tgT/tQT/tgT/tgT/tgT/tgX/tQT/twX/tgb/twX/ugX/vw3/tQX/tgX/tQX/tQX/tgX/tgX/tgX/tgX/uAb/uAX/twj/thL/tQQ/yV1+AAAAJXRSTlMACfyxOxkF0p6IVkMn+PXz7+zNt5uDgC4U3cfCqaWMbF5PNiAOfgOkpAAAAJJJREFUKM910VcSwyAQA1Dh3pK4O73r/leM44kZIMv71MCwaGGYIsj6q5zvtweIcrKU8nhHhhBcOBOef/CrTdy8qrnInDxq+NObd1QeUEtLPc7Q0HK6qzl+dfy36SZAFUc3r8cYizK1jg9vrJKRWlvBVKxznRVsN87EtsLlE0puN3h69pF5NhhUEGUhZFEBD7PxD7uJFtCdpVvpAAAAAElFTkSuQmCC";
const Ce = [{
        position: 20,
        img: ke,
        img_done: Ne
    }, {
        position: 50,
        img: we,
        img_done: Ae
    }, {
        position: 80,
        img: pe,
        img_done: be
    }, {
        position: 100,
        img: ye,
        img_done: xe
    }],
    Ee = (s, t) => {
        const a = Ce.find(c => c.position === t);
        return s >= t ? a == null ? void 0 : a.img_done : a == null ? void 0 : a.img
    },
    g = [20, 50, 80, 100],
    T = [12.5, 37.5, 62.5, 87.5, 100],
    _e = s => {
        if (s >= g[g.length - 1]) return s;
        if (s <= g[0]) return Number((s * T[0] / g[0]).toFixed(2)); {
            const t = g.findIndex(o => o > s),
                a = t - 1,
                c = T[a],
                r = T[t] - T[a],
                l = g[t] - g[a],
                n = (s - g[a]) * r / l;
            return Number((c + n).toFixed(2))
        }
    },
    Pe = t => {
        var s = _(t, []);
        const a = Math.floor(s.currentPoint * 100 / s.totalPoint),
            c = N(),
            r = s.rewards && s.rewards.length > 0;
        return i("div", {
            className: Re,
            children: [i("div", {
                className: "head",
                children: [e("div", {
                    className: "title",
                    children: s.dayOfWeek
                }), i("div", {
                    className: "cut-time",
                    children: [e("div", {
                        className: "tip-txt",
                        children: c("page.task.refreash_tip")
                    }), e(X, {
                        endTime: s.weekTaskExpireTimeInMs,
                        children: ({
                            days: l,
                            hours: n,
                            minutes: o,
                            seconds: m
                        }) => i("div", {
                            className: "time-wrap",
                            children: [i("span", {
                                className: "day",
                                children: [l, "D"]
                            }), e("span", {
                                children: A(n)
                            }), e("span", {
                                className: "colon",
                                children: " : "
                            }), e("span", {
                                children: A(o)
                            }), e("span", {
                                className: "colon",
                                children: " : "
                            }), e("span", {
                                children: A(m)
                            })]
                        })
                    })]
                })]
            }), e("div", {
                className: "desc",
                children: c("page.task.rewrards_desc")
            }), i("div", {
                className: "progress-wrap",
                children: [g.map((l, n) => e(Ie, {
                    percent: l,
                    amount: r && s.rewards[n] ? s.rewards[n].amount : 0,
                    curProgress: a,
                    totalNumber: s.totalPoint
                }, l)), e(Ve, {
                    cur: s.currentPoint,
                    total: s.totalPoint
                })]
            }), e("div", {
                className: "rewards",
                children: e(se, {
                    k: "page.task.rewrards_amount",
                    children: i(p, {
                        children: [e("span", {
                            className: "amount",
                            children: s.rewardsAmount
                        }), e("b", {
                            className: "currency",
                            children: "BCD"
                        })]
                    })
                })
            })]
        })
    },
    Ve = ({
        cur: s,
        total: t
    }) => {
        const [a, c] = d.exports.useState(0), r = Math.floor(s * 100 / t);
        return d.exports.useEffect(() => {
            c(_e(r))
        }, []), e("div", {
            className: Se,
            children: i("div", {
                className: "wrap",
                style: {
                    width: `${a}%`
                },
                children: [e("div", {
                    className: "progress-point"
                }), i("div", {
                    className: "progress-mark",
                    children: [e("div", {
                        className: "top",
                        children: s
                    }), e("div", {
                        className: "bot",
                        children: t
                    })]
                })]
            })
        })
    },
    Ie = ({
        percent: s,
        curProgress: t,
        amount: a,
        totalNumber: c
    }) => {
        const r = t >= s ? "done" : "",
            l = new ae(c).mul(s / 100).toFixed(0),
            n = N();
        return i("div", {
            className: b(Fe, r),
            children: [e("div", {
                className: "item-bg",
                children: e("img", {
                    src: fe,
                    alt: ""
                })
            }), i("div", {
                className: "item-wrap",
                children: [i("div", {
                    className: "progress-box",
                    children: [e("div", {
                        className: "top-amount",
                        children: a ? (Math.floor(a * 100) / 100).toFixed(2) + " BCD" : n("page.task.on_way")
                    }), i("div", {
                        className: "centent",
                        children: [e("img", {
                            src: Ee(t, s),
                            className: "gold-img",
                            alt: ""
                        }), e("img", {
                            src: Te,
                            className: "light-img",
                            alt: ""
                        }), e("img", {
                            src: P,
                            className: "star-img star-a",
                            alt: ""
                        }), e("img", {
                            src: De,
                            className: "star-img star-b",
                            alt: ""
                        }), t === 100 && i(p, {
                            children: [e("img", {
                                src: P,
                                className: "star-img star-c",
                                alt: ""
                            }), e("img", {
                                src: P,
                                className: "star-img star-d",
                                alt: ""
                            })]
                        })]
                    }), i("div", {
                        className: "bot-wrap",
                        children: [e("img", {
                            src: ve,
                            alt: ""
                        }), l]
                    }), i("div", {
                        children: [s, "%"]
                    })]
                }), e("div", {
                    className: "point"
                })]
            })]
        })
    },
    Se = "b1vijc5r";
C({
    cl1: ["#7458ff", u("#ffffff", .6)],
    cl2: ["#ffffff", "#31373d"],
    cl3: [u("#99a4b0", .1), u("#5f6975", .1)]
});
const Re = "p1nb1i8i",
    Fe = "iik7gn6";
var Me = "/assets/point.961c559e.svg";
const Be = a => {
        var c = a,
            {
                curtab: s
            } = c,
            t = _(c, ["curtab"]);
        const r = N(),
            l = s ? 1 : 0,
            n = z(),
            o = d.exports.useCallback(f => {
                n(`/task${f===1?"/weekly":""}`)
            }, []),
            m = [{
                label: r("page.task.daily"),
                value: () => e(B, {
                    list: t.dailyTasks,
                    cutTime: t.dailyTaskExpireTimeInMs,
                    showDay: !1
                })
            }, {
                label: r("page.task.weekly"),
                value: () => e(B, {
                    list: t.weeklyTasks,
                    cutTime: t.weekTaskExpireTimeInMs,
                    showDay: !0
                })
            }];
        return e(ce, {
            className: Qe,
            value: l,
            tabs: m,
            onChange: o
        })
    },
    B = ({
        list: s,
        cutTime: t,
        showDay: a
    }) => {
        const c = N();
        return i(p, {
            children: [s.map(r => e(W, w({}, r), r.title)), i("div", {
                className: "cut-time",
                children: [c("page.task.expire"), e(X, {
                    endTime: t,
                    children: ({
                        days: r,
                        hours: l,
                        minutes: n,
                        seconds: o
                    }) => i("div", {
                        className: "time-wrap",
                        children: [a && i("b", {
                            className: "day",
                            children: [r, "D"]
                        }), e("b", {
                            children: A(l)
                        }), e("b", {
                            className: "colon",
                            children: ":"
                        }), e("b", {
                            children: A(n)
                        }), e("b", {
                            className: "colon",
                            children: ":"
                        }), e("b", {
                            children: A(o)
                        })]
                    })
                })]
            })]
        })
    },
    W = s => {
        const t = z(),
            a = s.doneValue >= s.totalValue,
            c = s.totalValue > 1,
            r = () => {
                const n = [];
                for (let o = 0; o < 8; o++) n.push(e("b", {}, o));
                return n
            },
            l = !s.path || s.path.length === 0;
        return i("div", {
            className: b(Oe, a && "complete", !l && "hover"),
            onClick: () => {
                l || (O.close(), t(s.path))
            },
            children: [i("div", {
                className: "ticket",
                children: [a ? "+ " : "", e("img", {
                    src: Me
                }), s.rewardPoint, e("div", {
                    className: "jagged",
                    children: r()
                })]
            }), e("div", {
                className: "item-head",
                children: e("div", {
                    className: "tit",
                    children: s.title
                })
            }), e("div", {
                className: "item-desc",
                children: s.describe
            }), i("div", {
                className: "item-status",
                children: [a && e("div", {
                    className: "done",
                    children: e(D, {
                        name: "Check"
                    })
                }), c && !a && e(Ue, {
                    progress: s.doneValue,
                    total: s.totalValue
                })]
            })]
        })
    },
    Le = s => Number(s.toFixed(0)) != s,
    Xe = 50,
    V = Math.PI * 2 * Xe,
    Ue = U.memo(({
        progress: s,
        total: t
    }) => {
        const a = d.exports.useRef(null),
            c = String(t).length > 4;
        let r = s,
            l = t;
        c ? (l = 100, r = Math.floor(s * l / t) + "%") : Le(r) && (r = Math.floor(r * 10) / 10), d.exports.useEffect(() => {
            const m = `${s/t*V} ${V}`,
                f = setTimeout(() => {
                    a.current && a.current.setAttribute("stroke-dasharray", m)
                }, 50);
            return () => clearTimeout(f)
        }, [s]);
        const n = te.isDarken ? "#3C404A" : "#EDEEF2";
        return i("div", {
            className: ze,
            children: [i("svg", {
                className: "circle",
                width: "100",
                height: "100",
                viewBox: "0 0 100 100",
                children: [e("circle", {
                    cx: "50",
                    cy: "50",
                    r: "45",
                    strokeWidth: "5",
                    stroke: n,
                    fill: "none"
                }), e("circle", {
                    ref: a,
                    cx: "50",
                    cy: "50",
                    r: "45",
                    strokeWidth: "5",
                    stroke: "#7bc524",
                    fill: "none",
                    transform: "matrix(0,-1,1,0,0,100)",
                    strokeDasharray: `0 ${V}`
                })]
            }), c && e("div", {
                className: "percent-num",
                children: r
            }), !c && i(p, {
                children: [e("div", {
                    className: "cur-num",
                    children: r
                }), e("div", {
                    className: "total-num",
                    children: l
                })]
            })]
        })
    });
C({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [u("#828c97", .5), u("#5f6975", .6)]
});
const ze = "c1lsgdbl";
C({
    cl1: ["rgba(45, 48, 53, 0.5)", "#f5f6fa"],
    cl2: ["#2d3035", "#edeef2"],
    cl3: ["#f5f6f7", "#31373d"],
    cl4: ["#1e2024", "#ffffff"],
    cl5: [u("#99a4b0", .6), u("#5f6975", .6)]
});
const Oe = "i1u0utym";
C({
    cl1: [u("#99a4b0", .6), u("#5f6975", .6)],
    cl2: ["#f5f6f7", "#31373d"]
});
const Qe = "tc840he";
const Ke = ({
        list: s
    }) => {
        var v;
        const [t, a] = d.exports.useState(s[0].taskDate), [c, r] = d.exports.useState(!1), l = d.exports.useRef(null), n = s.length < 5, o = (v = s.find(h => h.taskDate === t)) == null ? void 0 : v.weekFormat, m = d.exports.useCallback(h => {
            const E = h.target,
                J = E.scrollWidth,
                q = E.clientWidth,
                I = E.scrollLeft;
            I < 10 ? r(!1) : J - q - I < 10 && r(!0)
        }, []), f = d.exports.useCallback(h => {
            l.current && ie.to(l.current, {
                scrollLeft: h,
                duration: .5
            })
        }, []);
        return e(Q, {
            className: $e,
            title: "Previous tasks",
            size: [464, 830],
            children: e(K, {
                className: b(Ge, "history-scroll"),
                children: i("div", {
                    className: "history-wrap",
                    children: [i("div", {
                        className: "history-top",
                        children: [e("div", {
                            className: "tit",
                            children: "Day"
                        }), !n && i("div", {
                            className: "page-btn-wrap",
                            children: [e("button", {
                                className: `scroll-left scroll-btn ${c?"":"disabled"}`,
                                onClick: () => {
                                    f(0)
                                },
                                children: e(D, {
                                    name: "Arrow"
                                })
                            }), e("button", {
                                className: `scroll-right scroll-btn ${c?"disabled":""}`,
                                onClick: () => {
                                    f(200)
                                },
                                children: e(D, {
                                    name: "Arrow"
                                })
                            })]
                        })]
                    }), e("div", {
                        className: "head-wrap",
                        children: e("div", {
                            className: "daily-head",
                            onScroll: m,
                            ref: l,
                            children: s.map(h => i("div", {
                                className: `daily-item ${t===h.taskDate?"active":""}`,
                                onClick: () => a(h.taskDate),
                                children: [e("div", {
                                    className: "head-tit",
                                    children: h.weekFormat
                                }), e("div", {
                                    className: "desc",
                                    children: h.dateFormat
                                }), e(D, {
                                    name: "Arrow"
                                })]
                            }, h.weekFormat))
                        })
                    }), i("div", {
                        className: "daily-list",
                        children: [e("div", {
                            className: "list-tit",
                            children: o
                        }), e(je, {
                            taskDate: t
                        }, t)]
                    })]
                })
            })
        })
    },
    je = ({
        taskDate: s
    }) => {
        const t = N(),
            a = re(() => j.post("/activity/taskhub/previous/", {
                taskDate: s
            }));
        if (a.error) throw a.error;
        return a.data ? a.data.tasks && a.data.tasks.length === 0 ? e("div", {
            className: L,
            children: e(M, {
                children: t("page.task.empty")
            })
        }) : a.data.tasks && a.data.tasks.length > 0 ? e(p, {
            children: a.data.tasks.map(c => d.exports.createElement(W, x(w({}, c), {
                key: c.title
            })))
        }) : e(M, {}) : e("div", {
            className: L,
            children: e($, {})
        })
    },
    $e = "dumvk1r",
    L = "t1703u1b",
    Ge = "h1c1ofws";
var He = "/assets/recharge_reward.6fe75678.json";
const We = {
    scale: {
        list: [{
            value: 1,
            time: 0
        }, {
            value: 1.5,
            time: 1
        }]
    },
    color: {
        start: "#892aff",
        end: "#892aff"
    },
    maxParticles: 8,
    spawnRect: {
        w: 414,
        h: 580
    }
};

function Je({
    currency: s,
    amount: t,
    rewardId: a,
    milestone: c,
    setData: r
}) {
    const l = N(),
        [n, o] = d.exports.useState(!1),
        m = d.exports.useRef(null);
    d.exports.useEffect(() => {
        setTimeout(() => {
            var v;
            (v = m.current) == null || v.play(0)
        }, 300)
    }, []);
    const f = async v => {
        o(!0), j.post("/activity/taskhub/takeReward/", {
            rewardId: v
        }).then(h => {
            oe.emit("taskClaim"), r(v), H.close(), o(!1)
        }).catch(de)
    };
    return i("div", {
        className: b(qe, "result-pop"),
        children: [e(le, {
            className: "lottie-wrap",
            ref: m,
            path: He
        }), e(ue, {
            config: We
        }), i("div", {
            className: "front",
            children: [e("div", {
                className: "recharge",
                children: "Task Reward"
            }), i("div", {
                className: "text",
                children: [i("span", {
                    style: {
                        marginLeft: 4
                    },
                    children: [c, "%"]
                }), " of the weekly task progress achieved, and you have received a task reward"]
            }), i("div", {
                className: "result-value flex-center",
                children: [e("div", {
                    className: "amount",
                    children: t
                }), e("div", {
                    className: "currency-name",
                    children: ne.getAlias(s)
                })]
            }), e(G, {
                onClick: () => {
                    f(a)
                },
                loading: n,
                type: "conic",
                children: l("common.actions.confirm")
            })]
        })]
    })
}
const qe = "r1iapx7p";
const Ye = U.memo(({
        rlist: s
    }) => {
        const [t, a] = d.exports.useState(s.map(n => n.rewardId)), c = me(), r = s.find(n => n.rewardId === t[0]), l = n => {
            const o = t.filter(m => m != n);
            a(o)
        };
        return r && setTimeout(() => {
            c() && H.push(e(Je, x(w({}, r), {
                setData: l
            })))
        }, 1500), null
    }),
    Ze = he(function() {
        const a = ge()["*"];
        d.exports.useEffect(() => {
            k.update()
        }, []);
        const c = N();
        if (k.loading) return e($, {}); {
            const r = k.data.rewards.filter(l => l.rewardId > 0);
            return e(Q, {
                className: es,
                size: [464, 830],
                title: c("page.promotion.task.title"),
                children: i(K, {
                    className: b(ss, "task-scroll"),
                    id: "task",
                    children: [r.length > 0 && e(Ye, {
                        rlist: r
                    }), i("div", {
                        className: "task-wrap",
                        children: [e(Pe, w({}, k.data)), e(Be, x(w({}, k.data), {
                            curtab: a
                        })), e(G, {
                            disabled: k.data.taskDates.length === 0,
                            type: "conic2",
                            onClick: () => O.push(e(Ke, {
                                list: k.data.taskDates
                            })),
                            children: c("page.task.previous")
                        })]
                    })]
                })
            })
        }
    });
var rs = Ze;
const es = "d842dhe",
    ss = "t3czso3";
export {
    rs as
    default
};
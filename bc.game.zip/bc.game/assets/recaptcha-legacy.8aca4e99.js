System.register(["./index-legacy.1416f96c.js"], (function(e) {
    "use strict";
    var t, i;
    return {
        setters: [function(e) {
            t = e.aG, i = e.aH
        }],
        execute: function() {
            e("r", (async function(e) {
                var t;
                return (null === (t = n) || void 0 === t ? void 0 : t.request(e)) || "No captcha!"
            }));
            class s extends class {
                constructor(e) {
                    this.timeout = 0, this.key = e, this.inited = i(8e3).then((() => this.init()))
                }
                async request(e) {
                    await this.inited;
                    const t = [this.requestCode(e)];
                    return this.timeout > 0 && t.push(i(this.timeout).then((() => "time out"))), await Promise.race(t)
                }
            } {
                async init() {
                    await t("https://js.hcaptcha.com/1/api.js");
                    const e = "hcaptcha_container",
                        i = document.createElement("div");
                    i.id = e, i.style.display = "none", document.body.appendChild(i), hcaptcha.render(e, {
                        size: "invisible",
                        sitekey: "cf0b9a27-82e3-42fb-bfec-562f8045e495"
                    })
                }
                async requestCode(e) {
                    return (await hcaptcha.execute({
                        async: !0
                    })).response
                }
            }
            let n = null;
            n = new s("cf0b9a27-82e3-42fb-bfec-562f8045e495")
        }
    }
}));
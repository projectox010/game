import {
    a2 as t,
    a as s
} from "./index.28e31dff.js";
import {
    F as r
} from "./AggregateList.fd1a9818.js";

function m() {
    const a = t();
    return s(r, {
        tagName: a.tagname || "",
        isTag: !0
    })
}
export {
    m as
    default
};
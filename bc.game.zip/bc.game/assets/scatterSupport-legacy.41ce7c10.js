System.register(["./index-legacy.1416f96c.js", "./index-legacy.876ed6a5.js", "./output-legacy.7da5a3a3.js", "./metamaskSupport-legacy.8f064903.js", "./Starting-legacy.71ee17e7.js", "./DepositBonus-legacy.b5f6d3ee.js", "./index-legacy.1f31f668.js", "./Status-legacy.ce7bc332.js"], (function(e) {
    "use strict";
    var t, r, n, i, a, o;
    return {
        setters: [function(e) {
            t = e.aM, r = e.bz, n = e.aN, i = e.cR
        }, function(e) {
            a = e.b
        }, function(e) {
            o = e.d
        }, function() {}, function() {}, function() {}, function() {}, function() {}],
        execute: function() {
            var s = {},
                u = {},
                l = {},
                c = {},
                h = {},
                f = {};

            function d(e) {
                let t = e.length;
                for (; --t >= 0;) e[t] = 0
            }
            const p = 256,
                _ = 286,
                y = 30,
                g = 15,
                b = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]),
                v = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
                m = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]),
                w = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
                x = new Array(576);
            d(x);
            const k = new Array(60);
            d(k);
            const S = new Array(512);
            d(S);
            const E = new Array(256);
            d(E);
            const A = new Array(29);
            d(A);
            const T = new Array(y);

            function z(e, t, r, n, i) {
                this.static_tree = e, this.extra_bits = t, this.extra_base = r, this.elems = n, this.max_length = i, this.has_stree = e && e.length
            }
            let O, R, P;

            function N(e, t) {
                this.dyn_tree = e, this.max_code = 0, this.stat_desc = t
            }
            d(T);
            const D = e => e < 256 ? S[e] : S[256 + (e >>> 7)],
                L = (e, t) => {
                    e.pending_buf[e.pending++] = 255 & t, e.pending_buf[e.pending++] = t >>> 8 & 255
                },
                U = (e, t, r) => {
                    e.bi_valid > 16 - r ? (e.bi_buf |= t << e.bi_valid & 65535, L(e, e.bi_buf), e.bi_buf = t >> 16 - e.bi_valid, e.bi_valid += r - 16) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += r)
                },
                I = (e, t, r) => {
                    U(e, r[2 * t], r[2 * t + 1])
                },
                B = (e, t) => {
                    let r = 0;
                    do {
                        r |= 1 & e, e >>>= 1, r <<= 1
                    } while (--t > 0);
                    return r >>> 1
                },
                j = (e, t, r) => {
                    const n = new Array(16);
                    let i, a, o = 0;
                    for (i = 1; i <= g; i++) n[i] = o = o + r[i - 1] << 1;
                    for (a = 0; a <= t; a++) {
                        let t = e[2 * a + 1];
                        0 !== t && (e[2 * a] = B(n[t]++, t))
                    }
                },
                M = e => {
                    let t;
                    for (t = 0; t < _; t++) e.dyn_ltree[2 * t] = 0;
                    for (t = 0; t < y; t++) e.dyn_dtree[2 * t] = 0;
                    for (t = 0; t < 19; t++) e.bl_tree[2 * t] = 0;
                    e.dyn_ltree[512] = 1, e.opt_len = e.static_len = 0, e.last_lit = e.matches = 0
                },
                C = e => {
                    e.bi_valid > 8 ? L(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0
                },
                F = (e, t, r, n) => {
                    const i = 2 * t,
                        a = 2 * r;
                    return e[i] < e[a] || e[i] === e[a] && n[t] <= n[r]
                },
                H = (e, t, r) => {
                    const n = e.heap[r];
                    let i = r << 1;
                    for (; i <= e.heap_len && (i < e.heap_len && F(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !F(t, n, e.heap[i], e.depth));) e.heap[r] = e.heap[i], r = i, i <<= 1;
                    e.heap[r] = n
                },
                K = (e, t, r) => {
                    let n, i, a, o, s = 0;
                    if (0 !== e.last_lit)
                        do {
                            n = e.pending_buf[e.d_buf + 2 * s] << 8 | e.pending_buf[e.d_buf + 2 * s + 1], i = e.pending_buf[e.l_buf + s], s++, 0 === n ? I(e, i, t) : (a = E[i], I(e, a + p + 1, t), o = b[a], 0 !== o && (i -= A[a], U(e, i, o)), n--, a = D(n), I(e, a, r), o = v[a], 0 !== o && (n -= T[a], U(e, n, o)))
                        } while (s < e.last_lit);
                    I(e, 256, t)
                },
                W = (e, t) => {
                    const r = t.dyn_tree,
                        n = t.stat_desc.static_tree,
                        i = t.stat_desc.has_stree,
                        a = t.stat_desc.elems;
                    let o, s, u, l = -1;
                    for (e.heap_len = 0, e.heap_max = 573, o = 0; o < a; o++) 0 !== r[2 * o] ? (e.heap[++e.heap_len] = l = o, e.depth[o] = 0) : r[2 * o + 1] = 0;
                    for (; e.heap_len < 2;) u = e.heap[++e.heap_len] = l < 2 ? ++l : 0, r[2 * u] = 1, e.depth[u] = 0, e.opt_len--, i && (e.static_len -= n[2 * u + 1]);
                    for (t.max_code = l, o = e.heap_len >> 1; o >= 1; o--) H(e, r, o);
                    u = a;
                    do {
                        o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], H(e, r, 1), s = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = s, r[2 * u] = r[2 * o] + r[2 * s], e.depth[u] = (e.depth[o] >= e.depth[s] ? e.depth[o] : e.depth[s]) + 1, r[2 * o + 1] = r[2 * s + 1] = u, e.heap[1] = u++, H(e, r, 1)
                    } while (e.heap_len >= 2);
                    e.heap[--e.heap_max] = e.heap[1], ((e, t) => {
                        const r = t.dyn_tree,
                            n = t.max_code,
                            i = t.stat_desc.static_tree,
                            a = t.stat_desc.has_stree,
                            o = t.stat_desc.extra_bits,
                            s = t.stat_desc.extra_base,
                            u = t.stat_desc.max_length;
                        let l, c, h, f, d, p, _ = 0;
                        for (f = 0; f <= g; f++) e.bl_count[f] = 0;
                        for (r[2 * e.heap[e.heap_max] + 1] = 0, l = e.heap_max + 1; l < 573; l++) c = e.heap[l], f = r[2 * r[2 * c + 1] + 1] + 1, f > u && (f = u, _++), r[2 * c + 1] = f, c > n || (e.bl_count[f]++, d = 0, c >= s && (d = o[c - s]), p = r[2 * c], e.opt_len += p * (f + d), a && (e.static_len += p * (i[2 * c + 1] + d)));
                        if (0 !== _) {
                            do {
                                for (f = u - 1; 0 === e.bl_count[f];) f--;
                                e.bl_count[f]--, e.bl_count[f + 1] += 2, e.bl_count[u]--, _ -= 2
                            } while (_ > 0);
                            for (f = u; 0 !== f; f--)
                                for (c = e.bl_count[f]; 0 !== c;) h = e.heap[--l], h > n || (r[2 * h + 1] !== f && (e.opt_len += (f - r[2 * h + 1]) * r[2 * h], r[2 * h + 1] = f), c--)
                        }
                    })(e, t), j(r, l, e.bl_count)
                },
                q = (e, t, r) => {
                    let n, i, a = -1,
                        o = t[1],
                        s = 0,
                        u = 7,
                        l = 4;
                    for (0 === o && (u = 138, l = 3), t[2 * (r + 1) + 1] = 65535, n = 0; n <= r; n++) i = o, o = t[2 * (n + 1) + 1], ++s < u && i === o || (s < l ? e.bl_tree[2 * i] += s : 0 !== i ? (i !== a && e.bl_tree[2 * i]++, e.bl_tree[32]++) : s <= 10 ? e.bl_tree[34]++ : e.bl_tree[36]++, s = 0, a = i, 0 === o ? (u = 138, l = 3) : i === o ? (u = 6, l = 3) : (u = 7, l = 4))
                },
                Z = (e, t, r) => {
                    let n, i, a = -1,
                        o = t[1],
                        s = 0,
                        u = 7,
                        l = 4;
                    for (0 === o && (u = 138, l = 3), n = 0; n <= r; n++)
                        if (i = o, o = t[2 * (n + 1) + 1], !(++s < u && i === o)) {
                            if (s < l)
                                do {
                                    I(e, i, e.bl_tree)
                                } while (0 != --s);
                            else 0 !== i ? (i !== a && (I(e, i, e.bl_tree), s--), I(e, 16, e.bl_tree), U(e, s - 3, 2)) : s <= 10 ? (I(e, 17, e.bl_tree), U(e, s - 3, 3)) : (I(e, 18, e.bl_tree), U(e, s - 11, 7));
                            s = 0, a = i, 0 === o ? (u = 138, l = 3) : i === o ? (u = 6, l = 3) : (u = 7, l = 4)
                        }
                };
            let V = !1;
            const G = (e, t, r, n) => {
                U(e, 0 + (n ? 1 : 0), 3), ((e, t, r, n) => {
                    C(e), n && (L(e, r), L(e, ~r)), e.pending_buf.set(e.window.subarray(t, t + r), e.pending), e.pending += r
                })(e, t, r, !0)
            };
            f._tr_init = e => {
                V || ((() => {
                    let e, t, r, n, i;
                    const a = new Array(16);
                    for (r = 0, n = 0; n < 28; n++)
                        for (A[n] = r, e = 0; e < 1 << b[n]; e++) E[r++] = n;
                    for (E[r - 1] = n, i = 0, n = 0; n < 16; n++)
                        for (T[n] = i, e = 0; e < 1 << v[n]; e++) S[i++] = n;
                    for (i >>= 7; n < y; n++)
                        for (T[n] = i << 7, e = 0; e < 1 << v[n] - 7; e++) S[256 + i++] = n;
                    for (t = 0; t <= g; t++) a[t] = 0;
                    for (e = 0; e <= 143;) x[2 * e + 1] = 8, e++, a[8]++;
                    for (; e <= 255;) x[2 * e + 1] = 9, e++, a[9]++;
                    for (; e <= 279;) x[2 * e + 1] = 7, e++, a[7]++;
                    for (; e <= 287;) x[2 * e + 1] = 8, e++, a[8]++;
                    for (j(x, 287, a), e = 0; e < y; e++) k[2 * e + 1] = 5, k[2 * e] = B(e, 5);
                    O = new z(x, b, 257, _, g), R = new z(k, v, 0, y, g), P = new z(new Array(0), m, 0, 19, 7)
                })(), V = !0), e.l_desc = new N(e.dyn_ltree, O), e.d_desc = new N(e.dyn_dtree, R), e.bl_desc = new N(e.bl_tree, P), e.bi_buf = 0, e.bi_valid = 0, M(e)
            }, f._tr_stored_block = G, f._tr_flush_block = (e, t, r, n) => {
                let i, a, o = 0;
                e.level > 0 ? (2 === e.strm.data_type && (e.strm.data_type = (e => {
                    let t, r = 4093624447;
                    for (t = 0; t <= 31; t++, r >>>= 1)
                        if (1 & r && 0 !== e.dyn_ltree[2 * t]) return 0;
                    if (0 !== e.dyn_ltree[18] || 0 !== e.dyn_ltree[20] || 0 !== e.dyn_ltree[26]) return 1;
                    for (t = 32; t < p; t++)
                        if (0 !== e.dyn_ltree[2 * t]) return 1;
                    return 0
                })(e)), W(e, e.l_desc), W(e, e.d_desc), o = (e => {
                    let t;
                    for (q(e, e.dyn_ltree, e.l_desc.max_code), q(e, e.dyn_dtree, e.d_desc.max_code), W(e, e.bl_desc), t = 18; t >= 3 && 0 === e.bl_tree[2 * w[t] + 1]; t--);
                    return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t
                })(e), i = e.opt_len + 3 + 7 >>> 3, a = e.static_len + 3 + 7 >>> 3, a <= i && (i = a)) : i = a = r + 5, r + 4 <= i && -1 !== t ? G(e, t, r, n) : 4 === e.strategy || a === i ? (U(e, 2 + (n ? 1 : 0), 3), K(e, x, k)) : (U(e, 4 + (n ? 1 : 0), 3), ((e, t, r, n) => {
                    let i;
                    for (U(e, t - 257, 5), U(e, r - 1, 5), U(e, n - 4, 4), i = 0; i < n; i++) U(e, e.bl_tree[2 * w[i] + 1], 3);
                    Z(e, e.dyn_ltree, t - 1), Z(e, e.dyn_dtree, r - 1)
                })(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), K(e, e.dyn_ltree, e.dyn_dtree)), M(e), n && C(e)
            }, f._tr_tally = (e, t, r) => (e.pending_buf[e.d_buf + 2 * e.last_lit] = t >>> 8 & 255, e.pending_buf[e.d_buf + 2 * e.last_lit + 1] = 255 & t, e.pending_buf[e.l_buf + e.last_lit] = 255 & r, e.last_lit++, 0 === t ? e.dyn_ltree[2 * r]++ : (e.matches++, t--, e.dyn_ltree[2 * (E[r] + p + 1)]++, e.dyn_dtree[2 * D(t)]++), e.last_lit === e.lit_bufsize - 1), f._tr_align = e => {
                U(e, 2, 3), I(e, 256, x), (e => {
                    16 === e.bi_valid ? (L(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = 255 & e.bi_buf, e.bi_buf >>= 8, e.bi_valid -= 8)
                })(e)
            };
            var J = (e, t, r, n) => {
                let i = 65535 & e | 0,
                    a = e >>> 16 & 65535 | 0,
                    o = 0;
                for (; 0 !== r;) {
                    o = r > 2e3 ? 2e3 : r, r -= o;
                    do {
                        i = i + t[n++] | 0, a = a + i | 0
                    } while (--o);
                    i %= 65521, a %= 65521
                }
                return i | a << 16 | 0
            };
            const Y = new Uint32Array((() => {
                let e, t = [];
                for (var r = 0; r < 256; r++) {
                    e = r;
                    for (var n = 0; n < 8; n++) e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
                    t[r] = e
                }
                return t
            })());
            var $ = (e, t, r, n) => {
                    const i = Y,
                        a = n + r;
                    e ^= -1;
                    for (let o = n; o < a; o++) e = e >>> 8 ^ i[255 & (e ^ t[o])];
                    return -1 ^ e
                },
                Q = {
                    2: "need dictionary",
                    1: "stream end",
                    0: "",
                    "-1": "file error",
                    "-2": "stream error",
                    "-3": "data error",
                    "-4": "insufficient memory",
                    "-5": "buffer error",
                    "-6": "incompatible version"
                },
                X = {
                    Z_NO_FLUSH: 0,
                    Z_PARTIAL_FLUSH: 1,
                    Z_SYNC_FLUSH: 2,
                    Z_FULL_FLUSH: 3,
                    Z_FINISH: 4,
                    Z_BLOCK: 5,
                    Z_TREES: 6,
                    Z_OK: 0,
                    Z_STREAM_END: 1,
                    Z_NEED_DICT: 2,
                    Z_ERRNO: -1,
                    Z_STREAM_ERROR: -2,
                    Z_DATA_ERROR: -3,
                    Z_MEM_ERROR: -4,
                    Z_BUF_ERROR: -5,
                    Z_NO_COMPRESSION: 0,
                    Z_BEST_SPEED: 1,
                    Z_BEST_COMPRESSION: 9,
                    Z_DEFAULT_COMPRESSION: -1,
                    Z_FILTERED: 1,
                    Z_HUFFMAN_ONLY: 2,
                    Z_RLE: 3,
                    Z_FIXED: 4,
                    Z_DEFAULT_STRATEGY: 0,
                    Z_BINARY: 0,
                    Z_TEXT: 1,
                    Z_UNKNOWN: 2,
                    Z_DEFLATED: 8
                };
            const {
                _tr_init: ee,
                _tr_stored_block: te,
                _tr_flush_block: re,
                _tr_tally: ne,
                _tr_align: ie
            } = f, ae = J, oe = $, se = Q, {
                Z_NO_FLUSH: ue,
                Z_PARTIAL_FLUSH: le,
                Z_FULL_FLUSH: ce,
                Z_FINISH: he,
                Z_BLOCK: fe,
                Z_OK: de,
                Z_STREAM_END: pe,
                Z_STREAM_ERROR: _e,
                Z_DATA_ERROR: ye,
                Z_BUF_ERROR: ge,
                Z_DEFAULT_COMPRESSION: be,
                Z_FILTERED: ve,
                Z_HUFFMAN_ONLY: me,
                Z_RLE: we,
                Z_FIXED: xe,
                Z_DEFAULT_STRATEGY: ke,
                Z_UNKNOWN: Se,
                Z_DEFLATED: Ee
            } = X, Ae = 258, Te = 262, ze = 103, Oe = 113, Re = 666, Pe = (e, t) => (e.msg = se[t], t), Ne = e => (e << 1) - (e > 4 ? 9 : 0), De = e => {
                let t = e.length;
                for (; --t >= 0;) e[t] = 0
            };
            let Le = (e, t, r) => (t << e.hash_shift ^ r) & e.hash_mask;
            const Ue = e => {
                    const t = e.state;
                    let r = t.pending;
                    r > e.avail_out && (r = e.avail_out), 0 !== r && (e.output.set(t.pending_buf.subarray(t.pending_out, t.pending_out + r), e.next_out), e.next_out += r, t.pending_out += r, e.total_out += r, e.avail_out -= r, t.pending -= r, 0 === t.pending && (t.pending_out = 0))
                },
                Ie = (e, t) => {
                    re(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, Ue(e.strm)
                },
                Be = (e, t) => {
                    e.pending_buf[e.pending++] = t
                },
                je = (e, t) => {
                    e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = 255 & t
                },
                Me = (e, t, r, n) => {
                    let i = e.avail_in;
                    return i > n && (i = n), 0 === i ? 0 : (e.avail_in -= i, t.set(e.input.subarray(e.next_in, e.next_in + i), r), 1 === e.state.wrap ? e.adler = ae(e.adler, t, i, r) : 2 === e.state.wrap && (e.adler = oe(e.adler, t, i, r)), e.next_in += i, e.total_in += i, i)
                },
                Ce = (e, t) => {
                    let r, n, i = e.max_chain_length,
                        a = e.strstart,
                        o = e.prev_length,
                        s = e.nice_match;
                    const u = e.strstart > e.w_size - Te ? e.strstart - (e.w_size - Te) : 0,
                        l = e.window,
                        c = e.w_mask,
                        h = e.prev,
                        f = e.strstart + Ae;
                    let d = l[a + o - 1],
                        p = l[a + o];
                    e.prev_length >= e.good_match && (i >>= 2), s > e.lookahead && (s = e.lookahead);
                    do {
                        if (r = t, l[r + o] === p && l[r + o - 1] === d && l[r] === l[a] && l[++r] === l[a + 1]) {
                            a += 2, r++;
                            do {} while (l[++a] === l[++r] && l[++a] === l[++r] && l[++a] === l[++r] && l[++a] === l[++r] && l[++a] === l[++r] && l[++a] === l[++r] && l[++a] === l[++r] && l[++a] === l[++r] && a < f);
                            if (n = Ae - (f - a), a = f - Ae, n > o) {
                                if (e.match_start = t, o = n, n >= s) break;
                                d = l[a + o - 1], p = l[a + o]
                            }
                        }
                    } while ((t = h[t & c]) > u && 0 != --i);
                    return o <= e.lookahead ? o : e.lookahead
                },
                Fe = e => {
                    const t = e.w_size;
                    let r, n, i, a, o;
                    do {
                        if (a = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - Te)) {
                            e.window.set(e.window.subarray(t, t + t), 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, n = e.hash_size, r = n;
                            do {
                                i = e.head[--r], e.head[r] = i >= t ? i - t : 0
                            } while (--n);
                            n = t, r = n;
                            do {
                                i = e.prev[--r], e.prev[r] = i >= t ? i - t : 0
                            } while (--n);
                            a += t
                        }
                        if (0 === e.strm.avail_in) break;
                        if (n = Me(e.strm, e.window, e.strstart + e.lookahead, a), e.lookahead += n, e.lookahead + e.insert >= 3)
                            for (o = e.strstart - e.insert, e.ins_h = e.window[o], e.ins_h = Le(e, e.ins_h, e.window[o + 1]); e.insert && (e.ins_h = Le(e, e.ins_h, e.window[o + 3 - 1]), e.prev[o & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = o, o++, e.insert--, !(e.lookahead + e.insert < 3)););
                    } while (e.lookahead < Te && 0 !== e.strm.avail_in)
                },
                He = (e, t) => {
                    let r, n;
                    for (;;) {
                        if (e.lookahead < Te) {
                            if (Fe(e), e.lookahead < Te && t === ue) return 1;
                            if (0 === e.lookahead) break
                        }
                        if (r = 0, e.lookahead >= 3 && (e.ins_h = Le(e, e.ins_h, e.window[e.strstart + 3 - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), 0 !== r && e.strstart - r <= e.w_size - Te && (e.match_length = Ce(e, r)), e.match_length >= 3)
                            if (n = ne(e, e.strstart - e.match_start, e.match_length - 3), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= 3) {
                                e.match_length--;
                                do {
                                    e.strstart++, e.ins_h = Le(e, e.ins_h, e.window[e.strstart + 3 - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart
                                } while (0 != --e.match_length);
                                e.strstart++
                            } else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = Le(e, e.ins_h, e.window[e.strstart + 1]);
                        else n = ne(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
                        if (n && (Ie(e, !1), 0 === e.strm.avail_out)) return 1
                    }
                    return e.insert = e.strstart < 2 ? e.strstart : 2, t === he ? (Ie(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.last_lit && (Ie(e, !1), 0 === e.strm.avail_out) ? 1 : 2
                },
                Ke = (e, t) => {
                    let r, n, i;
                    for (;;) {
                        if (e.lookahead < Te) {
                            if (Fe(e), e.lookahead < Te && t === ue) return 1;
                            if (0 === e.lookahead) break
                        }
                        if (r = 0, e.lookahead >= 3 && (e.ins_h = Le(e, e.ins_h, e.window[e.strstart + 3 - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = 2, 0 !== r && e.prev_length < e.max_lazy_match && e.strstart - r <= e.w_size - Te && (e.match_length = Ce(e, r), e.match_length <= 5 && (e.strategy === ve || 3 === e.match_length && e.strstart - e.match_start > 4096) && (e.match_length = 2)), e.prev_length >= 3 && e.match_length <= e.prev_length) {
                            i = e.strstart + e.lookahead - 3, n = ne(e, e.strstart - 1 - e.prev_match, e.prev_length - 3), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
                            do {
                                ++e.strstart <= i && (e.ins_h = Le(e, e.ins_h, e.window[e.strstart + 3 - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart)
                            } while (0 != --e.prev_length);
                            if (e.match_available = 0, e.match_length = 2, e.strstart++, n && (Ie(e, !1), 0 === e.strm.avail_out)) return 1
                        } else if (e.match_available) {
                            if (n = ne(e, 0, e.window[e.strstart - 1]), n && Ie(e, !1), e.strstart++, e.lookahead--, 0 === e.strm.avail_out) return 1
                        } else e.match_available = 1, e.strstart++, e.lookahead--
                    }
                    return e.match_available && (n = ne(e, 0, e.window[e.strstart - 1]), e.match_available = 0), e.insert = e.strstart < 2 ? e.strstart : 2, t === he ? (Ie(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.last_lit && (Ie(e, !1), 0 === e.strm.avail_out) ? 1 : 2
                };

            function We(e, t, r, n, i) {
                this.good_length = e, this.max_lazy = t, this.nice_length = r, this.max_chain = n, this.func = i
            }
            const qe = [new We(0, 0, 0, 0, ((e, t) => {
                let r = 65535;
                for (r > e.pending_buf_size - 5 && (r = e.pending_buf_size - 5);;) {
                    if (e.lookahead <= 1) {
                        if (Fe(e), 0 === e.lookahead && t === ue) return 1;
                        if (0 === e.lookahead) break
                    }
                    e.strstart += e.lookahead, e.lookahead = 0;
                    const n = e.block_start + r;
                    if ((0 === e.strstart || e.strstart >= n) && (e.lookahead = e.strstart - n, e.strstart = n, Ie(e, !1), 0 === e.strm.avail_out)) return 1;
                    if (e.strstart - e.block_start >= e.w_size - Te && (Ie(e, !1), 0 === e.strm.avail_out)) return 1
                }
                return e.insert = 0, t === he ? (Ie(e, !0), 0 === e.strm.avail_out ? 3 : 4) : (e.strstart > e.block_start && (Ie(e, !1), e.strm.avail_out), 1)
            })), new We(4, 4, 8, 4, He), new We(4, 5, 16, 8, He), new We(4, 6, 32, 32, He), new We(4, 4, 16, 16, Ke), new We(8, 16, 32, 32, Ke), new We(8, 16, 128, 128, Ke), new We(8, 32, 128, 256, Ke), new We(32, 128, 258, 1024, Ke), new We(32, 258, 258, 4096, Ke)];

            function Ze() {
                this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = Ee, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new Uint16Array(1146), this.dyn_dtree = new Uint16Array(122), this.bl_tree = new Uint16Array(78), De(this.dyn_ltree), De(this.dyn_dtree), De(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new Uint16Array(16), this.heap = new Uint16Array(573), De(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new Uint16Array(573), De(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0
            }
            const Ve = e => {
                    if (!e || !e.state) return Pe(e, _e);
                    e.total_in = e.total_out = 0, e.data_type = Se;
                    const t = e.state;
                    return t.pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap ? 42 : Oe, e.adler = 2 === t.wrap ? 0 : 1, t.last_flush = ue, ee(t), de
                },
                Ge = e => {
                    const t = Ve(e);
                    return t === de && (e => {
                        e.window_size = 2 * e.w_size, De(e.head), e.max_lazy_match = qe[e.level].max_lazy, e.good_match = qe[e.level].good_length, e.nice_match = qe[e.level].nice_length, e.max_chain_length = qe[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = 2, e.match_available = 0, e.ins_h = 0
                    })(e.state), t
                },
                Je = (e, t, r, n, i, a) => {
                    if (!e) return _e;
                    let o = 1;
                    if (t === be && (t = 6), n < 0 ? (o = 0, n = -n) : n > 15 && (o = 2, n -= 16), i < 1 || i > 9 || r !== Ee || n < 8 || n > 15 || t < 0 || t > 9 || a < 0 || a > xe) return Pe(e, _e);
                    8 === n && (n = 9);
                    const s = new Ze;
                    return e.state = s, s.strm = e, s.wrap = o, s.gzhead = null, s.w_bits = n, s.w_size = 1 << s.w_bits, s.w_mask = s.w_size - 1, s.hash_bits = i + 7, s.hash_size = 1 << s.hash_bits, s.hash_mask = s.hash_size - 1, s.hash_shift = ~~((s.hash_bits + 3 - 1) / 3), s.window = new Uint8Array(2 * s.w_size), s.head = new Uint16Array(s.hash_size), s.prev = new Uint16Array(s.w_size), s.lit_bufsize = 1 << i + 6, s.pending_buf_size = 4 * s.lit_bufsize, s.pending_buf = new Uint8Array(s.pending_buf_size), s.d_buf = 1 * s.lit_bufsize, s.l_buf = 3 * s.lit_bufsize, s.level = t, s.strategy = a, s.method = r, Ge(e)
                };
            h.deflateInit = (e, t) => Je(e, t, Ee, 15, 8, ke), h.deflateInit2 = Je, h.deflateReset = Ge, h.deflateResetKeep = Ve, h.deflateSetHeader = (e, t) => e && e.state ? 2 !== e.state.wrap ? _e : (e.state.gzhead = t, de) : _e, h.deflate = (e, t) => {
                let r, n;
                if (!e || !e.state || t > fe || t < 0) return e ? Pe(e, _e) : _e;
                const i = e.state;
                if (!e.output || !e.input && 0 !== e.avail_in || i.status === Re && t !== he) return Pe(e, 0 === e.avail_out ? ge : _e);
                i.strm = e;
                const a = i.last_flush;
                if (i.last_flush = t, 42 === i.status)
                    if (2 === i.wrap) e.adler = 0, Be(i, 31), Be(i, 139), Be(i, 8), i.gzhead ? (Be(i, (i.gzhead.text ? 1 : 0) + (i.gzhead.hcrc ? 2 : 0) + (i.gzhead.extra ? 4 : 0) + (i.gzhead.name ? 8 : 0) + (i.gzhead.comment ? 16 : 0)), Be(i, 255 & i.gzhead.time), Be(i, i.gzhead.time >> 8 & 255), Be(i, i.gzhead.time >> 16 & 255), Be(i, i.gzhead.time >> 24 & 255), Be(i, 9 === i.level ? 2 : i.strategy >= me || i.level < 2 ? 4 : 0), Be(i, 255 & i.gzhead.os), i.gzhead.extra && i.gzhead.extra.length && (Be(i, 255 & i.gzhead.extra.length), Be(i, i.gzhead.extra.length >> 8 & 255)), i.gzhead.hcrc && (e.adler = oe(e.adler, i.pending_buf, i.pending, 0)), i.gzindex = 0, i.status = 69) : (Be(i, 0), Be(i, 0), Be(i, 0), Be(i, 0), Be(i, 0), Be(i, 9 === i.level ? 2 : i.strategy >= me || i.level < 2 ? 4 : 0), Be(i, 3), i.status = Oe);
                    else {
                        let t = Ee + (i.w_bits - 8 << 4) << 8,
                            r = -1;
                        r = i.strategy >= me || i.level < 2 ? 0 : i.level < 6 ? 1 : 6 === i.level ? 2 : 3, t |= r << 6, 0 !== i.strstart && (t |= 32), t += 31 - t % 31, i.status = Oe, je(i, t), 0 !== i.strstart && (je(i, e.adler >>> 16), je(i, 65535 & e.adler)), e.adler = 1
                    }
                if (69 === i.status)
                    if (i.gzhead.extra) {
                        for (r = i.pending; i.gzindex < (65535 & i.gzhead.extra.length) && (i.pending !== i.pending_buf_size || (i.gzhead.hcrc && i.pending > r && (e.adler = oe(e.adler, i.pending_buf, i.pending - r, r)), Ue(e), r = i.pending, i.pending !== i.pending_buf_size));) Be(i, 255 & i.gzhead.extra[i.gzindex]), i.gzindex++;
                        i.gzhead.hcrc && i.pending > r && (e.adler = oe(e.adler, i.pending_buf, i.pending - r, r)), i.gzindex === i.gzhead.extra.length && (i.gzindex = 0, i.status = 73)
                    } else i.status = 73;
                if (73 === i.status)
                    if (i.gzhead.name) {
                        r = i.pending;
                        do {
                            if (i.pending === i.pending_buf_size && (i.gzhead.hcrc && i.pending > r && (e.adler = oe(e.adler, i.pending_buf, i.pending - r, r)), Ue(e), r = i.pending, i.pending === i.pending_buf_size)) {
                                n = 1;
                                break
                            }
                            n = i.gzindex < i.gzhead.name.length ? 255 & i.gzhead.name.charCodeAt(i.gzindex++) : 0, Be(i, n)
                        } while (0 !== n);
                        i.gzhead.hcrc && i.pending > r && (e.adler = oe(e.adler, i.pending_buf, i.pending - r, r)), 0 === n && (i.gzindex = 0, i.status = 91)
                    } else i.status = 91;
                if (91 === i.status)
                    if (i.gzhead.comment) {
                        r = i.pending;
                        do {
                            if (i.pending === i.pending_buf_size && (i.gzhead.hcrc && i.pending > r && (e.adler = oe(e.adler, i.pending_buf, i.pending - r, r)), Ue(e), r = i.pending, i.pending === i.pending_buf_size)) {
                                n = 1;
                                break
                            }
                            n = i.gzindex < i.gzhead.comment.length ? 255 & i.gzhead.comment.charCodeAt(i.gzindex++) : 0, Be(i, n)
                        } while (0 !== n);
                        i.gzhead.hcrc && i.pending > r && (e.adler = oe(e.adler, i.pending_buf, i.pending - r, r)), 0 === n && (i.status = ze)
                    } else i.status = ze;
                if (i.status === ze && (i.gzhead.hcrc ? (i.pending + 2 > i.pending_buf_size && Ue(e), i.pending + 2 <= i.pending_buf_size && (Be(i, 255 & e.adler), Be(i, e.adler >> 8 & 255), e.adler = 0, i.status = Oe)) : i.status = Oe), 0 !== i.pending) {
                    if (Ue(e), 0 === e.avail_out) return i.last_flush = -1, de
                } else if (0 === e.avail_in && Ne(t) <= Ne(a) && t !== he) return Pe(e, ge);
                if (i.status === Re && 0 !== e.avail_in) return Pe(e, ge);
                if (0 !== e.avail_in || 0 !== i.lookahead || t !== ue && i.status !== Re) {
                    let r = i.strategy === me ? ((e, t) => {
                        let r;
                        for (;;) {
                            if (0 === e.lookahead && (Fe(e), 0 === e.lookahead)) {
                                if (t === ue) return 1;
                                break
                            }
                            if (e.match_length = 0, r = ne(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, r && (Ie(e, !1), 0 === e.strm.avail_out)) return 1
                        }
                        return e.insert = 0, t === he ? (Ie(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.last_lit && (Ie(e, !1), 0 === e.strm.avail_out) ? 1 : 2
                    })(i, t) : i.strategy === we ? ((e, t) => {
                        let r, n, i, a;
                        const o = e.window;
                        for (;;) {
                            if (e.lookahead <= Ae) {
                                if (Fe(e), e.lookahead <= Ae && t === ue) return 1;
                                if (0 === e.lookahead) break
                            }
                            if (e.match_length = 0, e.lookahead >= 3 && e.strstart > 0 && (i = e.strstart - 1, n = o[i], n === o[++i] && n === o[++i] && n === o[++i])) {
                                a = e.strstart + Ae;
                                do {} while (n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && i < a);
                                e.match_length = Ae - (a - i), e.match_length > e.lookahead && (e.match_length = e.lookahead)
                            }
                            if (e.match_length >= 3 ? (r = ne(e, 1, e.match_length - 3), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (r = ne(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), r && (Ie(e, !1), 0 === e.strm.avail_out)) return 1
                        }
                        return e.insert = 0, t === he ? (Ie(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.last_lit && (Ie(e, !1), 0 === e.strm.avail_out) ? 1 : 2
                    })(i, t) : qe[i.level].func(i, t);
                    if (3 !== r && 4 !== r || (i.status = Re), 1 === r || 3 === r) return 0 === e.avail_out && (i.last_flush = -1), de;
                    if (2 === r && (t === le ? ie(i) : t !== fe && (te(i, 0, 0, !1), t === ce && (De(i.head), 0 === i.lookahead && (i.strstart = 0, i.block_start = 0, i.insert = 0))), Ue(e), 0 === e.avail_out)) return i.last_flush = -1, de
                }
                return t !== he ? de : i.wrap <= 0 ? pe : (2 === i.wrap ? (Be(i, 255 & e.adler), Be(i, e.adler >> 8 & 255), Be(i, e.adler >> 16 & 255), Be(i, e.adler >> 24 & 255), Be(i, 255 & e.total_in), Be(i, e.total_in >> 8 & 255), Be(i, e.total_in >> 16 & 255), Be(i, e.total_in >> 24 & 255)) : (je(i, e.adler >>> 16), je(i, 65535 & e.adler)), Ue(e), i.wrap > 0 && (i.wrap = -i.wrap), 0 !== i.pending ? de : pe)
            }, h.deflateEnd = e => {
                if (!e || !e.state) return _e;
                const t = e.state.status;
                return 42 !== t && 69 !== t && 73 !== t && 91 !== t && t !== ze && t !== Oe && t !== Re ? Pe(e, _e) : (e.state = null, t === Oe ? Pe(e, ye) : de)
            }, h.deflateSetDictionary = (e, t) => {
                let r = t.length;
                if (!e || !e.state) return _e;
                const n = e.state,
                    i = n.wrap;
                if (2 === i || 1 === i && 42 !== n.status || n.lookahead) return _e;
                if (1 === i && (e.adler = ae(e.adler, t, r, 0)), n.wrap = 0, r >= n.w_size) {
                    0 === i && (De(n.head), n.strstart = 0, n.block_start = 0, n.insert = 0);
                    let e = new Uint8Array(n.w_size);
                    e.set(t.subarray(r - n.w_size, r), 0), t = e, r = n.w_size
                }
                const a = e.avail_in,
                    o = e.next_in,
                    s = e.input;
                for (e.avail_in = r, e.next_in = 0, e.input = t, Fe(n); n.lookahead >= 3;) {
                    let e = n.strstart,
                        t = n.lookahead - 2;
                    do {
                        n.ins_h = Le(n, n.ins_h, n.window[e + 3 - 1]), n.prev[e & n.w_mask] = n.head[n.ins_h], n.head[n.ins_h] = e, e++
                    } while (--t);
                    n.strstart = e, n.lookahead = 2, Fe(n)
                }
                return n.strstart += n.lookahead, n.block_start = n.strstart, n.insert = n.lookahead, n.lookahead = 0, n.match_length = n.prev_length = 2, n.match_available = 0, e.next_in = o, e.input = s, e.avail_in = a, n.wrap = i, de
            }, h.deflateInfo = "pako deflate (from Nodeca project)";
            var Ye = {};
            const $e = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
            Ye.assign = function(e) {
                const t = Array.prototype.slice.call(arguments, 1);
                for (; t.length;) {
                    const r = t.shift();
                    if (r) {
                        if ("object" != typeof r) throw new TypeError(r + "must be non-object");
                        for (const t in r) $e(r, t) && (e[t] = r[t])
                    }
                }
                return e
            }, Ye.flattenChunks = e => {
                let t = 0;
                for (let n = 0, i = e.length; n < i; n++) t += e[n].length;
                const r = new Uint8Array(t);
                for (let n = 0, i = 0, a = e.length; n < a; n++) {
                    let t = e[n];
                    r.set(t, i), i += t.length
                }
                return r
            };
            var Qe = {};
            let Xe = !0;
            try {
                String.fromCharCode.apply(null, new Uint8Array(1))
            } catch (nh) {
                Xe = !1
            }
            const et = new Uint8Array(256);
            for (let e = 0; e < 256; e++) et[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
            et[254] = et[254] = 1, Qe.string2buf = e => {
                let t, r, n, i, a, o = e.length,
                    s = 0;
                for (i = 0; i < o; i++) r = e.charCodeAt(i), 55296 == (64512 & r) && i + 1 < o && (n = e.charCodeAt(i + 1), 56320 == (64512 & n) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++)), s += r < 128 ? 1 : r < 2048 ? 2 : r < 65536 ? 3 : 4;
                for (t = new Uint8Array(s), a = 0, i = 0; a < s; i++) r = e.charCodeAt(i), 55296 == (64512 & r) && i + 1 < o && (n = e.charCodeAt(i + 1), 56320 == (64512 & n) && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++)), r < 128 ? t[a++] = r : r < 2048 ? (t[a++] = 192 | r >>> 6, t[a++] = 128 | 63 & r) : r < 65536 ? (t[a++] = 224 | r >>> 12, t[a++] = 128 | r >>> 6 & 63, t[a++] = 128 | 63 & r) : (t[a++] = 240 | r >>> 18, t[a++] = 128 | r >>> 12 & 63, t[a++] = 128 | r >>> 6 & 63, t[a++] = 128 | 63 & r);
                return t
            }, Qe.buf2string = (e, t) => {
                let r, n;
                const i = t || e.length,
                    a = new Array(2 * i);
                for (n = 0, r = 0; r < i;) {
                    let t = e[r++];
                    if (t < 128) {
                        a[n++] = t;
                        continue
                    }
                    let o = et[t];
                    if (o > 4) a[n++] = 65533, r += o - 1;
                    else {
                        for (t &= 2 === o ? 31 : 3 === o ? 15 : 7; o > 1 && r < i;) t = t << 6 | 63 & e[r++], o--;
                        o > 1 ? a[n++] = 65533 : t < 65536 ? a[n++] = t : (t -= 65536, a[n++] = 55296 | t >> 10 & 1023, a[n++] = 56320 | 1023 & t)
                    }
                }
                return ((e, t) => {
                    if (t < 65534 && e.subarray && Xe) return String.fromCharCode.apply(null, e.length === t ? e : e.subarray(0, t));
                    let r = "";
                    for (let n = 0; n < t; n++) r += String.fromCharCode(e[n]);
                    return r
                })(a, n)
            }, Qe.utf8border = (e, t) => {
                (t = t || e.length) > e.length && (t = e.length);
                let r = t - 1;
                for (; r >= 0 && 128 == (192 & e[r]);) r--;
                return r < 0 || 0 === r ? t : r + et[e[r]] > t ? r : t
            };
            var tt = function() {
                this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0
            };
            const rt = h,
                nt = Ye,
                it = Qe,
                at = Q,
                ot = tt,
                st = Object.prototype.toString,
                {
                    Z_NO_FLUSH: ut,
                    Z_SYNC_FLUSH: lt,
                    Z_FULL_FLUSH: ct,
                    Z_FINISH: ht,
                    Z_OK: ft,
                    Z_STREAM_END: dt,
                    Z_DEFAULT_COMPRESSION: pt,
                    Z_DEFAULT_STRATEGY: _t,
                    Z_DEFLATED: yt
                } = X;

            function gt(e) {
                this.options = nt.assign({
                    level: pt,
                    method: yt,
                    chunkSize: 16384,
                    windowBits: 15,
                    memLevel: 8,
                    strategy: _t
                }, e || {});
                let t = this.options;
                t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new ot, this.strm.avail_out = 0;
                let r = rt.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
                if (r !== ft) throw new Error(at[r]);
                if (t.header && rt.deflateSetHeader(this.strm, t.header), t.dictionary) {
                    let e;
                    if (e = "string" == typeof t.dictionary ? it.string2buf(t.dictionary) : "[object ArrayBuffer]" === st.call(t.dictionary) ? new Uint8Array(t.dictionary) : t.dictionary, r = rt.deflateSetDictionary(this.strm, e), r !== ft) throw new Error(at[r]);
                    this._dict_set = !0
                }
            }

            function bt(e, t) {
                const r = new gt(t);
                if (r.push(e, !0), r.err) throw r.msg || at[r.err];
                return r.result
            }
            gt.prototype.push = function(e, t) {
                const r = this.strm,
                    n = this.options.chunkSize;
                let i, a;
                if (this.ended) return !1;
                for (a = t === ~~t ? t : !0 === t ? ht : ut, "string" == typeof e ? r.input = it.string2buf(e) : "[object ArrayBuffer]" === st.call(e) ? r.input = new Uint8Array(e) : r.input = e, r.next_in = 0, r.avail_in = r.input.length;;)
                    if (0 === r.avail_out && (r.output = new Uint8Array(n), r.next_out = 0, r.avail_out = n), (a === lt || a === ct) && r.avail_out <= 6) this.onData(r.output.subarray(0, r.next_out)), r.avail_out = 0;
                    else {
                        if (i = rt.deflate(r, a), i === dt) return r.next_out > 0 && this.onData(r.output.subarray(0, r.next_out)), i = rt.deflateEnd(this.strm), this.onEnd(i), this.ended = !0, i === ft;
                        if (0 !== r.avail_out) {
                            if (a > 0 && r.next_out > 0) this.onData(r.output.subarray(0, r.next_out)), r.avail_out = 0;
                            else if (0 === r.avail_in) break
                        } else this.onData(r.output)
                    }
                return !0
            }, gt.prototype.onData = function(e) {
                this.chunks.push(e)
            }, gt.prototype.onEnd = function(e) {
                e === ft && (this.result = nt.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg
            }, c.Deflate = gt, c.deflate = bt, c.deflateRaw = function(e, t) {
                return (t = t || {}).raw = !0, bt(e, t)
            }, c.gzip = function(e, t) {
                return (t = t || {}).gzip = !0, bt(e, t)
            }, c.constants = X;
            var vt = {},
                mt = {};
            const wt = 15,
                xt = new Uint16Array([3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0]),
                kt = new Uint8Array([16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78]),
                St = new Uint16Array([1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0]),
                Et = new Uint8Array([16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64]);
            var At = (e, t, r, n, i, a, o, s) => {
                const u = s.bits;
                let l, c, h, f, d, p, _ = 0,
                    y = 0,
                    g = 0,
                    b = 0,
                    v = 0,
                    m = 0,
                    w = 0,
                    x = 0,
                    k = 0,
                    S = 0,
                    E = null,
                    A = 0;
                const T = new Uint16Array(16),
                    z = new Uint16Array(16);
                let O, R, P, N = null,
                    D = 0;
                for (_ = 0; _ <= wt; _++) T[_] = 0;
                for (y = 0; y < n; y++) T[t[r + y]]++;
                for (v = u, b = wt; b >= 1 && 0 === T[b]; b--);
                if (v > b && (v = b), 0 === b) return i[a++] = 20971520, i[a++] = 20971520, s.bits = 1, 0;
                for (g = 1; g < b && 0 === T[g]; g++);
                for (v < g && (v = g), x = 1, _ = 1; _ <= wt; _++)
                    if (x <<= 1, x -= T[_], x < 0) return -1;
                if (x > 0 && (0 === e || 1 !== b)) return -1;
                for (z[1] = 0, _ = 1; _ < wt; _++) z[_ + 1] = z[_] + T[_];
                for (y = 0; y < n; y++) 0 !== t[r + y] && (o[z[t[r + y]]++] = y);
                if (0 === e ? (E = N = o, p = 19) : 1 === e ? (E = xt, A -= 257, N = kt, D -= 257, p = 256) : (E = St, N = Et, p = -1), S = 0, y = 0, _ = g, d = a, m = v, w = 0, h = -1, k = 1 << v, f = k - 1, 1 === e && k > 852 || 2 === e && k > 592) return 1;
                for (;;) {
                    O = _ - w, o[y] < p ? (R = 0, P = o[y]) : o[y] > p ? (R = N[D + o[y]], P = E[A + o[y]]) : (R = 96, P = 0), l = 1 << _ - w, c = 1 << m, g = c;
                    do {
                        c -= l, i[d + (S >> w) + c] = O << 24 | R << 16 | P | 0
                    } while (0 !== c);
                    for (l = 1 << _ - 1; S & l;) l >>= 1;
                    if (0 !== l ? (S &= l - 1, S += l) : S = 0, y++, 0 == --T[_]) {
                        if (_ === b) break;
                        _ = t[r + o[y]]
                    }
                    if (_ > v && (S & f) !== h) {
                        for (0 === w && (w = v), d += g, m = _ - w, x = 1 << m; m + w < b && (x -= T[m + w], !(x <= 0));) m++, x <<= 1;
                        if (k += 1 << m, 1 === e && k > 852 || 2 === e && k > 592) return 1;
                        h = S & f, i[h] = v << 24 | m << 16 | d - a | 0
                    }
                }
                return 0 !== S && (i[d + S] = _ - w << 24 | 64 << 16 | 0), s.bits = v, 0
            };
            const Tt = J,
                zt = $,
                Ot = function(e, t) {
                    let r, n, i, a, o, s, u, l, c, h, f, d, p, _, y, g, b, v, m, w, x, k, S, E;
                    const A = e.state;
                    r = e.next_in, S = e.input, n = r + (e.avail_in - 5), i = e.next_out, E = e.output, a = i - (t - e.avail_out), o = i + (e.avail_out - 257), s = A.dmax, u = A.wsize, l = A.whave, c = A.wnext, h = A.window, f = A.hold, d = A.bits, p = A.lencode, _ = A.distcode, y = (1 << A.lenbits) - 1, g = (1 << A.distbits) - 1;
                    e: do {
                        d < 15 && (f += S[r++] << d, d += 8, f += S[r++] << d, d += 8), b = p[f & y];
                        t: for (;;) {
                            if (v = b >>> 24, f >>>= v, d -= v, v = b >>> 16 & 255, 0 === v) E[i++] = 65535 & b;
                            else {
                                if (!(16 & v)) {
                                    if (0 == (64 & v)) {
                                        b = p[(65535 & b) + (f & (1 << v) - 1)];
                                        continue t
                                    }
                                    if (32 & v) {
                                        A.mode = 12;
                                        break e
                                    }
                                    e.msg = "invalid literal/length code", A.mode = 30;
                                    break e
                                }
                                m = 65535 & b, v &= 15, v && (d < v && (f += S[r++] << d, d += 8), m += f & (1 << v) - 1, f >>>= v, d -= v), d < 15 && (f += S[r++] << d, d += 8, f += S[r++] << d, d += 8), b = _[f & g];
                                r: for (;;) {
                                    if (v = b >>> 24, f >>>= v, d -= v, v = b >>> 16 & 255, !(16 & v)) {
                                        if (0 == (64 & v)) {
                                            b = _[(65535 & b) + (f & (1 << v) - 1)];
                                            continue r
                                        }
                                        e.msg = "invalid distance code", A.mode = 30;
                                        break e
                                    }
                                    if (w = 65535 & b, v &= 15, d < v && (f += S[r++] << d, d += 8, d < v && (f += S[r++] << d, d += 8)), w += f & (1 << v) - 1, w > s) {
                                        e.msg = "invalid distance too far back", A.mode = 30;
                                        break e
                                    }
                                    if (f >>>= v, d -= v, v = i - a, w > v) {
                                        if (v = w - v, v > l && A.sane) {
                                            e.msg = "invalid distance too far back", A.mode = 30;
                                            break e
                                        }
                                        if (x = 0, k = h, 0 === c) {
                                            if (x += u - v, v < m) {
                                                m -= v;
                                                do {
                                                    E[i++] = h[x++]
                                                } while (--v);
                                                x = i - w, k = E
                                            }
                                        } else if (c < v) {
                                            if (x += u + c - v, v -= c, v < m) {
                                                m -= v;
                                                do {
                                                    E[i++] = h[x++]
                                                } while (--v);
                                                if (x = 0, c < m) {
                                                    v = c, m -= v;
                                                    do {
                                                        E[i++] = h[x++]
                                                    } while (--v);
                                                    x = i - w, k = E
                                                }
                                            }
                                        } else if (x += c - v, v < m) {
                                            m -= v;
                                            do {
                                                E[i++] = h[x++]
                                            } while (--v);
                                            x = i - w, k = E
                                        }
                                        for (; m > 2;) E[i++] = k[x++], E[i++] = k[x++], E[i++] = k[x++], m -= 3;
                                        m && (E[i++] = k[x++], m > 1 && (E[i++] = k[x++]))
                                    } else {
                                        x = i - w;
                                        do {
                                            E[i++] = E[x++], E[i++] = E[x++], E[i++] = E[x++], m -= 3
                                        } while (m > 2);
                                        m && (E[i++] = E[x++], m > 1 && (E[i++] = E[x++]))
                                    }
                                    break
                                }
                            }
                            break
                        }
                    } while (r < n && i < o);
                    m = d >> 3, r -= m, d -= m << 3, f &= (1 << d) - 1, e.next_in = r, e.next_out = i, e.avail_in = r < n ? n - r + 5 : 5 - (r - n), e.avail_out = i < o ? o - i + 257 : 257 - (i - o), A.hold = f, A.bits = d
                },
                Rt = At,
                {
                    Z_FINISH: Pt,
                    Z_BLOCK: Nt,
                    Z_TREES: Dt,
                    Z_OK: Lt,
                    Z_STREAM_END: Ut,
                    Z_NEED_DICT: It,
                    Z_STREAM_ERROR: Bt,
                    Z_DATA_ERROR: jt,
                    Z_MEM_ERROR: Mt,
                    Z_BUF_ERROR: Ct,
                    Z_DEFLATED: Ft
                } = X,
                Ht = 12,
                Kt = 30,
                Wt = e => (e >>> 24 & 255) + (e >>> 8 & 65280) + ((65280 & e) << 8) + ((255 & e) << 24);

            function qt() {
                this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new Uint16Array(320), this.work = new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0
            }
            const Zt = e => {
                    if (!e || !e.state) return Bt;
                    const t = e.state;
                    return e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = 1 & t.wrap), t.mode = 1, t.last = 0, t.havedict = 0, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new Int32Array(852), t.distcode = t.distdyn = new Int32Array(592), t.sane = 1, t.back = -1, Lt
                },
                Vt = e => {
                    if (!e || !e.state) return Bt;
                    const t = e.state;
                    return t.wsize = 0, t.whave = 0, t.wnext = 0, Zt(e)
                },
                Gt = (e, t) => {
                    let r;
                    if (!e || !e.state) return Bt;
                    const n = e.state;
                    return t < 0 ? (r = 0, t = -t) : (r = 1 + (t >> 4), t < 48 && (t &= 15)), t && (t < 8 || t > 15) ? Bt : (null !== n.window && n.wbits !== t && (n.window = null), n.wrap = r, n.wbits = t, Vt(e))
                },
                Jt = (e, t) => {
                    if (!e) return Bt;
                    const r = new qt;
                    e.state = r, r.window = null;
                    const n = Gt(e, t);
                    return n !== Lt && (e.state = null), n
                };
            let Yt, $t, Qt = !0;
            const Xt = e => {
                    if (Qt) {
                        Yt = new Int32Array(512), $t = new Int32Array(32);
                        let t = 0;
                        for (; t < 144;) e.lens[t++] = 8;
                        for (; t < 256;) e.lens[t++] = 9;
                        for (; t < 280;) e.lens[t++] = 7;
                        for (; t < 288;) e.lens[t++] = 8;
                        for (Rt(1, e.lens, 0, 288, Yt, 0, e.work, {
                                bits: 9
                            }), t = 0; t < 32;) e.lens[t++] = 5;
                        Rt(2, e.lens, 0, 32, $t, 0, e.work, {
                            bits: 5
                        }), Qt = !1
                    }
                    e.lencode = Yt, e.lenbits = 9, e.distcode = $t, e.distbits = 5
                },
                er = (e, t, r, n) => {
                    let i;
                    const a = e.state;
                    return null === a.window && (a.wsize = 1 << a.wbits, a.wnext = 0, a.whave = 0, a.window = new Uint8Array(a.wsize)), n >= a.wsize ? (a.window.set(t.subarray(r - a.wsize, r), 0), a.wnext = 0, a.whave = a.wsize) : (i = a.wsize - a.wnext, i > n && (i = n), a.window.set(t.subarray(r - n, r - n + i), a.wnext), (n -= i) ? (a.window.set(t.subarray(r - n, r), 0), a.wnext = n, a.whave = a.wsize) : (a.wnext += i, a.wnext === a.wsize && (a.wnext = 0), a.whave < a.wsize && (a.whave += i))), 0
                };
            mt.inflateReset = Vt, mt.inflateReset2 = Gt, mt.inflateResetKeep = Zt, mt.inflateInit = e => Jt(e, 15), mt.inflateInit2 = Jt, mt.inflate = (e, t) => {
                let r, n, i, a, o, s, u, l, c, h, f, d, p, _, y, g, b, v, m, w, x, k, S = 0;
                const E = new Uint8Array(4);
                let A, T;
                const z = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
                if (!e || !e.state || !e.output || !e.input && 0 !== e.avail_in) return Bt;
                r = e.state, r.mode === Ht && (r.mode = 13), o = e.next_out, i = e.output, u = e.avail_out, a = e.next_in, n = e.input, s = e.avail_in, l = r.hold, c = r.bits, h = s, f = u, k = Lt;
                e: for (;;) switch (r.mode) {
                    case 1:
                        if (0 === r.wrap) {
                            r.mode = 13;
                            break
                        }
                        for (; c < 16;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        if (2 & r.wrap && 35615 === l) {
                            r.check = 0, E[0] = 255 & l, E[1] = l >>> 8 & 255, r.check = zt(r.check, E, 2, 0), l = 0, c = 0, r.mode = 2;
                            break
                        }
                        if (r.flags = 0, r.head && (r.head.done = !1), !(1 & r.wrap) || (((255 & l) << 8) + (l >> 8)) % 31) {
                            e.msg = "incorrect header check", r.mode = Kt;
                            break
                        }
                        if ((15 & l) !== Ft) {
                            e.msg = "unknown compression method", r.mode = Kt;
                            break
                        }
                        if (l >>>= 4, c -= 4, x = 8 + (15 & l), 0 === r.wbits) r.wbits = x;
                        else if (x > r.wbits) {
                            e.msg = "invalid window size", r.mode = Kt;
                            break
                        }
                        r.dmax = 1 << r.wbits, e.adler = r.check = 1, r.mode = 512 & l ? 10 : Ht, l = 0, c = 0;
                        break;
                    case 2:
                        for (; c < 16;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        if (r.flags = l, (255 & r.flags) !== Ft) {
                            e.msg = "unknown compression method", r.mode = Kt;
                            break
                        }
                        if (57344 & r.flags) {
                            e.msg = "unknown header flags set", r.mode = Kt;
                            break
                        }
                        r.head && (r.head.text = l >> 8 & 1), 512 & r.flags && (E[0] = 255 & l, E[1] = l >>> 8 & 255, r.check = zt(r.check, E, 2, 0)), l = 0, c = 0, r.mode = 3;
                    case 3:
                        for (; c < 32;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        r.head && (r.head.time = l), 512 & r.flags && (E[0] = 255 & l, E[1] = l >>> 8 & 255, E[2] = l >>> 16 & 255, E[3] = l >>> 24 & 255, r.check = zt(r.check, E, 4, 0)), l = 0, c = 0, r.mode = 4;
                    case 4:
                        for (; c < 16;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        r.head && (r.head.xflags = 255 & l, r.head.os = l >> 8), 512 & r.flags && (E[0] = 255 & l, E[1] = l >>> 8 & 255, r.check = zt(r.check, E, 2, 0)), l = 0, c = 0, r.mode = 5;
                    case 5:
                        if (1024 & r.flags) {
                            for (; c < 16;) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            r.length = l, r.head && (r.head.extra_len = l), 512 & r.flags && (E[0] = 255 & l, E[1] = l >>> 8 & 255, r.check = zt(r.check, E, 2, 0)), l = 0, c = 0
                        } else r.head && (r.head.extra = null);
                        r.mode = 6;
                    case 6:
                        if (1024 & r.flags && (d = r.length, d > s && (d = s), d && (r.head && (x = r.head.extra_len - r.length, r.head.extra || (r.head.extra = new Uint8Array(r.head.extra_len)), r.head.extra.set(n.subarray(a, a + d), x)), 512 & r.flags && (r.check = zt(r.check, n, d, a)), s -= d, a += d, r.length -= d), r.length)) break e;
                        r.length = 0, r.mode = 7;
                    case 7:
                        if (2048 & r.flags) {
                            if (0 === s) break e;
                            d = 0;
                            do {
                                x = n[a + d++], r.head && x && r.length < 65536 && (r.head.name += String.fromCharCode(x))
                            } while (x && d < s);
                            if (512 & r.flags && (r.check = zt(r.check, n, d, a)), s -= d, a += d, x) break e
                        } else r.head && (r.head.name = null);
                        r.length = 0, r.mode = 8;
                    case 8:
                        if (4096 & r.flags) {
                            if (0 === s) break e;
                            d = 0;
                            do {
                                x = n[a + d++], r.head && x && r.length < 65536 && (r.head.comment += String.fromCharCode(x))
                            } while (x && d < s);
                            if (512 & r.flags && (r.check = zt(r.check, n, d, a)), s -= d, a += d, x) break e
                        } else r.head && (r.head.comment = null);
                        r.mode = 9;
                    case 9:
                        if (512 & r.flags) {
                            for (; c < 16;) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            if (l !== (65535 & r.check)) {
                                e.msg = "header crc mismatch", r.mode = Kt;
                                break
                            }
                            l = 0, c = 0
                        }
                        r.head && (r.head.hcrc = r.flags >> 9 & 1, r.head.done = !0), e.adler = r.check = 0, r.mode = Ht;
                        break;
                    case 10:
                        for (; c < 32;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        e.adler = r.check = Wt(l), l = 0, c = 0, r.mode = 11;
                    case 11:
                        if (0 === r.havedict) return e.next_out = o, e.avail_out = u, e.next_in = a, e.avail_in = s, r.hold = l, r.bits = c, It;
                        e.adler = r.check = 1, r.mode = Ht;
                    case Ht:
                        if (t === Nt || t === Dt) break e;
                    case 13:
                        if (r.last) {
                            l >>>= 7 & c, c -= 7 & c, r.mode = 27;
                            break
                        }
                        for (; c < 3;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        switch (r.last = 1 & l, l >>>= 1, c -= 1, 3 & l) {
                            case 0:
                                r.mode = 14;
                                break;
                            case 1:
                                if (Xt(r), r.mode = 20, t === Dt) {
                                    l >>>= 2, c -= 2;
                                    break e
                                }
                                break;
                            case 2:
                                r.mode = 17;
                                break;
                            case 3:
                                e.msg = "invalid block type", r.mode = Kt
                        }
                        l >>>= 2, c -= 2;
                        break;
                    case 14:
                        for (l >>>= 7 & c, c -= 7 & c; c < 32;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        if ((65535 & l) != (l >>> 16 ^ 65535)) {
                            e.msg = "invalid stored block lengths", r.mode = Kt;
                            break
                        }
                        if (r.length = 65535 & l, l = 0, c = 0, r.mode = 15, t === Dt) break e;
                    case 15:
                        r.mode = 16;
                    case 16:
                        if (d = r.length, d) {
                            if (d > s && (d = s), d > u && (d = u), 0 === d) break e;
                            i.set(n.subarray(a, a + d), o), s -= d, a += d, u -= d, o += d, r.length -= d;
                            break
                        }
                        r.mode = Ht;
                        break;
                    case 17:
                        for (; c < 14;) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        if (r.nlen = 257 + (31 & l), l >>>= 5, c -= 5, r.ndist = 1 + (31 & l), l >>>= 5, c -= 5, r.ncode = 4 + (15 & l), l >>>= 4, c -= 4, r.nlen > 286 || r.ndist > 30) {
                            e.msg = "too many length or distance symbols", r.mode = Kt;
                            break
                        }
                        r.have = 0, r.mode = 18;
                    case 18:
                        for (; r.have < r.ncode;) {
                            for (; c < 3;) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            r.lens[z[r.have++]] = 7 & l, l >>>= 3, c -= 3
                        }
                        for (; r.have < 19;) r.lens[z[r.have++]] = 0;
                        if (r.lencode = r.lendyn, r.lenbits = 7, A = {
                                bits: r.lenbits
                            }, k = Rt(0, r.lens, 0, 19, r.lencode, 0, r.work, A), r.lenbits = A.bits, k) {
                            e.msg = "invalid code lengths set", r.mode = Kt;
                            break
                        }
                        r.have = 0, r.mode = 19;
                    case 19:
                        for (; r.have < r.nlen + r.ndist;) {
                            for (; S = r.lencode[l & (1 << r.lenbits) - 1], y = S >>> 24, g = S >>> 16 & 255, b = 65535 & S, !(y <= c);) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            if (b < 16) l >>>= y, c -= y, r.lens[r.have++] = b;
                            else {
                                if (16 === b) {
                                    for (T = y + 2; c < T;) {
                                        if (0 === s) break e;
                                        s--, l += n[a++] << c, c += 8
                                    }
                                    if (l >>>= y, c -= y, 0 === r.have) {
                                        e.msg = "invalid bit length repeat", r.mode = Kt;
                                        break
                                    }
                                    x = r.lens[r.have - 1], d = 3 + (3 & l), l >>>= 2, c -= 2
                                } else if (17 === b) {
                                    for (T = y + 3; c < T;) {
                                        if (0 === s) break e;
                                        s--, l += n[a++] << c, c += 8
                                    }
                                    l >>>= y, c -= y, x = 0, d = 3 + (7 & l), l >>>= 3, c -= 3
                                } else {
                                    for (T = y + 7; c < T;) {
                                        if (0 === s) break e;
                                        s--, l += n[a++] << c, c += 8
                                    }
                                    l >>>= y, c -= y, x = 0, d = 11 + (127 & l), l >>>= 7, c -= 7
                                }
                                if (r.have + d > r.nlen + r.ndist) {
                                    e.msg = "invalid bit length repeat", r.mode = Kt;
                                    break
                                }
                                for (; d--;) r.lens[r.have++] = x
                            }
                        }
                        if (r.mode === Kt) break;
                        if (0 === r.lens[256]) {
                            e.msg = "invalid code -- missing end-of-block", r.mode = Kt;
                            break
                        }
                        if (r.lenbits = 9, A = {
                                bits: r.lenbits
                            }, k = Rt(1, r.lens, 0, r.nlen, r.lencode, 0, r.work, A), r.lenbits = A.bits, k) {
                            e.msg = "invalid literal/lengths set", r.mode = Kt;
                            break
                        }
                        if (r.distbits = 6, r.distcode = r.distdyn, A = {
                                bits: r.distbits
                            }, k = Rt(2, r.lens, r.nlen, r.ndist, r.distcode, 0, r.work, A), r.distbits = A.bits, k) {
                            e.msg = "invalid distances set", r.mode = Kt;
                            break
                        }
                        if (r.mode = 20, t === Dt) break e;
                    case 20:
                        r.mode = 21;
                    case 21:
                        if (s >= 6 && u >= 258) {
                            e.next_out = o, e.avail_out = u, e.next_in = a, e.avail_in = s, r.hold = l, r.bits = c, Ot(e, f), o = e.next_out, i = e.output, u = e.avail_out, a = e.next_in, n = e.input, s = e.avail_in, l = r.hold, c = r.bits, r.mode === Ht && (r.back = -1);
                            break
                        }
                        for (r.back = 0; S = r.lencode[l & (1 << r.lenbits) - 1], y = S >>> 24, g = S >>> 16 & 255, b = 65535 & S, !(y <= c);) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        if (g && 0 == (240 & g)) {
                            for (v = y, m = g, w = b; S = r.lencode[w + ((l & (1 << v + m) - 1) >> v)], y = S >>> 24, g = S >>> 16 & 255, b = 65535 & S, !(v + y <= c);) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            l >>>= v, c -= v, r.back += v
                        }
                        if (l >>>= y, c -= y, r.back += y, r.length = b, 0 === g) {
                            r.mode = 26;
                            break
                        }
                        if (32 & g) {
                            r.back = -1, r.mode = Ht;
                            break
                        }
                        if (64 & g) {
                            e.msg = "invalid literal/length code", r.mode = Kt;
                            break
                        }
                        r.extra = 15 & g, r.mode = 22;
                    case 22:
                        if (r.extra) {
                            for (T = r.extra; c < T;) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            r.length += l & (1 << r.extra) - 1, l >>>= r.extra, c -= r.extra, r.back += r.extra
                        }
                        r.was = r.length, r.mode = 23;
                    case 23:
                        for (; S = r.distcode[l & (1 << r.distbits) - 1], y = S >>> 24, g = S >>> 16 & 255, b = 65535 & S, !(y <= c);) {
                            if (0 === s) break e;
                            s--, l += n[a++] << c, c += 8
                        }
                        if (0 == (240 & g)) {
                            for (v = y, m = g, w = b; S = r.distcode[w + ((l & (1 << v + m) - 1) >> v)], y = S >>> 24, g = S >>> 16 & 255, b = 65535 & S, !(v + y <= c);) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            l >>>= v, c -= v, r.back += v
                        }
                        if (l >>>= y, c -= y, r.back += y, 64 & g) {
                            e.msg = "invalid distance code", r.mode = Kt;
                            break
                        }
                        r.offset = b, r.extra = 15 & g, r.mode = 24;
                    case 24:
                        if (r.extra) {
                            for (T = r.extra; c < T;) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            r.offset += l & (1 << r.extra) - 1, l >>>= r.extra, c -= r.extra, r.back += r.extra
                        }
                        if (r.offset > r.dmax) {
                            e.msg = "invalid distance too far back", r.mode = Kt;
                            break
                        }
                        r.mode = 25;
                    case 25:
                        if (0 === u) break e;
                        if (d = f - u, r.offset > d) {
                            if (d = r.offset - d, d > r.whave && r.sane) {
                                e.msg = "invalid distance too far back", r.mode = Kt;
                                break
                            }
                            d > r.wnext ? (d -= r.wnext, p = r.wsize - d) : p = r.wnext - d, d > r.length && (d = r.length), _ = r.window
                        } else _ = i, p = o - r.offset, d = r.length;
                        d > u && (d = u), u -= d, r.length -= d;
                        do {
                            i[o++] = _[p++]
                        } while (--d);
                        0 === r.length && (r.mode = 21);
                        break;
                    case 26:
                        if (0 === u) break e;
                        i[o++] = r.length, u--, r.mode = 21;
                        break;
                    case 27:
                        if (r.wrap) {
                            for (; c < 32;) {
                                if (0 === s) break e;
                                s--, l |= n[a++] << c, c += 8
                            }
                            if (f -= u, e.total_out += f, r.total += f, f && (e.adler = r.check = r.flags ? zt(r.check, i, f, o - f) : Tt(r.check, i, f, o - f)), f = u, (r.flags ? l : Wt(l)) !== r.check) {
                                e.msg = "incorrect data check", r.mode = Kt;
                                break
                            }
                            l = 0, c = 0
                        }
                        r.mode = 28;
                    case 28:
                        if (r.wrap && r.flags) {
                            for (; c < 32;) {
                                if (0 === s) break e;
                                s--, l += n[a++] << c, c += 8
                            }
                            if (l !== (4294967295 & r.total)) {
                                e.msg = "incorrect length check", r.mode = Kt;
                                break
                            }
                            l = 0, c = 0
                        }
                        r.mode = 29;
                    case 29:
                        k = Ut;
                        break e;
                    case Kt:
                        k = jt;
                        break e;
                    case 31:
                        return Mt;
                    default:
                        return Bt
                }
                return e.next_out = o, e.avail_out = u, e.next_in = a, e.avail_in = s, r.hold = l, r.bits = c, (r.wsize || f !== e.avail_out && r.mode < Kt && (r.mode < 27 || t !== Pt)) && er(e, e.output, e.next_out, f - e.avail_out), h -= e.avail_in, f -= e.avail_out, e.total_in += h, e.total_out += f, r.total += f, r.wrap && f && (e.adler = r.check = r.flags ? zt(r.check, i, f, e.next_out - f) : Tt(r.check, i, f, e.next_out - f)), e.data_type = r.bits + (r.last ? 64 : 0) + (r.mode === Ht ? 128 : 0) + (20 === r.mode || 15 === r.mode ? 256 : 0), (0 === h && 0 === f || t === Pt) && k === Lt && (k = Ct), k
            }, mt.inflateEnd = e => {
                if (!e || !e.state) return Bt;
                let t = e.state;
                return t.window && (t.window = null), e.state = null, Lt
            }, mt.inflateGetHeader = (e, t) => {
                if (!e || !e.state) return Bt;
                const r = e.state;
                return 0 == (2 & r.wrap) ? Bt : (r.head = t, t.done = !1, Lt)
            }, mt.inflateSetDictionary = (e, t) => {
                const r = t.length;
                let n, i, a;
                return e && e.state ? (n = e.state, 0 !== n.wrap && 11 !== n.mode ? Bt : 11 === n.mode && (i = 1, i = Tt(i, t, r, 0), i !== n.check) ? jt : (a = er(e, t, r, r), a ? (n.mode = 31, Mt) : (n.havedict = 1, Lt))) : Bt
            }, mt.inflateInfo = "pako inflate (from Nodeca project)";
            const tr = mt,
                rr = Ye,
                nr = Qe,
                ir = Q,
                ar = tt,
                or = function() {
                    this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1
                },
                sr = Object.prototype.toString,
                {
                    Z_NO_FLUSH: ur,
                    Z_FINISH: lr,
                    Z_OK: cr,
                    Z_STREAM_END: hr,
                    Z_NEED_DICT: fr,
                    Z_STREAM_ERROR: dr,
                    Z_DATA_ERROR: pr,
                    Z_MEM_ERROR: _r
                } = X;

            function yr(e) {
                this.options = rr.assign({
                    chunkSize: 65536,
                    windowBits: 15,
                    to: ""
                }, e || {});
                const t = this.options;
                t.raw && t.windowBits >= 0 && t.windowBits < 16 && (t.windowBits = -t.windowBits, 0 === t.windowBits && (t.windowBits = -15)), !(t.windowBits >= 0 && t.windowBits < 16) || e && e.windowBits || (t.windowBits += 32), t.windowBits > 15 && t.windowBits < 48 && 0 == (15 & t.windowBits) && (t.windowBits |= 15), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new ar, this.strm.avail_out = 0;
                let r = tr.inflateInit2(this.strm, t.windowBits);
                if (r !== cr) throw new Error(ir[r]);
                if (this.header = new or, tr.inflateGetHeader(this.strm, this.header), t.dictionary && ("string" == typeof t.dictionary ? t.dictionary = nr.string2buf(t.dictionary) : "[object ArrayBuffer]" === sr.call(t.dictionary) && (t.dictionary = new Uint8Array(t.dictionary)), t.raw && (r = tr.inflateSetDictionary(this.strm, t.dictionary), r !== cr))) throw new Error(ir[r])
            }

            function gr(e, t) {
                const r = new yr(t);
                if (r.push(e), r.err) throw r.msg || ir[r.err];
                return r.result
            }
            yr.prototype.push = function(e, t) {
                const r = this.strm,
                    n = this.options.chunkSize,
                    i = this.options.dictionary;
                let a, o, s;
                if (this.ended) return !1;
                for (o = t === ~~t ? t : !0 === t ? lr : ur, "[object ArrayBuffer]" === sr.call(e) ? r.input = new Uint8Array(e) : r.input = e, r.next_in = 0, r.avail_in = r.input.length;;) {
                    for (0 === r.avail_out && (r.output = new Uint8Array(n), r.next_out = 0, r.avail_out = n), a = tr.inflate(r, o), a === fr && i && (a = tr.inflateSetDictionary(r, i), a === cr ? a = tr.inflate(r, o) : a === pr && (a = fr)); r.avail_in > 0 && a === hr && r.state.wrap > 0 && 0 !== e[r.next_in];) tr.inflateReset(r), a = tr.inflate(r, o);
                    switch (a) {
                        case dr:
                        case pr:
                        case fr:
                        case _r:
                            return this.onEnd(a), this.ended = !0, !1
                    }
                    if (s = r.avail_out, r.next_out && (0 === r.avail_out || a === hr))
                        if ("string" === this.options.to) {
                            let e = nr.utf8border(r.output, r.next_out),
                                t = r.next_out - e,
                                i = nr.buf2string(r.output, e);
                            r.next_out = t, r.avail_out = n - t, t && r.output.set(r.output.subarray(e, e + t), 0), this.onData(i)
                        } else this.onData(r.output.length === r.next_out ? r.output : r.output.subarray(0, r.next_out));
                    if (a !== cr || 0 !== s) {
                        if (a === hr) return a = tr.inflateEnd(this.strm), this.onEnd(a), this.ended = !0, !0;
                        if (0 === r.avail_in) break
                    }
                }
                return !0
            }, yr.prototype.onData = function(e) {
                this.chunks.push(e)
            }, yr.prototype.onEnd = function(e) {
                e === cr && ("string" === this.options.to ? this.result = this.chunks.join("") : this.result = rr.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg
            }, vt.Inflate = yr, vt.inflate = gr, vt.inflateRaw = function(e, t) {
                return (t = t || {}).raw = !0, gr(e, t)
            }, vt.ungzip = gr, vt.constants = X;
            const {
                Deflate: br,
                deflate: vr,
                deflateRaw: mr,
                gzip: wr
            } = c, {
                Inflate: xr,
                inflate: kr,
                inflateRaw: Sr,
                ungzip: Er
            } = vt, Ar = X;
            l.Deflate = br, l.deflate = vr, l.deflateRaw = mr, l.gzip = wr, l.Inflate = xr, l.inflate = kr, l.inflateRaw = Sr, l.ungzip = Er, l.constants = Ar;
            var Tr = {},
                zr = {},
                Or = {},
                Rr = {},
                Pr = Nr;

            function Nr(e, t) {
                if (!e) throw new Error(t || "Assertion failed")
            }
            Nr.equal = function(e, t, r) {
                if (e != t) throw new Error(r || "Assertion failed: " + e + " != " + t)
            };
            var Dr = {
                exports: {}
            };
            "function" == typeof Object.create ? Dr.exports = function(e, t) {
                t && (e.super_ = t, e.prototype = Object.create(t.prototype, {
                    constructor: {
                        value: e,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }))
            } : Dr.exports = function(e, t) {
                if (t) {
                    e.super_ = t;
                    var r = function() {};
                    r.prototype = t.prototype, e.prototype = new r, e.prototype.constructor = e
                }
            };
            var Lr = Pr,
                Ur = Dr.exports;

            function Ir(e, t) {
                return 55296 == (64512 & e.charCodeAt(t)) && !(t < 0 || t + 1 >= e.length) && 56320 == (64512 & e.charCodeAt(t + 1))
            }

            function Br(e) {
                return (e >>> 24 | e >>> 8 & 65280 | e << 8 & 16711680 | (255 & e) << 24) >>> 0
            }

            function jr(e) {
                return 1 === e.length ? "0" + e : e
            }

            function Mr(e) {
                return 7 === e.length ? "0" + e : 6 === e.length ? "00" + e : 5 === e.length ? "000" + e : 4 === e.length ? "0000" + e : 3 === e.length ? "00000" + e : 2 === e.length ? "000000" + e : 1 === e.length ? "0000000" + e : e
            }
            Rr.inherits = Ur, Rr.toArray = function(e, t) {
                if (Array.isArray(e)) return e.slice();
                if (!e) return [];
                var r = [];
                if ("string" == typeof e)
                    if (t) {
                        if ("hex" === t)
                            for ((e = e.replace(/[^a-z0-9]+/gi, "")).length % 2 != 0 && (e = "0" + e), i = 0; i < e.length; i += 2) r.push(parseInt(e[i] + e[i + 1], 16))
                    } else
                        for (var n = 0, i = 0; i < e.length; i++) {
                            var a = e.charCodeAt(i);
                            a < 128 ? r[n++] = a : a < 2048 ? (r[n++] = a >> 6 | 192, r[n++] = 63 & a | 128) : Ir(e, i) ? (a = 65536 + ((1023 & a) << 10) + (1023 & e.charCodeAt(++i)), r[n++] = a >> 18 | 240, r[n++] = a >> 12 & 63 | 128, r[n++] = a >> 6 & 63 | 128, r[n++] = 63 & a | 128) : (r[n++] = a >> 12 | 224, r[n++] = a >> 6 & 63 | 128, r[n++] = 63 & a | 128)
                        } else
                            for (i = 0; i < e.length; i++) r[i] = 0 | e[i];
                return r
            }, Rr.toHex = function(e) {
                for (var t = "", r = 0; r < e.length; r++) t += jr(e[r].toString(16));
                return t
            }, Rr.htonl = Br, Rr.toHex32 = function(e, t) {
                for (var r = "", n = 0; n < e.length; n++) {
                    var i = e[n];
                    "little" === t && (i = Br(i)), r += Mr(i.toString(16))
                }
                return r
            }, Rr.zero2 = jr, Rr.zero8 = Mr, Rr.join32 = function(e, t, r, n) {
                var i = r - t;
                Lr(i % 4 == 0);
                for (var a = new Array(i / 4), o = 0, s = t; o < a.length; o++, s += 4) {
                    var u;
                    u = "big" === n ? e[s] << 24 | e[s + 1] << 16 | e[s + 2] << 8 | e[s + 3] : e[s + 3] << 24 | e[s + 2] << 16 | e[s + 1] << 8 | e[s], a[o] = u >>> 0
                }
                return a
            }, Rr.split32 = function(e, t) {
                for (var r = new Array(4 * e.length), n = 0, i = 0; n < e.length; n++, i += 4) {
                    var a = e[n];
                    "big" === t ? (r[i] = a >>> 24, r[i + 1] = a >>> 16 & 255, r[i + 2] = a >>> 8 & 255, r[i + 3] = 255 & a) : (r[i + 3] = a >>> 24, r[i + 2] = a >>> 16 & 255, r[i + 1] = a >>> 8 & 255, r[i] = 255 & a)
                }
                return r
            }, Rr.rotr32 = function(e, t) {
                return e >>> t | e << 32 - t
            }, Rr.rotl32 = function(e, t) {
                return e << t | e >>> 32 - t
            }, Rr.sum32 = function(e, t) {
                return e + t >>> 0
            }, Rr.sum32_3 = function(e, t, r) {
                return e + t + r >>> 0
            }, Rr.sum32_4 = function(e, t, r, n) {
                return e + t + r + n >>> 0
            }, Rr.sum32_5 = function(e, t, r, n, i) {
                return e + t + r + n + i >>> 0
            }, Rr.sum64 = function(e, t, r, n) {
                var i = e[t],
                    a = n + e[t + 1] >>> 0,
                    o = (a < n ? 1 : 0) + r + i;
                e[t] = o >>> 0, e[t + 1] = a
            }, Rr.sum64_hi = function(e, t, r, n) {
                return (t + n >>> 0 < t ? 1 : 0) + e + r >>> 0
            }, Rr.sum64_lo = function(e, t, r, n) {
                return t + n >>> 0
            }, Rr.sum64_4_hi = function(e, t, r, n, i, a, o, s) {
                var u = 0,
                    l = t;
                return u += (l = l + n >>> 0) < t ? 1 : 0, u += (l = l + a >>> 0) < a ? 1 : 0, e + r + i + o + (u += (l = l + s >>> 0) < s ? 1 : 0) >>> 0
            }, Rr.sum64_4_lo = function(e, t, r, n, i, a, o, s) {
                return t + n + a + s >>> 0
            }, Rr.sum64_5_hi = function(e, t, r, n, i, a, o, s, u, l) {
                var c = 0,
                    h = t;
                return c += (h = h + n >>> 0) < t ? 1 : 0, c += (h = h + a >>> 0) < a ? 1 : 0, c += (h = h + s >>> 0) < s ? 1 : 0, e + r + i + o + u + (c += (h = h + l >>> 0) < l ? 1 : 0) >>> 0
            }, Rr.sum64_5_lo = function(e, t, r, n, i, a, o, s, u, l) {
                return t + n + a + s + l >>> 0
            }, Rr.rotr64_hi = function(e, t, r) {
                return (t << 32 - r | e >>> r) >>> 0
            }, Rr.rotr64_lo = function(e, t, r) {
                return (e << 32 - r | t >>> r) >>> 0
            }, Rr.shr64_hi = function(e, t, r) {
                return e >>> r
            }, Rr.shr64_lo = function(e, t, r) {
                return (e << 32 - r | t >>> r) >>> 0
            };
            var Cr = {},
                Fr = Rr,
                Hr = Pr;

            function Kr() {
                this.pending = null, this.pendingTotal = 0, this.blockSize = this.constructor.blockSize, this.outSize = this.constructor.outSize, this.hmacStrength = this.constructor.hmacStrength, this.padLength = this.constructor.padLength / 8, this.endian = "big", this._delta8 = this.blockSize / 8, this._delta32 = this.blockSize / 32
            }
            Cr.BlockHash = Kr, Kr.prototype.update = function(e, t) {
                if (e = Fr.toArray(e, t), this.pending ? this.pending = this.pending.concat(e) : this.pending = e, this.pendingTotal += e.length, this.pending.length >= this._delta8) {
                    var r = (e = this.pending).length % this._delta8;
                    this.pending = e.slice(e.length - r, e.length), 0 === this.pending.length && (this.pending = null), e = Fr.join32(e, 0, e.length - r, this.endian);
                    for (var n = 0; n < e.length; n += this._delta32) this._update(e, n, n + this._delta32)
                }
                return this
            }, Kr.prototype.digest = function(e) {
                return this.update(this._pad()), Hr(null === this.pending), this._digest(e)
            }, Kr.prototype._pad = function() {
                var e = this.pendingTotal,
                    t = this._delta8,
                    r = t - (e + this.padLength) % t,
                    n = new Array(r + this.padLength);
                n[0] = 128;
                for (var i = 1; i < r; i++) n[i] = 0;
                if (e <<= 3, "big" === this.endian) {
                    for (var a = 8; a < this.padLength; a++) n[i++] = 0;
                    n[i++] = 0, n[i++] = 0, n[i++] = 0, n[i++] = 0, n[i++] = e >>> 24 & 255, n[i++] = e >>> 16 & 255, n[i++] = e >>> 8 & 255, n[i++] = 255 & e
                } else
                    for (n[i++] = 255 & e, n[i++] = e >>> 8 & 255, n[i++] = e >>> 16 & 255, n[i++] = e >>> 24 & 255, n[i++] = 0, n[i++] = 0, n[i++] = 0, n[i++] = 0, a = 8; a < this.padLength; a++) n[i++] = 0;
                return n
            };
            var Wr = {},
                qr = {},
                Zr = Rr.rotr32;

            function Vr(e, t, r) {
                return e & t ^ ~e & r
            }

            function Gr(e, t, r) {
                return e & t ^ e & r ^ t & r
            }

            function Jr(e, t, r) {
                return e ^ t ^ r
            }
            qr.ft_1 = function(e, t, r, n) {
                return 0 === e ? Vr(t, r, n) : 1 === e || 3 === e ? Jr(t, r, n) : 2 === e ? Gr(t, r, n) : void 0
            }, qr.ch32 = Vr, qr.maj32 = Gr, qr.p32 = Jr, qr.s0_256 = function(e) {
                return Zr(e, 2) ^ Zr(e, 13) ^ Zr(e, 22)
            }, qr.s1_256 = function(e) {
                return Zr(e, 6) ^ Zr(e, 11) ^ Zr(e, 25)
            }, qr.g0_256 = function(e) {
                return Zr(e, 7) ^ Zr(e, 18) ^ e >>> 3
            }, qr.g1_256 = function(e) {
                return Zr(e, 17) ^ Zr(e, 19) ^ e >>> 10
            };
            var Yr = Rr,
                $r = Cr,
                Qr = qr,
                Xr = Yr.rotl32,
                en = Yr.sum32,
                tn = Yr.sum32_5,
                rn = Qr.ft_1,
                nn = $r.BlockHash,
                an = [1518500249, 1859775393, 2400959708, 3395469782];

            function on() {
                if (!(this instanceof on)) return new on;
                nn.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.W = new Array(80)
            }
            Yr.inherits(on, nn);
            var sn = on;
            on.blockSize = 512, on.outSize = 160, on.hmacStrength = 80, on.padLength = 64, on.prototype._update = function(e, t) {
                for (var r = this.W, n = 0; n < 16; n++) r[n] = e[t + n];
                for (; n < r.length; n++) r[n] = Xr(r[n - 3] ^ r[n - 8] ^ r[n - 14] ^ r[n - 16], 1);
                var i = this.h[0],
                    a = this.h[1],
                    o = this.h[2],
                    s = this.h[3],
                    u = this.h[4];
                for (n = 0; n < r.length; n++) {
                    var l = ~~(n / 20),
                        c = tn(Xr(i, 5), rn(l, a, o, s), u, r[n], an[l]);
                    u = s, s = o, o = Xr(a, 30), a = i, i = c
                }
                this.h[0] = en(this.h[0], i), this.h[1] = en(this.h[1], a), this.h[2] = en(this.h[2], o), this.h[3] = en(this.h[3], s), this.h[4] = en(this.h[4], u)
            }, on.prototype._digest = function(e) {
                return "hex" === e ? Yr.toHex32(this.h, "big") : Yr.split32(this.h, "big")
            };
            var un = Rr,
                ln = Cr,
                cn = qr,
                hn = Pr,
                fn = un.sum32,
                dn = un.sum32_4,
                pn = un.sum32_5,
                _n = cn.ch32,
                yn = cn.maj32,
                gn = cn.s0_256,
                bn = cn.s1_256,
                vn = cn.g0_256,
                mn = cn.g1_256,
                wn = ln.BlockHash,
                xn = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];

            function kn() {
                if (!(this instanceof kn)) return new kn;
                wn.call(this), this.h = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225], this.k = xn, this.W = new Array(64)
            }
            un.inherits(kn, wn);
            var Sn = kn;
            kn.blockSize = 512, kn.outSize = 256, kn.hmacStrength = 192, kn.padLength = 64, kn.prototype._update = function(e, t) {
                for (var r = this.W, n = 0; n < 16; n++) r[n] = e[t + n];
                for (; n < r.length; n++) r[n] = dn(mn(r[n - 2]), r[n - 7], vn(r[n - 15]), r[n - 16]);
                var i = this.h[0],
                    a = this.h[1],
                    o = this.h[2],
                    s = this.h[3],
                    u = this.h[4],
                    l = this.h[5],
                    c = this.h[6],
                    h = this.h[7];
                for (hn(this.k.length === r.length), n = 0; n < r.length; n++) {
                    var f = pn(h, bn(u), _n(u, l, c), this.k[n], r[n]),
                        d = fn(gn(i), yn(i, a, o));
                    h = c, c = l, l = u, u = fn(s, f), s = o, o = a, a = i, i = fn(f, d)
                }
                this.h[0] = fn(this.h[0], i), this.h[1] = fn(this.h[1], a), this.h[2] = fn(this.h[2], o), this.h[3] = fn(this.h[3], s), this.h[4] = fn(this.h[4], u), this.h[5] = fn(this.h[5], l), this.h[6] = fn(this.h[6], c), this.h[7] = fn(this.h[7], h)
            }, kn.prototype._digest = function(e) {
                return "hex" === e ? un.toHex32(this.h, "big") : un.split32(this.h, "big")
            };
            var En = Rr,
                An = Sn;

            function Tn() {
                if (!(this instanceof Tn)) return new Tn;
                An.call(this), this.h = [3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428]
            }
            En.inherits(Tn, An);
            var zn = Tn;
            Tn.blockSize = 512, Tn.outSize = 224, Tn.hmacStrength = 192, Tn.padLength = 64, Tn.prototype._digest = function(e) {
                return "hex" === e ? En.toHex32(this.h.slice(0, 7), "big") : En.split32(this.h.slice(0, 7), "big")
            };
            var On = Rr,
                Rn = Cr,
                Pn = Pr,
                Nn = On.rotr64_hi,
                Dn = On.rotr64_lo,
                Ln = On.shr64_hi,
                Un = On.shr64_lo,
                In = On.sum64,
                Bn = On.sum64_hi,
                jn = On.sum64_lo,
                Mn = On.sum64_4_hi,
                Cn = On.sum64_4_lo,
                Fn = On.sum64_5_hi,
                Hn = On.sum64_5_lo,
                Kn = Rn.BlockHash,
                Wn = [1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591];

            function qn() {
                if (!(this instanceof qn)) return new qn;
                Kn.call(this), this.h = [1779033703, 4089235720, 3144134277, 2227873595, 1013904242, 4271175723, 2773480762, 1595750129, 1359893119, 2917565137, 2600822924, 725511199, 528734635, 4215389547, 1541459225, 327033209], this.k = Wn, this.W = new Array(160)
            }
            On.inherits(qn, Kn);
            var Zn = qn;

            function Vn(e, t, r, n, i) {
                var a = e & r ^ ~e & i;
                return a < 0 && (a += 4294967296), a
            }

            function Gn(e, t, r, n, i, a) {
                var o = t & n ^ ~t & a;
                return o < 0 && (o += 4294967296), o
            }

            function Jn(e, t, r, n, i) {
                var a = e & r ^ e & i ^ r & i;
                return a < 0 && (a += 4294967296), a
            }

            function Yn(e, t, r, n, i, a) {
                var o = t & n ^ t & a ^ n & a;
                return o < 0 && (o += 4294967296), o
            }

            function $n(e, t) {
                var r = Nn(e, t, 28) ^ Nn(t, e, 2) ^ Nn(t, e, 7);
                return r < 0 && (r += 4294967296), r
            }

            function Qn(e, t) {
                var r = Dn(e, t, 28) ^ Dn(t, e, 2) ^ Dn(t, e, 7);
                return r < 0 && (r += 4294967296), r
            }

            function Xn(e, t) {
                var r = Nn(e, t, 14) ^ Nn(e, t, 18) ^ Nn(t, e, 9);
                return r < 0 && (r += 4294967296), r
            }

            function ei(e, t) {
                var r = Dn(e, t, 14) ^ Dn(e, t, 18) ^ Dn(t, e, 9);
                return r < 0 && (r += 4294967296), r
            }

            function ti(e, t) {
                var r = Nn(e, t, 1) ^ Nn(e, t, 8) ^ Ln(e, t, 7);
                return r < 0 && (r += 4294967296), r
            }

            function ri(e, t) {
                var r = Dn(e, t, 1) ^ Dn(e, t, 8) ^ Un(e, t, 7);
                return r < 0 && (r += 4294967296), r
            }

            function ni(e, t) {
                var r = Nn(e, t, 19) ^ Nn(t, e, 29) ^ Ln(e, t, 6);
                return r < 0 && (r += 4294967296), r
            }

            function ii(e, t) {
                var r = Dn(e, t, 19) ^ Dn(t, e, 29) ^ Un(e, t, 6);
                return r < 0 && (r += 4294967296), r
            }
            qn.blockSize = 1024, qn.outSize = 512, qn.hmacStrength = 192, qn.padLength = 128, qn.prototype._prepareBlock = function(e, t) {
                for (var r = this.W, n = 0; n < 32; n++) r[n] = e[t + n];
                for (; n < r.length; n += 2) {
                    var i = ni(r[n - 4], r[n - 3]),
                        a = ii(r[n - 4], r[n - 3]),
                        o = r[n - 14],
                        s = r[n - 13],
                        u = ti(r[n - 30], r[n - 29]),
                        l = ri(r[n - 30], r[n - 29]),
                        c = r[n - 32],
                        h = r[n - 31];
                    r[n] = Mn(i, a, o, s, u, l, c, h), r[n + 1] = Cn(i, a, o, s, u, l, c, h)
                }
            }, qn.prototype._update = function(e, t) {
                this._prepareBlock(e, t);
                var r = this.W,
                    n = this.h[0],
                    i = this.h[1],
                    a = this.h[2],
                    o = this.h[3],
                    s = this.h[4],
                    u = this.h[5],
                    l = this.h[6],
                    c = this.h[7],
                    h = this.h[8],
                    f = this.h[9],
                    d = this.h[10],
                    p = this.h[11],
                    _ = this.h[12],
                    y = this.h[13],
                    g = this.h[14],
                    b = this.h[15];
                Pn(this.k.length === r.length);
                for (var v = 0; v < r.length; v += 2) {
                    var m = g,
                        w = b,
                        x = Xn(h, f),
                        k = ei(h, f),
                        S = Vn(h, 0, d, 0, _),
                        E = Gn(0, f, 0, p, 0, y),
                        A = this.k[v],
                        T = this.k[v + 1],
                        z = r[v],
                        O = r[v + 1],
                        R = Fn(m, w, x, k, S, E, A, T, z, O),
                        P = Hn(m, w, x, k, S, E, A, T, z, O);
                    m = $n(n, i), w = Qn(n, i), x = Jn(n, 0, a, 0, s), k = Yn(0, i, 0, o, 0, u);
                    var N = Bn(m, w, x, k),
                        D = jn(m, w, x, k);
                    g = _, b = y, _ = d, y = p, d = h, p = f, h = Bn(l, c, R, P), f = jn(c, c, R, P), l = s, c = u, s = a, u = o, a = n, o = i, n = Bn(R, P, N, D), i = jn(R, P, N, D)
                }
                In(this.h, 0, n, i), In(this.h, 2, a, o), In(this.h, 4, s, u), In(this.h, 6, l, c), In(this.h, 8, h, f), In(this.h, 10, d, p), In(this.h, 12, _, y), In(this.h, 14, g, b)
            }, qn.prototype._digest = function(e) {
                return "hex" === e ? On.toHex32(this.h, "big") : On.split32(this.h, "big")
            };
            var ai = Rr,
                oi = Zn;

            function si() {
                if (!(this instanceof si)) return new si;
                oi.call(this), this.h = [3418070365, 3238371032, 1654270250, 914150663, 2438529370, 812702999, 355462360, 4144912697, 1731405415, 4290775857, 2394180231, 1750603025, 3675008525, 1694076839, 1203062813, 3204075428]
            }
            ai.inherits(si, oi);
            var ui = si;
            si.blockSize = 1024, si.outSize = 384, si.hmacStrength = 192, si.padLength = 128, si.prototype._digest = function(e) {
                return "hex" === e ? ai.toHex32(this.h.slice(0, 12), "big") : ai.split32(this.h.slice(0, 12), "big")
            }, Wr.sha1 = sn, Wr.sha224 = zn, Wr.sha256 = Sn, Wr.sha384 = ui, Wr.sha512 = Zn;
            var li = {},
                ci = Rr,
                hi = Cr,
                fi = ci.rotl32,
                di = ci.sum32,
                pi = ci.sum32_3,
                _i = ci.sum32_4,
                yi = hi.BlockHash;

            function gi() {
                if (!(this instanceof gi)) return new gi;
                yi.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.endian = "little"
            }

            function bi(e, t, r, n) {
                return e <= 15 ? t ^ r ^ n : e <= 31 ? t & r | ~t & n : e <= 47 ? (t | ~r) ^ n : e <= 63 ? t & n | r & ~n : t ^ (r | ~n)
            }

            function vi(e) {
                return e <= 15 ? 0 : e <= 31 ? 1518500249 : e <= 47 ? 1859775393 : e <= 63 ? 2400959708 : 2840853838
            }

            function mi(e) {
                return e <= 15 ? 1352829926 : e <= 31 ? 1548603684 : e <= 47 ? 1836072691 : e <= 63 ? 2053994217 : 0
            }
            ci.inherits(gi, yi), li.ripemd160 = gi, gi.blockSize = 512, gi.outSize = 160, gi.hmacStrength = 192, gi.padLength = 64, gi.prototype._update = function(e, t) {
                for (var r = this.h[0], n = this.h[1], i = this.h[2], a = this.h[3], o = this.h[4], s = r, u = n, l = i, c = a, h = o, f = 0; f < 80; f++) {
                    var d = di(fi(_i(r, bi(f, n, i, a), e[wi[f] + t], vi(f)), ki[f]), o);
                    r = o, o = a, a = fi(i, 10), i = n, n = d, d = di(fi(_i(s, bi(79 - f, u, l, c), e[xi[f] + t], mi(f)), Si[f]), h), s = h, h = c, c = fi(l, 10), l = u, u = d
                }
                d = pi(this.h[1], i, c), this.h[1] = pi(this.h[2], a, h), this.h[2] = pi(this.h[3], o, s), this.h[3] = pi(this.h[4], r, u), this.h[4] = pi(this.h[0], n, l), this.h[0] = d
            }, gi.prototype._digest = function(e) {
                return "hex" === e ? ci.toHex32(this.h, "little") : ci.split32(this.h, "little")
            };
            var wi = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13],
                xi = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11],
                ki = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6],
                Si = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11],
                Ei = Rr,
                Ai = Pr;

            function Ti(e, t, r) {
                if (!(this instanceof Ti)) return new Ti(e, t, r);
                this.Hash = e, this.blockSize = e.blockSize / 8, this.outSize = e.outSize / 8, this.inner = null, this.outer = null, this._init(Ei.toArray(t, r))
            }
            var zi = Ti;
            Ti.prototype._init = function(e) {
                    e.length > this.blockSize && (e = (new this.Hash).update(e).digest()), Ai(e.length <= this.blockSize);
                    for (var t = e.length; t < this.blockSize; t++) e.push(0);
                    for (t = 0; t < e.length; t++) e[t] ^= 54;
                    for (this.inner = (new this.Hash).update(e), t = 0; t < e.length; t++) e[t] ^= 106;
                    this.outer = (new this.Hash).update(e)
                }, Ti.prototype.update = function(e, t) {
                    return this.inner.update(e, t), this
                }, Ti.prototype.digest = function(e) {
                    return this.outer.update(this.inner.digest()), this.outer.digest(e)
                },
                function(e) {
                    var t = e;
                    t.utils = Rr, t.common = Cr, t.sha = Wr, t.ripemd = li, t.hmac = zi, t.sha1 = t.sha.sha1, t.sha256 = t.sha.sha256, t.sha224 = t.sha.sha224, t.sha384 = t.sha.sha384, t.sha512 = t.sha.sha512, t.ripemd160 = t.ripemd.ripemd160
                }(Or);
            var Oi = function(e, t) {
                    if (Array.isArray(e)) return e;
                    if (Symbol.iterator in Object(e)) return function(e, t) {
                        var r = [],
                            n = !0,
                            i = !1,
                            a = void 0;
                        try {
                            for (var o, s = e[Symbol.iterator](); !(n = (o = s.next()).done) && (r.push(o.value), !t || r.length !== t); n = !0);
                        } catch (Pe) {
                            i = !0, a = Pe
                        } finally {
                            try {
                                !n && s.return && s.return()
                            } finally {
                                if (i) throw a
                            }
                        }
                        return r
                    }(e, t);
                    throw new TypeError("Invalid attempt to destructure non-iterable instance")
                },
                Ri = function() {
                    function e(e, t) {
                        for (var r = 0; r < t.length; r++) {
                            var n = t[r];
                            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                        }
                    }
                    return function(t, r, n) {
                        return r && e(t.prototype, r), n && e(t, n), t
                    }
                }(),
                Pi = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e)
                    }
                    return Ri(e, null, [{
                        key: "get_n_pad_bytes",
                        value: function(e) {
                            return 64 - (e + 8 & 63)
                        }
                    }, {
                        key: "pad",
                        value: function(t) {
                            var r, n, i = t.byteLength,
                                a = e.get_n_pad_bytes(i),
                                o = (r = i, n = 536870912, [Math.floor(r / n), r % n]).map((function(e, t) {
                                    return t ? 8 * e : e
                                })),
                                s = Oi(o, 2),
                                u = s[0],
                                l = s[1],
                                c = new Uint8Array(i + a + 8);
                            c.set(new Uint8Array(t), 0);
                            var h = new DataView(c.buffer);
                            return h.setUint8(i, 128), h.setUint32(i + a, l, !0), h.setUint32(i + a + 4, u, !0), c.buffer
                        }
                    }, {
                        key: "f",
                        value: function(e, t, r, n) {
                            return 0 <= e && e <= 15 ? t ^ r ^ n : 16 <= e && e <= 31 ? t & r | ~t & n : 32 <= e && e <= 47 ? (t | ~r) ^ n : 48 <= e && e <= 63 ? t & n | r & ~n : 64 <= e && e <= 79 ? t ^ (r | ~n) : void 0
                        }
                    }, {
                        key: "K",
                        value: function(e) {
                            return 0 <= e && e <= 15 ? 0 : 16 <= e && e <= 31 ? 1518500249 : 32 <= e && e <= 47 ? 1859775393 : 48 <= e && e <= 63 ? 2400959708 : 64 <= e && e <= 79 ? 2840853838 : void 0
                        }
                    }, {
                        key: "KP",
                        value: function(e) {
                            return 0 <= e && e <= 15 ? 1352829926 : 16 <= e && e <= 31 ? 1548603684 : 32 <= e && e <= 47 ? 1836072691 : 48 <= e && e <= 63 ? 2053994217 : 64 <= e && e <= 79 ? 0 : void 0
                        }
                    }, {
                        key: "add_modulo32",
                        value: function() {
                            return 0 | Array.from(arguments).reduce((function(e, t) {
                                return e + t
                            }), 0)
                        }
                    }, {
                        key: "rol32",
                        value: function(e, t) {
                            return e << t | e >>> 32 - t
                        }
                    }, {
                        key: "hash",
                        value: function(t) {
                            for (var r = e.pad(t), n = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13], i = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11], a = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6], o = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11], s = r.byteLength / 64, u = new Array(s).fill(void 0).map((function(e, t) {
                                    return function(e) {
                                        return new DataView(r, 64 * t, 64).getUint32(4 * e, !0)
                                    }
                                })), l = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], c = 0; c < s; ++c) {
                                for (var h = l[0], f = l[1], d = l[2], p = l[3], _ = l[4], y = h, g = f, b = d, v = p, m = _, w = 0; w < 80; ++w) {
                                    var x = e.add_modulo32(e.rol32(e.add_modulo32(h, e.f(w, f, d, p), u[c](n[w]), e.K(w)), a[w]), _);
                                    h = _, _ = p, p = e.rol32(d, 10), d = f, f = x, x = e.add_modulo32(e.rol32(e.add_modulo32(y, e.f(79 - w, g, b, v), u[c](i[w]), e.KP(w)), o[w]), m), y = m, m = v, v = e.rol32(b, 10), b = g, g = x
                                }
                                var k = e.add_modulo32(l[1], d, v);
                                l[1] = e.add_modulo32(l[2], p, m), l[2] = e.add_modulo32(l[3], _, y), l[3] = e.add_modulo32(l[4], h, g), l[4] = e.add_modulo32(l[0], f, b), l[0] = k
                            }
                            var S = new ArrayBuffer(20),
                                E = new DataView(S);
                            return l.forEach((function(e, t) {
                                return E.setUint32(4 * t, e, !0)
                            })), S
                        }
                    }]), e
                }(),
                Ni = {
                    RIPEMD160: Pi
                };
            ! function(e) {
                var r = t && t.__read || function(e, t) {
                        var r = "function" == typeof Symbol && e[Symbol.iterator];
                        if (!r) return e;
                        var n, i, a = r.call(e),
                            o = [];
                        try {
                            for (;
                                (void 0 === t || t-- > 0) && !(n = a.next()).done;) o.push(n.value)
                        } catch (s) {
                            i = {
                                error: s
                            }
                        } finally {
                            try {
                                n && !n.done && (r = a.return) && r.call(a)
                            } finally {
                                if (i) throw i.error
                            }
                        }
                        return o
                    },
                    n = t && t.__spreadArray || function(e, t) {
                        for (var r = 0, n = t.length, i = e.length; r < n; r++, i++) e[i] = t[r];
                        return e
                    },
                    i = t && t.__values || function(e) {
                        var t = "function" == typeof Symbol && Symbol.iterator,
                            r = t && e[t],
                            n = 0;
                        if (r) return r.call(e);
                        if (e && "number" == typeof e.length) return {
                            next: function() {
                                return e && n >= e.length && (e = void 0), {
                                    value: e && e[n++],
                                    done: !e
                                }
                            }
                        };
                        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.signatureToString = e.stringToSignature = e.privateKeyToString = e.privateKeyToLegacyString = e.stringToPrivateKey = e.convertLegacyPublicKeys = e.convertLegacyPublicKey = e.publicKeyToString = e.publicKeyToLegacyString = e.stringToPublicKey = e.signatureDataSize = e.privateKeyDataSize = e.publicKeyDataSize = e.KeyType = e.base64ToBinary = e.binaryToBase58 = e.base58ToBinary = e.signedBinaryToDecimal = e.binaryToDecimal = e.signedDecimalToBinary = e.decimalToBinary = e.negate = e.isNegative = void 0;
                var a, o = Or,
                    s = Ni.RIPEMD160.hash,
                    u = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz",
                    l = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                    c = function() {
                        for (var e = Array(256).fill(-1), t = 0; t < u.length; ++t) e[u.charCodeAt(t)] = t;
                        return e
                    }(),
                    h = function() {
                        for (var e = Array(256).fill(-1), t = 0; t < l.length; ++t) e[l.charCodeAt(t)] = t;
                        return e["=".charCodeAt(0)] = 0, e
                    }();
                e.isNegative = function(e) {
                        return 0 != (128 & e[e.length - 1])
                    }, e.negate = function(e) {
                        for (var t = 1, r = 0; r < e.length; ++r) {
                            var n = (255 & ~e[r]) + t;
                            e[r] = n, t = n >> 8
                        }
                    }, e.decimalToBinary = function(e, t) {
                        for (var r = new Uint8Array(e), n = 0; n < t.length; ++n) {
                            var i = t.charCodeAt(n);
                            if (i < "0".charCodeAt(0) || i > "9".charCodeAt(0)) throw new Error("invalid number");
                            for (var a = i - "0".charCodeAt(0), o = 0; o < e; ++o) {
                                var s = 10 * r[o] + a;
                                r[o] = s, a = s >> 8
                            }
                            if (a) throw new Error("number is out of range")
                        }
                        return r
                    }, e.signedDecimalToBinary = function(t, r) {
                        var n = "-" === r[0];
                        n && (r = r.substr(1));
                        var i = e.decimalToBinary(t, r);
                        if (n) {
                            if (e.negate(i), !e.isNegative(i)) throw new Error("number is out of range")
                        } else if (e.isNegative(i)) throw new Error("number is out of range");
                        return i
                    }, e.binaryToDecimal = function(e, t) {
                        void 0 === t && (t = 1);
                        for (var i = Array(t).fill("0".charCodeAt(0)), a = e.length - 1; a >= 0; --a) {
                            for (var o = e[a], s = 0; s < i.length; ++s) {
                                var u = (i[s] - "0".charCodeAt(0) << 8) + o;
                                i[s] = "0".charCodeAt(0) + u % 10, o = u / 10 | 0
                            }
                            for (; o;) i.push("0".charCodeAt(0) + o % 10), o = o / 10 | 0
                        }
                        return i.reverse(), String.fromCharCode.apply(String, n([], r(i)))
                    }, e.signedBinaryToDecimal = function(t, r) {
                        if (void 0 === r && (r = 1), e.isNegative(t)) {
                            var n = t.slice();
                            return e.negate(n), "-" + e.binaryToDecimal(n, r)
                        }
                        return e.binaryToDecimal(t, r)
                    }, e.base58ToBinary = function(e, t) {
                        if (!e) return function(e) {
                            for (var t, r, n = [], a = 0; a < e.length; ++a) {
                                var o = c[e.charCodeAt(a)];
                                if (o < 0) throw new Error("invalid base-58 value");
                                for (var s = 0; s < n.length; ++s) {
                                    var u = 58 * n[s] + o;
                                    n[s] = 255 & u, o = u >> 8
                                }
                                o && n.push(o)
                            }
                            try {
                                for (var l = i(e), h = l.next(); !h.done && "1" === h.value; h = l.next()) n.push(0)
                            } catch (f) {
                                t = {
                                    error: f
                                }
                            } finally {
                                try {
                                    h && !h.done && (r = l.return) && r.call(l)
                                } finally {
                                    if (t) throw t.error
                                }
                            }
                            return n.reverse(), new Uint8Array(n)
                        }(t);
                        for (var r = new Uint8Array(e), n = 0; n < t.length; ++n) {
                            var a = c[t.charCodeAt(n)];
                            if (a < 0) throw new Error("invalid base-58 value");
                            for (var o = 0; o < e; ++o) {
                                var s = 58 * r[o] + a;
                                r[o] = s, a = s >> 8
                            }
                            if (a) throw new Error("base-58 value is out of range")
                        }
                        return r.reverse(), r
                    }, e.binaryToBase58 = function(e, t) {
                        var a, o, s, l, h = [];
                        try {
                            for (var f = i(e), d = f.next(); !d.done; d = f.next()) {
                                for (var p = d.value, _ = 0; _ < h.length; ++_) {
                                    var y = (c[h[_]] << 8) + p;
                                    h[_] = u.charCodeAt(y % 58), p = y / 58 | 0
                                }
                                for (; p;) h.push(u.charCodeAt(p % 58)), p = p / 58 | 0
                            }
                        } catch (v) {
                            a = {
                                error: v
                            }
                        } finally {
                            try {
                                d && !d.done && (o = f.return) && o.call(f)
                            } finally {
                                if (a) throw a.error
                            }
                        }
                        try {
                            for (var g = i(e), b = g.next(); !b.done && !b.value; b = g.next()) h.push("1".charCodeAt(0))
                        } catch (m) {
                            s = {
                                error: m
                            }
                        } finally {
                            try {
                                b && !b.done && (l = g.return) && l.call(g)
                            } finally {
                                if (s) throw s.error
                            }
                        }
                        return h.reverse(), String.fromCharCode.apply(String, n([], r(h)))
                    }, e.base64ToBinary = function(e) {
                        var t = e.length;
                        if (1 == (3 & t) && "=" === e[t - 1] && (t -= 1), 0 != (3 & t)) throw new Error("base-64 value is not padded correctly");
                        var r = t >> 2,
                            n = 3 * r;
                        t > 0 && "=" === e[t - 1] && ("=" === e[t - 2] ? n -= 2 : n -= 1);
                        for (var i = new Uint8Array(n), a = 0; a < r; ++a) {
                            var o = h[e.charCodeAt(4 * a + 0)],
                                s = h[e.charCodeAt(4 * a + 1)],
                                u = h[e.charCodeAt(4 * a + 2)],
                                l = h[e.charCodeAt(4 * a + 3)];
                            i[3 * a + 0] = o << 2 | s >> 4, 3 * a + 1 < n && (i[3 * a + 1] = (15 & s) << 4 | u >> 2), 3 * a + 2 < n && (i[3 * a + 2] = (3 & u) << 6 | l)
                        }
                        return i
                    },
                    function(e) {
                        e[e.k1 = 0] = "k1", e[e.r1 = 1] = "r1", e[e.wa = 2] = "wa"
                    }(a = e.KeyType || (e.KeyType = {})), e.publicKeyDataSize = 33, e.privateKeyDataSize = 32, e.signatureDataSize = 65;
                var f = function(e, t) {
                        for (var r = new Uint8Array(e.length + t.length), n = 0; n < e.length; ++n) r[n] = e[n];
                        for (n = 0; n < t.length; ++n) r[e.length + n] = t.charCodeAt(n);
                        return s(r)
                    },
                    d = function(t, r, n, i) {
                        var a = e.base58ToBinary(n ? n + 4 : 0, t),
                            o = {
                                type: r,
                                data: new Uint8Array(a.buffer, 0, a.length - 4)
                            },
                            s = new Uint8Array(f(o.data, i));
                        if (s[0] !== a[a.length - 4] || s[1] !== a[a.length - 3] || s[2] !== a[a.length - 2] || s[3] !== a[a.length - 1]) throw new Error("checksum doesn't match");
                        return o
                    },
                    p = function(t, r, n) {
                        for (var i = new Uint8Array(f(t.data, r)), a = new Uint8Array(t.data.length + 4), o = 0; o < t.data.length; ++o) a[o] = t.data[o];
                        for (o = 0; o < 4; ++o) a[o + t.data.length] = i[o];
                        return n + e.binaryToBase58(a)
                    };
                e.stringToPublicKey = function(t) {
                    if ("string" != typeof t) throw new Error("expected string containing public key");
                    if ("EOS" === t.substr(0, 3)) {
                        for (var r = e.base58ToBinary(e.publicKeyDataSize + 4, t.substr(3)), n = {
                                type: a.k1,
                                data: new Uint8Array(e.publicKeyDataSize)
                            }, i = 0; i < e.publicKeyDataSize; ++i) n.data[i] = r[i];
                        var o = new Uint8Array(s(n.data));
                        if (o[0] !== r[e.publicKeyDataSize] || o[1] !== r[34] || o[2] !== r[35] || o[3] !== r[36]) throw new Error("checksum doesn't match");
                        return n
                    }
                    if ("PUB_K1_" === t.substr(0, 7)) return d(t.substr(7), a.k1, e.publicKeyDataSize, "K1");
                    if ("PUB_R1_" === t.substr(0, 7)) return d(t.substr(7), a.r1, e.publicKeyDataSize, "R1");
                    if ("PUB_WA_" === t.substr(0, 7)) return d(t.substr(7), a.wa, 0, "WA");
                    throw new Error("unrecognized public key format")
                }, e.publicKeyToLegacyString = function(t) {
                    if (t.type === a.k1 && t.data.length === e.publicKeyDataSize) return p(t, "", "EOS");
                    throw t.type === a.r1 || t.type === a.wa ? new Error("Key format not supported in legacy conversion") : new Error("unrecognized public key format")
                }, e.publicKeyToString = function(t) {
                    if (t.type === a.k1 && t.data.length === e.publicKeyDataSize) return p(t, "K1", "PUB_K1_");
                    if (t.type === a.r1 && t.data.length === e.publicKeyDataSize) return p(t, "R1", "PUB_R1_");
                    if (t.type === a.wa) return p(t, "WA", "PUB_WA_");
                    throw new Error("unrecognized public key format")
                }, e.convertLegacyPublicKey = function(t) {
                    return "EOS" === t.substr(0, 3) ? e.publicKeyToString(e.stringToPublicKey(t)) : t
                }, e.convertLegacyPublicKeys = function(t) {
                    return t.map(e.convertLegacyPublicKey)
                }, e.stringToPrivateKey = function(t) {
                    if ("string" != typeof t) throw new Error("expected string containing private key");
                    if ("PVT_R1_" === t.substr(0, 7)) return d(t.substr(7), a.r1, e.privateKeyDataSize, "R1");
                    if ("PVT_K1_" === t.substr(0, 7)) return d(t.substr(7), a.k1, e.privateKeyDataSize, "K1");
                    var r = e.base58ToBinary(e.privateKeyDataSize + 5, t),
                        n = {
                            type: a.k1,
                            data: new Uint8Array(e.privateKeyDataSize)
                        };
                    if (128 !== r[0]) throw new Error("unrecognized private key type");
                    for (var i = 0; i < e.privateKeyDataSize; ++i) n.data[i] = r[i + 1];
                    return n
                }, e.privateKeyToLegacyString = function(t) {
                    if (t.type === a.k1 && t.data.length === e.privateKeyDataSize) {
                        var r = [];
                        r.push(128), t.data.forEach((function(e) {
                            return r.push(e)
                        }));
                        for (var n = new Uint8Array(o.sha256().update(o.sha256().update(r).digest()).digest()), i = new Uint8Array(e.privateKeyDataSize + 5), s = 0; s < r.length; s++) i[s] = r[s];
                        for (s = 0; s < 4; s++) i[s + r.length] = n[s];
                        return e.binaryToBase58(i)
                    }
                    throw t.type === a.r1 || t.type === a.wa ? new Error("Key format not supported in legacy conversion") : new Error("unrecognized public key format")
                }, e.privateKeyToString = function(e) {
                    if (e.type === a.r1) return p(e, "R1", "PVT_R1_");
                    if (e.type === a.k1) return p(e, "K1", "PVT_K1_");
                    throw new Error("unrecognized private key format")
                }, e.stringToSignature = function(t) {
                    if ("string" != typeof t) throw new Error("expected string containing signature");
                    if ("SIG_K1_" === t.substr(0, 7)) return d(t.substr(7), a.k1, e.signatureDataSize, "K1");
                    if ("SIG_R1_" === t.substr(0, 7)) return d(t.substr(7), a.r1, e.signatureDataSize, "R1");
                    if ("SIG_WA_" === t.substr(0, 7)) return d(t.substr(7), a.wa, 0, "WA");
                    throw new Error("unrecognized signature format")
                }, e.signatureToString = function(e) {
                    if (e.type === a.k1) return p(e, "K1", "SIG_K1_");
                    if (e.type === a.r1) return p(e, "R1", "SIG_R1_");
                    if (e.type === a.wa) return p(e, "WA", "SIG_WA_");
                    throw new Error("unrecognized signature format")
                }
            }(zr),
            function(e) {
                var r = t && t.__assign || function() {
                        return r = Object.assign || function(e) {
                            for (var t, r = 1, n = arguments.length; r < n; r++)
                                for (var i in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                            return e
                        }, r.apply(this, arguments)
                    },
                    n = t && t.__read || function(e, t) {
                        var r = "function" == typeof Symbol && e[Symbol.iterator];
                        if (!r) return e;
                        var n, i, a = r.call(e),
                            o = [];
                        try {
                            for (;
                                (void 0 === t || t-- > 0) && !(n = a.next()).done;) o.push(n.value)
                        } catch (s) {
                            i = {
                                error: s
                            }
                        } finally {
                            try {
                                n && !n.done && (r = a.return) && r.call(a)
                            } finally {
                                if (i) throw i.error
                            }
                        }
                        return o
                    },
                    i = t && t.__spreadArray || function(e, t) {
                        for (var r = 0, n = t.length, i = e.length; r < n; r++, i++) e[i] = t[r];
                        return e
                    },
                    a = t && t.__values || function(e) {
                        var t = "function" == typeof Symbol && Symbol.iterator,
                            r = t && e[t],
                            n = 0;
                        if (r) return r.call(e);
                        if (e && "number" == typeof e.length) return {
                            next: function() {
                                return e && n >= e.length && (e = void 0), {
                                    value: e && e[n++],
                                    done: !e
                                }
                            }
                        };
                        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.serializeQuery = e.deserializeAnyArray = e.serializeAnyArray = e.deserializeAnyObject = e.serializeAnyObject = e.deserializeAnyvarShort = e.deserializeAnyvar = e.serializeAnyvar = e.deserializeAction = e.deserializeActionData = e.serializeAction = e.serializeActionData = e.transactionHeader = e.getTypesFromAbi = e.getType = e.createTransactionTypes = e.createTransactionExtensionTypes = e.createAbiTypes = e.createInitialTypes = e.hexToUint8Array = e.arrayToHex = e.symbolToString = e.stringToSymbol = e.blockTimestampToDate = e.dateToBlockTimestamp = e.timePointSecToDate = e.dateToTimePointSec = e.timePointToDate = e.dateToTimePoint = e.supportedAbiVersion = e.SerialBuffer = e.SerializerState = void 0;
                var o = zr,
                    s = function(e) {
                        void 0 === e && (e = {}), this.skippedBinaryExtension = !1, this.options = e
                    };
                e.SerializerState = s;
                var u = function() {
                    function e(e) {
                        var t = void 0 === e ? {} : e,
                            r = t.textEncoder,
                            n = t.textDecoder,
                            i = t.array;
                        this.readPos = 0, this.array = i || new Uint8Array(1024), this.length = i ? i.length : 0, this.textEncoder = r || new TextEncoder, this.textDecoder = n || new TextDecoder("utf-8", {
                            fatal: !0
                        })
                    }
                    return e.prototype.reserve = function(e) {
                        if (!(this.length + e <= this.array.length)) {
                            for (var t = this.array.length; this.length + e > t;) t = Math.ceil(1.5 * t);
                            var r = new Uint8Array(t);
                            r.set(this.array), this.array = r
                        }
                    }, e.prototype.haveReadData = function() {
                        return this.readPos < this.length
                    }, e.prototype.restartRead = function() {
                        this.readPos = 0
                    }, e.prototype.asUint8Array = function() {
                        return new Uint8Array(this.array.buffer, this.array.byteOffset, this.length)
                    }, e.prototype.pushArray = function(e) {
                        this.reserve(e.length), this.array.set(e, this.length), this.length += e.length
                    }, e.prototype.push = function() {
                        for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                        this.pushArray(e)
                    }, e.prototype.get = function() {
                        if (this.readPos < this.length) return this.array[this.readPos++];
                        throw new Error("Read past end of buffer")
                    }, e.prototype.pushUint8ArrayChecked = function(e, t) {
                        if (e.length !== t) throw new Error("Binary data has incorrect size");
                        this.pushArray(e)
                    }, e.prototype.getUint8Array = function(e) {
                        if (this.readPos + e > this.length) throw new Error("Read past end of buffer");
                        var t = new Uint8Array(this.array.buffer, this.array.byteOffset + this.readPos, e);
                        return this.readPos += e, t
                    }, e.prototype.skip = function(e) {
                        if (this.readPos + e > this.length) throw new Error("Read past end of buffer");
                        this.readPos += e
                    }, e.prototype.pushUint16 = function(e) {
                        this.push(e >> 0 & 255, e >> 8 & 255)
                    }, e.prototype.getUint16 = function() {
                        var e = 0;
                        return e |= this.get() << 0, e |= this.get() << 8
                    }, e.prototype.pushUint32 = function(e) {
                        this.push(e >> 0 & 255, e >> 8 & 255, e >> 16 & 255, e >> 24 & 255)
                    }, e.prototype.getUint32 = function() {
                        var e = 0;
                        return e |= this.get() << 0, e |= this.get() << 8, e |= this.get() << 16, (e |= this.get() << 24) >>> 0
                    }, e.prototype.pushNumberAsUint64 = function(e) {
                        this.pushUint32(e >>> 0), this.pushUint32(Math.floor(e / 4294967296) >>> 0)
                    }, e.prototype.getUint64AsNumber = function() {
                        var e = this.getUint32();
                        return 4294967296 * (this.getUint32() >>> 0) + (e >>> 0)
                    }, e.prototype.pushVaruint32 = function(e) {
                        for (;;) {
                            if (!(e >>> 7)) {
                                this.push(e);
                                break
                            }
                            this.push(128 | 127 & e), e >>>= 7
                        }
                    }, e.prototype.getVaruint32 = function() {
                        for (var e = 0, t = 0;;) {
                            var r = this.get();
                            if (e |= (127 & r) << t, t += 7, !(128 & r)) break
                        }
                        return e >>> 0
                    }, e.prototype.pushVarint32 = function(e) {
                        this.pushVaruint32(e << 1 ^ e >> 31)
                    }, e.prototype.getVarint32 = function() {
                        var e = this.getVaruint32();
                        return 1 & e ? ~e >> 1 | 2147483648 : e >>> 1
                    }, e.prototype.pushFloat32 = function(e) {
                        this.pushArray(new Uint8Array(new Float32Array([e]).buffer))
                    }, e.prototype.getFloat32 = function() {
                        return new Float32Array(this.getUint8Array(4).slice().buffer)[0]
                    }, e.prototype.pushFloat64 = function(e) {
                        this.pushArray(new Uint8Array(new Float64Array([e]).buffer))
                    }, e.prototype.getFloat64 = function() {
                        return new Float64Array(this.getUint8Array(8).slice().buffer)[0]
                    }, e.prototype.pushName = function(e) {
                        if ("string" != typeof e) throw new Error("Expected string containing name");
                        if (!new RegExp(/^[.1-5a-z]{0,12}[.1-5a-j]?$/).test(e)) throw new Error("Name should be less than 13 characters, or less than 14 if last character is between 1-5 or a-j, and only contain the following symbols .12345abcdefghijklmnopqrstuvwxyz");
                        for (var t = function(e) {
                                return e >= "a".charCodeAt(0) && e <= "z".charCodeAt(0) ? e - "a".charCodeAt(0) + 6 : e >= "1".charCodeAt(0) && e <= "5".charCodeAt(0) ? e - "1".charCodeAt(0) + 1 : 0
                            }, r = new Uint8Array(8), n = 63, i = 0; i < e.length; ++i) {
                            var a = t(e.charCodeAt(i));
                            n < 5 && (a <<= 1);
                            for (var o = 4; o >= 0; --o) n >= 0 && (r[Math.floor(n / 8)] |= (a >> o & 1) << n % 8, --n)
                        }
                        this.pushArray(r)
                    }, e.prototype.getName = function() {
                        for (var e = this.getUint8Array(8), t = "", r = 63; r >= 0;) {
                            for (var n = 0, i = 0; i < 5; ++i) r >= 0 && (n = n << 1 | e[Math.floor(r / 8)] >> r % 8 & 1, --r);
                            t += n >= 6 ? String.fromCharCode(n + "a".charCodeAt(0) - 6) : n >= 1 ? String.fromCharCode(n + "1".charCodeAt(0) - 1) : "."
                        }
                        for (; t.endsWith(".");) t = t.substr(0, t.length - 1);
                        return t
                    }, e.prototype.pushBytes = function(e) {
                        this.pushVaruint32(e.length), this.pushArray(e)
                    }, e.prototype.getBytes = function() {
                        return this.getUint8Array(this.getVaruint32())
                    }, e.prototype.pushString = function(e) {
                        this.pushBytes(this.textEncoder.encode(e))
                    }, e.prototype.getString = function() {
                        return this.textDecoder.decode(this.getBytes())
                    }, e.prototype.pushSymbolCode = function(e) {
                        if ("string" != typeof e) throw new Error("Expected string containing symbol_code");
                        var t = [];
                        for (t.push.apply(t, i([], n(this.textEncoder.encode(e)))); t.length < 8;) t.push(0);
                        this.pushArray(t.slice(0, 8))
                    }, e.prototype.getSymbolCode = function() {
                        var e, t = this.getUint8Array(8);
                        for (e = 0; e < t.length && t[e]; ++e);
                        return this.textDecoder.decode(new Uint8Array(t.buffer, t.byteOffset, e))
                    }, e.prototype.pushSymbol = function(e) {
                        var t = e.name,
                            r = e.precision;
                        if (!/^[A-Z]{1,7}$/.test(t)) throw new Error("Expected symbol to be A-Z and between one and seven characters");
                        var a = [255 & r];
                        for (a.push.apply(a, i([], n(this.textEncoder.encode(t)))); a.length < 8;) a.push(0);
                        this.pushArray(a.slice(0, 8))
                    }, e.prototype.getSymbol = function() {
                        var e, t = this.get(),
                            r = this.getUint8Array(7);
                        for (e = 0; e < r.length && r[e]; ++e);
                        return {
                            name: this.textDecoder.decode(new Uint8Array(r.buffer, r.byteOffset, e)),
                            precision: t
                        }
                    }, e.prototype.pushAsset = function(e) {
                        if ("string" != typeof e) throw new Error("Expected string containing asset");
                        var t = 0,
                            r = "",
                            n = 0;
                        "-" === (e = e.trim())[t] && (r += "-", ++t);
                        for (var i = !1; t < e.length && e.charCodeAt(t) >= "0".charCodeAt(0) && e.charCodeAt(t) <= "9".charCodeAt(0);) i = !0, r += e[t], ++t;
                        if (!i) throw new Error("Asset must begin with a number");
                        if ("." === e[t])
                            for (++t; t < e.length && e.charCodeAt(t) >= "0".charCodeAt(0) && e.charCodeAt(t) <= "9".charCodeAt(0);) r += e[t], ++n, ++t;
                        var a = e.substr(t).trim();
                        this.pushArray(o.signedDecimalToBinary(8, r)), this.pushSymbol({
                            name: a,
                            precision: n
                        })
                    }, e.prototype.getAsset = function() {
                        var e = this.getUint8Array(8),
                            t = this.getSymbol(),
                            r = t.name,
                            n = t.precision,
                            i = o.signedBinaryToDecimal(e, n + 1);
                        return n && (i = i.substr(0, i.length - n) + "." + i.substr(i.length - n)), i + " " + r
                    }, e.prototype.pushPublicKey = function(e) {
                        var t = o.stringToPublicKey(e);
                        this.push(t.type), this.pushArray(t.data)
                    }, e.prototype.getPublicKey = function() {
                        var e, t = this.get();
                        if (t === o.KeyType.wa) {
                            var r = this.readPos;
                            this.skip(34), this.skip(this.getVaruint32()), e = new Uint8Array(this.array.buffer, this.array.byteOffset + r, this.readPos - r)
                        } else e = this.getUint8Array(o.publicKeyDataSize);
                        return o.publicKeyToString({
                            type: t,
                            data: e
                        })
                    }, e.prototype.pushPrivateKey = function(e) {
                        var t = o.stringToPrivateKey(e);
                        this.push(t.type), this.pushArray(t.data)
                    }, e.prototype.getPrivateKey = function() {
                        var e = this.get(),
                            t = this.getUint8Array(o.privateKeyDataSize);
                        return o.privateKeyToString({
                            type: e,
                            data: t
                        })
                    }, e.prototype.pushSignature = function(e) {
                        var t = o.stringToSignature(e);
                        this.push(t.type), this.pushArray(t.data)
                    }, e.prototype.getSignature = function() {
                        var e, t = this.get();
                        if (t === o.KeyType.wa) {
                            var r = this.readPos;
                            this.skip(65), this.skip(this.getVaruint32()), this.skip(this.getVaruint32()), e = new Uint8Array(this.array.buffer, this.array.byteOffset + r, this.readPos - r)
                        } else e = this.getUint8Array(o.signatureDataSize);
                        return o.signatureToString({
                            type: t,
                            data: e
                        })
                    }, e
                }();
                e.SerialBuffer = u, e.supportedAbiVersion = function(e) {
                    return e.startsWith("eosio::abi/1.")
                };
                var l = function(e) {
                    var t = Date.parse(e);
                    if (Number.isNaN(t)) throw new Error("Invalid time format");
                    return t
                };

                function c(e, t) {
                    throw new Error("Don't know how to serialize " + this.name)
                }

                function h(e) {
                    throw new Error("Don't know how to deserialize " + this.name)
                }

                function f(e, t, r, n) {
                    var i, o;
                    if (void 0 === r && (r = new s), void 0 === n && (n = !0), "object" != typeof t) throw new Error("expected object containing data: " + JSON.stringify(t));
                    this.base && this.base.serialize(e, t, r, n);
                    try {
                        for (var u = a(this.fields), l = u.next(); !l.done; l = u.next()) {
                            var c = l.value;
                            if (c.name in t) {
                                if (r.skippedBinaryExtension) throw new Error("unexpected " + this.name + "." + c.name);
                                c.type.serialize(e, t[c.name], r, n && c === this.fields[this.fields.length - 1])
                            } else {
                                if (!n || !c.type.extensionOf) throw new Error("missing " + this.name + "." + c.name + " (type=" + c.type.name + ")");
                                r.skippedBinaryExtension = !0
                            }
                        }
                    } catch (h) {
                        i = {
                            error: h
                        }
                    } finally {
                        try {
                            l && !l.done && (o = u.return) && o.call(u)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                }

                function d(e, t, r) {
                    var n, i, o;
                    void 0 === t && (t = new s), void 0 === r && (r = !0), o = this.base ? this.base.deserialize(e, t, r) : {};
                    try {
                        for (var u = a(this.fields), l = u.next(); !l.done; l = u.next()) {
                            var c = l.value;
                            r && c.type.extensionOf && !e.haveReadData() ? t.skippedBinaryExtension = !0 : o[c.name] = c.type.deserialize(e, t, r)
                        }
                    } catch (h) {
                        n = {
                            error: h
                        }
                    } finally {
                        try {
                            l && !l.done && (i = u.return) && i.call(u)
                        } finally {
                            if (n) throw n.error
                        }
                    }
                    return o
                }

                function p(e, t, r, n) {
                    if (!Array.isArray(t) || 2 !== t.length || "string" != typeof t[0]) throw new Error('expected variant: ["type", value]');
                    var i = this.fields.findIndex((function(e) {
                        return e.name === t[0]
                    }));
                    if (i < 0) throw new Error('type "' + t[0] + '" is not valid for variant');
                    e.pushVaruint32(i), this.fields[i].type.serialize(e, t[1], r, n)
                }

                function _(e, t, r) {
                    var n = e.getVaruint32();
                    if (n >= this.fields.length) throw new Error("type index " + n + " is not valid for variant");
                    var i = this.fields[n];
                    return [i.name, i.type.deserialize(e, t, r)]
                }

                function y(e, t, r, n) {
                    var i, o;
                    e.pushVaruint32(t.length);
                    try {
                        for (var s = a(t), u = s.next(); !u.done; u = s.next()) {
                            var l = u.value;
                            this.arrayOf.serialize(e, l, r, !1)
                        }
                    } catch (c) {
                        i = {
                            error: c
                        }
                    } finally {
                        try {
                            u && !u.done && (o = s.return) && o.call(s)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                }

                function g(e, t, r) {
                    for (var n = e.getVaruint32(), i = [], a = 0; a < n; ++a) i.push(this.arrayOf.deserialize(e, t, !1));
                    return i
                }

                function b(e, t, r, n) {
                    null == t ? e.push(0) : (e.push(1), this.optionalOf.serialize(e, t, r, n))
                }

                function v(e, t, r) {
                    return e.get() ? this.optionalOf.deserialize(e, t, r) : null
                }

                function m(e, t, r, n) {
                    this.extensionOf.serialize(e, t, r, n)
                }

                function w(e, t, r) {
                    return this.extensionOf.deserialize(e, t, r)
                }

                function x(e, t, r, i) {
                    var o, s, u = Object.entries(t);
                    e.pushVaruint32(u.length);
                    try {
                        for (var l = a(u), c = l.next(); !c.done; c = l.next()) {
                            var h = n(c.value, 2),
                                f = h[0],
                                d = h[1],
                                p = this.fields[0].type,
                                _ = this.fields[1].type;
                            p.serialize(e, f, r, i), _.serialize(e, d, r, i)
                        }
                    } catch (y) {
                        o = {
                            error: y
                        }
                    } finally {
                        try {
                            c && !c.done && (s = l.return) && s.call(l)
                        } finally {
                            if (o) throw o.error
                        }
                    }
                }

                function k(e, t, r) {
                    for (var n = e.getVaruint32(), i = {}, a = 0; a < n; ++a) {
                        var o = this.fields[0].type,
                            s = this.fields[1].type;
                        i[o.deserialize(e, t, r)] = s.deserialize(e, t, r)
                    }
                    return i
                }

                function S(e, t, r, n) {
                    var i = this;
                    e.pushVaruint32(t.length), t.forEach((function(t) {
                        i.fields[0].type.serialize(e, t[0], r, n), i.fields[1].type.serialize(e, t[1], r, n)
                    }))
                }

                function E(e, t, r) {
                    for (var n = [], i = e.getVaruint32(), a = 0; a < i; ++a) n.push(this.fields[0].type.deserialize(e, t, r)), n.push(this.fields[1].type.deserialize(e, t, r));
                    return n
                }
                e.dateToTimePoint = function(e) {
                    return Math.round(1e3 * l(e + "Z"))
                }, e.timePointToDate = function(e) {
                    var t = new Date(e / 1e3).toISOString();
                    return t.substr(0, t.length - 1)
                }, e.dateToTimePointSec = function(e) {
                    return Math.round(l(e + "Z") / 1e3)
                }, e.timePointSecToDate = function(e) {
                    var t = new Date(1e3 * e).toISOString();
                    return t.substr(0, t.length - 1)
                }, e.dateToBlockTimestamp = function(e) {
                    return Math.round((l(e + "Z") - 9466848e5) / 500)
                }, e.blockTimestampToDate = function(e) {
                    var t = new Date(500 * e + 9466848e5).toISOString();
                    return t.substr(0, t.length - 1)
                }, e.stringToSymbol = function(e) {
                    if ("string" != typeof e) throw new Error("Expected string containing symbol");
                    var t = e.match(/^([0-9]+),([A-Z]+)$/);
                    if (!t) throw new Error("Invalid symbol");
                    return {
                        name: t[2],
                        precision: +t[1]
                    }
                }, e.symbolToString = function(e) {
                    var t = e.name;
                    return e.precision + "," + t
                }, e.arrayToHex = function(e) {
                    var t, r, n = "";
                    try {
                        for (var i = a(e), o = i.next(); !o.done; o = i.next()) n += ("00" + o.value.toString(16)).slice(-2)
                    } catch (s) {
                        t = {
                            error: s
                        }
                    } finally {
                        try {
                            o && !o.done && (r = i.return) && r.call(i)
                        } finally {
                            if (t) throw t.error
                        }
                    }
                    return n.toUpperCase()
                }, e.hexToUint8Array = function(e) {
                    if ("string" != typeof e) throw new Error("Expected string containing hex digits");
                    if (e.length % 2) throw new Error("Odd number of hex digits");
                    for (var t = e.length / 2, r = new Uint8Array(t), n = 0; n < t; ++n) {
                        var i = parseInt(e.substr(2 * n, 2), 16);
                        if (Number.isNaN(i)) throw new Error("Expected hex string");
                        r[n] = i
                    }
                    return r
                };
                var A = function(e) {
                        return r({
                            name: "<missing name>",
                            aliasOfName: "",
                            arrayOf: null,
                            optionalOf: null,
                            extensionOf: null,
                            baseName: "",
                            base: null,
                            fields: [],
                            serialize: c,
                            deserialize: h
                        }, e)
                    },
                    T = function(e, t) {
                        if (Number.isNaN(+e) || Number.isNaN(+t) || "number" != typeof e && "string" != typeof e) throw new Error("Expected number");
                        if (+e != +t) throw new Error("Number is out of range");
                        return +e
                    };
                e.createInitialTypes = function() {
                    var t = new Map(Object.entries({
                        bool: A({
                            name: "bool",
                            serialize: function(e, t) {
                                if ("boolean" != typeof t && ("number" != typeof t || 1 !== t && 0 !== t)) throw new Error("Expected boolean or number equal to 1 or 0");
                                e.push(t ? 1 : 0)
                            },
                            deserialize: function(e) {
                                return !!e.get()
                            }
                        }),
                        uint8: A({
                            name: "uint8",
                            serialize: function(e, t) {
                                e.push(T(t, 255 & t))
                            },
                            deserialize: function(e) {
                                return e.get()
                            }
                        }),
                        int8: A({
                            name: "int8",
                            serialize: function(e, t) {
                                e.push(T(t, t << 24 >> 24))
                            },
                            deserialize: function(e) {
                                return e.get() << 24 >> 24
                            }
                        }),
                        uint16: A({
                            name: "uint16",
                            serialize: function(e, t) {
                                e.pushUint16(T(t, 65535 & t))
                            },
                            deserialize: function(e) {
                                return e.getUint16()
                            }
                        }),
                        int16: A({
                            name: "int16",
                            serialize: function(e, t) {
                                e.pushUint16(T(t, t << 16 >> 16))
                            },
                            deserialize: function(e) {
                                return e.getUint16() << 16 >> 16
                            }
                        }),
                        uint32: A({
                            name: "uint32",
                            serialize: function(e, t) {
                                e.pushUint32(T(t, t >>> 0))
                            },
                            deserialize: function(e) {
                                return e.getUint32()
                            }
                        }),
                        uint64: A({
                            name: "uint64",
                            serialize: function(e, t) {
                                e.pushArray(o.decimalToBinary(8, "" + t))
                            },
                            deserialize: function(e) {
                                return o.binaryToDecimal(e.getUint8Array(8))
                            }
                        }),
                        int64: A({
                            name: "int64",
                            serialize: function(e, t) {
                                e.pushArray(o.signedDecimalToBinary(8, "" + t))
                            },
                            deserialize: function(e) {
                                return o.signedBinaryToDecimal(e.getUint8Array(8))
                            }
                        }),
                        int32: A({
                            name: "int32",
                            serialize: function(e, t) {
                                e.pushUint32(T(t, 0 | t))
                            },
                            deserialize: function(e) {
                                return 0 | e.getUint32()
                            }
                        }),
                        varuint32: A({
                            name: "varuint32",
                            serialize: function(e, t) {
                                e.pushVaruint32(T(t, t >>> 0))
                            },
                            deserialize: function(e) {
                                return e.getVaruint32()
                            }
                        }),
                        varint32: A({
                            name: "varint32",
                            serialize: function(e, t) {
                                e.pushVarint32(T(t, 0 | t))
                            },
                            deserialize: function(e) {
                                return e.getVarint32()
                            }
                        }),
                        uint128: A({
                            name: "uint128",
                            serialize: function(e, t) {
                                e.pushArray(o.decimalToBinary(16, "" + t))
                            },
                            deserialize: function(e) {
                                return o.binaryToDecimal(e.getUint8Array(16))
                            }
                        }),
                        int128: A({
                            name: "int128",
                            serialize: function(e, t) {
                                e.pushArray(o.signedDecimalToBinary(16, "" + t))
                            },
                            deserialize: function(e) {
                                return o.signedBinaryToDecimal(e.getUint8Array(16))
                            }
                        }),
                        float32: A({
                            name: "float32",
                            serialize: function(e, t) {
                                e.pushFloat32(t)
                            },
                            deserialize: function(e) {
                                return e.getFloat32()
                            }
                        }),
                        float64: A({
                            name: "float64",
                            serialize: function(e, t) {
                                e.pushFloat64(t)
                            },
                            deserialize: function(e) {
                                return e.getFloat64()
                            }
                        }),
                        float128: A({
                            name: "float128",
                            serialize: function(t, r) {
                                t.pushUint8ArrayChecked(e.hexToUint8Array(r), 16)
                            },
                            deserialize: function(t) {
                                return e.arrayToHex(t.getUint8Array(16))
                            }
                        }),
                        bytes: A({
                            name: "bytes",
                            serialize: function(t, r) {
                                r instanceof Uint8Array || Array.isArray(r) ? t.pushBytes(r) : t.pushBytes(e.hexToUint8Array(r))
                            },
                            deserialize: function(t, r) {
                                return r && r.options.bytesAsUint8Array ? t.getBytes() : e.arrayToHex(t.getBytes())
                            }
                        }),
                        string: A({
                            name: "string",
                            serialize: function(e, t) {
                                e.pushString(t)
                            },
                            deserialize: function(e) {
                                return e.getString()
                            }
                        }),
                        name: A({
                            name: "name",
                            serialize: function(e, t) {
                                e.pushName(t)
                            },
                            deserialize: function(e) {
                                return e.getName()
                            }
                        }),
                        time_point: A({
                            name: "time_point",
                            serialize: function(t, r) {
                                t.pushNumberAsUint64(e.dateToTimePoint(r))
                            },
                            deserialize: function(t) {
                                return e.timePointToDate(t.getUint64AsNumber())
                            }
                        }),
                        time_point_sec: A({
                            name: "time_point_sec",
                            serialize: function(t, r) {
                                t.pushUint32(e.dateToTimePointSec(r))
                            },
                            deserialize: function(t) {
                                return e.timePointSecToDate(t.getUint32())
                            }
                        }),
                        block_timestamp_type: A({
                            name: "block_timestamp_type",
                            serialize: function(t, r) {
                                t.pushUint32(e.dateToBlockTimestamp(r))
                            },
                            deserialize: function(t) {
                                return e.blockTimestampToDate(t.getUint32())
                            }
                        }),
                        symbol_code: A({
                            name: "symbol_code",
                            serialize: function(e, t) {
                                e.pushSymbolCode(t)
                            },
                            deserialize: function(e) {
                                return e.getSymbolCode()
                            }
                        }),
                        symbol: A({
                            name: "symbol",
                            serialize: function(t, r) {
                                t.pushSymbol(e.stringToSymbol(r))
                            },
                            deserialize: function(t) {
                                return e.symbolToString(t.getSymbol())
                            }
                        }),
                        asset: A({
                            name: "asset",
                            serialize: function(e, t) {
                                e.pushAsset(t)
                            },
                            deserialize: function(e) {
                                return e.getAsset()
                            }
                        }),
                        checksum160: A({
                            name: "checksum160",
                            serialize: function(t, r) {
                                t.pushUint8ArrayChecked(e.hexToUint8Array(r), 20)
                            },
                            deserialize: function(t) {
                                return e.arrayToHex(t.getUint8Array(20))
                            }
                        }),
                        checksum256: A({
                            name: "checksum256",
                            serialize: function(t, r) {
                                t.pushUint8ArrayChecked(e.hexToUint8Array(r), 32)
                            },
                            deserialize: function(t) {
                                return e.arrayToHex(t.getUint8Array(32))
                            }
                        }),
                        checksum512: A({
                            name: "checksum512",
                            serialize: function(t, r) {
                                t.pushUint8ArrayChecked(e.hexToUint8Array(r), 64)
                            },
                            deserialize: function(t) {
                                return e.arrayToHex(t.getUint8Array(64))
                            }
                        }),
                        public_key: A({
                            name: "public_key",
                            serialize: function(e, t) {
                                e.pushPublicKey(t)
                            },
                            deserialize: function(e) {
                                return e.getPublicKey()
                            }
                        }),
                        private_key: A({
                            name: "private_key",
                            serialize: function(e, t) {
                                e.pushPrivateKey(t)
                            },
                            deserialize: function(e) {
                                return e.getPrivateKey()
                            }
                        }),
                        signature: A({
                            name: "signature",
                            serialize: function(e, t) {
                                e.pushSignature(t)
                            },
                            deserialize: function(e) {
                                return e.getSignature()
                            }
                        })
                    }));
                    return t.set("extended_asset", A({
                        name: "extended_asset",
                        baseName: "",
                        fields: [{
                            name: "quantity",
                            typeName: "asset",
                            type: t.get("asset")
                        }, {
                            name: "contract",
                            typeName: "name",
                            type: t.get("name")
                        }],
                        serialize: f,
                        deserialize: d
                    })), t
                }, e.createAbiTypes = function() {
                    var t = e.createInitialTypes();
                    return t.set("extensions_entry", A({
                        name: "extensions_entry",
                        baseName: "",
                        fields: [{
                            name: "tag",
                            typeName: "uint16",
                            type: null
                        }, {
                            name: "value",
                            typeName: "bytes",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("type_def", A({
                        name: "type_def",
                        baseName: "",
                        fields: [{
                            name: "new_type_name",
                            typeName: "string",
                            type: null
                        }, {
                            name: "type",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("field_def", A({
                        name: "field_def",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "string",
                            type: null
                        }, {
                            name: "type",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("struct_def", A({
                        name: "struct_def",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "string",
                            type: null
                        }, {
                            name: "base",
                            typeName: "string",
                            type: null
                        }, {
                            name: "fields",
                            typeName: "field_def[]",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("action_def", A({
                        name: "action_def",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "type",
                            typeName: "string",
                            type: null
                        }, {
                            name: "ricardian_contract",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("table_def", A({
                        name: "table_def",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "index_type",
                            typeName: "string",
                            type: null
                        }, {
                            name: "key_names",
                            typeName: "string[]",
                            type: null
                        }, {
                            name: "key_types",
                            typeName: "string[]",
                            type: null
                        }, {
                            name: "type",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("clause_pair", A({
                        name: "clause_pair",
                        baseName: "",
                        fields: [{
                            name: "id",
                            typeName: "string",
                            type: null
                        }, {
                            name: "body",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("error_message", A({
                        name: "error_message",
                        baseName: "",
                        fields: [{
                            name: "error_code",
                            typeName: "uint64",
                            type: null
                        }, {
                            name: "error_msg",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("variant_def", A({
                        name: "variant_def",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "string",
                            type: null
                        }, {
                            name: "types",
                            typeName: "string[]",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("action_result", A({
                        name: "action_result",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "result_type",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("primary_key_index_def", A({
                        name: "primary_key_index_def",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "type",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("secondary_index_def", A({
                        name: "secondary_index_def",
                        baseName: "",
                        fields: [{
                            name: "type",
                            typeName: "string",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("secondary_indices", A({
                        name: "secondary_indices",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "secondary_index_def",
                            typeName: "secondary_index_def",
                            type: null
                        }],
                        serialize: x,
                        deserialize: k
                    })), t.set("kv_table_entry_def", A({
                        name: "kv_table_entry_def",
                        baseName: "",
                        fields: [{
                            name: "type",
                            typeName: "string",
                            type: null
                        }, {
                            name: "primary_index",
                            typeName: "primary_key_index_def",
                            type: null
                        }, {
                            name: "secondary_indices",
                            typeName: "secondary_indices",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("kv_table", A({
                        name: "kv_table",
                        baseName: "",
                        fields: [{
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "kv_table_entry_def",
                            typeName: "kv_table_entry_def",
                            type: null
                        }],
                        serialize: x,
                        deserialize: k
                    })), t.set("abi_def", A({
                        name: "abi_def",
                        baseName: "",
                        fields: [{
                            name: "version",
                            typeName: "string",
                            type: null
                        }, {
                            name: "types",
                            typeName: "type_def[]",
                            type: null
                        }, {
                            name: "structs",
                            typeName: "struct_def[]",
                            type: null
                        }, {
                            name: "actions",
                            typeName: "action_def[]",
                            type: null
                        }, {
                            name: "tables",
                            typeName: "table_def[]",
                            type: null
                        }, {
                            name: "ricardian_clauses",
                            typeName: "clause_pair[]",
                            type: null
                        }, {
                            name: "error_messages",
                            typeName: "error_message[]",
                            type: null
                        }, {
                            name: "abi_extensions",
                            typeName: "extensions_entry[]",
                            type: null
                        }, {
                            name: "variants",
                            typeName: "variant_def[]$",
                            type: null
                        }, {
                            name: "action_results",
                            typeName: "action_result[]$",
                            type: null
                        }, {
                            name: "kv_tables",
                            typeName: "kv_table$",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t
                }, e.createTransactionExtensionTypes = function() {
                    var t = e.createInitialTypes();
                    return t.set("resource_payer", A({
                        name: "resource_payer",
                        baseName: "",
                        fields: [{
                            name: "payer",
                            typeName: "name",
                            type: null
                        }, {
                            name: "max_net_bytes",
                            typeName: "uint64",
                            type: null
                        }, {
                            name: "max_cpu_us",
                            typeName: "uint64",
                            type: null
                        }, {
                            name: "max_memory_bytes",
                            typeName: "uint64",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t
                }, e.createTransactionTypes = function() {
                    var t = e.createInitialTypes();
                    return t.set("permission_level", A({
                        name: "permission_level",
                        baseName: "",
                        fields: [{
                            name: "actor",
                            typeName: "name",
                            type: null
                        }, {
                            name: "permission",
                            typeName: "name",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("action", A({
                        name: "action",
                        baseName: "",
                        fields: [{
                            name: "account",
                            typeName: "name",
                            type: null
                        }, {
                            name: "name",
                            typeName: "name",
                            type: null
                        }, {
                            name: "authorization",
                            typeName: "permission_level[]",
                            type: null
                        }, {
                            name: "data",
                            typeName: "bytes",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("extension", A({
                        name: "extension",
                        baseName: "",
                        fields: [{
                            name: "type",
                            typeName: "uint16",
                            type: null
                        }, {
                            name: "data",
                            typeName: "bytes",
                            type: null
                        }],
                        serialize: S,
                        deserialize: E
                    })), t.set("transaction_header", A({
                        name: "transaction_header",
                        baseName: "",
                        fields: [{
                            name: "expiration",
                            typeName: "time_point_sec",
                            type: null
                        }, {
                            name: "ref_block_num",
                            typeName: "uint16",
                            type: null
                        }, {
                            name: "ref_block_prefix",
                            typeName: "uint32",
                            type: null
                        }, {
                            name: "max_net_usage_words",
                            typeName: "varuint32",
                            type: null
                        }, {
                            name: "max_cpu_usage_ms",
                            typeName: "uint8",
                            type: null
                        }, {
                            name: "delay_sec",
                            typeName: "varuint32",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t.set("transaction", A({
                        name: "transaction",
                        baseName: "transaction_header",
                        fields: [{
                            name: "context_free_actions",
                            typeName: "action[]",
                            type: null
                        }, {
                            name: "actions",
                            typeName: "action[]",
                            type: null
                        }, {
                            name: "transaction_extensions",
                            typeName: "extension",
                            type: null
                        }],
                        serialize: f,
                        deserialize: d
                    })), t
                }, e.getType = function(t, r) {
                    var n = t.get(r);
                    if (n && n.aliasOfName) return e.getType(t, n.aliasOfName);
                    if (n) return n;
                    if (r.endsWith("[]")) return A({
                        name: r,
                        arrayOf: e.getType(t, r.substr(0, r.length - 2)),
                        serialize: y,
                        deserialize: g
                    });
                    if (r.endsWith("?")) return A({
                        name: r,
                        optionalOf: e.getType(t, r.substr(0, r.length - 1)),
                        serialize: b,
                        deserialize: v
                    });
                    if (r.endsWith("$")) return A({
                        name: r,
                        extensionOf: e.getType(t, r.substr(0, r.length - 1)),
                        serialize: m,
                        deserialize: w
                    });
                    throw new Error("Unknown type: " + r)
                }, e.getTypesFromAbi = function(t, r) {
                    var i, o, s, u, l, c, h, y, g, b, v = new Map(t);
                    if (r && r.types) try {
                        for (var m = a(r.types), w = m.next(); !w.done; w = m.next()) {
                            var x = w.value,
                                k = x.new_type_name,
                                S = x.type;
                            v.set(k, A({
                                name: k,
                                aliasOfName: S
                            }))
                        }
                    } catch (K) {
                        i = {
                            error: K
                        }
                    } finally {
                        try {
                            w && !w.done && (o = m.return) && o.call(m)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                    if (r && r.structs) try {
                        for (var E = a(r.structs), T = E.next(); !T.done; T = E.next()) {
                            var z = T.value,
                                O = z.name,
                                R = z.base,
                                P = z.fields;
                            v.set(O, A({
                                name: O,
                                baseName: R,
                                fields: P.map((function(e) {
                                    return {
                                        name: e.name,
                                        typeName: e.type,
                                        type: null
                                    }
                                })),
                                serialize: f,
                                deserialize: d
                            }))
                        }
                    } catch (W) {
                        s = {
                            error: W
                        }
                    } finally {
                        try {
                            T && !T.done && (u = E.return) && u.call(E)
                        } finally {
                            if (s) throw s.error
                        }
                    }
                    if (r && r.variants) try {
                        for (var N = a(r.variants), D = N.next(); !D.done; D = N.next()) {
                            var L = D.value,
                                U = L.name,
                                I = L.types;
                            v.set(U, A({
                                name: U,
                                fields: I.map((function(e) {
                                    return {
                                        name: e,
                                        typeName: e,
                                        type: null
                                    }
                                })),
                                serialize: p,
                                deserialize: _
                            }))
                        }
                    } catch (q) {
                        l = {
                            error: q
                        }
                    } finally {
                        try {
                            D && !D.done && (c = N.return) && c.call(N)
                        } finally {
                            if (l) throw l.error
                        }
                    }
                    try {
                        for (var B = a(v), j = B.next(); !j.done; j = B.next()) {
                            var M = n(j.value, 2);
                            M[0], (S = M[1]).baseName && (S.base = e.getType(v, S.baseName));
                            try {
                                for (var C = (g = void 0, a(S.fields)), F = C.next(); !F.done; F = C.next()) {
                                    var H = F.value;
                                    H.type = e.getType(v, H.typeName)
                                }
                            } catch (Z) {
                                g = {
                                    error: Z
                                }
                            } finally {
                                try {
                                    F && !F.done && (b = C.return) && b.call(C)
                                } finally {
                                    if (g) throw g.error
                                }
                            }
                        }
                    } catch (V) {
                        h = {
                            error: V
                        }
                    } finally {
                        try {
                            j && !j.done && (y = B.return) && y.call(B)
                        } finally {
                            if (h) throw h.error
                        }
                    }
                    return v
                }, e.transactionHeader = function(t, r) {
                    var n, i = t.header ? t.header.timestamp : t.timestamp,
                        a = parseInt((n = t.id.substr(16, 8)).substr(6, 2) + n.substr(4, 2) + n.substr(2, 2) + n.substr(0, 2), 16);
                    return {
                        expiration: e.timePointSecToDate(e.dateToTimePointSec(i) + r),
                        ref_block_num: 65535 & t.block_num,
                        ref_block_prefix: a
                    }
                }, e.serializeActionData = function(t, r, n, i, a, o) {
                    var s = t.actions.get(n);
                    if (!s) throw new Error("Unknown action " + n + " in contract " + r);
                    var l = new u({
                        textEncoder: a,
                        textDecoder: o
                    });
                    return s.serialize(l, i), e.arrayToHex(l.asUint8Array())
                }, e.serializeAction = function(t, r, n, i, a, o, s) {
                    return {
                        account: r,
                        name: n,
                        authorization: i,
                        data: e.serializeActionData(t, r, n, a, o, s)
                    }
                }, e.deserializeActionData = function(t, r, n, i, a, o) {
                    var s = t.actions.get(n);
                    if ("string" == typeof i && (i = e.hexToUint8Array(i)), !s) throw new Error("Unknown action " + n + " in contract " + r);
                    var l = new u({
                        textDecoder: o,
                        textEncoder: a
                    });
                    return l.pushArray(i), s.deserialize(l)
                }, e.deserializeAction = function(t, r, n, i, a, o, s) {
                    return {
                        account: r,
                        name: n,
                        authorization: i,
                        data: e.deserializeActionData(t, r, n, a, o, s)
                    }
                }, e.serializeAnyvar = function(e, t) {
                    var r, i, a, o, s, u, l, c, h;
                    null === t ? (c = (r = n([R.null_t, t], 2))[0], h = r[1]) : "string" == typeof t ? (c = (i = n([R.string, t], 2))[0], h = i[1]) : "number" == typeof t ? (c = (a = n([R.int32, t], 2))[0], h = a[1]) : t instanceof Uint8Array ? (c = (o = n([R.bytes, t], 2))[0], h = o[1]) : Array.isArray(t) ? (c = (s = n([R.any_array, t], 2))[0], h = s[1]) : 2 === Object.keys(t).length && t.hasOwnProperty("type") && t.hasOwnProperty("value") ? (c = (u = n([R[t.type], t.value], 2))[0], h = u[1]) : (c = (l = n([R.any_object, t], 2))[0], h = l[1]), e.pushVaruint32(c.index), c.type.serialize(e, h)
                }, e.deserializeAnyvar = function(e, t) {
                    var r = e.getVaruint32();
                    if (r >= P.length) throw new Error("Tried to deserialize unknown anyvar type");
                    var n = P[r],
                        i = n.type.deserialize(e, t);
                    return t && t.options.useShortForm || n.useShortForm ? i : {
                        type: n.type.name,
                        value: i
                    }
                }, e.deserializeAnyvarShort = function(t) {
                    return e.deserializeAnyvar(t, new s({
                        useShortForm: !0
                    }))
                }, e.serializeAnyObject = function(t, r) {
                    var i, o, s = Object.entries(r);
                    t.pushVaruint32(s.length);
                    try {
                        for (var u = a(s), l = u.next(); !l.done; l = u.next()) {
                            var c = n(l.value, 2),
                                h = c[0],
                                f = c[1];
                            t.pushString(h), e.serializeAnyvar(t, f)
                        }
                    } catch (d) {
                        i = {
                            error: d
                        }
                    } finally {
                        try {
                            l && !l.done && (o = u.return) && o.call(u)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                }, e.deserializeAnyObject = function(t, r) {
                    for (var n = t.getVaruint32(), i = {}, a = 0; a < n; ++a) {
                        var o = t.getString();
                        if (o in i) {
                            for (var s = 1; o + "_" + s in i;) ++s;
                            o = o + "_" + s
                        }
                        i[o] = e.deserializeAnyvar(t, r)
                    }
                    return i
                }, e.serializeAnyArray = function(t, r) {
                    var n, i;
                    t.pushVaruint32(r.length);
                    try {
                        for (var o = a(r), s = o.next(); !s.done; s = o.next()) {
                            var u = s.value;
                            e.serializeAnyvar(t, u)
                        }
                    } catch (l) {
                        n = {
                            error: l
                        }
                    } finally {
                        try {
                            s && !s.done && (i = o.return) && i.call(o)
                        } finally {
                            if (n) throw n.error
                        }
                    }
                }, e.deserializeAnyArray = function(t, r) {
                    for (var n = t.getVaruint32(), i = [], a = 0; a < n; ++a) i.push(e.deserializeAnyvar(t, r));
                    return i
                };
                var z, O = ((z = e.createInitialTypes()).set("null_t", A({
                        name: "null_t",
                        serialize: function(e, t) {},
                        deserialize: function(e, t) {}
                    })), z.set("any_object", A({
                        name: "any_object",
                        serialize: e.serializeAnyObject,
                        deserialize: e.deserializeAnyObject
                    })), z.set("any_array", A({
                        name: "any_array",
                        serialize: e.serializeAnyArray,
                        deserialize: e.deserializeAnyArray
                    })), z),
                    R = {
                        null_t: {
                            index: 0,
                            useShortForm: !0,
                            type: O.get("null_t")
                        },
                        int64: {
                            index: 1,
                            useShortForm: !1,
                            type: O.get("int64")
                        },
                        uint64: {
                            index: 2,
                            useShortForm: !1,
                            type: O.get("uint64")
                        },
                        int32: {
                            index: 3,
                            useShortForm: !0,
                            type: O.get("int32")
                        },
                        uint32: {
                            index: 4,
                            useShortForm: !1,
                            type: O.get("uint32")
                        },
                        int16: {
                            index: 5,
                            useShortForm: !1,
                            type: O.get("int16")
                        },
                        uint16: {
                            index: 6,
                            useShortForm: !1,
                            type: O.get("uint16")
                        },
                        int8: {
                            index: 7,
                            useShortForm: !1,
                            type: O.get("int8")
                        },
                        uint8: {
                            index: 8,
                            useShortForm: !1,
                            type: O.get("uint8")
                        },
                        time_point: {
                            index: 9,
                            useShortForm: !1,
                            type: O.get("time_point")
                        },
                        checksum256: {
                            index: 10,
                            useShortForm: !1,
                            type: O.get("checksum256")
                        },
                        float64: {
                            index: 11,
                            useShortForm: !1,
                            type: O.get("float64")
                        },
                        string: {
                            index: 12,
                            useShortForm: !0,
                            type: O.get("string")
                        },
                        any_object: {
                            index: 13,
                            useShortForm: !0,
                            type: O.get("any_object")
                        },
                        any_array: {
                            index: 14,
                            useShortForm: !0,
                            type: O.get("any_array")
                        },
                        bytes: {
                            index: 15,
                            useShortForm: !1,
                            type: O.get("bytes")
                        },
                        symbol: {
                            index: 16,
                            useShortForm: !1,
                            type: O.get("symbol")
                        },
                        symbol_code: {
                            index: 17,
                            useShortForm: !1,
                            type: O.get("symbol_code")
                        },
                        asset: {
                            index: 18,
                            useShortForm: !1,
                            type: O.get("asset")
                        }
                    },
                    P = [R.null_t, R.int64, R.uint64, R.int32, R.uint32, R.int16, R.uint16, R.int8, R.uint8, R.time_point, R.checksum256, R.float64, R.string, R.any_object, R.any_array, R.bytes, R.symbol, R.symbol_code, R.asset];
                e.serializeQuery = function(t, r) {
                    var i, o, s, u, l, c, h, f;
                    if ("string" == typeof r ? c = r : Array.isArray(r) && 2 === r.length ? (c = (i = n(r, 2))[0], f = i[1]) : Array.isArray(r) && 3 === r.length ? (c = (o = n(r, 3))[0], h = o[1], f = o[2]) : (c = (s = n([r.method, r.arg, r.filter], 3))[0], h = s[1], f = s[2]), t.pushString(c), void 0 === h ? t.push(0) : (t.push(1), e.serializeAnyvar(t, h)), void 0 === f) t.push(0);
                    else {
                        t.pushVaruint32(f.length);
                        try {
                            for (var d = a(f), p = d.next(); !p.done; p = d.next()) {
                                var _ = p.value;
                                e.serializeQuery(t, _)
                            }
                        } catch (y) {
                            u = {
                                error: y
                            }
                        } finally {
                            try {
                                p && !p.done && (l = d.return) && l.call(d)
                            } finally {
                                if (u) throw u.error
                            }
                        }
                    }
                }
            }(Tr);
            var Di = t && t.__assign || function() {
                    return Di = Object.assign || function(e) {
                        for (var t, r = 1, n = arguments.length; r < n; r++)
                            for (var i in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                        return e
                    }, Di.apply(this, arguments)
                },
                Li = t && t.__awaiter || function(e, t, r, n) {
                    return new(r || (r = Promise))((function(i, a) {
                        function o(e) {
                            try {
                                u(n.next(e))
                            } catch (t) {
                                a(t)
                            }
                        }

                        function s(e) {
                            try {
                                u(n.throw(e))
                            } catch (t) {
                                a(t)
                            }
                        }

                        function u(e) {
                            var t;
                            e.done ? i(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(o, s)
                        }
                        u((n = n.apply(e, t || [])).next())
                    }))
                },
                Ui = t && t.__generator || function(e, t) {
                    var r, n, i, a, o = {
                        label: 0,
                        sent: function() {
                            if (1 & i[0]) throw i[1];
                            return i[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(a) {
                        return function(s) {
                            return function(a) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; o;) try {
                                    if (r = 1, n && (i = 2 & a[0] ? n.return : a[0] ? n.throw || ((i = n.return) && i.call(n), 0) : n.next) && !(i = i.call(n, a[1])).done) return i;
                                    switch (n = 0, i && (a = [2 & a[0], i.value]), a[0]) {
                                        case 0:
                                        case 1:
                                            i = a;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: a[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, n = a[1], a = [0];
                                            continue;
                                        case 7:
                                            a = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!((i = (i = o.trys).length > 0 && i[i.length - 1]) || 6 !== a[0] && 2 !== a[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === a[0] && (!i || a[1] > i[0] && a[1] < i[3])) {
                                                o.label = a[1];
                                                break
                                            }
                                            if (6 === a[0] && o.label < i[1]) {
                                                o.label = i[1], i = a;
                                                break
                                            }
                                            if (i && o.label < i[2]) {
                                                o.label = i[2], o.ops.push(a);
                                                break
                                            }
                                            i[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    a = t.call(e, o)
                                } catch (s) {
                                    a = [6, s], n = 0
                                } finally {
                                    r = i = 0
                                }
                                if (5 & a[0]) throw a[1];
                                return {
                                    value: a[0] ? a[1] : void 0,
                                    done: !0
                                }
                            }([a, s])
                        }
                    }
                },
                Ii = t && t.__read || function(e, t) {
                    var r = "function" == typeof Symbol && e[Symbol.iterator];
                    if (!r) return e;
                    var n, i, a = r.call(e),
                        o = [];
                    try {
                        for (;
                            (void 0 === t || t-- > 0) && !(n = a.next()).done;) o.push(n.value)
                    } catch (s) {
                        i = {
                            error: s
                        }
                    } finally {
                        try {
                            n && !n.done && (r = a.return) && r.call(a)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                    return o
                },
                Bi = t && t.__spreadArray || function(e, t) {
                    for (var r = 0, n = t.length, i = e.length; r < n; r++, i++) e[i] = t[r];
                    return e
                },
                ji = t && t.__values || function(e) {
                    var t = "function" == typeof Symbol && Symbol.iterator,
                        r = t && e[t],
                        n = 0;
                    if (r) return r.call(e);
                    if (e && "number" == typeof e.length) return {
                        next: function() {
                            return e && n >= e.length && (e = void 0), {
                                value: e && e[n++],
                                done: !e
                            }
                        }
                    };
                    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
                };
            Object.defineProperty(u, "__esModule", {
                value: !0
            }), u.ActionBuilder = u.TransactionBuilder = u.Api = void 0;
            var Mi = l,
                Ci = Tr,
                Fi = function() {
                    function e(e) {
                        this.contracts = new Map, this.cachedAbis = new Map, this.transactionExtensions = [{
                            id: 1,
                            type: "resource_payer",
                            keys: ["payer", "max_net_bytes", "max_cpu_us", "max_memory_bytes"]
                        }], this.rpc = e.rpc, this.authorityProvider = e.authorityProvider || e.rpc, this.abiProvider = e.abiProvider || e.rpc, this.signatureProvider = e.signatureProvider, this.chainId = e.chainId, this.textEncoder = e.textEncoder, this.textDecoder = e.textDecoder, this.abiTypes = Ci.getTypesFromAbi(Ci.createAbiTypes()), this.transactionTypes = Ci.getTypesFromAbi(Ci.createTransactionTypes())
                    }
                    return e.prototype.rawAbiToJson = function(e) {
                        var t = new Ci.SerialBuffer({
                            textEncoder: this.textEncoder,
                            textDecoder: this.textDecoder,
                            array: e
                        });
                        if (!Ci.supportedAbiVersion(t.getString())) throw new Error("Unsupported abi version");
                        return t.restartRead(), this.abiTypes.get("abi_def").deserialize(t)
                    }, e.prototype.jsonToRawAbi = function(e) {
                        var t = new Ci.SerialBuffer({
                            textEncoder: this.textEncoder,
                            textDecoder: this.textDecoder
                        });
                        if (this.abiTypes.get("abi_def").serialize(t, e), !Ci.supportedAbiVersion(t.getString())) throw new Error("Unsupported abi version");
                        return t.asUint8Array()
                    }, e.prototype.getCachedAbi = function(e, t) {
                        return void 0 === t && (t = !1), Li(this, void 0, void 0, (function() {
                            var r, n, i, a;
                            return Ui(this, (function(o) {
                                switch (o.label) {
                                    case 0:
                                        if (!t && this.cachedAbis.get(e)) return [2, this.cachedAbis.get(e)];
                                        o.label = 1;
                                    case 1:
                                        return o.trys.push([1, 3, , 4]), [4, this.abiProvider.getRawAbi(e)];
                                    case 2:
                                        return n = o.sent().abi, i = this.rawAbiToJson(n), r = {
                                            rawAbi: n,
                                            abi: i
                                        }, [3, 4];
                                    case 3:
                                        throw (a = o.sent()).message = "fetching abi for " + e + ": " + a.message, a;
                                    case 4:
                                        if (!r) throw new Error("Missing abi for " + e);
                                        return this.cachedAbis.set(e, r), [2, r]
                                }
                            }))
                        }))
                    }, e.prototype.getAbi = function(e, t) {
                        return void 0 === t && (t = !1), Li(this, void 0, void 0, (function() {
                            return Ui(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return [4, this.getCachedAbi(e, t)];
                                    case 1:
                                        return [2, r.sent().abi]
                                }
                            }))
                        }))
                    }, e.prototype.getTransactionAbis = function(e, t) {
                        return void 0 === t && (t = !1), Li(this, void 0, void 0, (function() {
                            var r, n, i, a, o = this;
                            return Ui(this, (function(s) {
                                return r = (e.context_free_actions || []).concat(e.actions), n = r.map((function(e) {
                                    return e.account
                                })), i = new Set(n), a = Bi([], Ii(i)).map((function(e) {
                                    return Li(o, void 0, void 0, (function() {
                                        var r;
                                        return Ui(this, (function(n) {
                                            switch (n.label) {
                                                case 0:
                                                    return r = {
                                                        accountName: e
                                                    }, [4, this.getCachedAbi(e, t)];
                                                case 1:
                                                    return [2, (r.abi = n.sent().rawAbi, r)]
                                            }
                                        }))
                                    }))
                                })), [2, Promise.all(a)]
                            }))
                        }))
                    }, e.prototype.getContract = function(e, t) {
                        return void 0 === t && (t = !1), Li(this, void 0, void 0, (function() {
                            var r, n, i, a, o, s, u, l, c, h, f;
                            return Ui(this, (function(d) {
                                switch (d.label) {
                                    case 0:
                                        return !t && this.contracts.get(e) ? [2, this.contracts.get(e)] : [4, this.getAbi(e, t)];
                                    case 1:
                                        r = d.sent(), n = Ci.getTypesFromAbi(Ci.createInitialTypes(), r), i = new Map;
                                        try {
                                            for (a = ji(r.actions), o = a.next(); !o.done; o = a.next()) s = o.value, u = s.name, l = s.type, i.set(u, Ci.getType(n, l))
                                        } catch (p) {
                                            h = {
                                                error: p
                                            }
                                        } finally {
                                            try {
                                                o && !o.done && (f = a.return) && f.call(a)
                                            } finally {
                                                if (h) throw h.error
                                            }
                                        }
                                        return c = {
                                            types: n,
                                            actions: i
                                        }, this.contracts.set(e, c), [2, c]
                                }
                            }))
                        }))
                    }, e.prototype.serialize = function(e, t, r) {
                        this.transactionTypes.get(t).serialize(e, r)
                    }, e.prototype.deserialize = function(e, t) {
                        return this.transactionTypes.get(t).deserialize(e)
                    }, e.prototype.serializeTransaction = function(e) {
                        var t = new Ci.SerialBuffer({
                            textEncoder: this.textEncoder,
                            textDecoder: this.textDecoder
                        });
                        return this.serialize(t, "transaction", Di({
                            max_net_usage_words: 0,
                            max_cpu_usage_ms: 0,
                            delay_sec: 0,
                            context_free_actions: [],
                            actions: [],
                            transaction_extensions: []
                        }, e)), t.asUint8Array()
                    }, e.prototype.serializeContextFreeData = function(e) {
                        var t, r;
                        if (!e || !e.length) return null;
                        var n = new Ci.SerialBuffer({
                            textEncoder: this.textEncoder,
                            textDecoder: this.textDecoder
                        });
                        n.pushVaruint32(e.length);
                        try {
                            for (var i = ji(e), a = i.next(); !a.done; a = i.next()) {
                                var o = a.value;
                                n.pushBytes(o)
                            }
                        } catch (s) {
                            t = {
                                error: s
                            }
                        } finally {
                            try {
                                a && !a.done && (r = i.return) && r.call(i)
                            } finally {
                                if (t) throw t.error
                            }
                        }
                        return n.asUint8Array()
                    }, e.prototype.deserializeTransaction = function(e) {
                        var t = new Ci.SerialBuffer({
                            textEncoder: this.textEncoder,
                            textDecoder: this.textDecoder
                        });
                        return t.pushArray(e), this.deserialize(t, "transaction")
                    }, e.prototype.serializeTransactionExtensions = function(e) {
                        var t = [];
                        if (e.resource_payer) {
                            var r = new Ci.SerialBuffer({
                                textEncoder: this.textEncoder,
                                textDecoder: this.textDecoder
                            });
                            Ci.getTypesFromAbi(Ci.createTransactionExtensionTypes()).get("resource_payer").serialize(r, e.resource_payer), t = Bi(Bi([], Ii(t)), [
                                [1, Ci.arrayToHex(r.asUint8Array())]
                            ])
                        }
                        return t
                    }, e.prototype.deserializeTransactionExtensions = function(e) {
                        var t = this,
                            r = {};
                        return e.forEach((function(e) {
                            var n = t.transactionExtensions.find((function(t) {
                                return t.id === e[0]
                            }));
                            if (void 0 === n) throw new Error("Transaction Extension could not be determined: " + e);
                            var i = Ci.getTypesFromAbi(Ci.createTransactionExtensionTypes()),
                                a = new Ci.SerialBuffer({
                                    textEncoder: t.textEncoder,
                                    textDecoder: t.textDecoder
                                });
                            a.pushArray(Ci.hexToUint8Array(e[1]));
                            var o = i.get(n.type).deserialize(a);
                            1 === e[0] && (o.max_net_bytes = Number(o.max_net_bytes), o.max_cpu_us = Number(o.max_cpu_us), o.max_memory_bytes = Number(o.max_memory_bytes), r.resource_payer = o)
                        })), r
                    }, e.prototype.deleteTransactionExtensionObjects = function(e) {
                        return delete e.resource_payer, e
                    }, e.prototype.serializeActions = function(e) {
                        return Li(this, void 0, void 0, (function() {
                            var t = this;
                            return Ui(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return [4, Promise.all(e.map((function(e) {
                                            return Li(t, void 0, void 0, (function() {
                                                var t, r, n, i, a;
                                                return Ui(this, (function(o) {
                                                    switch (o.label) {
                                                        case 0:
                                                            return t = e.account, r = e.name, n = e.authorization, i = e.data, [4, this.getContract(t)];
                                                        case 1:
                                                            return a = o.sent(), "object" != typeof i ? [2, e] : [2, Ci.serializeAction(a, t, r, n, i, this.textEncoder, this.textDecoder)]
                                                    }
                                                }))
                                            }))
                                        })))];
                                    case 1:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.deserializeActions = function(e) {
                        return Li(this, void 0, void 0, (function() {
                            var t = this;
                            return Ui(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return [4, Promise.all(e.map((function(e) {
                                            var r = e.account,
                                                n = e.name,
                                                i = e.authorization,
                                                a = e.data;
                                            return Li(t, void 0, void 0, (function() {
                                                var e;
                                                return Ui(this, (function(t) {
                                                    switch (t.label) {
                                                        case 0:
                                                            return [4, this.getContract(r)];
                                                        case 1:
                                                            return e = t.sent(), [2, Ci.deserializeAction(e, r, n, i, a, this.textEncoder, this.textDecoder)]
                                                    }
                                                }))
                                            }))
                                        })))];
                                    case 1:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.deserializeTransactionWithActions = function(e) {
                        return Li(this, void 0, void 0, (function() {
                            var t, r, n;
                            return Ui(this, (function(i) {
                                switch (i.label) {
                                    case 0:
                                        return "string" == typeof e && (e = Ci.hexToUint8Array(e)), t = this.deserializeTransaction(e), [4, this.deserializeActions(t.context_free_actions)];
                                    case 1:
                                        return r = i.sent(), [4, this.deserializeActions(t.actions)];
                                    case 2:
                                        return n = i.sent(), [2, Di(Di({}, t), {
                                            context_free_actions: r,
                                            actions: n
                                        })]
                                }
                            }))
                        }))
                    }, e.prototype.deflateSerializedArray = function(e) {
                        return Mi.deflate(e, {
                            level: 9
                        })
                    }, e.prototype.inflateSerializedArray = function(e) {
                        return Mi.inflate(e)
                    }, e.prototype.transact = function(e, t) {
                        var r = void 0 === t ? {} : t,
                            n = r.broadcast,
                            i = void 0 === n || n,
                            a = r.sign,
                            o = void 0 === a || a,
                            s = r.readOnlyTrx,
                            u = r.returnFailureTraces,
                            l = r.requiredKeys,
                            c = r.compression,
                            h = r.blocksBehind,
                            f = r.useLastIrreversible,
                            d = r.expireSeconds;
                        return Li(this, void 0, void 0, (function() {
                            var t, r, n, a, p, _, y, g;
                            return Ui(this, (function(b) {
                                switch (b.label) {
                                    case 0:
                                        if ("number" == typeof h && f) throw new Error("Use either blocksBehind or useLastIrreversible");
                                        return this.chainId ? [3, 2] : [4, this.rpc.get_info()];
                                    case 1:
                                        t = b.sent(), this.chainId = t.chain_id, b.label = 2;
                                    case 2:
                                        return "number" != typeof h && !f || !d ? [3, 4] : [4, this.generateTapos(t, e, h, f, d)];
                                    case 3:
                                        e = b.sent(), b.label = 4;
                                    case 4:
                                        if (!this.hasRequiredTaposFields(e)) throw new Error("Required configuration or TAPOS fields are not present");
                                        return [4, this.getTransactionAbis(e)];
                                    case 5:
                                        return r = b.sent(), n = [Di({}, e)], g = {}, [4, this.serializeTransactionExtensions(e)];
                                    case 6:
                                        return g.transaction_extensions = b.sent(), [4, this.serializeActions(e.context_free_actions || [])];
                                    case 7:
                                        return g.context_free_actions = b.sent(), [4, this.serializeActions(e.actions)];
                                    case 8:
                                        return e = Di.apply(void 0, n.concat([(g.actions = b.sent(), g)])), e = this.deleteTransactionExtensionObjects(e), a = this.serializeTransaction(e), p = this.serializeContextFreeData(e.context_free_data), _ = {
                                            serializedTransaction: a,
                                            serializedContextFreeData: p,
                                            signatures: []
                                        }, o ? l ? [3, 11] : [4, this.signatureProvider.getAvailableKeys()] : [3, 13];
                                    case 9:
                                        return y = b.sent(), [4, this.authorityProvider.getRequiredKeys({
                                            transaction: e,
                                            availableKeys: y
                                        })];
                                    case 10:
                                        l = b.sent(), b.label = 11;
                                    case 11:
                                        return [4, this.signatureProvider.sign({
                                            chainId: this.chainId,
                                            requiredKeys: l,
                                            serializedTransaction: a,
                                            serializedContextFreeData: p,
                                            abis: r
                                        })];
                                    case 12:
                                        _ = b.sent(), b.label = 13;
                                    case 13:
                                        return i ? c ? [2, this.pushCompressedSignedTransaction(_, s, u)] : [2, this.pushSignedTransaction(_, s, u)] : [2, _]
                                }
                            }))
                        }))
                    }, e.prototype.query = function(e, t, r, n) {
                        var i = n.sign,
                            a = n.requiredKeys,
                            o = n.authorization,
                            s = void 0 === o ? [] : o;
                        return Li(this, void 0, void 0, (function() {
                            var n, o, u, l, c, h, f, d, p, _, y;
                            return Ui(this, (function(g) {
                                switch (g.label) {
                                    case 0:
                                        return [4, this.rpc.get_info()];
                                    case 1:
                                        return n = g.sent(), [4, this.tryRefBlockFromGetInfo(n)];
                                    case 2:
                                        return o = g.sent(), u = new Ci.SerialBuffer({
                                            textEncoder: this.textEncoder,
                                            textDecoder: this.textDecoder
                                        }), Ci.serializeQuery(u, r), l = Di(Di({}, Ci.transactionHeader(o, 1800)), {
                                            context_free_actions: [],
                                            actions: [{
                                                account: e,
                                                name: "queryit",
                                                authorization: s,
                                                data: Ci.arrayToHex(u.asUint8Array())
                                            }]
                                        }), c = this.serializeTransaction(l), h = [], i ? [4, this.getTransactionAbis(l)] : [3, 8];
                                    case 3:
                                        return f = g.sent(), a ? [3, 6] : [4, this.signatureProvider.getAvailableKeys()];
                                    case 4:
                                        return d = g.sent(), [4, this.authorityProvider.getRequiredKeys({
                                            transaction: l,
                                            availableKeys: d
                                        })];
                                    case 5:
                                        a = g.sent(), g.label = 6;
                                    case 6:
                                        return [4, this.signatureProvider.sign({
                                            chainId: this.chainId,
                                            requiredKeys: a,
                                            serializedTransaction: c,
                                            serializedContextFreeData: null,
                                            abis: f
                                        })];
                                    case 7:
                                        p = g.sent(), h = p.signatures, g.label = 8;
                                    case 8:
                                        return [4, this.rpc.send_transaction({
                                            signatures: h,
                                            compression: 0,
                                            serializedTransaction: c
                                        })];
                                    case 9:
                                        return _ = g.sent(), y = new Ci.SerialBuffer({
                                            textEncoder: this.textEncoder,
                                            textDecoder: this.textDecoder,
                                            array: Ci.hexToUint8Array(_.processed.action_traces[0][1].return_value)
                                        }), t ? [2, Ci.deserializeAnyvarShort(y)] : [2, Ci.deserializeAnyvar(y)]
                                }
                            }))
                        }))
                    }, e.prototype.pushSignedTransaction = function(e, t, r) {
                        var n = e.signatures,
                            i = e.serializedTransaction,
                            a = e.serializedContextFreeData;
                        return void 0 === t && (t = !1), void 0 === r && (r = !1), Li(this, void 0, void 0, (function() {
                            return Ui(this, (function(e) {
                                return t ? [2, this.rpc.push_ro_transaction({
                                    signatures: n,
                                    serializedTransaction: i,
                                    serializedContextFreeData: a
                                }, r)] : [2, this.rpc.push_transaction({
                                    signatures: n,
                                    serializedTransaction: i,
                                    serializedContextFreeData: a
                                })]
                            }))
                        }))
                    }, e.prototype.pushCompressedSignedTransaction = function(e, t, r) {
                        var n = e.signatures,
                            i = e.serializedTransaction,
                            a = e.serializedContextFreeData;
                        return void 0 === t && (t = !1), void 0 === r && (r = !1), Li(this, void 0, void 0, (function() {
                            var e, o;
                            return Ui(this, (function(s) {
                                return e = this.deflateSerializedArray(i), o = this.deflateSerializedArray(a || new Uint8Array(0)), t ? [2, this.rpc.push_ro_transaction({
                                    signatures: n,
                                    compression: 1,
                                    serializedTransaction: e,
                                    serializedContextFreeData: o
                                }, r)] : [2, this.rpc.push_transaction({
                                    signatures: n,
                                    compression: 1,
                                    serializedTransaction: e,
                                    serializedContextFreeData: o
                                })]
                            }))
                        }))
                    }, e.prototype.generateTapos = function(e, t, r, n, i) {
                        return Li(this, void 0, void 0, (function() {
                            var a, o, s, u;
                            return Ui(this, (function(l) {
                                switch (l.label) {
                                    case 0:
                                        return e ? [3, 2] : [4, this.rpc.get_info()];
                                    case 1:
                                        e = l.sent(), l.label = 2;
                                    case 2:
                                        return n ? [4, this.tryRefBlockFromGetInfo(e)] : [3, 4];
                                    case 3:
                                        return a = l.sent(), [2, Di(Di({}, Ci.transactionHeader(a, i)), t)];
                                    case 4:
                                        return (o = e.head_block_num - r) <= e.last_irreversible_block_num ? [4, this.tryGetBlockInfo(o)] : [3, 6];
                                    case 5:
                                        return u = l.sent(), [3, 8];
                                    case 6:
                                        return [4, this.tryGetBlockHeaderState(o)];
                                    case 7:
                                        u = l.sent(), l.label = 8;
                                    case 8:
                                        return s = u, [2, Di(Di({}, Ci.transactionHeader(s, i)), t)]
                                }
                            }))
                        }))
                    }, e.prototype.hasRequiredTaposFields = function(e) {
                        var t = e.expiration,
                            r = e.ref_block_num,
                            n = e.ref_block_prefix;
                        return !(!t || "number" != typeof r || "number" != typeof n)
                    }, e.prototype.tryGetBlockHeaderState = function(e) {
                        return Li(this, void 0, void 0, (function() {
                            return Ui(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return t.trys.push([0, 2, , 4]), [4, this.rpc.get_block_header_state(e)];
                                    case 1:
                                    case 3:
                                        return [2, t.sent()];
                                    case 2:
                                        return t.sent(), [4, this.tryGetBlockInfo(e)];
                                    case 4:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.tryGetBlockInfo = function(e) {
                        return Li(this, void 0, void 0, (function() {
                            return Ui(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return t.trys.push([0, 2, , 4]), [4, this.rpc.get_block_info(e)];
                                    case 1:
                                    case 3:
                                        return [2, t.sent()];
                                    case 2:
                                        return t.sent(), [4, this.rpc.get_block(e)];
                                    case 4:
                                        return [2]
                                }
                            }))
                        }))
                    }, e.prototype.tryRefBlockFromGetInfo = function(e) {
                        return Li(this, void 0, void 0, (function() {
                            var t;
                            return Ui(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return e.hasOwnProperty("last_irreversible_block_id") && e.hasOwnProperty("last_irreversible_block_num") && e.hasOwnProperty("last_irreversible_block_time") ? [2, {
                                            block_num: e.last_irreversible_block_num,
                                            id: e.last_irreversible_block_id,
                                            timestamp: e.last_irreversible_block_time
                                        }] : [3, 1];
                                    case 1:
                                        return [4, this.tryGetBlockInfo(e.last_irreversible_block_num)];
                                    case 2:
                                        return [2, {
                                            block_num: (t = r.sent()).block_num,
                                            id: t.id,
                                            timestamp: t.timestamp
                                        }]
                                }
                            }))
                        }))
                    }, e.prototype.with = function(e) {
                        return new Ki(this, e)
                    }, e.prototype.buildTransaction = function(e) {
                        var t = new Hi(this);
                        return e ? e(t) : t
                    }, e
                }();
            u.Api = Fi;
            var Hi = function() {
                function e(e) {
                    this.actions = [], this.contextFreeGroups = [], this.api = e
                }
                return e.prototype.with = function(e) {
                    var t = new Ki(this.api, e);
                    return this.actions.push(t), t
                }, e.prototype.associateContextFree = function(e) {
                    return this.contextFreeGroups.push(e), this
                }, e.prototype.send = function(e) {
                    return Li(this, void 0, void 0, (function() {
                        var t, r, n, i = this;
                        return Ui(this, (function(a) {
                            switch (a.label) {
                                case 0:
                                    return t = [], r = [], n = this.actions.map((function(e) {
                                        return e.serializedData
                                    })), [4, Promise.all(this.contextFreeGroups.map((function(e) {
                                        return Li(i, void 0, void 0, (function() {
                                            var i, a, o, s;
                                            return Ui(this, (function(u) {
                                                return i = e({
                                                    cfd: t.length,
                                                    cfa: r.length
                                                }), a = i.action, o = i.contextFreeAction, s = i.contextFreeData, a && n.push(a), o && r.push(o), s && t.push(s), [2]
                                            }))
                                        }))
                                    })))];
                                case 1:
                                    return a.sent(), this.contextFreeGroups = [], this.actions = [], [4, this.api.transact({
                                        context_free_data: t,
                                        context_free_actions: r,
                                        actions: n
                                    }, e)];
                                case 2:
                                    return [2, a.sent()]
                            }
                        }))
                    }))
                }, e
            }();
            u.TransactionBuilder = Hi;
            var Ki = function() {
                function e(e, t) {
                    this.api = e, this.accountName = t
                }
                return e.prototype.as = function(e) {
                    void 0 === e && (e = []);
                    var t = [];
                    return t = e && "string" == typeof e ? [{
                        actor: e,
                        permission: "active"
                    }] : e, new Wi(this, this.api, this.accountName, t)
                }, e
            }();
            u.ActionBuilder = Ki;
            var Wi = function(e, t, r, n) {
                    var i, a, o = this,
                        s = t.cachedAbis.get(r);
                    if (!s) throw new Error("ABI must be cached before using ActionBuilder, run api.getAbi()");
                    var u = Ci.getTypesFromAbi(Ci.createInitialTypes(), s.abi),
                        l = new Map;
                    try {
                        for (var c = ji(s.abi.actions), h = c.next(); !h.done; h = c.next()) {
                            var f = h.value,
                                d = f.name,
                                p = f.type;
                            l.set(d, Ci.getType(u, p))
                        }
                    } catch (_) {
                        i = {
                            error: _
                        }
                    } finally {
                        try {
                            h && !h.done && (a = c.return) && a.call(c)
                        } finally {
                            if (i) throw i.error
                        }
                    }
                    l.forEach((function(i, a) {
                        var s;
                        Object.assign(o, ((s = {})[a] = function() {
                            for (var o = [], s = 0; s < arguments.length; s++) o[s] = arguments[s];
                            var c = {};
                            o.forEach((function(e, t) {
                                var r = i.fields[t];
                                c[r.name] = e
                            }));
                            var h = Ci.serializeAction({
                                types: u,
                                actions: l
                            }, r, a, n, c, t.textEncoder, t.textDecoder);
                            return e.serializedData = h, h
                        }, s))
                    }))
                },
                qi = {};
            Object.defineProperty(qi, "__esModule", {
                value: !0
            });
            var Zi, Vi = {},
                Gi = {},
                Ji = t && t.__extends || (Zi = function(e, t) {
                    return Zi = Object.setPrototypeOf || {
                        __proto__: []
                    }
                    instanceof Array && function(e, t) {
                        e.__proto__ = t
                    } || function(e, t) {
                        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r])
                    }, Zi(e, t)
                }, function(e, t) {
                    if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                    function r() {
                        this.constructor = e
                    }
                    Zi(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
                });
            Object.defineProperty(Gi, "__esModule", {
                value: !0
            }), Gi.RpcError = void 0;
            var Yi = function(e) {
                function t(r) {
                    var n = this;
                    return r.error && r.error.details && r.error.details.length && r.error.details[0].message ? (n = e.call(this, r.error.details[0].message) || this).details = r.error.details : r.processed && r.processed.except && r.processed.except.message ? (n = e.call(this, r.processed.except.message) || this).details = r.processed.except : r.result && r.result.except && r.result.except.message ? (n = e.call(this, r.result.except.message) || this).details = r.result.except : n = e.call(this, r.message) || this, Object.setPrototypeOf(n, t.prototype), n.json = r, n
                }
                return Ji(t, e), t
            }(Error);
            Gi.RpcError = Yi;
            var $i = t && t.__awaiter || function(e, t, r, n) {
                    return new(r || (r = Promise))((function(i, a) {
                        function o(e) {
                            try {
                                u(n.next(e))
                            } catch (t) {
                                a(t)
                            }
                        }

                        function s(e) {
                            try {
                                u(n.throw(e))
                            } catch (t) {
                                a(t)
                            }
                        }

                        function u(e) {
                            var t;
                            e.done ? i(e.value) : (t = e.value, t instanceof r ? t : new r((function(e) {
                                e(t)
                            }))).then(o, s)
                        }
                        u((n = n.apply(e, t || [])).next())
                    }))
                },
                Qi = t && t.__generator || function(e, t) {
                    var r, n, i, a, o = {
                        label: 0,
                        sent: function() {
                            if (1 & i[0]) throw i[1];
                            return i[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(a) {
                        return function(s) {
                            return function(a) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; o;) try {
                                    if (r = 1, n && (i = 2 & a[0] ? n.return : a[0] ? n.throw || ((i = n.return) && i.call(n), 0) : n.next) && !(i = i.call(n, a[1])).done) return i;
                                    switch (n = 0, i && (a = [2 & a[0], i.value]), a[0]) {
                                        case 0:
                                        case 1:
                                            i = a;
                                            break;
                                        case 4:
                                            return o.label++, {
                                                value: a[1],
                                                done: !1
                                            };
                                        case 5:
                                            o.label++, n = a[1], a = [0];
                                            continue;
                                        case 7:
                                            a = o.ops.pop(), o.trys.pop();
                                            continue;
                                        default:
                                            if (!((i = (i = o.trys).length > 0 && i[i.length - 1]) || 6 !== a[0] && 2 !== a[0])) {
                                                o = 0;
                                                continue
                                            }
                                            if (3 === a[0] && (!i || a[1] > i[0] && a[1] < i[3])) {
                                                o.label = a[1];
                                                break
                                            }
                                            if (6 === a[0] && o.label < i[1]) {
                                                o.label = i[1], i = a;
                                                break
                                            }
                                            if (i && o.label < i[2]) {
                                                o.label = i[2], o.ops.push(a);
                                                break
                                            }
                                            i[2] && o.ops.pop(), o.trys.pop();
                                            continue
                                    }
                                    a = t.call(e, o)
                                } catch (s) {
                                    a = [6, s], n = 0
                                } finally {
                                    r = i = 0
                                }
                                if (5 & a[0]) throw a[1];
                                return {
                                    value: a[0] ? a[1] : void 0,
                                    done: !0
                                }
                            }([a, s])
                        }
                    }
                },
                Xi = t && t.__values || function(e) {
                    var t = "function" == typeof Symbol && Symbol.iterator,
                        r = t && e[t],
                        n = 0;
                    if (r) return r.call(e);
                    if (e && "number" == typeof e.length) return {
                        next: function() {
                            return e && n >= e.length && (e = void 0), {
                                value: e && e[n++],
                                done: !e
                            }
                        }
                    };
                    throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
                };
            Object.defineProperty(Vi, "__esModule", {
                value: !0
            }), Vi.JsonRpc = void 0;
            var ea = zr,
                ta = Gi,
                ra = function(e) {
                    var t, r, n = "";
                    try {
                        for (var i = Xi(e), a = i.next(); !a.done; a = i.next()) n += ("00" + a.value.toString(16)).slice(-2)
                    } catch (o) {
                        t = {
                            error: o
                        }
                    } finally {
                        try {
                            a && !a.done && (r = i.return) && r.call(i)
                        } finally {
                            if (t) throw t.error
                        }
                    }
                    return n
                },
                na = function() {
                    function e(e, r) {
                        void 0 === r && (r = {}), this.endpoint = e.replace(/\/$/, ""), r.fetch ? this.fetchBuiltin = r.fetch : this.fetchBuiltin = t.fetch
                    }
                    return e.prototype.fetch = function(e, t) {
                        return $i(this, void 0, void 0, (function() {
                            var r, n, i;
                            return Qi(this, (function(a) {
                                switch (a.label) {
                                    case 0:
                                        return a.trys.push([0, 3, , 4]), [4, (0, this.fetchBuiltin)(this.endpoint + e, {
                                            body: JSON.stringify(t),
                                            method: "POST"
                                        })];
                                    case 1:
                                        return [4, (r = a.sent()).json()];
                                    case 2:
                                        if ((n = a.sent()).processed && n.processed.except) throw new ta.RpcError(n);
                                        if (n.result && n.result.except) throw new ta.RpcError(n);
                                        return [3, 4];
                                    case 3:
                                        throw (i = a.sent()).isFetchError = !0, i;
                                    case 4:
                                        if (!r.ok) throw new ta.RpcError(n);
                                        return [2, n]
                                }
                            }))
                        }))
                    }, e.prototype.abi_bin_to_json = function(e, t, r) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/abi_bin_to_json", {
                                            code: e,
                                            action: t,
                                            binargs: r
                                        })];
                                    case 1:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.abi_json_to_bin = function(e, t, r) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/abi_json_to_bin", {
                                            code: e,
                                            action: t,
                                            args: r
                                        })];
                                    case 1:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_abi = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_abi", {
                                            account_name: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_account = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_account", {
                                            account_name: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_accounts_by_authorizers = function(e, t) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_accounts_by_authorizers", {
                                            accounts: e,
                                            keys: t
                                        })];
                                    case 1:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_activated_protocol_features = function(e) {
                        var t = e.limit,
                            r = void 0 === t ? 10 : t,
                            n = e.search_by_block_num,
                            i = void 0 !== n && n,
                            a = e.reverse,
                            o = void 0 !== a && a,
                            s = e.lower_bound,
                            u = void 0 === s ? null : s,
                            l = e.upper_bound,
                            c = void 0 === l ? null : l;
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_activated_protocol_features", {
                                            lower_bound: u,
                                            upper_bound: c,
                                            limit: r,
                                            search_by_block_num: i,
                                            reverse: o
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_block_header_state = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_block_header_state", {
                                            block_num_or_id: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_block_info = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_block_info", {
                                            block_num: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_block = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_block", {
                                            block_num_or_id: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_code = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_code", {
                                            account_name: e,
                                            code_as_wasm: !0
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_code_hash = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_code_hash", {
                                            account_name: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_currency_balance = function(e, t, r) {
                        return void 0 === r && (r = null), $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_currency_balance", {
                                            code: e,
                                            account: t,
                                            symbol: r
                                        })];
                                    case 1:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_currency_stats = function(e, t) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_currency_stats", {
                                            code: e,
                                            symbol: t
                                        })];
                                    case 1:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_info = function() {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_info", {})];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_producer_schedule = function() {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_producer_schedule", {})];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_producers = function(e, t, r) {
                        return void 0 === e && (e = !0), void 0 === t && (t = ""), void 0 === r && (r = 50), $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_producers", {
                                            json: e,
                                            lower_bound: t,
                                            limit: r
                                        })];
                                    case 1:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_raw_code_and_abi = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_raw_code_and_abi", {
                                            account_name: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.getRawAbi = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            var t, r;
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.get_raw_abi(e)];
                                    case 1:
                                        return t = n.sent(), r = ea.base64ToBinary(t.abi), [2, {
                                            accountName: t.account_name,
                                            abi: r
                                        }]
                                }
                            }))
                        }))
                    }, e.prototype.get_raw_abi = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_raw_abi", {
                                            account_name: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_scheduled_transactions = function(e, t, r) {
                        return void 0 === e && (e = !0), void 0 === t && (t = ""), void 0 === r && (r = 50), $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_scheduled_transactions", {
                                            json: e,
                                            lower_bound: t,
                                            limit: r
                                        })];
                                    case 1:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_table_rows = function(e) {
                        var t = e.json,
                            r = void 0 === t || t,
                            n = e.code,
                            i = e.scope,
                            a = e.table,
                            o = e.lower_bound,
                            s = void 0 === o ? "" : o,
                            u = e.upper_bound,
                            l = void 0 === u ? "" : u,
                            c = e.index_position,
                            h = void 0 === c ? 1 : c,
                            f = e.key_type,
                            d = void 0 === f ? "" : f,
                            p = e.limit,
                            _ = void 0 === p ? 10 : p,
                            y = e.reverse,
                            g = void 0 !== y && y,
                            b = e.show_payer,
                            v = void 0 !== b && b;
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_table_rows", {
                                            json: r,
                                            code: n,
                                            scope: i,
                                            table: a,
                                            lower_bound: s,
                                            upper_bound: l,
                                            index_position: h,
                                            key_type: d,
                                            limit: _,
                                            reverse: g,
                                            show_payer: v
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_kv_table_rows = function(e) {
                        var t = e.json,
                            r = void 0 === t || t,
                            n = e.code,
                            i = e.table,
                            a = e.index_name,
                            o = e.encode_type,
                            s = void 0 === o ? "bytes" : o,
                            u = e.index_value,
                            l = e.lower_bound,
                            c = e.upper_bound,
                            h = e.limit,
                            f = void 0 === h ? 10 : h,
                            d = e.reverse,
                            p = void 0 !== d && d,
                            _ = e.show_payer,
                            y = void 0 !== _ && _;
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_kv_table_rows", {
                                            json: r,
                                            code: n,
                                            table: i,
                                            index_name: a,
                                            encode_type: s,
                                            index_value: u,
                                            lower_bound: l,
                                            upper_bound: c,
                                            limit: f,
                                            reverse: p,
                                            show_payer: y
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.get_table_by_scope = function(e) {
                        var t = e.code,
                            r = e.table,
                            n = e.lower_bound,
                            i = void 0 === n ? "" : n,
                            a = e.upper_bound,
                            o = void 0 === a ? "" : a,
                            s = e.limit,
                            u = void 0 === s ? 10 : s;
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/get_table_by_scope", {
                                            code: t,
                                            table: r,
                                            lower_bound: i,
                                            upper_bound: o,
                                            limit: u
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.getRequiredKeys = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            var t;
                            return Qi(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return t = ea.convertLegacyPublicKeys, [4, this.fetch("/v1/chain/get_required_keys", {
                                            transaction: e.transaction,
                                            available_keys: e.availableKeys
                                        })];
                                    case 1:
                                        return [2, t.apply(void 0, [r.sent().required_keys])]
                                }
                            }))
                        }))
                    }, e.prototype.push_transaction = function(e) {
                        var t = e.signatures,
                            r = e.compression,
                            n = void 0 === r ? 0 : r,
                            i = e.serializedTransaction,
                            a = e.serializedContextFreeData;
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/push_transaction", {
                                            signatures: t,
                                            compression: n,
                                            packed_context_free_data: ra(a || new Uint8Array(0)),
                                            packed_trx: ra(i)
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.push_ro_transaction = function(e, t) {
                        var r = e.signatures,
                            n = e.compression,
                            i = void 0 === n ? 0 : n,
                            a = e.serializedTransaction;
                        return void 0 === t && (t = !1), $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/push_ro_transaction", {
                                            transaction: {
                                                signatures: r,
                                                compression: i,
                                                packed_context_free_data: ra(new Uint8Array(0)),
                                                packed_trx: ra(a)
                                            },
                                            return_failure_traces: t
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.push_transactions = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            var t;
                            return Qi(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return t = e.map((function(e) {
                                            var t = e.signatures,
                                                r = e.compression,
                                                n = void 0 === r ? 0 : r,
                                                i = e.serializedTransaction,
                                                a = e.serializedContextFreeData;
                                            return {
                                                signatures: t,
                                                compression: n,
                                                packed_context_free_data: ra(a || new Uint8Array(0)),
                                                packed_trx: ra(i)
                                            }
                                        })), [4, this.fetch("/v1/chain/push_transactions", t)];
                                    case 1:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.send_transaction = function(e) {
                        var t = e.signatures,
                            r = e.compression,
                            n = void 0 === r ? 0 : r,
                            i = e.serializedTransaction,
                            a = e.serializedContextFreeData;
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/chain/send_transaction", {
                                            signatures: t,
                                            compression: n,
                                            packed_context_free_data: ra(a || new Uint8Array(0)),
                                            packed_trx: ra(i)
                                        })];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.db_size_get = function() {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(e) {
                                switch (e.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/db_size/get", {})];
                                    case 1:
                                        return [2, e.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.trace_get_block = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/trace_api/get_block", {
                                            block_num: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.history_get_actions = function(e, t, r) {
                        return void 0 === t && (t = null), void 0 === r && (r = null), $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(n) {
                                switch (n.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/history/get_actions", {
                                            account_name: e,
                                            pos: t,
                                            offset: r
                                        })];
                                    case 1:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.history_get_transaction = function(e, t) {
                        return void 0 === t && (t = null), $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(r) {
                                switch (r.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/history/get_transaction", {
                                            id: e,
                                            block_num_hint: t
                                        })];
                                    case 1:
                                        return [2, r.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.history_get_key_accounts = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/history/get_key_accounts", {
                                            public_key: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e.prototype.history_get_controlled_accounts = function(e) {
                        return $i(this, void 0, void 0, (function() {
                            return Qi(this, (function(t) {
                                switch (t.label) {
                                    case 0:
                                        return [4, this.fetch("/v1/history/get_controlled_accounts", {
                                            controlling_account: e
                                        })];
                                    case 1:
                                        return [2, t.sent()]
                                }
                            }))
                        }))
                    }, e
                }();
            Vi.JsonRpc = na;
            var ia = {};
            Object.defineProperty(ia, "__esModule", {
                    value: !0
                }),
                function(e) {
                    Object.defineProperty(e, "__esModule", {
                        value: !0
                    }), e.Serialize = e.RpcError = e.RpcInterfaces = e.Numeric = e.JsonRpc = e.ApiInterfaces = e.Api = void 0;
                    var t = u;
                    Object.defineProperty(e, "Api", {
                        enumerable: !0,
                        get: function() {
                            return t.Api
                        }
                    });
                    var r = qi;
                    e.ApiInterfaces = r;
                    var n = Vi;
                    Object.defineProperty(e, "JsonRpc", {
                        enumerable: !0,
                        get: function() {
                            return n.JsonRpc
                        }
                    });
                    var i = zr;
                    e.Numeric = i;
                    var a = ia;
                    e.RpcInterfaces = a;
                    var o = Gi;
                    Object.defineProperty(e, "RpcError", {
                        enumerable: !0,
                        get: function() {
                            return o.RpcError
                        }
                    });
                    var s = Tr;
                    e.Serialize = s
                }(s);
            var aa = r(s),
                oa = {},
                sa = {
                    exports: {}
                },
                ua = {
                    exports: {}
                };
            ! function(e) {
                function t(r) {
                    return e.exports = t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
                        return typeof e
                    } : function(e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
                    }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r)
                }
                e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
            }(ua),
            function(e) {
                var t = ua.exports.default;

                function r(e) {
                    if ("function" != typeof WeakMap) return null;
                    var t = new WeakMap,
                        n = new WeakMap;
                    return (r = function(e) {
                        return e ? n : t
                    })(e)
                }
                e.exports = function(e, n) {
                    if (!n && e && e.__esModule) return e;
                    if (null === e || "object" !== t(e) && "function" != typeof e) return {
                        default: e
                    };
                    var i = r(n);
                    if (i && i.has(e)) return i.get(e);
                    var a = {},
                        o = Object.defineProperty && Object.getOwnPropertyDescriptor;
                    for (var s in e)
                        if ("default" !== s && Object.prototype.hasOwnProperty.call(e, s)) {
                            var u = o ? Object.getOwnPropertyDescriptor(e, s) : null;
                            u && (u.get || u.set) ? Object.defineProperty(a, s, u) : a[s] = e[s]
                        }
                    return a.default = e, i && i.set(e, a), a
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(sa);
            var la, ca = {
                exports: {}
            };
            (la = ca).exports = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            }, la.exports.__esModule = !0, la.exports.default = la.exports;
            var ha = {
                exports: {}
            };
            ! function(e) {
                var t = function(e) {
                    var t, r = Object.prototype,
                        n = r.hasOwnProperty,
                        i = "function" == typeof Symbol ? Symbol : {},
                        a = i.iterator || "@@iterator",
                        o = i.asyncIterator || "@@asyncIterator",
                        s = i.toStringTag || "@@toStringTag";

                    function u(e, t, r) {
                        return Object.defineProperty(e, t, {
                            value: r,
                            enumerable: !0,
                            configurable: !0,
                            writable: !0
                        }), e[t]
                    }
                    try {
                        u({}, "")
                    } catch (Pe) {
                        u = function(e, t, r) {
                            return e[t] = r
                        }
                    }

                    function l(e, t, r, n) {
                        var i = t && t.prototype instanceof y ? t : y,
                            a = Object.create(i.prototype),
                            o = new z(n || []);
                        return a._invoke = function(e, t, r) {
                            var n = h;
                            return function(i, a) {
                                if (n === d) throw new Error("Generator is already running");
                                if (n === p) {
                                    if ("throw" === i) throw a;
                                    return R()
                                }
                                for (r.method = i, r.arg = a;;) {
                                    var o = r.delegate;
                                    if (o) {
                                        var s = E(o, r);
                                        if (s) {
                                            if (s === _) continue;
                                            return s
                                        }
                                    }
                                    if ("next" === r.method) r.sent = r._sent = r.arg;
                                    else if ("throw" === r.method) {
                                        if (n === h) throw n = p, r.arg;
                                        r.dispatchException(r.arg)
                                    } else "return" === r.method && r.abrupt("return", r.arg);
                                    n = d;
                                    var u = c(e, t, r);
                                    if ("normal" === u.type) {
                                        if (n = r.done ? p : f, u.arg === _) continue;
                                        return {
                                            value: u.arg,
                                            done: r.done
                                        }
                                    }
                                    "throw" === u.type && (n = p, r.method = "throw", r.arg = u.arg)
                                }
                            }
                        }(e, r, o), a
                    }

                    function c(e, t, r) {
                        try {
                            return {
                                type: "normal",
                                arg: e.call(t, r)
                            }
                        } catch (Pe) {
                            return {
                                type: "throw",
                                arg: Pe
                            }
                        }
                    }
                    e.wrap = l;
                    var h = "suspendedStart",
                        f = "suspendedYield",
                        d = "executing",
                        p = "completed",
                        _ = {};

                    function y() {}

                    function g() {}

                    function b() {}
                    var v = {};
                    u(v, a, (function() {
                        return this
                    }));
                    var m = Object.getPrototypeOf,
                        w = m && m(m(O([])));
                    w && w !== r && n.call(w, a) && (v = w);
                    var x = b.prototype = y.prototype = Object.create(v);

                    function k(e) {
                        ["next", "throw", "return"].forEach((function(t) {
                            u(e, t, (function(e) {
                                return this._invoke(t, e)
                            }))
                        }))
                    }

                    function S(e, t) {
                        function r(i, a, o, s) {
                            var u = c(e[i], e, a);
                            if ("throw" !== u.type) {
                                var l = u.arg,
                                    h = l.value;
                                return h && "object" == typeof h && n.call(h, "__await") ? t.resolve(h.__await).then((function(e) {
                                    r("next", e, o, s)
                                }), (function(e) {
                                    r("throw", e, o, s)
                                })) : t.resolve(h).then((function(e) {
                                    l.value = e, o(l)
                                }), (function(e) {
                                    return r("throw", e, o, s)
                                }))
                            }
                            s(u.arg)
                        }
                        var i;
                        this._invoke = function(e, n) {
                            function a() {
                                return new t((function(t, i) {
                                    r(e, n, t, i)
                                }))
                            }
                            return i = i ? i.then(a, a) : a()
                        }
                    }

                    function E(e, r) {
                        var n = e.iterator[r.method];
                        if (n === t) {
                            if (r.delegate = null, "throw" === r.method) {
                                if (e.iterator.return && (r.method = "return", r.arg = t, E(e, r), "throw" === r.method)) return _;
                                r.method = "throw", r.arg = new TypeError("The iterator does not provide a 'throw' method")
                            }
                            return _
                        }
                        var i = c(n, e.iterator, r.arg);
                        if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, _;
                        var a = i.arg;
                        return a ? a.done ? (r[e.resultName] = a.value, r.next = e.nextLoc, "return" !== r.method && (r.method = "next", r.arg = t), r.delegate = null, _) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, _)
                    }

                    function A(e) {
                        var t = {
                            tryLoc: e[0]
                        };
                        1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
                    }

                    function T(e) {
                        var t = e.completion || {};
                        t.type = "normal", delete t.arg, e.completion = t
                    }

                    function z(e) {
                        this.tryEntries = [{
                            tryLoc: "root"
                        }], e.forEach(A, this), this.reset(!0)
                    }

                    function O(e) {
                        if (e) {
                            var r = e[a];
                            if (r) return r.call(e);
                            if ("function" == typeof e.next) return e;
                            if (!isNaN(e.length)) {
                                var i = -1,
                                    o = function r() {
                                        for (; ++i < e.length;)
                                            if (n.call(e, i)) return r.value = e[i], r.done = !1, r;
                                        return r.value = t, r.done = !0, r
                                    };
                                return o.next = o
                            }
                        }
                        return {
                            next: R
                        }
                    }

                    function R() {
                        return {
                            value: t,
                            done: !0
                        }
                    }
                    return g.prototype = b, u(x, "constructor", b), u(b, "constructor", g), g.displayName = u(b, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                        var t = "function" == typeof e && e.constructor;
                        return !!t && (t === g || "GeneratorFunction" === (t.displayName || t.name))
                    }, e.mark = function(e) {
                        return Object.setPrototypeOf ? Object.setPrototypeOf(e, b) : (e.__proto__ = b, u(e, s, "GeneratorFunction")), e.prototype = Object.create(x), e
                    }, e.awrap = function(e) {
                        return {
                            __await: e
                        }
                    }, k(S.prototype), u(S.prototype, o, (function() {
                        return this
                    })), e.AsyncIterator = S, e.async = function(t, r, n, i, a) {
                        void 0 === a && (a = Promise);
                        var o = new S(l(t, r, n, i), a);
                        return e.isGeneratorFunction(r) ? o : o.next().then((function(e) {
                            return e.done ? e.value : o.next()
                        }))
                    }, k(x), u(x, s, "Generator"), u(x, a, (function() {
                        return this
                    })), u(x, "toString", (function() {
                        return "[object Generator]"
                    })), e.keys = function(e) {
                        var t = [];
                        for (var r in e) t.push(r);
                        return t.reverse(),
                            function r() {
                                for (; t.length;) {
                                    var n = t.pop();
                                    if (n in e) return r.value = n, r.done = !1, r
                                }
                                return r.done = !0, r
                            }
                    }, e.values = O, z.prototype = {
                        constructor: z,
                        reset: function(e) {
                            if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(T), !e)
                                for (var r in this) "t" === r.charAt(0) && n.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = t)
                        },
                        stop: function() {
                            this.done = !0;
                            var e = this.tryEntries[0].completion;
                            if ("throw" === e.type) throw e.arg;
                            return this.rval
                        },
                        dispatchException: function(e) {
                            if (this.done) throw e;
                            var r = this;

                            function i(n, i) {
                                return s.type = "throw", s.arg = e, r.next = n, i && (r.method = "next", r.arg = t), !!i
                            }
                            for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                                var o = this.tryEntries[a],
                                    s = o.completion;
                                if ("root" === o.tryLoc) return i("end");
                                if (o.tryLoc <= this.prev) {
                                    var u = n.call(o, "catchLoc"),
                                        l = n.call(o, "finallyLoc");
                                    if (u && l) {
                                        if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                                        if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                    } else if (u) {
                                        if (this.prev < o.catchLoc) return i(o.catchLoc, !0)
                                    } else {
                                        if (!l) throw new Error("try statement without catch or finally");
                                        if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                                    }
                                }
                            }
                        },
                        abrupt: function(e, t) {
                            for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                                var i = this.tryEntries[r];
                                if (i.tryLoc <= this.prev && n.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                                    var a = i;
                                    break
                                }
                            }
                            a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                            var o = a ? a.completion : {};
                            return o.type = e, o.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, _) : this.complete(o)
                        },
                        complete: function(e, t) {
                            if ("throw" === e.type) throw e.arg;
                            return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), _
                        },
                        finish: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var r = this.tryEntries[t];
                                if (r.finallyLoc === e) return this.complete(r.completion, r.afterLoc), T(r), _
                            }
                        },
                        catch: function(e) {
                            for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                                var r = this.tryEntries[t];
                                if (r.tryLoc === e) {
                                    var n = r.completion;
                                    if ("throw" === n.type) {
                                        var i = n.arg;
                                        T(r)
                                    }
                                    return i
                                }
                            }
                            throw new Error("illegal catch attempt")
                        },
                        delegateYield: function(e, r, n) {
                            return this.delegate = {
                                iterator: O(e),
                                resultName: r,
                                nextLoc: n
                            }, "next" === this.method && (this.arg = t), _
                        }
                    }, e
                }(e.exports);
                try {
                    regeneratorRuntime = t
                } catch (r) {
                    "object" == typeof globalThis ? globalThis.regeneratorRuntime = t : Function("r", "regeneratorRuntime = r")(t)
                }
            }(ha);
            var fa = ha.exports,
                da = {
                    exports: {}
                };
            ! function(e) {
                function t(e, t, r, n, i, a, o) {
                    try {
                        var s = e[a](o),
                            u = s.value
                    } catch (l) {
                        return void r(l)
                    }
                    s.done ? t(u) : Promise.resolve(u).then(n, i)
                }
                e.exports = function(e) {
                    return function() {
                        var r = this,
                            n = arguments;
                        return new Promise((function(i, a) {
                            var o = e.apply(r, n);

                            function s(e) {
                                t(o, i, a, s, u, "next", e)
                            }

                            function u(e) {
                                t(o, i, a, s, u, "throw", e)
                            }
                            s(void 0)
                        }))
                    }
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(da);
            var pa = {
                exports: {}
            };
            ! function(e) {
                e.exports = function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(pa);
            var _a = {
                exports: {}
            };
            ! function(e) {
                function t(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                    }
                }
                e.exports = function(e, r, n) {
                    return r && t(e.prototype, r), n && t(e, n), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), e
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(_a);
            var ya = {},
                ga = {};
            ! function(e) {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.WALLET_SUPPORT = e.BLOCKCHAIN_SUPPORT = void 0, e.BLOCKCHAIN_SUPPORT = "blockchain_support", e.WALLET_SUPPORT = "wallet_support"
            }(ga),
            function(e) {
                var t = sa.exports,
                    r = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var n = r(fa),
                    i = r(da.exports),
                    a = r(pa.exports),
                    o = r(_a.exports),
                    s = t(ga),
                    u = function() {
                        function e() {
                            (0, a.default)(this, e), this.plugins = []
                        }
                        return (0, o.default)(e, [{
                            key: "loadPlugin",
                            value: function(e) {
                                this.plugin(e.name) || this.plugins.push(e)
                            }
                        }, {
                            key: "wallets",
                            value: function() {
                                return this.plugins.filter((function(e) {
                                    return e.type === s.WALLET_SUPPORT
                                }))
                            }
                        }, {
                            key: "signatureProviders",
                            value: function() {
                                return this.plugins.filter((function(e) {
                                    return e.type === s.BLOCKCHAIN_SUPPORT
                                }))
                            }
                        }, {
                            key: "supportedBlockchains",
                            value: function() {
                                return this.signatureProviders().map((function() {
                                    return name
                                }))
                            }
                        }, {
                            key: "plugin",
                            value: function(e) {
                                return this.plugins.find((function(t) {
                                    return t.name === e
                                }))
                            }
                        }, {
                            key: "endorsedNetworks",
                            value: function() {
                                var e = (0, i.default)(n.default.mark((function e() {
                                    return n.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return e.next = 2, Promise.all(this.signatureProviders().map(function() {
                                                    var e = (0, i.default)(n.default.mark((function e(t) {
                                                        return n.default.wrap((function(e) {
                                                            for (;;) switch (e.prev = e.next) {
                                                                case 0:
                                                                    return e.next = 2, t.getEndorsedNetwork();
                                                                case 2:
                                                                    return e.abrupt("return", e.sent);
                                                                case 3:
                                                                case "end":
                                                                    return e.stop()
                                                            }
                                                        }), e, this)
                                                    })));
                                                    return function() {
                                                        return e.apply(this, arguments)
                                                    }
                                                }()));
                                            case 2:
                                                return e.abrupt("return", e.sent);
                                            case 3:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }]), e
                    }(),
                    l = new u;
                e.default = l
            }(ya);
            var ba = {},
                va = {
                    exports: {}
                },
                ma = {
                    exports: {}
                };
            ! function(e) {
                e.exports = function(e) {
                    if (Array.isArray(e)) return e
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(ma);
            var wa = {
                exports: {}
            };
            ! function(e) {
                e.exports = function(e, t) {
                    var r = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                    if (null != r) {
                        var n, i, a = [],
                            o = !0,
                            s = !1;
                        try {
                            for (r = r.call(e); !(o = (n = r.next()).done) && (a.push(n.value), !t || a.length !== t); o = !0);
                        } catch (Pe) {
                            s = !0, i = Pe
                        } finally {
                            try {
                                o || null == r.return || r.return()
                            } finally {
                                if (s) throw i
                            }
                        }
                        return a
                    }
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(wa);
            var xa = {
                    exports: {}
                },
                ka = {
                    exports: {}
                };
            ! function(e) {
                e.exports = function(e, t) {
                    (null == t || t > e.length) && (t = e.length);
                    for (var r = 0, n = new Array(t); r < t; r++) n[r] = e[r];
                    return n
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(ka),
            function(e) {
                var t = ka.exports;
                e.exports = function(e, r) {
                    if (e) {
                        if ("string" == typeof e) return t(e, r);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? t(e, r) : void 0
                    }
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(xa);
            var Sa = {
                exports: {}
            };
            ! function(e) {
                e.exports = function() {
                    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(Sa),
            function(e) {
                var t = ma.exports,
                    r = wa.exports,
                    n = xa.exports,
                    i = Sa.exports;
                e.exports = function(e, a) {
                    return t(e) || r(e, a) || n(e, a) || i()
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(va);
            var Ea = {};
            ! function(e) {
                var t = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var r = t(pa.exports),
                    n = t(_a.exports),
                    i = {},
                    a = function() {
                        return "undefined" == typeof window ? {
                            localStorage: {
                                setItem: function(e, t) {
                                    return i[e] = t
                                },
                                getItem: function(e) {
                                    return i[e] || null
                                },
                                removeItem: function(e) {
                                    return delete i[e]
                                }
                            }
                        } : window
                    },
                    o = function() {
                        function e() {
                            (0, r.default)(this, e)
                        }
                        return (0, n.default)(e, null, [{
                            key: "setAppKey",
                            value: function(e) {
                                a().localStorage.setItem("appkey", e)
                            }
                        }, {
                            key: "getAppKey",
                            value: function() {
                                return a().localStorage.getItem("appkey")
                            }
                        }, {
                            key: "removeAppKey",
                            value: function() {
                                return a().localStorage.removeItem("appkey")
                            }
                        }, {
                            key: "setNonce",
                            value: function(e) {
                                a().localStorage.setItem("nonce", e)
                            }
                        }, {
                            key: "getNonce",
                            value: function() {
                                return a().localStorage.getItem("nonce")
                            }
                        }, {
                            key: "removeNonce",
                            value: function() {
                                return a().localStorage.removeItem("nonce")
                            }
                        }]), e
                    }();
                e.default = o
            }(Ea);
            var Aa = "undefined" != typeof window ? window : void 0 !== t ? t : "undefined" != typeof self ? self : {},
                Ta = Object.freeze(Object.defineProperty({
                    __proto__: null,
                    default: {}
                }, Symbol.toStringTag, {
                    value: "Module"
                })),
                za = n(Ta),
                Oa = Aa,
                Ra = za,
                Pa = function(e) {
                    if (Oa.crypto && Oa.crypto.getRandomValues) return Oa.crypto.getRandomValues(e);
                    if ("object" == typeof Oa.msCrypto && "function" == typeof Oa.msCrypto.getRandomValues) return Oa.msCrypto.getRandomValues(e);
                    if (Ra.randomBytes) {
                        if (!(e instanceof Uint8Array)) throw new TypeError("expected Uint8Array");
                        if (e.length > 65536) {
                            var t = new Error;
                            throw t.code = 22, t.message = "Failed to execute 'getRandomValues' on 'Crypto': The ArrayBufferView's byte length (" + e.length + ") exceeds the number of bytes of entropy available via this API (65536).", t.name = "QuotaExceededError", t
                        }
                        var r = Ra.randomBytes(e.length);
                        return e.set(r), e
                    }
                    throw new Error("No secure random number generator available.")
                },
                Na = {
                    exports: {}
                }; /*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
            ! function(e, t) {
                var r = a,
                    n = r.Buffer;

                function i(e, t) {
                    for (var r in e) t[r] = e[r]
                }

                function o(e, t, r) {
                    return n(e, t, r)
                }
                n.from && n.alloc && n.allocUnsafe && n.allocUnsafeSlow ? e.exports = r : (i(r, t), t.Buffer = o), o.prototype = Object.create(n.prototype), i(n, o), o.from = function(e, t, r) {
                    if ("number" == typeof e) throw new TypeError("Argument must not be a number");
                    return n(e, t, r)
                }, o.alloc = function(e, t, r) {
                    if ("number" != typeof e) throw new TypeError("Argument must be a number");
                    var i = n(e);
                    return void 0 !== t ? "string" == typeof r ? i.fill(t, r) : i.fill(t) : i.fill(0), i
                }, o.allocUnsafe = function(e) {
                    if ("number" != typeof e) throw new TypeError("Argument must be a number");
                    return n(e)
                }, o.allocUnsafeSlow = function(e) {
                    if ("number" != typeof e) throw new TypeError("Argument must be a number");
                    return r.SlowBuffer(e)
                }
            }(Na, Na.exports);
            var Da = {
                    exports: {}
                },
                La = i.exports.EventEmitter;

            function Ua(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), r.push.apply(r, n)
                }
                return r
            }

            function Ia(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }

            function Ba(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                }
            }
            var ja = a.Buffer,
                Ma = za.inspect,
                Ca = Ma && Ma.custom || "inspect",
                Fa = function() {
                    function e() {
                        ! function(e, t) {
                            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                        }(this, e), this.head = null, this.tail = null, this.length = 0
                    }
                    var t, r, n;
                    return t = e, r = [{
                        key: "push",
                        value: function(e) {
                            var t = {
                                data: e,
                                next: null
                            };
                            this.length > 0 ? this.tail.next = t : this.head = t, this.tail = t, ++this.length
                        }
                    }, {
                        key: "unshift",
                        value: function(e) {
                            var t = {
                                data: e,
                                next: this.head
                            };
                            0 === this.length && (this.tail = t), this.head = t, ++this.length
                        }
                    }, {
                        key: "shift",
                        value: function() {
                            if (0 !== this.length) {
                                var e = this.head.data;
                                return 1 === this.length ? this.head = this.tail = null : this.head = this.head.next, --this.length, e
                            }
                        }
                    }, {
                        key: "clear",
                        value: function() {
                            this.head = this.tail = null, this.length = 0
                        }
                    }, {
                        key: "join",
                        value: function(e) {
                            if (0 === this.length) return "";
                            for (var t = this.head, r = "" + t.data; t = t.next;) r += e + t.data;
                            return r
                        }
                    }, {
                        key: "concat",
                        value: function(e) {
                            if (0 === this.length) return ja.alloc(0);
                            for (var t, r, n, i = ja.allocUnsafe(e >>> 0), a = this.head, o = 0; a;) t = a.data, r = i, n = o, ja.prototype.copy.call(t, r, n), o += a.data.length, a = a.next;
                            return i
                        }
                    }, {
                        key: "consume",
                        value: function(e, t) {
                            var r;
                            return e < this.head.data.length ? (r = this.head.data.slice(0, e), this.head.data = this.head.data.slice(e)) : r = e === this.head.data.length ? this.shift() : t ? this._getString(e) : this._getBuffer(e), r
                        }
                    }, {
                        key: "first",
                        value: function() {
                            return this.head.data
                        }
                    }, {
                        key: "_getString",
                        value: function(e) {
                            var t = this.head,
                                r = 1,
                                n = t.data;
                            for (e -= n.length; t = t.next;) {
                                var i = t.data,
                                    a = e > i.length ? i.length : e;
                                if (a === i.length ? n += i : n += i.slice(0, e), 0 == (e -= a)) {
                                    a === i.length ? (++r, t.next ? this.head = t.next : this.head = this.tail = null) : (this.head = t, t.data = i.slice(a));
                                    break
                                }++r
                            }
                            return this.length -= r, n
                        }
                    }, {
                        key: "_getBuffer",
                        value: function(e) {
                            var t = ja.allocUnsafe(e),
                                r = this.head,
                                n = 1;
                            for (r.data.copy(t), e -= r.data.length; r = r.next;) {
                                var i = r.data,
                                    a = e > i.length ? i.length : e;
                                if (i.copy(t, t.length - e, 0, a), 0 == (e -= a)) {
                                    a === i.length ? (++n, r.next ? this.head = r.next : this.head = this.tail = null) : (this.head = r, r.data = i.slice(a));
                                    break
                                }++n
                            }
                            return this.length -= n, t
                        }
                    }, {
                        key: Ca,
                        value: function(e, t) {
                            return Ma(this, function(e) {
                                for (var t = 1; t < arguments.length; t++) {
                                    var r = null != arguments[t] ? arguments[t] : {};
                                    t % 2 ? Ua(Object(r), !0).forEach((function(t) {
                                        Ia(e, t, r[t])
                                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Ua(Object(r)).forEach((function(t) {
                                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t))
                                    }))
                                }
                                return e
                            }({}, t, {
                                depth: 0,
                                customInspect: !1
                            }))
                        }
                    }], r && Ba(t.prototype, r), n && Ba(t, n), e
                }();

            function Ha(e, t) {
                Wa(e, t), Ka(e)
            }

            function Ka(e) {
                e._writableState && !e._writableState.emitClose || e._readableState && !e._readableState.emitClose || e.emit("close")
            }

            function Wa(e, t) {
                e.emit("error", t)
            }
            var qa = {
                    destroy: function(e, t) {
                        var r = this,
                            n = this._readableState && this._readableState.destroyed,
                            i = this._writableState && this._writableState.destroyed;
                        return n || i ? (t ? t(e) : e && (this._writableState ? this._writableState.errorEmitted || (this._writableState.errorEmitted = !0, process.nextTick(Wa, this, e)) : process.nextTick(Wa, this, e)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(e || null, (function(e) {
                            !t && e ? r._writableState ? r._writableState.errorEmitted ? process.nextTick(Ka, r) : (r._writableState.errorEmitted = !0, process.nextTick(Ha, r, e)) : process.nextTick(Ha, r, e) : t ? (process.nextTick(Ka, r), t(e)) : process.nextTick(Ka, r)
                        })), this)
                    },
                    undestroy: function() {
                        this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1)
                    },
                    errorOrDestroy: function(e, t) {
                        var r = e._readableState,
                            n = e._writableState;
                        r && r.autoDestroy || n && n.autoDestroy ? e.destroy(t) : e.emit("error", t)
                    }
                },
                Za = {},
                Va = {};

            function Ga(e, t, r) {
                r || (r = Error);
                var n = function(e) {
                    var r, n;

                    function i(r, n, i) {
                        return e.call(this, function(e, r, n) {
                            return "string" == typeof t ? t : t(e, r, n)
                        }(r, n, i)) || this
                    }
                    return n = e, (r = i).prototype = Object.create(n.prototype), r.prototype.constructor = r, r.__proto__ = n, i
                }(r);
                n.prototype.name = r.name, n.prototype.code = e, Va[e] = n
            }

            function Ja(e, t) {
                if (Array.isArray(e)) {
                    var r = e.length;
                    return e = e.map((function(e) {
                        return String(e)
                    })), r > 2 ? "one of ".concat(t, " ").concat(e.slice(0, r - 1).join(", "), ", or ") + e[r - 1] : 2 === r ? "one of ".concat(t, " ").concat(e[0], " or ").concat(e[1]) : "of ".concat(t, " ").concat(e[0])
                }
                return "of ".concat(t, " ").concat(String(e))
            }
            Ga("ERR_INVALID_OPT_VALUE", (function(e, t) {
                return 'The value "' + t + '" is invalid for option "' + e + '"'
            }), TypeError), Ga("ERR_INVALID_ARG_TYPE", (function(e, t, r) {
                var n, i, a, o;
                if ("string" == typeof t && (i = "not ", t.substr(!a || a < 0 ? 0 : +a, i.length) === i) ? (n = "must not be", t = t.replace(/^not /, "")) : n = "must be", function(e, t, r) {
                        return (void 0 === r || r > e.length) && (r = e.length), e.substring(r - t.length, r) === t
                    }(e, " argument")) o = "The ".concat(e, " ").concat(n, " ").concat(Ja(t, "type"));
                else {
                    var s = function(e, t, r) {
                        return "number" != typeof r && (r = 0), !(r + t.length > e.length) && -1 !== e.indexOf(t, r)
                    }(e, ".") ? "property" : "argument";
                    o = 'The "'.concat(e, '" ').concat(s, " ").concat(n, " ").concat(Ja(t, "type"))
                }
                return o += ". Received type ".concat(typeof r)
            }), TypeError), Ga("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF"), Ga("ERR_METHOD_NOT_IMPLEMENTED", (function(e) {
                return "The " + e + " method is not implemented"
            })), Ga("ERR_STREAM_PREMATURE_CLOSE", "Premature close"), Ga("ERR_STREAM_DESTROYED", (function(e) {
                return "Cannot call " + e + " after a stream was destroyed"
            })), Ga("ERR_MULTIPLE_CALLBACK", "Callback called multiple times"), Ga("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable"), Ga("ERR_STREAM_WRITE_AFTER_END", "write after end"), Ga("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError), Ga("ERR_UNKNOWN_ENCODING", (function(e) {
                return "Unknown encoding: " + e
            }), TypeError), Ga("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event"), Za.codes = Va;
            var Ya = Za.codes.ERR_INVALID_OPT_VALUE,
                $a = {
                    getHighWaterMark: function(e, t, r, n) {
                        var i = function(e, t, r) {
                            return null != e.highWaterMark ? e.highWaterMark : t ? e[r] : null
                        }(t, n, r);
                        if (null != i) {
                            if (!isFinite(i) || Math.floor(i) !== i || i < 0) throw new Ya(n ? r : "highWaterMark", i);
                            return Math.floor(i)
                        }
                        return e.objectMode ? 16 : 16384
                    }
                },
                Qa = function(e, t) {
                    if (Xa("noDeprecation")) return e;
                    var r = !1;
                    return function() {
                        if (!r) {
                            if (Xa("throwDeprecation")) throw new Error(t);
                            Xa("traceDeprecation") ? console.trace(t) : console.warn(t), r = !0
                        }
                        return e.apply(this, arguments)
                    }
                };

            function Xa(e) {
                try {
                    if (!t.localStorage) return !1
                } catch (n) {
                    return !1
                }
                var r = t.localStorage[e];
                return null != r && "true" === String(r).toLowerCase()
            }
            var eo, to = ko;

            function ro(e) {
                var t = this;
                this.next = null, this.entry = null, this.finish = function() {
                    ! function(e, t, r) {
                        var n = e.entry;
                        for (e.entry = null; n;) {
                            var i = n.callback;
                            t.pendingcb--, i(r), n = n.next
                        }
                        t.corkedRequestsFree.next = e
                    }(t, e)
                }
            }
            ko.WritableState = xo;
            var no, io = {
                    deprecate: Qa
                },
                ao = La,
                oo = a.Buffer,
                so = t.Uint8Array || function() {},
                uo = qa,
                lo = $a.getHighWaterMark,
                co = Za.codes,
                ho = co.ERR_INVALID_ARG_TYPE,
                fo = co.ERR_METHOD_NOT_IMPLEMENTED,
                po = co.ERR_MULTIPLE_CALLBACK,
                _o = co.ERR_STREAM_CANNOT_PIPE,
                yo = co.ERR_STREAM_DESTROYED,
                go = co.ERR_STREAM_NULL_VALUES,
                bo = co.ERR_STREAM_WRITE_AFTER_END,
                vo = co.ERR_UNKNOWN_ENCODING,
                mo = uo.errorOrDestroy;

            function wo() {}

            function xo(e, t, r) {
                eo = eo || Po, e = e || {}, "boolean" != typeof r && (r = t instanceof eo), this.objectMode = !!e.objectMode, r && (this.objectMode = this.objectMode || !!e.writableObjectMode), this.highWaterMark = lo(this, e, "writableHighWaterMark", r), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
                var n = !1 === e.decodeStrings;
                this.decodeStrings = !n, this.defaultEncoding = e.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(e) {
                    ! function(e, t) {
                        var r = e._writableState,
                            n = r.sync,
                            i = r.writecb;
                        if ("function" != typeof i) throw new po;
                        if (function(e) {
                                e.writing = !1, e.writecb = null, e.length -= e.writelen, e.writelen = 0
                            }(r), t) ! function(e, t, r, n, i) {
                            --t.pendingcb, r ? (process.nextTick(i, n), process.nextTick(Oo, e, t), e._writableState.errorEmitted = !0, mo(e, n)) : (i(n), e._writableState.errorEmitted = !0, mo(e, n), Oo(e, t))
                        }(e, r, n, t, i);
                        else {
                            var a = To(r) || e.destroyed;
                            a || r.corked || r.bufferProcessing || !r.bufferedRequest || Ao(e, r), n ? process.nextTick(Eo, e, r, a, i) : Eo(e, r, a, i)
                        }
                    }(t, e)
                }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.emitClose = !1 !== e.emitClose, this.autoDestroy = !!e.autoDestroy, this.bufferedRequestCount = 0, this.corkedRequestsFree = new ro(this)
            }

            function ko(e) {
                var t = this instanceof(eo = eo || Po);
                if (!t && !no.call(ko, this)) return new ko(e);
                this._writableState = new xo(e, this, t), this.writable = !0, e && ("function" == typeof e.write && (this._write = e.write), "function" == typeof e.writev && (this._writev = e.writev), "function" == typeof e.destroy && (this._destroy = e.destroy), "function" == typeof e.final && (this._final = e.final)), ao.call(this)
            }

            function So(e, t, r, n, i, a, o) {
                t.writelen = n, t.writecb = o, t.writing = !0, t.sync = !0, t.destroyed ? t.onwrite(new yo("write")) : r ? e._writev(i, t.onwrite) : e._write(i, a, t.onwrite), t.sync = !1
            }

            function Eo(e, t, r, n) {
                r || function(e, t) {
                    0 === t.length && t.needDrain && (t.needDrain = !1, e.emit("drain"))
                }(e, t), t.pendingcb--, n(), Oo(e, t)
            }

            function Ao(e, t) {
                t.bufferProcessing = !0;
                var r = t.bufferedRequest;
                if (e._writev && r && r.next) {
                    var n = t.bufferedRequestCount,
                        i = new Array(n),
                        a = t.corkedRequestsFree;
                    a.entry = r;
                    for (var o = 0, s = !0; r;) i[o] = r, r.isBuf || (s = !1), r = r.next, o += 1;
                    i.allBuffers = s, So(e, t, !0, t.length, i, "", a.finish), t.pendingcb++, t.lastBufferedRequest = null, a.next ? (t.corkedRequestsFree = a.next, a.next = null) : t.corkedRequestsFree = new ro(t), t.bufferedRequestCount = 0
                } else {
                    for (; r;) {
                        var u = r.chunk,
                            l = r.encoding,
                            c = r.callback;
                        if (So(e, t, !1, t.objectMode ? 1 : u.length, u, l, c), r = r.next, t.bufferedRequestCount--, t.writing) break
                    }
                    null === r && (t.lastBufferedRequest = null)
                }
                t.bufferedRequest = r, t.bufferProcessing = !1
            }

            function To(e) {
                return e.ending && 0 === e.length && null === e.bufferedRequest && !e.finished && !e.writing
            }

            function zo(e, t) {
                e._final((function(r) {
                    t.pendingcb--, r && mo(e, r), t.prefinished = !0, e.emit("prefinish"), Oo(e, t)
                }))
            }

            function Oo(e, t) {
                var r = To(t);
                if (r && (function(e, t) {
                        t.prefinished || t.finalCalled || ("function" != typeof e._final || t.destroyed ? (t.prefinished = !0, e.emit("prefinish")) : (t.pendingcb++, t.finalCalled = !0, process.nextTick(zo, e, t)))
                    }(e, t), 0 === t.pendingcb && (t.finished = !0, e.emit("finish"), t.autoDestroy))) {
                    var n = e._readableState;
                    (!n || n.autoDestroy && n.endEmitted) && e.destroy()
                }
                return r
            }
            Dr.exports(ko, ao), xo.prototype.getBuffer = function() {
                    for (var e = this.bufferedRequest, t = []; e;) t.push(e), e = e.next;
                    return t
                },
                function() {
                    try {
                        Object.defineProperty(xo.prototype, "buffer", {
                            get: io.deprecate((function() {
                                return this.getBuffer()
                            }), "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
                        })
                    } catch (e) {}
                }(), "function" == typeof Symbol && Symbol.hasInstance && "function" == typeof Function.prototype[Symbol.hasInstance] ? (no = Function.prototype[Symbol.hasInstance], Object.defineProperty(ko, Symbol.hasInstance, {
                    value: function(e) {
                        return !!no.call(this, e) || this === ko && e && e._writableState instanceof xo
                    }
                })) : no = function(e) {
                    return e instanceof this
                }, ko.prototype.pipe = function() {
                    mo(this, new _o)
                }, ko.prototype.write = function(e, t, r) {
                    var n, i = this._writableState,
                        a = !1,
                        o = !i.objectMode && (n = e, oo.isBuffer(n) || n instanceof so);
                    return o && !oo.isBuffer(e) && (e = function(e) {
                        return oo.from(e)
                    }(e)), "function" == typeof t && (r = t, t = null), o ? t = "buffer" : t || (t = i.defaultEncoding), "function" != typeof r && (r = wo), i.ending ? function(e, t) {
                        var r = new bo;
                        mo(e, r), process.nextTick(t, r)
                    }(this, r) : (o || function(e, t, r, n) {
                        var i;
                        return null === r ? i = new go : "string" == typeof r || t.objectMode || (i = new ho("chunk", ["string", "Buffer"], r)), !i || (mo(e, i), process.nextTick(n, i), !1)
                    }(this, i, e, r)) && (i.pendingcb++, a = function(e, t, r, n, i, a) {
                        if (!r) {
                            var o = function(e, t, r) {
                                return e.objectMode || !1 === e.decodeStrings || "string" != typeof t || (t = oo.from(t, r)), t
                            }(t, n, i);
                            n !== o && (r = !0, i = "buffer", n = o)
                        }
                        var s = t.objectMode ? 1 : n.length;
                        t.length += s;
                        var u = t.length < t.highWaterMark;
                        if (u || (t.needDrain = !0), t.writing || t.corked) {
                            var l = t.lastBufferedRequest;
                            t.lastBufferedRequest = {
                                chunk: n,
                                encoding: i,
                                isBuf: r,
                                callback: a,
                                next: null
                            }, l ? l.next = t.lastBufferedRequest : t.bufferedRequest = t.lastBufferedRequest, t.bufferedRequestCount += 1
                        } else So(e, t, !1, s, n, i, a);
                        return u
                    }(this, i, o, e, t, r)), a
                }, ko.prototype.cork = function() {
                    this._writableState.corked++
                }, ko.prototype.uncork = function() {
                    var e = this._writableState;
                    e.corked && (e.corked--, e.writing || e.corked || e.bufferProcessing || !e.bufferedRequest || Ao(this, e))
                }, ko.prototype.setDefaultEncoding = function(e) {
                    if ("string" == typeof e && (e = e.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((e + "").toLowerCase()) > -1)) throw new vo(e);
                    return this._writableState.defaultEncoding = e, this
                }, Object.defineProperty(ko.prototype, "writableBuffer", {
                    enumerable: !1,
                    get: function() {
                        return this._writableState && this._writableState.getBuffer()
                    }
                }), Object.defineProperty(ko.prototype, "writableHighWaterMark", {
                    enumerable: !1,
                    get: function() {
                        return this._writableState.highWaterMark
                    }
                }), ko.prototype._write = function(e, t, r) {
                    r(new fo("_write()"))
                }, ko.prototype._writev = null, ko.prototype.end = function(e, t, r) {
                    var n = this._writableState;
                    return "function" == typeof e ? (r = e, e = null, t = null) : "function" == typeof t && (r = t, t = null), null != e && this.write(e, t), n.corked && (n.corked = 1, this.uncork()), n.ending || function(e, t, r) {
                        t.ending = !0, Oo(e, t), r && (t.finished ? process.nextTick(r) : e.once("finish", r)), t.ended = !0, e.writable = !1
                    }(this, n, r), this
                }, Object.defineProperty(ko.prototype, "writableLength", {
                    enumerable: !1,
                    get: function() {
                        return this._writableState.length
                    }
                }), Object.defineProperty(ko.prototype, "destroyed", {
                    enumerable: !1,
                    get: function() {
                        return void 0 !== this._writableState && this._writableState.destroyed
                    },
                    set: function(e) {
                        this._writableState && (this._writableState.destroyed = e)
                    }
                }), ko.prototype.destroy = uo.destroy, ko.prototype._undestroy = uo.undestroy, ko.prototype._destroy = function(e, t) {
                    t(e)
                };
            var Ro = Object.keys || function(e) {
                    var t = [];
                    for (var r in e) t.push(r);
                    return t
                },
                Po = Bo,
                No = vs,
                Do = to;
            Dr.exports(Bo, No);
            for (var Lo = Ro(Do.prototype), Uo = 0; Uo < Lo.length; Uo++) {
                var Io = Lo[Uo];
                Bo.prototype[Io] || (Bo.prototype[Io] = Do.prototype[Io])
            }

            function Bo(e) {
                if (!(this instanceof Bo)) return new Bo(e);
                No.call(this, e), Do.call(this, e), this.allowHalfOpen = !0, e && (!1 === e.readable && (this.readable = !1), !1 === e.writable && (this.writable = !1), !1 === e.allowHalfOpen && (this.allowHalfOpen = !1, this.once("end", jo)))
            }

            function jo() {
                this._writableState.ended || process.nextTick(Mo, this)
            }

            function Mo(e) {
                e.end()
            }
            Object.defineProperty(Bo.prototype, "writableHighWaterMark", {
                enumerable: !1,
                get: function() {
                    return this._writableState.highWaterMark
                }
            }), Object.defineProperty(Bo.prototype, "writableBuffer", {
                enumerable: !1,
                get: function() {
                    return this._writableState && this._writableState.getBuffer()
                }
            }), Object.defineProperty(Bo.prototype, "writableLength", {
                enumerable: !1,
                get: function() {
                    return this._writableState.length
                }
            }), Object.defineProperty(Bo.prototype, "destroyed", {
                enumerable: !1,
                get: function() {
                    return void 0 !== this._readableState && void 0 !== this._writableState && this._readableState.destroyed && this._writableState.destroyed
                },
                set: function(e) {
                    void 0 !== this._readableState && void 0 !== this._writableState && (this._readableState.destroyed = e, this._writableState.destroyed = e)
                }
            });
            var Co = {},
                Fo = Na.exports.Buffer,
                Ho = Fo.isEncoding || function(e) {
                    switch ((e = "" + e) && e.toLowerCase()) {
                        case "hex":
                        case "utf8":
                        case "utf-8":
                        case "ascii":
                        case "binary":
                        case "base64":
                        case "ucs2":
                        case "ucs-2":
                        case "utf16le":
                        case "utf-16le":
                        case "raw":
                            return !0;
                        default:
                            return !1
                    }
                };

            function Ko(e) {
                var t;
                switch (this.encoding = function(e) {
                    var t = function(e) {
                        if (!e) return "utf8";
                        for (var t;;) switch (e) {
                            case "utf8":
                            case "utf-8":
                                return "utf8";
                            case "ucs2":
                            case "ucs-2":
                            case "utf16le":
                            case "utf-16le":
                                return "utf16le";
                            case "latin1":
                            case "binary":
                                return "latin1";
                            case "base64":
                            case "ascii":
                            case "hex":
                                return e;
                            default:
                                if (t) return;
                                e = ("" + e).toLowerCase(), t = !0
                        }
                    }(e);
                    if ("string" != typeof t && (Fo.isEncoding === Ho || !Ho(e))) throw new Error("Unknown encoding: " + e);
                    return t || e
                }(e), this.encoding) {
                    case "utf16le":
                        this.text = Zo, this.end = Vo, t = 4;
                        break;
                    case "utf8":
                        this.fillLast = qo, t = 4;
                        break;
                    case "base64":
                        this.text = Go, this.end = Jo, t = 3;
                        break;
                    default:
                        return this.write = Yo, void(this.end = $o)
                }
                this.lastNeed = 0, this.lastTotal = 0, this.lastChar = Fo.allocUnsafe(t)
            }

            function Wo(e) {
                return e <= 127 ? 0 : e >> 5 == 6 ? 2 : e >> 4 == 14 ? 3 : e >> 3 == 30 ? 4 : e >> 6 == 2 ? -1 : -2
            }

            function qo(e) {
                var t = this.lastTotal - this.lastNeed,
                    r = function(e, t, r) {
                        if (128 != (192 & t[0])) return e.lastNeed = 0, "�";
                        if (e.lastNeed > 1 && t.length > 1) {
                            if (128 != (192 & t[1])) return e.lastNeed = 1, "�";
                            if (e.lastNeed > 2 && t.length > 2 && 128 != (192 & t[2])) return e.lastNeed = 2, "�"
                        }
                    }(this, e);
                return void 0 !== r ? r : this.lastNeed <= e.length ? (e.copy(this.lastChar, t, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal)) : (e.copy(this.lastChar, t, 0, e.length), void(this.lastNeed -= e.length))
            }

            function Zo(e, t) {
                if ((e.length - t) % 2 == 0) {
                    var r = e.toString("utf16le", t);
                    if (r) {
                        var n = r.charCodeAt(r.length - 1);
                        if (n >= 55296 && n <= 56319) return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = e[e.length - 2], this.lastChar[1] = e[e.length - 1], r.slice(0, -1)
                    }
                    return r
                }
                return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = e[e.length - 1], e.toString("utf16le", t, e.length - 1)
            }

            function Vo(e) {
                var t = e && e.length ? this.write(e) : "";
                if (this.lastNeed) {
                    var r = this.lastTotal - this.lastNeed;
                    return t + this.lastChar.toString("utf16le", 0, r)
                }
                return t
            }

            function Go(e, t) {
                var r = (e.length - t) % 3;
                return 0 === r ? e.toString("base64", t) : (this.lastNeed = 3 - r, this.lastTotal = 3, 1 === r ? this.lastChar[0] = e[e.length - 1] : (this.lastChar[0] = e[e.length - 2], this.lastChar[1] = e[e.length - 1]), e.toString("base64", t, e.length - r))
            }

            function Jo(e) {
                var t = e && e.length ? this.write(e) : "";
                return this.lastNeed ? t + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : t
            }

            function Yo(e) {
                return e.toString(this.encoding)
            }

            function $o(e) {
                return e && e.length ? this.write(e) : ""
            }
            Co.StringDecoder = Ko, Ko.prototype.write = function(e) {
                if (0 === e.length) return "";
                var t, r;
                if (this.lastNeed) {
                    if (void 0 === (t = this.fillLast(e))) return "";
                    r = this.lastNeed, this.lastNeed = 0
                } else r = 0;
                return r < e.length ? t ? t + this.text(e, r) : this.text(e, r) : t || ""
            }, Ko.prototype.end = function(e) {
                var t = e && e.length ? this.write(e) : "";
                return this.lastNeed ? t + "�" : t
            }, Ko.prototype.text = function(e, t) {
                var r = function(e, t, r) {
                    var n = t.length - 1;
                    if (n < r) return 0;
                    var i = Wo(t[n]);
                    return i >= 0 ? (i > 0 && (e.lastNeed = i - 1), i) : --n < r || -2 === i ? 0 : (i = Wo(t[n])) >= 0 ? (i > 0 && (e.lastNeed = i - 2), i) : --n < r || -2 === i ? 0 : (i = Wo(t[n])) >= 0 ? (i > 0 && (2 === i ? i = 0 : e.lastNeed = i - 3), i) : 0
                }(this, e, t);
                if (!this.lastNeed) return e.toString("utf8", t);
                this.lastTotal = r;
                var n = e.length - (r - this.lastNeed);
                return e.copy(this.lastChar, 0, n), e.toString("utf8", t, n)
            }, Ko.prototype.fillLast = function(e) {
                if (this.lastNeed <= e.length) return e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
                e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, e.length), this.lastNeed -= e.length
            };
            var Qo = Za.codes.ERR_STREAM_PREMATURE_CLOSE;

            function Xo() {}
            var es, ts = function e(t, r, n) {
                if ("function" == typeof r) return e(t, null, r);
                r || (r = {}), n = function(e) {
                    var t = !1;
                    return function() {
                        if (!t) {
                            t = !0;
                            for (var r = arguments.length, n = new Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                            e.apply(this, n)
                        }
                    }
                }(n || Xo);
                var i = r.readable || !1 !== r.readable && t.readable,
                    a = r.writable || !1 !== r.writable && t.writable,
                    o = function() {
                        t.writable || u()
                    },
                    s = t._writableState && t._writableState.finished,
                    u = function() {
                        a = !1, s = !0, i || n.call(t)
                    },
                    l = t._readableState && t._readableState.endEmitted,
                    c = function() {
                        i = !1, l = !0, a || n.call(t)
                    },
                    h = function(e) {
                        n.call(t, e)
                    },
                    f = function() {
                        var e;
                        return i && !l ? (t._readableState && t._readableState.ended || (e = new Qo), n.call(t, e)) : a && !s ? (t._writableState && t._writableState.ended || (e = new Qo), n.call(t, e)) : void 0
                    },
                    d = function() {
                        t.req.on("finish", u)
                    };
                return function(e) {
                        return e.setHeader && "function" == typeof e.abort
                    }(t) ? (t.on("complete", u), t.on("abort", f), t.req ? d() : t.on("request", d)) : a && !t._writableState && (t.on("end", o), t.on("close", o)), t.on("end", c), t.on("finish", u), !1 !== r.error && t.on("error", h), t.on("close", f),
                    function() {
                        t.removeListener("complete", u), t.removeListener("abort", f), t.removeListener("request", d), t.req && t.req.removeListener("finish", u), t.removeListener("end", o), t.removeListener("close", o), t.removeListener("finish", u), t.removeListener("end", c), t.removeListener("error", h), t.removeListener("close", f)
                    }
            };

            function rs(e, t, r) {
                return t in e ? Object.defineProperty(e, t, {
                    value: r,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = r, e
            }
            var ns = ts,
                is = Symbol("lastResolve"),
                as = Symbol("lastReject"),
                os = Symbol("error"),
                ss = Symbol("ended"),
                us = Symbol("lastPromise"),
                ls = Symbol("handlePromise"),
                cs = Symbol("stream");

            function hs(e, t) {
                return {
                    value: e,
                    done: t
                }
            }

            function fs(e) {
                var t = e[is];
                if (null !== t) {
                    var r = e[cs].read();
                    null !== r && (e[us] = null, e[is] = null, e[as] = null, t(hs(r, !1)))
                }
            }

            function ds(e) {
                process.nextTick(fs, e)
            }
            var ps, _s = Object.getPrototypeOf((function() {})),
                ys = Object.setPrototypeOf((rs(es = {
                    get stream() {
                        return this[cs]
                    },
                    next: function() {
                        var e = this,
                            t = this[os];
                        if (null !== t) return Promise.reject(t);
                        if (this[ss]) return Promise.resolve(hs(void 0, !0));
                        if (this[cs].destroyed) return new Promise((function(t, r) {
                            process.nextTick((function() {
                                e[os] ? r(e[os]) : t(hs(void 0, !0))
                            }))
                        }));
                        var r, n = this[us];
                        if (n) r = new Promise(function(e, t) {
                            return function(r, n) {
                                e.then((function() {
                                    t[ss] ? r(hs(void 0, !0)) : t[ls](r, n)
                                }), n)
                            }
                        }(n, this));
                        else {
                            var i = this[cs].read();
                            if (null !== i) return Promise.resolve(hs(i, !1));
                            r = new Promise(this[ls])
                        }
                        return this[us] = r, r
                    }
                }, Symbol.asyncIterator, (function() {
                    return this
                })), rs(es, "return", (function() {
                    var e = this;
                    return new Promise((function(t, r) {
                        e[cs].destroy(null, (function(e) {
                            e ? r(e) : t(hs(void 0, !0))
                        }))
                    }))
                })), es), _s),
                gs = function(e) {
                    var t, r = Object.create(ys, (rs(t = {}, cs, {
                        value: e,
                        writable: !0
                    }), rs(t, is, {
                        value: null,
                        writable: !0
                    }), rs(t, as, {
                        value: null,
                        writable: !0
                    }), rs(t, os, {
                        value: null,
                        writable: !0
                    }), rs(t, ss, {
                        value: e._readableState.endEmitted,
                        writable: !0
                    }), rs(t, ls, {
                        value: function(e, t) {
                            var n = r[cs].read();
                            n ? (r[us] = null, r[is] = null, r[as] = null, e(hs(n, !1))) : (r[is] = e, r[as] = t)
                        },
                        writable: !0
                    }), t));
                    return r[us] = null, ns(e, (function(e) {
                        if (e && "ERR_STREAM_PREMATURE_CLOSE" !== e.code) {
                            var t = r[as];
                            return null !== t && (r[us] = null, r[is] = null, r[as] = null, t(e)), void(r[os] = e)
                        }
                        var n = r[is];
                        null !== n && (r[us] = null, r[is] = null, r[as] = null, n(hs(void 0, !0))), r[ss] = !0
                    })), e.on("readable", ds.bind(null, r)), r
                },
                bs = function() {
                    throw new Error("Readable.from is not available in the browser")
                },
                vs = Cs;
            Cs.ReadableState = Ms, i.exports.EventEmitter;
            var ms, ws = function(e, t) {
                    return e.listeners(t).length
                },
                xs = La,
                ks = a.Buffer,
                Ss = t.Uint8Array || function() {},
                Es = za;
            ms = Es && Es.debuglog ? Es.debuglog("stream") : function() {};
            var As, Ts, zs, Os = Fa,
                Rs = qa,
                Ps = $a.getHighWaterMark,
                Ns = Za.codes,
                Ds = Ns.ERR_INVALID_ARG_TYPE,
                Ls = Ns.ERR_STREAM_PUSH_AFTER_EOF,
                Us = Ns.ERR_METHOD_NOT_IMPLEMENTED,
                Is = Ns.ERR_STREAM_UNSHIFT_AFTER_END_EVENT;
            Dr.exports(Cs, xs);
            var Bs = Rs.errorOrDestroy,
                js = ["error", "close", "destroy", "pause", "resume"];

            function Ms(e, t, r) {
                ps = ps || Po, e = e || {}, "boolean" != typeof r && (r = t instanceof ps), this.objectMode = !!e.objectMode, r && (this.objectMode = this.objectMode || !!e.readableObjectMode), this.highWaterMark = Ps(this, e, "readableHighWaterMark", r), this.buffer = new Os, this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.paused = !0, this.emitClose = !1 !== e.emitClose, this.autoDestroy = !!e.autoDestroy, this.destroyed = !1, this.defaultEncoding = e.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, e.encoding && (As || (As = Co.StringDecoder), this.decoder = new As(e.encoding), this.encoding = e.encoding)
            }

            function Cs(e) {
                if (ps = ps || Po, !(this instanceof Cs)) return new Cs(e);
                var t = this instanceof ps;
                this._readableState = new Ms(e, this, t), this.readable = !0, e && ("function" == typeof e.read && (this._read = e.read), "function" == typeof e.destroy && (this._destroy = e.destroy)), xs.call(this)
            }

            function Fs(e, t, r, n, i) {
                ms("readableAddChunk", t);
                var a, o = e._readableState;
                if (null === t) o.reading = !1,
                    function(e, t) {
                        if (ms("onEofChunk"), !t.ended) {
                            if (t.decoder) {
                                var r = t.decoder.end();
                                r && r.length && (t.buffer.push(r), t.length += t.objectMode ? 1 : r.length)
                            }
                            t.ended = !0, t.sync ? qs(e) : (t.needReadable = !1, t.emittedReadable || (t.emittedReadable = !0, Zs(e)))
                        }
                    }(e, o);
                else if (i || (a = function(e, t) {
                        var r, n;
                        return n = t, ks.isBuffer(n) || n instanceof Ss || "string" == typeof t || void 0 === t || e.objectMode || (r = new Ds("chunk", ["string", "Buffer", "Uint8Array"], t)), r
                    }(o, t)), a) Bs(e, a);
                else if (o.objectMode || t && t.length > 0)
                    if ("string" == typeof t || o.objectMode || Object.getPrototypeOf(t) === ks.prototype || (t = function(e) {
                            return ks.from(e)
                        }(t)), n) o.endEmitted ? Bs(e, new Is) : Hs(e, o, t, !0);
                    else if (o.ended) Bs(e, new Ls);
                else {
                    if (o.destroyed) return !1;
                    o.reading = !1, o.decoder && !r ? (t = o.decoder.write(t), o.objectMode || 0 !== t.length ? Hs(e, o, t, !1) : Vs(e, o)) : Hs(e, o, t, !1)
                } else n || (o.reading = !1, Vs(e, o));
                return !o.ended && (o.length < o.highWaterMark || 0 === o.length)
            }

            function Hs(e, t, r, n) {
                t.flowing && 0 === t.length && !t.sync ? (t.awaitDrain = 0, e.emit("data", r)) : (t.length += t.objectMode ? 1 : r.length, n ? t.buffer.unshift(r) : t.buffer.push(r), t.needReadable && qs(e)), Vs(e, t)
            }
            Object.defineProperty(Cs.prototype, "destroyed", {
                enumerable: !1,
                get: function() {
                    return void 0 !== this._readableState && this._readableState.destroyed
                },
                set: function(e) {
                    this._readableState && (this._readableState.destroyed = e)
                }
            }), Cs.prototype.destroy = Rs.destroy, Cs.prototype._undestroy = Rs.undestroy, Cs.prototype._destroy = function(e, t) {
                t(e)
            }, Cs.prototype.push = function(e, t) {
                var r, n = this._readableState;
                return n.objectMode ? r = !0 : "string" == typeof e && ((t = t || n.defaultEncoding) !== n.encoding && (e = ks.from(e, t), t = ""), r = !0), Fs(this, e, t, !1, r)
            }, Cs.prototype.unshift = function(e) {
                return Fs(this, e, null, !0, !1)
            }, Cs.prototype.isPaused = function() {
                return !1 === this._readableState.flowing
            }, Cs.prototype.setEncoding = function(e) {
                As || (As = Co.StringDecoder);
                var t = new As(e);
                this._readableState.decoder = t, this._readableState.encoding = this._readableState.decoder.encoding;
                for (var r = this._readableState.buffer.head, n = ""; null !== r;) n += t.write(r.data), r = r.next;
                return this._readableState.buffer.clear(), "" !== n && this._readableState.buffer.push(n), this._readableState.length = n.length, this
            };
            var Ks = 1073741824;

            function Ws(e, t) {
                return e <= 0 || 0 === t.length && t.ended ? 0 : t.objectMode ? 1 : e != e ? t.flowing && t.length ? t.buffer.head.data.length : t.length : (e > t.highWaterMark && (t.highWaterMark = function(e) {
                    return e >= Ks ? e = Ks : (e--, e |= e >>> 1, e |= e >>> 2, e |= e >>> 4, e |= e >>> 8, e |= e >>> 16, e++), e
                }(e)), e <= t.length ? e : t.ended ? t.length : (t.needReadable = !0, 0))
            }

            function qs(e) {
                var t = e._readableState;
                ms("emitReadable", t.needReadable, t.emittedReadable), t.needReadable = !1, t.emittedReadable || (ms("emitReadable", t.flowing), t.emittedReadable = !0, process.nextTick(Zs, e))
            }

            function Zs(e) {
                var t = e._readableState;
                ms("emitReadable_", t.destroyed, t.length, t.ended), t.destroyed || !t.length && !t.ended || (e.emit("readable"), t.emittedReadable = !1), t.needReadable = !t.flowing && !t.ended && t.length <= t.highWaterMark, Qs(e)
            }

            function Vs(e, t) {
                t.readingMore || (t.readingMore = !0, process.nextTick(Gs, e, t))
            }

            function Gs(e, t) {
                for (; !t.reading && !t.ended && (t.length < t.highWaterMark || t.flowing && 0 === t.length);) {
                    var r = t.length;
                    if (ms("maybeReadMore read 0"), e.read(0), r === t.length) break
                }
                t.readingMore = !1
            }

            function Js(e) {
                var t = e._readableState;
                t.readableListening = e.listenerCount("readable") > 0, t.resumeScheduled && !t.paused ? t.flowing = !0 : e.listenerCount("data") > 0 && e.resume()
            }

            function Ys(e) {
                ms("readable nexttick read 0"), e.read(0)
            }

            function $s(e, t) {
                ms("resume", t.reading), t.reading || e.read(0), t.resumeScheduled = !1, e.emit("resume"), Qs(e), t.flowing && !t.reading && e.read(0)
            }

            function Qs(e) {
                var t = e._readableState;
                for (ms("flow", t.flowing); t.flowing && null !== e.read(););
            }

            function Xs(e, t) {
                return 0 === t.length ? null : (t.objectMode ? r = t.buffer.shift() : !e || e >= t.length ? (r = t.decoder ? t.buffer.join("") : 1 === t.buffer.length ? t.buffer.first() : t.buffer.concat(t.length), t.buffer.clear()) : r = t.buffer.consume(e, t.decoder), r);
                var r
            }

            function eu(e) {
                var t = e._readableState;
                ms("endReadable", t.endEmitted), t.endEmitted || (t.ended = !0, process.nextTick(tu, t, e))
            }

            function tu(e, t) {
                if (ms("endReadableNT", e.endEmitted, e.length), !e.endEmitted && 0 === e.length && (e.endEmitted = !0, t.readable = !1, t.emit("end"), e.autoDestroy)) {
                    var r = t._writableState;
                    (!r || r.autoDestroy && r.finished) && t.destroy()
                }
            }

            function ru(e, t) {
                for (var r = 0, n = e.length; r < n; r++)
                    if (e[r] === t) return r;
                return -1
            }
            Cs.prototype.read = function(e) {
                ms("read", e), e = parseInt(e, 10);
                var t = this._readableState,
                    r = e;
                if (0 !== e && (t.emittedReadable = !1), 0 === e && t.needReadable && ((0 !== t.highWaterMark ? t.length >= t.highWaterMark : t.length > 0) || t.ended)) return ms("read: emitReadable", t.length, t.ended), 0 === t.length && t.ended ? eu(this) : qs(this), null;
                if (0 === (e = Ws(e, t)) && t.ended) return 0 === t.length && eu(this), null;
                var n, i = t.needReadable;
                return ms("need readable", i), (0 === t.length || t.length - e < t.highWaterMark) && ms("length less than watermark", i = !0), t.ended || t.reading ? ms("reading or ended", i = !1) : i && (ms("do read"), t.reading = !0, t.sync = !0, 0 === t.length && (t.needReadable = !0), this._read(t.highWaterMark), t.sync = !1, t.reading || (e = Ws(r, t))), null === (n = e > 0 ? Xs(e, t) : null) ? (t.needReadable = t.length <= t.highWaterMark, e = 0) : (t.length -= e, t.awaitDrain = 0), 0 === t.length && (t.ended || (t.needReadable = !0), r !== e && t.ended && eu(this)), null !== n && this.emit("data", n), n
            }, Cs.prototype._read = function(e) {
                Bs(this, new Us("_read()"))
            }, Cs.prototype.pipe = function(e, t) {
                var r = this,
                    n = this._readableState;
                switch (n.pipesCount) {
                    case 0:
                        n.pipes = e;
                        break;
                    case 1:
                        n.pipes = [n.pipes, e];
                        break;
                    default:
                        n.pipes.push(e)
                }
                n.pipesCount += 1, ms("pipe count=%d opts=%j", n.pipesCount, t);
                var i = t && !1 === t.end || e === process.stdout || e === process.stderr ? d : o;

                function a(t, i) {
                    ms("onunpipe"), t === r && i && !1 === i.hasUnpiped && (i.hasUnpiped = !0, ms("cleanup"), e.removeListener("close", h), e.removeListener("finish", f), e.removeListener("drain", s), e.removeListener("error", c), e.removeListener("unpipe", a), r.removeListener("end", o), r.removeListener("end", d), r.removeListener("data", l), u = !0, !n.awaitDrain || e._writableState && !e._writableState.needDrain || s())
                }

                function o() {
                    ms("onend"), e.end()
                }
                n.endEmitted ? process.nextTick(i) : r.once("end", i), e.on("unpipe", a);
                var s = function(e) {
                    return function() {
                        var t = e._readableState;
                        ms("pipeOnDrain", t.awaitDrain), t.awaitDrain && t.awaitDrain--, 0 === t.awaitDrain && ws(e, "data") && (t.flowing = !0, Qs(e))
                    }
                }(r);
                e.on("drain", s);
                var u = !1;

                function l(t) {
                    ms("ondata");
                    var i = e.write(t);
                    ms("dest.write", i), !1 === i && ((1 === n.pipesCount && n.pipes === e || n.pipesCount > 1 && -1 !== ru(n.pipes, e)) && !u && (ms("false write response, pause", n.awaitDrain), n.awaitDrain++), r.pause())
                }

                function c(t) {
                    ms("onerror", t), d(), e.removeListener("error", c), 0 === ws(e, "error") && Bs(e, t)
                }

                function h() {
                    e.removeListener("finish", f), d()
                }

                function f() {
                    ms("onfinish"), e.removeListener("close", h), d()
                }

                function d() {
                    ms("unpipe"), r.unpipe(e)
                }
                return r.on("data", l),
                    function(e, t, r) {
                        if ("function" == typeof e.prependListener) return e.prependListener(t, r);
                        e._events && e._events[t] ? Array.isArray(e._events[t]) ? e._events[t].unshift(r) : e._events[t] = [r, e._events[t]] : e.on(t, r)
                    }(e, "error", c), e.once("close", h), e.once("finish", f), e.emit("pipe", r), n.flowing || (ms("pipe resume"), r.resume()), e
            }, Cs.prototype.unpipe = function(e) {
                var t = this._readableState,
                    r = {
                        hasUnpiped: !1
                    };
                if (0 === t.pipesCount) return this;
                if (1 === t.pipesCount) return e && e !== t.pipes || (e || (e = t.pipes), t.pipes = null, t.pipesCount = 0, t.flowing = !1, e && e.emit("unpipe", this, r)), this;
                if (!e) {
                    var n = t.pipes,
                        i = t.pipesCount;
                    t.pipes = null, t.pipesCount = 0, t.flowing = !1;
                    for (var a = 0; a < i; a++) n[a].emit("unpipe", this, {
                        hasUnpiped: !1
                    });
                    return this
                }
                var o = ru(t.pipes, e);
                return -1 === o || (t.pipes.splice(o, 1), t.pipesCount -= 1, 1 === t.pipesCount && (t.pipes = t.pipes[0]), e.emit("unpipe", this, r)), this
            }, Cs.prototype.on = function(e, t) {
                var r = xs.prototype.on.call(this, e, t),
                    n = this._readableState;
                return "data" === e ? (n.readableListening = this.listenerCount("readable") > 0, !1 !== n.flowing && this.resume()) : "readable" === e && (n.endEmitted || n.readableListening || (n.readableListening = n.needReadable = !0, n.flowing = !1, n.emittedReadable = !1, ms("on readable", n.length, n.reading), n.length ? qs(this) : n.reading || process.nextTick(Ys, this))), r
            }, Cs.prototype.addListener = Cs.prototype.on, Cs.prototype.removeListener = function(e, t) {
                var r = xs.prototype.removeListener.call(this, e, t);
                return "readable" === e && process.nextTick(Js, this), r
            }, Cs.prototype.removeAllListeners = function(e) {
                var t = xs.prototype.removeAllListeners.apply(this, arguments);
                return "readable" !== e && void 0 !== e || process.nextTick(Js, this), t
            }, Cs.prototype.resume = function() {
                var e = this._readableState;
                return e.flowing || (ms("resume"), e.flowing = !e.readableListening, function(e, t) {
                    t.resumeScheduled || (t.resumeScheduled = !0, process.nextTick($s, e, t))
                }(this, e)), e.paused = !1, this
            }, Cs.prototype.pause = function() {
                return ms("call pause flowing=%j", this._readableState.flowing), !1 !== this._readableState.flowing && (ms("pause"), this._readableState.flowing = !1, this.emit("pause")), this._readableState.paused = !0, this
            }, Cs.prototype.wrap = function(e) {
                var t = this,
                    r = this._readableState,
                    n = !1;
                for (var i in e.on("end", (function() {
                        if (ms("wrapped end"), r.decoder && !r.ended) {
                            var e = r.decoder.end();
                            e && e.length && t.push(e)
                        }
                        t.push(null)
                    })), e.on("data", (function(i) {
                        ms("wrapped data"), r.decoder && (i = r.decoder.write(i)), r.objectMode && null == i || (r.objectMode || i && i.length) && (t.push(i) || (n = !0, e.pause()))
                    })), e) void 0 === this[i] && "function" == typeof e[i] && (this[i] = function(t) {
                    return function() {
                        return e[t].apply(e, arguments)
                    }
                }(i));
                for (var a = 0; a < js.length; a++) e.on(js[a], this.emit.bind(this, js[a]));
                return this._read = function(t) {
                    ms("wrapped _read", t), n && (n = !1, e.resume())
                }, this
            }, "function" == typeof Symbol && (Cs.prototype[Symbol.asyncIterator] = function() {
                return void 0 === Ts && (Ts = gs), Ts(this)
            }), Object.defineProperty(Cs.prototype, "readableHighWaterMark", {
                enumerable: !1,
                get: function() {
                    return this._readableState.highWaterMark
                }
            }), Object.defineProperty(Cs.prototype, "readableBuffer", {
                enumerable: !1,
                get: function() {
                    return this._readableState && this._readableState.buffer
                }
            }), Object.defineProperty(Cs.prototype, "readableFlowing", {
                enumerable: !1,
                get: function() {
                    return this._readableState.flowing
                },
                set: function(e) {
                    this._readableState && (this._readableState.flowing = e)
                }
            }), Cs._fromList = Xs, Object.defineProperty(Cs.prototype, "readableLength", {
                enumerable: !1,
                get: function() {
                    return this._readableState.length
                }
            }), "function" == typeof Symbol && (Cs.from = function(e, t) {
                return void 0 === zs && (zs = bs), zs(Cs, e, t)
            });
            var nu = hu,
                iu = Za.codes,
                au = iu.ERR_METHOD_NOT_IMPLEMENTED,
                ou = iu.ERR_MULTIPLE_CALLBACK,
                su = iu.ERR_TRANSFORM_ALREADY_TRANSFORMING,
                uu = iu.ERR_TRANSFORM_WITH_LENGTH_0,
                lu = Po;

            function cu(e, t) {
                var r = this._transformState;
                r.transforming = !1;
                var n = r.writecb;
                if (null === n) return this.emit("error", new ou);
                r.writechunk = null, r.writecb = null, null != t && this.push(t), n(e);
                var i = this._readableState;
                i.reading = !1, (i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
            }

            function hu(e) {
                if (!(this instanceof hu)) return new hu(e);
                lu.call(this, e), this._transformState = {
                    afterTransform: cu.bind(this),
                    needTransform: !1,
                    transforming: !1,
                    writecb: null,
                    writechunk: null,
                    writeencoding: null
                }, this._readableState.needReadable = !0, this._readableState.sync = !1, e && ("function" == typeof e.transform && (this._transform = e.transform), "function" == typeof e.flush && (this._flush = e.flush)), this.on("prefinish", fu)
            }

            function fu() {
                var e = this;
                "function" != typeof this._flush || this._readableState.destroyed ? du(this, null, null) : this._flush((function(t, r) {
                    du(e, t, r)
                }))
            }

            function du(e, t, r) {
                if (t) return e.emit("error", t);
                if (null != r && e.push(r), e._writableState.length) throw new uu;
                if (e._transformState.transforming) throw new su;
                return e.push(null)
            }
            Dr.exports(hu, lu), hu.prototype.push = function(e, t) {
                return this._transformState.needTransform = !1, lu.prototype.push.call(this, e, t)
            }, hu.prototype._transform = function(e, t, r) {
                r(new au("_transform()"))
            }, hu.prototype._write = function(e, t, r) {
                var n = this._transformState;
                if (n.writecb = r, n.writechunk = e, n.writeencoding = t, !n.transforming) {
                    var i = this._readableState;
                    (n.needTransform || i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
                }
            }, hu.prototype._read = function(e) {
                var t = this._transformState;
                null === t.writechunk || t.transforming ? t.needTransform = !0 : (t.transforming = !0, this._transform(t.writechunk, t.writeencoding, t.afterTransform))
            }, hu.prototype._destroy = function(e, t) {
                lu.prototype._destroy.call(this, e, (function(e) {
                    t(e)
                }))
            };
            var pu, _u = gu,
                yu = nu;

            function gu(e) {
                if (!(this instanceof gu)) return new gu(e);
                yu.call(this, e)
            }
            Dr.exports(gu, yu), gu.prototype._transform = function(e, t, r) {
                r(null, e)
            };
            var bu = Za.codes,
                vu = bu.ERR_MISSING_ARGS,
                mu = bu.ERR_STREAM_DESTROYED;

            function wu(e) {
                if (e) throw e
            }

            function xu(e, t, r, n) {
                n = function(e) {
                    var t = !1;
                    return function() {
                        t || (t = !0, e.apply(void 0, arguments))
                    }
                }(n);
                var i = !1;
                e.on("close", (function() {
                    i = !0
                })), void 0 === pu && (pu = ts), pu(e, {
                    readable: t,
                    writable: r
                }, (function(e) {
                    if (e) return n(e);
                    i = !0, n()
                }));
                var a = !1;
                return function(t) {
                    if (!i && !a) return a = !0,
                        function(e) {
                            return e.setHeader && "function" == typeof e.abort
                        }(e) ? e.abort() : "function" == typeof e.destroy ? e.destroy() : void n(t || new mu("pipe"))
                }
            }

            function ku(e) {
                e()
            }

            function Su(e, t) {
                return e.pipe(t)
            }

            function Eu(e) {
                return e.length ? "function" != typeof e[e.length - 1] ? wu : e.pop() : wu
            }
            var Au = function() {
                for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                var n, i = Eu(t);
                if (Array.isArray(t[0]) && (t = t[0]), t.length < 2) throw new vu("streams");
                var a = t.map((function(e, r) {
                    var o = r < t.length - 1;
                    return xu(e, o, r > 0, (function(e) {
                        n || (n = e), e && a.forEach(ku), o || (a.forEach(ku), i(n))
                    }))
                }));
                return t.reduce(Su)
            };
            ! function(e, t) {
                (t = e.exports = vs).Stream = t, t.Readable = t, t.Writable = to, t.Duplex = Po, t.Transform = nu, t.PassThrough = _u, t.finished = ts, t.pipeline = Au
            }(Da, Da.exports);
            var Tu = Na.exports.Buffer,
                zu = Da.exports.Transform;

            function Ou(e) {
                zu.call(this), this._block = Tu.allocUnsafe(e), this._blockSize = e, this._blockOffset = 0, this._length = [0, 0, 0, 0], this._finalized = !1
            }(0, Dr.exports)(Ou, zu), Ou.prototype._transform = function(e, t, r) {
                var n = null;
                try {
                    this.update(e, t)
                } catch (Pe) {
                    n = Pe
                }
                r(n)
            }, Ou.prototype._flush = function(e) {
                var t = null;
                try {
                    this.push(this.digest())
                } catch (Pe) {
                    t = Pe
                }
                e(t)
            }, Ou.prototype.update = function(e, t) {
                if (function(e, t) {
                        if (!Tu.isBuffer(e) && "string" != typeof e) throw new TypeError(t + " must be a string or a buffer")
                    }(e, "Data"), this._finalized) throw new Error("Digest already called");
                Tu.isBuffer(e) || (e = Tu.from(e, t));
                for (var r = this._block, n = 0; this._blockOffset + e.length - n >= this._blockSize;) {
                    for (var i = this._blockOffset; i < this._blockSize;) r[i++] = e[n++];
                    this._update(), this._blockOffset = 0
                }
                for (; n < e.length;) r[this._blockOffset++] = e[n++];
                for (var a = 0, o = 8 * e.length; o > 0; ++a) this._length[a] += o, (o = this._length[a] / 4294967296 | 0) > 0 && (this._length[a] -= 4294967296 * o);
                return this
            }, Ou.prototype._update = function() {
                throw new Error("_update is not implemented")
            }, Ou.prototype.digest = function(e) {
                if (this._finalized) throw new Error("Digest already called");
                this._finalized = !0;
                var t = this._digest();
                void 0 !== e && (t = t.toString(e)), this._block.fill(0), this._blockOffset = 0;
                for (var r = 0; r < 4; ++r) this._length[r] = 0;
                return t
            }, Ou.prototype._digest = function() {
                throw new Error("_digest is not implemented")
            };
            var Ru = Ou,
                Pu = Dr.exports,
                Nu = Ru,
                Du = Na.exports.Buffer,
                Lu = new Array(16);

            function Uu() {
                Nu.call(this, 64), this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878
            }

            function Iu(e, t) {
                return e << t | e >>> 32 - t
            }

            function Bu(e, t, r, n, i, a, o) {
                return Iu(e + (t & r | ~t & n) + i + a | 0, o) + t | 0
            }

            function ju(e, t, r, n, i, a, o) {
                return Iu(e + (t & n | r & ~n) + i + a | 0, o) + t | 0
            }

            function Mu(e, t, r, n, i, a, o) {
                return Iu(e + (t ^ r ^ n) + i + a | 0, o) + t | 0
            }

            function Cu(e, t, r, n, i, a, o) {
                return Iu(e + (r ^ (t | ~n)) + i + a | 0, o) + t | 0
            }
            Pu(Uu, Nu), Uu.prototype._update = function() {
                for (var e = Lu, t = 0; t < 16; ++t) e[t] = this._block.readInt32LE(4 * t);
                var r = this._a,
                    n = this._b,
                    i = this._c,
                    a = this._d;
                r = Bu(r, n, i, a, e[0], 3614090360, 7), a = Bu(a, r, n, i, e[1], 3905402710, 12), i = Bu(i, a, r, n, e[2], 606105819, 17), n = Bu(n, i, a, r, e[3], 3250441966, 22), r = Bu(r, n, i, a, e[4], 4118548399, 7), a = Bu(a, r, n, i, e[5], 1200080426, 12), i = Bu(i, a, r, n, e[6], 2821735955, 17), n = Bu(n, i, a, r, e[7], 4249261313, 22), r = Bu(r, n, i, a, e[8], 1770035416, 7), a = Bu(a, r, n, i, e[9], 2336552879, 12), i = Bu(i, a, r, n, e[10], 4294925233, 17), n = Bu(n, i, a, r, e[11], 2304563134, 22), r = Bu(r, n, i, a, e[12], 1804603682, 7), a = Bu(a, r, n, i, e[13], 4254626195, 12), i = Bu(i, a, r, n, e[14], 2792965006, 17), r = ju(r, n = Bu(n, i, a, r, e[15], 1236535329, 22), i, a, e[1], 4129170786, 5), a = ju(a, r, n, i, e[6], 3225465664, 9), i = ju(i, a, r, n, e[11], 643717713, 14), n = ju(n, i, a, r, e[0], 3921069994, 20), r = ju(r, n, i, a, e[5], 3593408605, 5), a = ju(a, r, n, i, e[10], 38016083, 9), i = ju(i, a, r, n, e[15], 3634488961, 14), n = ju(n, i, a, r, e[4], 3889429448, 20), r = ju(r, n, i, a, e[9], 568446438, 5), a = ju(a, r, n, i, e[14], 3275163606, 9), i = ju(i, a, r, n, e[3], 4107603335, 14), n = ju(n, i, a, r, e[8], 1163531501, 20), r = ju(r, n, i, a, e[13], 2850285829, 5), a = ju(a, r, n, i, e[2], 4243563512, 9), i = ju(i, a, r, n, e[7], 1735328473, 14), r = Mu(r, n = ju(n, i, a, r, e[12], 2368359562, 20), i, a, e[5], 4294588738, 4), a = Mu(a, r, n, i, e[8], 2272392833, 11), i = Mu(i, a, r, n, e[11], 1839030562, 16), n = Mu(n, i, a, r, e[14], 4259657740, 23), r = Mu(r, n, i, a, e[1], 2763975236, 4), a = Mu(a, r, n, i, e[4], 1272893353, 11), i = Mu(i, a, r, n, e[7], 4139469664, 16), n = Mu(n, i, a, r, e[10], 3200236656, 23), r = Mu(r, n, i, a, e[13], 681279174, 4), a = Mu(a, r, n, i, e[0], 3936430074, 11), i = Mu(i, a, r, n, e[3], 3572445317, 16), n = Mu(n, i, a, r, e[6], 76029189, 23), r = Mu(r, n, i, a, e[9], 3654602809, 4), a = Mu(a, r, n, i, e[12], 3873151461, 11), i = Mu(i, a, r, n, e[15], 530742520, 16), r = Cu(r, n = Mu(n, i, a, r, e[2], 3299628645, 23), i, a, e[0], 4096336452, 6), a = Cu(a, r, n, i, e[7], 1126891415, 10), i = Cu(i, a, r, n, e[14], 2878612391, 15), n = Cu(n, i, a, r, e[5], 4237533241, 21), r = Cu(r, n, i, a, e[12], 1700485571, 6), a = Cu(a, r, n, i, e[3], 2399980690, 10), i = Cu(i, a, r, n, e[10], 4293915773, 15), n = Cu(n, i, a, r, e[1], 2240044497, 21), r = Cu(r, n, i, a, e[8], 1873313359, 6), a = Cu(a, r, n, i, e[15], 4264355552, 10), i = Cu(i, a, r, n, e[6], 2734768916, 15), n = Cu(n, i, a, r, e[13], 1309151649, 21), r = Cu(r, n, i, a, e[4], 4149444226, 6), a = Cu(a, r, n, i, e[11], 3174756917, 10), i = Cu(i, a, r, n, e[2], 718787259, 15), n = Cu(n, i, a, r, e[9], 3951481745, 21), this._a = this._a + r | 0, this._b = this._b + n | 0, this._c = this._c + i | 0, this._d = this._d + a | 0
            }, Uu.prototype._digest = function() {
                this._block[this._blockOffset++] = 128, this._blockOffset > 56 && (this._block.fill(0, this._blockOffset, 64), this._update(), this._blockOffset = 0), this._block.fill(0, this._blockOffset, 56), this._block.writeUInt32LE(this._length[0], 56), this._block.writeUInt32LE(this._length[1], 60), this._update();
                var e = Du.allocUnsafe(16);
                return e.writeInt32LE(this._a, 0), e.writeInt32LE(this._b, 4), e.writeInt32LE(this._c, 8), e.writeInt32LE(this._d, 12), e
            };
            var Fu = Uu,
                Hu = a.Buffer,
                Ku = Dr.exports,
                Wu = Ru,
                qu = new Array(16),
                Zu = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13],
                Vu = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11],
                Gu = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6],
                Ju = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11],
                Yu = [0, 1518500249, 1859775393, 2400959708, 2840853838],
                $u = [1352829926, 1548603684, 1836072691, 2053994217, 0];

            function Qu() {
                Wu.call(this, 64), this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520
            }

            function Xu(e, t) {
                return e << t | e >>> 32 - t
            }

            function el(e, t, r, n, i, a, o, s) {
                return Xu(e + (t ^ r ^ n) + a + o | 0, s) + i | 0
            }

            function tl(e, t, r, n, i, a, o, s) {
                return Xu(e + (t & r | ~t & n) + a + o | 0, s) + i | 0
            }

            function rl(e, t, r, n, i, a, o, s) {
                return Xu(e + ((t | ~r) ^ n) + a + o | 0, s) + i | 0
            }

            function nl(e, t, r, n, i, a, o, s) {
                return Xu(e + (t & n | r & ~n) + a + o | 0, s) + i | 0
            }

            function il(e, t, r, n, i, a, o, s) {
                return Xu(e + (t ^ (r | ~n)) + a + o | 0, s) + i | 0
            }
            Ku(Qu, Wu), Qu.prototype._update = function() {
                for (var e = qu, t = 0; t < 16; ++t) e[t] = this._block.readInt32LE(4 * t);
                for (var r = 0 | this._a, n = 0 | this._b, i = 0 | this._c, a = 0 | this._d, o = 0 | this._e, s = 0 | this._a, u = 0 | this._b, l = 0 | this._c, c = 0 | this._d, h = 0 | this._e, f = 0; f < 80; f += 1) {
                    var d, p;
                    f < 16 ? (d = el(r, n, i, a, o, e[Zu[f]], Yu[0], Gu[f]), p = il(s, u, l, c, h, e[Vu[f]], $u[0], Ju[f])) : f < 32 ? (d = tl(r, n, i, a, o, e[Zu[f]], Yu[1], Gu[f]), p = nl(s, u, l, c, h, e[Vu[f]], $u[1], Ju[f])) : f < 48 ? (d = rl(r, n, i, a, o, e[Zu[f]], Yu[2], Gu[f]), p = rl(s, u, l, c, h, e[Vu[f]], $u[2], Ju[f])) : f < 64 ? (d = nl(r, n, i, a, o, e[Zu[f]], Yu[3], Gu[f]), p = tl(s, u, l, c, h, e[Vu[f]], $u[3], Ju[f])) : (d = il(r, n, i, a, o, e[Zu[f]], Yu[4], Gu[f]), p = el(s, u, l, c, h, e[Vu[f]], $u[4], Ju[f])), r = o, o = a, a = Xu(i, 10), i = n, n = d, s = h, h = c, c = Xu(l, 10), l = u, u = p
                }
                var _ = this._b + i + c | 0;
                this._b = this._c + a + h | 0, this._c = this._d + o + s | 0, this._d = this._e + r + u | 0, this._e = this._a + n + l | 0, this._a = _
            }, Qu.prototype._digest = function() {
                this._block[this._blockOffset++] = 128, this._blockOffset > 56 && (this._block.fill(0, this._blockOffset, 64), this._update(), this._blockOffset = 0), this._block.fill(0, this._blockOffset, 56), this._block.writeUInt32LE(this._length[0], 56), this._block.writeUInt32LE(this._length[1], 60), this._update();
                var e = Hu.alloc ? Hu.alloc(20) : new Hu(20);
                return e.writeInt32LE(this._a, 0), e.writeInt32LE(this._b, 4), e.writeInt32LE(this._c, 8), e.writeInt32LE(this._d, 12), e.writeInt32LE(this._e, 16), e
            };
            var al = Qu,
                ol = {
                    exports: {}
                },
                sl = Na.exports.Buffer;

            function ul(e, t) {
                this._block = sl.alloc(e), this._finalSize = t, this._blockSize = e, this._len = 0
            }
            ul.prototype.update = function(e, t) {
                "string" == typeof e && (t = t || "utf8", e = sl.from(e, t));
                for (var r = this._block, n = this._blockSize, i = e.length, a = this._len, o = 0; o < i;) {
                    for (var s = a % n, u = Math.min(i - o, n - s), l = 0; l < u; l++) r[s + l] = e[o + l];
                    o += u, (a += u) % n == 0 && this._update(r)
                }
                return this._len += i, this
            }, ul.prototype.digest = function(e) {
                var t = this._len % this._blockSize;
                this._block[t] = 128, this._block.fill(0, t + 1), t >= this._finalSize && (this._update(this._block), this._block.fill(0));
                var r = 8 * this._len;
                if (r <= 4294967295) this._block.writeUInt32BE(r, this._blockSize - 4);
                else {
                    var n = (4294967295 & r) >>> 0,
                        i = (r - n) / 4294967296;
                    this._block.writeUInt32BE(i, this._blockSize - 8), this._block.writeUInt32BE(n, this._blockSize - 4)
                }
                this._update(this._block);
                var a = this._hash();
                return e ? a.toString(e) : a
            }, ul.prototype._update = function() {
                throw new Error("_update must be implemented by subclass")
            };
            var ll = ul,
                cl = Dr.exports,
                hl = ll,
                fl = Na.exports.Buffer,
                dl = [1518500249, 1859775393, -1894007588, -899497514],
                pl = new Array(80);

            function _l() {
                this.init(), this._w = pl, hl.call(this, 64, 56)
            }

            function yl(e) {
                return e << 30 | e >>> 2
            }

            function gl(e, t, r, n) {
                return 0 === e ? t & r | ~t & n : 2 === e ? t & r | t & n | r & n : t ^ r ^ n
            }
            cl(_l, hl), _l.prototype.init = function() {
                return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this
            }, _l.prototype._update = function(e) {
                for (var t, r = this._w, n = 0 | this._a, i = 0 | this._b, a = 0 | this._c, o = 0 | this._d, s = 0 | this._e, u = 0; u < 16; ++u) r[u] = e.readInt32BE(4 * u);
                for (; u < 80; ++u) r[u] = r[u - 3] ^ r[u - 8] ^ r[u - 14] ^ r[u - 16];
                for (var l = 0; l < 80; ++l) {
                    var c = ~~(l / 20),
                        h = 0 | ((t = n) << 5 | t >>> 27) + gl(c, i, a, o) + s + r[l] + dl[c];
                    s = o, o = a, a = yl(i), i = n, n = h
                }
                this._a = n + this._a | 0, this._b = i + this._b | 0, this._c = a + this._c | 0, this._d = o + this._d | 0, this._e = s + this._e | 0
            }, _l.prototype._hash = function() {
                var e = fl.allocUnsafe(20);
                return e.writeInt32BE(0 | this._a, 0), e.writeInt32BE(0 | this._b, 4), e.writeInt32BE(0 | this._c, 8), e.writeInt32BE(0 | this._d, 12), e.writeInt32BE(0 | this._e, 16), e
            };
            var bl = _l,
                vl = Dr.exports,
                ml = ll,
                wl = Na.exports.Buffer,
                xl = [1518500249, 1859775393, -1894007588, -899497514],
                kl = new Array(80);

            function Sl() {
                this.init(), this._w = kl, ml.call(this, 64, 56)
            }

            function El(e) {
                return e << 5 | e >>> 27
            }

            function Al(e) {
                return e << 30 | e >>> 2
            }

            function Tl(e, t, r, n) {
                return 0 === e ? t & r | ~t & n : 2 === e ? t & r | t & n | r & n : t ^ r ^ n
            }
            vl(Sl, ml), Sl.prototype.init = function() {
                return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this
            }, Sl.prototype._update = function(e) {
                for (var t, r = this._w, n = 0 | this._a, i = 0 | this._b, a = 0 | this._c, o = 0 | this._d, s = 0 | this._e, u = 0; u < 16; ++u) r[u] = e.readInt32BE(4 * u);
                for (; u < 80; ++u) r[u] = (t = r[u - 3] ^ r[u - 8] ^ r[u - 14] ^ r[u - 16]) << 1 | t >>> 31;
                for (var l = 0; l < 80; ++l) {
                    var c = ~~(l / 20),
                        h = El(n) + Tl(c, i, a, o) + s + r[l] + xl[c] | 0;
                    s = o, o = a, a = Al(i), i = n, n = h
                }
                this._a = n + this._a | 0, this._b = i + this._b | 0, this._c = a + this._c | 0, this._d = o + this._d | 0, this._e = s + this._e | 0
            }, Sl.prototype._hash = function() {
                var e = wl.allocUnsafe(20);
                return e.writeInt32BE(0 | this._a, 0), e.writeInt32BE(0 | this._b, 4), e.writeInt32BE(0 | this._c, 8), e.writeInt32BE(0 | this._d, 12), e.writeInt32BE(0 | this._e, 16), e
            };
            var zl = Sl,
                Ol = Dr.exports,
                Rl = ll,
                Pl = Na.exports.Buffer,
                Nl = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298],
                Dl = new Array(64);

            function Ll() {
                this.init(), this._w = Dl, Rl.call(this, 64, 56)
            }

            function Ul(e, t, r) {
                return r ^ e & (t ^ r)
            }

            function Il(e, t, r) {
                return e & t | r & (e | t)
            }

            function Bl(e) {
                return (e >>> 2 | e << 30) ^ (e >>> 13 | e << 19) ^ (e >>> 22 | e << 10)
            }

            function jl(e) {
                return (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7)
            }

            function Ml(e) {
                return (e >>> 7 | e << 25) ^ (e >>> 18 | e << 14) ^ e >>> 3
            }
            Ol(Ll, Rl), Ll.prototype.init = function() {
                return this._a = 1779033703, this._b = 3144134277, this._c = 1013904242, this._d = 2773480762, this._e = 1359893119, this._f = 2600822924, this._g = 528734635, this._h = 1541459225, this
            }, Ll.prototype._update = function(e) {
                for (var t, r = this._w, n = 0 | this._a, i = 0 | this._b, a = 0 | this._c, o = 0 | this._d, s = 0 | this._e, u = 0 | this._f, l = 0 | this._g, c = 0 | this._h, h = 0; h < 16; ++h) r[h] = e.readInt32BE(4 * h);
                for (; h < 64; ++h) r[h] = 0 | (((t = r[h - 2]) >>> 17 | t << 15) ^ (t >>> 19 | t << 13) ^ t >>> 10) + r[h - 7] + Ml(r[h - 15]) + r[h - 16];
                for (var f = 0; f < 64; ++f) {
                    var d = c + jl(s) + Ul(s, u, l) + Nl[f] + r[f] | 0,
                        p = Bl(n) + Il(n, i, a) | 0;
                    c = l, l = u, u = s, s = o + d | 0, o = a, a = i, i = n, n = d + p | 0
                }
                this._a = n + this._a | 0, this._b = i + this._b | 0, this._c = a + this._c | 0, this._d = o + this._d | 0, this._e = s + this._e | 0, this._f = u + this._f | 0, this._g = l + this._g | 0, this._h = c + this._h | 0
            }, Ll.prototype._hash = function() {
                var e = Pl.allocUnsafe(32);
                return e.writeInt32BE(this._a, 0), e.writeInt32BE(this._b, 4), e.writeInt32BE(this._c, 8), e.writeInt32BE(this._d, 12), e.writeInt32BE(this._e, 16), e.writeInt32BE(this._f, 20), e.writeInt32BE(this._g, 24), e.writeInt32BE(this._h, 28), e
            };
            var Cl = Ll,
                Fl = Dr.exports,
                Hl = Cl,
                Kl = ll,
                Wl = Na.exports.Buffer,
                ql = new Array(64);

            function Zl() {
                this.init(), this._w = ql, Kl.call(this, 64, 56)
            }
            Fl(Zl, Hl), Zl.prototype.init = function() {
                return this._a = 3238371032, this._b = 914150663, this._c = 812702999, this._d = 4144912697, this._e = 4290775857, this._f = 1750603025, this._g = 1694076839, this._h = 3204075428, this
            }, Zl.prototype._hash = function() {
                var e = Wl.allocUnsafe(28);
                return e.writeInt32BE(this._a, 0), e.writeInt32BE(this._b, 4), e.writeInt32BE(this._c, 8), e.writeInt32BE(this._d, 12), e.writeInt32BE(this._e, 16), e.writeInt32BE(this._f, 20), e.writeInt32BE(this._g, 24), e
            };
            var Vl = Zl,
                Gl = Dr.exports,
                Jl = ll,
                Yl = Na.exports.Buffer,
                $l = [1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591],
                Ql = new Array(160);

            function Xl() {
                this.init(), this._w = Ql, Jl.call(this, 128, 112)
            }

            function ec(e, t, r) {
                return r ^ e & (t ^ r)
            }

            function tc(e, t, r) {
                return e & t | r & (e | t)
            }

            function rc(e, t) {
                return (e >>> 28 | t << 4) ^ (t >>> 2 | e << 30) ^ (t >>> 7 | e << 25)
            }

            function nc(e, t) {
                return (e >>> 14 | t << 18) ^ (e >>> 18 | t << 14) ^ (t >>> 9 | e << 23)
            }

            function ic(e, t) {
                return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ e >>> 7
            }

            function ac(e, t) {
                return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ (e >>> 7 | t << 25)
            }

            function oc(e, t) {
                return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ e >>> 6
            }

            function sc(e, t) {
                return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ (e >>> 6 | t << 26)
            }

            function uc(e, t) {
                return e >>> 0 < t >>> 0 ? 1 : 0
            }
            Gl(Xl, Jl), Xl.prototype.init = function() {
                return this._ah = 1779033703, this._bh = 3144134277, this._ch = 1013904242, this._dh = 2773480762, this._eh = 1359893119, this._fh = 2600822924, this._gh = 528734635, this._hh = 1541459225, this._al = 4089235720, this._bl = 2227873595, this._cl = 4271175723, this._dl = 1595750129, this._el = 2917565137, this._fl = 725511199, this._gl = 4215389547, this._hl = 327033209, this
            }, Xl.prototype._update = function(e) {
                for (var t = this._w, r = 0 | this._ah, n = 0 | this._bh, i = 0 | this._ch, a = 0 | this._dh, o = 0 | this._eh, s = 0 | this._fh, u = 0 | this._gh, l = 0 | this._hh, c = 0 | this._al, h = 0 | this._bl, f = 0 | this._cl, d = 0 | this._dl, p = 0 | this._el, _ = 0 | this._fl, y = 0 | this._gl, g = 0 | this._hl, b = 0; b < 32; b += 2) t[b] = e.readInt32BE(4 * b), t[b + 1] = e.readInt32BE(4 * b + 4);
                for (; b < 160; b += 2) {
                    var v = t[b - 30],
                        m = t[b - 30 + 1],
                        w = ic(v, m),
                        x = ac(m, v),
                        k = oc(v = t[b - 4], m = t[b - 4 + 1]),
                        S = sc(m, v),
                        E = t[b - 14],
                        A = t[b - 14 + 1],
                        T = t[b - 32],
                        z = t[b - 32 + 1],
                        O = x + A | 0,
                        R = w + E + uc(O, x) | 0;
                    R = (R = R + k + uc(O = O + S | 0, S) | 0) + T + uc(O = O + z | 0, z) | 0, t[b] = R, t[b + 1] = O
                }
                for (var P = 0; P < 160; P += 2) {
                    R = t[P], O = t[P + 1];
                    var N = tc(r, n, i),
                        D = tc(c, h, f),
                        L = rc(r, c),
                        U = rc(c, r),
                        I = nc(o, p),
                        B = nc(p, o),
                        j = $l[P],
                        M = $l[P + 1],
                        C = ec(o, s, u),
                        F = ec(p, _, y),
                        H = g + B | 0,
                        K = l + I + uc(H, g) | 0;
                    K = (K = (K = K + C + uc(H = H + F | 0, F) | 0) + j + uc(H = H + M | 0, M) | 0) + R + uc(H = H + O | 0, O) | 0;
                    var W = U + D | 0,
                        q = L + N + uc(W, U) | 0;
                    l = u, g = y, u = s, y = _, s = o, _ = p, o = a + K + uc(p = d + H | 0, d) | 0, a = i, d = f, i = n, f = h, n = r, h = c, r = K + q + uc(c = H + W | 0, H) | 0
                }
                this._al = this._al + c | 0, this._bl = this._bl + h | 0, this._cl = this._cl + f | 0, this._dl = this._dl + d | 0, this._el = this._el + p | 0, this._fl = this._fl + _ | 0, this._gl = this._gl + y | 0, this._hl = this._hl + g | 0, this._ah = this._ah + r + uc(this._al, c) | 0, this._bh = this._bh + n + uc(this._bl, h) | 0, this._ch = this._ch + i + uc(this._cl, f) | 0, this._dh = this._dh + a + uc(this._dl, d) | 0, this._eh = this._eh + o + uc(this._el, p) | 0, this._fh = this._fh + s + uc(this._fl, _) | 0, this._gh = this._gh + u + uc(this._gl, y) | 0, this._hh = this._hh + l + uc(this._hl, g) | 0
            }, Xl.prototype._hash = function() {
                var e = Yl.allocUnsafe(64);

                function t(t, r, n) {
                    e.writeInt32BE(t, n), e.writeInt32BE(r, n + 4)
                }
                return t(this._ah, this._al, 0), t(this._bh, this._bl, 8), t(this._ch, this._cl, 16), t(this._dh, this._dl, 24), t(this._eh, this._el, 32), t(this._fh, this._fl, 40), t(this._gh, this._gl, 48), t(this._hh, this._hl, 56), e
            };
            var lc = Xl,
                cc = Dr.exports,
                hc = lc,
                fc = ll,
                dc = Na.exports.Buffer,
                pc = new Array(160);

            function _c() {
                this.init(), this._w = pc, fc.call(this, 128, 112)
            }
            cc(_c, hc), _c.prototype.init = function() {
                return this._ah = 3418070365, this._bh = 1654270250, this._ch = 2438529370, this._dh = 355462360, this._eh = 1731405415, this._fh = 2394180231, this._gh = 3675008525, this._hh = 1203062813, this._al = 3238371032, this._bl = 914150663, this._cl = 812702999, this._dl = 4144912697, this._el = 4290775857, this._fl = 1750603025, this._gl = 1694076839, this._hl = 3204075428, this
            }, _c.prototype._hash = function() {
                var e = dc.allocUnsafe(48);

                function t(t, r, n) {
                    e.writeInt32BE(t, n), e.writeInt32BE(r, n + 4)
                }
                return t(this._ah, this._al, 0), t(this._bh, this._bl, 8), t(this._ch, this._cl, 16), t(this._dh, this._dl, 24), t(this._eh, this._el, 32), t(this._fh, this._fl, 40), e
            };
            var yc = _c,
                gc = ol.exports = function(e) {
                    e = e.toLowerCase();
                    var t = gc[e];
                    if (!t) throw new Error(e + " is not supported (we accept pull requests)");
                    return new t
                };
            gc.sha = bl, gc.sha1 = zl, gc.sha224 = Vl, gc.sha256 = Cl, gc.sha384 = yc, gc.sha512 = lc;
            var bc = mc,
                vc = i.exports.EventEmitter;

            function mc() {
                vc.call(this)
            }(0, Dr.exports)(mc, vc), mc.Readable = vs, mc.Writable = to, mc.Duplex = Po, mc.Transform = nu, mc.PassThrough = _u, mc.finished = ts, mc.pipeline = Au, mc.Stream = mc, mc.prototype.pipe = function(e, t) {
                var r = this;

                function n(t) {
                    e.writable && !1 === e.write(t) && r.pause && r.pause()
                }

                function i() {
                    r.readable && r.resume && r.resume()
                }
                r.on("data", n), e.on("drain", i), e._isStdio || t && !1 === t.end || (r.on("end", o), r.on("close", s));
                var a = !1;

                function o() {
                    a || (a = !0, e.end())
                }

                function s() {
                    a || (a = !0, "function" == typeof e.destroy && e.destroy())
                }

                function u(e) {
                    if (l(), 0 === vc.listenerCount(this, "error")) throw e
                }

                function l() {
                    r.removeListener("data", n), e.removeListener("drain", i), r.removeListener("end", o), r.removeListener("close", s), r.removeListener("error", u), e.removeListener("error", u), r.removeListener("end", l), r.removeListener("close", l), e.removeListener("close", l)
                }
                return r.on("error", u), e.on("error", u), r.on("end", l), r.on("close", l), e.on("close", l), e.emit("pipe", r), e
            };
            var wc = Na.exports.Buffer,
                xc = bc.Transform,
                kc = Co.StringDecoder;

            function Sc(e) {
                xc.call(this), this.hashMode = "string" == typeof e, this.hashMode ? this[e] = this._finalOrDigest : this.final = this._finalOrDigest, this._final && (this.__final = this._final, this._final = null), this._decoder = null, this._encoding = null
            }(0, Dr.exports)(Sc, xc), Sc.prototype.update = function(e, t, r) {
                "string" == typeof e && (e = wc.from(e, t));
                var n = this._update(e);
                return this.hashMode ? this : (r && (n = this._toString(n, r)), n)
            }, Sc.prototype.setAutoPadding = function() {}, Sc.prototype.getAuthTag = function() {
                throw new Error("trying to get auth tag in unsupported state")
            }, Sc.prototype.setAuthTag = function() {
                throw new Error("trying to set auth tag in unsupported state")
            }, Sc.prototype.setAAD = function() {
                throw new Error("trying to set aad in unsupported state")
            }, Sc.prototype._transform = function(e, t, r) {
                var n;
                try {
                    this.hashMode ? this._update(e) : this.push(this._update(e))
                } catch (i) {
                    n = i
                } finally {
                    r(n)
                }
            }, Sc.prototype._flush = function(e) {
                var t;
                try {
                    this.push(this.__final())
                } catch (r) {
                    t = r
                }
                e(t)
            }, Sc.prototype._finalOrDigest = function(e) {
                var t = this.__final() || wc.alloc(0);
                return e && (t = this._toString(t, e, !0)), t
            }, Sc.prototype._toString = function(e, t, r) {
                if (this._decoder || (this._decoder = new kc(t), this._encoding = t), this._encoding !== t) throw new Error("can't switch encodings");
                var n = this._decoder.write(e);
                return r && (n += this._decoder.end()), n
            };
            var Ec = Sc,
                Ac = Dr.exports,
                Tc = Fu,
                zc = al,
                Oc = ol.exports,
                Rc = Ec;

            function Pc(e) {
                Rc.call(this, "digest"), this._hash = e
            }
            Ac(Pc, Rc), Pc.prototype._update = function(e) {
                this._hash.update(e)
            }, Pc.prototype._final = function() {
                return this._hash.digest()
            };
            var Nc = function(e) {
                    return "md5" === (e = e.toLowerCase()) ? new Tc : "rmd160" === e || "ripemd160" === e ? new zc : new Pc(Oc(e))
                },
                Dc = null;
            "undefined" != typeof WebSocket ? Dc = WebSocket : "undefined" != typeof MozWebSocket ? Dc = MozWebSocket : void 0 !== t ? Dc = t.WebSocket || t.MozWebSocket : "undefined" != typeof window ? Dc = window.WebSocket || window.MozWebSocket : "undefined" != typeof self && (Dc = self.WebSocket || self.MozWebSocket);
            var Lc = Dc;
            ! function(e) {
                var t = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var r, n = t(fa),
                    i = t(ua.exports),
                    a = t(va.exports),
                    o = t(da.exports),
                    s = t(pa.exports),
                    u = t(_a.exports),
                    l = t(Ea),
                    c = t(Pa),
                    h = t(Nc),
                    f = t(Lc),
                    d = "/socket.io/?EIO=3&transport=websocket",
                    p = null,
                    _ = !1,
                    y = !1,
                    g = [],
                    b = function(e) {
                        return (0, h.default)("sha256").update(e).digest("hex")
                    },
                    v = function() {
                        var e = new Uint8Array(24);
                        return (0, c.default)(e), e.join("")
                    },
                    m = function() {
                        var e;
                        return "www." === (e = "undefined" == typeof location ? r : location.hasOwnProperty("hostname") && location.hostname.length && "localhost" !== location.hostname ? location.hostname : r).substr(0, 4) && (e = e.replace("www.", "")), e
                    },
                    w = l.default.getAppKey();
                w || (w = "appkey:" + v());
                var x = function() {
                        var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : null,
                            t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
                        null === e && null === t ? p.send("40/scatter") : p.send("42/scatter," + JSON.stringify([e, t]))
                    },
                    k = null,
                    S = function() {
                        var e = !!(0 < arguments.length && void 0 !== arguments[0]) && arguments[0];
                        return new Promise((function(t, n) {
                            k = {
                                resolve: t,
                                reject: n
                            }, x("pair", {
                                data: {
                                    appkey: w,
                                    origin: m(),
                                    passthrough: e
                                },
                                plugin: r
                            })
                        }))
                    },
                    E = {},
                    A = function() {
                        function e() {
                            (0, s.default)(this, e)
                        }
                        return (0, u.default)(e, null, [{
                            key: "init",
                            value: function(e) {
                                var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 6e4;
                                r = e, this.timeout = t
                            }
                        }, {
                            key: "getOrigin",
                            value: function() {
                                return m()
                            }
                        }, {
                            key: "addEventHandler",
                            value: function(e, t) {
                                t || (t = "app"), E[t] = e
                            }
                        }, {
                            key: "removeEventHandler",
                            value: function(e) {
                                e || (e = "app"), delete E[e]
                            }
                        }, {
                            key: "link",
                            value: function() {
                                var e = this;
                                return Promise.race([new Promise((function(t) {
                                    return setTimeout((function() {
                                        _ || (t(!1), p && (p.disconnect(), p = null))
                                    }), e.timeout)
                                })), new Promise(function() {
                                    var e = (0, o.default)(n.default.mark((function e(t) {
                                        var o, s;
                                        return n.default.wrap((function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                                case 0:
                                                    return o = function() {
                                                        p.onmessage = function(r) {
                                                            if (-1 === r.data.indexOf("42/scatter")) return !1;
                                                            var i = JSON.parse(r.data.replace("42/scatter,", "")),
                                                                s = (0, a.default)(i, 2),
                                                                u = s[0],
                                                                l = s[1];
                                                            return "paired" === u ? e(l) : "rekey" === u ? t() : "api" === u ? n(l) : "event" === u ? o(l) : void 0
                                                        };
                                                        var e = function(e) {
                                                                if (y = e) {
                                                                    var t = l.default.getAppKey(),
                                                                        r = -1 < w.indexOf("appkey:") ? b(w) : w;
                                                                    t && t === r || (l.default.setAppKey(r), w = l.default.getAppKey())
                                                                }
                                                                k.resolve(e)
                                                            },
                                                            t = function() {
                                                                w = "appkey:" + v(), x("rekeyed", {
                                                                    data: {
                                                                        appkey: w,
                                                                        origin: m()
                                                                    },
                                                                    plugin: r
                                                                })
                                                            },
                                                            n = function(e) {
                                                                var t = g.find((function(t) {
                                                                    return t.id === e.id
                                                                }));
                                                                t && (g = g.filter((function(t) {
                                                                    return t.id !== e.id
                                                                })), "object" === (0, i.default)(e.result) && null !== e.result && e.result.hasOwnProperty("isError") ? t.reject(e.result) : t.resolve(e.result))
                                                            },
                                                            o = function(e) {
                                                                var t = e.event,
                                                                    r = e.payload;
                                                                Object.keys(E).length && Object.keys(E).map((function(e) {
                                                                    E[e](t, r)
                                                                }))
                                                            }
                                                    }, s = function() {
                                                        var e, r = !(0 < arguments.length && void 0 !== arguments[0]) || arguments[0],
                                                            n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
                                                        n || (e = new Promise((function(e) {
                                                            return n = e
                                                        })));
                                                        var i = r ? "local.get-scatter.com:50006" : "127.0.0.1:50005",
                                                            a = r ? "wss://" : "ws://",
                                                            u = "".concat(a).concat(i).concat(d),
                                                            l = new f.default(u);
                                                        return l.onerror = function() {
                                                            r ? s(!1, n) : (t(!1), n(!1))
                                                        }, l.onopen = function() {
                                                            p = l, x(), clearTimeout(null), _ = !0, S(!0).then((function() {
                                                                t(!0), n(!0)
                                                            })), o()
                                                        }, e
                                                    }, e.next = 4, s();
                                                case 4:
                                                case "end":
                                                    return e.stop()
                                            }
                                        }), e, this)
                                    })));
                                    return function() {
                                        return e.apply(this, arguments)
                                    }
                                }())])
                            }
                        }, {
                            key: "isConnected",
                            value: function() {
                                return _
                            }
                        }, {
                            key: "isPaired",
                            value: function() {
                                return y
                            }
                        }, {
                            key: "disconnect",
                            value: function() {
                                return p && p.close(), !0
                            }
                        }, {
                            key: "removeAppKeys",
                            value: function() {
                                l.default.removeAppKey(), l.default.removeNonce()
                            }
                        }, {
                            key: "sendApiRequest",
                            value: function(e) {
                                return new Promise((function(t, n) {
                                    return "identityFromPermissions" !== e.type || y ? void S().then((function() {
                                        if (!y) return n({
                                            code: "not_paired",
                                            message: "The user did not allow this app to connect to their Scatter"
                                        });
                                        e.id = v(), e.appkey = w, e.nonce = l.default.getNonce() || 0;
                                        var i = v();
                                        e.nextNonce = b(i), l.default.setNonce(i), e.hasOwnProperty("payload") && !e.payload.hasOwnProperty("origin") && (e.payload.origin = m()), g.push(Object.assign(e, {
                                            resolve: t,
                                            reject: n
                                        })), x("api", {
                                            data: e,
                                            plugin: r
                                        })
                                    })) : t(!1)
                                }))
                            }
                        }]), e
                    }();
                e.default = A
            }(ba);
            var Uc = {};
            ! function(e) {
                var t = sa.exports,
                    r = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var n = r(pa.exports),
                    i = r(_a.exports),
                    a = t(ga),
                    o = function() {
                        function e() {
                            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
                                r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "";
                            (0, n.default)(this, e), this.name = t, this.type = r
                        }
                        return (0, i.default)(e, [{
                            key: "isSignatureProvider",
                            value: function() {
                                return this.type === a.BLOCKCHAIN_SUPPORT
                            }
                        }, {
                            key: "isValid",
                            value: function() {
                                return Object.keys(a).map((function(e) {
                                    return a[e]
                                })).includes(this.type)
                            }
                        }], [{
                            key: "placeholder",
                            value: function() {
                                return new e
                            }
                        }, {
                            key: "fromJson",
                            value: function(t) {
                                return Object.assign(e.placeholder(), t)
                            }
                        }]), e
                    }();
                e.default = o
            }(Uc);
            var Ic = {};
            ! function(e) {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.BlockchainsArray = e.Blockchains = void 0;
                var t = {
                    EOS: "eos",
                    ETH: "eth",
                    TRX: "trx"
                };
                e.Blockchains = t;
                var r = Object.keys(t).map((function(e) {
                    return {
                        key: e,
                        value: t[e]
                    }
                }));
                e.BlockchainsArray = r
            }(Ic);
            var Bc = {},
                jc = {};
            ! function(e) {
                var t = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var r = t(pa.exports),
                    n = t(_a.exports),
                    i = Ic,
                    a = function() {
                        function e() {
                            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : i.Blockchains.EOS,
                                n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "",
                                a = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "",
                                o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null,
                                s = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : null;
                            (0, r.default)(this, e), this.blockchain = t, this.contract = n, this.symbol = a, this.name = o || a, this.decimals = s
                        }
                        return (0, n.default)(e, null, [{
                            key: "placeholder",
                            value: function() {
                                return new e
                            }
                        }, {
                            key: "fromJson",
                            value: function(e) {
                                return Object.assign(this.placeholder(), e)
                            }
                        }]), e
                    }();
                e.default = a
            }(jc),
            function(e) {
                var t = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var r = t(pa.exports),
                    n = t(_a.exports),
                    i = Ic,
                    a = t(jc),
                    o = function() {
                        function e() {
                            var t = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
                                n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "https",
                                a = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "",
                                o = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : 0,
                                s = 4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : i.Blockchains.EOS,
                                u = 5 < arguments.length && void 0 !== arguments[5] ? arguments[5] : "";
                            (0, r.default)(this, e), this.name = t, this.protocol = n, this.host = a, this.port = o, this.blockchain = s, this.chainId = u.toString(), this.token = null
                        }
                        return (0, n.default)(e, [{
                            key: "fullhost",
                            value: function() {
                                return "".concat(this.protocol, "://").concat(this.host).concat(this.port ? ":" : "").concat(this.port)
                            }
                        }, {
                            key: "unique",
                            value: function() {
                                return ("".concat(this.blockchain, ":") + (this.chainId.length ? "chain:".concat(this.chainId) : "".concat(this.host, ":").concat(this.port))).toLowerCase()
                            }
                        }], [{
                            key: "placeholder",
                            value: function() {
                                return new e
                            }
                        }, {
                            key: "fromJson",
                            value: function(t) {
                                var r = Object.assign(e.placeholder(), t);
                                return r.chainId = r.chainId ? r.chainId.toString() : "", r.token = t.hasOwnProperty("token") && t.token ? a.default.fromJson(t.token) : null, r
                            }
                        }]), e
                    }();
                e.default = o
            }(Bc);
            var Mc = {};
            ! function(e) {
                var t = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = e.WALLET_METHODS = void 0;
                var r, n = t(pa.exports),
                    i = t(_a.exports),
                    a = t(o.exports),
                    s = {
                        disconnect: "disconnect",
                        isConnected: "isConnected",
                        isPaired: "isPaired",
                        addEventHandler: "addEventHandler",
                        removeEventHandler: "removeEventHandler",
                        listen: "listen",
                        getVersion: "getVersion",
                        getIdentity: "getIdentity",
                        getIdentityFromPermissions: "getIdentityFromPermissions",
                        forgetIdentity: "forgetIdentity",
                        updateIdentity: "updateIdentity",
                        authenticate: "authenticate",
                        getArbitrarySignature: "getArbitrarySignature",
                        getPublicKey: "getPublicKey",
                        linkAccount: "linkAccount",
                        hasAccountFor: "hasAccountFor",
                        suggestNetwork: "suggestNetwork",
                        requestTransfer: "requestTransfer",
                        requestSignature: "requestSignature",
                        createTransaction: "createTransaction",
                        addToken: "addToken"
                    };
                e.WALLET_METHODS = s;
                var u = (r = {}, (0, a.default)(r, s.getIdentity, "login"), (0, a.default)(r, s.forgetIdentity, "logout"), (0, a.default)(r, s.getIdentityFromPermissions, "checkLogin"), r),
                    l = function() {
                        function e(t, r, i) {
                            (0, n.default)(this, e);
                            var a = function(e) {
                                return function() {
                                    throw console.error("".concat(t, " does not support the ").concat(e, " method.")), new Error("".concat(t, " does not support the ").concat(e, " method."))
                                }
                            };
                            Object.keys(s).map((function(e) {
                                return function(e, t) {
                                    void 0 === i[t] && (i[t] = e || a(t)), u[t] && void 0 === i[u[t]] && (i[u[t]] = i[t] ? i[t] : a(t))
                                }(r[e], e)
                            }))
                        }
                        return (0, i.default)(e, null, [{
                            key: "bindBasics",
                            value: function(e) {
                                e.account = function(t) {
                                    return e.identity && e.identity.accounts ? e.identity.accounts.find((function(e) {
                                        return e.blockchain === t
                                    })) : void 0
                                }
                            }
                        }]), e
                    }();
                e.default = l
            }(Mc);
            var Cc = {},
                Fc = {
                    exports: {}
                },
                Hc = {
                    exports: {}
                };
            ! function(e) {
                e.exports = function(e) {
                    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                    return e
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(Hc),
            function(e) {
                var t = ua.exports.default,
                    r = Hc.exports;
                e.exports = function(e, n) {
                    if (n && ("object" === t(n) || "function" == typeof n)) return n;
                    if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                    return r(e)
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(Fc);
            var Kc = {
                exports: {}
            };
            ! function(e) {
                function t(r) {
                    return e.exports = t = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                        return e.__proto__ || Object.getPrototypeOf(e)
                    }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r)
                }
                e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
            }(Kc);
            var Wc = {
                    exports: {}
                },
                qc = {
                    exports: {}
                };
            ! function(e) {
                function t(r, n) {
                    return e.exports = t = Object.setPrototypeOf || function(e, t) {
                        return e.__proto__ = t, e
                    }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r, n)
                }
                e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
            }(qc),
            function(e) {
                var t = qc.exports;
                e.exports = function(e, r) {
                    if ("function" != typeof r && null !== r) throw new TypeError("Super expression must either be null or a function");
                    e.prototype = Object.create(r && r.prototype, {
                        constructor: {
                            value: e,
                            writable: !0,
                            configurable: !0
                        }
                    }), Object.defineProperty(e, "prototype", {
                        writable: !1
                    }), r && t(e, r)
                }, e.exports.__esModule = !0, e.exports.default = e.exports
            }(Wc),
            function(e) {
                var t = sa.exports,
                    r = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var n = r(o.exports),
                    i = r(fa),
                    a = r(da.exports),
                    s = r(pa.exports),
                    u = r(_a.exports),
                    l = r(Fc.exports),
                    c = r(Kc.exports),
                    h = r(Wc.exports),
                    f = r(Uc),
                    d = Ic,
                    p = t(ga),
                    _ = r(ba),
                    y = oa,
                    g = function(e) {
                        function t(e, r) {
                            var n;
                            return (0, s.default)(this, t), (n = (0, l.default)(this, (0, c.default)(t).call(this, d.Blockchains.EOS, p.WALLET_SUPPORT))).name = "ScatterSockets", n.context = e, n.holderFns = r, n
                        }
                        return (0, h.default)(t, e), (0, u.default)(t, [{
                            key: "connect",
                            value: function(e) {
                                var t = this,
                                    r = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {};
                                return new Promise((function(n) {
                                    if (!e || !e.length) throw new Error("You must specify a name for this connection");
                                    r = Object.assign({
                                        initTimeout: 1e4,
                                        linkTimeout: 3e4
                                    }, r), _.default.init(e, r.linkTimeout), _.default.link().then(function() {
                                        var e = (0, a.default)(i.default.mark((function e(r) {
                                            return i.default.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        if (r) {
                                                            e.next = 2;
                                                            break
                                                        }
                                                        return e.abrupt("return", !1);
                                                    case 2:
                                                        return t.holderFns.get().isExtension = !1, t.holderFns.get().wallet || (t.holderFns.get().wallet = t.name), e.abrupt("return", n(!0));
                                                    case 5:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e, this)
                                        })));
                                        return function() {
                                            return e.apply(this, arguments)
                                        }
                                    }())
                                }))
                            }
                        }, {
                            key: "runAfterInterfacing",
                            value: function() {
                                var e = (0, a.default)(i.default.mark((function e() {
                                    var t = this;
                                    return i.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return this.holderFns.get().addEventHandler((function(e, r) {
                                                    return t.eventHandler(e, r)
                                                }), "internal"), e.next = 3, this.holderFns.get().getIdentityFromPermissions();
                                            case 3:
                                                return this.holderFns.get().identity = e.sent, e.abrupt("return", !0);
                                            case 5:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }, {
                            key: "methods",
                            value: function() {
                                var e, t = this,
                                    r = function(e, r) {
                                        return (e || r) && (t.holderFns.get().identity = e), r || e
                                    };
                                return e = {}, (0, n.default)(e, y.WALLET_METHODS.disconnect, (function() {
                                    return _.default.disconnect()
                                })), (0, n.default)(e, y.WALLET_METHODS.isConnected, (function() {
                                    return _.default.isConnected()
                                })), (0, n.default)(e, y.WALLET_METHODS.isPaired, (function() {
                                    return _.default.isPaired()
                                })), (0, n.default)(e, y.WALLET_METHODS.addEventHandler, (function(e) {
                                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null;
                                    return _.default.addEventHandler(e, t)
                                })), (0, n.default)(e, y.WALLET_METHODS.removeEventHandler, (function() {
                                    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : null;
                                    return _.default.removeEventHandler(e)
                                })), (0, n.default)(e, y.WALLET_METHODS.listen, (function(e) {
                                    return _.default.addEventHandler(e)
                                })), (0, n.default)(e, y.WALLET_METHODS.getVersion, (function() {
                                    return _.default.sendApiRequest({
                                        type: "getVersion",
                                        payload: {}
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.getIdentity, (function(e) {
                                    return _.default.sendApiRequest({
                                        type: "getOrRequestIdentity",
                                        payload: {
                                            fields: e || {
                                                accounts: [t.holderFns.get().network]
                                            }
                                        }
                                    }).then(r)
                                })), (0, n.default)(e, y.WALLET_METHODS.getIdentityFromPermissions, (function() {
                                    return _.default.sendApiRequest({
                                        type: "identityFromPermissions",
                                        payload: {}
                                    }).then(r)
                                })), (0, n.default)(e, y.WALLET_METHODS.forgetIdentity, (function() {
                                    return _.default.sendApiRequest({
                                        type: "forgetIdentity",
                                        payload: {}
                                    }).then((function(e) {
                                        return r(null, e)
                                    }))
                                })), (0, n.default)(e, y.WALLET_METHODS.updateIdentity, (function(e) {
                                    var t = e.name,
                                        n = e.kyc;
                                    return _.default.sendApiRequest({
                                        type: "updateIdentity",
                                        payload: {
                                            name: t,
                                            kyc: n
                                        }
                                    }).then((function(e) {
                                        return e ? r(e) : null
                                    }))
                                })), (0, n.default)(e, y.WALLET_METHODS.authenticate, (function(e) {
                                    var t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : null,
                                        r = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
                                    return _.default.sendApiRequest({
                                        type: "authenticate",
                                        payload: {
                                            nonce: e,
                                            data: t,
                                            publicKey: r
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.getArbitrarySignature, (function(e, t) {
                                    return _.default.sendApiRequest({
                                        type: "requestArbitrarySignature",
                                        payload: {
                                            publicKey: e,
                                            data: t
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.getPublicKey, (function(e) {
                                    return _.default.sendApiRequest({
                                        type: "getPublicKey",
                                        payload: {
                                            blockchain: e
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.linkAccount, (function(e, r) {
                                    return _.default.sendApiRequest({
                                        type: "linkAccount",
                                        payload: {
                                            account: e,
                                            network: r || t.holderFns.get().network
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.hasAccountFor, (function(e) {
                                    return _.default.sendApiRequest({
                                        type: "hasAccountFor",
                                        payload: {
                                            network: e || t.holderFns.get().network
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.suggestNetwork, (function(e) {
                                    return _.default.sendApiRequest({
                                        type: "requestAddNetwork",
                                        payload: {
                                            network: e || t.holderFns.get().network
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.requestTransfer, (function(e, r, n) {
                                    var i = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {};
                                    return _.default.sendApiRequest({
                                        type: "requestTransfer",
                                        payload: {
                                            network: e || t.holderFns.get().network,
                                            to: r,
                                            amount: n,
                                            options: i
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.requestSignature, (function(e) {
                                    return _.default.sendApiRequest({
                                        type: "requestSignature",
                                        payload: e
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.createTransaction, (function(e, r, n, i) {
                                    return _.default.sendApiRequest({
                                        type: "createTransaction",
                                        payload: {
                                            blockchain: e,
                                            actions: r,
                                            account: n,
                                            network: i || t.holderFns.get().network
                                        }
                                    })
                                })), (0, n.default)(e, y.WALLET_METHODS.addToken, (function(e, r) {
                                    return _.default.sendApiRequest({
                                        type: "addToken",
                                        payload: {
                                            token: e,
                                            network: r || t.holderFns.get().network
                                        }
                                    })
                                })), e
                            }
                        }, {
                            key: "eventHandler",
                            value: function() {
                                var e = (0, a.default)(i.default.mark((function e(t) {
                                    return i.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                e.t0 = t, e.next = e.t0 === y.EVENTS.Disconnected ? 3 : e.t0 === y.EVENTS.LoggedOut ? 5 : 9;
                                                break;
                                            case 3:
                                                return this.holderFns.get().identity = null, e.abrupt("break", 9);
                                            case 5:
                                                return e.next = 7, this.holderFns.get().getIdentityFromPermissions();
                                            case 7:
                                                return this.holderFns.get().identity = e.sent, e.abrupt("break", 9);
                                            case 9:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }]), t
                    }(f.default);
                e.default = g
            }(Cc);
            var Zc = {};
            ! function(e) {
                var t = sa.exports,
                    r = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var n = r(o.exports),
                    i = r(pa.exports),
                    a = r(_a.exports),
                    s = r(Fc.exports),
                    u = r(Kc.exports),
                    l = r(Wc.exports),
                    c = r(fa),
                    h = r(da.exports),
                    f = t(ga),
                    d = r(Uc),
                    p = Ic,
                    _ = t(Mc);
                r(ba);
                var y = !1;
                "undefined" != typeof window && "undefined" != typeof document && (void 0 === window.scatter ? document.addEventListener("scatterLoaded", (function() {
                    return y = !0
                })) : y = !0);
                var g = function() {
                        var e = (0, h.default)(c.default.mark((function e() {
                            var t, r, n = arguments;
                            return c.default.wrap((function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return t = 0 < n.length && void 0 !== n[0] ? n[0] : null, r = 1 < n.length && void 0 !== n[1] ? n[1] : 0, e.abrupt("return", new Promise((function(e) {
                                            return t || (t = e), y ? t(!0) : 5 < r ? t(!1) : void setTimeout((function() {
                                                return g(t, r + 1)
                                            }), 100)
                                        })));
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, this)
                        })));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }(),
                    b = function(e) {
                        function t(e, r) {
                            var n;
                            return (0, i.default)(this, t), (n = (0, s.default)(this, (0, u.default)(t).call(this, p.Blockchains.EOS, f.WALLET_SUPPORT))).name = "ScatterExtension", n.context = e, n.holderFns = r, n
                        }
                        return (0, l.default)(t, e), (0, a.default)(t, [{
                            key: "connect",
                            value: function() {
                                var e = (0, h.default)(c.default.mark((function e() {
                                    var t = this;
                                    return c.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return e.abrupt("return", new Promise(function() {
                                                    var e = (0, h.default)(c.default.mark((function e(r) {
                                                        return c.default.wrap((function(e) {
                                                            for (;;) switch (e.prev = e.next) {
                                                                case 0:
                                                                    return e.next = 2, g();
                                                                case 2:
                                                                    e.sent && (!t.holderFns.get().wallet && (t.holderFns.get().wallet = t.name), r(!0));
                                                                case 4:
                                                                case "end":
                                                                    return e.stop()
                                                            }
                                                        }), e, this)
                                                    })));
                                                    return function() {
                                                        return e.apply(this, arguments)
                                                    }
                                                }()));
                                            case 1:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }, {
                            key: "runBeforeInterfacing",
                            value: function() {
                                var e = (0, h.default)(c.default.mark((function e() {
                                    var t, r, n, i, a = this;
                                    return c.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return (t = this.context.network) && (r = window.scatter.getIdentity.bind(window.scatter), n = window.scatter.useIdentity.bind(window.scatter), window.scatter.getIdentity = function(e) {
                                                    return r(e || {
                                                        accounts: [t]
                                                    }).then((function(e) {
                                                        return a.holderFns.get().identity = e, n(e), e
                                                    }))
                                                }, i = window.scatter.suggestNetwork.bind(window.scatter), window.scatter.suggestNetwork = function(e) {
                                                    return i(e || t)
                                                }), this.holderFns.get().wallet === this.name && (window.scatter.wallet = this.name), this.holderFns.set(window.scatter), this.context = this.holderFns.get(), e.abrupt("return", !0);
                                            case 6:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }, {
                            key: "runAfterInterfacing",
                            value: function() {
                                var e = (0, h.default)(c.default.mark((function e() {
                                    return c.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return this.context.isExtension = !0, this.context.connect = this.connect, e.abrupt("return", !0);
                                            case 3:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }, {
                            key: "methods",
                            value: function() {
                                return (0, n.default)({}, _.WALLET_METHODS.getIdentity, (function() {
                                    console.log("getid")
                                }))
                            }
                        }]), t
                    }(d.default);
                e.default = b
            }(Zc),
            function(e) {
                var t = sa.exports,
                    r = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), Object.defineProperty(e, "SocketService", {
                    enumerable: !0,
                    get: function() {
                        return u.default
                    }
                }), Object.defineProperty(e, "Plugin", {
                    enumerable: !0,
                    get: function() {
                        return l.default
                    }
                }), Object.defineProperty(e, "Blockchains", {
                    enumerable: !0,
                    get: function() {
                        return h.Blockchains
                    }
                }), Object.defineProperty(e, "Network", {
                    enumerable: !0,
                    get: function() {
                        return f.default
                    }
                }), Object.defineProperty(e, "WalletInterface", {
                    enumerable: !0,
                    get: function() {
                        return d.default
                    }
                }), Object.defineProperty(e, "WALLET_METHODS", {
                    enumerable: !0,
                    get: function() {
                        return d.WALLET_METHODS
                    }
                }), e.PluginTypes = e.default = e.EVENTS = void 0;
                var n = r(fa),
                    i = r(da.exports),
                    a = r(pa.exports),
                    o = r(_a.exports),
                    s = r(ya),
                    u = r(ba),
                    l = r(Uc),
                    c = t(ga);
                e.PluginTypes = c;
                var h = Ic,
                    f = r(Bc),
                    d = t(Mc),
                    p = r(Cc),
                    _ = r(Zc),
                    y = r(jc),
                    g = {
                        Disconnected: "dced",
                        LoggedOut: "logout"
                    };
                e.EVENTS = g, u.default;
                var b = [],
                    v = {},
                    m = function() {
                        function e() {
                            (0, a.default)(this, e), this.identity = null, this.network = null, s.default.loadPlugin(new p.default(this, v)), s.default.loadPlugin(new _.default(this, v))
                        }
                        return (0, o.default)(e, [{
                            key: "loadPlugin",
                            value: function(e) {
                                if (!e.isValid()) throw new Error("".concat(e.name, " doesn't seem to be a valid ScatterJS plugin."));
                                s.default.loadPlugin(e), e.type === c.BLOCKCHAIN_SUPPORT && (this[e.name] = e.signatureProvider((function() {
                                    if (!v.get().identity) throw new Error("No Identity")
                                }), (function() {
                                    return v.get().identity
                                })), this[e.name + "Hook"] = e.hookProvider, b.push(e.setSocketService)), e.type === c.WALLET_SUPPORT && e.init(this, v, b)
                            }
                        }, {
                            key: "connect",
                            value: function() {
                                var e = (0, i.default)(n.default.mark((function e(t, r) {
                                    var a;
                                    return n.default.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return r || (r = {}), this.network = r.hasOwnProperty("network") ? r.network : null, a = s.default.wallets(), e.next = 5, Promise.race(a.map((function(e) {
                                                    return e.connect(t, r).then((0, i.default)(n.default.mark((function t() {
                                                        return n.default.wrap((function(t) {
                                                            for (;;) switch (t.prev = t.next) {
                                                                case 0:
                                                                    if ("function" != typeof e.runBeforeInterfacing) {
                                                                        t.next = 3;
                                                                        break
                                                                    }
                                                                    return t.next = 3, e.runBeforeInterfacing();
                                                                case 3:
                                                                    if (new d.default(e.name, e.methods(), v.get()), "function" != typeof e.runAfterInterfacing) {
                                                                        t.next = 7;
                                                                        break
                                                                    }
                                                                    return t.next = 7, e.runAfterInterfacing();
                                                                case 7:
                                                                    return d.default.bindBasics(v.get()), t.abrupt("return", !0);
                                                                case 9:
                                                                case "end":
                                                                    return t.stop()
                                                            }
                                                        }), t, this)
                                                    }))))
                                                })).concat(new Promise((function(e) {
                                                    return setTimeout((function() {
                                                        return e(!1)
                                                    }), r.initTimeout || 5e3)
                                                }))));
                                            case 5:
                                                return e.abrupt("return", e.sent);
                                            case 6:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                })));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }]), e
                    }(),
                    w = function() {
                        function e(t) {
                            (0, a.default)(this, e), this.scatter = t
                        }
                        return (0, o.default)(e, [{
                            key: "plugins",
                            value: function() {
                                var e = this;
                                if (!this.scatter.isExtension) {
                                    for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                                    r.map((function(t) {
                                        return e.scatter.loadPlugin(t)
                                    }))
                                }
                            }
                        }, {
                            key: "connect",
                            value: function() {
                                var e;
                                return (e = this.scatter).connect.apply(e, arguments)
                            }
                        }, {
                            key: "catchAll",
                            value: function() {}
                        }]), e
                    }(),
                    x = new Proxy(new w(new m), {
                        get: function(e, t) {
                            return void 0 === e[t] ? e.scatter[t] : e[t]
                        }
                    });
                v.set = function(e) {
                    return x.scatter = e
                }, v.get = function() {
                    return x.scatter
                }, "undefined" != typeof window && (window.ScatterJS = x), x.Plugin = l.default, x.PluginTypes = c, x.Blockchains = h.Blockchains, x.Network = f.default, x.Token = y.default, x.SocketService = u.default, x.EVENTS = g, x.WalletInterface = d.default, x.WALLET_METHODS = d.WALLET_METHODS;
                var k = x;
                e.default = k
            }(oa);
            var Vc = r(oa),
                Gc = {};
            ! function(e) {
                var t = ca.exports;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.default = void 0;
                var r = t(fa),
                    n = t(da.exports),
                    i = t(pa.exports),
                    a = t(_a.exports),
                    o = t(Fc.exports),
                    s = t(Kc.exports),
                    u = t(Wc.exports),
                    l = oa,
                    c = l.SocketService,
                    h = function(e, t) {
                        return new Proxy(e, t)
                    },
                    f = function(e) {
                        function t() {
                            return (0, i.default)(this, t), (0, o.default)(this, (0, s.default)(t).call(this, l.Blockchains.EOS, l.PluginTypes.BLOCKCHAIN_SUPPORT))
                        }
                        return (0, u.default)(t, e), (0, a.default)(t, [{
                            key: "setSocketService",
                            value: function(e) {
                                c = e
                            }
                        }, {
                            key: "hookProvider",
                            value: function(e) {
                                return function(t) {
                                    return new Promise((function(r, n) {
                                        var i = Object.assign(t, {
                                            blockchain: l.Blockchains.EOS,
                                            network: e,
                                            requiredFields: {}
                                        });
                                        c.sendApiRequest({
                                            type: "requestSignature",
                                            payload: i
                                        }).then((function(e) {
                                            return r(e.signatures)
                                        })).catch((function(e) {
                                            return n(e)
                                        }))
                                    }))
                                }
                            }
                        }, {
                            key: "signatureProvider",
                            value: function() {
                                var e = 0 >= arguments.length ? void 0 : arguments[0];
                                return function(t, i) {
                                    var a, o = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {},
                                        s = (t = l.Network.fromJson(t)).hasOwnProperty("chainId") && t.chainId.length ? t.chainId : o.chainId,
                                        u = function() {
                                            var e = (0, n.default)(r.default.mark((function e(t) {
                                                return r.default.wrap((function(e) {
                                                    for (;;) switch (e.prev = e.next) {
                                                        case 0:
                                                            return e.abrupt("return", a(t));
                                                        case 1:
                                                        case "end":
                                                            return e.stop()
                                                    }
                                                }), e, this)
                                            })));
                                            return function() {
                                                return e.apply(this, arguments)
                                            }
                                        }();
                                    return h(i({
                                        httpEndpoint: t.fullhost(),
                                        chainId: s,
                                        signProvider: u
                                    }), {
                                        get: function(i, o) {
                                            if ("function" != typeof i[o]) return i[o];
                                            var s = null;
                                            return function() {
                                                for (var u = arguments.length, f = Array(u), d = 0; d < u; d++) f[d] = arguments[d];
                                                if (f.find((function(e) {
                                                        return e.hasOwnProperty("keyProvider")
                                                    }))) throw Error.usedKeyProvider();
                                                return a = function() {
                                                    var i = (0, n.default)(r.default.mark((function n(i) {
                                                        var a, o, u, h;
                                                        return r.default.wrap((function(r) {
                                                            for (;;) switch (r.prev = r.next) {
                                                                case 0:
                                                                    return e(), a = f.find((function(e) {
                                                                        return e.hasOwnProperty("requiredFields")
                                                                    })) || {
                                                                        requiredFields: {}
                                                                    }, o = Object.assign(i, {
                                                                        blockchain: l.Blockchains.EOS,
                                                                        network: t,
                                                                        requiredFields: a.requiredFields
                                                                    }), r.next = 5, c.sendApiRequest({
                                                                        type: "requestSignature",
                                                                        payload: o
                                                                    });
                                                                case 5:
                                                                    if (u = r.sent) {
                                                                        r.next = 8;
                                                                        break
                                                                    }
                                                                    return r.abrupt("return", null);
                                                                case 8:
                                                                    if (!u.hasOwnProperty("signatures")) {
                                                                        r.next = 13;
                                                                        break
                                                                    }
                                                                    return s = u.returnedFields, h = f.find((function(e) {
                                                                        return e.hasOwnProperty("signProvider")
                                                                    })), h && u.signatures.push(h.signProvider(i.buf, i.sign)), r.abrupt("return", u.signatures);
                                                                case 13:
                                                                    return r.abrupt("return", u);
                                                                case 14:
                                                                case "end":
                                                                    return r.stop()
                                                            }
                                                        }), n, this)
                                                    })));
                                                    return function() {
                                                        return i.apply(this, arguments)
                                                    }
                                                }(), new Promise((function(e, t) {
                                                    i[o].apply(i, f).then((function(t) {
                                                        return t.hasOwnProperty("fc") ? void e(h(t, {
                                                            get: function(e, t) {
                                                                return "then" === t ? e[t] : function() {
                                                                    for (var i = arguments.length, a = Array(i), o = 0; o < i; o++) a[o] = arguments[o];
                                                                    return new Promise(function() {
                                                                        var i = (0, n.default)(r.default.mark((function n(i, o) {
                                                                            return r.default.wrap((function(r) {
                                                                                for (;;) switch (r.prev = r.next) {
                                                                                    case 0:
                                                                                        e[t].apply(e, a).then((function(e) {
                                                                                            i(Object.assign(e, {
                                                                                                returnedFields: s
                                                                                            }))
                                                                                        })).catch(o);
                                                                                    case 1:
                                                                                    case "end":
                                                                                        return r.stop()
                                                                                }
                                                                            }), n, this)
                                                                        })));
                                                                        return function() {
                                                                            return i.apply(this, arguments)
                                                                        }
                                                                    }())
                                                                }
                                                            }
                                                        })) : e(Object.assign(t, {
                                                            returnedFields: s
                                                        }))
                                                    })).catch(t)
                                                }))
                                            }
                                        }
                                    })
                                }
                            }
                        }]), t
                    }(l.Plugin);
                e.default = f, "undefined" != typeof window && (window.ScatterEOS = f)
            }(Gc);
            var Jc = r(Gc);
            let Yc, $c;
            Vc.plugins(new Jc);
            const Qc = {
                    blockchain: "eos",
                    chainId: "aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906",
                    host: "nodes.get-scatter.com",
                    port: 443,
                    protocol: "https"
                },
                Xc = e("connect", (async () => {
                    if (Yc) return Yc;
                    if (Yc = await Vc.connect(location.host, {
                            network: Qc
                        }), !Yc) throw new Error("Scatter connect error!");
                    return Yc
                })),
                eh = e("getScatter", (async () => $c || (await Xc(), $c = Vc.scatter, await Vc.login({
                    accounts: [Qc]
                }), $c))),
                th = e("getAccount", (async (e = "eos") => (await rh()).find((t => t.blockchain === e)))),
                rh = e("getAccounts", (async () => {
                    let e = await eh();
                    return e.identity.accounts || await e.getIdentity({
                        accounts: [Qc]
                    }), e.identity.accounts
                }));
            e("transaction", (async (e, t, r, n = "EOS") => {
                let i = await eh(),
                    a = await th(),
                    o = i.eos(Qc, aa, {
                        expireInSeconds: 60
                    }),
                    s = {
                        authorization: [`${a.name}@${a.authority}`]
                    };
                return await o.transfer(a.name, e, `${t.toFixed(4)} ${n}`, r, s)
            })), e("sign", (async (e, t = "") => {
                let r = await eh(),
                    n = r.identity.publicKey;
                return {
                    signature: await r.getArbitrarySignature(n, e, t, !1),
                    publicAddress: n
                }
            }))
        }
    }
}));
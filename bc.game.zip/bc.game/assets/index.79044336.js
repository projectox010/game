var We = Object.defineProperty;
var he = Object.getOwnPropertySymbols;
var Fe = Object.prototype.hasOwnProperty,
    Oe = Object.prototype.propertyIsEnumerable;
var ge = (a, t, s) => t in a ? We(a, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : a[t] = s,
    ve = (a, t) => {
        for (var s in t || (t = {})) Fe.call(t, s) && ge(a, s, t[s]);
        if (he)
            for (var s of he(t)) Oe.call(t, s) && ge(a, s, t[s]);
        return a
    };
import {
    a as e,
    l as le,
    u as w,
    ao as xe,
    r as p,
    j as n,
    p as R,
    A as I,
    s as U,
    aR as T,
    E as Ue,
    G as A,
    d as N,
    e as Q,
    K as ae,
    aS as Qe,
    J as y,
    aT as P,
    P as me,
    $ as _,
    a3 as de,
    S as z,
    y as O,
    F as J,
    aU as He,
    aV as Xe,
    k as fe,
    aH as $e,
    o as M,
    D as q,
    X as Ge,
    Y as Je,
    Z as je,
    b as S,
    _ as Ve,
    v as Ye,
    a0 as ze,
    a1 as qe,
    a5 as j,
    ax as Ke,
    M as Ne,
    aO as Be,
    t as W,
    q as f,
    aP as ie,
    aW as Ze,
    I as te,
    m as re,
    aX as ce,
    aA as oe,
    aY as be,
    aZ as Se,
    a_ as _e,
    am as Re,
    c as se,
    n as ne,
    a$ as et,
    a7 as tt,
    z as nt,
    ab as at,
    aE as st,
    C as it,
    aB as Ae,
    b0 as rt
} from "./index.28e31dff.js";
import {
    C as Y
} from "./index.65304255.js";
import {
    r as ct
} from "./recaptcha.94966f3c.js";
import {
    B as ot
} from "./Status.3214655e.js";
import {
    M as lt,
    B as $
} from "./Achieve.65f39bc0.js";
import {
    b as pa
} from "./Achieve.65f39bc0.js";
import {
    a as dt
} from "./DepositBonus.c3043053.js";
import {
    default as ga
} from "./index.cfa2dfdf.js";
import "./ParticleLayer.e2a68149.js";
import "./usePixiGsap.bf451f35.js";
const Le = function({
        active: t,
        length: s,
        className: c,
        onJump: r
    }) {
        return e("div", {
            className: le(mt, c),
            children: new Array(s).fill(null).map((i, m) => e("div", {
                className: le("pgs-item", t === m && "active"),
                onClick: () => {
                    !r || r(m)
                }
            }, m))
        })
    },
    mt = "psy2wg8";
const ut = function() {
        const t = w(),
            [s, c] = xe({
                url: "",
                dataURL: "",
                blobURL: "",
                link: ""
            }),
            r = "invite.png",
            i = T.shareBg,
            m = () => {
                try {
                    Ue(s.link), A(t("common.messages.copy_success"))
                } catch (d) {
                    A(d)
                }
            },
            l = async () => {
                try {
                    const d = await N.getInviteUrl();
                    c({
                        link: d.invitationUrl
                    })
                } catch (d) {
                    A(d)
                }
            },
            o = d => {
                window.open(d)
            };
        return p.exports.useEffect(() => {
            l()
        }, []), e("div", {
            className: pt,
            children: n("div", {
                className: "coin-invite-img",
                children: [e("img", {
                    alt: "",
                    src: i
                }), e("div", {
                    className: "coindrop-close",
                    onClick: () => R.close(),
                    children: e(I, {
                        name: "Close"
                    })
                }), n("div", {
                    className: "btn-wrap",
                    onClick: () => R.close(),
                    children: [e("button", {
                        onClick: m,
                        children: t("page.user.copy_invite")
                    }), U.isIOS ? e("button", {
                        onClick: () => o(i),
                        children: t("page.user.down_invite")
                    }) : e("a", {
                        target: "_blank",
                        rel: "noopener noreferrer",
                        href: i,
                        download: r,
                        children: e("button", {
                            children: t("page.user.down_invite")
                        })
                    })]
                })]
            })
        })
    },
    pt = "c1j27d2";

function ht(a) {
    return _.post("/game/support/red-packet/get-log/", {
        page: 1,
        pageSize: 100,
        id: a
    }).then(t => t.list.map(s => (s.amount = Number(s.amount), s)))
}
const gt = function({
        info: t,
        total: s,
        totalamount: c
    }) {
        const r = w(),
            [i, m] = p.exports.useState(null),
            l = me();
        return p.exports.useEffect(() => {
            ht(t.id).then(o => {
                l() && m(o)
            }).catch(A)
        }, []), i ? n("div", {
            id: "receive-wrap",
            children: [e("div", {
                className: "invite-btn",
                children: e("button", {
                    onClick: () => R.push(e(ut, {})),
                    children: r("page.coindrop.inviteFriends")
                })
            }), n("div", {
                className: "receive-desc",
                children: ["Opend ", i.length, "/", s]
            }), e(z, {
                className: "receive-list",
                children: i.map((o, d) => n("div", {
                    className: "receive-item",
                    children: [n("div", {
                        className: "user-info",
                        children: [e(ae, {
                            userId: o.userId,
                            name: o.userName
                        }), n("div", {
                            className: "name-time",
                            children: [e("div", {
                                className: "user-name",
                                children: o.userName
                            }), e("div", {
                                className: "user-time",
                                children: new Date(o.createTime).toLocaleString()
                            })]
                        })]
                    }), n("div", {
                        className: "rec-amount",
                        children: [e("div", {
                            className: "user-amount",
                            children: new O(o.amount).toFixed(8)
                        }), e("div", {
                            className: "user-currency",
                            children: y.getAlias(o.currencyName)
                        })]
                    })]
                }, d))
            })]
        }) : e(de, {})
    },
    vt = a => a.toFixed(8),
    ft = ({
        state: a
    }) => {
        const t = w(),
            s = Q(),
            c = a.info;
        return c ? n("div", {
            className: Nt,
            children: [n("div", {
                className: "banner",
                children: [n("div", {
                    className: "user-head",
                    children: [e(ae, {
                        userId: a.userId,
                        name: a.username
                    }), n("div", {
                        className: "user-dcont",
                        children: [e("p", {
                            children: t("page.coindrop.coinDropsFrom")
                        }), e("p", {
                            className: "name",
                            children: a.username
                        })]
                    })]
                }), n("div", {
                    className: "user-cont",
                    children: [e("img", {
                        className: "star",
                        alt: "star",
                        src: T.star
                    }), e("span", {
                        children: c.content
                    }), e("img", {
                        className: "star",
                        alt: "star",
                        src: T.star
                    })]
                }), c.receiverAmount > 0 && n("div", {
                    className: "mid-area receive-amount",
                    children: [n("div", {
                        className: "amount-wrap",
                        children: [e(Qe, {
                            className: "amount-num",
                            format: vt,
                            children: c.receiverAmount
                        }), e("span", {
                            className: "amount-currency",
                            children: y.getAlias(c.currencyName)
                        })]
                    }), n("div", {
                        className: "go-wallet",
                        onClick: () => {
                            R.close(), s(`/transactions/bill/${c.currencyName}`)
                        },
                        children: [t("page.coindrop.coinDropsToWallet"), " >>"]
                    })]
                }), a.status === P.COMPLETED && n("div", {
                    className: "mid-area empty-amount",
                    children: [e("img", {
                        alt: "empty_img",
                        src: T.parachuteFall
                    }), n("p", {
                        children: [t("page.coindrop.completeCoinDrop"), "."]
                    })]
                }), (a.status === P.EXPIRED || a.status === P.ISSUS) && n("div", {
                    className: "mid-area empty-amount",
                    children: [e("img", {
                        alt: "empty_img",
                        src: T.parachuteFall
                    }), n("p", {
                        children: [t("page.coindrop.expiredCoinDrop"), "."]
                    })]
                })]
            }), e(gt, {
                info: c,
                total: c.number,
                totalamount: c.amount
            })]
        }) : null
    },
    Nt = "lpsodm";
const bt = function({
    info: t,
    packageKey: s,
    username: c,
    status: r,
    onReceive: i,
    userId: m,
    level: l
}) {
    var E;
    const [o, d] = xe(() => ({
        userId: m,
        username: c,
        status: r,
        level: l,
        loading: !1,
        showList: !1,
        opened: !1,
        info: void 0
    })), k = me();
    p.exports.useEffect(() => {
        _.post("/game/support/red-packet/get-info/", {
            info: t,
            key: s
        }).then(v => {
            k() && (v.amount = Number(v.amount), v.receiverAmount = Number(v.receiverAmount), d({
                info: v,
                status: v.receiverStatus == 1 ? P.GRABBED : v.status
            }))
        })
    }, []);
    const b = async (v, F) => {
            const L = new Date().getTime();
            try {
                const h = Math.round(Math.random() * 1e4),
                    u = await ct("login");
                let g = At(v + "_" + F, s),
                    x = await _.post("/game/support/red-packet/get-base/", {
                        info: t,
                        key: s,
                        token: u,
                        cid: h
                    }, {
                        headers: {
                            "Content-Origin": g
                        }
                    });
                const V = Object.assign(o.info, {
                        receiverAmount: Number(x.receiverAmount)
                    }),
                    H = new Date().getTime(),
                    X = H - L > 1e3 ? 0 : 1e3 - H + L;
                await $e(X), k() && (d({
                    loading: !1,
                    showList: !0,
                    info: V,
                    status: x.receiverStatus == 1 ? P.GRABBED : x.status
                }), i())
            } catch (h) {
                R.close(), A(h)
            }
        },
        D = v => o.info ? n("div", {
            className: "coindrop-main",
            children: [n("div", {
                className: "coindrop-bg",
                children: [e("div", {
                    className: "down"
                }), e("div", {
                    className: "up"
                })]
            }), e(kt, {
                toggle: v,
                coindropInfo: e(ft, {
                    state: o
                }),
                listInfo: e(wt, {
                    state: o,
                    onClick: b,
                    onDetail: () => d({
                        showList: !0
                    })
                })
            })]
        }) : e(de, {}),
        C = o.showList || o.status !== P.UNGRABB && ((E = o.info) == null ? void 0 : E.receiverAmount) !== 0;
    return n("div", {
        className: `${Ct} ${C?"list-coindrop":"open-coindrop"}`,
        children: [o.info ? n(J, {
            children: [D(C), e("img", {
                className: "parachute-top",
                alt: "parachute",
                src: T.parachute
            }), e("img", {
                className: "btc-center",
                alt: "btc",
                src: T.fallBtc
            }), e("img", {
                className: "cloud left",
                alt: "cloud",
                src: T.cloudLeft
            }), e("img", {
                className: "cloud right",
                alt: "cloud",
                src: T.cloudRight
            })]
        }) : e(de, {}), e("div", {
            className: "coindrop-close",
            onClick: () => R.close(),
            children: e(I, {
                name: "Close"
            })
        })]
    })
};

function At(a, t) {
    const s = Y.enc.Utf8.parse(t);
    let c = Y.enc.Utf8.parse(a);
    var r = Y.AES.encrypt(c, s, {
        mode: Y.mode.ECB,
        padding: Y.pad.Pkcs7
    });
    return r.toString()
}
const wt = ({
    onClick: a,
    state: t,
    onDetail: s
}) => {
    var m;
    const c = w(),
        [r, i] = p.exports.useState(!1);
    return e("div", {
        className: yt,
        children: n("div", {
            className: "main-info",
            children: [n("div", {
                className: "user-head",
                children: [e("div", {
                    className: "avatar-wrap",
                    children: e(ae, {
                        userId: t.userId,
                        name: t.username
                    })
                }), e(He, {
                    level: t.level
                }), e("div", {
                    className: "user-name",
                    children: t.username
                }), n("div", {
                    className: "desc",
                    children: [e("img", {
                        className: "star",
                        alt: "star",
                        src: T.star
                    }), t.status === P.UNGRABB ? c("page.coindrop.sendCoinDrop") : t.status === P.COMPLETED ? c("page.coindrop.completeCoinDrop") : c("page.coindrop.expiredCoinDrop"), e("img", {
                        className: "star",
                        alt: "star",
                        src: T.star
                    })]
                })]
            }), e("img", {
                alt: "btc",
                className: "btc-coin " + (r ? "loading" : ""),
                src: T.bcgame
            }), e("div", {
                className: "content",
                children: (m = t.info) == null ? void 0 : m.content
            }), e("button", {
                className: "open-view",
                disabled: r,
                onClick: l => {
                    i(!0), t.status === P.UNGRABB ? a(l.clientX, l.clientY) : s()
                },
                children: t.status === P.UNGRABB ? c("page.coindrop.openTap") : c("page.coindrop.viewHistory")
            })]
        })
    })
};
var aa = bt;
const kt = ({
        toggle: a,
        coindropInfo: t,
        listInfo: s
    }) => {
        const r = Xe(a, {
            from: {
                opacity: 0
            },
            enter: {
                opacity: 1
            },
            leave: {
                opacity: 0
            }
        })((i, m) => m ? e(fe.div, {
            className: "animated-div",
            style: i,
            children: t
        }) : e(fe.div, {
            className: "animated-div",
            style: i,
            children: s
        }));
        return e(J, {
            children: r
        })
    },
    Ct = "r1lg8rc1",
    yt = "o1c4am7g";
const xt = M(function() {
    const t = w(),
        s = ve({}, y.dict),
        i = (() => {
            const B = [];
            return Object.keys(s).map(K => {
                s[K].redPackageLimit > 0 && B.push(s[K])
            }), B
        })().map(B => B.currencyName),
        m = i.map(B => y.dict[B]),
        l = i.indexOf("BTC") >= 0 ? "BTC" : i[0],
        o = i.indexOf(y.current) >= 0 ? y.current : l,
        [d, k] = p.exports.useState(o),
        [b, D] = p.exports.useState(50),
        [C, E] = p.exports.useState(""),
        [v, F] = p.exports.useState(!1);
    let L = s[d].redPackageLimit;
    const [h, u] = p.exports.useState(s[o].redPackageLimit), g = async () => {
        try {
            const B = await Ve();
            if (!B) return;
            const {
                code: K,
                timestamp: Pe,
                verifyType: Ie
            } = B, Me = C.length > 0 ? C : "Good Luck!";
            F(!0), await _.post("/game/support/red-packet/add/", {
                currencyName: d,
                amount: h,
                number: b,
                isSingle: 1,
                grantType: 1,
                type: 1,
                content: Me,
                verifyType: Ie,
                code: K,
                remarks: C,
                timestamp: Pe
            }), A(t("common.messages.send_success")), Ye.back()
        } catch (B) {
            A(B), B && B.code === ze.TWOFA_ERROR && g()
        }
        F(!1)
    }, x = async () => {
        const B = await qe(d, !1, m);
        k(B)
    }, V = y.dict[d].amount, H = y.getAlias(d);
    let [X, pe] = y.getValideMaxMin(L, V, d);
    d === "BCL" && (b < 10 ? (X = 10, L = 10) : (X = b, L = b));
    const Ee = h < X || h > pe || C.length > 32 || v;
    return e(q, {
        title: t("title.user_coindrop"),
        children: n("div", {
            className: Bt,
            children: [e(Ge, {
                label: n(J, {
                    children: [e("p", {
                        style: {
                            flex: "auto"
                        },
                        children: t("common.amount")
                    }), n("p", {
                        children: [t("common.balance"), ":", " ", n("span", {
                            children: [V, " ", H]
                        })]
                    })]
                }),
                className: "amount-input",
                currencyName: d,
                value: h,
                onClick: x,
                onChange: u,
                max: pe,
                min: X,
                after: `Min: ${L} ${H}`
            }), e(Je, {
                label: t("page.coindrop.person"),
                min: 1,
                max: 100,
                value: b,
                className: "people-input",
                onChange: D,
                children: e("div", {
                    className: "min-number",
                    children: "1~100"
                })
            }), e(je, {
                label: t("page.tips.message") + t("page.tips.Optional"),
                className: "send-textarea",
                value: C,
                onChange: E,
                children: n("div", {
                    className: C.length > 32 ? "send-error send-len" : "send-len",
                    children: [C.length, "/32"]
                })
            }), n("div", {
                className: "show-amount",
                children: [n("span", {
                    className: "amount-num",
                    children: [h, " "]
                }), e("span", {
                    className: "cl-primary",
                    children: H
                })]
            }), e(S, {
                type: "conic",
                loading: v,
                onClick: g,
                disabled: Ee,
                children: t("page.coindrop.btn")
            })]
        })
    })
});
var sa = xt;
const Bt = "s1kketnf";
const ue = j.memo(({
        num: a
    }) => {
        const t = w(),
            [s, c] = p.exports.useState([]),
            [r, i] = p.exports.useState(""),
            m = l => l.map(o => ({
                amount: o.bonusAmount,
                value: o.currencyName,
                label: y.getAlias(o.currencyName)
            }));
        return p.exports.useEffect(() => {
            let l = !0;
            if (N.login) return _.get("/game/support/bonus/" + a + "/").then(o => {
                o.length > 0 && l && (c(m(o)), i(o[0].currencyName))
            }).catch(o => {
                l && A(o)
            }), () => {
                l = !1
            }
        }, []), !s || s.length === 0 ? e("div", {
            style: {
                display: "none"
            }
        }) : n("div", {
            className: _t,
            children: [e("div", {
                className: "title",
                children: t("page.inviteRain.all")
            }), r && e(Ke, {
                value: r,
                options: s,
                renderLabel: l => e(Ne, {
                    name: l.value,
                    amount: new O(l.amount).toNumber(),
                    icon: !0
                }),
                renderOption: l => e(Ne, {
                    name: l.value,
                    amount: new O(l.amount).toNumber(),
                    icon: !0
                }),
                onChange: l => {
                    i(l)
                }
            })]
        })
    }),
    St = j.memo(a => {
        const t = () => {
                const r = [];
                for (let i = 0; i < a.number.length; i++) r.push(e("span", {
                    className: "num-wrap",
                    children: e("div", {
                        className: "num-box",
                        children: s(i)
                    })
                }, i));
                return r
            },
            s = r => {
                const i = [];
                for (let m = 0; m < (a.number.length + 3 - r) * 10; m++) {
                    const l = m + 1;
                    i.push(e("span", {
                        children: l > 9 ? l % 10 : l
                    }, "item-" + l))
                }
                return i
            };
        p.exports.useEffect(() => {
            c()
        }, [a.number]);
        const c = () => {
            let r = a.number.split("");
            document.querySelectorAll(".num-wrap").forEach((m, l) => {
                let o = a.number.length + 3 - l,
                    d = a.modefiy ? a.modefiy : o + (a.delay || 0);
                Be.to(m, {
                    duration: d,
                    top: m.offsetHeight * (-9 - Number(r[l])) + "px"
                })
            })
        };
        return e("div", {
            className: Rt,
            children: e("div", {
                className: "scroll-number",
                children: t()
            })
        })
    }),
    _t = "c1x0aqub",
    Rt = "s1oue61f";
const Lt = function() {
    const t = w();
    return e(q, {
        title: t("title.bonus_crocodile", t("common.env.mascot")),
        children: e(z, {
            children: n("div", {
                className: Tt,
                children: [e(ue, {
                    num: 2
                }), n("div", {
                    className: "sub-title",
                    children: [t("title.bonus_crocodile", t("common.env.mascot")), n("span", {
                        className: "theme",
                        children: ["(", t("title.user_level"), "14)"]
                    })]
                }), n("ol", {
                    className: "content",
                    children: [e("li", {
                        children: t("page.inviteCro.line1.content.0", t("common.env.mascot"), t("common.env.mascot"))
                    }), e("li", {
                        children: t("page.inviteCro.line1.content.1", y.getAlias("BCD"))
                    }), e("li", {
                        children: t("page.inviteCro.line1.content.2", y.getAlias("BCD"))
                    })]
                })]
            })
        })
    })
};
var ia = Lt;
W({
    cl1: [f("#99a4b0", .8), f("#5f6975", .6)],
    cl2: ["#99a4b0", "#5f6975"],
    cl3: ["#17181b", "#f5f6fa"],
    cl4: ["#99a4b0", f("#5f6975", .8)]
});
const Tt = "c7egzjg";
const Dt = M(function() {
    const t = w(),
        s = Q(),
        c = ie.receiveTime > 0 ? Date.now() + ie.receiveTime : 0,
        r = ie.list.length > 0;

    function i() {
        return N.login ? N.vipLevel < 14 ? n("div", {
            className: "unlock",
            children: [e(I, {
                name: "Locked"
            }), t("page.vip.unlock", "14")]
        }) : r ? e(S, {
            type: "conic",
            children: t("common.claim_now")
        }) : c > 0 ? e(re, {
            endTime: c,
            children: ({
                days: o,
                hours: d,
                minutes: k,
                seconds: b
            }) => e(ce, {
                title: t("page.promotion.available"),
                days: o,
                hours: d,
                minutes: k,
                seconds: b
            })
        }) : null : null
    }

    function m() {
        return N.login ? N.vipLevel < 22 ? n("div", {
            className: "unlock",
            children: [e(I, {
                name: "Locked"
            }), t("page.vip.unlock", "22")]
        }) : oe.isRech ? e(S, {
            type: "conic",
            children: t("common.claim_now")
        }) : oe.endTime > 0 ? e(re, {
            endTime: oe.endTime,
            children: ({
                days: o,
                hours: d,
                minutes: k,
                seconds: b
            }) => e(ce, {
                title: t("page.promotion.available"),
                days: o,
                hours: d,
                minutes: k,
                seconds: b
            })
        }) : e(S, {
            type: "conic",
            children: t("page.recharge.request")
        }) : null
    }

    function l() {
        return N.login ? be.freeTimes === 0 ? e(re, {
            endTime: be.nextTime,
            children: ({
                days: o,
                hours: d,
                minutes: k,
                seconds: b
            }) => e(ce, {
                title: t("page.promotion.available"),
                days: o,
                hours: d,
                minutes: k,
                seconds: b
            })
        }) : e(S, {
            type: "gray",
            children: t("page.promotion.spin.button.login")
        }) : e(S, {
            type: "gray",
            children: t("page.promotion.spin.button.nologin")
        })
    }
    return n("div", {
        className: Wt,
        children: [e(Ze, {
            id: "promotions"
        }), n("div", {
            onClick: () => s("/spin"),
            className: "item spin",
            children: [n("div", {
                className: "item-title ttu bold",
                children: [e(te, {
                    k: "page.promotion.spin.title1",
                    children: e("span", {
                        className: "theme1",
                        children: t("page.promotion.spin.title0")
                    })
                }), e("br", {}), e(te, {
                    k: "page.promotion.spin.title2",
                    children: e("span", {
                        className: "theme2",
                        children: t("page.promotion.spin.title3")
                    })
                })]
            }), e("div", {
                className: "item-desc"
            }), l()]
        }), n("div", {
            className: "item rakeback",
            onClick: () => {
                N.vipLevel < 14 ? A(t("page.vip.unlock", "14")) : s("/rakeback")
            },
            children: [e("div", {
                className: "item-title ttu bold",
                children: t("page.promotion.rakeback.title")
            }), e("div", {
                className: "item-desc",
                children: N.login ? t("page.promotion.rakeback.desc.login") : t("page.promotion.rakeback.desc.nologin")
            }), i()]
        }), n("div", {
            className: "item recharge",
            onClick: () => {
                N.vipLevel < 22 ? A(t("page.vip.unlock", "22")) : s("/recharge")
            },
            children: [e("div", {
                className: "item-title ttu bold",
                children: t("page.promotion.recharge.title")
            }), e("div", {
                className: "item-desc",
                children: N.login ? t("page.promotion.recharge.desc.login") : t("page.promotion.recharge.desc.nologin")
            }), m()]
        })]
    })
});

function Et() {
    return _.get("/home/main/event-list/", {
        cache: !0
    })
}
const Pt = M(function() {
        const t = w(),
            [s, c] = p.exports.useState(null);
        p.exports.useEffect(() => {
            Et().then(i => {
                c(i.eventList)
            })
        }, []);

        function r(i) {
            location.href = i.linkUrl
        }
        return !s || !s.length ? null : n("div", {
            className: Ft,
            children: [e("div", {
                className: "title bold",
                children: t("page.promotion.title.activities")
            }), e("div", {
                className: "list",
                children: s.map((i, m) => n("div", {
                    className: "item",
                    children: [n("div", {
                        className: "enter",
                        children: [e("div", {
                            className: "enter-title bold",
                            children: i.title
                        }), e("div", {
                            className: "enter-desc",
                            children: i.desc
                        }), e(S, {
                            type: "conic",
                            className: "detail",
                            onClick: () => r(i),
                            children: t("common.detail")
                        })]
                    }), e("div", {
                        className: "cover",
                        children: e("img", {
                            src: U.isDarken ? i.eventBgImg : i.eventMobBgImg,
                            className: "cover-img",
                            onClick: () => r(i)
                        })
                    })]
                }, m))
            })]
        })
    }),
    It = M(function() {
        const t = w();
        return n("div", {
            className: Mt,
            children: [n("div", {
                className: "title ttu bold",
                children: [e(I, {
                    name: "Chip"
                }), t("page.promotion.title.other"), e(I, {
                    name: "Chip"
                })]
            }), e(Dt, {}), e(Pt, {})]
        })
    });
W({
    cl1: [f("#333940", .56), f("#ebebeb", .56)],
    cl2: ["#ebeef1", "#31373d"]
});
const Mt = "o5o29t8",
    Wt = "t8bfr5m",
    Ft = "l1ig3vpb";

function Te() {
    const a = w(),
        t = Q();
    return [{
        title: a("page.vip.rights.title3"),
        desc: a("page.promotion.roll.desc"),
        onClick: () => t("/bonus/roll"),
        cssName: "bonus-roll"
    }, {
        title: a("page.vip.rights.title11"),
        desc: a("page.promotion.coco.desc"),
        onClick: () => t("/bonus/crocodile"),
        cssName: "bonus-coco"
    }, {
        title: a("title.user_rain"),
        desc: a("page.promotion.rain.desc"),
        onClick: () => t("/bonus/rain"),
        cssName: "bonus-rain"
    }]
}
const Ot = M(function({
        isSmallSize: t
    }) {
        const s = w();
        return n("div", {
            className: Ht,
            children: [e("div", {
                className: "title ttu bold",
                children: s("page.promotion.title.casino")
            }), U.isMobile ? e(Ut, {}) : e(Qt, {
                isSmallSize: t
            })]
        })
    }),
    Ut = () => {
        const [a, t] = p.exports.useState(0), s = Te();
        return n("div", {
            className: `${De} bonus`,
            children: [e(Se, {
                className: "carousel-wraps",
                value: a,
                onChange: t,
                children: s.map((c, r) => e("div", {
                    className: `bonus__item ${c.cssName}`,
                    children: n("div", {
                        className: "item-wrap",
                        onClick: c.onClick,
                        children: [e("div", {
                            className: "item-title ttu bold",
                            children: c.title
                        }), e("div", {
                            className: "item-desc",
                            children: c.desc
                        })]
                    })
                }, r))
            }), n("div", {
                className: "bot-wrap",
                children: [e(Le, {
                    active: a,
                    length: s.length,
                    onJump: t
                }), e(_e, {
                    onPrev: () => t(a - 1),
                    onNext: () => t(a + 1),
                    length: s.length
                })]
            })]
        })
    },
    Qt = ({
        isSmallSize: a
    }) => {
        const [t, s] = p.exports.useState(0), c = Te();
        if (a) {
            let r = [c.slice(0, 2), c.slice(2, 3)];
            return n("div", {
                className: `${De} bonus`,
                children: [e(Se, {
                    className: "carousel-wraps",
                    value: t,
                    onChange: s,
                    children: r.map((i, m) => e("div", {
                        className: "bonus__item-wrap",
                        children: i.map((l, o) => e("div", {
                            className: `bonus__item ${l.cssName}`,
                            children: n("div", {
                                className: "item-wrap",
                                onClick: l.onClick,
                                children: [e("div", {
                                    className: "item-title ttu bold",
                                    children: l.title
                                }), e("div", {
                                    className: "item-desc",
                                    children: l.desc
                                })]
                            })
                        }, o))
                    }, m))
                }), n("div", {
                    className: "bot-wrap",
                    children: [e(Le, {
                        active: t,
                        length: r.length,
                        onJump: s
                    }), e(_e, {
                        onPrev: () => s(t - 1),
                        onNext: () => s(t + 1),
                        length: r.length
                    })]
                })]
            })
        }
        return e("div", {
            className: "bonus",
            children: c.map((r, i) => e("div", {
                className: `bonus__item ${r.cssName}`,
                children: n("div", {
                    className: "item-wrap",
                    onClick: r.onClick,
                    children: [e("div", {
                        className: "item-title ttu bold",
                        children: r.title
                    }), e("div", {
                        className: "item-desc",
                        children: r.desc
                    })]
                })
            }, i))
        })
    },
    De = "s1tt5s80";
W({
    cl1: ["#dfe3e6", "#31373d"],
    cl2: ['url("../assets/promotion/roll_competition.png") no-repeat 96% center/auto 60%,linear-gradient(160deg, #fbd116 -121%, #1e2024 51%)', 'url("../assets/promotion/roll_competition.png") no-repeat 96% center/auto 60%,linear-gradient(168deg, #fbbf00 -6%, #fffaea 50%, #ffffff 62%)'],
    cl3: ['url("@bc/assets/promotion/where_is_coco.png") no-repeat 96% center/auto 80%,linear-gradient(160deg, #1cca69 -121%, #1e2024 51%)', 'url("@bc/assets/promotion/where_is_coco.png") no-repeat 96% center/auto 80%,linear-gradient(169deg, #039a3d -44%, #edf8f1 51%, #ffffff 69%)'],
    cl4: ['url("@bc/assets/promotion/rain.png") no-repeat 96% center/auto 80%,linear-gradient(160deg, #1c5fca -121%, #1e2024 51%)', 'url("@bc/assets/promotion/rain.png") no-repeat 96% center/auto 80%,linear-gradient(166deg, #1c5fca -62%, #eef3fb 48%, #ffffff 67%)'],
    cl5: ["#dfe3e6", "#31373d"],
    cl6: [f("#98a7b5", .7), f("#31373d", .7)]
});
const Ht = "o94ju8e";
const Xt = M(function() {
        const t = w(),
            s = Q(),
            {
                totalAmount: c,
                releaseAmount: r,
                bonusAmount: i,
                bonusThreshold: m
            } = se;
        let l = 0;
        return c && r && c !== "0" && (O.div(r, c).mul(100).toNumber(), l = O.sub(c, r).toNumber()), n("div", {
            className: `bcd ${jt} ${N.login?"":"nologin"}`,
            children: [n("div", {
                className: "left",
                children: [e("div", {
                    className: "title ttu bold",
                    children: N.login ? t("page.promotion.bcd.title.login") : t("page.promotion.bcd.title.nologin")
                }), e("div", {
                    className: "desc",
                    children: N.login ? t("page.promotion.bcd.desc.login") : n(J, {
                        children: [e("div", {
                            children: "1 BCD = 1 USD"
                        }), e("div", {
                            children: t("page.promotion.bcd.desc.nologin")
                        })]
                    })
                }), N.login && n("div", {
                    className: "preview",
                    children: [n("div", {
                        className: "released",
                        children: [e("div", {
                            className: "type",
                            children: t("wallet.bcd.dialog.released")
                        }), n("div", {
                            className: "value bold",
                            children: [new O(r || 0).toFixed(2), " BCD"]
                        })]
                    }), n("div", {
                        className: "lucked",
                        children: [e("div", {
                            className: "type",
                            children: t("wallet.bcd.lucked")
                        }), n("div", {
                            className: "value bold",
                            children: [new O(l).toFixed(2), " BCD"]
                        })]
                    })]
                }), n("div", {
                    className: "detail",
                    onClick: () => {
                        N.login ? s("/bonus_dashboard") : s("/about_bonuscoin")
                    },
                    children: [e("span", {
                        children: t("common.detail")
                    }), e(I, {
                        name: "Arrow"
                    })]
                })]
            }), N.login ? e(ot, {
                className: "bcd-status",
                bonusAmount: i,
                bonusThreshold: m
            }) : e("div", {
                className: "right bg"
            })]
        })
    }),
    $t = j.memo(function() {
        const t = w(),
            s = Q(),
            [c, r] = p.exports.useState(""),
            [i, m] = p.exports.useState(!1),
            l = () => {
                m(!0), _.post("/activity/redeemCode/useCode/", {
                    redeemCode: c
                }).then(o => {
                    m(!1);
                    const d = n("div", {
                        children: ["You have got", " ", n("span", {
                            className: "cl-primary",
                            children: [o.stringAmount, " ", o.currencyName]
                        }), " ", "from Coco's cave"]
                    });
                    A(d, {
                        title: "The shitcode worked!",
                        duration: 0,
                        onClick() {
                            s(`/transactions/bill/${o.currencyName}`)
                        }
                    })
                }).catch(o => {
                    m(!1), A(o)
                })
            };
        return n("div", {
            className: `${Vt} shitcode`,
            children: [n("div", {
                className: "flex flex-center",
                children: [e("div", {
                    className: "title ttu bold",
                    children: t("page.promotion.shitcode.title")
                }), n("div", {
                    className: "detail",
                    onClick: () => s("/sweetcodes"),
                    children: [e("span", {
                        children: t("common.detail")
                    }), e(I, {
                        name: "Arrow"
                    })]
                })]
            }), e("div", {
                className: "desc",
                children: t("page.promotion.shitcode.desc")
            }), n("div", {
                className: "flex-center wrap",
                children: [e(Re, {
                    value: c,
                    onChange: o => r(o)
                }), e(S, {
                    type: "gray",
                    disabled: !c || i,
                    onClick: l,
                    children: t("page.promotion.shitcode.button")
                })]
            })]
        })
    }),
    Gt = M(function() {
        return n("div", {
            className: Jt,
            children: [e(Xt, {}), e($t, {})]
        })
    }),
    Jt = "b1rm56tm";
W({
    cl1: [`linear-gradient(to right, ${f("#932ac3",.76)} 27%, #8b2bb8 57%, #30343c 121%)`, `linear-gradient(to right, ${f("#c142fc",.76)} -7%, #ffffff 121%)`],
    cl2: ["#ffffff", "#31373d"],
    cl3: [f("#17181b", .3), f("#f6f7fa", 1)],
    cl4: [f("#d8d8d8", .12), f("#eaa9ff", .2)],
    cl5: ['url("../assets/promotion/bcd-bg-bottom.png")', 'url("../assets/promotion/bcd-bg-bottom-w.png")'],
    cl6: ['url("../assets/promotion/circle-bcd.png")', 'url("../assets/promotion/circle-bcd-w.png")']
});
const jt = "b8wsqvs",
    Vt = "srixgjn";
var Yt = "/assets/deposit01.27f72c23.png",
    zt = "/assets/deposit02.f212800e.png",
    qt = "/assets/deposit03.2932cbb2.png",
    Kt = "/assets/deposit04.3e2bf32e.png",
    Zt = "/assets/front1.165b9763.png",
    en = "/assets/front2.4d817c22.png",
    tn = "/assets/front3.e272db5a.png",
    nn = "/assets/front4.0a2b25a2.png",
    an = "/assets/front1_m.366e7d85.png",
    sn = "/assets/front2_m.151e275c.png",
    rn = "/assets/front3_m.0e3b8405.png",
    cn = "/assets/front4_m.ed23ed52.png",
    on = "/assets/rain.6ed17417.png",
    ln = "/assets/where_is_coco.6686403b.png",
    dn = "/assets/bcd-bg.9055bbfa.png",
    mn = "/assets/deposit-banner.584900c4.png",
    un = "/assets/deposit-banner-w.b3c1c8b1.png",
    pn = "/assets/deposit-banner-m.71cd7cc9.png",
    hn = "/assets/deposit-banner-m-w.cc67c1e1.png";
const Z = {
    deposit01: Yt,
    deposit02: zt,
    deposit03: qt,
    deposit04: Kt,
    front1: Zt,
    front2: en,
    front3: tn,
    front4: nn,
    front1_m: an,
    front2_m: sn,
    front3_m: rn,
    front4_m: cn,
    rain: on,
    whereIsCoco: ln,
    bcdbg: dn,
    depositBanner: mn,
    depositBannerWhite: un,
    depositBannerMobile: pn,
    depositBannerMobileWhite: hn
};
var gn = "/assets/gold_bg.5431379f.png",
    vn = "/assets/gold_bg_m.aac4f22d.png",
    ee = {
        gold_bg: gn,
        gold_bg_m: vn,
        deposit01: Z.deposit01,
        deposit02: Z.deposit02,
        deposit03: Z.deposit03,
        deposit04: Z.deposit04
    };

function fn({
    index: a
}) {
    const t = w(),
        {
            maxBonusRatio: s,
            firstExpiredTime: c
        } = se,
        r = [{
            ratio: s[c > 0 ? 0 : 1],
            index: 0,
            title: "1st",
            img: ee.deposit01
        }, {
            ratio: s[2],
            index: 1,
            title: "2nd",
            img: ee.deposit02
        }, {
            ratio: s[3],
            index: 2,
            title: "3rd",
            img: ee.deposit03
        }, {
            ratio: s[4],
            index: 3,
            title: "4th",
            img: ee.deposit04
        }];
    return n("div", {
        className: `${Nn} deposit-top index-${a}`,
        style: {
            backgroundImage: `url(${r[a].img})`
        },
        children: [n("div", {
            className: "title ttu",
            children: [n("div", {
                className: "normal",
                children: [r[a].title, " ", t("common.deposit_bonus")]
            }), n("div", {
                className: "large",
                children: [t("page.promotion.deposit.upto"), n("span", {
                    className: "theme",
                    children: [" ", Math.round(r[a].ratio * 100), "% "]
                }), t("title.bonus")]
            })]
        }), e("div", {
            className: "desc",
            children: t("page.promotion.deposit.tip.desc")
        })]
    })
}
W({
    cl1: ["#f5f6f7", "#000000"],
    cl2: [f("#f5f6f7", .6), f("#5f6975", .8)]
});
const Nn = "d1n6g68l";

function we(a) {
    const {
        firstExpiredTime: t
    } = se;
    t > 0 ? ne("/wallet/deposit") : dt(e(fn, {
        index: a
    }))
}

function bn() {
    return e("svg", {
        width: "32",
        height: "24",
        xmlns: "http://www.w3.org/2000/svg",
        className: "icon",
        children: e("path", {
            d: "M21.908.814l.128.112 7.878 7.563a4.662 4.662 0 01.172 6.615l-.172.174-7.878 7.563a2.06 2.06 0 01-2.829 0 1.864 1.864 0 01-.117-2.593l.117-.122 7.879-7.564a.932.932 0 00.083-1.267l-.083-.09-7.879-7.564a1.866 1.866 0 010-2.715 2.062 2.062 0 012.701-.112zm-9 0l.128.112 7.878 7.563a4.662 4.662 0 01.172 6.615l-.172.174-7.878 7.563a2.06 2.06 0 01-2.829 0 1.864 1.864 0 01-.117-2.593l.117-.122 7.879-7.564a.932.932 0 00.083-1.267l-.083-.09-7.879-7.564a1.866 1.866 0 010-2.715 2.062 2.062 0 012.701-.112zm-9 0l.128.112 7.878 7.563a4.662 4.662 0 01.172 6.615l-.172.174-7.878 7.563a2.06 2.06 0 01-2.829 0 1.864 1.864 0 01-.117-2.593l.117-.122 7.879-7.564a.932.932 0 00.083-1.267l-.083-.09L1.207 3.64a1.866 1.866 0 010-2.715A2.062 2.062 0 013.908.814z"
        })
    })
}
const An = M(function() {
        const t = w(),
            s = Q(),
            {
                expiredTime: c,
                maxBonusRatio: r,
                rechargeValidNum: i,
                firstExpiredTime: m
            } = se,
            l = i > 3,
            o = [{
                ratio: r[m > 0 ? 0 : 1],
                index: 0
            }, {
                ratio: r[2],
                index: 1
            }, {
                ratio: r[3],
                index: 2
            }, {
                ratio: r[4],
                index: 3
            }];
        return l ? n("div", {
            className: wn,
            children: [n("div", {
                className: "banner-title ttu",
                children: ["BC ", e("span", {
                    className: "theme",
                    children: t("common.promotion")
                })]
            }), e("div", {
                className: "banner-subtitle ttu",
                children: t("wallet.bcd.deposit.desc_1")
            }), n("div", {
                className: "banner-desc",
                children: [e("div", {
                    children: t("wallet.bcd.deposit.desc_2")
                }), e("div", {
                    children: t("wallet.bcd.depoist.desc_3")
                })]
            })]
        }) : n("div", {
            className: kn,
            children: [n("div", {
                className: "left",
                onClick: () => s("/bcd_rule"),
                children: [n("div", {
                    className: "title ttu bold",
                    children: [t("page.promotion.deposit.title1"), e("div", {
                        className: "theme1",
                        children: t("page.promotion.deposit.title2")
                    })]
                }), n("div", {
                    className: "desc",
                    children: [n("div", {
                        className: "speed ttu bold",
                        children: [t("wallet.bcd.unlock_speed"), e("span", {
                            className: "theme1 up",
                            children: "+5%"
                        })]
                    }), t("page.promotion.deposit.desc1"), e("br", {}), e("span", {
                        className: "date bold ttc",
                        children: e(te, {
                            k: "page.promotion.deposit.desc2",
                            children: new Date(c).toLocaleDateString()
                        })
                    })]
                }), n("div", {
                    className: "detail",
                    children: [e("span", {
                        children: t("common.detail")
                    }), e(I, {
                        name: "Arrow"
                    })]
                })]
            }), e("div", {
                className: "right",
                children: o.map(d => n("div", {
                    className: `item ${d.index===i?"active":""} ${U.isMobile?"mobile":""}`,
                    children: [n("div", {
                        className: "stage",
                        children: [e("div", {
                            className: "mask"
                        }), e("div", {
                            className: "front"
                        }), n("div", {
                            className: "text ttu bold",
                            children: [e("div", {
                                className: "small",
                                children: t("page.promotion.deposit.upto")
                            }), U.isMobile ? n(J, {
                                children: [n("div", {
                                    className: "large",
                                    children: [Math.round((d.ratio || 0) * 100), "%"]
                                }), e("div", {
                                    className: "small",
                                    children: t("title.bonus")
                                })]
                            }) : n("div", {
                                className: "large",
                                children: [Math.round((d.ratio || 0) * 100), "% ", t("title.bonus")]
                            })]
                        }), n("div", {
                            className: "effect",
                            children: [e("div", {
                                className: "effect-item"
                            }), e("div", {
                                className: "effect-item"
                            })]
                        }), d.index !== 3 && e("div", {
                            className: "stage__arrow flex-center",
                            children: e(bn, {})
                        })]
                    }), N.login ? e(S, {
                        type: "gray",
                        onClick: () => we(d.index),
                        disabled: d.index !== i,
                        children: t("page.bcd.deposit_now")
                    }) : e(S, {
                        type: "gray",
                        onClick: () => s("/login"),
                        disabled: d.index !== 0,
                        children: t("title.regist")
                    })]
                }, d.index))
            }), U.isMobile && e(J, {
                children: N.login ? e(S, {
                    type: "gray",
                    className: `index_${i}`,
                    onClick: () => we(i),
                    children: t("page.bcd.deposit_now")
                }) : e(S, {
                    type: "gray",
                    onClick: () => s("/login"),
                    children: t("title.regist")
                })
            })]
        })
    }),
    wn = "a16s9kk5";
W({
    cl1: ["#b53e16", "#d25c35"],
    cl2: ["#c44921", "#d05228"],
    cl3: ["200%", "54%"],
    cl4: ["#ffffff", "#f8f9fa"],
    cl5: [f("#d54e42", 0), "#cc745d"],
    cl6: ["linear-gradient(to right, #dd5327, rgba(206, 85, 60, 0) 83%)", "linear-gradient(to right, #f46738, rgba(255, 103, 64, 0) 83%)"],
    cl7: ['url("../assets/promotion/shadow.png")', 'url("../assets/promotion/shadow-w.png")']
});
const kn = "d1y3tunz";
const Cn = function() {
        const [t, s] = p.exports.useState(!1), c = et(({
            width: r
        }) => {
            r > 621 && r <= 1100 ? s(!0) : s(!1)
        }, 300);
        return n("div", {
            id: "promotion",
            ref: c,
            className: le(yn, t && "p-small"),
            children: [e(An, {}), e(Gt, {}), e(lt, {}), e(It, {}), e(Ot, {
                isSmallSize: t
            })]
        })
    },
    yn = "p15el2px";
var ra = Cn;
const xn = () => e("div", {
    className: Sn,
    children: n("div", {
        className: "fireworks-acive fireworks-wrap",
        children: [e("img", {
            className: "fireworks",
            src: $.fireworks.fire_fireworks_r
        }), e("img", {
            className: "fireworks ps_r",
            src: $.fireworks.fire_fireworks_r
        }), e("img", {
            className: "fireworks ps_l",
            src: $.fireworks.fire_fireworks_p
        }), e("img", {
            className: "fireworks ps_t",
            src: $.fireworks.fire_fireworks_g
        }), e("img", {
            className: "fireworks ps_b",
            src: $.fireworks.fire_fireworks_y
        }), e("img", {
            className: "fireworks ps_lb",
            src: $.fireworks.fire_fireworks_g
        })]
    })
});
var Bn = j.memo(xn);
const Sn = "fule6o7";
const _n = j.memo(() => {
    const a = w(),
        t = Q(),
        [s, c] = p.exports.useState(""),
        [r, i] = p.exports.useState(!1),
        [m, l] = p.exports.useState(!1),
        o = () => {
            l(!0), _.post("/activity/redeemCode/useCode/", {
                redeemCode: s
            }).then(d => {
                i(!0), l(!1);
                const k = y.getAlias(d.currencyName),
                    b = e("div", {
                        children: e(te, {
                            k: "page.promotion.shitcode.recive",
                            children: n("span", {
                                className: "cl-primary",
                                children: [d.stringAmount, " ", k]
                            })
                        })
                    });
                A(b, {
                    title: "The shitcode worked!",
                    duration: 0,
                    onClick() {
                        t(`/transactions/bill/${d.currencyName}`)
                    }
                })
            }).catch(d => {
                l(!1), A(d)
            })
        };
    return e(q, {
        title: a("title.sweetcodes"),
        children: n(z, {
            className: Rn,
            children: [n("div", {
                className: "sweet-input",
                children: [e("div", {
                    className: "label",
                    children: a("page.sweet.title")
                }), n("div", {
                    className: "flex-center",
                    children: [e(Re, {
                        value: s,
                        onChange: d => c(d)
                    }), e(S, {
                        type: "conic",
                        disabled: s === "" || m,
                        className: s === "" ? "disable" : "",
                        onClick: o,
                        children: m ? "Loading..." : "Redeem"
                    })]
                })]
            }), r && e(Bn, {}), n("div", {
                className: "content",
                children: [a("page.sweet.cont"), n("ul", {
                    className: "code-list",
                    children: [e("li", {
                        children: a("page.sweet.li1")
                    }), e("li", {
                        children: a("page.sweet.li2")
                    }), e("li", {
                        children: a("page.sweet.li3")
                    }), e("li", {
                        children: a("page.sweet.li4")
                    }), e("li", {
                        children: a("page.sweet.li5")
                    }), e("li", {
                        children: a("page.sweet.li6")
                    })]
                }), "\u{1F381}\u{1F4A9}\u{1F381}\u{1F4A9}\u{1F381}\u{1F4A9}\u{1F381}\u{1F4A9}", e("br", {}), e("br", {}), a("page.sweet.desc")]
            })]
        })
    })
});
var ca = _n;
W({
    cl1: [f("#99a4b0", .6), f("#5f6975", .6)],
    cl2: [f("#99a4b0", .8), f("#5f6975", .8)],
    cl3: ["#2d3035", "#dadde6"]
});
const Rn = "sp5kulc";
const Ln = function() {
    const t = w();
    return e(q, {
        title: t("title.user_rain"),
        children: e(z, {
            children: n("div", {
                className: Tn,
                children: [e(ue, {
                    num: 3
                }), e("div", {
                    className: "title",
                    children: t("title.user_rain")
                }), n("div", {
                    className: "theme",
                    children: ["(", t("title.user_level"), "4)"]
                }), n("ol", {
                    children: [e("li", {
                        children: t("page.inviteRain.line1.content.0")
                    }), e("li", {
                        children: t("page.inviteRain.line1.content.1")
                    }), e("li", {
                        children: t("page.inviteRain.line1.content.2")
                    }), e("li", {
                        children: t("page.inviteRain.line1.content.3")
                    }), e("li", {
                        children: t("page.inviteRain.line1.content.4")
                    }), e("li", {
                        children: t("page.inviteBonus.line1.content.4")
                    })]
                }), e("div", {
                    className: "sub-title more-title",
                    children: t("page.inviteBonus.line2.title")
                }), n("div", {
                    className: "example",
                    children: [n("div", {
                        className: "example-title",
                        children: [e(ae, {
                            name: "BC.GAME",
                            userId: 0
                        }), e("div", {
                            className: "name ttu",
                            children: t("page.publicchat.bcgame")
                        }), e(I, {
                            name: "Official"
                        })]
                    }), n("div", {
                        className: "example-content",
                        children: [e("div", {
                            children: t("page.rain.title")
                        }), n("div", {
                            className: "content-item",
                            children: [e("div", {
                                className: "item",
                                children: "@Jachk:888TRX"
                            }), e("div", {
                                className: "item",
                                children: "@Blrr:888TRX"
                            }), e("div", {
                                className: "item",
                                children: "@Pokiuutt:888TRX"
                            }), e("div", {
                                className: "item",
                                children: "@Liisdt:888TRX"
                            }), e("div", {
                                className: "item",
                                children: "@Yoiohu:888TRX"
                            }), e("div", {
                                className: "item",
                                children: "@Loidr:888TRX"
                            })]
                        }), e("div", {
                            children: t("page.coindrop.congratulations")
                        })]
                    })]
                })]
            })
        })
    })
};
var oa = Ln;
W({
    cl1: [f("#99a4b0", .8), f("#5f6975", .6)],
    cl2: ["#f5f6f7", "#31373d"],
    cl3: ["#99a4b0", "#5f6975"],
    cl4: [f("#99a4b0", .8), f("#5f6975", .8)],
    cl5: ["#1a1b1e", "#f6f7fa"]
});
const Tn = "r1e1f6ta";
const Dn = () => _.get("/game/support/get-roll/").then(a => Promise.resolve(a)).catch(a => Promise.reject(a)),
    En = () => _.get("/game/support/roll/get-user/").then(a => Promise.resolve(a)).catch(a => Promise.reject(a)),
    ke = () => _.get("/game/support/roll-purview/").then(a => Promise.resolve(a)).catch(a => Promise.reject(a)),
    Pn = function() {
        const t = w(),
            [s, c] = p.exports.useState("000"),
            [r, i] = p.exports.useState(-9999),
            [m, l] = p.exports.useState(0),
            [o, d] = p.exports.useState({
                allAmount: "",
                currencyName: "",
                list: []
            }),
            k = p.exports.useRef(),
            b = p.exports.useRef(!0);
        p.exports.useEffect(() => (C(!0), () => {
            b.current = !1;
            try {
                clearInterval(k.current)
            } catch (h) {}
        }), []);
        const D = h => {
                let u = h;
                u > 0 && (k.current = setInterval(() => {
                    u < 1e3 ? (ke().then(g => l(g)).catch(A), clearInterval(k.current)) : (u = u > 0 ? u - 1e3 : u, i(u))
                }, 1e3))
            },
            C = h => Promise.all([Dn(), En(), ke()]).then(u => {
                b.current && (h && c(E(u[0].roll)), i(u[0].currentTime), d(u[1]), l(u[2]), D(u[0].currentTime))
            }).catch(A),
            E = h => {
                let u;
                return u = h.toString(), h < 10 ? u = "00" + u : h < 100 && (u = "0" + u), u
            },
            v = h => {
                let u = parseInt(h % 864e5 / 36e5),
                    g = parseInt(h % (1e3 * 60 * 60) / (1e3 * 60)),
                    x = parseInt(h % (1e3 * 60) / 1e3);
                return u = u < 10 ? "0" + u : u, g = g < 10 ? "0" + g : g, x = x < 10 && x >= 1 ? "0" + x : x, u + ":" + g + ":" + x
            },
            F = h => !h || h.length === 0 ? null : h.map((u, g) => e(tt, {
                title: v(u.createTime),
                children: n("tr", {
                    children: [e("td", {
                        className: "darken",
                        children: u.sort
                    }), e("td", {
                        children: e("div", {
                            className: "ellipsis",
                            children: u.userName
                        })
                    }), e("td", {
                        className: "darken",
                        children: u.roll
                    }), n("td", {
                        className: "flex-center",
                        children: [e(nt, {
                            name: u.currencyName
                        }), " ", u.rollAmountStr, " ", y.getAlias(u.currencyName)]
                    })]
                })
            }, "body-" + g)),
            L = () => {
                if (at.trackEvent("roll_click"), m === 0) return !1;
                _.get("/game/support/click-roll/").then(h => {
                    c(E(h.roll)), C()
                }).catch(A)
            };
        return e(q, {
            title: t("title.bonus_roll"),
            children: e(z, {
                children: n("div", {
                    className: In,
                    children: [e(ue, {
                        num: 5
                    }), n("div", {
                        className: "ir-top",
                        children: [e("div", {
                            className: "ir-title sub-title",
                            children: t("page.inviteRoll.title")
                        }), n("div", {
                            className: "ir-cont",
                            children: [t("page.inviteRoll.cont"), n("span", {
                                className: "theme bold",
                                children: ["(", t("title.user_level"), "3)"]
                            })]
                        })]
                    }), n("div", {
                        className: "ir-control",
                        children: [n("div", {
                            className: "display-wrap flex-center",
                            children: [e(St, {
                                number: s
                            }), e("div", {
                                className: "display-num"
                            }), e("div", {
                                className: "display-num"
                            }), e("div", {
                                className: "display-num"
                            })]
                        }), e("div", {
                            className: "roll-butwrap",
                            children: e(S, {
                                type: "conic",
                                disabled: m === 0,
                                onClick: L,
                                className: "roll-button ttu",
                                children: t("title.bonus_roll")
                            })
                        }), n("div", {
                            className: "roll-desc",
                            children: [n("div", {
                                className: "roll-time",
                                children: [t("page.inviteRoll.endTime"), " ", r > 0 ? v(r) : "00:00:00"]
                            }), n("div", {
                                className: "roll-chance",
                                children: [t("page.inviteRoll.changce"), "\xA0", e("span", {
                                    className: "theme",
                                    children: m
                                })]
                            })]
                        })]
                    }), n("div", {
                        className: "ir-amount",
                        children: [t("page.inviteRoll.toDay"), n("span", {
                            className: "theme",
                            children: ["\xA0", o.allAmount, " ", y.getAlias(o.currencyName)]
                        })]
                    }), e("div", {
                        className: "roll-table",
                        children: n("table", {
                            children: [e("thead", {
                                children: n("tr", {
                                    children: [e("th", {
                                        children: t("page.inviteRoll.rank")
                                    }), e("th", {
                                        children: t("common.player")
                                    }), e("th", {
                                        children: t("common.result")
                                    }), e("th", {
                                        children: t("title.bonus")
                                    })]
                                })
                            }), e("tbody", {
                                className: "records",
                                children: F(o.list)
                            })]
                        })
                    }), n("div", {
                        className: "ir-bottom",
                        children: [e("div", {
                            className: "ir-bot-list",
                            dangerouslySetInnerHTML: {
                                __html: t("page.inviteRoll.cont_1")
                            }
                        }), e("div", {
                            className: "ir-bot-list",
                            dangerouslySetInnerHTML: {
                                __html: t("page.inviteRoll.cont_2", t("common.env.free_coin"))
                            }
                        })]
                    })]
                })
            })
        })
    };
var la = Pn;
W({
    cl1: [f("#99a4b0", .8), f("#5f6975", .6)],
    cl2: ["#f5f6f7", "#31373d"],
    cl3: ["#17181b", "#f5f6fa"],
    cl4: ["#272b30", "#dadde6"],
    cl5: [f("#99a4b0", .6), f("#5f6975", .8)],
    cl6: ["#99a4b0", f("#5f6975", .8)],
    cl7: ["#99a4b0", "#5f6975"]
});
const In = "rk2fxtl";
var Mn = "/assets/sunflower.63165faf.png",
    Wn = "/assets/background.e61f027b.png",
    Fn = "/assets/starone.934d9e99.png",
    On = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAeCAYAAADZ7LXbAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAGaADAAQAAAABAAAAHgAAAADq00tOAAAB2ElEQVRIDbWWPUvDQBiAL/GjLdTFQQQnEcRFXERERV1EnTroXhzEQXTxV4g4ObuJdRcRxMlZBUe/0MFBBD8WXez1fM621oR4uatp4Jr07n2fJ+81fVshHA+l1KBjivBdE4Qo5RGlXPLqkIgRBAMNk1BBG/B+qhlumATwlBCqhTHjInGKVUpuK1WkIPnBS8Yp2SYYaBr4c1miRWrOJs8pBvhCTaAlxSMnQFwwRJ8qLoISWWK+Ly7Xeh3BUlDwXYmu5tAaYgqE1BP8LH4EWqJH3pQfuwahF8HdH1VUJPKTi1wsLBxAUhb4GuPdLKhWJbmQ6+TFtxuCugneYLzZwauS6llekbcIJ/37xj0mxmkT80xO8k2mZSRxeE9QCkL4+5xPmj3PO0H0guhVCK8dUdf/NaoD1izMJkQqwEOWYquWGQ91bpcktwBnLACOekOQbiFbbiJ5Tt5QFM84h2jFTiT3ELQaYaZFRJtmkdxF4JkYsWsAMohuo0XykvVsLMQmAFAuWqIf/4QOJLoLX4dExwnhaxgkq0GJmqitJnRFNZ2I+A3RLUTeuGCt/xLRGR7pBqcV+E5DJGWod1A++/SlBh3s0zRbde+Kt96uCviMc/JPVfiuqWY0PBf3/guUvLNmQY8SswAAAABJRU5ErkJggg==",
    Un = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHoAAAB6AgMAAAANN693AAAADFBMVEWPMP8AAACYQP+VOv9qJ9p2AAAABHRSTlMQAAULCS8cyAAAAdZJREFUSMft171twkAUB/CHLQoXRGkywo1AkVQZ4Qpsn4QL11EKj+AR0twIVGkYIFIYIQ0jpCBLEGMDT+d7H5Yo0uTf/tB94Pt4B7kYG/rL5/HH8/4BXdJD5Mh9DrS/wiUbytdwzR3lW8AsY18DYFIfeYuKDaCvIUgy9hrCmNALGGURuoNxfOBN5AYdmw87QHcQBx1HH3aAviM8Qy+BSIJeARV/9YZ0c/WW9OziBZCZXdzRnl7cAp392RvGzdlbxueDF8BkMXjJeTK4Ay6DW9b3vTesm95b1pe971jPTl4Am8XJS96Tkzve05NXwMd3bgXfd14L/tB5I7jpvBV82flO8HnnICRTfGGhkHxmoZQ8sbBS3EmeKg4Wqpv8DexN/qV6Lfr9v/+l699PXR/Vje5E1/fHSnRtf+r7u1DOh1zznXL+tMr59Sy40c5XxfcTzncn+JT7peB9pt1vyv04n3S/1sr9XLHue19xnCr1xax3foLZxPqmVuojx3h+9pLmZHB2gJlWH+r1pV6f6vUtNwCDTg7Ay/V5kqNTa2yJTnbg5ffFXY5OzcCM3EVLC534i7LIK/59FU/xUX7fpT7yYBl+55QXW2w9dvzBE/++fT+mx00euhj7C3T0aTRglpzkAAAAAElFTkSuQmCC",
    Qn = "/assets/rainbow.0b98f616.json",
    Hn = "/assets/wallet.43a456d9.json";
const G = {
    rainbow: Qn,
    wallet: Hn,
    sunflower: Mn,
    background: Wn,
    starone: Fn,
    startwo: On,
    wallet_bg: Un
};
var Xn = "/assets/one.e1362f4b.mp3";
const $n = new st({
        src: Xn
    }),
    Ce = a => _.get("/activity/redeemCode/useCode/" + a + "/"),
    Gn = M(function a({
        code: t,
        info: s,
        status: c = 0,
        error: r = "",
        isWelcome: i = !1
    }) {
        const m = p.exports.useRef(null),
            l = p.exports.useRef(null),
            [o, d] = p.exports.useState(!1),
            [k, b] = p.exports.useState(s),
            [D, C] = p.exports.useState(c),
            E = me(),
            v = w(),
            F = () => {
                U.settings.soundEffectEnable && $n.play()
            },
            L = v("page.shitcode.failed");
        p.exports.useEffect(() => {
            var g, x;
            if (D === 1) try {
                (g = m.current) == null || g.play(1), (x = l.current) == null || x.play(1), F()
            } catch (V) {}
        }, [D]), p.exports.useEffect(() => {
            c === 3 && Ce(t).then(g => {
                C(1), b({
                    currencyName: g.currencyName,
                    stringAmount: g.stringAmount
                })
            }).catch(g => {
                A(new Error(L + g.message)), R.close()
            })
        }, []);
        const h = () => n("div", {
                className: "area",
                children: [n("p", {
                    className: "big",
                    children: [v("common.congrats").toLocaleUpperCase(), "!"]
                }), n("p", {
                    className: "small",
                    children: [v("common.messages.got_shitlink"), "!"]
                }), e(S, {
                    type: "conic",
                    disabled: o,
                    onClick: () => {
                        N.userId > 0 ? (d(!0), Ce(t).then(g => {
                            E() && (C(1), b({
                                currencyName: g.currencyName,
                                stringAmount: g.stringAmount
                            }))
                        }).catch(g => {
                            E() && (A(new Error(L + g.message)), R.close())
                        }).finally(() => d(!1))) : (R.close(), ne("/login", {
                            replace: !0
                        }), N.waitLogin().then(() => {
                            R.push(e(a, {
                                code: t,
                                info: {
                                    currencyName: "BTC",
                                    stringAmount: "2"
                                },
                                status: 3
                            }))
                        }))
                    },
                    children: N.userId > 0 ? v("page.task.receive") : v("common.messages.sign_claim")
                })]
            }),
            u = g => n("div", {
                className: "award-info",
                children: [e("p", {
                    className: "award_one",
                    children: i ? v("common.welcome_bonus").toLocaleUpperCase() + "!" : v("page.vip.receive.congrats")
                }), n("p", {
                    className: "award_two",
                    children: [e(Jn, {
                        num: g.stringAmount
                    }), y.getAlias(g.currencyName)]
                }), e("p", {
                    className: "award_three first",
                    children: v("wallet.already_sentbalance")
                }), i ? e("p", {
                    className: "award_three",
                    children: v("common.messages.you_onboard")
                }) : null, e("p", {
                    className: "award_three",
                    children: i ? v("common.messages.wish_fun") + "!" : v("page.inviteIndex.lucky.part1.title")
                })]
            });
        return n("div", {
            className: jn,
            children: [e(it, {
                onClick: () => R.close()
            }), n("div", {
                className: "shitlink-main",
                children: [n("div", {
                    className: "shitlink-bg",
                    children: [e("img", {
                        className: "bg-two",
                        alt: "",
                        src: G.sunflower
                    }), n("div", {
                        className: "bg-three",
                        children: [e("div", {
                            className: "wallet-bg"
                        }), e(Ae, {
                            ref: m,
                            className: "wallet",
                            path: G.wallet
                        }), e("img", {
                            className: "one",
                            alt: "",
                            src: G.starone
                        }), e("img", {
                            className: "two",
                            alt: "",
                            src: G.startwo
                        }), e("img", {
                            className: "three",
                            alt: "",
                            src: G.startwo
                        })]
                    }), e(Ae, {
                        ref: l,
                        className: "bg-rainbow",
                        path: G.rainbow,
                        loop: !0
                    })]
                }), n("div", {
                    className: "mian-info",
                    children: [D === 0 && h(), D === 1 && u(k)]
                })]
            })]
        })
    }),
    Jn = j.memo(function({
        num: t
    }) {
        const s = p.exports.useRef(null);
        return p.exports.useEffect(() => {
            if (s.current) {
                const c = new O(t).toNumber(),
                    r = {
                        numb: 0
                    },
                    i = t.split("."),
                    m = 10 - i[0].length,
                    l = i.length > 1 ? i[1].length : 1,
                    o = Math.pow(10, l),
                    d = m > 0 ? m : 0;
                Be.to(r, {
                    numb: o,
                    duration: 1,
                    ease: "Linear.easeNone",
                    onUpdate: () => {
                        s.current && (s.current.innerHTML = (r.numb * c / o).toFixed(d))
                    }
                })
            }
        }, [t]), e("span", {
            ref: s,
            className: "scroll-number",
            children: "0"
        })
    }),
    jn = "sy078sv";
var ye = Gn,
    da = rt(function(t) {
        R.push(e(ye, {
            code: t,
            info: {
                currencyName: "BTC",
                stringAmount: "0.001"
            }
        })), _.get("/activity/redeemCode/findCode/" + t + "/").then(s => {
            R.push(e(ye, {
                code: t,
                info: {
                    currencyName: s.currencyName,
                    stringAmount: s.stringAmount
                }
            }))
        }).catch(s => {
            N.inited.then(() => {
                N.login ? (A(new Error("Failed to redeem shitlink. " + s.message)), ne(-1)) : ne("/spin", {
                    replace: !0
                })
            })
        })
    }, 1e3, {
        trailing: !1
    });
export {
    pa as Achieve, ia as CocoBonus, aa as CoindropReceive, sa as CoindropSend, ra as Promotion, oa as RainPage, la as RollPage, ye as Shitlink, ca as Sweetcodes, ga as Task, da as openShitlink
};
System.register(["./index-legacy.1416f96c.js"], (function(t) {
    "use strict";
    var e, n, r;
    return {
        setters: [function(t) {
            e = t.r, n = t.bb, r = t.ej
        }],
        execute: function() {
            t("u", (function(t, u) {
                var i = u && r(u);
                return e.exports.useState((function() {
                    return n(t(i), void 0, {
                        autoBind: !0
                    })
                }))[0]
            }))
        }
    }
}));
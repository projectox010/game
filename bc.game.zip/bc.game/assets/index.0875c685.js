import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as e
} from "./index.28e31dff.js";
var n = `<section>
  <h2>Terms of Service</h2>
  <p>This end user agreement (the "Agreement") should be read by you (the "User" or "you") in its entirety prior to your use of BC.GAME\u2019s service or products. Please note that the Agreement constitutes a legally binding agreement between you and BC.GAME (referred to herein as "BC.GAME", "us" or "we") which owns and operates the Internet site found and games described at BC.GAME (the "Service"). By clicking the "I Agree" button if and where provided and/or using the Service, you consent to the terms and conditions set forth in this Agreement.</p>
  <p>1. Grant of License</p>
  <ul class="content">
    <li>1.1. Subject to the terms and conditions contained herein, BC.GAME grants the User a non-exclusive, personal, non-transferable right to use the Service on your personal computer or other device that accesses the Internet in order to access the games ava</li>
    <li>1.2. The Service is not for use by (i) individuals under 18 years of age, (ii) individuals under the legal age of majority in their jurisdiction and (iii) individuals accessing the Service from jurisdictions from which it is illegal to do so. BC.GAME is not able to verify the legality of the Service in each jurisdiction and it is the User\u2019s responsibility to ensure that their use of the Service is lawful.</li>
    <li>1.3. BC.GAME and its licensors are the sole holders of all rights in and to the Service and code, structure and organization, including copyright, trade secrets, intellectual property and other rights. You may not, within the limits prescribed by applicable laws: (a) copy, distribute, publish, reverse engineer, decompile, disassemble, modify, or translate the website; or (b) use the Service in a manner prohibited by applicable laws or regulations (each of the above is an "Unauthorized Use"). BC.GAME reserves any and all rights implied or otherwise, which are not expressly granted to the User hereunder and retain all rights, title and interest in and to the Service. You agree that you will be solely liable for any damage, costs or expenses arising out of or in connection with the commission by you of any Unauthorized Use. You shall notify BC.GAME immediately upon becoming aware of the commission by any person of any Unauthorized Use and shall provide BC.GAME with reasonable assistance with any investigations it conducts in light of the information provided by you in this respect.</li>
    <li>1.4. The term "BC.GAME", its domain names and any other trade marks, or service marks used by BC.GAME as part of the Service (the "Trade Marks"), are solely owned by BC.GAME In addition, all content on the website, including, but not limited to, the images, pictures, graphics, photographs, animations, videos, music, audio and text (the "Site Content") belongs to BC.GAME and is protected by copyright and/or other intellectual property or other rights. You hereby acknowledge that by using the Service, you obtain no rights in the Site Content and/or the Trade Marks, or any part thereof. Under no circumstances may you use the Site Content and/or the Trade Marks without BC.GAME\u2019s prior written consent. Additionally, you agree not to do anything that will harm or potentially harm the rights, including the intellectual property rights of BC.GAME</li>
  </ul>
  <p>2. No Warranties</p>
  <ul class="content">
    <li>2.1. BC.GAME disclaims any and all warranties, expressed or implied, in connection with the service which is provided to you "as is" and we provide you with no warranty or representation whatsoever regarding its quality, fitness for purpose, completeness or accuracy.</li>
    <li>2.2. Regardless of BC.GAME\u2019s efforts, BC.GAME makes no warranty that the service will be uninterrupted, timely or error-free, or that defects will be corrected.</li>
  </ul>  
  <p>3. Authority/Terms of Service You agree to the game rules described on the BC.GAME website. BC.GAME retains authority over the issuing, maintenance, and closing of the Service. The decision of BC.GAME\u2019s management, concerning any use of the Service, or dispute resolution, is final and shall not be open to review or appeal.</p>
  <p>4. Your Obligations as a Player</p>
  <p>4.1. You hereby declare and warrant that:</p>
  <ul class="content">
    <li>4.1.1. You are over 18 years of age or such a higher minimum legal age of majority as stipulated if the jurisdiction of Your residence (e.g. Estonia \u2013 21 years) and, under the laws applicable to You, legally allowed to participate in the Games offered on the Website.</li>
    <li>4.1.2. You participate in the Games strictly in your personal non-professional capacity for recreational and entertainment reasons only.</li>
    <li>4.1.3. You participate in the Games on your own behalf and not on behalf of any other person.</li>
    <li>4.1.4. All information that You provide to BC.GAME during the term of validity of this agreement is true, complete, and correct, and that You shall immediately notify BC.GAME of any change of such information.</li>
    <li>4.1.5. You are solely responsible for reporting and accounting for any taxes applicable to You under relevant laws for any winnings that You receive from BC.GAME.</li>
    <li>4.1.6. You understand that by participating in the Games you take the risk of losing Virtual Funds deposited into Your Member Account.</li>
    <li>4.1.7. You shall not be involved in any fraudulent, collusive, fixing or other unlawful activity in relation to Your or third parties\u2019 participation in any of the Games and shall not use any software- assisted methods or techniques or hardware devices for Your participation in any of the Games. BC.GAME hereby reserves the right to invalidate any wager in the event of such behaviour.</li>
    <li>4.1.8. You understand that Virtual Funds as Bitcoin are not considered a legal currency or tender and as such on the Website they are treated as virtual funds with no intrinsic value.</li>
    <li>4.1.9. You understand that Bitcoin value can change dramatically depending on the market value.</li>
    <li>4.1.10. You are not allowed to use any payment methods that belong to a Third party or person.</li>
  </ul>
  <p>4.2. You are not allowed to transfer, sell and/or acquire, user accounts.</p>
  <p>4.3. Games played on Our site should be played in the same manner as games played in any other setting. This means that players should be courteous to each other and avoid rude or obscene comments.</p>
  <p>4.4. Some circumstances may arise where a wager is confirmed, or a payment is performed by us in error. In all these cases BC.GAME reserves the right to cancel all the wagers accepted containing such an error.</p>
  <p>4.5. Should the user become aware of possible errors or incompleteness in the software, he/she agrees to refrain from taking advantage of them. Moreover, the user agrees to report any error or incompleteness immediately to BC.GAME Should the user fail to fulfil the obligations stated in this clause, BC.GAME has a right to full compensation for all costs related to the error or incompleteness, including any costs incurred in association with the respective error/incompleteness and the failed notification by the user.</p>
  <p>4.6. In the event a game is started but miscarried because of a failure of the system, BC.GAME shall refund the amount wagered in the game to the User by crediting it to the User\u2019s Account or, if the account no longer exists, by paying it to the User in an approved manner; and if the User has an accrued credit at the time the game miscarried, credit to the User\u2019s Account the monetary value of the credit or, if the account no longer exists, pay it to the User in an approved manner.</p>
  <p>4.7. BC.GAME reserves the right to reject or limit wagers. The user is not permitted to wager an amount exceeding his/her personal account. Wins are credited to the personal account of the user.</p>
  <p>4.8. BC.GAME reserves the right to retain payments, if suspicion or evidence exists of manipulation of the casino system. Criminal charges will be brought against any user or any other person(s), who has/have manipulated the casino system or attempted to do so. BC.GAME reserves the right to terminate and/or, change any games or events being offered on the Website.</p>
  <p>4.9. We reserve the right to require some verification in case of suspicious or fraudulent transactions.</p>
  <p>4.10. BC.GAME reserves the right to declare a wager void partially or in full if BC.GAME, at its own discretion, would deem it obvious that any of the following circumstances have occurred:</p>
  <ul class="content">
    <li>4.10.1. You, or people associated with you may directly or indirectly influence the outcome of an event, to obtain an unlawful advantage,</li>
    <li>4.10.2. You and or people associated with you are directly or indirectly avoiding the rules of BC.GAME</li>
    <li>4.10.3. The result of an event has been directly or indirectly affected by criminal activity.</li>
    <li>4.10.4. Wagers have been placed that would not have been accepted otherwise, but that were accepted during periods when the website have been affected by technical problems.</li>
    <li>4.10.5. Due to an error, such as a, misprint, technical error, force majeure or otherwise, wagers have been offered, placed and or accepted due to this error.</li>
    <li>4.10.6. If a player's deposit fee is too low and is flagged by blockchain or similar site as \u201Cnot enough fee to relay\u201D BC.GAME reserve the right to confiscate the winnings if BC.GAME at their own discretion deem the transaction and behavior of the player to be fraudulent in nature.</li>
  </ul>
  <p>4.11. You will inform BC.GAME immediately if you enter into a self-exclusion agreement with any gambling provider.</p>
  
  <p>5. Prohibited Uses</p>
  <p>5.1. PERSONAL USE. The Service is intended solely for the User\u2019s personal use. The User is only allowed to wager for his/her personal entertainment and may not create multiple accounts, including for the purpose of collusion and/or abuse of service.</p>
  <p>5.2. JURISDICTIONS. Persons located in or residents of Aruba, Bonaire, Curacao, Costa Rica, France, Netherlands, Saba, Statia, St Martin, USA (the \u201DProhibited Jurisdictions\u201D) are not permitted make use of the Service. For the avoidance of doubt, the foregoing restrictions on engaging in real-money play from Prohibited Jurisdictions applies equally to residents and citizens of other nations while located in a Prohibited Jurisdiction. Any attempt to circumvent the restrictions on play by any persons located in a Prohibited Jurisdiction or Restricted Jurisdiction, is a breach of this Agreement. An attempt at circumvention includes, but is not limited to, manipulating the information used by BC.GAME to identify your location and providing BC.GAME with false or misleading information regarding your location or place of residence.</p>
  
  <p>6. Know your Customer (\u201CKYC\u201D)</p>
  <p>BC.GAME reserves the right, at any time, to ask for any KYC documentation it deems necessary to determine the identity and location of a User. BC.GAME reserves the right to restrict service and payment until identity is sufficiently determined.</p>
  
  <p>7. Breach</p>
  <p>7.1. Without prejudice to any other rights, if a User breaches in whole or in part any provision contained herein, BC.GAME reserves the right to take such action as it sees fit, including terminating this Agreement or any other agreement in place with the User and/or taking legal action against such User.</p>
  <p>7.2. You agree to fully indemnify, defend and hold harmless BC.GAME and its shareholders, directors, agents and employees from and against all claims, demands, liabilities, damages, losses, costs and expenses, including legal fees and any other charges whatsoever, howsoever caused, that may arise as a result of: (i) your breach of this Agreement, in whole or in part; (ii) violation by you of any law or any third party rights; and (iii) use by you of the Service.</p>
  
  <p>8. Limitations and Liability</p>
  <p>8.1. Under no circumstances, including negligence, shall BC.GAME be liable for any special, incidental, direct, indirect or consequential damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out of the use (or misuse) of the Service even if BC.GAME had prior knowledge of the possibility of such damages.</p>
  <p>8.2. Nothing in this Agreement shall exclude or limit BC.GAME\u2019s liability for death or personal injury resulting from its negligence.</p>
  
  <p>9. Disputes</p>
  <p>If a User wishes to make a complaint, please contact BC.GAME\u2019s customer service team at support@BC.GAME. Should any dispute not be resolved to your satisfaction you may pursue remedies in the governing law jurisdiction set forth below.</p>
  
  <p>10. Amendment</p>
  <p>BC.GAME reserves the right to update or modify this Agreement or any part thereof at any time or otherwise change the Service without notice and you will be bound by such amended Agreement upon posting. Therefore, we encourage you to check the terms and conditions contained in the version of the Agreement in force at such time. Your continued use of the Service shall be deemed to attest to your agreement to any amendments to the Agreement.</p>
  
  <p>11. Governing Law</p>
  <p>The Agreement and any matters relating thereto shall be governed by, and construed in accordance with, the laws of Costa Rica. You irrevocably agree that, subject as provided below, the courts of Costa Rica shall have exclusive jurisdiction in relation to any claim, dispute or difference concerning the Agreement and any matter arising therefrom and irrevocably waive any right that it may have to object to an action being brought in those courts, or to claim that the action has been brought in an inconvenient forum, or that those courts do not have jurisdiction. Nothing in this clause shall limit the right of BC.GAME to take proceedings against you in any other court of competent jurisdiction, nor shall the taking of proceedings in any one or more jurisdictions preclude the taking of proceedings in any other jurisdictions, whether concurrently or not, to the extent permitted by the law of such other jurisdiction.</p>
  <p>If a provision of this Agreement is or becomes illegal, invalid or unenforceable in any jurisdiction, that shall not affect the validity or enforceability in that jurisdiction of any other provision hereof or the validity or enforceability in other jurisdiction of that or any other provision hereof.</p>
  
  <p>13. Assignment</p>
  <p>BC.GAME reserves the right to assign this agreement, in whole or in part, at any time without notice. The User may not assign any of his/her rights or obligations under this Agreement.</p>
  
  <p>14. ADVANTAGE PLAY</p>
  <p>Should the Casino become aware of any user who has accepted the bonus or a promotion with sole purpose of creating a positive expected value on bonus return by using known practices aimed at securing a cash out of said bonus or at any way try to take advantage of bonuses received by BC.GAME, then BC.GAME will enforce immediate confiscation of winnings and closure of the account with the right to withhold any further withdrawals. An example of advantage play would be delaying any game round in any game, including free spins features and bonus features, to a later time when you have no more wagering requirement and/or performing new deposit(s) while having free spins features or bonus features still available in a game. In the interests of fair gaming, equal, zero or low margin bets or hedge betting, shall all be considered irregular gaming for bonus play- through requirement purposes. Should the Casino deem that irregular game play has occurred, the Casino reserves the right to withhold any withdrawals and/or confiscate all winnings.</p>
</section>

<section>
  <h2>User Agreement</h2>
  <p>Definitions; BC.GAME is referred to as 'we' or 'us'.</p>
  <p>The Player is referred to as "you" or 'the Player'.</p>
  <p>'The Website' means BC.GAME through desktop, mobile or other platforms utilised by the Player.</p>
  <p>https://BC.GAME/help/terms-service</p>
</section>

<section>
  <h2>Definitions</h2>
  <p>BC.GAME is referred to as 'we' or 'us'</p>
  <p>The Player is referred to as "you" or 'the Player'</p>
  <p>'The Website' means BC.GAME through desktop, mobile or other platforms utilised by the Player</p>
   
  <p>1. General</p>
  <ul class="content">
    <li>1.1. This User Agreement applies to the usage of games accessible through BC.GAME.</li>
    <li>1.2. This User Agreement comes into force as soon as you complete the registration process, which includes checking the box accepting this User Agreement and successfully creating an account. By using any part of the Website following account creation, you agree to this User Agreement.</li>
    <li>1.3. You must read this User Agreement carefully in their entirety before creating an account. If you do not agree with any provision of this User Agreement, you must not create an account or continue to use the Website.</li>
    <li>1.4. We are entitled to make amendments to this User Agreement at any time and without advanced notice. If we make such amendments, we may take appropriate steps to bring such changes to your attention (such as by e-mail or placing a notice on a prominent position on the Website, together with the amended User Agreement) but it shall be your sole responsibility to check for any amendments, updates and/or modifications. Your continued use of BC.GAME services and Website after any such amendment to the User Agreement will be deemed as your acceptance and agreement to be bound by such amendments, updates and/or modifications.</li>
    <li>1.5. this User Agreement may be published in several languages for informational purposes and ease of access by players. The English version is the only legal basis of the relationship between you and us and in the case of any discrepancy with respect to a translation of any kind, the English version of this User Agreement shall prevail.</li>
  </ul>
  
  <p>2. Binding Declarations</p>
  <p>2.1. By agreeing to be bound by this User Agreement, you also agree to be bound by the BC.GAME Rules and Privacy Policy that are hereby incorporated by reference into this User Agreement. In the event of any inconsistency, this User Agreement will prevail. You hereby represent and warrant that:</p>
  <ul class="content">
    <li>2.1.1. You are over (a) 18 or (b) such other legal age or age of majority as determined by any laws which are applicable to you, whichever age is greater;</li>
    <li>2.1.2. You have full capacity to enter into a legally binding agreement with us and you are not restricted by any form of limited legal capacity;</li>
    <li>2.1.3. All information that you provide to us during the term of validity of this agreement is true, complete, correct, and that you shall immediately notify us of any change of such information;</li>
    <li>2.1.4. You are solely responsible for reporting and accounting for any taxes applicable to you under relevant laws for any winnings that you receive from us;</li>
    <li>2.1.5. You understand that by using our services you take the risk of losing money deposited into your Member Account and accept that you are fully and solely responsible for any such loss;</li>
    <li>2.1.6. You are permitted in the jurisdiction in which you are located to use online casino services;</li>
    <li>2.1.7. In relation to deposits and withdraws of funds into and from your Member Account, you shall only use Cryptocurrency that are valid and lawfully belong to you;</li>
    <li>2.1.8. You understand that the value of Cryptocurrency can change dramatically depending on the market value;</li>
    <li>2.1.9. The computer software, the computer graphics, the Websites and the user interface that we make available to you are owned by BC.GAME or its associates and is protected by copyright laws. You may only use the software for your own personal, recreational uses in accordance with all rules, User Agreement we have established and in accordance with all applicable laws, rules and regulations;</li>
    <li>2.1.10. You understand that Cryptocurrency is not considered a legal currency or tender and as such on the Website they are treated as virtual funds with no intrinsic value.</li>
    <li>2.1.11. You affirm that you are not an officer, director, employee, consultant or agent of BC.GAME or working for any company related to BC.GAME, or a relative or spouse of any of the foregoing;</li>
    <li>2.1.12. You are not diagnosed or classified as a compulsive or problem gambler. We are not accountable if such problem gambling arises whilst using our services but will endeavor to inform of relevant assistance available. We reserve the right to implement cool off periods if we believe such actions will be of benefit.</li>
    <li>2.1.13. You accept and acknowledge that we reserve the right to detect and prevent the use of prohibited techniques, including but not limited to fraudulent transaction detection, automated registration and signup, gameplay and screen capture techniques. These steps may include, but are not limited to, examination of Players device properties, detection of geo-location and IP masking, transactions and blockchain analysis;</li>
    <li>2.1.14. You accept our right to terminate and/or change any games or events being offered on the Website, and to refuse and/or limit bets.</li>
    <li>2.1.15. You accept that we have the right to ban/block multiple accounts and freely control the assets in such accounts.</li>
    <li>2.1.16. You are aware of possible errors or incompleteness in the software, you agree to refrain from taking advantage of them. Moreover, you agree to report any error or incompleteness immediately to BC.GAME. Should you fail to fulfil the obligations stated in this clause, BC.GAME has a right to full compensation for all costs related to the error or incompleteness, including any costs incurred in association with the respective error/incompleteness and the failed notification by the user.</li>
    <li>2.1.17. You are aware of that BC.GAME has the right to carry out \u201CKYC\u201D (Know Your Customer) verification procedures. The access to your user account may be blocked or closed if we determine that you have supplied false or misleading information.</li>
  </ul>

  <p>2.2. We reserve the right to declare a wager void partially or in full if BC.GAME, at its own discretion, would deem it obvious that any of the following circumstances have occurred:</p>
  <ul class="content">
    <li>2.2.1. You, or people associated with you, may directly or indirectly influence the outcome of an event, to obtain an unlawful advantage.</li>
    <li>2.2.2. You and or people associated with you are directly or indirectly avoiding the rules of BC.GAME.</li>
    <li>2.2.3. The result of an event has been directly or indirectly affected by criminal activity.</li>
    <li>2.2.4. Wagers have been placed that would not have been accepted otherwise, but that were accepted during periods when the website has been affected by technical problems.</li>
    <li>2.2.5. Due to an error, such as a mistake, vulnerabilities, technical error, force majeure or otherwise, wagers have been offered, placed and or accepted due to this error.</li>
    <li>2.2.6. If a player's deposit fee is too low and is flagged by blockchain or similar site as \u201Cnot enough fee to relay\u201D BC.GAME reserves the right to confiscate the winnings if BC.GAME at their own discretion deems the transaction and behavior of the player to be fraudulent in nature.</li>
  </ul>
  
  <p>3. Restricted Territories</p>
  <ul class="content">
    <li>3.1. Blacklisted Territories: China, Netherlands, Dutch Caribbean Islands, Curacao, France, United States and/or any other restricted by law country or state. Note that it is strictly forbidden to play on BC.GAME games in blacklisted countries mentioned above.your personal data for the purpose of executing their duties and providing you with the best possible assistance and service. You hereby consent to such disclosures.</li>
  </ul>
  
  <p>4. General Betting Rules</p> 
  <ul class="content">
    <li>4.1. A bet can only be placed by a registered account holder.</li>
    <li>4.2. A bet can only be placed over the internet.</li>
    <li>4.3. You can only place a bet if you have a sufficient balance in your account with BC.GAME.</li>
    <li>4.4. The bet, once concluded, will be governed by the version of the User Agreement valid and available on the Website at the time of the bet being accepted.</li>
    <li>4.5. Any payout of a winning bet is credited to your account, consisting of the stake multiplied by the odds at which the bet was placed.</li>
    <li>4.6. BC.GAME reserves the right to adjust a bet payout credited to a BC.GAME account if it is determined by BC.GAME in its sole discretion that such a payout has been credited due to an error.</li>
    <li>4.7. A bet, which has been placed and accepted, cannot be amended, withdrawn, or cancelled by you.</li>
    <li>4.8. The list of all the bets, their status and details are available to you on the Website.</li>
    <li>4.9. When you place a bet you acknowledge that you have read and understood in full all of this User Agreement regarding the bet as stated on the Website.</li>
    <li>4.10. BC.GAME manages your account, and calculates the available funds, the pending funds, the betting funds as well as the amount of winnings. Unless proven otherwise, these amounts are considered as final and are deemed to be accurate.</li>
    <li>4.11. You are fully responsible for the bets placed.</li>
    <li>4.12. Winnings will be paid into your account after the final result is confirmed.</li>
  </ul>
  
  <p>5. Bonuses and Promotions</p> 
  <ul class="content">
    <li>5.1. BC.GAME reserves the right to cancel any promotion, bonus or bonus program (including, but not limited to top-up rewards, invite friends to reward bonuses and loyalty programs) with immediate effect if we believe the bonus has been set up incorrectly or is being abused, and if the said bonus has been paid out, we reserve the right to decline any Withdraw request and to deduct such amount from your account. Whether or not a bonus is deemed to be set up incorrectly or abused shall be determined solely by BC.GAME.</li>
    <li>5.2. If you use a Deposit Bonus, no Withdraw of your original deposit will be accepted before you have reached the requirements stipulated under the User Agreement of the Deposit Bonus.</li>
    <li>5.3. Where any term of the offer or promotion is breached or there is any evidence of a series of bets placed by a customer or group of customers, which due to a deposit bonus, enhanced payments, free bets, risk free bets or any other promotional offer results in guaranteed customer profits irrespective of the outcome, whether individually or as part of a group, BC.GAME reserves the right to reclaim the bonus element of such offers and in their absolute discretion either settle bets at the correct odds, void the free bet bonus and risk free bets or void any bet funded by the deposit bonus. In addition, BC.GAME reserves the right to levy an administration charge on the customer up to the value of the deposit bonus, free bet bonus, risk free bet or additional payment to cover administrative costs. We further reserve the right to ask any customer to provide sufficient documentation for us to be satisfied in our absolute discretion as to the customer's identity prior to us crediting any bonus, free bet, risk free bet or offer to their account.</li>
    <li>5.4. All BC.GAME offers are intended for recreational players and BC.GAME may in its sole discretion limit the eligibility of customers to participate in all or part of any promotion.</li>
    <li>5.5. BC.GAME reserves the right to amend, cancel, reclaim or refuse any promotion at its own discretion.</li>
    <li>5.6. Bonuses can only be received once per person/account, family, household, address, e-mail address, IP addresses and environments where computers are shared (university, fraternity, school, public library, workplace, etc.). The Operator reserves the right to close your account and confiscate any existing funds if evidence of abuse/fraud is found.</li>
    <li>5.7. You acknowledge and understand that separate User Agreement exist with respect to promotions, bonuses and special offers, and are in addition to this User Agreement. This User Agreement is set forth in the respective content page on this website, or have been made available to you personally, as the case may be. In the event of a conflict between the provisions of such promotions, bonuses and special offers, and the provisions of this User Agreement, the provisions of such promotions, bonuses and special offers will prevail.</li>
    <li>5.8. We may insist that you bet a certain amount of your own deposit before you can bet with any free/bonus funds we credit to your account.</li>
    <li>5.9. You accept that certain promotions may be subject to Withdraw restrictions and/or requirements which need to be met before funds credited under the promotion can be withdrawn. Such terms shall be duly published and made available as part of the promotion. If you opt to make a Withdraw before the applicable wagering requirements are fulfilled, we will deduct the whole bonus amount as well as any winnings connected with the use of the bonus amounts before approving any Withdraw.</li>
  </ul>
  
  <p>6. Live Chat</p>
  <p>6.1. As part of your use of the Website we may provide you with a live chat facility, which is moderated by us and subject to controls. We reserve the right to review the chat and to keep a record of all statements made on the facility. Your use of the chat facility should be for recreational and socialising purposes.</p>
  <p>6.2. We have the right to remove the chat room functionality or immediately terminate your Member Account and refund your account balance if you:</p>
  <ul class="content">
    <li>(a) make any statements that are sexually explicit or grossly offensive, including expressions of bigotry, racism, hatred or profanity;</li>
    <li>(b) make statements that are abusive, defamatory or harassing or insulting;</li>
    <li>(c) use the chat facility to advertise, promote or otherwise relate to any other online entities;</li>
    <li>(d) make statements about BC.GAME, or any other Internet site(s) connected to the Website that are untrue and/or malicious and/or damaging to BC.GAME;</li>
    <li>(e) user the chat facility to collude, engage in unlawful conduct or encourage conduct we deem seriously inappropriate. Any suspicious chats will be reported to the competent authority.</li>
  </ul>
  
  <p>6.3. Live Chat is used as a form of communication between us and you and should not be copied or shared with any forums or third parties.</p>

  <p>7. Limitation of Liability</p>
  <ul class="content">
    <li>7.1. You enter the Website and participate in the Games at your own risk. The Websites and the Games are provided without any warranty whatsoever, whether expressed or implied.</li>
    <li>7.2. Without prejudice to the generality of the preceding provision, we, our directors, employees, partners, service providers.</li>
    <li>7.3. Do not warrant that the software, Games and the Websites are fit for their purpose.</li>
    <li>7.4. Do not warrant that the software, Games and the Websites are free from errors.</li>
    <li>7.5. Do not warrant that the software, Games and the Websites will be accessible without interruptions.</li>
    <li>7.6. Shall not be liable for any loss, costs, expenses or damages, whether direct, indirect, special, consequential, incidental or otherwise, arising in relation to your use of the Websites or your participation in the Games.</li>
    <li>7.7. You understand and acknowledge that, if there is a malfunction in a Game or its interoperability, any bets made during such a malfunction shall be void. Funds obtained from a malfunctioning Game shall be considered void, as well as any subsequent game rounds with said funds, regardless of what Games are played using such funds.</li>
    <li>7.8. You hereby agree to fully indemnify and hold harmless us, our directors, employees, partners, and service providers for any cost, expense, loss, damages, claims and liabilities howsoever caused that may arise in relation to your use of the Website or participation in the Games.</li>
    <li>7.9. To the extent permitted by law, our maximum liability arising out of or in connection with your use of the Websites, regardless of the cause of actions (whether in contract, tort, breach of warranty or otherwise), will not exceed \u20AC100.</li>
  </ul>

  <p>8. Breaches, Penalties and Termination</p>
  <ul class="content">
    <li>8.1. If you breach any provision of this User Agreement or we have a reasonable ground to suspect that you have breached them, we reserve the right to not open, to suspend, or to close your Member Account, or withhold payment of your winnings and apply such funds to any damages due by you.</li>
    <li>8.2. You acknowledge that BC.GAME shall be the final decision-maker of whether you have violated BC.GAME\u2019s rules, terms or conditions in a manner that results in your suspension or permanent barring from participation in our site.</li>
  </ul>

  <p>9. Self-exclusion</p>
  <ul class="content">
    <li>9.1. By requesting a period of self-exclusion, you agree to follow the below terms and conditions, which will be in effect from the time that CS implements the chosen period of self-exclusion.</li>
    <li>9.2. You may self-exclude for periods of 1, 3, 6, 12 month/s or permanent. Self-exclusion requests are to be made via Live Support.</li>
    <li>9.3. Once you have self-excluded you will not be able to access your account or withdraw during this period.</li>
    <li>9.4. If you have excluded your account whilst you have pending bets on your account, bets placed will remain valid and settle according to official results. </li>
    <li>9.5. Once the period of self-exclusion has lapsed you may withdraw winnings from qualifying bets. BC.GAME does not cancel or void any bets placed before a self-exclusion has been affected.</li>
    <li>9.6. Once you have self-excluded you will not be able to change or alter the period for a shorter length of time or have your self-exclusion cancelled until the period that you selected for self-exclusion has passed.</li>
    <li>9.7. Please contact our customer services team if you wish to extend your self-exclusion period.</li>
    <li>9.8. Once your self-exclusion period has elapsed, reinstatement of the account can be done by emailing the request to support@BC.GAME.</li>
    <li>9.9. By self-excluding, you agree that:</li>
    <ul class="content">
      <li>  a) You will not create another account during this period.</li>
      <li>  b) You will not deposit or attempt to deposit funds into a BC.GAME account. </li>
      <li>  c) You will not wager on this website during this period.</li>
      <li>  d) This is a voluntary act initiated by yourself, and BlockDance B.V. will not be liable for any losses you may incur during the period of self-exclusion in any form.</li>
    </ul>
  </ul>
</section>
<section>
  <h2>Privacy Policy</h2>  
  <p> You hereby acknowledge and accept that if we deem necessary, we are able to collect and otherwise use your personal data in order to allow you access and use of the Websites and in order to allow you to participate in the Games.</p>
  <p>We hereby acknowledge that in collecting your personal details as stated in the previous provision, we are bound by the Data Protection Act. We will protect your personal information and respect your privacy in accordance with best business practices and applicable laws.</p>
  <p>We will use your personal data to allow you to participate in the Games and to carry out operations relevant to your participation in the Games. We may also use your personal data to inform you of changes, new services and promotions that we think you may find interesting. If you do not wish to receive such direct marketing correspondences, you may opt out of the service.</p>
  <p>Your personal data will not be disclosed to third parties, unless it is required by law. As BC.GAME business partners or suppliers or service providers may be responsible for certain parts of the overall functioning or operation of the Website, personal data may be disclosed to them. The employees of BC.GAME have access to your personal data for the purpose of executing their duties and providing you with the best possible assistance and service. You hereby consent to such disclosures.</p>
  <p>We shall keep all information provided as personal data. You have the right to access personal data held by us about you. No data shall be destroyed unless required by law, or unless the information held is no longer required to be kept for the purpose of the relationship.</p>
  <p>In order to make your visit to the Websites more user-friendly, to keep track of visits to the Websites and to improve the service, we collect a small piece of information sent from your browser, called a cookie. You can, if you wish, turn off the collection of cookies. You must note, however, that turning off cookies may severely restrict or completely hinder your use of the Websites.</p>
</section>
  <section>
    <h2>Cookies Policy</h2>
  <p>1.What are cookies?</p>
  <ul class="content">
    <li>A cookie is a piece of information in the form of a very small text file that is placed on an internet user's computer. It is generated by a web page server (which is basically the computer that operates the website) and can be used by that server whenever the user visits the site. A cookie can be thought of as an internet user's identification card, which tells a website when the user has returned. Cookies can't harm your computer and we don't store any personally identifiable information about you on any of our cookies.</li>
  </ul>
  <p>2.Why do we use cookies on BC.GAME?</p>
  <ul class="content">
    <li>BC.GAME uses two types of cookies: cookies set by us and cookies set by third parties (i.e. other websites or services). BC.GAME cookies enable us to keep you signed in to your account throughout your visit and to tailor the information displayed on the site to your preferences.</li>
  </ul>
  <p>3.What cookies do we use on BC.GAME?</p>
  <p>Below is a list of the main cookies set by BC.GAME, and what each is used for:</p>
  <ul class="content">
    <li>_fp - stores browser's fingerprint. Lifetime: forever.</li>
    <li>_t - stores timestamp when user firstly visited site in current browsing session. Needed for unique visits statistic. Lifetime: browsing session.</li>
    <li>_r - stores http referrer for current browsing session. Needed in order to external track traffic sources. Lifetime: browsing session.</li>
    <li>_c - stores identifier of affiliate campaign. Needed for affiliate statistic. Lifetime: forever.</li>
    <li>Cookies set by third parties for wildcard domain: *.BC.GAME</li>
    <li>Google analytics: _ga, _gat, _gid</li>
    <li>Zendesk\uFF1A__ zlcmid</li>
    <li>Cloudflare\uFF1A__ cfuid</li>
    <li>Please keep in mind that some browsers (i.e. chrome on mac) keep background processes running even if no tabs opened due to this session cookies may left set between sessions.</li>
    <li>There are also cookies set by third party scripts to their domains.</li>
  </ul>
  
  
  <p>4.How can I manage my cookies on BC.GAME?</p>
  <ul class="content">
    <li>If you wish to stop accepting cookies, you can do so through the Privacy Settings option in your browser.</li>
  </ul>
  
  <p>5.Personal Data Protection Policy</p>
  <ul class="content">
    <li>BC.GAME\u2019s mission is to keep your Data safe and for this matter we protect your data in various ways. We provide our customers with high security standards, such as encryption of data in motion over public networks, encryption of data in database, auditing standards, Distributed Denial of Service mitigations, and a Live Chat available on-site.</li>
  </ul>

  <p>6.Server Protection Policy</p>
  <ul class="content">
    <li>All servers have full encryption;</li>
    <li>All backups have encryption;</li>
    <li>Firewalls, VPN Access;</li>
    <li>Access to servers allowed only over VPN;</li>
    <li>All http/s services work over Cloudflare;</li>
    <li>Connections to nodes over VPN;</li>
    <li>SSH port forwarding tunnels;</li>
    <li>Services allowed only over VPN;</li>
    <li>Server have firewall and allowed only SSH port;</li>
    <li>Alerts on critical services.</li>
    <li>Data Breach Notification</li>
    <li>When BC.GAME will be made aware of personal data breaches we will notify relevant users in accordance with GDPR timeframes.</li>
  </ul>
  
  <p>7.Data International Transfer</p>
  <ul class="content">
    <li>We only disclose personal data to third parties where it is necessary to provide the high-quality service or in order to respond lawful requests from authorities.</li>
    <li>We share the following data to third party systems:</li>
    <li>Zendesk Inc. \u2013 username and e-mail information is transferred if user sends a message to live-chat or sends an e-mail to support mailbox.</li>
    <li>Although we try to do our best, problems could occur now and then. Our team will do everything we could to solve your problems as soon as possible. To assist you quicker, You can join us by clicking the button above to join the telegram group.</li>
    <li>If an error occurs, please provide the following information:</li>
    <ul class="content">
      <li>Username</li>
      <li>Date and time of the problem</li>
    </ul>
  </ul>
  
  <p>Game ID or table name, if any</p>
  <p>Screenshot of the error, if possible</p>
  <p>We really appreciate your help and the error report you provided because your information report could help us improve.</p>
  <p>Collecting and Using Your Personal Data</p>
  <p>Types of Data Collected</p>
  <p>Personal Data</p>
  <p>While using Our Service, We may ask You to provide Us with certain personally identifiable information that can be used to contact or identify You. Personally identifiable information may include, but is not limited to:</p>
  <p>Email address</p>
  <p>First name and last name</p>
  <p>Usage Data</p>
  <p>Usage Data</p>
  <p>Usage Data is collected automatically when using the Service.</p>
  <p>Usage Data may include information such as Your Device's Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that You visit, the time and date of Your visit, the time spent on those pages, unique device identifiers and other diagnostic data.</p>
  <p>When You access the Service by or through a mobile device, We may collect certain information automatically, including, but not limited to, the type of mobile device You use, Your mobile device unique ID, the IP address of Your mobile device, Your mobile operating system, the type of mobile Internet browser You use, unique device identifiers and other diagnostic data.</p>
  <p>We may also collect information that Your browser sends whenever You visit our Service or when You access the Service by or through a mobile device.</p>
  <p>Information from Third-Party Social Media Services</p>
  <p>BC.GAME allows You to create an account and log in to use the Service through the following Third-party Social Media Services:</p>
  <ul class="content">
    <li>Google</li>
    <li>Facebook</li>
    <li>Telegram</li>
    <li>Metamask</li>
  </ul>
  </section>
  <section>
  <h2>Web3.0</h2>
  <p>If You decide to register through or otherwise grant us access to a Third-Party Social Media Service, We may collect Personal data that is already associated with Your Third-Party Social Media Service's account, such as Your name, Your email address, Your activities or Your contact list associated with that account.</p>
  <p>You may also have the option of sharing additional information with the BC.GAME through Your Third-Party Social Media Service's account. If You choose to provide such information and Personal Data, during registration or otherwise, You are giving BC.GAME permission to use, share, and store it in a manner consistent with this Privacy Policy.</p>
  <p>Delete Personal Data</p>
  <p>You can request to have your personal data deleted if BC.GAME no longer have a legal reason to continue to process or store it. Please note that this right is not guaranteed - in the sense that BC.GAME do not have the ability to comply with your request if it is subject to a legal obligation to store your data. You can request the deletion of your personal data by sending an email to support@BC.GAME.</p>
  </section>
  <section>
    <h2>Registration and Login</h2>
    <p>You must be at least 18 years old to register. If you want to add your email address, please make sure the email address you entered is correct so that later it can be used in KYC account verification.</p>
    <p>You can login at any time. For added security, we recommend you to add 2FA. To know more about Google authenticator.</p>
    <p>If you need to change your registered email, we are so sorry, but we are not able to update this information. If you insist on changing your username and/or registered email, we suggest you close the current account and register a new one.</p>
  </section>
</section>

`,
    i = `<section>\r
  <h2>Termos de servi\xE7o</h2>\r
  <p>Este contrato de usu\xE1rio final (o "Contrato") deve ser lido por voc\xEA (o "Usu\xE1rio" ou "voc\xEA") em sua totalidade antes do uso dos servi\xE7os ou produtos da BC.GAME. Observe que o Contrato constitui um contrato juridicamente vinculativo entre voc\xEA e BC.GAME (referido aqui como "BC.GAME", "n\xF3s" ou "n\xF3s"), que possui e opera o site da Internet encontrado e os jogos descritos em BC.GAME (o "Servi\xE7o") . Ao clicar no bot\xE3o "Concordo" se e onde fornecido e/ou usando o Servi\xE7o, voc\xEA concorda com os termos e condi\xE7\xF5es estabelecidos neste Contrato.</p>\r
  <p>1. Concess\xE3o de licen\xE7a</p>\r
  <ul>\r
    <li>1.1. Sujeito aos termos e condi\xE7\xF5es aqui contidos, BC.GAME concede ao Usu\xE1rio um direito n\xE3o exclusivo, pessoal e intransfer\xEDvel de usar o Servi\xE7o em seu computador pessoal ou outro dispositivo que acesse a Internet para acessar os jogos ava</li>\r
    <li>1.2. O Servi\xE7o n\xE3o deve ser usado por (i) indiv\xEDduos menores de 18 anos de idade, (ii) indiv\xEDduos menores de idade em sua jurisdi\xE7\xE3o e (iii) indiv\xEDduos que acessam o Servi\xE7o a partir de jurisdi\xE7\xF5es nas quais \xE9 ilegal faz\xEA-lo. BC.GAME n\xE3o \xE9 capaz de verificar a legalidade do Servi\xE7o em cada jurisdi\xE7\xE3o e \xE9 responsabilidade do Usu\xE1rio garantir que seu uso do Servi\xE7o seja legal.</li>\r
    <li>1.3. BC.GAME e seus licenciadores s\xE3o os \xFAnicos detentores de todos os direitos sobre o Servi\xE7o e c\xF3digo, estrutura e organiza\xE7\xE3o, incluindo direitos autorais, segredos comerciais, propriedade intelectual e outros direitos. Voc\xEA n\xE3o pode, dentro dos limites prescritos pelas leis aplic\xE1veis: (a) copiar, distribuir, publicar, fazer engenharia reversa, descompilar, desmontar, modificar ou traduzir o site; ou (b) usar o Servi\xE7o de maneira proibida pelas leis ou regulamentos aplic\xE1veis \u200B\u200B(cada um dos itens acima \xE9 um "Uso N\xE3o Autorizado"). BC.GAME reserva-se todos e quaisquer direitos impl\xEDcitos ou n\xE3o, que n\xE3o sejam expressamente concedidos ao Usu\xE1rio e ret\xE9m todos os direitos, t\xEDtulos e interesses no Servi\xE7o. Voc\xEA concorda que ser\xE1 o \xFAnico respons\xE1vel por quaisquer danos, custos ou despesas decorrentes ou relacionados \xE0 comiss\xE3o por voc\xEA de qualquer Uso N\xE3o Autorizado. Voc\xEA deve notificar BC.GAME imediatamente ap\xF3s tomar conhecimento da comiss\xE3o por qualquer pessoa de qualquer Uso N\xE3o Autorizado e fornecer BC.GAME assist\xEAncia razo\xE1vel com quaisquer investiga\xE7\xF5es que conduza \xE0 luz das informa\xE7\xF5es fornecidas por voc\xEA a esse respeito.</li>\r
    <li> 1.4. O termo "BC.GAME", seus nomes de dom\xEDnio e quaisquer outras marcas registradas, ou marcas de servi\xE7o usadas por BC.GAME como parte do Servi\xE7o (as "Marcas Registradas"), s\xE3o de propriedade exclusiva de BC.GAME Al\xE9m disso, todo o conte\xFAdo do site, incluindo, mas n\xE3o limitado a, imagens, imagens, gr\xE1ficos, fotografias, anima\xE7\xF5es, v\xEDdeos, m\xFAsica, \xE1udio e texto (o "Conte\xFAdo do Site") pertence a BC.GAME e \xE9 protegido por direitos autorais e/ou outra propriedade intelectual ou outros direitos. Voc\xEA reconhece que, ao usar o Servi\xE7o, n\xE3o obt\xE9m direitos sobre o Conte\xFAdo do Site e/ou as Marcas Registradas, ou qualquer parte dele. Sob nenhuma circunst\xE2ncia voc\xEA pode usar o Conte\xFAdo do Site e/ou as Marcas Registradas sem o consentimento pr\xE9vio por escrito de BC.GAME. Al\xE9m disso, voc\xEA concorda em n\xE3o fazer nada que prejudique ou potencialmente prejudique os direitos, incluindo os direitos de propriedade intelectual de BC.GAME</li>\r
  </ul>\r
  <p>2. Nenhuma garantia</p>\r
  <ul>\r
<li>2.1. BC.GAME se isenta de todas e quaisquer garantias, expressas ou impl\xEDcitas, relacionadas ao servi\xE7o que \xE9 fornecido a voc\xEA "como est\xE1" e n\xE3o fornecemos nenhuma garantia ou representa\xE7\xE3o em rela\xE7\xE3o \xE0 sua qualidade, adequa\xE7\xE3o \xE0 finalidade, integridade ou precis\xE3o.</li>\r
     <li>2.2. Independentemente dos esfor\xE7os de BC.GAME, BC.GAME n\xE3o garante que o servi\xE7o ser\xE1 ininterrupto, oportuno ou sem erros, ou que os defeitos ser\xE3o corrigidos.</li>\r
  </ul>  \r
  <p>3. Autoridade/Termos de Servi\xE7o Voc\xEA concorda com as regras do jogo descritas no site BC.GAME. BC.GAME mant\xE9m autoridade sobre a emiss\xE3o, manuten\xE7\xE3o e encerramento do Servi\xE7o. A decis\xE3o da administra\xE7\xE3o do BC.GAME, relativa a qualquer uso do Servi\xE7o, ou resolu\xE7\xE3o de disputas, \xE9 final e n\xE3o ser\xE1 pass\xEDvel de revis\xE3o ou apela\xE7\xE3o.</p>\r
  <p>4.Suas obriga\xE7\xF5es como jogador</p>\r
  <p>4.1. Voc\xEA declara e garante que:</p>\r
  <ul>\r
 <ul>\r
    <li>4.1.1. Voc\xEA tem mais de 18 anos de idade ou uma idade legal m\xEDnima de maioridade, conforme estipulado, se a jurisdi\xE7\xE3o de sua resid\xEAncia (por exemplo, Est\xF4nia \u2013 21 anos) e, de acordo com as leis aplic\xE1veis \u200B\u200Ba voc\xEA, for legalmente autorizada a participar dos Jogos oferecidos no Site.</li>\r
    <li>4.1.2. Voc\xEA participa dos Jogos estritamente em sua capacidade pessoal n\xE3o profissional apenas por motivos recreativos e de entretenimento.</li>\r
    <li>4.1.3. Voc\xEA participa dos Jogos em seu pr\xF3prio nome e n\xE3o em nome de qualquer outra pessoa.</li>\r
    <li>4.1.4. Todas as informa\xE7\xF5es que Voc\xEA fornecer a BC.GAME durante o prazo de validade deste contrato s\xE3o verdadeiras, completas e corretas, e voc\xEA dever\xE1 notificar imediatamente BC.GAME sobre qualquer altera\xE7\xE3o dessas informa\xE7\xF5es.</li>\r
    <li>4.1.5. Voc\xEA \xE9 o \xFAnico respons\xE1vel por relatar e contabilizar quaisquer impostos aplic\xE1veis \u200B\u200Ba Voc\xEA de acordo com as leis relevantes para quaisquer ganhos que Voc\xEA receber de BC.GAME.</li>\r
    <li>4.1.6. Voc\xEA entende que ao participar dos Jogos voc\xEA corre o risco de perder os Fundos Virtuais depositados em Sua Conta de Membro.</li>\r
    <li>4.1.7. Voc\xEA n\xE3o deve se envolver em nenhuma atividade fraudulenta, colusiva, fixa\xE7\xE3o ou outra atividade ilegal em rela\xE7\xE3o \xE0 sua participa\xE7\xE3o ou de terceiros em qualquer um dos Jogos e n\xE3o deve usar m\xE9todos ou t\xE9cnicas assistidas por software ou dispositivos de hardware para sua participa\xE7\xE3o em qualquer um dos os jogos. BC.GAME se reserva o direito de invalidar qualquer aposta no caso de tal comportamento.</li>\r
    <li>4.1.8. Voc\xEA entende que os Fundos Virtuais como Bitcoin n\xE3o s\xE3o considerados uma moeda ou moeda legal e, como tal, no Site, eles s\xE3o tratados como fundos virtuais sem valor intr\xEDnseco.</li>\r
    <li>4.1.9. Voc\xEA entende que o valor do Bitcoin pode mudar drasticamente dependendo do valor de mercado.</li>\r
    <li>4.1.10. Voc\xEA n\xE3o tem permiss\xE3o para usar m\xE9todos de pagamento que perten\xE7am a terceiros ou pessoas.</li>\r
  </ul>\r
  <p>4.2. Voc\xEA n\xE3o tem permiss\xE3o para transferir, vender e/ou adquirir contas de usu\xE1rio.</p>\r
  <p>4.3. Os jogos jogados em nosso site devem ser jogados da mesma maneira que os jogos jogados em qualquer outro ambiente. Isso significa que os jogadores devem ser corteses uns com os outros e evitar coment\xE1rios rudes ou obscenos.</p>\r
  <p>4.4. Algumas circunst\xE2ncias podem surgir quando uma aposta \xE9 confirmada ou um pagamento \xE9 realizado por n\xF3s por engano. Em todos esses casos, BC.GAME se reserva o direito de cancelar todas as apostas aceitas que contenham tal erro.</p>\r
  <p>4.5. Caso o usu\xE1rio tome conhecimento de poss\xEDveis erros ou incompletudes no software, ele concorda em abster-se de aproveit\xE1-los. Al\xE9m disso, o usu\xE1rio concorda em relatar qualquer erro ou incompletude imediatamente a BC.GAME Caso o usu\xE1rio n\xE3o cumpra as obriga\xE7\xF5es estabelecidas nesta cl\xE1usula, BC.GAME tem direito a uma compensa\xE7\xE3o total por todos os custos relacionados ao erro ou incompletude, incluindo quaisquer custos incorridos em associa\xE7\xE3o com o respectivo erro/incompletude e a falha de notifica\xE7\xE3o pelo usu\xE1rio.</p>\r
  <p>4.6. No caso de um jogo ser iniciado, mas abortado devido a uma falha do sistema, BC.GAME reembolsar\xE1 o valor apostado no jogo ao usu\xE1rio creditando-o na conta do usu\xE1rio ou, se a conta n\xE3o existir mais, pagando-o ao Usu\xE1rio de forma aprovada; e se o usu\xE1rio tiver um cr\xE9dito acumulado no momento em que o jogo falhou, credite na conta do usu\xE1rio o valor monet\xE1rio do cr\xE9dito ou, se a conta n\xE3o existir mais, pague ao usu\xE1rio de maneira aprovada.</p>\r
  <p>4.7. BC.GAME reserva-se o direito de rejeitar ou limitar as apostas. O usu\xE1rio n\xE3o est\xE1 autorizado a apostar um valor que exceda sua conta pessoal. Os ganhos s\xE3o creditados na conta pessoal do usu\xE1rio.</p>\r
  <p>4.8. BC.GAME reserva-se o direito de reter os pagamentos, se houver suspeita ou evid\xEAncia de manipula\xE7\xE3o do sistema do cassino. Acusa\xE7\xF5es criminais ser\xE3o feitas contra qualquer usu\xE1rio ou qualquer outra pessoa(s) que tenha manipulado o sistema do cassino ou tentado faz\xEA-lo. BC.GAME reserva-se o direito de encerrar e/ou alterar quaisquer jogos ou eventos oferecidos no Site.</p>\r
  <p>4.9. Reservamo-nos o direito de exigir alguma verifica\xE7\xE3o em caso de transa\xE7\xF5es suspeitas ou fraudulentas.</p>\r
  <p>4.10. BC.GAME reserva-se o direito de declarar uma aposta anulada parcial ou totalmente se BC.GAME, a seu crit\xE9rio, considerar \xF3bvio que qualquer uma das seguintes circunst\xE2ncias ocorreu:</p>\r
  <ul>\r
    <li>4.10.1. Voc\xEA ou pessoas associadas a voc\xEA podem influenciar direta ou indiretamente o resultado de um evento, para obter uma vantagem ilegal,</li>\r
    <li>4.10.2. Voc\xEA e/ou pessoas associadas a voc\xEA est\xE3o evitando direta ou indiretamente as regras de BC.GAME</li>\r
    <li>4.10.3. O resultado de um evento foi afetado direta ou indiretamente por atividade criminosa.</li>\r
    <li>4.10.4. Foram feitas apostas que n\xE3o seriam aceitas de outra forma, mas que foram aceitas durante os per\xEDodos em que o site foi afetado por problemas t\xE9cnicos.</li>\r
   <li>4.10.5. Devido a um erro, como erro de impress\xE3o, erro t\xE9cnico, for\xE7a maior ou outro, as apostas foram oferecidas, colocadas e/ou aceitas devido a esse erro.</li>\r
     <li>4.10.6. Se a taxa de dep\xF3sito de um jogador for muito baixa e for sinalizada pelo blockchain ou site semelhante como "taxa insuficiente para retransmitir" BC.GAME reserva-se o direito de confiscar os ganhos se BC.GAME, a seu crit\xE9rio, considerar a transa\xE7\xE3o e o comportamento do jogador fraudulentos em natureza.</li>\r
   </ul>\r
   <p>4.11. Voc\xEA informar\xE1 BC.GAME imediatamente se firmar um contrato de autoexclus\xE3o com qualquer provedor de jogos de azar.</p>\r
  \r
 <p>5. Usos proibidos</p>\r
  <p>5.1. USO PESSOAL. O Servi\xE7o destina-se exclusivamente ao uso pessoal do Usu\xE1rio. O Usu\xE1rio s\xF3 pode apostar para seu entretenimento pessoal e n\xE3o pode criar v\xE1rias contas, inclusive para fins de conluio e/ou abuso de servi\xE7o.</p>\r
  <p>5.2. JURISDI\xC7\xD5ES. Pessoas localizadas ou residentes em Aruba, Bonaire, Cura\xE7ao, Costa Rica, Fran\xE7a, Holanda, Saba, Statia, St Martin, EUA (as "Jurisdi\xE7\xF5es Proibidas") n\xE3o t\xEAm permiss\xE3o para usar o Servi\xE7o. Para evitar d\xFAvidas, as restri\xE7\xF5es anteriores sobre a participa\xE7\xE3o em jogos com dinheiro real de Jurisdi\xE7\xF5es Proibidas se aplicam igualmente a residentes e cidad\xE3os de outras na\xE7\xF5es enquanto estiverem localizados em uma Jurisdi\xE7\xE3o Proibida. Qualquer tentativa de contornar as restri\xE7\xF5es de jogo por qualquer pessoa localizada em uma Jurisdi\xE7\xE3o Proibida ou Jurisdi\xE7\xE3o Restrita \xE9 uma viola\xE7\xE3o deste Contrato. Uma tentativa de evas\xE3o inclui, mas n\xE3o se limita a, manipular as informa\xE7\xF5es usadas por BC.GAME para identificar sua localiza\xE7\xE3o e fornecer a BC.GAME informa\xE7\xF5es falsas ou enganosas sobre sua localiza\xE7\xE3o ou local de resid\xEAncia.</p>\r
\r
  \r
<p>6. Conhe\xE7a seu cliente (\u201CKYC\u201D)</p>\r
  <p>BC.GAME reserva-se o direito de, a qualquer momento, solicitar qualquer documenta\xE7\xE3o KYC que considere necess\xE1ria para determinar a identidade e localiza\xE7\xE3o de um Usu\xE1rio. BC.GAME reserva-se o direito de restringir o servi\xE7o e o pagamento at\xE9 que a identidade seja suficientemente determinada.</p>\r
  \r
  <p>7. Viola\xE7\xE3o</p>\r
  <p>7.1. Sem preju\xEDzo de quaisquer outros direitos, se um Usu\xE1rio violar, no todo ou em parte, qualquer disposi\xE7\xE3o contida neste documento, BC.GAME se reserva o direito de tomar as medidas que julgar adequadas, incluindo rescindir este Contrato ou qualquer outro contrato em vigor com o Usu\xE1rio e/ou tomar medidas legais contra tal Usu\xE1rio.</p>\r
  <p>7.2. Voc\xEA concorda em indenizar totalmente, defender e isentar BC.GAME e seus acionistas, diretores, agentes e funcion\xE1rios de e contra todas as reivindica\xE7\xF5es, demandas, responsabilidades, danos, perdas, custos e despesas, incluindo honor\xE1rios advocat\xEDcios e quaisquer outros encargos, independentemente da causa, que possam surgir como resultado de: (i) sua viola\xE7\xE3o deste Contrato, no todo ou em parte; (ii) viola\xE7\xE3o por voc\xEA de qualquer lei ou direitos de terceiros; e (iii) uso por voc\xEA do Servi\xE7o.</p>\r
\r
  \r
  <p>8. Limita\xE7\xF5es e responsabilidade</p>\r
  <p>8.1. Sob nenhuma circunst\xE2ncia, incluindo neglig\xEAncia, o BC.GAME ser\xE1 respons\xE1vel por quaisquer danos especiais, incidentais, diretos, indiretos ou conseq\xFCentes (incluindo, sem limita\xE7\xE3o, danos por lucros cessantes, interrup\xE7\xE3o de neg\xF3cios, perda de informa\xE7\xF5es comerciais ou qualquer outra perda pecuni\xE1ria ) decorrentes do uso (ou uso indevido) do Servi\xE7o, mesmo que BC.GAME tivesse conhecimento pr\xE9vio da possibilidade de tais danos.</p>\r
  <p>8.2. Nada neste Contrato deve excluir ou limitar a responsabilidade de BC.GAME por morte ou danos pessoais resultantes de sua neglig\xEAncia.</p>\r
  \r
  <p>9. Disputas</p>\r
  <p>Se um usu\xE1rio desejar fazer uma reclama\xE7\xE3o, entre em contato com a equipe de atendimento ao cliente de BC.GAME em support@BC.GAME. Caso alguma disputa n\xE3o seja resolvida de forma satisfat\xF3ria, voc\xEA pode buscar recursos na jurisdi\xE7\xE3o da lei aplic\xE1vel estabelecida abaixo.</p>\r
  \r
  <p>10. Altera\xE7\xE3o</p>\r
  <p>BC.GAME reserva-se o direito de atualizar ou modificar este Contrato ou qualquer parte dele a qualquer momento ou alterar o Servi\xE7o sem aviso pr\xE9vio e voc\xEA estar\xE1 vinculado a tal Contrato alterado ap\xF3s a publica\xE7\xE3o. Portanto, recomendamos que voc\xEA verifique os termos e condi\xE7\xF5es contidos na vers\xE3o do Contrato em vigor no momento. Seu uso continuado do Servi\xE7o ser\xE1 considerado como um atestado de sua concord\xE2ncia com quaisquer altera\xE7\xF5es ao Contrato.</p>\r
  \r
 <p>11. Lei Aplic\xE1vel</p>\r
  <p>O Contrato e quaisquer assuntos relacionados a ele ser\xE3o regidos e interpretados de acordo com as leis da Costa Rica. Voc\xEA concorda irrevogavelmente que, sujeito ao disposto abaixo, os tribunais da Costa Rica ter\xE3o jurisdi\xE7\xE3o exclusiva em rela\xE7\xE3o a qualquer reclama\xE7\xE3o, disputa ou diferen\xE7a relativa ao Contrato e qualquer quest\xE3o dele decorrente e renuncia irrevogavelmente a qualquer direito que possa ter de se opor a uma a\xE7\xE3o a ser intentada nesses tribunais, ou para alegar que a a\xE7\xE3o foi intentada em foro inconveniente ou que esses tribunais n\xE3o s\xE3o competentes. Nada nesta cl\xE1usula limitar\xE1 o direito de BC.GAME de instaurar processos contra voc\xEA em qualquer outro tribunal de jurisdi\xE7\xE3o competente, nem a instaura\xE7\xE3o de processos em uma ou mais jurisdi\xE7\xF5es impedir\xE1 a instaura\xE7\xE3o de processos em quaisquer outras jurisdi\xE7\xF5es, simultaneamente ou n\xE3o, na medida permitida pela lei de tal outra jurisdi\xE7\xE3o.</p>\r
  <p>Se uma disposi\xE7\xE3o deste Contrato for ou se tornar ilegal, inv\xE1lida ou inexequ\xEDvel em qualquer jurisdi\xE7\xE3o, isso n\xE3o afetar\xE1 a validade ou exequibilidade nessa jurisdi\xE7\xE3o de qualquer outra disposi\xE7\xE3o ou a validade ou exequibilidade em outra jurisdi\xE7\xE3o dessa ou de qualquer outra disposi\xE7\xE3o deste documento.</p>\r
  \r
  <p>13. Atribui\xE7\xE3o</p>\r
  <p>BC.GAME reserva-se o direito de ceder este contrato, no todo ou em parte, a qualquer momento sem aviso pr\xE9vio. O Usu\xE1rio n\xE3o pode ceder nenhum de seus direitos ou obriga\xE7\xF5es sob este Contrato.</p>\r
  \r
<p>14. JOGO DE VANTAGEM</p>\r
  <p>Se o Cassino tomar conhecimento de qualquer usu\xE1rio que tenha aceitado o b\xF4nus ou uma promo\xE7\xE3o com o \xFAnico prop\xF3sito de criar um valor esperado positivo no retorno do b\xF4nus usando pr\xE1ticas conhecidas destinadas a garantir um saque do referido b\xF4nus ou de qualquer forma tentar aproveitar os b\xF4nus recebidos por BC.GAME, ent\xE3o BC.GAME aplicar\xE1 o confisco imediato dos ganhos e o fechamento da conta com o direito de reter quaisquer saques adicionais. Um exemplo de jogo de vantagem seria adiar qualquer rodada de jogo em qualquer jogo, incluindo recursos de rodadas gr\xE1tis e recursos de b\xF4nus, para um momento posterior, quando voc\xEA n\xE3o tiver mais requisitos de apostas e/ou realizar novos dep\xF3sitos enquanto tiver recursos de rodadas gr\xE1tis ou b\xF4nus recursos ainda dispon\xEDveis em um jogo. No interesse do jogo justo, apostas de margem igual, zero ou baixa ou apostas de hedge, devem ser consideradas jogos irregulares para fins de requisito de b\xF4nus de jogo. Caso o Casino considere que ocorreu um jogo irregular, o Casino reserva-se o direito de reter quaisquer levantamentos e/ou confiscar todos os ganhos.</p>\r
  \r
<h2>Acordo do usu\xE1rio (vers\xE3o revisada para verifica\xE7\xE3o)</h2>\r
   <p>Defini\xE7\xF5es; BC.GAME \xE9 referido como 'n\xF3s' ou 'n\xF3s'.</p>\r
   <p>O Jogador \xE9 referido como "voc\xEA" ou 'o Jogador'.</p>\r
   <p>'O Site' significa BC.GAME por meio de desktop, celular ou outras plataformas utilizadas pelo Jogador.</p>\r
   <p>https://BC.GAME/help/terms-service</p>\r
   \r
   <h2>Defini\xE7\xF5es</h2>\r
   <p>BC.GAME \xE9 referido como 'n\xF3s' ou 'n\xF3s'</p>\r
   <p>O Jogador \xE9 referido como "voc\xEA" ou 'o Jogador'</p>\r
   <p>'O Site' significa BC.GAME por meio de desktop, celular ou outras plataformas utilizadas pelo Jogador</p>\r
   \r
 <p>1. Geral</p>\r
  <ul>\r
    <li>1.1. Este Contrato do Usu\xE1rio se aplica ao uso de jogos acess\xEDveis por meio de BC.GAME.</li>\r
    <li>1.2. Este Contrato do Usu\xE1rio entrar\xE1 em vigor assim que voc\xEA concluir o processo de registro, que inclui marcar a caixa aceitar este Contrato do Usu\xE1rio e criar uma conta com sucesso. Ao usar qualquer parte do site ap\xF3s a cria\xE7\xE3o da conta, voc\xEA concorda com este Contrato do usu\xE1rio.</li>\r
    <li>1.3. Voc\xEA deve ler este Contrato do Usu\xE1rio cuidadosamente em sua totalidade antes de criar uma conta. Se voc\xEA n\xE3o concordar com qualquer disposi\xE7\xE3o deste Contrato do Usu\xE1rio, n\xE3o dever\xE1 criar uma conta ou continuar a usar o Site.</li>\r
    <li>1.4. Temos o direito de fazer altera\xE7\xF5es a este Contrato do Usu\xE1rio a qualquer momento e sem aviso pr\xE9vio. Se fizermos tais altera\xE7\xF5es, poderemos tomar as medidas apropriadas para chamar a sua aten\xE7\xE3o para tais altera\xE7\xF5es (como por e-mail ou colocar um aviso em uma posi\xE7\xE3o de destaque no Site, juntamente com o Contrato do Usu\xE1rio alterado), mas ser\xE1 sua \xFAnica responsabilidade de verificar quaisquer altera\xE7\xF5es, atualiza\xE7\xF5es e/ou modifica\xE7\xF5es. Seu uso continuado dos servi\xE7os e do site do BC.GAME ap\xF3s qualquer altera\xE7\xE3o do Contrato do Usu\xE1rio ser\xE1 considerado como sua aceita\xE7\xE3o e concord\xE2ncia em ficar vinculado a tais altera\xE7\xF5es, atualiza\xE7\xF5es e/ou modifica\xE7\xF5es.</li>\r
    <li>1.5. este Contrato de Usu\xE1rio pode ser publicado em v\xE1rios idiomas para fins informativos e facilidade de acesso pelos jogadores. A vers\xE3o em ingl\xEAs \xE9 a \xFAnica base legal do relacionamento entre voc\xEA e n\xF3s e no caso de qualquer discrep\xE2ncia em rela\xE7\xE3o a uma tradu\xE7\xE3o de qualquer tipo, a vers\xE3o em ingl\xEAs deste Contrato do Usu\xE1rio prevalecer\xE1.</li>\r
  </ul>\r
  \r
<p>2. Declara\xE7\xF5es vinculativas</p>\r
  <p>2.1. Ao concordar em estar vinculado a este Contrato de Usu\xE1rio, voc\xEA tamb\xE9m concorda em estar vinculado \xE0s Regras BC.GAME e Pol\xEDtica de Privacidade que s\xE3o incorporadas por refer\xEAncia a este Contrato de Usu\xE1rio. Em caso de qualquer inconsist\xEAncia, este Contrato do Usu\xE1rio prevalecer\xE1. Voc\xEA declara e garante que:</p>\r
  <ul>\r
    <li>2.1.1. Voc\xEA tem mais de (a) 18 anos ou (b) outra idade legal ou maioridade conforme determinado por quaisquer leis aplic\xE1veis \u200B\u200Ba voc\xEA, a idade que for maior;</li>\r
    <li>2.1.2. Voc\xEA tem plena capacidade para firmar um contrato juridicamente vinculativo conosco e n\xE3o est\xE1 restringido por nenhuma forma de capacidade legal limitada;</li>\r
    <li>2.1.3. Todas as informa\xE7\xF5es que voc\xEA nos fornecer durante o prazo de validade deste contrato s\xE3o verdadeiras, completas, corretas e voc\xEA dever\xE1 nos notificar imediatamente sobre qualquer altera\xE7\xE3o dessas informa\xE7\xF5es;</li>\r
    <li>2.1.4. Voc\xEA \xE9 o \xFAnico respons\xE1vel por relatar e contabilizar quaisquer impostos aplic\xE1veis \u200B\u200Ba voc\xEA de acordo com as leis relevantes para quaisquer ganhos que voc\xEA receber de n\xF3s;</li>\r
    <li>2.1.5. Voc\xEA entende que, ao usar nossos servi\xE7os, corre o risco de perder dinheiro depositado em sua conta de membro e aceita que \xE9 total e exclusivamente respons\xE1vel por qualquer perda;</li>\r
    <li>2.1.6. Voc\xEA tem permiss\xE3o na jurisdi\xE7\xE3o em que est\xE1 localizado para usar os servi\xE7os de cassino online;</li>\r
    <li>2.1.7. Em rela\xE7\xE3o a dep\xF3sitos e saques de fundos de e para sua Conta de Membro, voc\xEA deve usar apenas Criptomoedas v\xE1lidas e que perten\xE7am legalmente a voc\xEA;</li>\r
    <li>2.1.8. Voc\xEA entende que o valor da criptomoeda pode mudar drasticamente dependendo do valor de mercado;</li>\r
    <li>2.1.9. O software de computador, os gr\xE1ficos de computador, os sites e a interface do usu\xE1rio que disponibilizamos a voc\xEA s\xE3o de propriedade de BC.GAME ou de seus associados e s\xE3o protegidos por leis de direitos autorais. Voc\xEA s\xF3 pode usar o software para seu pr\xF3prio uso pessoal e recreativo de acordo com todas as regras, Contrato do Usu\xE1rio que estabelecemos e de acordo com todas as leis, regras e regulamentos aplic\xE1veis;</li>\r
    <li>2.1.10. Voc\xEA entende que a Criptomoeda n\xE3o \xE9 considerada uma moeda ou moeda legal e, como tal, no Site, elas s\xE3o tratadas como fundos virtuais sem valor intr\xEDnseco.</li>\r
    <li>2.1.11. Voc\xEA afirma que n\xE3o \xE9 um executivo, diretor, funcion\xE1rio, consultor ou agente de BC.GAME ou trabalhando para qualquer empresa relacionada a BC.GAME, ou parente ou c\xF4njuge de qualquer um dos anteriores;</li>\r
    <li>2.1.12. Voc\xEA n\xE3o \xE9 diagnosticado ou classificado como um jogador compulsivo ou problem\xE1tico. N\xE3o nos responsabilizamos se tal problema de jogo surgir durante o uso de nossos servi\xE7os, mas nos esfor\xE7aremos para informar sobre a assist\xEAncia relevante dispon\xEDvel. Reservamo-nos o direito de implementar per\xEDodos de reflex\xE3o se acreditarmos que tais a\xE7\xF5es ser\xE3o ben\xE9ficas.</li>\r
    <li>2.1.13. Voc\xEA aceita e reconhece que nos reservamos o direito de detectar e impedir o uso de t\xE9cnicas proibidas, incluindo, entre outras, detec\xE7\xE3o de transa\xE7\xF5es fraudulentas, registro e inscri\xE7\xE3o automatizados, t\xE9cnicas de jogo e captura de tela. Essas etapas podem incluir, mas n\xE3o est\xE3o limitadas a, exame das propriedades do dispositivo dos Jogadores, detec\xE7\xE3o de geolocaliza\xE7\xE3o e mascaramento de IP, transa\xE7\xF5es e an\xE1lise de blockchain;</li>\r
    <li>2.1.14. Voc\xEA aceita nosso direito de encerrar e/ou alterar quaisquer jogos ou eventos oferecidos no Site e de recusar e/ou limitar apostas.</li>\r
    <li>2.1.15. Voc\xEA aceita que temos o direito de banir/bloquear v\xE1rias contas e controlar livremente os ativos dessas contas.</li>\r
    <li>2.1.16. Voc\xEA est\xE1 ciente de poss\xEDveis erros ou incompletude no software, voc\xEA concorda em abster-se de aproveit\xE1-los. Al\xE9m disso, voc\xEA concorda em relatar qualquer erro ou incompletude imediatamente para BC.GAME. Caso voc\xEA n\xE3o cumpra as obriga\xE7\xF5es estabelecidas nesta cl\xE1usula, BC.GAME tem direito a uma compensa\xE7\xE3o total por todos os custos relacionados ao erro ou incompletude, incluindo quaisquer custos incorridos em associa\xE7\xE3o com o respectivo erro/incompletude e a falha de notifica\xE7\xE3o pelo usu\xE1rio.&lt; /li&gt;\r
    </li><li>2.1.17. Voc\xEA est\xE1 ciente de que BC.GAME tem o direito de realizar procedimentos de verifica\xE7\xE3o \u201CKYC\u201D (Know Your Customer). O acesso \xE0 sua conta de usu\xE1rio pode ser bloqueado ou fechado se determinarmos que voc\xEA forneceu informa\xE7\xF5es falsas ou enganosas.</li>\r
  </ul>\r
\r
 <p>2.2. Reservamo-nos o direito de declarar uma aposta anulada parcial ou totalmente se BC.GAME, a seu crit\xE9rio, considerar \xF3bvio que ocorreu qualquer uma das seguintes circunst\xE2ncias:</p>\r
  <ul>\r
    <li>2.2.1. Voc\xEA, ou pessoas associadas a voc\xEA, podem influenciar direta ou indiretamente o resultado de um evento para obter uma vantagem ilegal.</li>\r
    <li>2.2.2. Voc\xEA e/ou pessoas associadas a voc\xEA est\xE3o evitando direta ou indiretamente as regras de BC.GAME.</li>\r
    <li>2.2.3. O resultado de um evento foi afetado direta ou indiretamente por atividade criminosa.</li>\r
    <li>2.2.4. Foram feitas apostas que n\xE3o seriam aceitas de outra forma, mas que foram aceitas durante os per\xEDodos em que o site foi afetado por problemas t\xE9cnicos.</li>\r
    <li>2.2.5. Devido a um erro, como um engano, vulnerabilidades, erro t\xE9cnico, for\xE7a maior ou outro, as apostas foram oferecidas, colocadas e/ou aceitas devido a esse erro.</li>\r
    <li>2.2.6. Se a taxa de dep\xF3sito de um jogador for muito baixa e for sinalizada por blockchain ou site semelhante como "taxa insuficiente para retransmitir" BC.GAME se reserva o direito de confiscar os ganhos se BC.GAME, a seu crit\xE9rio, considerar a transa\xE7\xE3o e o comportamento do jogador fraudulentos em natureza.</li>\r
  </ul>\r
  \r
  <p>3. Territ\xF3rios Restritos</p>\r
  <ul>\r
    <li>3.1. Territ\xF3rios na lista negra: China, Holanda, Ilhas do Caribe Holand\xEAs, Cura\xE7ao, Fran\xE7a, Estados Unidos e/ou qualquer outro pa\xEDs ou estado restrito por lei. Observe que \xE9 estritamente proibido jogar em jogos BC.GAME nos pa\xEDses da lista negra mencionados acima. seus dados pessoais com a finalidade de executar suas fun\xE7\xF5es e fornecer a voc\xEA a melhor assist\xEAncia e servi\xE7o poss\xEDvel. Voc\xEA concorda com tais divulga\xE7\xF5es.</li>\r
  </ul>\r
  \r
  <p>4. Regras gerais de apostas</p>\r
  <ul>\r
    <li>4.1. Uma aposta s\xF3 pode ser feita por um titular de conta registrado.</li>\r
    <li>4.2. Uma aposta s\xF3 pode ser feita pela Internet.</li>\r
    <li>4.3. Voc\xEA s\xF3 pode fazer uma aposta se tiver saldo suficiente em sua conta com BC.GAME.</li>\r
    <li>4.4. A aposta, uma vez conclu\xEDda, ser\xE1 regida pela vers\xE3o do Contrato do Usu\xE1rio v\xE1lida e dispon\xEDvel no Site no momento da aceita\xE7\xE3o da aposta.</li>\r
    <li>4.5. Qualquer pagamento de uma aposta vencedora \xE9 creditado em sua conta, consistindo na aposta multiplicada pelas probabilidades em que a aposta foi feita.</li>\r
    <li>4.6. BC.GAME reserva-se o direito de ajustar um pagamento de aposta creditado em uma conta BC.GAME se for determinado por BC.GAME a seu exclusivo crit\xE9rio que tal pagamento foi creditado devido a um erro.</li>\r
    <li>4.7. Uma aposta que foi feita e aceita n\xE3o pode ser alterada, retirada ou cancelada por voc\xEA.</li>\r
    <li>4.8. A lista de todas as apostas, seu status e detalhes est\xE3o dispon\xEDveis para voc\xEA no site.</li>\r
    <li>4.9. Ao fazer uma aposta, voc\xEA reconhece que leu e entendeu na \xEDntegra todo este Contrato do Usu\xE1rio referente \xE0 aposta, conforme declarado no Site.</li>\r
    <li>4.10. BC.GAME gerencia sua conta e calcula os fundos dispon\xEDveis, os fundos pendentes, os fundos de apostas e o valor dos ganhos. Salvo prova em contr\xE1rio, esses valores s\xE3o considerados definitivos e precisos.</li>\r
    <li>4.11. Voc\xEA \xE9 totalmente respons\xE1vel pelas apostas feitas.</li>\r
    <li>4.12. Os ganhos ser\xE3o pagos em sua conta ap\xF3s a confirma\xE7\xE3o do resultado final.</li>\r
  </ul>\r
  \r
  <p>5. B\xF4nus e promo\xE7\xF5es</p>\r
  <ul>\r
    <li>5.1. BC.GAME reserva-se o direito de cancelar qualquer promo\xE7\xE3o, b\xF4nus ou programa de b\xF4nus (incluindo, mas n\xE3o limitado a recompensas de recarga, convidar amigos para recompensar b\xF4nus e programas de fidelidade) com efeito imediato se acreditarmos que o b\xF4nus foi configurado incorretamente ou est\xE1 sendo abusado, e se o referido b\xF4nus tiver sido pago, nos reservamos o direito de recusar qualquer solicita\xE7\xE3o de saque e deduzir tal valor de sua conta. Se um b\xF4nus \xE9 ou n\xE3o considerado configurado incorretamente ou abusado deve ser determinado exclusivamente por BC.GAME.</li>\r
    <li>5.2. Se voc\xEA usar um B\xF4nus de Dep\xF3sito, nenhum saque do seu dep\xF3sito original ser\xE1 aceito antes de voc\xEA ter atingido os requisitos estipulados no Contrato do Usu\xE1rio do B\xF4nus de Dep\xF3sito.</li>\r
    <li>5.3. Quando qualquer termo da oferta ou promo\xE7\xE3o for violado ou houver qualquer evid\xEAncia de uma s\xE9rie de apostas feitas por um cliente ou grupo de clientes, que devido a um b\xF4nus de dep\xF3sito, pagamentos aprimorados, apostas gr\xE1tis, apostas sem risco ou qualquer outra oferta promocional resulta em lucros garantidos para o cliente, independentemente do resultado, seja individualmente ou como parte de um grupo, BC.GAME reserva-se o direito de recuperar o elemento de b\xF4nus de tais ofertas e, a seu crit\xE9rio absoluto, liquidar as apostas com as probabilidades corretas, anular o b\xF4nus de aposta gr\xE1tis e apostas sem risco ou anular qualquer aposta financiada pelo b\xF4nus de dep\xF3sito. Al\xE9m disso, BC.GAME se reserva o direito de cobrar uma taxa de administra\xE7\xE3o do cliente at\xE9 o valor do b\xF4nus de dep\xF3sito, b\xF4nus de aposta gr\xE1tis, aposta sem risco ou pagamento adicional para cobrir custos administrativos. Reservamo-nos ainda o direito de pedir a qualquer cliente que forne\xE7a documenta\xE7\xE3o suficiente para que fiquemos satisfeitos, a nosso crit\xE9rio absoluto, quanto \xE0 identidade do cliente antes de creditarmos qualquer b\xF4nus, aposta gr\xE1tis, aposta sem risco ou oferta em sua conta.</li>\r
    <li>5.4. Todas as ofertas de BC.GAME s\xE3o destinadas a jogadores recreativos e BC.GAME pode, a seu exclusivo crit\xE9rio, limitar a qualifica\xE7\xE3o dos clientes para participar de toda ou parte de qualquer promo\xE7\xE3o.</li>\r
    <li>5.5. BC.GAME reserva-se o direito de alterar, cancelar, reclamar ou recusar qualquer promo\xE7\xE3o a seu crit\xE9rio.</li>\r
    <li>5.6. Os b\xF4nus s\xF3 podem ser recebidos uma vez por pessoa/conta, fam\xEDlia, domic\xEDlio, endere\xE7o, endere\xE7o de e-mail, endere\xE7os IP e ambientes onde os computadores s\xE3o compartilhados (universidade, fraternidade, escola, biblioteca p\xFAblica, local de trabalho, etc.). O Operador reserva-se o direito de encerrar sua conta e confiscar quaisquer fundos existentes se forem encontradas evid\xEAncias de abuso/fraude.</li>\r
    <li>5.7. Voc\xEA reconhece e entende que existe um Contrato de Usu\xE1rio separado com rela\xE7\xE3o a promo\xE7\xF5es, b\xF4nus e ofertas especiais, e s\xE3o adicionais a este Contrato de Usu\xE1rio. Este Contrato do Usu\xE1rio est\xE1 estabelecido na respectiva p\xE1gina de conte\xFAdo deste site ou foi disponibilizado a voc\xEA pessoalmente, conforme o caso. Em caso de conflito entre as disposi\xE7\xF5es de tais promo\xE7\xF5es, b\xF4nus e ofertas especiais e as disposi\xE7\xF5es deste Contrato do Usu\xE1rio, prevalecer\xE3o as disposi\xE7\xF5es de tais promo\xE7\xF5es, b\xF4nus e ofertas especiais.</li>\r
    <li>5.8. Podemos insistir que voc\xEA aposte uma certa quantia de seu pr\xF3prio dep\xF3sito antes de poder apostar com quaisquer fundos gratuitos/b\xF4nus que creditamos em sua conta.</li>\r
    <li>5.9. Voc\xEA aceita que certas promo\xE7\xF5es podem estar sujeitas a restri\xE7\xF5es de saque e/ou requisitos que precisam ser atendidos antes que os fundos creditados na promo\xE7\xE3o possam ser sacados. Tais termos ser\xE3o devidamente publicados e disponibilizados como parte da promo\xE7\xE3o. Se voc\xEA optar por fazer um Saque antes que os requisitos de apostas aplic\xE1veis \u200B\u200Bsejam cumpridos, deduziremos todo o valor do b\xF4nus, bem como quaisquer ganhos relacionados ao uso dos valores do b\xF4nus antes de aprovar qualquer Saque.</li>\r
  </ul>\r
  \r
 <p>6. Bate-papo ao vivo</p>\r
  <p>6.1. Como parte de seu uso do site, podemos fornecer a voc\xEA um recurso de bate-papo ao vivo, moderado por n\xF3s e sujeito a controles. Reservamo-nos o direito de revisar o bate-papo e manter um registro de todas as declara\xE7\xF5es feitas nas instala\xE7\xF5es. Seu uso do recurso de bate-papo deve ser para fins recreativos e de socializa\xE7\xE3o.</p>\r
  <p>6.2. Temos o direito de remover a funcionalidade da sala de bate-papo ou encerrar imediatamente sua conta de membro e reembolsar o saldo da sua conta se voc\xEA:</p>\r
  <ul>\r
    <li>(a) fazer quaisquer declara\xE7\xF5es que sejam sexualmente expl\xEDcitas ou grosseiramente ofensivas, incluindo express\xF5es de intoler\xE2ncia, racismo, \xF3dio ou palavr\xF5es;</li>\r
    <li>(b) fazer declara\xE7\xF5es abusivas, difamat\xF3rias, assediantes ou ofensivas;</li>\r
    <li>(c) usar o recurso de bate-papo para anunciar, promover ou se relacionar de outra forma com quaisquer outras entidades on-line;</li>\r
    <li>(d) fazer declara\xE7\xF5es sobre BC.GAME ou qualquer outro site da Internet conectado ao Site que sejam falsas e/ou maliciosas e/ou prejudiciais a BC.GAME;</li>\r
    <li>(e) usar o recurso de bate-papo para conspirar, envolver-se em conduta ilegal ou incentivar condutas que consideremos seriamente inadequadas. Quaisquer bate-papos suspeitos ser\xE3o relatados \xE0 autoridade competente.</li>\r
  </ul>\r
  \r
  <p>6.3. O chat ao vivo \xE9 usado como uma forma de comunica\xE7\xE3o entre n\xF3s e voc\xEA e n\xE3o deve ser copiado ou compartilhado com nenhum f\xF3rum ou terceiros.</p>\r
\r
  <p>7. Limita\xE7\xE3o de responsabilidade</p>\r
  <ul>\r
    <li>7.1. Voc\xEA entra no Site e participa dos Jogos por sua conta e risco. Os Sites e os Jogos s\xE3o fornecidos sem qualquer garantia, expressa ou impl\xEDcita.</li>\r
    <li>7.2. Sem preju\xEDzo da generalidade da disposi\xE7\xE3o anterior, n\xF3s, nossos diretores, funcion\xE1rios, parceiros, prestadores de servi\xE7os.</li>\r
    <li>7.3. N\xE3o garantimos que o software, os Jogos e os Sites sejam adequados para sua finalidade.</li>\r
    <li>7.4. N\xE3o garantimos que o software, os Jogos e os Sites estejam livres de erros.</li>\r
    <li>7.5. N\xE3o garantimos que o software, os Jogos e os Sites estar\xE3o acess\xEDveis sem interrup\xE7\xF5es.</li>\r
    <li>7.6. N\xE3o ser\xE1 respons\xE1vel por quaisquer perdas, custos, despesas ou danos, sejam diretos, indiretos, especiais, conseq\xFCentes, incidentais ou outros, decorrentes do uso dos Sites ou da participa\xE7\xE3o nos Jogos.</li>\r
    <li>7.7. Voc\xEA entende e reconhece que, se houver um mau funcionamento em um Jogo ou sua interoperabilidade, todas as apostas feitas durante esse mau funcionamento ser\xE3o anuladas. Os fundos obtidos de um Jogo com defeito ser\xE3o considerados nulos, bem como quaisquer rodadas de jogos subsequentes com esses fundos, independentemente de quais Jogos sejam jogados com esses fundos.</li>\r
    <li>7.8. Voc\xEA concorda em indenizar totalmente e isentar n\xF3s, nossos diretores, funcion\xE1rios, parceiros e prestadores de servi\xE7os por qualquer custo, despesa, perda, danos, reclama\xE7\xF5es e responsabilidades, independentemente da causa que possa surgir em rela\xE7\xE3o ao seu uso do Site ou participa\xE7\xE3o em os Jogos.</li>\r
    <li>7.9. Na extens\xE3o permitida por lei, nossa responsabilidade m\xE1xima decorrente ou em conex\xE3o com o uso dos Sites, independentemente da causa das a\xE7\xF5es (seja em contrato, ato il\xEDcito, viola\xE7\xE3o de garantia ou de outra forma), n\xE3o exceder\xE1 \u20AC 100.&lt; /li&gt;\r
  </li></ul>\r
\r
 <p>8. Viola\xE7\xF5es, penalidades e rescis\xE3o</p>\r
  <ul>\r
    <li>8.1. Se voc\xEA violar qualquer disposi\xE7\xE3o deste Contrato de Usu\xE1rio ou tivermos motivos razo\xE1veis \u200B\u200Bpara suspeitar que voc\xEA os violou, nos reservamos o direito de n\xE3o abrir, suspender ou encerrar sua Conta de Membro, ou reter o pagamento de seus ganhos e aplicar tais fundos para quaisquer danos devidos por voc\xEA.</li>\r
    <li>8.2. Voc\xEA reconhece que BC.GAME deve ser o tomador de decis\xE3o final se voc\xEA violou as regras, termos ou condi\xE7\xF5es de BC.GAME de uma maneira que resulte em sua suspens\xE3o ou impedimento permanente de participa\xE7\xE3o em nosso site.</li>\r
  </ul>\r
\r
  <p>9. Autoexclus\xE3o</p>\r
  <ul>\r
    <li>9.1. Ao solicitar um per\xEDodo de autoexclus\xE3o, voc\xEA concorda em seguir os termos e condi\xE7\xF5es abaixo, que entrar\xE3o em vigor a partir do momento em que o CS implementar o per\xEDodo de autoexclus\xE3o escolhido.</li>\r
    <li>9.2. Voc\xEA pode se autoexcluir por per\xEDodos de 1, 3, 6, 12 m\xEAs/s ou permanente. As solicita\xE7\xF5es de autoexclus\xE3o devem ser feitas por meio do suporte ao vivo.</li>\r
    <li>9.3. Depois de se autoexcluir, voc\xEA n\xE3o poder\xE1 acessar sua conta ou fazer saques durante esse per\xEDodo.</li>\r
    <li>9.4. Se voc\xEA excluiu sua conta enquanto tem apostas pendentes em sua conta, as apostas feitas permanecer\xE3o v\xE1lidas e ser\xE3o liquidadas de acordo com os resultados oficiais. </li>\r
    <li>9.5. Uma vez que o per\xEDodo de autoexclus\xE3o tenha expirado, voc\xEA pode retirar os ganhos das apostas qualificadas. BC.GAME n\xE3o cancela ou anula quaisquer apostas feitas antes que uma autoexclus\xE3o tenha sido afetada.</li>\r
    <li>9.6. Depois de se autoexcluir, voc\xEA n\xE3o poder\xE1 alterar ou alterar o per\xEDodo por um per\xEDodo menor ou cancelar sua autoexclus\xE3o at\xE9 que o per\xEDodo selecionado para a autoexclus\xE3o tenha passado.</li>\r
    <li>9.7. Entre em contato com nossa equipe de atendimento ao cliente se desejar estender seu per\xEDodo de autoexclus\xE3o.</li>\r
    <li>9.8. Ap\xF3s o t\xE9rmino do per\xEDodo de autoexclus\xE3o, o restabelecimento da conta pode ser feito enviando a solicita\xE7\xE3o por e-mail para support@BC.GAME.</li>\r
    <li>9.9. Ao se autoexcluir, voc\xEA concorda que:</li>\r
    <ul>\r
      <li> a) Voc\xEA n\xE3o criar\xE1 outra conta durante este per\xEDodo.</li>\r
      <li> b) Voc\xEA n\xE3o depositar\xE1 ou tentar\xE1 depositar fundos em uma conta BC.GAME. </li>\r
      <li> c) Voc\xEA n\xE3o apostar\xE1 neste site durante este per\xEDodo.</li>\r
      <li> d) Este \xE9 um ato volunt\xE1rio iniciado por voc\xEA, e a BlockDance B.V. n\xE3o ser\xE1 respons\xE1vel por quaisquer perdas que voc\xEA possa incorrer durante o per\xEDodo de autoexclus\xE3o de qualquer forma.</li>\r
    </ul>\r
  </ul>\r
\r
 <h2>Pol\xEDtica de Privacidade</h2>\r
  <p> Voc\xEA reconhece e aceita que, se julgarmos necess\xE1rio, podemos coletar e usar seus dados pessoais para permitir que voc\xEA acesse e use os Sites e para permitir que voc\xEA participe dos Jogos.</p> p&gt;\r
  <p>Reconhecemos que, ao coletar seus dados pessoais, conforme declarado na disposi\xE7\xE3o anterior, estamos vinculados \xE0 Lei de Prote\xE7\xE3o de Dados. Protegeremos suas informa\xE7\xF5es pessoais e respeitaremos sua privacidade de acordo com as melhores pr\xE1ticas comerciais e as leis aplic\xE1veis.</p>\r
  <p>Usaremos seus dados pessoais para permitir que voc\xEA participe dos Jogos e realize opera\xE7\xF5es relevantes para sua participa\xE7\xE3o nos Jogos. Tamb\xE9m podemos usar seus dados pessoais para inform\xE1-lo sobre altera\xE7\xF5es, novos servi\xE7os e promo\xE7\xF5es que achamos que voc\xEA possa achar interessantes. Se voc\xEA n\xE3o deseja receber tais correspond\xEAncias de marketing direto, pode optar por n\xE3o participar do servi\xE7o.</p>\r
  <p>Seus dados pessoais n\xE3o ser\xE3o divulgados a terceiros, a menos que seja exigido por lei. Como BC.GAME parceiros de neg\xF3cios ou fornecedores ou prestadores de servi\xE7os podem ser respons\xE1veis \u200B\u200Bpor certas partes do funcionamento geral ou opera\xE7\xE3o do Site, os dados pessoais podem ser divulgados a eles. Os colaboradores da BC.GAME t\xEAm acesso aos seus dados pessoais com a finalidade de desempenhar as suas fun\xE7\xF5es e prestar-lhe a melhor assist\xEAncia e servi\xE7o poss\xEDvel. Voc\xEA concorda com tais divulga\xE7\xF5es.</p>\r
  <p>Vamos manter todas as informa\xE7\xF5es fornecidas como dados pessoais. Voc\xEA tem o direito de acessar os dados pessoais mantidos por n\xF3s sobre voc\xEA. Nenhum dado deve ser destru\xEDdo, a menos que exigido por lei, ou a menos que as informa\xE7\xF5es mantidas n\xE3o precisem mais ser mantidas para os fins do relacionamento.</p>\r
  <p>Para tornar sua visita aos Sites mais f\xE1cil de usar, acompanhar as visitas aos Sites e melhorar o servi\xE7o, coletamos uma pequena informa\xE7\xE3o enviada do seu navegador, chamada cookie. Voc\xEA pode, se desejar, desativar a coleta de cookies. Voc\xEA deve observar, no entanto, que desativar os cookies pode restringir severamente ou impedir completamente o uso dos sites.</p>\r
  \r
 <h2>Pol\xEDtica de Cookies</h2>\r
  <p>1.O que s\xE3o cookies?</p>\r
  <ul>\r
    <li>Um cookie \xE9 uma informa\xE7\xE3o na forma de um arquivo de texto muito pequeno que \xE9 colocado no computador de um usu\xE1rio da Internet. Ele \xE9 gerado por um servidor de p\xE1ginas web (que \xE9 basicamente o computador que opera o site) e pode ser utilizado por esse servidor sempre que o usu\xE1rio visitar o site. Um cookie pode ser considerado como o cart\xE3o de identifica\xE7\xE3o de um usu\xE1rio da Internet, que informa a um site quando o usu\xE1rio retornou. Os cookies n\xE3o podem danificar seu computador e n\xE3o armazenamos nenhuma informa\xE7\xE3o pessoal identific\xE1vel sobre voc\xEA em nenhum de nossos cookies.</li>\r
  </ul>\r
  <p>2. Por que usamos cookies em BC.GAME?</p>\r
  <ul>\r
    <li>BC.GAME usa dois tipos de cookies: cookies definidos por n\xF3s e cookies definidos por terceiros (ou seja, outros sites ou servi\xE7os). Os cookies BC.GAME nos permitem mant\xEA-lo conectado \xE0 sua conta durante toda a sua visita e adaptar as informa\xE7\xF5es exibidas no site \xE0s suas prefer\xEAncias.</li>\r
  </ul>\r
  <p>3. Quais cookies usamos em BC.GAME?</p>\r
  <p>Abaixo est\xE1 uma lista dos principais cookies definidos por BC.GAME e para que cada um \xE9 usado:</p>\r
  <ul>\r
    <li>_fp - armazena a impress\xE3o digital do navegador. Vida \xFAtil: para sempre.</li>\r
    <li>_t - armazena o carimbo de data/hora quando o usu\xE1rio visitou o site pela primeira vez na sess\xE3o de navega\xE7\xE3o atual. Necess\xE1rio para estat\xEDstica de visitas \xFAnicas. Vida \xFAtil: sess\xE3o de navega\xE7\xE3o.</li>\r
    <li>_r - armazena o referenciador http para a sess\xE3o de navega\xE7\xE3o atual. Necess\xE1rio para rastrear fontes de tr\xE1fego externas. Vida \xFAtil: sess\xE3o de navega\xE7\xE3o.</li>\r
    <li>_c - armazena o identificador da campanha do afiliado. Necess\xE1rio para estat\xEDstica de afiliados. Vida \xFAtil: para sempre.</li>\r
    <li>Cookies definidos por terceiros para dom\xEDnio curinga: *.BC.GAME</li>\r
    <li>Google Analytics: _ga, _gat, _gid</li>\r
    <li>Zendesk\uFF1A__ zlcmid</li>\r
    <li>Cloudflare\uFF1A__ cfuid</li>\r
    <li>Lembre-se de que alguns navegadores (ou seja, chrome no mac) mant\xEAm os processos em segundo plano em execu\xE7\xE3o, mesmo que nenhuma guia seja aberta devido a esta sess\xE3o, os cookies podem ser deixados definidos entre as sess\xF5es.</li>\r
    <li>H\xE1 tamb\xE9m cookies definidos por scripts de terceiros para seus dom\xEDnios.</li>\r
  </ul>\r
  \r
  \r
  <p>4.Como posso gerenciar meus cookies em BC.GAME?</p>\r
  <ul>\r
    <li>Se voc\xEA deseja parar de aceitar cookies, pode faz\xEA-lo atrav\xE9s da op\xE7\xE3o Configura\xE7\xF5es de privacidade em seu navegador.</li>\r
  </ul>\r
  \r
  <p>5.Pol\xEDtica de prote\xE7\xE3o de dados pessoais</p>\r
  <ul>\r
    A miss\xE3o da <li>BC.GAME \xE9 manter seus dados seguros e, para isso, protegemos seus dados de v\xE1rias maneiras. Oferecemos aos nossos clientes altos padr\xF5es de seguran\xE7a, como criptografia de dados em movimento em redes p\xFAblicas, criptografia de dados em banco de dados, padr\xF5es de auditoria, mitiga\xE7\xF5es de nega\xE7\xE3o de servi\xE7o distribu\xEDda e um bate-papo ao vivo dispon\xEDvel no local.</li>\r
  </ul>\r
  \r
  \r
 <p>6.Pol\xEDtica de prote\xE7\xE3o do servidor</p>\r
  <ul>\r
    <li>Todos os servidores t\xEAm criptografia completa;</li>\r
    <li>Todos os backups t\xEAm criptografia;</li>\r
    <li>Firewalls, acesso VPN;</li>\r
    <li>Acesso a servidores permitido apenas por VPN;</li>\r
    <li>Todos os servi\xE7os http/s funcionam na Cloudflare;</li>\r
    <li>Conex\xF5es a n\xF3s por VPN;</li>\r
    <li>T\xFAneis de encaminhamento de porta SSH;</li>\r
    <li>Servi\xE7os permitidos apenas por VPN;</li>\r
    <li>O servidor tem firewall e permite apenas a porta SSH;</li>\r
    <li>Alertas sobre servi\xE7os cr\xEDticos.</li>\r
    <li>Notifica\xE7\xE3o de viola\xE7\xE3o de dados</li>\r
    <li>Quando BC.GAME for informado sobre viola\xE7\xF5es de dados pessoais, notificaremos os usu\xE1rios relevantes de acordo com os prazos do GDPR.</li>\r
  </ul>\r
  \r
  <p>7.Transfer\xEAncia Internacional de Dados</p>\r
  <ul>\r
    <li>S\xF3 divulgamos dados pessoais a terceiros quando \xE9 necess\xE1rio fornecer o servi\xE7o de alta qualidade ou para responder a solicita\xE7\xF5es legais de autoridades.</li>\r
    <li>Compartilhamos os seguintes dados com sistemas de terceiros:</li>\r
    <li>Zendesk Inc. \u2013 as informa\xE7\xF5es de nome de usu\xE1rio e e-mail s\xE3o transferidas se o usu\xE1rio enviar uma mensagem para o chat ao vivo ou enviar um e-mail para a caixa de correio de suporte.</li>\r
    <li>Embora tentemos fazer o nosso melhor, problemas podem ocorrer de vez em quando. Nossa equipe far\xE1 todo o poss\xEDvel para resolver seus problemas o mais r\xE1pido poss\xEDvel. Para ajud\xE1-lo mais rapidamente, voc\xEA pode se juntar a n\xF3s clicando no bot\xE3o acima para entrar no grupo do telegram.</li>\r
    <li>Se ocorrer um erro, forne\xE7a as seguintes informa\xE7\xF5es:</li>\r
    <ul>\r
      <li>Nome de usu\xE1rio</li>\r
      <li>Data e hora do problema</li>\r
    </ul>\r
  </ul>\r
  \r
  <p>ID do jogo ou nome da mesa, se houver</p>\r
  <p>Captura de tela do erro, se poss\xEDvel</p>\r
  <p>Agradecemos muito sua ajuda e o relat\xF3rio de erros que voc\xEA forneceu, pois seu relat\xF3rio de informa\xE7\xF5es pode nos ajudar a melhorar.</p>\r
  <p>Coletar e usar seus dados pessoais</p>\r
  <p>Tipos de dados coletados</p>\r
  <p>Dados pessoais</p>\r
  <p>Ao usar nosso servi\xE7o, podemos pedir que voc\xEA nos forne\xE7a determinadas informa\xE7\xF5es de identifica\xE7\xE3o pessoal que podem ser usadas para contat\xE1-lo ou identific\xE1-lo. As informa\xE7\xF5es de identifica\xE7\xE3o pessoal podem incluir, mas n\xE3o se limitam a:</p>\r
  <p>Endere\xE7o de e-mail</p>\r
  <p>Nome e sobrenome</p>\r
  <p>Dados de uso</p>\r
  <p>Dados de uso</p>\r
  <p>Os Dados de Uso s\xE3o coletados automaticamente ao usar o Servi\xE7o.</p>\r
  <p>Os dados de uso podem incluir informa\xE7\xF5es como o endere\xE7o do protocolo de Internet do seu dispositivo (por exemplo, endere\xE7o IP), tipo de navegador, vers\xE3o do navegador, as p\xE1ginas do nosso servi\xE7o que voc\xEA visita, a hora e a data da sua visita, o tempo gasto nessas p\xE1ginas , identificadores exclusivos de dispositivo e outros dados de diagn\xF3stico.</p>\r
  <p>Quando voc\xEA acessa o Servi\xE7o por ou por meio de um dispositivo m\xF3vel, podemos coletar determinadas informa\xE7\xF5es automaticamente, incluindo, mas n\xE3o se limitando ao tipo de dispositivo m\xF3vel que voc\xEA usa, o ID exclusivo do seu dispositivo m\xF3vel, o endere\xE7o IP do seu dispositivo m\xF3vel , Seu sistema operacional m\xF3vel, o tipo de navegador de Internet m\xF3vel que voc\xEA usa, identificadores exclusivos de dispositivo e outros dados de diagn\xF3stico.</p>\r
  <p>Tamb\xE9m podemos coletar informa\xE7\xF5es que Seu navegador envia sempre que Voc\xEA visita nosso Servi\xE7o ou quando acessa o Servi\xE7o por ou por meio de um dispositivo m\xF3vel.</p>\r
  <p>Informa\xE7\xF5es de servi\xE7os de m\xEDdia social de terceiros</p>\r
  <p>BC.GAME permite que Voc\xEA crie uma conta e fa\xE7a login para usar o Servi\xE7o por meio dos seguintes Servi\xE7os de M\xEDdia Social de Terceiros:</p>\r
  <ul>\r
    <li>Google</li>\r
    <li>Facebook</li>\r
    <li>Telegrama</li>\r
    <li>Metam\xE1scara</li>\r
  </ul>\r
\r
 <h2>Web 3.0</h2>\r
  <p>Se voc\xEA decidir se registrar ou nos conceder acesso a um servi\xE7o de m\xEDdia social de terceiros, poderemos coletar dados pessoais que j\xE1 estejam associados \xE0 conta do seu servi\xE7o de m\xEDdia social de terceiros, como seu nome, seu endere\xE7o de e-mail , Suas atividades ou Sua lista de contatos associada a essa conta.</p>\r
  <p>Voc\xEA tamb\xE9m pode ter a op\xE7\xE3o de compartilhar informa\xE7\xF5es adicionais com o BC.GAME por meio da conta do seu servi\xE7o de m\xEDdia social de terceiros. Se Voc\xEA optar por fornecer tais informa\xE7\xF5es e Dados Pessoais, durante o registro ou de outra forma, Voc\xEA est\xE1 dando permiss\xE3o a BC.GAME para us\xE1-los, compartilh\xE1-los e armazen\xE1-los de maneira consistente com esta Pol\xEDtica de Privacidade.</p>\r
  <p>Excluir dados pessoais</p>\r
  <p>Voc\xEA pode solicitar a exclus\xE3o de seus dados pessoais se BC.GAME n\xE3o tiver mais um motivo legal para continuar a process\xE1-los ou armazen\xE1-los. Por favor, note que este direito n\xE3o \xE9 garantido - no sentido de que BC.GAME n\xE3o tem a capacidade de cumprir sua solicita\xE7\xE3o se estiver sujeito a uma obriga\xE7\xE3o legal de armazenar seus dados. Voc\xEA pode solicitar a exclus\xE3o de seus dados pessoais enviando um e-mail para support@BC.GAME.</p>\r
 \r
  <h2>Registro e Login</h2>\r
  <p>Voc\xEA deve ter pelo menos 18 anos para se registrar. Se voc\xEA quiser adicionar seu endere\xE7o de e-mail, verifique se o endere\xE7o de e-mail digitado est\xE1 correto para que possa ser usado posteriormente na verifica\xE7\xE3o da conta KYC.</p>\r
  <p>Voc\xEA pode fazer login a qualquer momento. Para maior seguran\xE7a, recomendamos que voc\xEA adicione 2FA. Para saber mais sobre o autenticador do Google.</p>\r
  <p>Se voc\xEA precisar alterar seu e-mail cadastrado, sentimos muito, mas n\xE3o podemos atualizar essas informa\xE7\xF5es. Se voc\xEA insistir em alterar seu nome de usu\xE1rio e/ou e-mail cadastrado, sugerimos que voc\xEA encerre a conta atual e registre uma nova.</p>\r
</ul></section>`,
    o = `<section>
  <h2>Persyaratan Layanan</h2>
  <p>Perjanjian pengguna akhir ini ("Perjanjian") harus dibaca oleh Anda ("Pengguna" atau "Anda") secara keseluruhan sebelum Anda menggunakan layanan atau produk BC.GAME. Harap dicatat bahwa Perjanjian ini merupakan perjanjian yang mengikat secara hukum antara Anda dan BC.GAME (di sini disebut sebagai "BC.GAME", "kami") yang memiliki dan mengoperasikan situs Internet yang ditemukan dan permainan yang dijelaskan di BC.GAME ("Layanan") . Dengan mengklik tombol "Saya Setuju" jika dan di mana disediakan dan/atau menggunakan Layanan, Anda menyetujui syarat dan ketentuan yang ditetapkan dalam Perjanjian ini.</p>
  <p>1. Pemberian Lisensi</p>
  <ul class="content">
    <li>1.1. Tunduk pada syarat dan ketentuan yang tercantum di sini, BC.GAME memberi Pengguna hak non-eksklusif, pribadi, tidak dapat dialihkan untuk menggunakan Layanan di komputer pribadi Anda atau perangkat lain yang mengakses Internet untuk mengakses game ava</li>
    <li>1.2. Layanan ini tidak untuk digunakan oleh (i) individu di bawah usia 18 tahun, (ii) individu di bawah usia mayoritas yang sah di yurisdiksi mereka dan (iii) individu yang mengakses Layanan dari yurisdiksi yang ilegal untuk melakukannya. BC.GAME tidak dapat memverifikasi legalitas Layanan di setiap yurisdiksi dan Pengguna bertanggung jawab untuk memastikan bahwa penggunaan Layanan oleh mereka sesuai hukum.</li>
    <li>1.3.BC.GAME dan pemberi lisensinya adalah satu-satunya pemegang semua hak dalam dan atas Layanan dan kode, struktur dan organisasi, termasuk hak cipta, rahasia dagang, kekayaan intelektual, dan hak lainnya. Anda tidak boleh, dalam batas yang ditentukan oleh hukum yang berlaku: (a) menyalin, mendistribusikan, menerbitkan, merekayasa balik, mendekompilasi, membongkar, memodifikasi, atau menerjemahkan situs web; atau (b) menggunakan Layanan dengan cara yang dilarang oleh undang-undang atau peraturan yang berlaku (masing-masing di atas adalah "Penggunaan Tidak Sah"). BC.GAME mencadangkan setiap dan semua hak tersirat atau sebaliknya, yang tidak secara tegas diberikan kepada Pengguna di bawah ini dan mempertahankan semua hak, kepemilikan, dan kepentingan dalam dan atas Layanan. Anda setuju bahwa Anda akan bertanggung jawab penuh atas segala kerusakan, biaya atau pengeluaran yang timbul dari atau sehubungan dengan komisi oleh Anda atas Penggunaan Tidak Sah. Anda harus segera memberi tahu BC.GAME setelah mengetahui komisi oleh siapa pun atas Penggunaan Tidak Sah dan harus memberikan BC.GAME bantuan yang wajar dengan penyelidikan apa pun yang dilakukan sehubungan dengan informasi yang Anda berikan dalam hal ini.</li>
    <li>1.4. Istilah "BC.GAME", nama domainnya dan merek dagang lainnya, atau merek layanan yang digunakan oleh BC.GAME sebagai bagian dari Layanan ("Merek Dagang"), sepenuhnya dimiliki oleh BC.GAME Selain itu, semua konten di situs web, termasuk, namun tidak terbatas pada, gambar, gambar, grafik, foto, animasi, video, musik, audio dan teks ("Konten Situs") adalah milik BC.GAME dan dilindungi oleh hak cipta dan/atau kekayaan intelektual atau hak lainnya. Anda dengan ini mengakui bahwa dengan menggunakan Layanan, Anda tidak memperoleh hak atas Konten Situs dan/atau Merek Dagang, atau bagian apa pun darinya. Dalam situasi apa pun Anda tidak boleh menggunakan Konten Situs dan/atau Merek Dagang tanpa persetujuan tertulis sebelumnya dari BC.GAME. Selain itu, Anda setuju untuk tidak melakukan apa pun yang akan membahayakan atau berpotensi membahayakan hak, termasuk hak kekayaan intelektual BC.GAME</li>
  </ul>
  <p>2. Tidak Ada Garansi</p>
  <ul class="content">
    <li>2.1. BC.GAME menyangkal setiap dan semua jaminan, tersurat maupun tersirat, sehubungan dengan layanan yang diberikan kepada Anda "sebagaimana adanya" dan kami tidak memberi Anda jaminan atau pernyataan apa pun mengenai kualitas, kesesuaian untuk tujuan, kelengkapan, atau keakuratannya.</li>
    <li>2.2. Terlepas dari upaya BC.GAME, BC.GAME tidak menjamin bahwa layanan tidak akan terganggu, tepat waktu, atau bebas kesalahan, atau bahwa kerusakan akan diperbaiki.</li>
  </ul>  
  <p>3. Otoritas/Ketentuan Layanan Anda menyetujui aturan permainan yang dijelaskan di situs web BC.GAME. BC.GAME memegang otoritas atas penerbitan, pemeliharaan, dan penutupan Layanan. Keputusan manajemen BC.GAME, mengenai penggunaan Layanan, atau penyelesaian sengketa, bersifat final dan tidak dapat ditinjau atau diajukan banding.</p>
  <p>4. Kewajiban Anda sebagai Pemain</p>
  <p>4.1. Anda dengan ini menyatakan dan menjamin bahwa:</p>
  <ul class="content">
    <li>4.1.1. Anda berusia di atas 18 tahun atau usia legal minimum yang lebih tinggi dari mayoritas sebagaimana ditentukan jika yurisdiksi tempat tinggal Anda (misalnya Estonia \u2013 21 tahun) dan, berdasarkan undang-undang yang berlaku untuk Anda, diizinkan secara hukum untuk berpartisipasi dalam Permainan yang ditawarkan di Situs web.</li>
    <li>4.1.2. Anda berpartisipasi dalam Game hanya dalam kapasitas non-profesional pribadi Anda untuk alasan rekreasi dan hiburan saja.</li>
    <li>4.1.3. Anda berpartisipasi dalam Game atas nama Anda sendiri dan bukan atas nama orang lain.</li>
    <li>4.1.4. Semua informasi yang Anda berikan kepada BC.GAME selama masa berlakunya perjanjian ini adalah benar, lengkap, dan benar, dan bahwa Anda harus segera memberi tahu BC.GAME tentang setiap perubahan informasi tersebut.</li>
    <li>4.1.5. Anda bertanggung jawab penuh untuk melaporkan dan menghitung pajak apa pun yang berlaku untuk Anda berdasarkan undang-undang yang relevan untuk setiap kemenangan yang Anda terima dari BC.GAME.</li>
    <li>4.1.6. Anda memahami bahwa dengan berpartisipasi dalam Game, Anda mengambil risiko kehilangan Dana Virtual yang disetorkan ke Akun Anggota Anda.</li>
    <li>4.1.7. Anda tidak boleh terlibat dalam penipuan, kolusi, perbaikan atau aktivitas melanggar hukum lainnya sehubungan dengan partisipasi Anda atau pihak ketiga dalam Game mana pun dan tidak boleh menggunakan metode atau teknik atau perangkat keras yang dibantu perangkat lunak untuk partisipasi Anda dalam salah satu dari permainan. BC.GAME dengan ini berhak untuk membatalkan taruhan apa pun jika terjadi perilaku tersebut.</li>
    <li>4.1.8. Anda memahami bahwa Dana Virtual sebagai Bitcoin tidak dianggap sebagai mata uang atau alat pembayaran yang sah dan karena itu di Situs Web mereka diperlakukan sebagai dana virtual tanpa nilai intrinsik.</li>
    <li>4.1.9. Anda memahami bahwa nilai Bitcoin dapat berubah secara dramatis tergantung pada nilai pasar.</li>
    <li>4.1.10. Anda tidak diperbolehkan menggunakan metode pembayaran apa pun milik pihak atau orang ketiga.</li>
  </ul>
  <p>4.2. Anda tidak diizinkan untuk mentransfer, menjual dan/atau memperoleh, akun pengguna.</p>
  <p>4.3. Game yang dimainkan di situs Kami harus dimainkan dengan cara yang sama seperti game yang dimainkan di pengaturan lainnya. Ini berarti bahwa pemain harus bersikap sopan satu sama lain dan menghindari komentar kasar atau cabul.</p>
  <p>4.4. Beberapa keadaan mungkin muncul di mana taruhan dikonfirmasi, atau pembayaran dilakukan oleh kami karena kesalahan. Dalam semua kasus ini BC.GAME berhak untuk membatalkan semua taruhan yang diterima yang mengandung kesalahan seperti itu.</p>
  <p>4.5. Jika pengguna mengetahui kemungkinan kesalahan atau ketidaklengkapan dalam perangkat lunak, dia setuju untuk tidak mengambil keuntungan darinya. Selain itu, pengguna setuju untuk segera melaporkan kesalahan atau ketidaklengkapan apa pun ke BC.GAME Jika pengguna gagal memenuhi kewajiban yang dinyatakan dalam klausul ini, BC.GAME berhak atas kompensasi penuh untuk semua biaya yang terkait dengan kesalahan atau ketidaklengkapan, termasuk biaya yang timbul sehubungan dengan dengan kesalahan/ketidaklengkapan masing-masing dan pemberitahuan yang gagal oleh pengguna.</p>
  <p>4.6. Jika permainan dimulai tetapi gagal karena kegagalan sistem, BC.GAME akan mengembalikan jumlah yang dipertaruhkan dalam permainan kepada Pengguna dengan mengkreditkannya ke Akun Pengguna atau, jika akun tidak ada lagi, dengan membayarnya ke Pengguna dengan cara yang disetujui; dan jika Pengguna memiliki kredit yang masih harus dibayar pada saat permainan gagal, kreditkan ke Akun Pengguna nilai moneter dari kredit tersebut atau, jika akun tidak ada lagi, bayarkan kepada Pengguna dengan cara yang disetujui.</p>
  <p>4.7. BC.GAME berhak menolak atau membatasi taruhan. Pengguna tidak diizinkan untuk bertaruh dalam jumlah yang melebihi akun pribadinya. Kemenangan dikreditkan ke akun pribadi pengguna.</p>
  <p>4.8. BC.GAME berhak menahan pembayaran, jika ada kecurigaan atau bukti manipulasi sistem kasino. Tuntutan pidana akan diajukan terhadap pengguna atau orang lain mana pun, yang telah/telah memanipulasi sistem kasino atau berusaha melakukannya. BC.GAME berhak untuk menghentikan dan/atau, mengubah permainan atau acara apa pun yang ditawarkan di Situs Web.</p>
  <p>4.9. Kami berhak untuk meminta beberapa verifikasi jika terjadi transaksi yang mencurigakan atau penipuan.</p>
  <p>4.10. BC.GAME berhak untuk menyatakan taruhan batal sebagian atau seluruhnya jika BC.GAME, atas kebijakannya sendiri, akan menganggap jelas bahwa salah satu dari keadaan berikut telah terjadi:</p>
  <ul class="konten">
    <li>4.10.1. Anda, atau orang-orang yang terkait dengan Anda dapat secara langsung atau tidak langsung memengaruhi hasil suatu peristiwa, untuk mendapatkan keuntungan yang melanggar hukum,</li>
    <li>4.10.2. Anda dan atau orang yang terkait dengan Anda secara langsung atau tidak langsung menghindari aturan BC.GAME</li>
    <li>4.10.3. Hasil suatu peristiwa secara langsung atau tidak langsung dipengaruhi oleh kegiatan kriminal.</li>
    <li>4.10.4. Taruhan telah ditempatkan yang tidak akan diterima sebaliknya, tetapi diterima selama periode ketika situs web terpengaruh oleh masalah teknis.</li>
    <li>4.10.5. Karena kesalahan, seperti, salah cetak, kesalahan teknis, force majeure atau lainnya, taruhan telah ditawarkan, ditempatkan dan atau diterima karena kesalahan ini.</li>
    <li>4.10.6. Jika biaya deposit pemain terlalu rendah dan ditandai oleh blockchain atau situs serupa sebagai \u201Cbiaya tidak cukup untuk menyampaikan\u201D BC.GAME berhak untuk menyita kemenangan jika BC.GAME atas kebijakan mereka sendiri menganggap transaksi dan perilaku pemain sebagai penipuan dalam alam.</li>
  </ul>
  <p>4.11. Anda akan segera memberi tahu BC.GAME jika Anda membuat perjanjian Pengunduran diri dengan penyedia perjudian mana pun.</p>
  
  <p>5. Penggunaan yang Dilarang</p>
  <p>5.1. KEPERLUAN PRIBADI. Layanan ditujukan semata-mata untuk penggunaan pribadi Pengguna. Pengguna hanya diperbolehkan bertaruh untuk hiburan pribadinya dan tidak boleh membuat banyak akun, termasuk untuk tujuan kolusi dan/atau penyalahgunaan layanan.</p>
  <p>5.2. YURISDIKSI. Orang yang berada di atau penduduk Aruba, Bonaire, Curacao, Kosta Rika, Prancis, Belanda, Saba, Statia, St Martin, AS ("Yurisdiksi Terlarang") tidak diizinkan menggunakan Layanan. Untuk menghindari keraguan, pembatasan sebelumnya untuk terlibat dalam permainan uang nyata dari Yurisdiksi Terlarang berlaku sama untuk penduduk dan warga negara lain saat berada di Yurisdiksi Terlarang. Segala upaya untuk menghindari pembatasan permainan oleh siapa pun yang berada di Yurisdiksi Terlarang atau Yurisdiksi Terlarang, merupakan pelanggaran terhadap Perjanjian ini. Upaya pengelakan termasuk, namun tidak terbatas pada, memanipulasi informasi yang digunakan oleh BC.GAME untuk mengidentifikasi lokasi Anda dan memberikan BC.GAME informasi palsu atau menyesatkan mengenai lokasi atau tempat tinggal Anda.</p>
  
  <p>6. Kenali Pelanggan Anda (\u201CKYC\u201D)</p>
  <p>BC.GAME berhak, setiap saat, untuk meminta dokumentasi KYC yang dianggap perlu untuk menentukan identitas dan lokasi Pengguna. BC.GAME berhak untuk membatasi layanan dan pembayaran sampai identitas cukup ditentukan.</p>
  
  <p>7. Pelanggaran</p>
  <p>7.1. Tanpa mengurangi hak lainnya, jika Pengguna melanggar secara keseluruhan atau sebagian ketentuan apa pun yang terkandung di sini, BC.GAME berhak untuk mengambil tindakan yang dianggap perlu, termasuk mengakhiri Perjanjian ini atau perjanjian lain apa pun yang berlaku dengan Pengguna dan/atau mengambil tindakan hukum terhadap Pengguna tersebut.</p>
   <p>7.2. Anda setuju untuk sepenuhnya mengganti kerugian, membela, dan membebaskan BC.GAME dan pemegang saham, direktur, agen, dan karyawannya dari dan terhadap semua klaim, tuntutan, kewajiban, kerusakan, kerugian, biaya dan pengeluaran, termasuk biaya hukum dan biaya lain apa pun, apa pun penyebabnya, yang mungkin timbul sebagai akibat dari: (i) pelanggaran Anda terhadap Perjanjian ini, secara keseluruhan atau sebagian; (ii) pelanggaran oleh Anda terhadap hukum apa pun atau hak pihak ketiga mana pun; dan (iii) penggunaan Layanan oleh Anda.</p>
  
  <p>8. Batasan dan Tanggung Jawab</p>
  <p>8.1. Dalam keadaan apa pun, termasuk kelalaian, BC.GAME tidak bertanggung jawab atas kerugian khusus, insidental, langsung, tidak langsung, atau konsekuensial apa pun (termasuk, tanpa batasan, ganti rugi atas hilangnya keuntungan bisnis, gangguan bisnis, hilangnya informasi bisnis, atau kerugian uang lainnya ) yang timbul dari penggunaan (atau penyalahgunaan) Layanan meskipun BC.GAME memiliki pengetahuan sebelumnya tentang kemungkinan kerusakan tersebut.</p>
   <p>8.2. Tidak ada dalam Perjanjian ini yang akan mengecualikan atau membatasi tanggung jawab BC.GAME atas kematian atau cedera pribadi akibat kelalaiannya.</p>
  
  <p>9. Perselisihan </p>
   <p>Jika Pengguna ingin mengajukan keluhan, harap hubungi tim layanan pelanggan BC.GAME di support@BC.GAME. Jika ada perselisihan yang tidak diselesaikan untuk kepuasan Anda, Anda dapat melakukan upaya hukum di yurisdiksi hukum yang mengatur yang ditetapkan di bawah ini.</p>
  
  <p>10. Amandemen</p>
   <p>BC.GAME berhak untuk memperbarui atau memodifikasi Perjanjian ini atau bagian apa pun darinya kapan saja atau mengubah Layanan tanpa pemberitahuan dan Anda akan terikat oleh Perjanjian yang diubah tersebut setelah diposting. Oleh karena itu, kami mendorong Anda untuk memeriksa syarat dan ketentuan yang terdapat dalam versi Perjanjian yang berlaku saat itu. Penggunaan Layanan yang berkelanjutan oleh Anda akan dianggap membuktikan persetujuan Anda terhadap setiap amandemen Perjanjian.</p>
  
  <p>11. Peraturan pemerintah</p>
  <p>Perjanjian dan segala hal yang terkait dengannya akan diatur oleh, dan ditafsirkan sesuai dengan, hukum Kosta Rika. Anda setuju tidak dapat ditarik kembali bahwa, dengan tunduk pada ketentuan di bawah ini, pengadilan Kosta Rika akan memiliki yurisdiksi eksklusif sehubungan dengan klaim, perselisihan, atau perbedaan apa pun mengenai Perjanjian dan masalah apa pun yang timbul darinya dan dengan tidak dapat ditarik kembali melepaskan hak apa pun yang mungkin dimiliki untuk menolak suatu tindakan dibawa ke pengadilan tersebut, atau untuk mengklaim bahwa tindakan tersebut telah dibawa ke forum yang tidak nyaman, atau bahwa pengadilan tersebut tidak memiliki yurisdiksi. Tidak ada dalam klausul ini yang akan membatasi hak BC.GAME untuk mengambil proses terhadap Anda di pengadilan lain dari yurisdiksi yang kompeten, juga tidak akan mengambil proses di satu atau lebih yurisdiksi menghalangi pengambilan proses di yurisdiksi lain, baik secara bersamaan atau tidak, sejauh diizinkan oleh hukum yurisdiksi lain tersebut.</p>
  <p>Jika suatu ketentuan dalam Perjanjian ini menjadi atau menjadi ilegal, tidak sah, atau tidak dapat diterapkan di yurisdiksi mana pun, hal itu tidak akan memengaruhi keabsahan atau keberlakuan di yurisdiksi tersebut dari ketentuan lain apa pun di sini atau keabsahan atau keberlakuan di yurisdiksi lain dari itu atau ketentuan lain apa pun di sini.</p>
  
  <p>13. Pengalihan</p>
  <p>BC.GAME berhak untuk mengalihkan perjanjian ini, seluruhnya atau sebagian, kapan saja tanpa pemberitahuan. Pengguna tidak boleh mengalihkan hak atau kewajibannya berdasarkan Perjanjian ini.</p>
  
  <p>14. KEUNTUNGAN BERMAIN</p>
  <p>Jika Kasino mengetahui ada pengguna yang telah menerima bonus atau promosi dengan tujuan semata-mata untuk menciptakan nilai positif yang diharapkan pada pengembalian bonus dengan menggunakan praktik yang dikenal yang bertujuan untuk mengamankan uang tunai dari bonus tersebut atau dengan cara apa pun mencoba memanfaatkannya bonus yang diterima oleh BC.GAME, maka BC.GAME akan memberlakukan penyitaan langsung atas kemenangan dan penutupan akun dengan hak untuk menahan penarikan lebih lanjut. Contoh permainan keuntungan akan menunda putaran permainan apa pun dalam permainan apa pun, termasuk fitur putaran gratis dan fitur bonus, ke lain waktu ketika Anda tidak memiliki persyaratan taruhan lagi dan/atau melakukan setoran baru sambil memiliki fitur atau bonus putaran gratis fitur yang masih tersedia dalam game. Untuk kepentingan permainan yang adil, taruhan dengan margin yang sama, nol atau rendah atau taruhan lindung nilai, semua akan dianggap sebagai permainan tidak teratur untuk tujuan persyaratan bermain bonus. Jika Kasino menganggap bahwa permainan tidak teratur telah terjadi, Kasino berhak menahan penarikan dan/atau menyita semua kemenangan.</p>
</section>

<section>
  <h2>Perjanjian Pengguna</h2>
  <p>Definisi; BC.GAME disebut sebagai 'kami' .</p>
  <p>Pemain disebut sebagai "Anda" atau 'Pemain'.</p>
  <p>'Situs Web' berarti BC.GAME melalui desktop, seluler, atau platform lain yang digunakan oleh Pemain.</p>
  <p>https://BC.GAME/help/terms-service</p>
</section>

<section>
  <h2>Definisi</h2>
  <p>BC.GAME disebut sebagai 'kami' atau 'kami'</p>
   <p>Pemain disebut sebagai "Anda" atau 'Pemain'</p>
   <p>'Situs Web' berarti BC.GAME melalui desktop, seluler, atau platform lain yang digunakan oleh Pemain</p>
   
  <p>1. Umum</p>
  <ul class="content">
    <li>1.1. Perjanjian Pengguna ini berlaku untuk penggunaan game yang dapat diakses melalui BC.GAME.</li>
    <li>1.2. Perjanjian Pengguna ini mulai berlaku segera setelah Anda menyelesaikan proses pendaftaran, termasuk mencentang kotak menerima Perjanjian Pengguna ini dan berhasil membuat akun. Dengan menggunakan bagian mana pun dari Situs Web setelah pembuatan akun, Anda menyetujui Perjanjian Pengguna ini.</li>
    <li>1.3. Anda harus membaca Perjanjian Pengguna ini dengan seksama secara keseluruhan sebelum membuat akun. Jika Anda tidak setuju dengan ketentuan apa pun dari Perjanjian Pengguna ini, Anda tidak boleh membuat akun atau terus menggunakan Situs Web.</li>
    <li>1.4. Kami berhak untuk membuat amandemen Perjanjian Pengguna ini setiap saat dan tanpa pemberitahuan sebelumnya. Jika kami membuat perubahan tersebut, kami dapat mengambil langkah-langkah yang tepat untuk membawa perubahan tersebut ke perhatian Anda (seperti melalui email atau menempatkan pemberitahuan pada posisi penting di Situs Web, bersama dengan Perjanjian Pengguna yang diubah) tetapi itu akan menjadi satu-satunya Anda tanggung jawab untuk memeriksa setiap amandemen, pembaruan dan/atau modifikasi. Penggunaan Anda yang berkelanjutan atas layanan dan Situs BC.GAME setelah amandemen Perjanjian Pengguna akan dianggap sebagai penerimaan dan persetujuan Anda untuk terikat oleh amandemen, pembaruan, dan/atau modifikasi tersebut.</li>
    <li>1.5. Perjanjian Pengguna ini dapat diterbitkan dalam beberapa bahasa untuk tujuan informasi dan kemudahan akses oleh pemain. Versi bahasa Inggris adalah satu-satunya dasar hukum dari hubungan antara Anda dan kami dan jika ada perbedaan sehubungan dengan terjemahan dalam bentuk apa pun, versi bahasa Inggris dari Perjanjian Pengguna ini yang akan berlaku.</li>
  </ul>
  
  <p>2. Deklarasi yang Mengikat</p>
  <p>2.1. Dengan setuju untuk terikat dengan Perjanjian Pengguna ini, Anda juga setuju untuk terikat oleh BC.GAME Aturan dan Kebijakan Privasi yang dengan ini digabungkan dengan referensi ke dalam Perjanjian Pengguna ini. Jika terjadi inkonsistensi, Perjanjian Pengguna ini yang akan berlaku. Anda dengan ini menyatakan dan menjamin bahwa:</p>
  <ul class="konten">
    <li>2.1.1. Anda berusia di atas (a) 18 atau (b) usia legal lainnya atau usia mayoritas sebagaimana ditentukan oleh undang-undang yang berlaku untuk Anda, usia mana pun yang lebih besar;</li>
    <li>2.1.2. Anda memiliki kapasitas penuh untuk membuat perjanjian yang mengikat secara hukum dengan kami dan Anda tidak dibatasi oleh segala bentuk kapasitas hukum yang terbatas;</li>
    <li>2.1.3. Semua informasi yang Anda berikan kepada kami selama masa berlakunya perjanjian ini adalah benar, lengkap, benar, dan bahwa Anda harus segera memberi tahu kami tentang setiap perubahan informasi tersebut;</li>
    <li>2.1.4. Anda sepenuhnya bertanggung jawab untuk melaporkan dan menghitung pajak apa pun yang berlaku untuk Anda berdasarkan undang-undang yang relevan untuk setiap kemenangan yang Anda terima dari kami;</li>
    <li>2.1.5. Anda memahami bahwa dengan menggunakan layanan kami, Anda mengambil risiko kehilangan uang yang disetorkan ke Akun Anggota Anda dan menerima bahwa Anda sepenuhnya dan bertanggung jawab penuh atas kerugian tersebut;</li>
    <li>2.1.6. Anda diizinkan di yurisdiksi tempat Anda berada untuk menggunakan layanan kasino online;</li>
    <li>2.1.7. Sehubungan dengan penyetoran dan penarikan dana ke dan dari Akun Anggota Anda, Anda hanya boleh menggunakan Cryptocurrency yang sah dan secara sah menjadi milik Anda;</li>
    <li>2.1.8. Anda memahami bahwa nilai Cryptocurrency dapat berubah secara dramatis tergantung pada nilai pasar;</li>
    <li>2.1.9. Perangkat lunak komputer, grafik komputer, Situs Web, dan antarmuka pengguna yang kami sediakan untuk Anda dimiliki oleh BC.GAME atau rekanannya dan dilindungi oleh undang-undang hak cipta. Anda hanya boleh menggunakan perangkat lunak untuk penggunaan pribadi dan rekreasional Anda sesuai dengan semua aturan, Perjanjian Pengguna yang telah kami buat dan sesuai dengan semua undang-undang, aturan, dan peraturan yang berlaku;</li>
    <li>2.1.10. Anda memahami bahwa Cryptocurrency tidak dianggap sebagai mata uang atau tender yang sah dan oleh karena itu di Situs Web mereka diperlakukan sebagai dana virtual tanpa nilai intrinsik.</li>
    <li>2.1.11. Anda menegaskan bahwa Anda bukan pejabat, direktur, karyawan, konsultan, atau agen BC.GAME atau bekerja untuk perusahaan mana pun yang terkait dengan BC.GAME, atau kerabat atau pasangan dari salah satu yang disebutkan di atas;</li>
    <li>2.1.12. Anda tidak didiagnosis atau diklasifikasikan sebagai penjudi kompulsif atau bermasalah. Kami tidak bertanggung jawab jika masalah perjudian muncul saat menggunakan layanan kami tetapi akan berusaha untuk menginformasikan bantuan relevan yang tersedia. Kami berhak untuk menerapkan masa tenang jika kami yakin tindakan tersebut akan bermanfaat.</li>
    <li>2.1.13. Anda menerima dan mengakui bahwa kami berhak untuk mendeteksi dan mencegah penggunaan teknik terlarang, termasuk namun tidak terbatas pada deteksi transaksi penipuan, pendaftaran dan pendaftaran otomatis, teknik permainan dan tangkapan layar. Langkah-langkah ini mungkin termasuk, namun tidak terbatas pada, pemeriksaan properti perangkat Pemain, deteksi lokasi geografis dan penyembunyian IP, transaksi dan analisis blockchain;</li>
    <li>2.1.14. Anda menerima hak kami untuk menghentikan dan/atau mengubah permainan atau acara apa pun yang ditawarkan di Situs Web, dan untuk menolak dan/atau membatasi taruhan.</li>
    <li>2.1.15. Anda menerima bahwa kami memiliki hak untuk memblokir/memblokir beberapa akun dan secara bebas mengontrol aset di akun tersebut.</li>
    <li>2.1.16. Anda mengetahui kemungkinan kesalahan atau ketidaklengkapan dalam perangkat lunak, Anda setuju untuk tidak mengambil keuntungan darinya. Selain itu, Anda setuju untuk segera melaporkan kesalahan atau ketidaklengkapan apa pun ke BC.GAME. Jika Anda gagal memenuhi kewajiban yang dinyatakan dalam klausul ini, BC.GAME berhak atas kompensasi penuh untuk semua biaya yang terkait dengan kesalahan atau ketidaklengkapan, termasuk biaya yang timbul sehubungan dengan kesalahan/ketidaklengkapan masing-masing dan pemberitahuan yang gagal oleh pengguna.< /li>
    <li>2.1.17. Anda mengetahui bahwa BC.GAME berhak untuk melakukan prosedur verifikasi \u201CKYC\u201D (Kenali Pelanggan Anda). Akses ke akun pengguna Anda dapat diblokir atau ditutup jika kami menemukan bahwa Anda telah memberikan informasi yang salah atau menyesatkan.</li>
  </ul>

  <p>2.2. Kami berhak untuk menyatakan taruhan batal sebagian atau seluruhnya jika BC.GAME, atas kebijakannya sendiri, akan menganggap jelas bahwa salah satu dari keadaan berikut telah terjadi:</p>
  <ul class="konten">
    <li>2.2.1. Anda, atau orang-orang yang terkait dengan Anda, dapat secara langsung atau tidak langsung memengaruhi hasil suatu peristiwa, untuk mendapatkan keuntungan yang melanggar hukum.</li>
    <li>2.2.2. Anda dan atau orang yang terkait dengan Anda secara langsung atau tidak langsung menghindari aturan BC.GAME.</li>
    <li>2.2.3. Hasil suatu peristiwa secara langsung atau tidak langsung dipengaruhi oleh kegiatan kriminal.</li>
    <li>2.2.4. Taruhan telah ditempatkan yang tidak akan diterima sebaliknya, tetapi diterima selama periode ketika situs web terpengaruh oleh masalah teknis.</li>
    <li>2.2.5. Karena kesalahan, seperti kesalahan, kerentanan, kesalahan teknis, force majeure atau lainnya, taruhan telah ditawarkan, ditempatkan, dan atau diterima karena kesalahan ini.</li>
    <li>2.2.6. Jika biaya deposit pemain terlalu rendah dan ditandai oleh blockchain atau situs serupa sebagai \u201Cbiaya tidak cukup untuk menyampaikan\u201D BC.GAME berhak untuk menyita kemenangan jika BC.GAME atas kebijakan mereka sendiri menganggap transaksi dan perilaku pemain sebagai penipuan dalam alam.</li>
  </ul>
  
  <p>3. Wilayah Terbatas</p>
  <ul class="content">
    <li>3.1. Wilayah yang Masuk Wilayah Terbatas: Cina, Belanda, Kepulauan Karibia Belanda, Curacao, Prancis, Amerika Serikat, dan/atau negara atau negara bagian lain yang dibatasi oleh hukum. Perhatikan bahwa sangat dilarang untuk bermain di game BC.GAME di negara-negara daftar wilayah terbatas yang disebutkan di atas. Data pribadi Anda untuk tujuan menjalankan tugas mereka dan memberi Anda bantuan dan layanan terbaik. Anda dengan ini menyetujui pengungkapan tersebut.</li>
  </ul>
  
  <p>4. Aturan Taruhan Umum</p> 
  <ul class="content">
    <li>4.1. Taruhan hanya dapat dipasang oleh pemegang akun terdaftar.</li>
     <li>4.2. Taruhan hanya dapat dipasang melalui internet.</li>
     <li>4.3. Anda hanya dapat memasang taruhan jika Anda memiliki saldo yang cukup di akun Anda dengan BC.GAME.</li>
    <li>4.4. Taruhan, setelah selesai, akan diatur oleh versi Perjanjian Pengguna yang valid dan tersedia di Situs Web pada saat taruhan diterima.</li>
    <li>4.5. Setiap pembayaran dari taruhan yang menang dikreditkan ke akun Anda, terdiri dari taruhan dikalikan dengan peluang di mana taruhan ditempatkan.</li>
    <li>4.6. BC.GAME berhak untuk menyesuaikan pembayaran taruhan yang dikreditkan ke akun BC.GAME jika ditentukan oleh BC.GAME atas kebijakannya sendiri bahwa pembayaran tersebut telah dikreditkan karena kesalahan.</li>
    <li>4.7. Taruhan yang telah dipasang dan diterima, tidak dapat diubah, ditarik, atau dibatalkan oleh Anda.</li>
    <li>4.8. Daftar semua taruhan, status dan detailnya tersedia untuk Anda di Situs Web.</li>
    <li>4.9. Saat Anda memasang taruhan, Anda mengakui bahwa Anda telah membaca dan memahami sepenuhnya semua Perjanjian Pengguna ini mengenai taruhan sebagaimana dinyatakan di Situs Web.</li>
    <li>4.10. BC.GAME mengelola akun Anda, dan menghitung dana yang tersedia, dana yang tertunda, dana taruhan, serta jumlah kemenangan. Kecuali terbukti sebaliknya, jumlah ini dianggap final dan dianggap akurat.</li>
    <li>4.11. Anda bertanggung jawab penuh atas taruhan yang dipasang.</li>
    <li>4.12. Kemenangan akan dibayarkan ke akun Anda setelah hasil akhir dikonfirmasi.</li>
  </ul>
  
  <p>5. Bonus dan Promosi</p> 
  <ul class="content">
    <li>5.1. BC.GAME berhak untuk membatalkan promosi, bonus, atau program bonus apa pun (termasuk, namun tidak terbatas pada hadiah top-up, undang teman untuk memberikan bonus, dan program loyalitas) dengan segera jika kami yakin bahwa bonus telah diatur secara tidak benar atau sedang disalahgunakan, dan jika bonus tersebut telah dibayarkan, kami berhak menolak permintaan Penarikan dan mengurangi jumlah tersebut dari akun Anda. Apakah bonus dianggap salah atau disalahgunakan hanya ditentukan oleh BC.GAME.</li>
    <li>5.2. Jika Anda menggunakan Bonus Deposit, Penarikan dari deposit awal Anda tidak akan diterima sebelum Anda mencapai persyaratan yang ditetapkan dalam Perjanjian Pengguna Bonus Deposit.</li>
    <li>5.3. Dimana ada ketentuan dari penawaran atau promosi yang dilanggar atau ada bukti dari serangkaian taruhan yang ditempatkan oleh pelanggan atau kelompok pelanggan, yang disebabkan oleh bonus deposit, pembayaran yang ditingkatkan, taruhan gratis, taruhan bebas risiko atau penawaran promosi lainnya. menghasilkan keuntungan pelanggan yang dijamin terlepas dari hasilnya, baik secara individu atau sebagai bagian dari kelompok, BC.GAME berhak untuk mengklaim kembali elemen bonus dari penawaran tersebut dan dalam kebijaksanaan mutlak mereka, baik menyelesaikan taruhan pada odds yang benar, membatalkan bonus taruhan gratis dan taruhan bebas risiko atau membatalkan taruhan yang didanai oleh bonus deposit. Selain itu, BC.GAME berhak untuk memungut biaya administrasi pada pelanggan hingga nilai bonus deposit, bonus taruhan gratis, taruhan bebas risiko, atau pembayaran tambahan untuk menutupi biaya administrasi. Kami selanjutnya berhak meminta pelanggan mana pun untuk memberikan dokumentasi yang memadai agar kami puas dengan kebijakan mutlak kami mengenai identitas pelanggan sebelum kami mengkreditkan bonus, taruhan gratis, taruhan bebas risiko, atau penawaran apa pun ke akun mereka.</li>
    <li>5.4. Semua penawaran BC.GAME ditujukan untuk pemain rekreasional dan BC.GAME atas kebijakannya sendiri dapat membatasi kelayakan pelanggan untuk berpartisipasi dalam semua atau sebagian dari promosi apa pun.</li>
    <li>5.5. BC.GAME berhak mengubah, membatalkan, mengklaim kembali, atau menolak promosi apa pun atas kebijaksanaannya sendiri.</li>
    <li>5.6. Bonus hanya dapat diterima satu kali per orang/akun, keluarga, rumah tangga, alamat, alamat email, alamat IP, dan lingkungan di mana komputer digunakan bersama (universitas, persaudaraan, sekolah, perpustakaan umum, tempat kerja, dll.). Operator berhak untuk menutup akun Anda dan menyita dana yang ada jika ditemukan bukti penyalahgunaan/penipuan.</li>
    <li>5.7. Anda mengakui dan memahami bahwa ada Perjanjian Pengguna terpisah sehubungan dengan promosi, bonus, dan penawaran khusus, dan merupakan tambahan dari Perjanjian Pengguna ini. Perjanjian Pengguna ini ditetapkan di halaman konten masing-masing di situs web ini, atau telah disediakan untuk Anda secara pribadi, tergantung pada keadaannya. Jika terjadi pertentangan antara ketentuan promosi, bonus, dan penawaran khusus tersebut, dan ketentuan Perjanjian Pengguna ini, ketentuan promosi, bonus, dan penawaran khusus tersebut akan berlaku.</li>
    <li>5.8. Kami mungkin bersikeras bahwa Anda bertaruh sejumlah tertentu dari deposit Anda sendiri sebelum Anda dapat bertaruh dengan dana gratis/bonus yang kami kreditkan ke akun Anda.</li>
    <li>5.9. Anda menerima bahwa promosi tertentu mungkin tunduk pada batasan Penarikan dan/atau persyaratan yang harus dipenuhi sebelum dana yang dikreditkan dalam promosi dapat ditarik. Ketentuan tersebut harus dipublikasikan dan tersedia sebagai bagian dari promosi. Jika Anda memilih untuk melakukan Penarikan sebelum persyaratan taruhan yang berlaku terpenuhi, kami akan mengurangi seluruh jumlah bonus serta setiap kemenangan yang terkait dengan penggunaan jumlah bonus sebelum menyetujui Penarikan apa pun.</li>
  </ul>
  
  <p>6. Obrolan Langsung</p>
  <p>6.1. Sebagai bagian dari penggunaan Anda atas Situs Web, kami dapat memberi Anda fasilitas obrolan langsung, yang dimoderasi oleh kami dan tunduk pada kontrol. Kami berhak meninjau obrolan dan mencatat semua pernyataan yang dibuat di fasilitas. Penggunaan fasilitas obrolan oleh Anda harus untuk tujuan rekreasi dan bersosialisasi.</p>
   <p>6.2. Kami berhak untuk menghapus fungsi ruang obrolan atau segera menghentikan Akun Anggota Anda dan mengembalikan saldo akun Anda jika Anda:</p>
  <ul class="content">
    <li>(a) membuat pernyataan apa pun yang eksplisit secara seksual atau sangat menyinggung, termasuk ekspresi kefanatikan, rasisme, kebencian, atau kata-kata tidak senonoh;</li>
     <li>(b) membuat pernyataan yang menghina, memfitnah, atau melecehkan atau menghina;</li>
     <li>(c) menggunakan fasilitas obrolan untuk mengiklankan, mempromosikan, atau berhubungan dengan entitas online lainnya;</li>
     <li>(d) membuat pernyataan tentang BC.GAME, atau situs Internet lainnya yang terhubung ke Situs Web yang tidak benar dan/atau berbahaya dan/atau merusak BC.GAME;</li>
     <li>(e) menggunakan fasilitas obrolan untuk berkolusi, terlibat dalam perilaku yang melanggar hukum, atau mendorong perilaku yang kami anggap sangat tidak pantas. Setiap obrolan yang mencurigakan akan dilaporkan ke otoritas yang berwenang.</li>
  </ul>
  
  <p>6.3. Obrolan Langsung digunakan sebagai bentuk komunikasi antara kami dan Anda dan tidak boleh disalin atau dibagikan dengan forum atau pihak ketiga mana pun.</p>

  <p>7. Batasan Tanggung Jawab</p>
  <ul class="content">
    <li>7.1. Anda memasuki Situs Web dan berpartisipasi dalam Permainan dengan risiko Anda sendiri. Situs Web dan Game disediakan tanpa jaminan apa pun, baik tersurat maupun tersirat.</li>
    <li>7.2. Tanpa mengurangi keumuman ketentuan sebelumnya, kami, direktur, karyawan, mitra, penyedia layanan kami.</li>
    <li>7.3. Tidak menjamin bahwa perangkat lunak, Game, dan Situs Web sesuai dengan tujuannya.</li>
    <li>7.4. Tidak menjamin bahwa perangkat lunak, Game, dan Situs Web bebas dari kesalahan.</li>
    <li>7.5. Tidak menjamin bahwa perangkat lunak, Game, dan Situs Web akan dapat diakses tanpa gangguan.</li>
    <li>7.6. Tidak akan bertanggung jawab atas kehilangan, biaya, pengeluaran atau kerusakan, baik langsung, tidak langsung, khusus, konsekuensial, insidental atau lainnya, yang timbul sehubungan dengan penggunaan Anda atas Situs Web atau partisipasi Anda dalam Permainan.</li>
    <li>7.7. Anda memahami dan mengakui bahwa, jika ada malfungsi dalam Game atau interoperabilitasnya, setiap taruhan yang dibuat selama malfungsi tersebut akan dibatalkan. Dana yang diperoleh dari Game yang tidak berfungsi akan dianggap batal, serta setiap putaran game berikutnya dengan dana tersebut, terlepas dari Game apa yang dimainkan menggunakan dana tersebut.</li>
    <li>7.8. Anda dengan ini setuju untuk sepenuhnya mengganti kerugian dan membebaskan kami, direktur, karyawan, mitra, dan penyedia layanan kami untuk setiap biaya, pengeluaran, kehilangan, kerusakan, klaim, dan kewajiban apa pun penyebabnya yang mungkin timbul sehubungan dengan penggunaan Anda atas Situs Web atau partisipasi dalam Permainan.</li>
    <li>7.9. Sejauh diizinkan oleh hukum, tanggung jawab maksimum kami yang timbul dari atau sehubungan dengan penggunaan Anda atas Situs Web, terlepas dari penyebab tindakan (baik dalam kontrak, kesalahan, pelanggaran garansi atau lainnya), tidak akan melebihi \u20AC100.</li>
  </ul>

  <p>8. Pelanggaran, Penalti, dan Pemutusan Hubungan Kerja</p>
  <ul class="content">
    <li>8.1. Jika Anda melanggar ketentuan apa pun dari Perjanjian Pengguna ini atau kami memiliki alasan yang masuk akal untuk mencurigai bahwa Anda telah melanggarnya, kami berhak untuk tidak membuka, menangguhkan, atau menutup Akun Anggota Anda, atau menahan pembayaran kemenangan Anda dan menerapkan ketentuan tersebut. dana untuk setiap kerusakan yang Anda tanggung.</li>
     <li>8.2. Anda mengakui bahwa BC.GAME akan menjadi pengambil keputusan akhir apakah Anda telah melanggar aturan, syarat, atau ketentuan BC.GAME dengan cara yang mengakibatkan penangguhan atau pembatasan permanen Anda untuk berpartisipasi di situs kami.</li>
  </ul>

  <p>9. Pengunduran diri</p>
  <ul class="content">
    <li>9.1. Dengan meminta periode Pengunduran diri, Anda setuju untuk mengikuti persyaratan dan ketentuan di bawah ini, yang akan berlaku sejak CS menerapkan periode Pengunduran diri yang dipilih.</li>
    <li>9.2. Anda dapat mengecualikan diri untuk periode 1, 3, 6, 12 bulan/s atau permanen. Permintaan Pengunduran diri harus dilakukan melalui Dukungan Langsung.</li>
    <li>9.3. Setelah Anda mengecualikan diri, Anda tidak akan dapat mengakses akun Anda atau menarik diri selama periode ini.</li>
    <li>9.4. Jika Anda telah mengecualikan akun Anda sementara Anda memiliki taruhan tertunda di akun Anda, taruhan yang ditempatkan akan tetap berlaku dan diselesaikan sesuai dengan hasil resmi. </li>
    <li>9.5. Setelah periode Pengunduran diri berakhir, Anda dapat menarik kemenangan dari taruhan yang memenuhi syarat. BC.GAME tidak membatalkan atau membatalkan taruhan yang ditempatkan sebelum Pengunduran diri terpengaruh.</li>
    <li>9.6. Setelah Anda mengecualikan diri, Anda tidak akan dapat mengubah atau mengubah periode untuk jangka waktu yang lebih pendek atau Pengunduran diri Anda dibatalkan hingga periode yang Anda pilih untuk Pengunduran diri telah berlalu.</li>
    <li>9.7. Silakan hubungi tim layanan pelanggan kami jika Anda ingin memperpanjang periode Pengunduran diri Anda.</li>
    <li>9.8. Setelah periode Pengunduran diri Anda berlalu, pemulihan akun dapat dilakukan dengan mengirim email permintaan ke support@BC.GAME.</li>
    <li>9.9. Dengan mengecualikan diri, Anda setuju bahwa:</li>
    <ul class="konten">
      <li> a) Anda tidak akan membuat akun lain selama periode ini.</li>
      <li> b) Anda tidak akan menyetor atau mencoba menyetor dana ke akun BC.GAME. </li>
      <li> c) Anda tidak akan bertaruh di situs web ini selama periode ini.</li>
      <li> d) Ini adalah tindakan sukarela yang dilakukan oleh Anda sendiri, dan BlockDance B.V. tidak akan bertanggung jawab atas kerugian apa pun yang mungkin Anda alami selama periode Pengunduran diri dalam bentuk apa pun.</li>
    </ul>
  </ul>
</section>
<section>
  <h2>Kebijakan Privasi</h2> 
  <p> Anda dengan ini mengakui dan menerima bahwa jika kami anggap perlu, kami dapat mengumpulkan dan menggunakan data pribadi Anda untuk memungkinkan Anda mengakses dan menggunakan Situs Web dan untuk memungkinkan Anda berpartisipasi dalam Permainan.</ p>
  <p>Dengan ini kami mengakui bahwa dalam mengumpulkan data pribadi Anda sebagaimana dinyatakan dalam ketentuan sebelumnya, kami terikat oleh Undang-Undang Perlindungan Data. Kami akan melindungi informasi pribadi Anda dan menghormati privasi Anda sesuai dengan praktik bisnis terbaik dan hukum yang berlaku.</p>
  <p>Kami akan menggunakan data pribadi Anda untuk memungkinkan Anda berpartisipasi dalam Game dan menjalankan operasi yang relevan dengan partisipasi Anda dalam Game. Kami juga dapat menggunakan data pribadi Anda untuk memberi tahu Anda tentang perubahan, layanan baru, dan promosi yang menurut kami menarik bagi Anda. Jika Anda tidak ingin menerima korespondensi pemasaran langsung seperti itu, Anda dapat memilih keluar dari layanan.</p>
  <p>Data pribadi Anda tidak akan diungkapkan kepada pihak ketiga, kecuali diwajibkan oleh hukum. Karena BC.GAME mitra bisnis atau pemasok atau penyedia layanan mungkin bertanggung jawab atas bagian-bagian tertentu dari keseluruhan fungsi atau pengoperasian Situs Web, data pribadi dapat diungkapkan kepada mereka. Karyawan BC.GAME memiliki akses ke data pribadi Anda untuk tujuan melaksanakan tugas mereka dan memberi Anda bantuan dan layanan terbaik. Anda dengan ini menyetujui pengungkapan tersebut.</p>
  <p>Kami akan menyimpan semua informasi yang diberikan sebagai data pribadi. Anda memiliki hak untuk mengakses data pribadi yang kami simpan tentang Anda. Tidak ada data yang akan dimusnahkan kecuali diwajibkan oleh hukum, atau kecuali informasi yang disimpan tidak lagi diperlukan untuk tujuan hubungan tersebut.</p>
  <p>Untuk membuat kunjungan Anda ke Situs Web lebih ramah pengguna, untuk melacak kunjungan ke Situs Web dan untuk meningkatkan layanan, kami mengumpulkan sebagian kecil informasi yang dikirim dari browser Anda, yang disebut cookie. Anda dapat, jika mau, mematikan koleksi cookie. Namun, Anda harus memperhatikan bahwa mematikan cookie dapat sangat membatasi atau sepenuhnya menghalangi penggunaan Situs Web oleh Anda.</p>
</section>
  <section>
    <h2>Kebijakan Cookies</h2>
  <p>1.Apa itu cookies?</p>
  <ul class="content">
    <li>Cookie adalah sepotong informasi dalam bentuk file teks yang sangat kecil yang ditempatkan di komputer pengguna internet. Itu dihasilkan oleh server halaman web (yang pada dasarnya adalah komputer yang mengoperasikan situs web) dan dapat digunakan oleh server itu setiap kali pengguna mengunjungi situs. Cookie dapat dianggap sebagai kartu identitas pengguna internet, yang memberi tahu situs web ketika pengguna telah kembali. Cookie tidak dapat membahayakan komputer Anda dan kami tidak menyimpan informasi pengenal pribadi tentang Anda di salah satu cookie kami.</li>
   </ul>
   <p>2.Mengapa kami menggunakan cookie di BC.GAME?</p>
  <ul class="content">
    <li>BC.GAME menggunakan dua jenis cookie: cookie yang ditetapkan oleh kami dan cookie yang ditetapkan oleh pihak ketiga (yaitu situs web atau layanan lain). Cookie BC.GAME memungkinkan kami untuk membuat Anda tetap masuk ke akun Anda selama kunjungan Anda dan untuk menyesuaikan informasi yang ditampilkan di situs dengan preferensi Anda.</li>
   </ul>
   <p>3. Cookie apa yang kami gunakan di BC.GAME?</p>
   <p>Di bawah ini adalah daftar cookie utama yang ditetapkan oleh BC.GAME, dan kegunaan masing-masing cookie:</p>
  <ul class="content">
    <li>_fp - menyimpan sidik jari browser. Seumur hidup: selamanya.</li>
    <li>_t - menyimpan stempel waktu saat pengguna pertama kali mengunjungi situs dalam sesi penjelajahan saat ini. Diperlukan untuk statistik kunjungan unik. Seumur hidup: sesi penjelajahan.</li>
    <li>_r - menyimpan perujuk http untuk sesi penjelajahan saat ini. Diperlukan untuk melacak sumber lalu lintas eksternal. Seumur hidup: sesi penjelajahan.</li>
    <li>_c - menyimpan pengidentifikasi kampanye afiliasi. Dibutuhkan untuk statistik afiliasi. Seumur hidup: selamanya.</li>
    <li>Cookie yang disetel oleh pihak ketiga untuk domain wildcard: *.BC.GAME</li>
    <li>Analisis Google: _ga, _gat, _gid</li>
    <li>Zendesk\uFF1A__ zlcmid</li>
    <li>Cloudflare\uFF1A__ cfuid</li>
    <li>Harap diingat bahwa beberapa browser (yaitu chrome di mac) tetap menjalankan proses latar belakang meskipun tidak ada tab yang dibuka karena cookie sesi ini mungkin disetel di antara sesi.</li>
    <li>Ada juga cookie yang disetel oleh skrip pihak ketiga ke domain mereka.</li>
  </ul>
  
  
  <p>4.Bagaimana cara mengelola cookies saya di BC.GAME?</p>
  <ul class="content">
    <li>Jika Anda ingin berhenti menerima cookie, Anda dapat melakukannya melalui opsi Pengaturan Privasi di browser Anda.</li>
   </ul>
  
   <p>5.Kebijakan Perlindungan Data Pribadi</p>
  <ul class="content">
    <li>Misi BC.GAME adalah menjaga keamanan Data Anda dan dalam hal ini kami melindungi data Anda dengan berbagai cara. Kami menyediakan pelanggan kami dengan standar keamanan yang tinggi, seperti enkripsi data yang bergerak melalui jaringan publik, enkripsi data dalam database, standar audit, mitigasi Distributed Denial of Service, dan Live Chat yang tersedia di tempat.</li>
   </ul>

   <p>6.Kebijakan Perlindungan Server</p>
  <ul class="content"><li>Semua server memiliki enkripsi penuh;</li>
     <li>Semua cadangan memiliki enkripsi;</li>
     <li>Firewall, Akses VPN;</li>
     <li>Akses ke server hanya diperbolehkan melalui VPN;</li>
     <li>Semua layanan http/s bekerja melalui Cloudflare;</li>
     <li>Koneksi ke node melalui VPN;</li>
     <li>Terowongan penerusan port SSH;</li>
     <li>Layanan hanya diizinkan melalui VPN;</li>
     <li>Server memiliki firewall dan hanya mengizinkan port SSH;</li>
     <li>Peringatan tentang layanan penting.</li>
     <li>Pemberitahuan Pelanggaran Data</li>
     <li>Ketika BC.GAME akan diberitahu tentang pelanggaran data pribadi, kami akan memberi tahu pengguna yang relevan sesuai dengan kerangka waktu GDPR.</li>
   </ul>
  
   <p>7.Transfer Internasional Data</p>
  <ul class="content">
    <li>Kami hanya mengungkapkan data pribadi kepada pihak ketiga jika diperlukan untuk menyediakan layanan berkualitas tinggi atau untuk menanggapi permintaan yang sah dari pihak berwenang.</li>
     <li>Kami membagikan data berikut ke sistem pihak ketiga:</li>
     <li>Zendesk Inc. \u2013 nama pengguna dan informasi email ditransfer jika pengguna mengirim pesan ke live-chat atau mengirim email ke kotak surat dukungan.</li>
     <li>Meskipun kami mencoba melakukan yang terbaik, masalah bisa saja terjadi sesekali. Tim kami akan melakukan segala yang kami bisa untuk menyelesaikan masalah Anda sesegera mungkin. Untuk membantu Anda lebih cepat, Anda dapat bergabung dengan kami dengan mengklik tombol di atas untuk bergabung dengan grup telegram.</li>
     <li>Jika terjadi kesalahan, berikan informasi berikut:</li>
    <ul class="content">
      <li>Nama pengguna</li>
      <li>Tanggal dan waktu masalah</li>
    </ul>
  </ul>
  
  <p>ID Game atau nama tabel, jika ada</p>
  <p>Screenshot kesalahan, jika memungkinkan</p>
  <p>Kami sangat menghargai bantuan Anda dan laporan kesalahan yang Anda berikan karena laporan informasi Anda dapat membantu kami menjadi lebih baik.</p>
  <p>Mengumpulkan dan Menggunakan Data Pribadi Anda</p>
  <p>Jenis Data yang Dikumpulkan</p>
  <p>Data Pribadi</p>
  <p>Saat menggunakan Layanan Kami, Kami dapat meminta Anda untuk memberikan kepada Kami informasi pengenal pribadi tertentu yang dapat digunakan untuk menghubungi atau mengidentifikasi Anda. Informasi pengenal pribadi dapat mencakup, tetapi tidak terbatas pada:</p>
  <p>Alamat email</p>
  <p>Nama depan dan nama belakang</p>
  <p>Data Penggunaan</p>
  <p>Data Penggunaan</p>
  <p>Data Penggunaan dikumpulkan secara otomatis saat menggunakan Layanan.</p>
  <p>Data Penggunaan dapat mencakup informasi seperti alamat Protokol Internet Perangkat Anda (misalnya alamat IP), jenis browser, versi browser, halaman Layanan kami yang Anda kunjungi, waktu dan tanggal kunjungan Anda, waktu yang dihabiskan di halaman tersebut , pengidentifikasi perangkat unik, dan data diagnostik lainnya.</p>
  <p>Saat Anda mengakses Layanan dengan atau melalui perangkat seluler, Kami dapat mengumpulkan informasi tertentu secara otomatis, termasuk, namun tidak terbatas pada, jenis perangkat seluler yang Anda gunakan, ID unik perangkat seluler Anda, alamat IP perangkat seluler Anda , Sistem operasi seluler Anda, jenis peramban Internet seluler yang Anda gunakan, pengidentifikasi perangkat unik, dan data diagnostik lainnya.</p>
  <p>Kami juga dapat mengumpulkan informasi yang dikirimkan browser Anda setiap kali Anda mengunjungi Layanan kami atau saat Anda mengakses Layanan dengan atau melalui perangkat seluler.</p>
  <p>Informasi dari Layanan Media Sosial Pihak Ketiga</p>
  <p>BC.GAME memungkinkan Anda membuat akun dan masuk untuk menggunakan Layanan melalui Layanan Media Sosial Pihak Ketiga berikut:</p>
  <ul class="content">
    <li>Google</li>
    <li>Facebook</li>
    <li>Telegram</li>
    <li>Metamask</li>
  </ul>
  </section>
  <section>
  <h2>Web3.0</h2>
  <p>Jika Anda memutuskan untuk mendaftar melalui atau memberi kami akses ke Layanan Media Sosial Pihak Ketiga, Kami dapat mengumpulkan data Pribadi yang telah dikaitkan dengan akun Layanan Media Sosial Pihak Ketiga Anda, seperti nama Anda, alamat email Anda, aktivitas Anda atau Daftar kontak Anda yang terkait dengan akun tersebut.</p>
  <p>Anda juga dapat memiliki opsi untuk berbagi informasi tambahan dengan BC.GAME melalui akun Layanan Media Sosial Pihak Ketiga Anda. Jika Anda memilih untuk memberikan informasi dan Data Pribadi tersebut, selama pendaftaran atau lainnya, Anda memberi BC.GAME izin untuk menggunakan, membagikan, dan menyimpannya dengan cara yang sesuai dengan Kebijakan Privasi ini.</p>
  <p>Hapus Data Pribadi</p>
  <p>Anda dapat meminta agar data pribadi Anda dihapus jika BC.GAME tidak lagi memiliki alasan hukum untuk terus memproses atau menyimpannya. Harap dicatat bahwa hak ini tidak dijamin - dalam arti bahwa BC.GAME tidak memiliki kemampuan untuk memenuhi permintaan Anda jika tunduk pada kewajiban hukum untuk menyimpan data Anda. Anda dapat meminta penghapusan data pribadi Anda dengan mengirimkan email ke support@BC.GAME.</p>
  </section>
  <section>
    <h2>Registrasi dan Login</h2>
     <p>Anda harus berusia minimal 18 tahun untuk mendaftar. Jika Anda ingin menambahkan alamat email Anda, pastikan alamat email yang Anda masukkan sudah benar agar nantinya bisa digunakan dalam verifikasi akun KYC.</p>
     <p>Anda dapat masuk kapan saja. Untuk keamanan tambahan, kami menyarankan Anda untuk menambahkan 2FA. Untuk mengetahui lebih lanjut tentang Google authenticator.</p>
     <p>Jika Anda perlu mengubah email terdaftar Anda, kami mohon maaf, tetapi kami tidak dapat memperbarui informasi ini. Jika Anda bersikeras mengubah nama pengguna dan/atau email terdaftar, kami sarankan Anda menutup akun saat ini dan mendaftarkan akun baru.</p>
  </section>
</section>

`;

function s() {
    return e(a, {
        br: i,
        en: n,
        id: o
    })
}
export {
    s as
    default
};
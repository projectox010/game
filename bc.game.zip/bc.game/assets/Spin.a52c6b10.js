var ie = Object.defineProperty;
var D = Object.getOwnPropertySymbols;
var re = Object.prototype.hasOwnProperty,
    ce = Object.prototype.propertyIsEnumerable;
var O = (t, n, s) => n in t ? ie(t, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[n] = s,
    j = (t, n) => {
        for (var s in n || (n = {})) re.call(n, s) && O(t, s, n[s]);
        if (D)
            for (var s of D(n)) ce.call(n, s) && O(t, s, n[s]);
        return t
    };
import {
    a5 as $,
    u as A,
    aY as a,
    cb as V,
    j as c,
    a as e,
    cX as f,
    b as x,
    cY as U,
    l as T,
    cZ as oe,
    as as J,
    at as X,
    r as u,
    e as Y,
    c_ as le,
    z as Z,
    bs as K,
    J as M,
    p as L,
    A as k,
    N as Q,
    O as de,
    cU as pe,
    $ as ee,
    G as P,
    k as S,
    c$ as me,
    d0 as ue,
    d1 as he,
    d2 as ge,
    d3 as fe,
    d4 as ve,
    d5 as B,
    d6 as ye,
    g as C,
    d7 as be,
    aO as F,
    F as E,
    o as ne,
    ao as Ne,
    d as R,
    m as Se,
    b1 as z,
    d8 as we,
    bI as _e,
    bJ as ke,
    d9 as se,
    da as te,
    M as Ce,
    a4 as Le,
    a3 as ae,
    K as xe,
    aV as Te,
    db as Ae,
    s as Ie
} from "./index.28e31dff.js";

function Be() {
    return [{
        active: f.tbtn_luckspin_2,
        default: f.tbtn_luckspin_1,
        value: 0
    }, {
        active: f.tbtn_superspin_2,
        default: f.tbtn_superspin_1,
        value: 1
    }, {
        active: f.tbtn_megaspin_2,
        default: f.tbtn_megaspin_1,
        value: 2
    }]
}
const Ee = $.memo(function({
        tab: n,
        onTab: s,
        level: i,
        updateFinished: o
    }) {
        const l = A(),
            r = a.tabs,
            d = V.find(p => p[4] === n) || V[0],
            m = n <= 1 && i === 0 ? 0 : d[0];
        return c("div", {
            className: Pe,
            children: [e("div", {
                className: "tab-nav",
                children: Be().map(p => c(x, {
                    style: {
                        backgroundColor: n === r[p.value] ? U(n) : "#191a1b"
                    },
                    onClick: () => s(r[p.value]),
                    children: [n != r[p.value] && e("img", {
                        src: p.default
                    }), n === r[p.value] && e("img", {
                        src: p.active
                    })]
                }, p.value))
            }), e("div", {
                className: "tag-wrap",
                children: c("div", {
                    className: T("tag", o && "active"),
                    style: {
                        backgroundColor: U(n)
                    },
                    children: [e("div", {
                        className: "tag-img",
                        style: {
                            color: U(n)
                        },
                        children: oe(d[4])
                    }), e("div", {
                        className: "desc",
                        children: l("page.spin.level_above", String(m))
                    })]
                })
            })]
        })
    }),
    Pe = "s1aophl7";
const Re = J(() => X(() =>
    import ("./SpinResultParticles.fbdd773e.js"), ["assets/SpinResultParticles.fbdd773e.js", "assets/SpinResultParticles.22db9602.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css", "assets/usePixiGsap.bf451f35.js"]));

function Me() {
    const t = Math.floor(Math.random() * 3);
    return t === 0 ? "I got free Crypto from BC.GAME free daily spin! Try your luck now! Free spin to get 5 BTC!" : t === 1 ? "Wow! I won free crypto from daily free spin at BC.GAME! Try your luck now! Free spin to get 5 BTC!" : "I got lucky at BC.GAME free Lucky Spin today! Try your luck now! Free spin to get 5 BTC!"
}

function Fe() {
    const t = A(),
        {
            data: n
        } = Q(() => de({
            title: "Spin",
            content: Me()
        }));
    if (!n) return e("div", {
        className: G
    });
    const s = n.filter(i => i.src);
    return c("div", {
        className: G,
        children: [e("div", {
            className: "share-bottom",
            children: e("div", {
                className: "word",
                children: t("page.share.share_social")
            })
        }), e("div", {
            className: "share-cont",
            children: s.slice(0, 6).map((i, o) => e("a", {
                href: i.src,
                target: "_blank",
                rel: "noopener noreferrer",
                className: T("share-item", o > 2 && "disabled"),
                children: e("img", {
                    className: "icon",
                    src: i.icon
                })
            }, o))
        })]
    })
}
const G = "s3ew4v3";

function $e({
    amount: t,
    currencyName: n,
    locked: s,
    level: i,
    trackId: o,
    bigPrize: l
}) {
    const r = A(),
        [d, m] = u.exports.useState(!1),
        p = Y(),
        h = async function() {
            const v = pe.currentRoom.id,
                y = r("page.share.success");
            if (await L.confirm(r("page.share.room") + "?")) return ee.post("/activity/lucky/spin/share/", {
                trackId: o,
                roomId: v
            }).then(() => {
                P(y), m(!0)
            })
        };
    return c("div", {
        className: Ue,
        children: [e(Re, {
            bigPrize: l
        }), c("div", {
            className: "img-cont",
            children: [e("img", {
                className: "bg",
                src: f.bg_lottery,
                alt: ""
            }), e("img", {
                className: "img",
                src: le(a.getTab(i)),
                alt: ""
            })]
        }), c("div", {
            className: T("cont", s && "locked"),
            children: [e(Z, {
                name: n
            }), "+ ", K(t, 5), c("span", {
                className: "currency",
                children: [s && "Locked", " ", M.getAlias(n)]
            })]
        }), c("div", {
            className: "btn-wrap",
            children: [e(x, {
                className: "collect",
                type: "conic",
                onClick: () => {
                    s ? (L.close(), setTimeout(() => {
                        p("/bonus_dashboard")
                    }, 50)) : L.back(), a.soundSprites.play("Collect")
                },
                children: s ? r("common.actions.view_my", "BCD") : r("common.actions.collect_now")
            }), e(x, {
                onClick: h,
                disabled: d,
                className: "share-local",
                children: e(k, {
                    name: "Share"
                })
            })]
        }), e(Fe, {})]
    })
}
const Ue = "s1w718k2";
J(async () => (await ve(1e3), X(() =>
    import ("./SpinBtnParticles.76f7822f.js"), ["assets/SpinBtnParticles.76f7822f.js", "assets/index.28e31dff.js", "assets/index.3647d14f.css", "assets/usePixiGsap.bf451f35.js"])));

function ze(t, n, s, i, o) {
    const l = a.getTab(t),
        r = B(),
        d = ye(o.length, {
            ref: r,
            config: {
                mass: 1,
                tension: 1e3,
                friction: 26
            },
            opacity: s ? 0 : 1,
            height: s ? 0 : 24,
            x: s ? 0 : 20,
            from: {
                opacity: 1,
                height: 24,
                x: 0
            }
        }),
        m = B(),
        p = C({
            ref: m,
            opacity: s ? 0 : 1,
            scale: s ? .3 : 1,
            rotate: s ? -30 : 0
        }),
        h = B(),
        v = C({
            ref: h,
            scale: s ? 2 : 1,
            opacity: s ? 0 : 1,
            onChange: b => {
                b.value.opacity < .01 && a.levelUpdateFinished()
            }
        }),
        y = B(),
        g = C({
            ref: y,
            opacity: s ? 0 : 1,
            y: s ? -100 : 0
        }),
        w = B(),
        I = C({
            ref: w,
            opacity: s ? 0 : 1,
            scale: s ? 1.5 : 1
        });
    return be(s ? [r, w, m, y, h] : [h, m, r, w, y], s ? [0, .6, 1, 1.2, 1.4] : [0, .4, .6, 1, 1.4]), {
        spinPoint: e(S.img, {
            style: I,
            src: me(t),
            alt: ""
        }),
        spinMain: c(S.div, {
            className: De,
            style: p,
            children: [e("img", {
                className: T("spin-light", !n && !s && "active"),
                src: f.spinLight3,
                alt: ""
            }), e("img", {
                className: "spin-img",
                src: ue(t),
                alt: ""
            }), t === 5 && e("img", {
                className: "diamond-cont",
                src: f.spin_diamond_fuck,
                alt: ""
            }), d.map((b, _) => c(S.div, {
                className: "spin-item",
                style: {
                    opacity: b.opacity,
                    height: b.height,
                    transform: `rotate(${_*22.5}deg)`
                },
                children: [e("span", {
                    className: "amount",
                    children: K(o[_].amount, 5)
                }), e(Z, {
                    name: o[_].currencyName
                }), o[_].locked && e(k, {
                    name: "Locked"
                })]
            }, _))]
        }),
        spinBtn: c(S.div, {
            style: v,
            className: T(n && "loading", "btn-img"),
            onClick: i,
            children: [e("img", {
                src: he(t),
                alt: ""
            }), e("img", {
                className: "btn-txt",
                src: ge(l),
                alt: ""
            })]
        }),
        spinBanner: e(S.img, {
            style: g,
            src: fe(t)
        })
    }
}
const De = "st4nmvc";
const Oe = {
        from: {
            opacity: 0,
            scale: .3,
            rotate: -30
        },
        to: {
            opacity: 1,
            scale: 1,
            rotate: 0
        }
    },
    W = {
        from: {
            y: -50,
            opacity: 0,
            scale: .3
        },
        to: {
            y: 0,
            opacity: 1,
            scale: 1
        }
    };

function je(t, n) {
    let s = 360;
    if (t > 0 && n.current) {
        const i = n.current.style.transform.match(/\d+/),
            o = i ? i[0] : 0,
            l = (Math.ceil(Number(o) / 360) + 5) * 360;
        s = 360 - t * 22.5 + l
    }
    return s
}
const Ve = $.memo(function({
        level: n,
        res: s,
        loading: i,
        update: o,
        onSpin: l
    }) {
        const r = u.exports.useRef(null),
            d = u.exports.useRef(null),
            m = u.exports.useRef(null),
            p = a.spinOptions[n],
            [h, v] = C(() => Oe),
            [y, g] = C(() => W),
            {
                spinPoint: w,
                spinMain: I,
                spinBtn: b,
                spinBanner: _
            } = ze(n, i, o, l, p);
        return u.exports.useEffect(() => {
            const N = F.timeline();
            return s > 0 && r.current && m.current && d.current ? (N.to(r.current, {
                rotate: je(s, r),
                duration: 3.6
            }), N.to(d.current, {
                scale: 1.1,
                duration: .3,
                delay: .3
            }), N.to(d.current, {
                scale: 1,
                duration: .2
            }), N.set(m.current, {
                x: -20,
                scale: 1
            }), N.to(m.current, {
                x: 200,
                skewX: -25,
                scale: 3.4,
                duration: .5,
                delay: .3
            }), N.to(d.current, {
                scale: 1,
                onComplete: () => {
                    a.setSpinAnimateEnd()
                }
            })) : N.set(r.current, {
                rotate: 0
            }), () => {
                F.killTweensOf(N)
            }
        }, [s]), u.exports.useEffect(() => () => a.setSpinAnimateEnd(), []), u.exports.useEffect(() => {
            g.start(W), v.start({
                reset: !0
            })
        }, [n]), c(E, {
            children: [c(S.div, {
                className: H,
                style: h,
                children: [e("div", {
                    ref: r,
                    className: H,
                    children: I
                }), c("div", {
                    className: "point-img",
                    ref: d,
                    children: [e("div", {
                        className: "light-wrap",
                        children: e("div", {
                            ref: m,
                            className: "point-light"
                        })
                    }), w]
                })]
            }), b, e(S.div, {
                style: y,
                className: "banner-img",
                children: _
            })]
        })
    }),
    H = "s1zzacp";
const Ge = ne(function({
        level: n
    }) {
        const [s, i] = Ne({
            res: 0
        }), o = A(), l = a.spinLoading, r = a.levelUpdated, d = Y(), m = R.login, p = we(n), h = async function() {
            if (a.soundSprites.play("Click"), !m) return L.close(), d("/login?redirect=/spin");
            if (!l) {
                if (a.freeTimes === 0) return P("Uh oh! Sorry but you don't have free spin yet!");
                if (n != a.spinLevel) return P("Uh ho! Please try other Spin");
                try {
                    a.spinLoading = !0;
                    const g = await a.handleSpin();
                    a.soundSprites.play("SpinAndBonus"), a.freeTimes = g.leftTimes, i({
                        res: g.hitSection - 1
                    }), await a.spinAnimateEnd(), a.spinLoading = !1, L.push(e($e, {
                        locked: g.locked,
                        amount: g.amount,
                        currencyName: g.currencyName,
                        bigPrize: g.bigPrize,
                        level: a.spinLevel,
                        trackId: g.trackId
                    })), g.leftTimes === 0 && a.setNextTime()
                } catch (g) {
                    P(g), a.spinLoading = !1
                }
            }
        };
        u.exports.useEffect(() => {
            i({
                res: 0
            })
        }, [n]);
        const v = m ? `${o("page.spin.free")}: ${a.freeTimes}` : o("page.spin.free"),
            y = R.login && (n != a.spinLevel || a.freeTimes <= 0);
        return c("div", {
            className: We,
            children: [e(Ve, {
                level: n,
                res: s.res,
                update: r,
                onSpin: h,
                loading: a.spinLoading
            }), e(x, {
                onClick: h,
                disabled: y,
                style: {
                    backgroundColor: p[0],
                    backgroundImage: `conic-gradient(from 1turn, ${p[1]}, ${p[0]})`
                },
                type: "conic4",
                className: "btn",
                children: a.freeTimes === 0 && R.login ? c(E, {
                    children: [c("span", {
                        style: {
                            marginRight: "5px"
                        },
                        children: [o("page.spin.next_free"), ":"]
                    }), e(Se, {
                        endTime: a.nextTime,
                        onEnd: a.getUserInfo,
                        children: ({
                            days: g,
                            hours: w,
                            minutes: I,
                            seconds: b
                        }) => c("div", {
                            className: "time-wrap",
                            children: [e("b", {
                                children: z(w)
                            }), e("b", {
                                className: "colon",
                                children: ":"
                            }), e("b", {
                                children: z(I)
                            }), e("b", {
                                className: "colon",
                                children: ":"
                            }), e("b", {
                                children: z(b)
                            })]
                        })
                    })]
                }) : v
            })]
        })
    }),
    We = "szbrnh5";

function He({
    list: t,
    onBack: n
}) {
    const [s, i] = u.exports.useState(!1), o = A();
    u.exports.useEffect(() => {
        i(!0)
    }, []);
    const l = () => {
        i(!1), setTimeout(() => {
            n()
        }, 200)
    };
    return e("div", {
        className: T(qe, s && "enter"),
        children: c("div", {
            className: "winlist-wrap",
            children: [e("div", {
                className: "pop-control",
                children: e("button", {
                    onClick: l,
                    className: "back",
                    children: e(k, {
                        name: "Arrow"
                    })
                })
            }), c("div", {
                className: "header",
                children: [e("img", {
                    src: f.crown,
                    className: "crown",
                    alt: ""
                }), c("div", {
                    className: "spin-bonus",
                    children: [e("img", {
                        className: "pre-img",
                        src: f.laurel,
                        alt: ""
                    }), e("div", {
                        className: "tit",
                        children: "Spin Bonus"
                    }), e("img", {
                        className: "suf-img",
                        src: f.laurel,
                        alt: ""
                    })]
                })]
            }), c("div", {
                className: "win-list",
                children: [c("div", {
                    className: "table-header td",
                    children: [e("p", {
                        children: o("page.share.username_label")
                    }), e("p", {
                        children: o("page.spin.level")
                    }), e("p", {
                        children: o("common.prize")
                    })]
                }), t.length > 0 ? e(_e, {
                    slidesPerView: "auto",
                    direction: "vertical",
                    freeMode: !0,
                    loop: !0,
                    autoplay: {
                        delay: 200,
                        disableOnInteraction: !1
                    },
                    effect: "fade",
                    slidesPerGroup: 1,
                    className: "winlist-swiper swiper-no-swiping",
                    children: t.map((r, d) => c(ke, {
                        className: "td",
                        children: [e("p", {
                            className: "name",
                            children: r.username
                        }), e("p", {
                            children: e("span", {
                                style: {
                                    color: se(a.getTab(r.level))
                                },
                                children: te(a.getTab(r.level))
                            })
                        }), e("p", {
                            children: e(Ce, {
                                sign: !0,
                                icon: !0,
                                name: r.currencyName,
                                amount: r.amount
                            })
                        })]
                    }, "tr-" + d))
                }) : e(Le, {})]
            })]
        })
    })
}
const qe = "s8knv0f";

function Je() {
    return ee.post("/activity/lucky/spin/news/", {
        start: new Date().getTime() - 24 * 60 * 60 * 1e3
    })
}

function Xe({
    num: t
}) {
    const n = {
            val: a.totalBonus
        },
        s = u.exports.useRef(null),
        i = A();
    return u.exports.useEffect(() => {
        const o = F.to(n, {
            val: t,
            duration: 3,
            ease: Ae.easeInOut,
            onUpdate: () => {
                s.current && (s.current.innerHTML = M.toLocaleCurrency(n.val, "USD"))
            }
        });
        return a.totalBonus = t, () => F.killTweensOf(o)
    }, [t]), c("div", {
        className: "left-cont",
        children: [e("div", {
            className: "tit",
            children: i("page.spin.totalbonus")
        }), e("div", {
            className: "amount",
            ref: s,
            children: M.toLocaleCurrency(n.val, "USD")
        })]
    })
}
const Ye = $.memo(function({
        spinLoading: n
    }) {
        const [s, i] = u.exports.useState(!1), {
            data: o,
            error: l
        } = Q(Je);
        return o ? c(E, {
            children: [s && e(He, {
                list: o.updates,
                onBack: () => i(!1)
            }), c("div", {
                className: q,
                children: [e(Xe, {
                    num: o.totalBonus
                }), e("div", {
                    className: "right-cont",
                    onClick: () => {
                        n || i(!s)
                    },
                    children: e(Ke, {
                        list: o.updates
                    })
                })]
            })]
        }) : e("div", {
            className: q,
            children: e(ae, {})
        })
    }),
    Ze = $.memo(({
        data: t,
        it: n
    }) => c(S.div, {
        className: "data-cont",
        style: j({
            position: "absolute"
        }, n),
        children: [e(xe, {
            name: "",
            userId: t.userId
        }), c("div", {
            className: "cont",
            children: [e("div", {
                className: "name",
                children: t.username
            }), c("div", {
                className: "win",
                children: ["Win: ", e("span", {
                    className: "amount",
                    children: t.amount
                }), " ", e("span", {
                    className: "currency",
                    children: M.getAlias(t.currencyName)
                }), " "]
            }), c("div", {
                className: "type",
                children: ["in ", e("b", {
                    style: {
                        color: se(a.getTab(t.level))
                    },
                    children: te(a.getTab(t.level))
                })]
            })]
        }), e(k, {
            name: "Arrow"
        })]
    }));

function Ke({
    list: t
}) {
    const [n, s] = u.exports.useState(0), i = t[n % t.length], o = Te(i, {
        from: {
            y: "100%"
        },
        enter: {
            y: "0%"
        },
        leave: {
            y: "-100%"
        }
    });
    return u.exports.useEffect(() => {
        const l = window.setInterval(() => s(r => r + 1), 5e3);
        return () => {
            clearInterval(l)
        }
    }, []), e("div", {
        children: o((l, r, d, m) => e(Ze, {
            data: r,
            it: l
        }, m))
    })
}
const q = "sydmigf",
    Qe = ne(function() {
        const n = a.spinLevel,
            s = Ie.isMobile,
            i = a.tabs,
            o = R.vipLevel,
            [l, r] = u.exports.useState({
                tab: n
            });
        u.exports.useEffect(() => {
            r({
                tab: n
            })
        }, [n]);

        function d(h) {
            a.spinLoading || r({
                tab: h
            })
        }

        function m() {
            const h = i.findIndex(v => v === l.tab);
            d(i[h - 1])
        }

        function p() {
            const h = i.findIndex(v => v === l.tab);
            d(i[h + 1])
        }
        return c(E, {
            children: [e(Ee, {
                tab: l.tab,
                level: o,
                onTab: d,
                updateFinished: a.updateFinished
            }), e(Ge, {
                level: l.tab
            }), s && c(E, {
                children: [e(x, {
                    disabled: l.tab === i[0],
                    className: "pre_btn",
                    onClick: m,
                    children: e("div", {
                        className: "btn-wrap",
                        children: e(k, {
                            name: "Arrow"
                        })
                    })
                }), e(x, {
                    disabled: l.tab === i[i.length - 1],
                    className: "suff_btn",
                    onClick: p,
                    children: e("div", {
                        className: "btn-wrap",
                        children: e(k, {
                            name: "Arrow"
                        })
                    })
                })]
            }), e(Ye, {
                spinLoading: a.spinLoading
            })]
        })
    });
var en = Qe;

function an() {
    const [t, n] = u.exports.useState(!0);
    return u.exports.useEffect(() => (a.initReq().then(() => n(!1)), () => {
        a.reset()
    }), []), c("div", {
        className: nn,
        children: [e("button", {
            onClick: () => L.back(),
            className: "close flex-center",
            children: e(k, {
                name: "Close"
            })
        }), e("div", {
            className: "bg-a"
        }), e("div", {
            className: "bg-b"
        }), t && e(ae, {}), !t && e(en, {})]
    })
}
const nn = "sy6yjq0";
export {
    an as
    default
};
import {
    t as f,
    q as n,
    u as g,
    j as a,
    l as B,
    a as e,
    bM as I,
    L as v,
    s as b,
    fe as Q,
    A as K,
    ag as U,
    bL as w,
    a5 as F,
    b1 as q,
    m as J,
    o as D,
    aS as $,
    K as x,
    d as p,
    I as k,
    F as C,
    z as ee,
    bl as ae,
    M as se,
    J as A,
    e as le,
    b as ne,
    v as te,
    D as ce,
    S as ie,
    a3 as Z,
    ff as u,
    r as L,
    bm as re,
    a4 as oe,
    cW as de,
    T as me,
    k as he
} from "./index.28e31dff.js";
import {
    c as l,
    C as T,
    T as ue
} from "./ContestStore.ee2a7e20.js";
const pe = [w.gold, w.silver, w.copper],
    fe = ({
        num: s
    }) => s < 4 ? e("div", {
        className: "position",
        children: e("img", {
            className: "user-ico",
            src: pe[s - 1]
        })
    }) : e("div", {
        className: "position",
        children: e("div", {
            children: U(s)
        })
    }),
    ve = ({
        dat: s
    }) => {
        const t = l.wagerCurrency;
        return a("div", {
            className: "item",
            children: [e(fe, {
                num: s.rank
            }), e("div", {
                className: "user-td",
                children: e(I, {
                    userId: s.userId,
                    name: s.player
                })
            }), e("div", {
                className: "wager",
                children: e("span", {
                    className: "coin",
                    children: e(v, {
                        amount: s.wager,
                        currency: t
                    })
                })
            }), a("div", {
                className: "prize flex-middle",
                children: [e("span", {
                    className: "coin",
                    children: e(v, {
                        amount: s.totalBonus,
                        currency: t
                    })
                }), !b.isMobile && a("div", {
                    className: "percent",
                    children: ["(", Q(l.userBonusRate[s.rank - 1]), ")"]
                })]
            })]
        })
    },
    ge = () => {
        const s = g();
        return a("div", {
            className: "list-head item",
            children: [e("div", {
                className: "position",
                children: "#"
            }), e("div", {
                className: "user-td",
                children: s("common.player")
            }), e("div", {
                className: "wager",
                children: s("common.wagered")
            }), e("div", {
                className: "prize",
                children: s("common.prize")
            })]
        })
    },
    Ae = ({
        children: s,
        active: t = !1
    }) => a("div", {
        className: "active-icon",
        children: [e("svg", {
            className: "bg",
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 81 32",
            children: e("path", {
                d: "M1.28 0h78.201c0.707 0 1.28 0.573 1.28 1.28 0 0.26-0.079 0.513-0.227 0.727l-10.079 14.603c-0.325 0.47-0.298 1.099 0.065 1.541l9.676 11.756c0.449 0.546 0.371 1.352-0.175 1.802-0.229 0.189-0.517 0.292-0.813 0.292h-77.929c-0.707 0-1.28-0.573-1.28-1.28v-29.44c0-0.707 0.573-1.28 1.28-1.28z"
            })
        }), t && e(K, {
            name: "Loading"
        }), e("div", {
            className: "label",
            children: s
        })]
    }),
    S = ({
        isActive: s = !1,
        startTime: t,
        endTime: i,
        list: c
    }) => {
        const r = g();
        return a("div", {
            className: B(Ne, s && "is-active"),
            children: [a("div", {
                className: "title",
                children: [e(Ae, {
                    active: s,
                    children: r(s ? "common.active" : "common.finished")
                }), a("div", {
                    className: "time",
                    children: [t.toLocaleDateString(), " ~ ", i.toLocaleDateString()]
                })]
            }), a("div", {
                className: "list",
                children: [e(ge, {}), c.map((o, m) => e(ve, {
                    dat: o
                }, m))]
            })]
        })
    };
f({
    cl1: ["#1e2024", "#ffffff"],
    cl2: [n("#99a4b0", .6), n("#5f6975", .6)],
    cl3: [n("#31343c", .6), n("#E9EAF2", .8)],
    cl4: ["#f5f6f7", "#5f6975"],
    cl5: ["#ffffff", n("#f5f6f7", .9)],
    cl6: ["#f5f6f7", "#31373d"],
    cl7: ["#99a4b0", n("#5f6975", .8)],
    cl8: ["#e0e5e8", n("#5f6975", .8)],
    cl9: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl10: ["rgba(153,164,176, 0.4)", "#31373d"]
});
const Ne = "c1goq8bh";
var ye = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACIAAAA+CAMAAAB5jTkQAAAAllBMVEUAAAD/4wD/zQD/zQD/zQD/zgD/2QD/zQD/zQD/0QD/0QD/0QD/zAD/zAD/zQD/zQD/zQD/zQD/zQD/zQD/zQD/zgD/zQD/zgD/0wD/zQD/zQD/zQD/zAD/zQD/zQD/zQD/zgD/zgD/zwD/zgD/0AD/0gD/zQD/zQD/zQD/zQD/zQD/zQD/zQD/zAD/zQD/0gD/zwD/zAAIjeTFAAAAMXRSTlMABFvPti8G9O8hDgv63cbBuqWOdHBWUUAX+Orh2MqYZU08NSklEuWriYF7sp94axxHbGQApQAAAZZJREFUSMeFlNlygkAQABflMIpo1MT7vu/0//9cGDREkB36gSq2umB2LhPTd0fVutHoQnOjGgtgrRr+Dlyj8gXMdWUPfOnKBFjoSgBUdKUGdHSlCUS68gkEvqrMKQ2mMQImflmJ4KoqThUY6lVahUDVUZ0jpblxInG+VedDUlz7UJ1vJJxG+tkiuyPOPlWuReG0xDmleTAFDHYvIfsUDsQylHp6RtiwMkXciNndk+htrTpLr3WkFz+tIbtxJVybYgZjcWbGCayK8QJxun3o6VkmUtvwxIOl3u2CVlI/QrgnL+q19JVUQWg75dF82o3tkAcHq9Ljj5u2b9otsG+mPjHzbZOY4dIe7MBsasTU1rZgp/K1UJzxwLIDTulSIXpLj5PE4P3PDZ2iTU7zqbsI+UZPTo/Pl/okqURutjON8LxW9lYHYlrZ5U830yuj/Gq8AJe3NggaLyf1MexflXYyI9l6ZA+24TMp2fAq+f+c88l0X398LsqUyVRA7tPWN70+YoKXpk1VfnTFD6WXdKYsyhRvakqxzPEvSmlIJn6vSEMAAAAASUVORK5CYII=",
    be = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAD4AAAA+CAMAAABEH1h2AAAAolBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8ELnaCAAAANXRSTlMA+wUJ8Rb46eTaxad0ZVkzJg0C9cyOUUpFLRvu4M/Aubayrp+cmIWAe21fPTgiEd7VkR+JiJije3UAAAGOSURBVEjHtdbXVsMwEEVRyT0u6c3pvRcSuP//a4SQIIzrTBbnfb/YI2nEv1b3gld4gIbJ1ycbuPD5BYDV4+qqxK0ll4/xlTzydBvfzVlaKz24rHK4j2ceQ5sGfgrpfA7VjKwr+F2Fyt0InxB1GdEOJK07iDYi8RX+1iXooxXjLoHPEK9TWHeRULMgNlsWktrUC+DTykBKw30erm0MZORds7Du95FdY62nYW1rI79BORkHDorlxs9PfXdG4eTCjOpyCaQMX1O4PQS50nMID02wmlTVZc5Jtmo33vPA7Xz/Avsmky8evy2wGXgaqllvSSIeR4enOqHgUfzwdQrPjttNHHvfKIKHqdeWuZB5+K2d+Ta52bNarue9L076WQ80kZu+SsbOVuNf85jqomChjOsGYT/z4nxNXOiiDXTGZqJqC0pXyXneVcuIliGR9yyFOWttC6q+SeZmQ/GtoPehDpnG4CdDbUWc1s9hF6xq/bu2joLX5s7fBTPdBmDXBDcfwE6w0x00xQvtjIN4pbyB+QQb2hHInJCpogAAAABJRU5ErkJggg==",
    De = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALIAAAAqCAMAAAAgYfF0AAAAkFBMVEUAAAAtlF1FrXMwl2AymmQtk10tlF07oGllxIEtlF0tlF4vl2A3nmUtlF0tlF0ulF0tk14vlV8tk14ulF0tlF4tlF4tlV4ulF4wlV4tlF4ulF4vlV8tk10tlF0tlF4tlF4ulF4ulV4ulV4vlWAtlF0ulV8vlV8xl2Awl2EtlF4tlF4ulV4tlF0zmGUtlF0tk12HckZvAAAAL3RSTlMA8gUkEfzsCQL2lCoNz8nAukz5oZyCcY00hn055tvUpnZqU0SwXz8uH9i1V6sY32eTc1QAAALZSURBVFjD1dnJdtpAEIXh22iW0IzEPGMm4/zv/3aJFB/AMcm68y1Y9KpOU119Jel/Nuh/yp0ss51/lveNu3yXVJDKMtBIgybXNy3MdYaxLJMSDdTCRH8aQ6ET6YcsM18QDHz43rHvsFCQDGSdYRI64Dl6NnGkcEWm4dnGkp3BMGLUbfij7LRbcH5MRx5mI7sEdVdUkQ/lZsT3ZQNjbcjoWFbzASDyOQY5XO/LS2BvOLYGcsvO32QJP/Yb0hYY3ZcbIGOd7E+ns6zjJPO9cyEF9o+Lr4DKWwHpSdbZLYAMA40ehqOKiE4r69zoVPj3U3Zsu3tlhQGIZZ8gB1gQdxFo1nVuDIXrYtxt3MxlpXI63k249EexS0JTICspZLfQcDJAKWkPcGVW3lb5bCgLOXG6qicFBRD1FRbAD3I677LQGMDLMcBMHTcHn15mYcSQPhb0vKdoXMZLOrkrKyUXOllz0kNBM50dZatB2cxGzPRs3Sfo4COUhYJz0Hf0Vp/CJBkoZqtJ4TGShS5Ut7PWvMudOPolBTPeUpce0MhCBeAnS+bXz/u5Briy9AEvkYXeADL8C8BbN6h9gIjOVDYKr3T8xxg++YABTCvtRpadQGd0VDCu+C1z1fuYHQ4xi33Q3yqWjboN/NpF9w0zvdVvAz1ZsZWufbNYZfR7KKxf5OKSxfAIUMoqDVC5E8zHq1FSj39HpeHUkp2ON6HmAO8rZvpquK3rqSEHZhqmGNnAhZt0ADIu48OXTt5/zjmvb/UYCGSBBHjrRwIVnYvz9D6uV+G1Xfy3peQTkPUByKPnO7pr+7XFmqpVAGBFbnaASEFNNTUA/lxPkulhvQ3UwM0BlrLBoAIzX2FKue263rp6ISx9oghvLytsYAFpEupvnCsQgbHme0nrUXng1a5eOvv0DhbFuWNKb/X6cO3oLa16MTDx6URnvbRLwcSWPbI6a0P0jz8+tGK4/SnUFz8BHG5seCviqmMAAAAASUVORK5CYII=",
    ze = "/assets/grass_left.b89126fa.svg",
    Ce = "/assets/grass_right.8cc9793f.svg",
    we = "/assets/grass_left_w.e0430055.svg",
    Te = "/assets/grass_right_w.93a510eb.svg",
    Ie = "/assets/trophy.424f8523.png";
const Fe = {
    img1: ye,
    star: be,
    grass: De,
    grass_left: ze,
    grass_right: Ce,
    grass_left_w: we,
    grass_right_w: Te,
    trophy: Ie
};
const z = F.memo(({
        name: s,
        value: t,
        line: i = !0
    }) => a("div", {
        className: "count-item",
        children: [a("div", {
            className: "count-panel",
            children: [e("div", {
                className: "count-name",
                children: s
            }), e("div", {
                className: "count-value",
                children: q(t)
            })]
        }), i && e("div", {
            className: "count-line",
            children: ":"
        })]
    })),
    R = ({
        endTime: s,
        className: t = ""
    }) => {
        const i = g();
        return a("div", {
            className: B(Be, t),
            children: [e("div", {
                className: "title tc",
                children: i("page.contest.time_remaining")
            }), e(J, {
                endTime: s,
                onEnd: () => setTimeout(l.loadByContestType, 5e3),
                children: ({
                    days: c,
                    hours: r,
                    minutes: o,
                    seconds: m
                }) => a("div", {
                    className: "contest-countdown",
                    children: [c > 0 && e(z, {
                        name: "DAYS",
                        value: c
                    }), e(z, {
                        name: i("common.hours"),
                        value: r
                    }), e(z, {
                        name: i("common.minutes"),
                        value: o,
                        line: c <= 0
                    }), c <= 0 && e(z, {
                        name: i("common.seconds"),
                        value: m,
                        line: !1
                    })]
                })
            })]
        })
    };
f({
    cl1: [n("#31343c", .6), "#f6f7fa"],
    cl2: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl3: ["#f5f6f7", "#31373d"],
    cl4: ["#353a43", "#ECECF3"],
    cl5: ["#1e2024", n("#bec1cc", .6)],
    cl6: ["#353a43", n("#f5f6fa", .6)],
    cl7: ["#ECECF3", "#CCCFD9"]
});
const Be = "ck5jccm";
var Qe = "/assets/winner.fd82f171.png";

function Ue(s) {
    return A.toLocaleCurrency(s, "USD")
}

function E(s) {
    return s == 0 || s > 50 ? "50th+" : U(s)
}
const Me = e("svg", {
        viewBox: "0 0 32 32",
        xmlns: "http://www.w3.org/2000/svg",
        className: "avatar-icon",
        children: e("path", {
            fill: "#ffd308",
            d: "M27.924 14.807l-4.892 11.74h-14.063l-4.892-11.74c-1.198-0.105-2.14-1.099-2.14-2.324 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.498-0.157 0.957-0.421 1.336 0.827 1.307 2.274 2.18 3.937 2.18 2.182 0 3.999-1.497 4.522-3.516l0.035-0.197 0.131-2.472c-0.698-0.406-1.172-1.153-1.172-2.019 0-1.295 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.866-0.474 1.613-1.172 2.019l0.082 2.434 0.084 0.235c0.523 2.018 2.341 3.516 4.522 3.516 1.663 0 3.109-0.873 3.937-2.18-0.264-0.379-0.421-0.839-0.421-1.336 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 1.225-0.942 2.218-2.14 2.324z"
        })
    }),
    xe = e("svg", {
        viewBox: "0 0 32 32",
        xmlns: "http://www.w3.org/2000/svg",
        className: "title-icon",
        children: e("path", {
            fill: "#ffd308",
            d: "M27.924 14.807l-4.892 11.74h-14.063l-4.892-11.74c-1.198-0.105-2.14-1.099-2.14-2.324 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.498-0.157 0.957-0.421 1.336 0.827 1.307 2.274 2.18 3.937 2.18 2.182 0 3.999-1.497 4.522-3.516l0.035-0.197 0.131-2.472c-0.698-0.406-1.172-1.153-1.172-2.019 0-1.295 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 0.866-0.474 1.613-1.172 2.019l0.082 2.434 0.084 0.235c0.523 2.018 2.341 3.516 4.522 3.516 1.663 0 3.109-0.873 3.937-2.18-0.264-0.379-0.421-0.839-0.421-1.336 0-1.294 1.049-2.344 2.344-2.344s2.344 1.049 2.344 2.344c0 1.225-0.942 2.218-2.14 2.324z"
        })
    }),
    V = D(function() {
        const t = g();
        return l.wagerCurrency, a("div", {
            className: ke,
            children: [!b.isMobile && e("div", {
                className: "trophy",
                children: e("img", {
                    src: Fe.trophy
                })
            }), a("div", {
                children: [e("div", {
                    className: "type ttc",
                    children: t("common.daily")
                }), e("div", {
                    className: "title",
                    children: t("page.home.latestbet_pool")
                }), e("div", {
                    className: "prize-amount",
                    children: e($, {
                        format: Ue,
                        children: l.prizeAmount
                    })
                })]
            })]
        })
    });
f({
    cl1: ['url("./assets/grass_left.svg")', 'url("./assets/grass_left_w.svg")'],
    cl2: ['url("./assets/grass_right.svg")', 'url("./assets/grass_right_w.svg")'],
    cl3: ["#f5f6f7", "#31373d"],
    cl4: [n("#31343c", .6), n("#f5f6fa", 1)]
});
const ke = "p1gf2a9a",
    O = () => {
        const s = g(),
            t = le();
        return a("div", {
            className: Le,
            children: [e("div", {
                className: "text",
                children: s("page.contest.nologin")
            }), e(ne, {
                type: "conic",
                className: "breathe",
                onClick: () => t("/login"),
                children: s("page.contest.participate")
            })]
        })
    };
f({
    cl1: [n("#31343c", .6), "#f6f7fa"],
    cl2: ["#99a4b0", n("#5f6975")]
});
const Le = "n493ip1",
    G = D(function() {
        const t = g(),
            {
                rank: i,
                wager: c,
                wagerCurrency: r,
                userBonusRate: o,
                activeList: m
            } = l;
        let h = 1;
        i == 0 ? h = o.length : i == 1 ? h = 1 : i <= o.length ? h = i - 1 : h = o.length;
        let N = 0,
            y = null;
        return m.length > h - 1 && (y = m[h - 1]), y && (N = y.wager - c), b.isMobile ? a("div", {
            className: _,
            children: [e("div", {
                className: "head",
                children: e(x, {
                    userId: p.userId,
                    name: p.name
                })
            }), a("div", {
                className: "box2 position",
                children: [e("div", {
                    className: "label",
                    children: t("page.contest.my_position")
                }), e("div", {
                    className: "value",
                    children: E(i)
                })]
            }), a("div", {
                className: "box2",
                children: [e("div", {
                    className: "label",
                    children: t("common.wagered")
                }), e("div", {
                    className: "value",
                    children: e(v, {
                        amount: c,
                        currency: r
                    })
                })]
            }), i != 1 && e("div", {
                className: "scale-text reach",
                children: e("div", {
                    className: "tc flex-middle",
                    children: a(k, {
                        k: "page.contest.reach",
                        children: [e("div", {
                            className: "coin-fait",
                            children: e(v, {
                                amount: N,
                                currency: r
                            })
                        }), a("span", {
                            className: "color-top",
                            children: ["TOP ", h]
                        })]
                    })
                })
            }), i === 1 && e("div", {
                className: "scale-text reach",
                children: a("div", {
                    className: "tc flex-middle",
                    children: [e("span", {
                        children: t("common.wager")
                    }), e("div", {
                        className: "coin-fait",
                        children: e(v, {
                            amount: c,
                            currency: r
                        })
                    })]
                })
            })]
        }) : a("div", {
            className: _,
            children: [a("div", {
                className: "user",
                children: [e("div", {
                    className: "head",
                    children: e(x, {
                        userId: p.userId,
                        name: p.name
                    })
                }), e("div", {
                    className: "user-name",
                    children: p.name
                })]
            }), a("div", {
                className: "position myinfo-item",
                children: [e("div", {
                    className: "label",
                    children: t("page.contest.my_position")
                }), e("div", {
                    className: "value",
                    children: E(i)
                })]
            }), a("div", {
                className: "wager myinfo-item",
                children: [e("div", {
                    className: "label",
                    children: t("common.wagered")
                }), e("div", {
                    className: "value",
                    children: e(v, {
                        amount: c,
                        currency: r
                    })
                })]
            }), i != 1 && e("div", {
                className: "reach myinfo-item",
                children: e("div", {
                    className: "flex-middle",
                    children: a(k, {
                        k: "page.contest.reach",
                        children: [e("div", {
                            className: "coin-fait",
                            children: e(v, {
                                amount: N,
                                currency: r
                            })
                        }), a("span", {
                            className: "color-top",
                            children: ["TOP ", h]
                        })]
                    })
                })
            })]
        })
    });
f({
    cl1: ["#24272c", n("#c0c4d0", .3)],
    cl2: ["#1e2024", "#ffffff"],
    cl3: ["#f5f6f7", "#31373d"],
    cl4: ["#dbe6ec", "#31373d"],
    cl5: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl6: [n("#31343c", .6), "#f6f7fa"],
    cl7: [n("#31343c", .6), "#ffffff"]
});
const _ = "mjto7ln",
    P = D(function() {
        const t = g();
        if (l.prevList.length == 0) return null;
        const i = l.prevList[0];
        let {
            userId: c,
            player: r,
            totalBonus: o
        } = i;
        return a("div", {
            className: Se,
            children: [e("img", {
                className: "img-winner",
                src: Qe,
                alt: ""
            }), a("div", {
                className: "champion-layout",
                children: [e(I, {
                    className: "head",
                    userId: c,
                    name: r,
                    showName: !1,
                    children: Me
                }), a("div", {
                    className: "content-box",
                    children: [a("div", {
                        className: "champion__title",
                        children: [xe, e("div", {
                            className: "contest-ml",
                            children: t("page.contest.last_champion")
                        })]
                    }), e(I, {
                        className: "user-name",
                        userId: c,
                        name: r,
                        avatar: !1
                    }), a("div", {
                        className: "profit",
                        children: [e("div", {
                            className: "profit-name",
                            children: t("common.profit")
                        }), l.wagerCurrency === "BCD" ? a(C, {
                            children: [e(ee, {
                                name: "BCD"
                            }), " ", e("span", {
                                className: "amount",
                                children: ae(o, 2)
                            })]
                        }) : e(se, {
                            className: "prize-coin",
                            name: l.wagerCurrency,
                            amount: o,
                            showName: !1,
                            icon: !0
                        }), a("div", {
                            className: "percent",
                            children: ["(", Q(l.userBonusRate[0]), ")"]
                        })]
                    })]
                })]
            })]
        })
    });
f({
    cl1: [n("#31343c", .6), "#f6f7fa"],
    cl2: ["#99a4b0", n("#5f6975", .8)],
    cl3: ["#818d99", "#bec1cc"],
    cl4: ["#f5f6f7", "#31373d"]
});
const Se = "c1cjnc2n",
    Re = D(function({
        type: t
    }) {
        return a("div", {
            className: Ee,
            children: [b.isMobile ? a("div", {
                className: "contest__top",
                children: [e("div", {
                    className: "scale-wrap",
                    children: e(V, {})
                }), e("div", {
                    className: "scale-wrap",
                    children: e(R, {
                        className: "bg-box",
                        endTime: l.endTime.getTime()
                    })
                }), p.login ? e(G, {}) : e(O, {}), e(P, {})]
            }) : a(C, {
                children: [a("div", {
                    className: `contest__top ${p.login?"":"radius"}`,
                    children: [e(V, {}), p.login ? e(R, {
                        className: "bg-box",
                        endTime: l.endTime.getTime()
                    }) : e(O, {}), e(P, {})]
                }), p.login && e(G, {})]
            }), e(S, {
                isActive: !0,
                startTime: l.startTime,
                endTime: l.endTime,
                list: l.activeList
            }), l.prevList.length > 0 && e(S, {
                startTime: l.prevStartTime,
                endTime: l.prevEndTime,
                list: l.prevList
            })]
        })
    }),
    Ee = "c1djacpj";
const d = {
        title: "Rules-{0} Wagering Contest",
        init_prize: " an initial amount of {0} plus",
        rule1: "The contest prize pool closely depends on the bankroll, the more players bet the bigger it grows. Current prize pool will be showed on the Contest page.",
        rule2: "{0} most wagering players carve up the prize pool.",
        rule3: "This Contest support wagering in : {0}",
        rule4: "You can wager in any cryptocurrencies above, and they all will be switched to USDT at the current rate.",
        rule5: "All prizes will be sent in {0}. ",
        rule6: "Prizes will be sent on Notice page as the Contest ends.",
        rule7: "BC.GAME reserve the right to exclude players who have violated our rules at any stage of the Contest.",
        rule8: "BC.GAME reserves the right to change any rules and conditions at its sole discretion and without prior notice.",
        rule9: "BC.GAME reserves the right to discontinue the Contest at any time and without prior notice.",
        luck: "\u{1F31F}\u{1F31F} Good luck and have fun! \u{1F31F}\u{1F31F}",
        formula: "Prize Calculation Formula",
        formala_item: "{0} place \u2013 {1} of the {2} Contest prize pool",
        daily: "Daily",
        weekly: "Weekly",
        monthly: "Monthly"
    },
    Y = {
        [T.DAILY]: "daily",
        [T.WEEKLY]: "weekly",
        [T.MONTHLY]: "monthly"
    },
    Ve = () => {
        let {
            wagerCurrency: s,
            participateCurrency: t,
            contestType: i,
            startTime: c,
            endTime: r,
            totalBonusWagerRate: o,
            userBonusRate: m
        } = l;
        const h = A.getAlias(s),
            N = t.map(A.getAlias.bind(A)).join(", ");
        return e(ce, {
            title: "Rules",
            children: e(ie, {
                className: Ge,
                children: e(Z, {
                    pms: l.inited,
                    children: () => a("div", {
                        children: [e("h2", {
                            children: u(d.title, u(d[Y[i]]))
                        }), a("div", {
                            className: "help-content",
                            children: [a("p", {
                                className: "cl-primary",
                                children: [c.toLocaleDateString(), " ~", " ", r.toLocaleDateString()]
                            }), a("ol", {
                                children: [a("li", {
                                    children: ["1.", d.rule1]
                                }), a("li", {
                                    children: ["2.", e(W, {
                                        message: d.rule2,
                                        children: e("span", {
                                            children: m.length
                                        })
                                    })]
                                }), a("li", {
                                    children: ["3.", u(d.rule3, N)]
                                }), a("li", {
                                    children: ["4.", u(d.rule4, A.getAlias(h))]
                                }), a("li", {
                                    children: ["5.", u(d.rule5, A.getAlias(h))]
                                }), a("li", {
                                    children: ["6.", u(d.rule6)]
                                }), a("li", {
                                    children: ["7.", u(d.rule7)]
                                }), a("li", {
                                    children: ["8.", u(d.rule8)]
                                })]
                            }), e("p", {
                                className: "tc",
                                children: u(d.luck)
                            }), e("h2", {
                                children: u(d.formula)
                            }), e("ul", {
                                children: m.map((y, M) => e("li", {
                                    children: a(W, {
                                        message: d.formala_item,
                                        children: [e("span", {
                                            children: U(M + 1)
                                        }), e("span", {
                                            children: Q(y)
                                        }), d[Y[i]]]
                                    })
                                }, M))
                            })]
                        })]
                    })
                })
            })
        })
    },
    j = /({\d+})/,
    W = F.memo(function({
        message: t,
        children: i
    }) {
        const c = F.Children.toArray(i);
        if (c.length == 0) return e(C, {
            children: t
        }); {
            let r = 0,
                o = t.split(j).map(m => j.test(m) ? c[r++] || "" : m);
            return e(C, {
                children: o
            })
        }
    }),
    Oe = () => te.push(e(Ve, {}));
f({
    cl1: [n("#99a40b0", .8), n("#5f6975", .8)],
    cl2: ["#99a4b0", n("#5f6975", .8)],
    cl3: [n("#99a4b0", .45), n("#5f6975", .6)]
});
const Ge = "w360n6m";
const X = 2,
    H = {
        from: {
            y: 10,
            opacity: 0
        },
        enter: {
            y: 0,
            opacity: 1
        }
    },
    je = D(() => {
        const [s, t] = L.exports.useState(() => l.loadByContestType());
        L.exports.useEffect(() => {
            const c = setInterval(() => {
                    l.loadByContestType()
                }, 12e4),
                r = setInterval(() => {
                    l.prizeAmount += l.prizePoolChangeRate * X
                }, X * 1e3);
            return () => {
                clearInterval(c), clearInterval(r)
            }
        }, []);
        const i = l.supportType.map(c => {
            const r = c.toUpperCase(),
                o = ue[r];
            return {
                label: c,
                value: o
            }
        });
        return e(re, {
            errorComponent: () => e(oe, {
                type: "offline"
            }),
            children: a("div", {
                id: "contest",
                className: B(_e, l.supportType.length <= 1 && !b.isMobile && "space-area"),
                children: [l.supportType.length > 1 ? e("div", {
                    className: "contest__tab",
                    children: e(de, {
                        className: "contest__tab__nav",
                        value: l.contestType,
                        onChange: c => t(l.loadByContestType(c)),
                        options: i,
                        children: ({
                            option: c,
                            active: r
                        }) => e("button", {
                            className: r ? "is-active nav-item" : "nav-item",
                            children: e("div", {
                                className: "label ttc",
                                children: c.label
                            })
                        })
                    })
                }) : null, l.supportType.length != 0 && e(K, {
                    name: "Help",
                    className: "contest__rules",
                    onClick: Oe
                }), e(Z, {
                    pms: s,
                    className: "c-loading",
                    children: () => e(me, {
                        from: H.from,
                        enter: H.enter,
                        children: e(he.div, {
                            children: e(Re, {
                                type: l.contestType
                            })
                        })
                    })
                })]
            })
        })
    });
f({
    cl1: ["#24272c", n("#c0c4d0", .3)],
    cl2: ["#1e2024", "#ffffff"],
    cl3: [n("#99a4b0", .6), n("#5f6975", .8)],
    cl4: ["#f5f6f7", "#31373d"],
    cl5: ["#24272c", "#ffffff"],
    cl6: ["#1e2024", "#ffffff"]
});
const _e = "cw5z5v2";
export {
    je as ContestMain, je as
    default
};
! function() {
    var e = document.createElement("style");
    e.innerHTML = '.g1sw2nop{position:relative}.g1sw2nop .sp-img{position:absolute;left:0;right:0;top:0;bottom:0;background-repeat:no-repeat;background-size:100% auto;background-position:center center}.wob9cer{width:100%;position:relative}.wob9cer:after{content:"";display:block;width:100%;padding-top:50%}.wob9cer iframe{position:absolute;left:0;top:0;width:100%;height:100%;border:none}\n', document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js"], (function(e) {
        "use strict";
        var t, n, o, r, c, i, a, s, l, d, u, m, p, f, g, h, w, b, v, y, x, N, k, C, D, R, S;
        return {
            setters: [function(e) {
                t = e.o, n = e.r, o = e.u, r = e.bT, c = e.s, i = e.bU, a = e.a, s = e.F, l = e.j, d = e.eP, u = e.l, m = e.b, p = e.eQ, f = e.eR, g = e.eS, h = e.eT, w = e.a5, b = e.du, v = e.e, y = e.eU, x = e.eV, N = e.J, k = e.y, C = e.dR, D = e.d, R = e.eW, S = e.eX
            }],
            execute: function() {
                e("S", t(n.exports.forwardRef((function({
                    tabs: e = [],
                    actions: t = [],
                    src: n,
                    banner: w,
                    className: b = "",
                    children: v,
                    ...y
                }, x) {
                    const k = o();
                    e = e.concat([{
                        label: k("common.highrolls"),
                        value: r
                    }, {
                        label: c.isMobile ? k("common.contest") : k("page.contest.title"),
                        value: i
                    }]);
                    return a(s, {
                        children: l(d, {
                            className: `game-style-iframe ${b}`,
                            ...y,
                            children: [a("div", {
                                className: "game-area",
                                children: c.isMobile ? l("div", {
                                    className: u(E, "game-thumb"),
                                    children: [a("div", {
                                        className: "sp-img",
                                        style: {
                                            backgroundImage: `url(${w})`
                                        }
                                    }), a(m, {
                                        type: "conic2",
                                        onClick: () => {
                                            const e = n.split("?");
                                            let t = {};
                                            e[1] && (t = R(e[1])), t.currencyName = N.current, window.open(`${e[0]}?${S(t)}`)
                                        },
                                        children: k("common.play")
                                    })]
                                }) : l("div", {
                                    className: "game-main",
                                    children: [a(M, {
                                        ref: x,
                                        src: n
                                    }), v, a(p, {
                                        actions: t
                                    })]
                                })
                            }), a(f, {
                                tabs: e
                            }), a(g, {}), a(h, {})]
                        })
                    })
                }))));
                const E = "g1sw2nop",
                    M = w.memo(w.forwardRef((({
                        src: e
                    }, t) => {
                        const o = b(),
                            r = v(),
                            [c, i] = n.exports.useState(Date.now()),
                            s = n.exports.useRef(null),
                            [l] = n.exports.useState((() => new y)),
                            {
                                ref: d,
                                inView: m
                            } = x();
                        n.exports.useImperativeHandle(t, (() => l)), n.exports.useLayoutEffect((() => {
                            l.on("connected", (() => l.emit("currencyChange", N.current))), l.on("inited", (() => {})), l.on("login", (() => r("/login"))), l.on("wallet", (() => r("/wallet/deposit"))), l.on("create_deduction", (({
                                amount: e,
                                currencyName: t,
                                timeout: n
                            }) => N.createDeduction(new k(e), t, o.name, n))), l.on("resolve_deduction", (e => N.resolveDeduction(e))), l.on("reject_deduction", (e => N.resolveDeduction(e, !1))), l.on("currencyChange", (e => {
                                N.dict[e] && (N.current = e)
                            }));
                            const e = C((() => l.emit("currencyChange", N.current)));
                            return () => {
                                e(), l.destroy()
                            }
                        }), []), n.exports.useEffect((() => {
                            var e;
                            l.target = null === (e = s.current) || void 0 === e ? void 0 : e.contentWindow
                        }), [c]), n.exports.useEffect((() => {
                            if (!D.login) {
                                const e = D.waitLogin();
                                return e.then((() => i(Date.now()))), () => e.cancel()
                            }
                        }), []);
                        const p = n.exports.useMemo((() => m ? $ : j), [m]);
                        return a("div", {
                            ref: d,
                            className: u(L, "game-iframe-wrap"),
                            children: a("iframe", {
                                className: "game-iframe",
                                style: p,
                                ref: s,
                                src: e
                            }, c)
                        })
                    }))),
                    $ = {},
                    j = {
                        position: "fixed",
                        width: "2!important",
                        height: "1!important",
                        left: 0,
                        top: 0,
                        opacity: 0
                    },
                    L = "wob9cer"
            }
        }
    }))
}();
System.register(["./index-legacy.1416f96c.js"], (function(e) {
    "use strict";
    var t, n;
    return {
        setters: [function(e) {
            t = e.aJ, n = e.aK
        }],
        execute: function() {
            e("i", (function(e) {
                return "number" == typeof e || t(e) && "[object Number]" == n(e)
            }))
        }
    }
}));
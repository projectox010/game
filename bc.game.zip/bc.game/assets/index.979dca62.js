var Z = Object.defineProperty;
var $ = (t, n, e) => n in t ? Z(t, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : t[n] = e;
var u = (t, n, e) => ($(t, typeof n != "symbol" ? n + "" : n, e), e);
import {
    cf as ee,
    aI as te,
    e7 as ie,
    es as ae,
    ch as ne,
    bE as se,
    r as w,
    ef as F,
    a,
    l as le,
    ee as C,
    o as k,
    di as oe,
    j as d,
    F as E,
    t as U,
    q as g,
    y as J,
    J as re,
    du as S,
    dj as de,
    dk as he,
    dl as ce,
    u as T,
    b as z,
    s as R,
    e9 as q,
    a5 as O,
    dx as Y,
    dy as ue,
    dz as fe,
    dG as me,
    dY as pe,
    dC as ge,
    dZ as be,
    dD as ye,
    dE as Ae,
    dp as B,
    w as ve,
    bN as G,
    d_ as ke,
    ba as we,
    bb as y,
    bc as He,
    dr as Se,
    dR as Le,
    d as j,
    G as x,
    aH as V
} from "./index.28e31dff.js";
import {
    s as P
} from "./index.dd8128e8.js";
import {
    G as p
} from "./index.06a59a68.js";
import {
    g as W
} from "./groupBy.00ce7dc6.js";
import "./_baseAssignValue.0532e777.js";

function _(t, n) {
    var e = te(t) ? ie : ae;
    return e(t, ee(n))
}

function Ve(t, n) {
    return t > n
}

function Ie(t, n, e) {
    for (var i = -1, l = t.length; ++i < l;) {
        var s = t[i],
            r = n(s);
        if (r != null && (h === void 0 ? r === r && !ne(r) : e(r, h))) var h = r,
            c = s
    }
    return c
}

function Be(t) {
    return t && t.length ? Ie(t, se, Ve) : void 0
}
const Ne = t => {
        let [n, e] = w.exports.useState(!1), [i, l] = w.exports.useState(!1);
        const s = t.hold === 1 ? "" : " holed",
            r = i ? " win" : " lose",
            h = t.isEnd ? "p_end" : "",
            c = t.isHold ? "pointer" : "",
            o = "card-model" + s,
            f = c + h + r,
            m = new F(t.cardId);
        w.exports.useEffect(() => {
            if (t.hold !== 0)
                if (t.isEnd) {
                    let L = setTimeout(() => {
                        t.isOpen ? t.game.vpPlaySound("fcSound") : t.game.vpPlaySound("closeSound"), e(t.isOpen)
                    }, t.atime);
                    return () => {
                        clearTimeout(L)
                    }
                } else t.isOpen ? t.game.vpPlaySound("fcSound") : t.game.vpPlaySound("closeSound"), e(t.isOpen)
        }, [t.isOpen]), w.exports.useEffect(() => {
            let L = setTimeout(() => {
                l(t.isWin)
            }, t.wtime);
            return () => {
                clearTimeout(L)
            }
        }, [t.isWin]);
        const b = w.exports.useCallback(() => {
            t.onHoldCard(t.cardId)
        }, [t.onHoldCard, t.cardId]);
        return a("div", {
            className: le(Ee, f),
            children: a(C, {
                card: m,
                active: n,
                children: a("div", {
                    className: o,
                    onClick: b
                })
            })
        })
    },
    Ee = "cj2j03x";
const Pe = ({
    game: t
}) => {
    let n = t.cardList,
        e = t.holedList,
        i = 1,
        l = e.map(c => {
            let o = 0;
            return c && (o = i * t.atime, i++), o
        });
    const s = c => {
            t.holdeCard(c)
        },
        [r, h] = oe();
    return w.exports.useEffect(() => {
        var c;
        t.isEnd && t.payoutIndex === 9 ? (c = t.dealPms) == null || c.then(o => {
            h({
                profitAmount: o.profitAmount,
                currencyName: o.currencyName,
                odds: o.odds,
                isBigWin: !0,
                enableSound: !1
            }), setTimeout(() => {
                h(null)
            }, 3e3)
        }) : h(null)
    }, [t.payoutIndex]), d(E, {
        children: [r, a("div", {
            className: Fe,
            children: n.map((c, o) => a(Ne, {
                game: t,
                cardId: c,
                hold: e[o],
                onHoldCard: s,
                isOpen: t.isOpen,
                isHold: t.isHold,
                isEnd: t.isEnd,
                isWin: t.winList[o] === 1 && t.isEnd,
                atime: l[o],
                wtime: Be(l) || 0
            }, o))
        })]
    })
};
var xe = k(Pe);
const Fe = "p1lzdfw";
var Ce = "/assets/banner_a1.0ced87e9.png",
    Re = "/assets/banner_a2.82174618.png",
    Ge = "/assets/icon.03b7a2de.png",
    Te = "/assets/hold.511a0356.png",
    Oe = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANcAAAE4CAMAAAD/xpZkAAAAVFBMVEUAAAAt+U8t+VEs+1At+FAt+VAq/08q/1At+U8t+U8t+U4u+FAu+VAs+U4t+E8t+k8u+lAu+k4u+VAu+E8u+VAu+FAt+E8t+FAt+U8t+08A/wAu+VAohNniAAAAG3RSTlMAsU9AwPgeDMmpKeDahm9nXDfw6829mJN4RAHjQgKhAAAB3klEQVR42uzSS05CQRRF0VIDokaNxg+h5j9PeMAkdmWtzm3v3DMuXv9+5jK+f9+fx9XHbq7l7euaNZez219GuNq3NofT+J8rehqHuaLjuN39WMXn3Lzcu8YyHufmQVeErhZdLbpadLXoatHVoqtFV4uuFl0tulp0tehq0dWiq0VXi64WXS26WnS16GrR1aKrRVeLrhZdLbpadLXoatHVoqtFV4uuFl0tulp0tehq0dWiq0VXi64WXS26WnS16GrR1aKrRVeLrhZdLbpadLXoatHVoqtFV4uuFl0tulp0tehq0dWiq0VXi64WXS26WnS16GrR1aKrRVeLrhZdLbpadLXoatHVoqtFV4uuFl0tulp0tehq0dWiq0VXi64WXS26WnS16GrR1aKrRVeLrhZdLbpadLXoatHVoqtFV4uuFl0tulp0tehq0dWiq0VXi64WXS26WnS16GrR1aKrRVeLrhZdLbpadLXoatHVoqtFV4uuFl0tulp0tehq0dWiq0VXi65z+/RuAyAMxVDUEZDwFUFU6O2/JwpkCVs+jetbmIu7uLiLi7u4uIuLu7i4i4u7uLiLi7u4uIuLetf+7Tyq+HsOLKGo4glBdwFS6KkA8hZqEpoidrHpRFfWQcaV0bwvvlqJAFfPIgAAAABJRU5ErkJggg==",
    De = "/assets/blue.7b3dc796.png",
    qe = "/assets/green.e744980c.png",
    je = "/assets/orange.12e1a113.png",
    We = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAAHKADAAQAAAABAAAAHAAAAABkvfSiAAADY0lEQVRIDbVXTUhUURQ+586oZWm1SFrUItAoKnJhO10YESpCFEG5CKpFkAspWoSEMy+NJCKSFgYtbCVuIpBEx4paOK10YVQQTtsgKqgc83feO333vp+ZyZ/Mnhfeu/fce+753jn33HPOI1pFk9vJEp9NOp7vE2voYkDHhk/749X0ajVMNJ3ulljivOG1M60kdEeswZ0APkPk9EnHswq9JlaiXG4O71pJ5rKAEhtqks6Rbd7mKgjukXjiHsCaSKSUHH6C8SPAMC3YpyQ2eIkcGSfb2bMSIC+3KPHBp5BVQ0ruQ/B1PMt+HBEvALjAyFKRE0SFA0RzR4mKxtmq/ZyLkSdErFc7xBordhn4G4RsIYfaVgbT3B6YGTpXSWY/keMAtGTSlZV9R7NDPZqrJGdmAOZ8B7N5wPkcf6VEql0efsNW1fSf/HkmhYZR83UiZX8yroFOEfNrWGc79vZye32flmE0NJ6lD1vmtftP4AkDsAJWgvfyT9q4+awG0801aUaKcFb9RPYmdzrEN5yOW2u++xIDkxq3Jur2F0LsbZg2BXljVFzSbLzUvbi81XXvEKFcURGYdi+u2Eu+Vp2Oig5NCzYOFBd4vRqrLr5RhyABlfTLhCgdNUQ2aDr0xpwBUh9Fop3exZck3Pdt6EC+QBFcNzpOdqZGmcgv/B56HvbXw+95lFj2s1X/UEHNEajbD0/KhA/kSWQ6iNMzEShwFDcTOJfXDRQqEqkm12lMrnN61gdMZxKKU0HkMbcdSymTzVmOwKQfsGCHD6ozifzQYFp2YFJNIIu3m3SkiVAb/yLFlWzVfQzSk8nuM1MtgA0PijlJrO4SO2mK8JwWHADSzFQdaDDwV/TVCALlmuE/G8qNwgGO1wY3IM+kvnAk4HFoesin19DjvBjJVw6QUo0wZcKXkVdi6Em3xAAj8xc8SZ/xn3okXiTcSlJlpbquyd2bNWkwmy7VXwXGF0TzjSS2ubD4Yrh3Tu0S8AcDG2XWLVRzLV6WJ6/EgKbZtkhDXWVpE6BHwMVhEzyMqBlP3GxjnsXcqDcGj+ryxim2GmLI7rtB95q5JV6LAPN4ImrCuHN7wwN9cQEkJOocSseTMPekzgBIO1cQQS5g35jeq7O7X7/kyVoLYXKnt1EHfV32+3Jyfwf8uaX631yoOBLzELpzAAAAAElFTkSuQmCC",
    A = {
        banner_a1: Ce,
        banner_a2: Re,
        icon: Ge,
        hold: Te,
        poker_green: Oe,
        blue: De,
        green: qe,
        orange: je,
        pink: We
    };
let _e = [{
    label: "Royal flush",
    odd: 9,
    class: "bgc_g top_radius",
    model: A.green
}, {
    label: "Straight Flush",
    odd: 8,
    class: "bgc_g",
    model: A.green
}, {
    label: "4 of a Kind",
    odd: 7,
    class: "bgc_o",
    model: A.orange
}, {
    label: "Full House",
    odd: 6,
    class: "bgc_o",
    model: A.orange
}, {
    label: "Flush",
    odd: 5,
    class: "bgc_b bot_radius",
    model: A.blue
}, {
    label: "Straight",
    odd: 4,
    class: "bgc_b top_radius",
    model: A.blue
}, {
    label: "3 of a Kind",
    odd: 3,
    class: "bgc_p",
    model: A.pink
}, {
    label: "2 Pairs",
    odd: 2,
    class: "bgc_p",
    model: A.pink
}, {
    label: "Jacks or Better",
    odd: 1,
    class: "bgc_p bot_radius",
    model: A.pink
}];
const Xe = t => {
        let i = (t.amount.isNaN() ? new J(0) : t.amount).mul(t.odd).toFixed(9) + " " + re.getAlias(I.currencyName);
        return a("div", {
            className: "vp-item",
            children: d("div", {
                className: `vp-wrap ${t.class} ${t.active?"winning":""}`,
                children: [d("div", {
                    className: "vp-label",
                    children: [a("img", {
                        src: t.model,
                        alt: "",
                        className: "vp-medal"
                    }), t.label]
                }), d("div", {
                    className: "vp-conversion",
                    children: [d("span", {
                        className: "vp-payout",
                        children: [t.odd, "x"]
                    }), d("span", {
                        className: "vp-amount",
                        children: [" =", i]
                    })]
                })]
            })
        })
    },
    Ke = k(() => a("div", {
        className: Me,
        children: _e.map(t => a(Xe, {
            label: t.label,
            odd: I.pokerPayouts[t.odd],
            class: t.class,
            active: I.payoutIndex === t.odd,
            amount: I.amount,
            model: t.model
        }, t.odd))
    }));
U({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [g("#31343c", .4), "#ffffff"],
    cl3: ["#17181b", g("#d8d8d8", .4)],
    cl4: [g("#31343c", .3), g("#cccfd9", .4)]
});
const Me = "p1q2wch2";
const Ue = () => {
    const t = S();
    w.exports.useEffect(() => {
        t.controlIdx === 1 && t.suggest === 0 && (t.suggest = 1)
    }, [t.controlIdx]);
    const n = t.suggest === 1,
        e = t.controlIdx === 1;
    return d("div", {
        className: ze,
        children: [a("div", {
            className: "switch_label",
            children: "AI-Hint"
        }), a("div", {
            className: `switch ${e?"switch-disabled":""} ${n?"switch-open":""}`,
            onClick: () => t.openSuggest(),
            children: a("div", {
                className: "switch-trigger"
            })
        })]
    })
};
var Je = k(Ue);
U({
    cl1: [g("#31343c", .8), "#ced1d9"],
    cl2: [g("#99a4b0", .8), "#f5f6fa"],
    cl3: [g("#99a4b0", .6), "#ffffff"],
    cl4: ["transparent", g("#1c1c1c", .2)],
    cl5: [g("#5da000", .2), g("#7bc514", .4)]
});
const ze = "s7b60sm",
    Ye = k(() => {
        const t = S(),
            n = P.useSingleDetail();
        return a(de, {
            list: t.myBets,
            keyof: "betId",
            onDetail: n
        })
    }),
    Qe = () => {
        const t = S();
        return d(E, {
            children: [a(Ye, {}), d(he, {
                children: [a(Ke, {}), a(xe, {
                    game: t
                }), a(ce, {}), a(Je, {})]
            })]
        })
    };
var Ze = k(Qe);
const X = k(function() {
        const n = T(),
            e = S();
        return a(z, {
            className: "bet-button",
            size: "big",
            type: "conic",
            loading: e.btnLoading,
            onClick: () => {
                e.manualBet()
            },
            children: e.isHold ? "Deal" : n("common.bet")
        })
    }),
    $e = () => d("div", {
        className: "bet-control-manual",
        children: [R.isMobile && a(X, {}), a(p.CoinInput, {
            checkIncrease: !0
        }), !R.isMobile && a(X, {})]
    });
var et = k($e);
const K = k(function() {
    const n = T(),
        e = S(),
        i = e.autoBet;
    return a(z, {
        type: "conic",
        className: "bet-button",
        size: "big",
        disabled: !e.autoBet.isRunning && e.btnLoading,
        onClick: async () => {
            e.handleAuto()
        },
        children: i.isRunning ? n("common.stop_auto_bet") : n("common.start_auto_bet")
    })
});
var tt = k(function() {
    return a("div", {
        className: "bet-control-auto",
        children: R.isMobile ? d(E, {
            children: [a(K, {}), a(p.CoinInput, {
                checkIncrease: !0
            }), a(p.TimesInput, {}), a(p.IncreaseInput, {}), a(p.StopInput, {}), a(p.IncreaseInput, {
                isLose: !0
            }), a(p.StopInput, {
                isLose: !0
            }), a(q, {})]
        }) : d(E, {
            children: [a(p.CoinInput, {
                checkIncrease: !0
            }), a(p.TimesInput, {}), a(p.IncreaseInput, {}), a(p.StopInput, {}), a(p.IncreaseInput, {
                isLose: !0
            }), a(p.StopInput, {
                isLose: !0
            }), a(q, {}), a(K, {})]
        })
    })
});
const it = O.memo(() => a(Y, {
        children: d("div", {
            className: "item",
            children: [a("h2", {
                children: "What Is Video Poker?"
            }), a("div", {
                className: "help-content",
                children: d("p", {
                    children: ["Video Poker involves 52 cards in a deck. When you get a winning hand, you get a great reward.", " "]
                })
            }), a("h2", {
                children: "How To Play It?"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: 'Place your bet then tap or click the "deal" button.'
                }), a("p", {
                    children: "You will be dealt 5 cards and have the opportunity to discard one or more of them in exchange for new ones drawn from the same virtual deck."
                }), d("p", {
                    children: ["After the draw, Coco will pay out the corresponding amount if the hand or hands played matches one of the winning combinations.", " "]
                }), d("p", {
                    children: ["Unlike the table version, the player may discard all 5 of their original cards if they so choose.", " "]
                }), a("p", {
                    children: "Good luck."
                })]
            }), a("h2", {
                children: "Auto Mode Operation Instructions"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "[ ON WIN ] when you win, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                }), d("p", {
                    children: ["[ ON LOSE ] when you lose, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'.", " "]
                }), a("p", {
                    children: "[ STOP ON WIN ] Once the amount winned (from start to this bet) is bigger/equal than _(your set)_ , auto will stop;"
                }), a("p", {
                    children: "[ STOP ON LOSS ] Once the amount lost (from start to next bet) may be bigger/equal than _(your set)_ , auto will stop."
                })]
            })]
        })
    })),
    at = O.memo(({
        game: t
    }) => a(ue, {
        game: t,
        children: d("div", {
            className: "item",
            children: [a("h2", {
                children: "What is the bankroll?"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                }), a("p", {
                    children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                }), a("p", {
                    children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                }), a("p", {
                    onClick: () => fe(t),
                    className: "cl-primary",
                    children: "Read more about bankrollers."
                })]
            }), a("h2", {
                children: "How does the pool of funds operate? "
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                }), d("p", {
                    children: [a("b", {
                        className: "cl-primary",
                        children: "The house edge is 1%."
                    }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                }), a("p", {
                    children: "Payouts made to the winning players will be deducted from the bankroll."
                })]
            }), a("h2", {
                children: "How does leverage investment work?"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                }), a("p", {
                    children: "Hint: You can also use this feature as an Off-Site investment."
                }), a("p", {
                    children: "Let's make an example:"
                }), a("p", {
                    children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                })]
            }), a("h2", {
                children: "What is the bankroller dilution fee?"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                }), a("p", {
                    children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                }), a("p", {
                    children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                }), a("p", {
                    children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                })]
            }), a("h2", {
                children: "Max Profits?"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "When your betting profit exceeds the maximum profit, the system will automatically settle to the maximum profit"
                }), a("p", {
                    children: "Different currencies have different max profits as follows:"
                })]
            })]
        })
    }));
var nt = at;
const st = O.memo(() => {
        const t = T(),
            n = S(),
            e = [{
                title: t("common.game_intro"),
                node: a(it, {})
            }, {
                title: t("common.fairness"),
                node: "/videopoker_help/fairness"
            }, {
                title: t("common.bankroll"),
                node: a(nt, {
                    game: n
                })
            }];
        return a(me, {
            className: lt,
            autoControl: a(tt, {}),
            manualControl: a(et, {}),
            gameView: a(Ze, {}),
            tabs: [{
                label: t("common.all_bet"),
                value: P.AllBet
            }, {
                label: t("common.my_bet"),
                value: P.MyBet
            }],
            actions: [a(pe, {}), a(ge, {}), a(be, {}), a(ye, {}), a(Ae, {
                list: e
            })]
        })
    }),
    lt = "h1v8qh4h",
    H = B.Reader,
    D = B.Writer,
    N = B.util,
    v = B.roots.gameCrash || (B.roots.gameCrash = {});
v.BetValue = (() => {
    function t(n) {
        if (n)
            for (let e = Object.keys(n), i = 0; i < e.length; ++i) n[e[i]] != null && (this[e[i]] = n[e[i]])
    }
    return t.prototype.suggest = 0, t.encode = function(e, i) {
        return i || (i = D.create()), e.suggest != null && Object.hasOwnProperty.call(e, "suggest") && i.uint32(8).sint32(e.suggest), i
    }, t.decode = function(e, i) {
        e instanceof H || (e = H.create(e));
        let l = i === void 0 ? e.len : e.pos + i,
            s = new v.BetValue;
        for (; e.pos < l;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    s.suggest = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return s
    }, t
})();
v.DealValue = (() => {
    function t(n) {
        if (this.hold = [], n)
            for (let e = Object.keys(n), i = 0; i < e.length; ++i) n[e[i]] != null && (this[e[i]] = n[e[i]])
    }
    return t.prototype.hold = N.emptyArray, t.prototype.frontgroundId = 0, t.encode = function(e, i) {
        if (i || (i = D.create()), e.hold != null && e.hold.length) {
            i.uint32(10).fork();
            for (let l = 0; l < e.hold.length; ++l) i.sint32(e.hold[l]);
            i.ldelim()
        }
        return e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && i.uint32(120).sint32(e.frontgroundId), i
    }, t.decode = function(e, i) {
        e instanceof H || (e = H.create(e));
        let l = i === void 0 ? e.len : e.pos + i,
            s = new v.DealValue;
        for (; e.pos < l;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    if (s.hold && s.hold.length || (s.hold = []), (r & 7) === 2) {
                        let h = e.uint32() + e.pos;
                        for (; e.pos < h;) s.hold.push(e.sint32())
                    } else s.hold.push(e.sint32());
                    break;
                case 15:
                    s.frontgroundId = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return s
    }, t
})();
v.GameValue = (() => {
    function t(n) {
        if (this.initialHard = [], this.playerHard = [], this.holdHard = [], n)
            for (let e = Object.keys(n), i = 0; i < e.length; ++i) n[e[i]] != null && (this[e[i]] = n[e[i]])
    }
    return t.prototype.active = 0, t.prototype.result = 0, t.prototype.initialHard = N.emptyArray, t.prototype.playerHard = N.emptyArray, t.prototype.holdHard = N.emptyArray, t.encode = function(e, i) {
        if (i || (i = D.create()), e.active != null && Object.hasOwnProperty.call(e, "active") && i.uint32(8).sint32(e.active), e.result != null && Object.hasOwnProperty.call(e, "result") && i.uint32(16).sint32(e.result), e.initialHard != null && e.initialHard.length) {
            i.uint32(26).fork();
            for (let l = 0; l < e.initialHard.length; ++l) i.sint32(e.initialHard[l]);
            i.ldelim()
        }
        if (e.playerHard != null && e.playerHard.length) {
            i.uint32(34).fork();
            for (let l = 0; l < e.playerHard.length; ++l) i.sint32(e.playerHard[l]);
            i.ldelim()
        }
        if (e.holdHard != null && e.holdHard.length) {
            i.uint32(42).fork();
            for (let l = 0; l < e.holdHard.length; ++l) i.sint32(e.holdHard[l]);
            i.ldelim()
        }
        return i
    }, t.decode = function(e, i) {
        e instanceof H || (e = H.create(e));
        let l = i === void 0 ? e.len : e.pos + i,
            s = new v.GameValue;
        for (; e.pos < l;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    s.active = e.sint32();
                    break;
                case 2:
                    s.result = e.sint32();
                    break;
                case 3:
                    if (s.initialHard && s.initialHard.length || (s.initialHard = []), (r & 7) === 2) {
                        let h = e.uint32() + e.pos;
                        for (; e.pos < h;) s.initialHard.push(e.sint32())
                    } else s.initialHard.push(e.sint32());
                    break;
                case 4:
                    if (s.playerHard && s.playerHard.length || (s.playerHard = []), (r & 7) === 2) {
                        let h = e.uint32() + e.pos;
                        for (; e.pos < h;) s.playerHard.push(e.sint32())
                    } else s.playerHard.push(e.sint32());
                    break;
                case 5:
                    if (s.holdHard && s.holdHard.length || (s.holdHard = []), (r & 7) === 2) {
                        let h = e.uint32() + e.pos;
                        for (; e.pos < h;) s.holdHard.push(e.sint32())
                    } else s.holdHard.push(e.sint32());
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return s
    }, t
})();
const ot = t => {
    let n = t >> 4,
        e = t & 15;
    return {
        suit: n,
        dot: e
    }
};

function M(t) {
    let n = t.map(ot).map((o, f) => (o.dot === 1 && (o.dot = 14), Object.assign({
            index: f,
            hold: !1
        }, o))),
        e = _(W(n, "suit"), (o, f) => ({
            suit: o,
            cards: f
        })),
        i = ve(_(W(n, "dot"), (o, f) => ({
            dot: parseInt(f),
            cards: o
        })), "dot"),
        l = !1;
    if (i.length == 5) {
        l = !0;
        for (let o = 1; o < 5; o++)
            if (o == 4) i[4].dot == 14 && i[3].dot == 5 || i[3].dot + 1 == i[4].dot ? l = !0 : l = !1;
            else if (i[o - 1].dot + 1 != i[o].dot) {
            l = !1;
            break
        }
    }
    if (e.length == 1 && n.length == 5) return n.forEach(o => o.hold = !0), l ? i[0].dot == 10 ? [9, n] : [8, n] : [5, n];
    let s = 0,
        r = 0,
        h = 0,
        c = !1;
    for (let o = 0; o < i.length; o++) {
        let f = i[o].dot,
            m = i[o].cards;
        m.length == 4 ? (m.forEach(b => b.hold = !0), h++) : m.length == 3 ? (m.forEach(b => b.hold = !0), r++) : m.length == 2 && (s++, f > 10 && (m.forEach(b => b.hold = !0), c = !0))
    }
    if (h > 0) return [7, n];
    if (s > 0 && r > 0) return n.forEach(o => o.hold = !0), [6, n];
    if (l) return n.forEach(o => o.hold = !0), [4, n];
    if (r > 0) return [3, n];
    if (s > 1) {
        for (let o = 0; o < i.length; o++) {
            let f = i[o].cards;
            f.length == 2 && f.forEach(m => m.hold = !0)
        }
        return [2, n]
    }
    return c ? [1, n] : [0, n]
}
var rt = "/assets/fc.65ae59b4.mp3",
    dt = "/assets/lose.f61ace17.mp3",
    ht = "/assets/win.ae4b0d6d.mp3",
    ct = "/assets/close.d3bb697b.mp3";
const ut = {
        fcSound: rt,
        loseSound: dt,
        winSound: ht,
        closeSound: ct
    },
    ft = G.encode(v.DealValue);
class mt extends ke {
    constructor() {
        super({
            name: "VideoPoker",
            namespace: "/g/vp",
            sounds: ut,
            fairLink: "/videopoker_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/videopoker.html"
        }, st);
        u(this, "suggest", 0);
        u(this, "holedList", [1, 1, 1, 1, 1]);
        u(this, "cardList", [0, 0, 0, 0, 0]);
        u(this, "winList", [0, 0, 0, 0, 0]);
        u(this, "suggestHoled", [1, 1, 1, 1, 1]);
        u(this, "btnLoading", !1);
        u(this, "isHold", !1);
        u(this, "isOpen", !1);
        u(this, "isEnd", !1);
        u(this, "clickPanel", !1);
        u(this, "atime", 300);
        u(this, "pokerPayouts", [0, 1, 2, 3, 4, 6, 9, 22, 60, 800]);
        u(this, "payoutIndex", 0);
        u(this, "dealPms", null);
        u(this, "dealResolve", () => {});
        u(this, "dealReject", () => {});
        u(this, "initBetlog", null);
        u(this, "soundsInterval", 50);
        u(this, "soundsPreTime", 0);
        u(this, "isJoining", !1);
        u(this, "gameValueDecoder", G.decode(v.GameValue));
        u(this, "theme", {
            text: "#acb5db",
            main: "#56669a",
            dark: "#3b497a",
            dark2: "#3b497a",
            light: "#9ba7d1"
        });
        we(this, {
            suggest: y,
            holedList: y,
            cardList: y,
            winList: y,
            btnLoading: y,
            isHold: y,
            isOpen: y,
            isEnd: y,
            payoutIndex: y,
            maxProfit: He,
            reset: Se
        }), this.join = this.join.bind(this), this.openSuggest = this.openSuggest.bind(this), this.vpPlaySound = this.vpPlaySound.bind(this), this.socket.on("connect", this.join), Le(() => {
            j.login && this.join()
        });
        const e = this.hotkeyList.find(i => i.key == "space");
        e && (e.handler = () => (this.controlIdx === 1 ? this.handleAuto() : this.manualBet(), !1))
    }
    get maxProfit() {
        return this.amount.mul(Math.max(...this.pokerPayouts) - 1)
    }
    async join() {
        if (!!j.login && !this.isJoining) {
            this.isJoining = !0;
            try {
                await this.initialize();
                let e = await this.socketRequest("join").then(this.betResultDecoder),
                    i = this.getBetlog(e);
                i.betId !== "0" && (this.initBetlog = Promise.resolve(i), this.currencyName = i.currencyName, this.amount = new J(i.betAmount), this.handleBet())
            } catch (e) {} finally {
                this.isJoining = !1
            }
        }
    }
    async manualBet() {
        try {
            if (this.btnLoading) return;
            this.dealPms ? await this.pokerDeal() : await this.handleBet()
        } catch (e) {
            x(e)
        }
    }
    async handleAuto() {
        try {
            if (this.autoBet.isRunning) this.autoBet.stop();
            else {
                if (this.btnLoading) return;
                this.dealPms && (this.pokerDeal(), await this.dealPms), setTimeout(() => {
                    this.autoBet.start().catch(x)
                }, 30)
            }
        } catch (e) {
            x(e)
        }
    }
    vpPlaySound(e) {
        let i = new Date().getTime();
        i - this.soundsPreTime > this.soundsInterval && (this.sounds.playSound(e), this.soundsPreTime = i)
    }
    openSuggest() {
        this.controlIdx !== 1 && (this.suggest = this.suggest === 1 ? 0 : 1, this.suggest ? this.holedList = this.suggestHoled : this.holedList = [1, 1, 1, 1, 1], this.checkPayoutInfo())
    }
    checkPayoutInfo() {
        let e = [];
        this.holedList.forEach((i, l) => {
            i || e.push(this.cardList[l])
        }), this.payoutIndex = M(e)[0]
    }
    async betRequest(e, i, l) {
        this.btnLoading = !0, this.reset(!1, !1, this.cardList, [1, 1, 1, 1, 1], 0, !1, [0, 0, 0, 0, 0]), setTimeout(() => {
            this.cardList = [0, 0, 0, 0, 0]
        }, this.atime);
        let s, r = new Date().getTime();
        try {
            this.initBetlog ? (s = await this.initBetlog, this.initBetlog = null) : s = await super.betRequest(e, i, l)
        } catch (m) {
            throw this.btnLoading = !1, m
        }
        let h = new Date().getTime() - r;
        h <= 600 && await V(600 - h);
        const c = s.gameValue;
        let o = c.playerHard.length === 0 ? this.cardList : c.playerHard;
        this.reset(!0, !1, o), await V(this.atime * 2);
        let f = [1, 1, 1, 1, 1];
        return this.suggestHoled = c.holdHard, this.suggest && (f = this.suggestHoled), this.reset(!0, !0, o, f), this.checkPayoutInfo(), this.autoBet.isRunning && await V(this.atime * 3), this.btnLoading = !1, this.dealPms = new Promise((m, b) => {
            this.dealResolve = L => {
                this.dealPms = null, m(L)
            }, this.dealReject = () => {
                this.dealPms = null, b()
            }, this.autoBet.isRunning && this.pokerDeal()
        }), s = await this.dealPms, s
    }
    async pokerDeal() {
        this.reset(!1, !1), this.btnLoading = !0;
        try {
            let e = [];
            this.holedList.forEach((f, m) => {
                f === 0 && e.push(this.cardList[m])
            });
            let i = ft({
                    hold: e,
                    frontgroundId: this.txId
                }),
                l = await this.socketRequest("deal", i).then(this.betResultDecoder),
                s = this.getBetlog(l),
                r = s.gameValue,
                h = M(r.playerHard)[1].map(f => f.hold ? 1 : 0);
            this.reset(!0, !1, r.playerHard, void 0, 0, !0, h);
            let c = this.holedList.filter(f => f).length + 1;
            await V(this.atime * c), this.payoutIndex = this.pokerPayouts.indexOf(l.odds / this.oddsScale), this.payoutIndex > 0 ? this.sounds.playSound("winSound") : this.sounds.playSound("loseSound"), this.holedList = [1, 1, 1, 1, 1];
            let o = this.autoBet.isRunning ? this.atime * 4 : this.atime;
            await V(o), this.btnLoading = !1, this.dealResolve(s)
        } catch (e) {
            this.dealReject(e), this.btnLoading = !1, this.reset(!0, !0)
        }
    }
    reset(e, i, l, s, r, h, c) {
        this.isOpen = e, this.isHold = i, this.isEnd = typeof h == "boolean" ? h : this.isEnd, this.payoutIndex = typeof r == "number" ? r : this.payoutIndex, this.holedList = s || this.holedList, this.cardList = l || this.cardList, this.winList = c || this.winList
    }
    holdeCard(e) {
        if (!this.isHold) return;
        let i = this.cardList.indexOf(e);
        i !== -1 && (this.holedList[i] = this.holedList[i] === 1 ? 0 : 1), this.checkPayoutInfo()
    }
    betValue() {
        return G.encode(v.BetValue)({
            suggest: this.suggest
        })
    }
}
const Q = new mt;
var I = Q;
window.hdg = Q;

function St({
    bodyLock: t
}) {
    return a(Y, {
        bodyLock: t,
        children: d("div", {
            className: "item",
            children: [a("h2", {
                children: "Solving the Trust Issue with Online Gambling"
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "The underlying concept of provable fairness is that players have the ability to prove and verify that their results are fair and unmanipulated. This is achieved through the use of a commitment scheme, along with cryptographic hashing."
                }), a("p", {
                    children: "The commitment scheme is used to ensure that the player has an influence on all results generated. Cryptographic hashing is used to ensure that the casino also remains honest to this commitment scheme. Both concepts combined creates a trust-less environment when gambling online."
                })]
            }), a("h2", {
                children: "This is simplified in the following representation: "
            }), d("div", {
                className: "help-content",
                children: [a("p", {
                    children: "Hex string: hash = HMAC_SHA512(clientSeed:nonce, serverSeed)"
                }), a("p", {
                    children: "Shuffling logic:"
                }), d("ol", {
                    children: [a("li", {
                        children: "Create a deck of cards named \xDF, the card is sequenced as spade A-K, heart A-K, club A-K and diamond A-K."
                    }), a("li", {
                        children: "Use combination to get the hash value, which will be used as the weight of the first card (spade A) in the card \xDF."
                    }), a("li", {
                        children: "Delete the first bit of the hash value and add it back as the last character of the hash value\uFF08for example 54321 to 43215\uFF09, the new hash value will be used as the weight of the second card of \xDF (Spades 2)."
                    }), a("li", {
                        children: "Repeat step 2 to calculate the weight for all the card in \xDF"
                    }), a("li", {
                        children: "Finally, shuffle \xDF according to the corresponding weights of the cards, from small to large. The reordered cards is the shuffled \xDF."
                    })]
                }), a("p", {
                    children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)"
                })]
            })]
        })
    })
}
const pt = (t, n, e, i) => {
        window.open(`${I.config.validateLink}?s=${t}&c=${n}&h=${i}&n=${e}`)
    },
    gt = P.withSingleDetail({
        onValidate: pt,
        result: ({
            betLog: t
        }) => {
            const {
                initialHard: n,
                playerHard: e
            } = t.gv, i = n.slice(0, 5);
            return d("div", {
                className: bt,
                children: [a("div", {
                    className: "title",
                    children: "Initial Hand"
                }), a("div", {
                    className: "card-list mb",
                    children: i.map((l, s) => a(C, {
                        card: new F(l),
                        active: !0
                    }, s))
                }), a("div", {
                    className: "title",
                    children: "Final Hand"
                }), a("div", {
                    className: "card-list",
                    children: e.map((l, s) => a(C, {
                        card: new F(l),
                        active: !0
                    }, s))
                })]
            })
        }
    });
var Lt = gt;
const bt = "d14fwkud";
export {
    nt as Bankroll, Lt as Detail, St as Fairness, I as Game
};
import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as n
} from "./index.28e31dff.js";
var e = `<section>
  <h2>Coin accuracy limit</h2>
  <p>
    Due to the limitation of data storage accuracy, changes in the amount less
    than a certain amount will not take effect. The minimum accuracy of most
    coins is consistent with the currency accuracy of the blockchain. For
    example, the minimum unit of SATS is 1. The minimum data storage accuracy of
    each coin is shown in the following table:
  </p>
</section>
`,
    i = `<section>\r
  <h2>Limite de precis\xE3o da moeda</h2>\r
  <p>\r
Devido \xE0 limita\xE7\xE3o da precis\xE3o do armazenamento de dados, as altera\xE7\xF5es no valor inferior a um determinado valor n\xE3o ter\xE3o efeito. A precis\xE3o m\xEDnima da maioria das moedas \xE9 consistente com a precis\xE3o da moeda do blockchain. Por exemplo, a unidade m\xEDnima de SATS \xE9 1. A precis\xE3o m\xEDnima de armazenamento de dados de cada moeda \xE9 mostrada na tabela a seguir:\r
  </p>\r
</section>`,
    o = `<section>
  <h2>Batas keakuratan koin</h2>
  <p>
   Karena keterbatasan akurasi penyimpanan data, perubahan jumlah lebih sedikit
     melebihi jumlah tertentu tidak akan berlaku. Keakuratan minimum dari sebagian besar
     koin konsisten dengan keakuratan mata uang dari blockchain. Untuk
     contoh, satuan minimum SATS adalah 1. Akurasi penyimpanan data minimum sebesar
     masing-masing koin ditunjukkan pada tabel berikut:
  </p>
</section>
`;

function m() {
    return n(a, {
        br: i,
        en: e,
        id: o,
        isCoinlimit: !0
    })
}
export {
    m as
    default
};
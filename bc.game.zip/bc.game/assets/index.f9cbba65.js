var ie = Object.defineProperty,
    le = Object.defineProperties;
var ce = Object.getOwnPropertyDescriptors;
var x = Object.getOwnPropertySymbols;
var V = Object.prototype.hasOwnProperty,
    $ = Object.prototype.propertyIsEnumerable;
var B = (s, t, e) => t in s ? ie(s, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : s[t] = e,
    p = (s, t) => {
        for (var e in t || (t = {})) V.call(t, e) && B(s, e, t[e]);
        if (x)
            for (var e of x(t)) $.call(t, e) && B(s, e, t[e]);
        return s
    },
    g = (s, t) => le(s, ce(t));
var W = (s, t) => {
    var e = {};
    for (var n in s) V.call(s, n) && t.indexOf(n) < 0 && (e[n] = s[n]);
    if (s != null && x)
        for (var n of x(s)) t.indexOf(n) < 0 && $.call(s, n) && (e[n] = s[n]);
    return e
};
import {
    dp as P,
    u as v,
    a,
    D as re,
    f1 as me,
    f2 as ue,
    f3 as de,
    y as E,
    f4 as fe,
    v as he,
    o as w,
    a4 as H,
    a5 as _,
    eh as U,
    A as N,
    p as Q,
    j as l,
    t as R,
    q as D,
    du as K,
    bg as be,
    r as u,
    bT as pe,
    s as f,
    bU as ge,
    F as ye,
    eP as Ne,
    eQ as Ie,
    eR as ve,
    eS as we,
    eT as Se,
    eV as ke,
    l as De,
    aG as Ae,
    G as y,
    al as X,
    f5 as Y,
    dD as Z,
    b as L,
    cj as Pe,
    eO as Oe,
    bf as xe,
    ao as ee,
    J as G,
    d as j,
    n as Ge,
    bN as M,
    dq as Le,
    ba as Me,
    $ as T,
    x as _e,
    bb as q
} from "./index.28e31dff.js";
import {
    s as A
} from "./slotsUtils.a0534c25.js";
const I = P.Reader,
    F = P.Writer,
    C = P.util,
    r = P.roots.slots || (P.roots.slots = {});
r.End = (() => {
    function s(t) {
        if (t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return s.prototype.betId = "", s.prototype.odds = 0, s.prototype.time = C.Long ? C.Long.fromBits(0, 0, !0) : 0, s.prototype.currencyName = "", s.prototype.betAmount = "", s.prototype.winAmount = "", s.prototype.userId = 0, s.prototype.userName = "", s.prototype.gameName = "", s.prototype.fullName = "", s.prototype.gameId = "", s.prototype.extData = "", s.encode = function(e, n) {
        return n || (n = F.create()), e.betId != null && Object.hasOwnProperty.call(e, "betId") && n.uint32(10).string(e.betId), e.odds != null && Object.hasOwnProperty.call(e, "odds") && n.uint32(16).uint32(e.odds), e.time != null && Object.hasOwnProperty.call(e, "time") && n.uint32(24).uint64(e.time), e.currencyName != null && Object.hasOwnProperty.call(e, "currencyName") && n.uint32(34).string(e.currencyName), e.betAmount != null && Object.hasOwnProperty.call(e, "betAmount") && n.uint32(42).string(e.betAmount), e.winAmount != null && Object.hasOwnProperty.call(e, "winAmount") && n.uint32(50).string(e.winAmount), e.userId != null && Object.hasOwnProperty.call(e, "userId") && n.uint32(56).uint32(e.userId), e.userName != null && Object.hasOwnProperty.call(e, "userName") && n.uint32(66).string(e.userName), e.gameName != null && Object.hasOwnProperty.call(e, "gameName") && n.uint32(74).string(e.gameName), e.fullName != null && Object.hasOwnProperty.call(e, "fullName") && n.uint32(82).string(e.fullName), e.gameId != null && Object.hasOwnProperty.call(e, "gameId") && n.uint32(90).string(e.gameId), e.extData != null && Object.hasOwnProperty.call(e, "extData") && n.uint32(98).string(e.extData), n
    }, s.decode = function(e, n) {
        e instanceof I || (e = I.create(e));
        let o = n === void 0 ? e.len : e.pos + n,
            i = new r.End;
        for (; e.pos < o;) {
            let c = e.uint32();
            switch (c >>> 3) {
                case 1:
                    i.betId = e.string();
                    break;
                case 2:
                    i.odds = e.uint32();
                    break;
                case 3:
                    i.time = e.uint64();
                    break;
                case 4:
                    i.currencyName = e.string();
                    break;
                case 5:
                    i.betAmount = e.string();
                    break;
                case 6:
                    i.winAmount = e.string();
                    break;
                case 7:
                    i.userId = e.uint32();
                    break;
                case 8:
                    i.userName = e.string();
                    break;
                case 9:
                    i.gameName = e.string();
                    break;
                case 10:
                    i.fullName = e.string();
                    break;
                case 11:
                    i.gameId = e.string();
                    break;
                case 12:
                    i.extData = e.string();
                    break;
                default:
                    e.skipType(c & 7);
                    break
            }
        }
        return i
    }, s
})();
r.RoomIdParam = (() => {
    function s(t) {
        if (t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return s.prototype.roomId = "", s.encode = function(e, n) {
        return n || (n = F.create()), e.roomId != null && Object.hasOwnProperty.call(e, "roomId") && n.uint32(10).string(e.roomId), n
    }, s.decode = function(e, n) {
        e instanceof I || (e = I.create(e));
        let o = n === void 0 ? e.len : e.pos + n,
            i = new r.RoomIdParam;
        for (; e.pos < o;) {
            let c = e.uint32();
            switch (c >>> 3) {
                case 1:
                    i.roomId = e.string();
                    break;
                default:
                    e.skipType(c & 7);
                    break
            }
        }
        return i
    }, s
})();
r.BetLogs = (() => {
    function s(t) {
        if (this.endItem = [], t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return s.prototype.endItem = C.emptyArray, s.encode = function(e, n) {
        if (n || (n = F.create()), e.endItem != null && e.endItem.length)
            for (let o = 0; o < e.endItem.length; ++o) r.End.encode(e.endItem[o], n.uint32(10).fork()).ldelim();
        return n
    }, s.decode = function(e, n) {
        e instanceof I || (e = I.create(e));
        let o = n === void 0 ? e.len : e.pos + n,
            i = new r.BetLogs;
        for (; e.pos < o;) {
            let c = e.uint32();
            switch (c >>> 3) {
                case 1:
                    i.endItem && i.endItem.length || (i.endItem = []), i.endItem.push(r.End.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(c & 7);
                    break
            }
        }
        return i
    }, s
})();
const je = "/softswiss.html";

function Ce(s) {
    return s ? "Live Casino" : "Slots"
}

function Ee(s, t, e) {
    const n = typeof s == "boolean" ? s : A.getIsLive(s);
    return [{
        label: Ce(n),
        path: A.getSlotsListPath(n)
    }, {
        label: e,
        path: A.getSlotsGamePath(n, e)
    }]
}
const Re = s => {
    const t = v(),
        e = Object.assign(s.data.betLog, {
            userName: s.userName,
            userId: s.userId
        }),
        n = {
            single: !0,
            betLog: e,
            gameName: s.gameName,
            userName: s.userName,
            userId: s.userId
        };
    return a(re, {
        title: t("common.bet_slip"),
        children: a(me, {
            children: a(ue, g(p({
                gameName: s.gameName,
                showIssus: !0
            }, e), {
                gameId: s.data.gameId,
                shareNode: a(de, g(p({}, n), {
                    third: !0
                }))
            }))
        })
    })
};
var Fe = Re;

function Be(s) {
    return s.map(t => ({
        betId: t.betId,
        userId: t.userId,
        nickName: t.userName,
        nonce: 0,
        currencyName: t.currencyName,
        betAmount: Number(t.betAmount),
        profitAmount: new E(t.winAmount).sub(t.betAmount).toNumber(),
        winAmount: Number(t.winAmount),
        odds: t.odds,
        betTime: Number(t.time),
        gameName: t.gameName,
        userName: t.userName,
        gameValue: "",
        gameId: t.gameId
    }))
}
const te = ({
        list: s,
        showName: t
    }) => {
        const e = Be(s);
        return a(fe, {
            list: e,
            onClick: o => {
                const i = {
                    betLog: {
                        betAmount: o.betAmount,
                        betId: o.betId,
                        currencyName: o.currencyName,
                        odds: o.odds * 1e4,
                        betTime: o.betTime,
                        winAmount: o.winAmount,
                        userName: o.userName,
                        userId: o.userId
                    },
                    gameId: o.gameId
                };
                he.push(a(Fe, {
                    data: i,
                    gameName: o.gameName,
                    userId: o.userId,
                    userName: o.userName
                }))
            },
            showName: t
        })
    },
    Ve = function() {
        const t = O().allbet;
        return t.length === 0 ? a(H, {}) : a(te, {
            list: t,
            showName: !0
        })
    };
var ne = w(Ve);
const $e = function() {
    const t = O().mybet;
    return t.length === 0 ? a(H, {}) : a(te, {
        list: t
    })
};
var se = w($e);
var ae = _.memo(function({
    rtp: t
}) {
    const e = v(),
        n = () => {
            Q.push(l("div", {
                className: We,
                children: [e("common.house_edge"), ": ", new E(100).sub(t).toNumber(), "%"]
            }))
        };
    return a(U, {
        icon: a(N, {
            name: "Fairness"
        }),
        title: e("common.fairness"),
        onClick: n
    })
});
R({
    cl1: ["#1e2024", D("#e9eaf2", .6)]
});
const We = "fo3ap71";
var Te = _.memo(function() {
    const t = v(),
        e = K().gameInfo;
    if (!e.detail || e.detail.length === 0) return null;
    const n = e.detail.split(`
`).filter(i => i.length > 1),
        o = () => {
            Q.push(a(be, {
                className: qe,
                closeable: !0,
                children: n.map((i, c) => a("p", {
                    children: i
                }, c))
            }))
        };
    return a(U, {
        icon: a(N, {
            name: "Help"
        }),
        title: t("common.fairness"),
        onClick: o
    })
});
const qe = "f1p8xwww";
const oe = w(u.exports.forwardRef(function(m, h) {
        var k = m,
            {
                tabs: s = [],
                actions: t = [],
                src: e,
                banner: n,
                className: o = "",
                children: i,
                topView: c,
                extSW: d
            } = k,
            S = W(k, ["tabs", "actions", "src", "banner", "className", "children", "topView", "extSW"]);
        const b = v();
        return s = s.concat([{
            label: b("common.highrolls"),
            value: pe
        }, {
            label: f.isMobile ? b("common.contest") : b("page.contest.title"),
            value: ge
        }]), a(ye, {
            children: l(Ne, g(p({
                className: `game-style-iframe ${o}`
            }, S), {
                children: [a("div", {
                    className: "game-area",
                    children: f.isMobile ? i : l("div", {
                        className: "game-main",
                        children: [c, i || a(Je, {
                            extSW: d,
                            src: e
                        }), a(Ie, {
                            actions: t
                        })]
                    })
                }), a(ve, {
                    tabs: s
                }), a(we, {}), a(Se, {})]
            }))
        })
    })),
    Je = _.memo(({
        src: s,
        extSW: t
    }) => {
        const {
            ref: e,
            inView: n
        } = ke(), o = u.exports.useRef(null), i = u.exports.useMemo(() => n ? He : Ue, [n]);
        return a("div", {
            ref: e,
            className: De(Qe, "game-iframe-wrap"),
            children: t ? a(ze, {
                extSW: t
            }) : a("iframe", {
                className: "game-iframe",
                style: i,
                ref: o,
                src: s,
                allow: "autopaly",
                allowFullScreen: !0
            })
        })
    }),
    ze = _.memo(({
        extSW: s
    }) => {
        const t = u.exports.useRef(null);
        return u.exports.useEffect(() => {
            const e = {
                target_element: "game_wrapper",
                launch_options: JSON.parse(s)
            };
            t.current ? t.current.launch(e, () => {}, y) : Ae("https://casino.cur.a8r.games/public/sg.js", "sg").then(n => {
                n.launch(e, () => {}, y), t.current = n
            }).catch(y)
        }, [s]), a("div", {
            id: "game_wrapper",
            style: {
                width: "100%",
                height: "100%"
            }
        })
    }),
    He = {},
    Ue = {
        position: "fixed",
        width: 2,
        height: 1,
        left: 0,
        top: 0,
        opacity: 0
    },
    Qe = "wvhswwm";
const Ke = w(s => {
        const t = O(),
            e = v();
        return a("div", {
            children: a(oe, {
                src: "",
                extSW: "",
                tabs: [{
                    label: e("common.all_bet"),
                    value: () => a(ne, {})
                }, {
                    label: e("common.my_bet"),
                    value: () => a(se, {})
                }],
                children: l("div", {
                    className: Xe,
                    children: [l("div", {
                        className: Ze,
                        children: [a("img", {
                            className: "slots-img",
                            src: t.gameInfo.thumbnail,
                            alt: ""
                        }), a("div", {
                            className: "slots-fullname",
                            children: t.gameInfo.fullName
                        }), l("div", {
                            className: "slots-provider",
                            children: ["by", " ", a(X, {
                                to: A.getSlotsListPath(t.live, t.gameInfo.providerName),
                                children: t.gameInfo.providerName
                            })]
                        }), l("div", {
                            className: "slots-actions",
                            children: [a(Y, {}), a(ae, {
                                rtp: String(t.gameInfo.rtpDes)
                            }), a(Te, {}), a(Z, {})]
                        })]
                    }), l("div", {
                        className: Ye,
                        children: [l(L, {
                            loading: s.btnDisabled,
                            type: "conic",
                            onClick: () => s.onPlay(!1),
                            children: [a(N, {
                                name: "Start"
                            }), a("span", {
                                children: e("common.real_play")
                            })]
                        }), t.gameInfo.supportDemo && l(L, {
                            type: "gray",
                            loading: s.btnDisabled,
                            onClick: () => s.onPlay(!0),
                            children: [a(N, {
                                name: "Start"
                            }), a("span", {
                                children: e("common.fun_play")
                            })]
                        })]
                    })]
                })
            })
        })
    }),
    Xe = "gchh7et",
    Ye = "buneup9",
    Ze = "gm8sl0d";
const et = function(t) {
    const e = O(),
        n = Ee(e.live, e.gameInfo.providerName, e.gameInfo.fullName),
        o = v();
    return l("div", {
        className: ot,
        children: [l("div", {
            className: at,
            children: [a(Pe, {
                list: n
            }), l("div", {
                className: "provider",
                children: [a("span", {
                    className: "tit_by",
                    children: " By "
                }), a(X, {
                    to: A.getSlotsListPath(e.live, e.gameInfo.providerName),
                    className: "under_txt",
                    children: e.gameInfo.providerName
                })]
            })]
        }), a(oe, {
            src: t.src,
            extSW: t.extSW,
            actions: [a(Y, {}), a(ae, {
                rtp: String(e.gameInfo.rtpDes)
            }), a(Z, {}), a(Oe, {})],
            tabs: [{
                label: o("common.all_bet"),
                value: () => a(ne, {})
            }, {
                label: o("common.my_bet"),
                value: () => a(se, {})
            }],
            topView: a("div", {
                className: st,
                children: l("div", {
                    className: `switch-wrap ${!t.supportDemo||t.btnDisabled?"disabled":""}`,
                    children: [a("div", {
                        className: t.isDemo ? "" : "active",
                        children: o("common.real_play")
                    }), a(xe, {
                        value: t.isDemo,
                        onChange: t.onPlay,
                        type: "rangeslider"
                    }), a("div", {
                        className: t.isDemo ? "active" : "",
                        children: o("common.fun_play")
                    })]
                })
            }),
            children: !t.src && l("div", {
                className: nt,
                children: [a("div", {
                    className: "ssp-img",
                    style: {
                        backgroundImage: `url(${e.gameInfo.thumbnail})`
                    }
                }), a("div", {
                    className: "mask",
                    children: l("div", {
                        className: "tips",
                        children: [a("div", {
                            className: "wrap",
                            children: o("game.slots.tips")
                        }), l("div", {
                            className: "btn-wrap",
                            children: [l(L, {
                                type: "conic",
                                disabled: t.btnDisabled,
                                onClick: () => t.onPlay(!1),
                                children: [a(N, {
                                    name: "Start"
                                }), a("span", {
                                    children: o("common.real_play")
                                })]
                            }), l(L, {
                                type: "gray",
                                disabled: !t.supportDemo || t.btnDisabled,
                                onClick: () => t.onPlay(!0),
                                children: [a(N, {
                                    name: "Start"
                                }), a("span", {
                                    children: o("common.fun_play")
                                })]
                            })]
                        })]
                    })
                })]
            })
        })]
    })
};
var tt = w(et);
const nt = "g1w37d0i";
R({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [D("#31343c", .8), D("#5f6975", .4)],
    cl3: [D("#99a4b0", .6), "#fff"]
});
const st = "gq0gxfm";
R({
    cl1: ["#99a4b0", D("#5f6975", .8)],
    cl2: ["#f5f6f7", "#7BC514"]
});
const at = "s17afgnl",
    ot = "sloaxhr";

function it() {
    const [s, t] = ee({
        msg: null,
        win: null,
        url: "/softswiss.html"
    });

    function e() {
        t({
            win: window.open(),
            url: ""
        })
    }
    return u.exports.useEffect(() => {
        const n = s.win;
        if (n && (s.url && (n.location.href = s.url), s.msg)) {
            const o = i => {
                i.source === n && i.data.event === "inited" && n.postMessage(JSON.stringify(s.msg), "*")
            };
            return window.addEventListener("message", o), () => {
                window.removeEventListener("message", o)
            }
        }
    }, [s.msg, s.url]), {
        reload: e,
        postMessage: t
    }
}
const lt = w(function() {
        const t = O(),
            e = f.isMobile,
            n = t.gameInfo.supportDemo,
            {
                reload: o,
                postMessage: i
            } = it(),
            [c, d] = ee({
                btnDisabled: !1,
                supportDemo: n,
                isDemo: n,
                src: "",
                extSW: ""
            }),
            S = async h => {
                if (!j.login) return Ge("/login");
                if (c.btnDisabled) return !1;
                e && o(), d({
                    btnDisabled: !0
                });
                try {
                    const m = await t.getGameSrc(h, G.current),
                        k = Boolean(m.extSW),
                        b = k ? je : m.url;
                    e && i({
                        msg: m.extSW,
                        url: b
                    }), d({
                        src: b,
                        isDemo: h,
                        extSW: k ? JSON.stringify(m.extSW) : ""
                    })
                } catch (m) {
                    y(m)
                }
                d({
                    btnDisabled: !1
                })
            };
        return u.exports.useEffect(() => {
            !c.isDemo && c.src && !f.isMobile && (d({
                src: ""
            }), S(!1))
        }, [G.current]), u.exports.useEffect(() => {
            G.hideAmount = !0;
            const h = m => {
                m.data === "nested" && !f.isMobile && d({
                    src: ""
                })
            };
            return window.addEventListener("message", h), () => {
                G.hideAmount = !1, window.removeEventListener("message", h)
            }
        }, []), f.isMobile ? a(Ke, g(p({}, c), {
            onPlay: S
        })) : a(tt, g(p({}, c), {
            onPlay: S
        }))
    }),
    J = M.encode(r.RoomIdParam),
    z = r.End;
class ct extends Le {
    constructor(t, e) {
        super({
            name: e,
            namespace: "/g/ps"
        }, lt), this.FullName = "", this.oddsScale = 1e4, this.mybet = [], this.allbet = [], Me(this, {
            mybet: q,
            allbet: q
        }), this.gameName = e, this.live = t, this.bindEvent()
    }
    async bindEvent() {
        this.onConnect = this.onConnect.bind(this), this.onMybet = M.decodeBind(this.onMybet.bind(this), z), this.loadMybet = this.loadMybet.bind(this), this.onAllbet = M.decodeBind(this.onAllbet.bind(this), z), this.socket.on("edu", this.onMybet), this.socket.on("ed", this.onAllbet), this.socket.on("connect", this.onConnect)
    }
    async init(t = {
        gameName: ""
    }) {
        this.name = t.gameName, this.gameName = this.name, await super.init(), j.waitLogin().then(this.loadMybet)
    }
    async loadMybet() {
        await T.post("/platform-slots/bet-log/my-bet/", {
            gameName: this.gameName,
            size: 20,
            page: 1
        }).then(t => {
            this.mybet = t.map(e => (e.odds = Math.floor(e.odds / this.oddsScale * 100) / 100, e))
        }).catch(y)
    }
    onConnect() {
        this.socketRequest("join", J({
            roomId: this.gameName
        })).then(rt).then(t => {
            t.endItem.map(e => {
                e.odds = e.odds / this.oddsScale
            }), this.allbet = t.endItem
        }).catch(y)
    }
    onAllbet(t) {
        if (t.odds = t.odds / this.oddsScale, this.allbet.find(o => o.betId === t.betId)) return;
        let n = [t, ...this.allbet];
        n.length > 20 && (n = n.splice(0, 20)), this.allbet = n
    }
    onMybet(t) {
        if (t.odds = t.odds / this.oddsScale, this.mybet.find(o => o.betId === t.betId)) return;
        this.emit("betEnd", {
            amount: new E(t.betAmount),
            odds: t.odds,
            currencyName: t.currencyName
        });
        let n = [t, ...this.mybet];
        n.length > 20 && (n = n.splice(0, 20)), this.mybet = n
    }
    active() {
        super.active()
    }
    deactivate() {
        this.socket.off("edu", this.onMybet), this.socket.off("ed", this.onAllbet), this.socket.off("connect", this.onConnect), this.socket.emit("leave", J({
            roomId: this.gameName
        })), super.deactivate()
    }
    async getGameSrc(t, e) {
        return await T.post("/platform-slots/launch/", {
            gameName: this.gameName,
            currency: e,
            lang: _e.lng,
            device: f.isMobile ? 1 : 2,
            demo: t,
            areaCode: j.areaCode
        })
    }
    getPathName(t) {
        return Number(t) === 1 ? "Slots" : "Live Casino"
    }
}
var ft = ct;
const rt = M.decode(r.BetLogs),
    O = K;
export {
    Fe as Detail, ae as Fairness, ft as SlotsGame
};
import {
    aG as i,
    aH as c
} from "./index.28e31dff.js";
async function u(a) {
    return (s == null ? void 0 : s.request(a)) || "No captcha!"
}
class n {
    constructor(t) {
        this.timeout = 0, this.key = t, this.inited = c(8e3).then(() => this.init())
    }
    async request(t) {
        await this.inited;
        const e = [this.requestCode(t)];
        return this.timeout > 0 && e.push(c(this.timeout).then(() => "time out")), await Promise.race(e)
    }
}
class o extends n {
    async init() {
        await i("https://js.hcaptcha.com/1/api.js");
        const t = "hcaptcha_container",
            e = document.createElement("div");
        e.id = t, e.style.display = "none", document.body.appendChild(e), hcaptcha.render(t, {
            size: "invisible",
            sitekey: "cf0b9a27-82e3-42fb-bfec-562f8045e495"
        })
    }
    async requestCode(t) {
        return (await hcaptcha.execute({
            async: !0
        })).response
    }
}
let s = null;
const r = "cf0b9a27-82e3-42fb-bfec-562f8045e495";
s = new o(r);
export {
    u as r
};
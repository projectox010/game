import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as e
} from "./index.28e31dff.js";
var n = `<section>
  <h2>1.Introduction</h2>
  <p>1.1 This set of
    terms and conditions govern the use of the Sportsbook platform. When placing a bet with Sportsbook platform,
    the Account Holder is therefore agreeing that the Account Holder has read, understood and will be adhering
    to these Terms and Conditions including the general Terms and Conditions at any time applicable to
    Sportsbook platform, click .</p>
  <p>1.2 The use of this Sportsbook platform is subject to the regulations imposed by the <b style="color: var(--title-color);">(Cura\xE7ao license.)</b>.</p>
  <p>1.3 Any dispute relating in any way to the use of this Sportsbook platform should be emailed to <b style="color: var(--title-color);">(support@bc.game)</b>. Should the reply not be considered satisfactory, arequest for confidential arbitration can be sent to the <b style="color: var(--title-color);">(info@curacaolicensing.com)</b>. Their decision shall be binding and may be entered as a judgment in any court of competent jurisdiction.</p>
  <p>1.4 Sportsbook platform reserves the right to make changes to the site, betting limits, payout limits and offerings.</p>
  <p>1.5 Sportsbook platform may update, amend, edit and supplement these Terms and Conditions at any time.</p>
  <p>1.6 Any reference in these Terms and Conditions to words/objects that appear in singular also applies to plural. References to gender are non-binding and to be treated for information</p>
  <p>purposes only.</p>
</section>

<section>
  <h2>2. Definition</h2>
  <p>2.1 Sportsbook
    platform \u2013 legal entity engaged in betting activities in accordance with the licensing and legislative
    requirements of the country.</p>
  <p>2.2 Client - an individual who has agreed to the Rules for accepting bets, registered on the site <b style="color: var(--title-color);">(https://BC.GAME/) </b>(and other subdomain versions of the site).</p>
  <p>2.3 Bet \u2013 risk-based agreement concluded between the Client and the Betting Company on the outcome of an event
    in which they do not participate, involving a win. Bets are made on terms previously proposed by the
    Sportsbook platform.</p>
  <p>2.4 Stake - the amount of money transferred by the client to Sportsbook platform and which are the main
    condition for participation in a bet in accordance with these Rules.</p>
  <p>2.5 The outcome is the result of the event on which the Sportsbook platform is invited to make a bet.</p>
  <p>2.6 Odd \u2014 the number by which the bet amount of the stakeholder is multiplied when determining the payout amount if bet wins.</p>
  <p>2.7 Winnings - cash to be paid to the Client upon the outcome, on which a bet was made.</p>
  <p>2.8 Bonuses:</p>
  <p>2.81 Bet refund - bet refund, client gets just won amount on his account. For example, freebet 5 on odd 3.5 client get 5*3.5 - 5 = 12.50</p>
  <p>2.82 Free money - client gets bet amount and won on his account. For example, freebet 5 on odd 3.5 client get 5*3.5 = 18.50</p>
  <p>2.83 No risk bet - player uses his money for bet, but if bet loses he gets his money back.</p>
</section>

<section>
  <h2>3. Betting Rules</h2>
  <p>3.1 Sportsbook platform reserves the right to cancel any bet made on obviously \u201Cbad\u201D odds, switched odds or a bet made after an event has started.</p>
  <p>3.2 All bets accepted by Sportsbook platform are subject to these rules, as well as to applicable license conditions.</p>
  <p>3.3 Sportsbook platform reserves the right to refuse, restrict, cancel or limit any bet.</p>
  <p>3.4 Sportsbook platform reserves the right to settle after the contest is final or with official results</p>
  <p>3.5 The winner of an event will be determined on the date of the event\u2019s conclusion. Sportsbook platform does
    not recognize protested or overturned decisions for betting purposes. The settlement of an event suspended
    after the start of the competition will be decided according to the betting rules specified for that sport
    by Sportsbook platform</p>
  <p>3.6 No one under the age of 18 is permitted to make a bet.</p>
  <p>3.7 All rules contained herein are subject to changes and revisions by Sportsbook platform without prior written notice.
    All changes and revisions to our rules will be posted on the Sportsbook platform website.</p>
  <p>3.8  Maximum bet amounts on all sporting events will be determined by Sportsbook platform and are subject to change without
    prior written notice. Sportsbook platform also reserves the right to adjust limits on individual accounts as
    well.</p>
  <p>3.9 For accounts with minus balances, Sportsbook platform reserves the right to cancel any pending plays,
    whether placed with funds resulting from the error or not.</p>
  <p>3.10 Members are solely responsible for their own account transactions. Please be sure to review and confirm your
    bets for any mistakes before sending them in. Once a transaction is complete, it cannot be changed.
    Sportsbook platform does not take responsibility for missing or duplicate bets made by the client and will
    not entertain requests for alterations because a play is missing or duplicated. Clients may review their
    transactions in the \u201CMy Bets\u201D of the site after each session to ensure all requested bets were accepted.</p>
  <p>3.11 Disputes must be lodged within seven (7) days from the date the bet in question has been decided. No claims will be
    honoured after this period. The client is solely responsible for their account transactions.</p>
  <p>3.12 Winnings will always be calculated using Decimal Odds. Please note, that when converting odds into the
    British standard, round-off errors may occur, since some odds don\u2019t have an exact translation into
    British-style fractions. Here, we\u2019ll show the nearest fractional odds.</p>
  <p>3.13 Sportsbook platform reserves the right to suspend a client account without prior notice.</p>
  <p>3.14 In the event of there being a discrepancy between the English language version of these rules and any other language version, the English language version will be deemed to be correct.</p>
  <p>3.15 Combo (accumulators, parlays, multis) bets are not accepted where the outcome of one part of the bet contributes to the outcome of another. If that kind of bet is accepted, we have the right to cancel this type of bet. example: place bet on Barcelona to win the La Liga combined with a Barcelona win in the deciding game.</p>
  <p>3.16 Any bets placed with a system bet will not count for the wagering requirement in Bonus.</p>
  <p>3.17 Live Score Update is for guidance only. Sportsbook platform is not responsible for any errors. Sportsbook platform reserves the right to cancel any bets if the outcome is already known or if the
    odds have not been updated correctly due to technical issues.</p>
  <p>3.18 Outright bets are considered all in run or not and so will be settled as a loss if the selection does not
    take part in the event, unless otherwise stated. Dead heat rules apply where there is more than one winner.
    Bettors stakes are first divided by the number of selections who tied and then this portion of their stakes
    is settled as a winner and the rest settled as a loser.</p>
  <p>3.19 Sportsbook platform reserves the right to void or cancel any bets where the outcome has been altered by the
    imposition of penalty points, enforced relegations or any other measure enforced as a
    result of anything other than the normal results of the games/competitions in question.</p>
  <p>3.20 All bets are settled using the information provided by the official body running the competition at the time
    of the result except where stated otherwise. In the case of any events outside of official competitions then
    bets are settled using the information provided.</p>
  <p>3.21 If one of competitors didn&#39;t start Sportsbook platform cancel this head to head market.</p>
  <p>3.22 If both competitors didn&#39;t finish, winner will be competitors who&#39;s have more laps. If both competitors out in the same lap, Sportsbook platform cancel this head to head market.</p>
  <p>3.23 If competitors in the same position, Sportsbook platform cancel bets on this head to head market.</p>
  <p>3.24 Sportsbook platform don&#39;t responsible for the damage incurred by the client as a result of a system malfunction, defects, delays, manipulations or errors in data transfer.</p>
  <p>3.25 Clients&#39; claims are considered by Sportsbook platform within thirty days from the moment the Client submits a written application to Sportsbook platform. After making a decision, Sportsbook platform notifies the client by means of an e-mail linked to the game account.</p>
  <p>3.26 In case of suspicion of unfair activity, Sportsbook platform reserves the right to void any bet or any part of it, thus
    making the questionable bet invalid (in these cases, the payout is made with odds of \u201C1\u201D) or suspend any
    withdrawals for up to 31 calendar days.</p>
  <p>3.27 Clients are allowed to bet only as individuals, group bets are not allowed. Repeated bets on the same results /
    winners from the same or different customers may subsequently be declared invalid. Even after the official
    result of the competition / athletes is already known, Sportsbook platform may
    consider the indicated bets invalid if it considers that the Clients act in collusion or as a syndicate, or
    the bets considered were made by one or more Clients within a short period of time. The betting company also has the right to refuse to accept bets or to count already made bets as
    invalid if they are made from different game accounts from the same IP address.</p>
  <p>3.28 LIVE bets: If the match is interrupted or postponed and does not continue in 48 hours after the scheduled time,
    the bets will be canceled (except for those outcomes that are clearly defined when the game was stopped).
  </p>
  <p>3.29 Statistics or editorial text published at the Sportsbook platform site are to be considered as added
    information but Sportsbook platform does not acknowledge or accept any liability whatsoever if the
    information is not correct. At all times it is the Account Holder\u2019s responsibility to be aware about
    circumstances relating to an event.</p>
  <p>3.30 It is forbidden to use automated systems (any kind of scanners or robots) on Sportsbook. Sportsbook platform
    reserves the right to cancel any bet which made using automatic systems</p>
  <p>3.31 It is forbidden
    to use accounts owned by other people or registered accounts on other</p>
  <p>people. Sportsbook platform reserves the right to cancel any bet which made not an owner of an account.</p>
</section>
  
<section>
  <h2>4. Bets Types</h2>
  <p>4.1 Single (Ordinary) - bet on a separate outcome of the event. Single bet payout equal to the product of the bid amount set for the outcome price.</p>
  <p>4.2 Combo - bet on several independent outcomes of events. To win on express it is necessary that none of the
    outcomes that are included in the express, there was no loss. Losing one of the results of the combo means
    losing all over the combo. Combo payment is equal to the product the amount of the bet on the odds of all
    outcomes included in the combo.</p>
  <p>4.3 System - a set of combos, which is a complete search variants of combos of the same size from a fixed set of
    outcomes. It is characterized by the same stake for each express (option system) and the same number of
    outcomes in each express. Betting the system must specify the total number of outcomes and number of combos (system option). Payment on the system is equal to the amount of payments
    on combo included in the system.</p>
  <p>4.4 A \u2018Trixie\u2019 is a combination, which includes one treble and three doubles from a selection of three matches.</p>
  <p>4.5 A \u2018Patent\u2019 is a combination, which includes one treble, three doubles and three singles from a selection of three matches.</p>
  <p>4.6 A \u2018Yankee\u2019 is a combination, which includes one fourfold, four trebles and six doubles from a selection of four matches.</p>
  <p>4.7 A \u2018Canadian\u2019 (also known as \u2018Super Yankee\u2019) is a combination, which includes one fivefold, five fourfolds, ten trebles and ten doubles from a selection of five matches.</p>
  <p>4.8 A \u2018Heinz\u2019 is a combination, which includes one sixfold, six fivefolds, fifteen fourfolds, twenty trebles and fifteen doubles from a selection of six matches.</p>
  <p>4.9 A \u2018Super Heinz\u2019 is a combination, which includes one sevenfold, seven sixfolds, twenty-one fivefolds, thirty-five fourfolds, thirty-five trebles and twenty-one doubles from a selection of seven matches.</p>
  <p>4.10 A \u2018Goliath\u2019 is a combination, which includes one eightfold, eight sevenfolds, twenty-eight sixfolds, fifty-six fivefolds, seventy fourfolds, fifty-six trebles and twenty-eight doubles from a selection of eight matches.</p>
  <p>4.11 If odds consider more than 2 digits after decimal point, the payout will be rounded for second digit after decimal point.</p>
  <p>4.12 "Cash out" is an individual offer initiated by Sportsbook platform, addressed to a bet participant, aimed at changing one or several essential betting conditions (coefficient, event calculation time, etc.) in order to fix a new result and complete the bet at the current time (further - Cash out). The offer to
    redeem a bet can be both accepted and rejected by the participant of the bet. By selecting \u201CCash out\u201D the participant of the bet confirms his acceptance of the
    new essential conditions of the bet. Cash out rates can be offered for both prematch and for live betting.
    The bookmaker&#39;s office reserves the right to change the offer to repurchase the bid over time, or not to
    form a bid to repurchase the bet without giving a reason.</p>
</section>

<section>
  <h2>5. Markets</h2>
  <p>5.1 &quot;Match&quot; (1X2) is where it is possible to bet on the (partial or definite) outcome of a match or event. The options are: &quot;1&quot; = Home team, or team listed to the left side of the offer;
    &quot;X&quot; = Draw, or the selection in the middle; &quot;2&quot; = Away team, or team listed to the right
    side of the offer.</p>
  <p>5.2 &quot;Correct Score&quot; ( is where it is possible to bet on the (partial or definite) exact score of a
    match or event.</p>
  <p>5.3 &quot;Over/Under&quot; (Totals) is where it is possible to bet on the (partial or definite) amount of a
    predefined occurrence (e.g. goals, points, corners, rebounds, penalty minutes, etc.). Should the total
    amount of the listed occurrences be exactly equal to the betting line, then all bets on this offer will be declared void. Example: an offer where the betting line is 128.0 points and the match ends with the result
    64-64 will be declared void.</p>
  <p>5.4 &quot;Odd/Even&quot; is where it is possible to bet on the (partial or definite) amount of a predefined
    occurrence (e.g. goals, points, corners, rebounds, penalty minutes, etc.).&quot;Odd&quot; is 1,3,5 etc.;
    &quot;Even&quot; is 0,2,4 etc.</p>
  <p>5.5 A &quot;Head-to-Head&quot; and/or &quot;Triple-Head&quot; is a competition between two or three participants/outcomes, originating from either an officially organised event, or else, as virtually defined
    by Sportsbook platfrorm</p>
  <p>5.6 &quot;Half time/Full time&quot; is where it is possible to bet on the result in half time and the final
    outcome of the match. E.g. if at Half time the score is 1-0 and the match ends 1-1, the winning outcome is
    1/X. The bet is void if the regular time of the match is played in a different time format than those listed in the bet
    (i.e. other than two halves).</p>
  <p>5.7 &quot;Period betting&quot; is where it is possible to bet on the outcome of each separate period within a
    match/event.</p>
  <p>5.8 &quot;Draw No Bet&quot; is where it is possible to bet on either &quot;1&quot; or &quot;2&quot; as defined
    in . It is also common practice to refer to &quot;Draw No Bet&quot; in cases where no draw odds are offered.
    Should the specific match contain no winner (E.g. match ends as a draw), or the particular occurrence not
    happen (E.g. Draw No Bet and match ends 0-0) the stakes will be refunded.</p>
  <p>5.9 &quot;Handicap&quot; is where it is possible to bet on whether the chosen outcome will be victorious once
    the listed handicap is added/subtracted (as applicable) to the match/period/total score to which the bet
    refers to. In those circumstances where the result after the adjustment of the handicap line is exactly
    equal to the betting line, then all bets on this offer will be declared void.</p>
  <p>5.10 Example: a bet on -3.0 goals will be declared void if the team chosen wins the match by exactly 3 goals difference (3-0,4-1, 5-2, etc).</p>
  <p>5.11 Asian Handicap: Home team (-1.75) vs Away team (+1.75). This means that the stake is divided into 2 equal bets and
    placed on the outcomes -1.5 and -2.0. For the bet to be fully paid out at the listed odds, Team A must win
    the match with a bigger margin than both of their listed handicaps (ie. 3 goals or more margin). In the
    eventuality that Team A wins with only a 2 goal margin, the bet will be
    considered as partially won with a full payout on the -1.5 part of the bet and a refund on the -2.0 side
    since the outcome on that part of the bet would be considered a \u201Ctie\u201D. Should the match produce any other
    outcome, including a Team A victory with only 1 goal of margin, the whole stake would be lost. Away team is
    given a +1.75 goal advantage in the match. This means that the stake is divided into 2 equal bets and placed
    on the outcomes +1.5 and +2.0.</p>
  <p>5.10 &quot;Double Chance&quot; is where it is possible to bet simultaneously on two (partial or definite)
    outcomes of a match or event. The options are: 1X, 12 and X2 with &quot;1&quot;, &quot;X&quot; and
    &quot;2&quot; as defined in .</p>
  <p>5.11 &quot;Outright&quot; or &quot;Place&quot; betting is where it is possible to choose from a list of
    alternatives and bet on the eventuality that a participant wins or places within a specified position in the
    classification of the listed event/competition.</p>
  <p>5.12 Bets on &quot;Quarter / Half / Period X&quot; refer to the result/score achieved in the relevant timeframe and does
    not include any other points/goals/events tallied from other parts of the event/match. Bets will be voided if the match is played in any other format but the one stipulated in the
    offer.</p>
  <p>5.13 Bets on &quot;Result at end of Quarter / Half / Period X&quot; refer to the result of the match/event after
    termination of the stipulated timeframe and will take into account all other points/goals/events tallied from
    previous parts of the event/match.</p>
  <p>5.14 Bets on &quot;Race to X Points / Race to X Goals...&quot; and similar offers refer to the team/participant reaching the earliest the particular tally of points/goals/events. If the offer lists a
    timeframe (or any other period restriction) it will not include any other points/goals/events tallied from other parts of the event/match which are not related to the mentioned timeframe. Should the listed score not
    be reached within the stipulated timeframe (if any), all bets will be declared void, unless otherwise
    stated.</p>
  <p>5.15 Bets on &quot;Winner of Point X / Scorer of Goal X&quot; and similar offers refer to the team/participant scoring/winning the listed occurrence. For the settlement of these offers, no reference to
    events happening prior to the listed occurrence will be taken into consideration. hould the listed
    event not be scored/won within the stipulated timeframe (if any), all bets will be declared void, unless
    otherwise stated.</p>
  <p>5.16 Bets referring to the happening of a particular occurrence in a pre-defined time order, such as \u201CFirst
    Card\u201D, or \u201CNext Team to receive penalty minutes\u201D will be settled as void should it not be possible, without
    any reasonable doubt, to decide the winning outcome, for example in case of players from different teams
    which are shown a card in the same interruption of play.</p>
  <p>5.17 &quot;Team to score first and win&quot; refer to the listed team scoring the first goal in the match and
    going on to win the match. Should there be no goals in the match all bets will be settled as void.</p>
  <p>5.18 Any reference to &quot;clean sheet&quot; indicates that the listed team must not concede any goal during the
    match.</p>
  <p>5.19 &quot;Team to win from behind&quot; refers to the listed team winning the match after having been at least 1
    goal down at any point in the match.</p>
  <p>5.20 Any reference for a team to win all halves/periods (e.g. Team to win both halves) means that the listed team
    must score more goals than its opponent during all the stipulated halves/periods of the match.</p>
  <p>5.21 Any reference to &quot;Injury Time&quot; refers to the amount displayed by the designated official and not to
    the actual amount played.</p>
  <p>5.22 Settlement of bets on offers such as &quot;Man of the Match&quot;, &quot;Most Valuable Player&quot; etc.
    will be based on the competition&#39;s organisers\u2019 decision, unless otherwise stated.</p>
</section>

<section>
  <h2>6. Special rules for sports</h2>
  <p>6.1. Soccer</p>
  <p>6.1.1. Bets on the outcome of a match will be decided based on two halves of the scheduled number of minutes each
    and any time the referee adds to compensate for injuries and other stoppages. It does not include periods of extra
    time nor penalty shootouts if not stated.</p>
  <p>6.1.2. Corners awarded but not taken are not considered.</p>
  <p>6.1.3. Own goals will not be considered for Anytime Goalscorer or Player to score X or Next Goalscorer or more
    settlement purposes and are ignored</p>
  <p>6.1.4. All players who took part in the match since kick off or previous goal are considered as runners</p>
  <p>6.1.5. If a player is not in the starting XI all player markets will be voided.</p>
  <p>6.1.6. If for any reason an unlisted player scores a goal all bets on listed players stand</p>
  <p>6.1.7. Anytime Goalscorer or Player to score X or Next Goalscorer market will be settled based on TV insert and
    statistics provided by Press Association unless there is clear evidence that these statistics are not correct.</p>
  <p>6.1.8. Interval markets will be settled based on the goal time announced by TV. If this is not available, the time
    according to the match clock is considered.</p>
  <p>6.1.9. Interval goal markets are settled based on the time the ball crosses the line, and not the time the kick is
    made.</p>
  <p>6.1.10. Corner interval markets are settled based on the time the corner kick is taken and not the time the corner
    is conceded or awarded.</p>
  <p>6.1.11. Booking interval markets are settled based on the time the card is shown and not the time the infringement
    is made</p>
  <p>6.1.12. Offsides will be settled based on the time when the referee gives the decision. This rule will be applied
    on any video assistant referee (VAR) situation.</p>
  <p>6.1.13. Penalty markets will be settled based on the time when the referee gives the decision. This rule will be
    applied on any video assistant referee (VAR) situation.</p>
  <p>6.1.14. Penalties awarded but not taken are not considered</p>
  <p>6.1.15. Next scoring type.Freekick: The goal has to be scored directly from the freekick or corner to qualify as a
    goal by freekick. Deflected shots count as long as the freekick or corner taker is awarded the goal. Penalty: Goal
    must be scored directly from the penalty. Goals after a rebound of a missed penalty do not count. Own Goal: If goal
    is declared as an own goal. Header: The scorers last touch has to be with the head. Shot: Goal has to be with any
    other part of the bodythan the head and the other types do not apply.No Goal.</p>
  <p>6.1.16. If the market was opened with a missing or incorrect red card, we reserve the right to void betting</p>
  <p>6.1.17. If odds were offered with an incorrect match time (more than 5 minutes), we reserve the right to void
    betting.</p>
  <p>6.1.18. If a wrong score is entered, all markets will be cancelled for the time when the incorrect score was
    displayed</p>
  <p>6.1.19. If the team names or category are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.1.20. Yellow card counts as 1 card and red or yellow-red card as 2. The 2nd yellow for oneplayer which leads to a
    yellow red card is not considered. As a consequence one player cannot cause more than 3 cards.</p>
  <p>6.1.21. Settlement will be made according to all available evidence of cards shown during the regular 90 minutes
    play.</p>
  <p>6.1.22. Cards shown after the match are not considered.</p>
  <p>6.1.23. Cards for non-players (already substituted players, managers, players on bench) are not considered</p>
  <p>6.1.24. Yellow card counts as 10 points and red or yellow red cards as 25. The 2nd yellow for one player which
    leads to a yellow red card is not considered. As a consequence one player cannot cause more than 35 booking points.
  </p>
  <p>6.1.25. Settlement will be made according to all available evidence for cards shown during the regular 90 minutes
    play.</p>
  <p>6.1.26. Cards for non-players (already substituted players, managers, players on bench) are not considered.</p>
  <p>6.1.27. If the match format was changed sportsbook reserves the right to void all bets.</p>
  <p>6.1.28. If a friendly match ended by referee decision earlier than 80 minutes.</p>
  <p>6.1.29. If a friendly match ended by referee decision earlier than 80 minutes</p>
  <p>6.1.30. All soccer player props bets are settled using the information provided by OPTA<a href="https://soccerstats.info/" target="_blank" class="cl-primary"> (https://soccerstats.info/)</a></p>
  <p>6.1.31. Player Props definitionGoal/Own GoalDifferent governing bodies have different rules, and where possible
    Opta works with the relevant people to reflect their official decisions on goal scorers.Regarding deflections,
    normally a goal is awarded if the original attempt is on target. An own goal is usually awarded if the attempt is
    off target and deflected into the goal by an opponent.ShotsA shot target is defined as any clear attempt to score
    that:Goes into the net regardless of intent.Is a clear attempt to score that would have gone into the net but for
    being saved by the goalkeeper or is stopped by a player who is the last-man with the goalkeeper having no chance of
    preventing the goal (last line block).Goes over or wide of the goal without making contact with another player.Would
    have gone over or wide of the goal but for being stopped by a goalkeeper\u2019s save or by an outfield player.Directly
    hits the frame of the goal and a goal is not scored.Blocked shots are not counted as shots.Shots on goal - any goal
    attempt that:Goes into the net regardless of intent.Is a clear attempt to score that would have gone into the net
    but for being saved by the goalkeeper or is stopped by a player who is the last-man with the goalkeeper having no
    chance of preventing the goal (last line block).Shots directly hitting the frame of the goal are not counted as
    shots on target, unless the ball goes in and is awarded as a goal.Shots blocked by another player, who is not the
    last-man, are not counted as shots on target.Goal AssistThe final touch (pass, pass-cum-shot or any other touch)
    leading to the recipient of the ball scoring a goal. If the final touch (as defined in bold) is deflected by an
    opposition player, the initiator is only given a goal assist if the receiving player was likely to receive the ball
    without the deflection having taken place. Own goals, directly taken free kicks, direct corner goals andpenalties do
    not get an assist awarded.TackleA tackle is defined as where a player connects with the ball in a ground challenge
    where he successfully takes the ball away from the player in possession.The tackled player must clearly be in
    possession of the ball before the tackle is made.A tackle won is deemed to be where the tackler or one of his
    team-mates regainspossession as a result of the challenge, or that the ball goes out of play and is \u201Csafe\u201D.A tackle
    lost is where a tackle is made but the ball goes to an opposition player.Both are deemed as successful tackles
    however, the outcome of the tackle (won or lost) is different based on where the ball goes after the tackle.It is
    not a tackle, when a player cuts out a pass by any means.</p>
  <p>6.1.31.1. Goal/Own GoalDifferent governing bodies have different rules, and where possible Opta works with the
    relevant people to reflect their official decisions on goal scorers.Regarding deflections, normally a goal is
    awarded if the original attempt is on target. An own goal is usually awarded if the attempt is off target and
    deflected into the goal by an opponent.</p>
  <p>6.1.31.2. ShotsA shot target is defined as any clear attempt to score that:Goes into the net regardless of
    intent.Is a clear attempt to score that would have gone into the net but for being saved by the goalkeeper or is
    stopped by a player who is the last-man with the goalkeeper having no chance of preventing the goal (last line
    block).Goes over or wide of the goal without making contact with another player.Would have gone over or wide of the
    goal but for being stopped by a goalkeeper\u2019s save or by an outfield player.Directly hits the frame of the goal and a
    goal is not scored.Blocked shots are not counted as shots.</p>
  <p>\u25CF Goes into the net regardless of intent.</p>
  <p>\u25CF Is a clear attempt to score that would have gone into the net but for being saved by the goalkeeper or is stopped
    by a player who is the last-man with the goalkeeper having no chance of preventing the goal (last line block).</p>
  <p>\u25CF Goes over or wide of the goal without making contact with another player.</p>
  <p>\u25CF Would have gone over or wide of the goal but for being stopped by a goalkeeper\u2019s save or by an outfield player.
  </p>
  <p>\u25CF Directly hits the frame of the goal and a goal is not scored.Blocked shots are not counted as shots.</p>
  <p>6.1.31.3. Shots on goal - any goal attempt that:Goes into the net regardless of intent.Is a clear attempt to score
    that would have gone into the net but for being saved by the goalkeeper or is stopped by a player who is the
    last-man with the goalkeeper having no chance of preventing the goal (last line block).Shots directly hitting the
    frame of the goal are not counted as shots on target, unless the ball goes in and is awarded as a goal.Shots blocked
    by another player, who is not the last-man, are not counted as shots on target.</p>
  <p>\u25CF Goes into the net regardless of intent.</p>
  <p>\u25CF Is a clear attempt to score that would have gone into the net but for being saved by the goalkeeper or is stopped
    by a player who is the last-man with the goalkeeper having no chance of preventing the goal (last line block).Shots
    directly hitting the frame of the goal are not counted as shots on target, unless the ball goes in and is awarded as
    a goal.Shots blocked by another player, who is not the last-man, are not counted as shots on target.</p>
  <p>6.1.31.4. Goal AssistThe final touch (pass, pass-cum-shot or any other touch) leading to the recipient of the ball
    scoring a goal. If the final touch (as defined in bold) is deflected by an opposition player, the initiator is only
    given a goal assist if the receiving player was likely to receive the ball without the deflection having taken
    place. Own goals, directly taken free kicks, direct corner goals andpenalties do not get an assist awarded.</p>
  <p>6.1.31.5. TackleA tackle is defined as where a player connects with the ball in a ground challenge where he
    successfully takes the ball away from the player in possession.The tackled player must clearly be in possession of
    the ball before the tackle is made.A tackle won is deemed to be where the tackler or one of his team-mates
    regainspossession as a result of the challenge, or that the ball goes out of play and is \u201Csafe\u201D.A tackle lost is
    where a tackle is made but the ball goes to an opposition player.Both are deemed as successful tackles however, the
    outcome of the tackle (won or lost) is different based on where the ball goes after the tackle.It is not a tackle,
    when a player cuts out a pass by any means.</p>
  <p>\u25CF A tackle won is deemed to be where the tackler or one of his team-mates regainspossession as a result of the
    challenge, or that the ball goes out of play and is \u201Csafe\u201D.</p>
  <p>\u25CF A tackle lost is where a tackle is made but the ball goes to an opposition player.Both are deemed as successful
    tackles however, the outcome of the tackle (won or lost) is different based on where the ball goes after the
    tackle.It is not a tackle, when a player cuts out a pass by any means.</p>
  <p>6.2. Tennis</p>
  <p>6.2.1. In case of a retirement and walk over of any player all undecided bets are considered void.</p>
  <p>6.2.2. In case of any delay (rain, darkness...) all markets remain unsettled and the trading will be continued as
    soon as the match continues.</p>
  <p>6.2.3. If penalty point(s) are awarded by the umpire, all bets on that game will stand.</p>
  <p>6.2.4. In case of a match is finished before certain points/games were finished, all affected point/game related
    markets are considered void.</p>
  <p>6.2.5. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.2.6. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.2.7. If a player retires all undecided markets are considered void.</p>
  <p>6.2.8. If a match is decided by a Match tie-break then it will be considered to be the 3rd set</p>
  <p>6.2.9. Every tie-break or Match tie-break counts as 1 game</p>
  <p>6.3. Basketball</p>
  <p>6.3.1. Markets do not consider overtime unless otherwise stated.</p>
  <p>6.3.2. If odds were offered with an incorrect match time (more than 2 minutes), we reserve the right to void
    betting.</p>
  <p>6.3.3. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.3.4. In the event that a match does not finish in a tie, but overtime is played for qualification purposes, the
    markets will be settled according to the result at the end of regular time.</p>
  <p>6.3.5. If a match ends before the Xth is reached, this market is considered void (cancelled). Who scores Xth point?
    (incl. ot), Which team will win race to x points? (incl. OT).</p>
  <p>6.3.6. Market (Will there be overtime?) will be settled as yes if at the end of regular time the match finishes in
    a draw, regardless of whether or not overtime is played.</p>
  <p>6.4. American Football</p>
  <p>6.4.1. In case of any delay (rain, darkness...) all markets remain unsettled and the trading will be continued as
    soon as the match continues.</p>
  <p>6.4.2. Markets do not consider overtime unless otherwise stated.</p>
  <p>6.4.3. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.4.4. If odds were offered with an incorrect match time (more than 89 seconds), we reserve the right to void
    betting.</p>
  <p>6.4.5. If a wrong score is displayed we reserve the right to void betting for this timeframe</p>
  <p>6.4.6. In case of abandoned or postponed matches all markets are considered void unless the match continues in the
    same NFL weekly schedule (Thursday - Wednesday local stadium time).</p>
  <p>6.4.7. If the teams are displayed incorrectly, we reserve the right to void betting</p>
  <p>6.4.8. All offered players are considered as runners.</p>
  <p>6.4.9. If no further touchdown is scored, the market (Next touchdown scorer (incl. overtime)) will be voided.</p>
  <p>6.4.10. Players which are not listed are considered as \u201CCompetitor1 other player\u201D or\u201CCompetitor2 other player\u201D for
    settlement purposes. Note this does not include players which are listed without an active price.</p>
  <p>6.4.11. Players of the Defense- or Special team are considered as \u201CCompetitor1 d/st player\u201D or \u201CCompetitor2 d/st
    player\u201D for settlement purposes, even if the player is listed as dedicated outcome.</p>
  <p>6.4.12. Market will be settled based on TV insert and statistics provided by official associations unless there is
    clear evidence that statistics are not correct.</p>
  <p>6.5. Ice Hockey</p>
  <p>6.5.1. All markets (except period, overtime and penalty shootout markets) are considered for regular time only
    unless it is mentioned in the market.</p>
  <p>6.5.2. In the event of a game being decided by a penalty shootout, then one goal will be added to the winning
    team's score and the game total for settlement purposes. This applies to all markets including overtime and penalty
    shootout</p>
  <p>6.5.3. If the market remains open when the following events have already taken place: goals and penalties, we
    reserve the right to void betting.</p>
  <p>6.5.4. If odds were offered with an incorrect match time (more than 2 minutes), we reserve the right to void
    betting.</p>
  <p>6.5.5. If a wrong score is entered all markets will be cancelled for the time when the incorrect score was
    displayed.</p>
  <p>6.6. Baseball</p>
  <p>6.6.1. If an inning ends before the Xth point is reached (incl. extra innings), this market (Which team wins race
    to x points?, Who scores the Xth point (incl. ot)) is considered void (cancelled).</p>
  <p>6.6.2. Market (When will the match be decided?) will be settled as \u201CAny extra inning\u201D if at the end of regular time
    (After a full 9 Innings) the match finishes in a draw, regardless of whether or not overtime (Extra innings) is
    played</p>
  <p>6.6.3. Market (Will there be overtime?) will be settled as \u201CYes\u201D if at the end of regular time (After full 9
    Innings) the match finishes in a draw, regardless of whether or not overtime (Extra innings) is played</p>
  <p>6.6.4. Possible extra innings are not considered in any market unless otherwise stated.</p>
  <p>6.6.5. All markets will be cleared according the final result after 9 innings (8 \xB9\u2044\uFEA3 innings if home team is
    leading at this point)</p>
  <p>6.6.6. If a match is interrupted or cancelled and won\u2019t be continued on the same day, all undecided markets are
    considered void.</p>
  <p>6.6.7. If markets remain open with an incorrect score or incorrect match status which has a significant impact on
    the prices, we reserve the right to void betting.</p>
  <p>6.7. Handball</p>
  <p>6.7.1. If a match ends before the Xth is reached, this market (Who scores Xth point? (incl. ot)) is considered void
    (cancelled)</p>
  <p>6.7.2. If a match ends before the Xth is reached, this market (Which team will win race to x points? (incl. ot)) is
    considered void (cancelled).</p>
  <p>6.7.3. All markets (except Who scores the Xth point and Which team will win race to X points) are considered for
    regular time only.</p>
  <p>6.7.4. If the match goes to a 7-metre shootout; the markets \u201CWho scores Xth point?\u201D and \u201CWhich team will win race
    to X points?\u201D will be voided.</p>
  <p>6.7.5. If odds were offered with an incorrect match time (more than 3 minutes), we reserve the right to void
    betting.</p>
  <p>6.7.6. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.8. Volleyball</p>
  <p>6.8.1. If a set ends before the Xth point is reached, this market (Who scores [Xth] point in set [y]) is considered
    void (cancelled)</p>
  <p>6.8.2. In the case of a match not being finished all undecided markets are considered void.</p>
  <p>6.8.3. Golden set is not considered in any of the mentioned markets</p>
  <p>6.8.4. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.8.5. Official points deductions will be taken into account for all undetermined markets. Markets which have
    already been determined will not take deductions into account.</p>
  <p>6.9. Beach Volleyball</p>
  <p>6.9.1. if a set ends before the Xth point is reached, this market (Who scores [Xth] point in set [y]) is considered
    void (cancelled)</p>
  <p>6.9.2. In the case of a match not being finished all undecided markets are considered void.</p>
  <p>6.9.3. Golden set is not considered in any of the mentioned markets</p>
  <p>6.9.4. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.9.5. If a team retires all undecided markets are considered void.</p>
  <p>6.9.6. Official points deductions will be taken into account for all undetermined markets. Markets which have
    already been determined will not take deductions into account.</p>
  <p>6.10. Futsal</p>
  <p>6.10.1. All markets (except halftime, first half markets, overtime and penalty shoot out) are considered for
    regular time only.</p>
  <p>6.10.2. If a match is interrupted and continued within 48h after initial kick-off date, all open bets will be
    settled with the final result. Otherwise all undecided bets are considered void.</p>
  <p>6.10.3. If the market remains open when the following events have already taken place: goals, red or yellow-red
    cards and penalties, we reserve the right to void betting.</p>
  <p>6.10.4. If the market was opened with a missing or incorrect red card, we reserve the right to void betting.</p>
  <p>6.10.5. If odds were offered with an incorrect match time (more than 2 minutes), we reserve the right to void
    betting.6.10.6 If a wrong score is entered, all markets will be cancelled for the time when the incorrect score was
    displayed.6.10.7. If the team names or category are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.11. Badminton</p>
  <p>6.11.1. If a set ends before the Xth point is reached, this market (Who scores [Xth] point in [Nth] set) is
    considered void (cancelled)</p>
  <p>6.11.2. In the case of a match not being finished, all undecided markets are considered void.</p>
  <p>6.11.3. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.11.4. If a team retires all undecided markets are considered void.</p>
  <p>6.11.5. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.11.6. Official points deductions will be taken into account for all undetermined markets. Markets which have
    already been determined will not take deductions into account.</p>
  <p>6.12. Rugby Union and Rugby League</p>
  <p>6.12.1. All markets (except halftime, first half markets, overtime and penalty shoot out) are considered for
    regular time only.</p>
  <p>6.12.2. Regular 80 Minutes: Markets are based on the result at the end of a scheduled 80 minutes play unless
    otherwise stated. This includes any added injury or stoppage time but does not include extra-time, time allocated
    for a penalty shootout or sudden death.</p>
  <p>6.12.3. If the market remains open when the following events have already taken place: score changes or red cards,
    we reserve the right to void betting.</p>
  <p>6.12.4. If the market was opened with a missing or incorrect red card, we reserve the right to void betting.</p>
  <p>6.12.5. If odds were offered with an incorrect match time (more than 2 minutes), we reserve the right to void
    betting.</p>
  <p>6.12.6. If the team names or category are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.13. Rugby Sevens</p>
  <p>6.13.1. All markets (except halftime, first half markets, overtime and penalty shoot out) are considered for
    regular time only.</p>
  <p>6.13.2. Regular 14 / 20 Minutes: Markets are based on the result at the end of a scheduled 14 / 20 minutes play
    unless otherwise stated. This includes any added injury or stoppage time but does not include extra-time, time
    allocated for a penalty shootout or sudden death</p>
  <p>6.13.3. If the market remains open when the following events have already taken place: score changes or red cards,
    we reserve the right to void betting.</p>
  <p>6.13.4. If the market was opened with a missing or incorrect red card, we reserve the right to void betting.</p>
  <p>6.13.5. If odds were offered with an incorrect match time (more than 1 minute), we reserve the right to void
    betting.1</p>
  <p>6.13.6. If the team names or categories are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.14. Darts</p>
  <p>6.14.1. In the case of a match not being finished all undecided markets are considered void.</p>
  <p>6.14.2. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.14.3. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.14.4. If a match is not completed all undecided markets are considered void.</p>
  <p>6.14.5. Bullseye counts as red check out colour.</p>
  <p>6.15. Snooker</p>
  <p>6.15.1. In the case of a retirement of a player or disqualification all undecided markets are considered void.</p>
  <p>6.15.2. In case of a re-rack settlement stays if the outcome was determined before the re-rack</p>
  <p>6.15.3. No fouls or free balls are considered for settlement of any Potted- Colour market</p>
  <p>6.15.4. In case of a frame starting but not being completed, all frame related markets will be voided unless the
    outcome has already been determined</p>
  <p>6.15.5. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.15.6. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.15.7. If a match is not completed all undecided markets are considered void.</p>
  <p>6.16. Table Tennis</p>
  <p>6.16.1. If a set ends before the Xth point is reached, this market (Who scores [Xth] point in set [y]) is
    considered void (cancelled).</p>
  <p>6.16.2. In the case of a match not being finished all undecided markets are considered void.</p>
  <p>6.16.3. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.16.4. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.16.5. If a player retires all undecided markets are considered void.</p>
  <p>6.16.6. Official points deductions will be taken into account for all undetermined markets. Markets which have
    already been determined will not take deductions into account.</p>
  <p>6.17. Bowls</p>
  <p>6.17.1. If a set ends before the Xth point is reached, this market (Xth set - which team wins race to x points, Xth
    set - which team scores Xth point) is considered void (cancelled)</p>
  <p>6.17.2. In case of a retirement and walk over of any player all undecided bets are considered void.</p>
  <p>6.17.3. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.17.4. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.18. Cricket</p>
  <p>6.18.1. Match BettingDescription: Who will win the match?Rules: All match betting will be settled in accordance
    with official competition rules. In matches affected by adverse weather, bets will be settled according to the
    official result.If there is no official result, all bets will be void.In the case of a tie, if the official
    competition rules do not determine a winner then deadheat rules will apply. In competitions where a bowl off or
    super over determines a winner, bets will be settled on the official result.In First Class Matches, if the official
    result is a tie, bets will be settled as a dead-heat between both teams. Bets on the draw will be settled as
    losers.If a match is abandoned due to external factors, then bets will be void unless a winner is declared based on
    the official competition rules.If a match is cancelled then all bets will be void if it is not replayed or restarted
    within 36 hours of its advertised start time.</p>
  <p>6.18.2. Double ChanceDescription: Will the match result be either of the three options given?Rules: A tie will be
    settled as a dead heat. All match betting will be settled in accordance with official competition rules.If there is
    no official result, all bets will be void.</p>
  <p>6.18.3. Match Betting: Draw No BetDescription: Who will win the match given that all bets will be void if the match
    is a draw?Rules: A tie will be settled as a dead heat. All match betting will be settled in accordance with official
    competition rules. If there is no official result, all bets will be void.</p>
  <p>6.18.4. Tied MatchDescription: Will the match be tied?Rules: All bets will be settled according to the official
    result. If the match is abandoned or there is no official result, all bets will be void. For First Class matches a
    tie is when the side batting second is bowled out for a second time with scores level.</p>
  <p>6.18.5. Most FoursDescription: Which team will hit the most fours?Rules: In limited overs matches, bets will be
    void if it has not been possible to complete at least 80% of the overs scheduled to be bowled in either innings due
    to external factors, including bad weather, unless settlement of the bet has already been determined before the
    reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.Only fours scored from the bat (off any delivery \u2013 legal or not)
    will count towards the total fours. Overthrows, all run fours and extras do not count.Fours scored in a super over
    do not count.In First Class games, only first innings fours will count.</p>
  <p>6.18.6. Most SixesDescription: Which team will hit the most sixes?Rules: In limited overs matches, bets will be
    void if it has not been possible to complete at least 80% of the overs scheduled to be bowled in either innings due
    to external factors, including bad weather, unless settlement of the bet has already been determined before the
    reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.Only sixes scored from the bat (off any delivery \u2013 legal or not)
    will count towards the total sixes. Overthrows and extras do not count.Sixes scored in a super over do not count.In
    First Class games, only first innings sixes will count.</p>
  <p>6.18.7. Most ExtrasDescription: Which team will have the most extras added to their batting score?Rules: In limited
    overs matches, bets will be void if it has not been possible to complete at least 80% of the overs scheduled to be
    bowled in either innings due to external factors, including bad weather, unless settlement of the bet has already
    been determined before the reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have
    been bowled, unless settlement of the bet has already been determined.All wide deliveries, no balls, byes, leg byes
    and penalty runs in the match count towards the final result. If there are runs off the bat as well as extras from
    the same delivery, the runs off the bat do not count towards the final total.Extras in a super over do not count.In
    First Class games, only first innings extras will count.</p>
  <p>6.18.8. Most Run Outs ConcededDescription: Which team will concede the most run outs in the match?Rules: A run out
    \u201Cconceded\u201D means that a member of that team will be run out while batting.In limited overs matches, bets will be
    void if it has not been possible to complete at least 80% of the scheduled overs in either innings due to external
    factors, including bad weather, unless settlement has already been determined before the reduction.In drawn First
    Class matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet has already
    been determined.Run Outs in a super over do not count.In First Class games, only first innings run outs will count.
  </p>
  <p>6.18.9. Highest First OverDescription: Which team will score the most runs in the first over of their
    innings?Rules: The first over must be completed for bets to stand unless settlement has already been determined. If
    during the first over the innings is ended due to external factors, including bad weather, all bets will be void,
    unless settlement has already been determined before thereduction.In First Class matches the market refers only to
    each team\u2019s first innings. Extras and penalty runs in the particular over count towards settlement.</p>
  <p>6.18.10. Most Runs in Groups of OversDescription: Which team will score the most runs after the first specified
    number overs of their innings?Rules: If the specified number of overs are not complete the bet will be void, unless
    the team is all out, declares, reaches their target or settlement of the bet has already been determined.In limited
    overs matches, bets will be void if it has not been possible to complete at least 80% of the specified overs have
    been bowled at the time the bet was placed due to external factors, including bad weather, unless settlement of the
    bet has already been determined before thereduction.In First Class matches the market refers only to each team\u2019s
    first innings.</p>
  <p>6.18.11. Highest First PartnershipDescription: Which team will score the most runs before losing their first
    wicket?Rules: If the batting team reaches the end of their allotted overs, reaches their target or declares before
    the first wicket falls, the result will be the total amassed. For settlement purposes, abatsman retiring hurt does
    not count as a wicket.In limited overs matches, bets will be void if the innings has been reduced due to external
    factors, including bad weather, unless settlement has already been determined before the reduction.In drawn First
    Class matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet has already
    been determined.In First Class matches the market refers only to each team\u2019s first innings.</p>
  <p>6.18.12. Match Markets Match FoursDescription: How many fours will be in hit in the match?Rules: In limited overs
    matches, bets will be void if it has not been possible to complete at least 80% of the overs scheduled to be bowled
    due to external factors, including bad weather, unless settlement of the bet has already been determined before the
    reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.Only fours scored from the bat (off any delivery \u2013 legal or not)
    will count towards the total fours. Overthrows, all run fours and extras do not count.Fours scored in a super over
    do not count.</p>
  <p>6.18.13. Match SixesDescription: How many sixes will be hit in the match?Rules: In limited overs matches, bets will
    be void if it has not been possible to complete at least 80% of the overs scheduled to be bowled due to external
    factors, including bad weather, unless settlement of the bet has already been determined before the reduction.In
    drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet
    has already been determined.Only sixes scored from the bat (off any delivery \u2013 legal or not) will count towards the
    total fours. Overthrows and extras do not count.Sixes scored in a super over do not count.</p>
  <p>6.18.14. Match ExtrasDescription: How many extras will be scored in the match?Rules: In limited overs matches, bets
    will be void if it has not been possible to complete at least 80% of the overs scheduled to be bowled due to
    external factors, including bad weather, unless settlement of the bet has already been determined before the
    reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.All wide deliveries, no balls, byes, leg byes and penalty runs in
    the match count towards the final result. If there are runs off the bat as well as extras from the same delivery,
    the runs off the bat do not count towards the final total.Extras in a super over do not count.</p>
  <p>6.18.15. Match Run OutsDescription: How many run outs will there be in the match?Rules: In limited overs matches,
    bets will be void if it has not been possible to complete at least 80% of the scheduled overs in either innings due
    to external factors, including bad weather, unless settlement of the bet has already been determined before the
    reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.Run outs in a super over do not count.Maximum Over in Match
    Description: How many runs will be scored in the highest scoring over of the match?Rules: In limited overs matches,
    bets will be void if it has not been possible to complete at least 80% of the overs scheduled to be bowled due to
    external factors, including bad weather, unless settlement of the bet has already been determined before the
    reduction.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.All runs, including extras, count towards settlement. Super overs
    do not count.</p>
  <p>6.18.16. Match Top BatsmanDescription: Which batsman will score the most runs in the match?Rules: The result of
    this market is determined on the batsman with the highest individual score in the match.In limited overs matches,
    bets will be void if it has not been possible to complete at least 50% of the overs scheduled to be bowled in either
    innings at the time the bet was placed due to external factors, including bad weather.Top batsmen bets for First
    Class matches apply only to the first innings of each team, and will be void if fewer than 200 overs have been
    bowled, unless settlement of the bet has already been determined. If a player was named at the toss, but later is
    removed as a concussion sub, thatplayer will still be counted, as will the replacement player.If a batsman does not
    bat, but was named in the starting XI, bets on that batsman will stand.If a substitute (concussion, or otherwise)
    not named in the original XI scores the highest individual score in the team\u2019s innings, bets on the market will be
    void.When two or more players score the same number of runs, dead-heat rules will apply. Runs scored in a super over
    do not count.</p>
  <p>6.18.17. Match Top BowlerDescription: Which bowler will take the most wickets in the match?Rules: The result of
    this market is determined on the bowler with the most wickets in the match.In limited overs matches, bets will be
    void if it has not been possible to complete at least 50% of the overs scheduled to be bowled in either innings at
    the time the bet was placed due to external factors, including bad weather.Top bowler bets for First Class matches
    apply only to the first innings of each team, and will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined. If a player was named at the toss, but later is removed as a
    concussion sub, thatplayer will still be counted, as will the replacement player.If a bowler does not bowl, but was
    named in the starting XI, bets on that bowler will stand.If a substitute (concussion, or otherwise) not named in the
    original XI takes the most wickets, bets on the market will be void.If two or more bowlers have taken the same
    number of wickets, the bowler who has concededthe fewest runs will be the winner. If there are two or more bowlers
    with the same wickets taken and runs conceded, dead heat rules will apply. Wickets taken in a super over don\u2019t
    count.If no bowlers take a wicket in an innings then all bets will be void.</p>
  <p>6.18.18. Man of the MatchDescription: Who will be named man of the match?Rules: Bets will be settled on the
    officially declared man of the match. Dead-heat rules apply. If no man of the match is officially declared then all
    bets will be void.</p>
  <p>6.18.19. Delivery Markets Runs off DeliveryDescription: How many runs will be scored off the specified
    delivery?Rules: The result will be determined by the number of runs added to the team total, off the specified
    delivery.For settlement purposes, all illegal balls count as deliveries. For example, if an over starts with a wide,
    then the first delivery will be settled as 1 and, although there has not been a legal ballbowled, the next ball will
    be deemed as delivery 2 for that over.If a delivery leads to free hit or a free hit is to be re-bowled because of an
    illegal delivery, the runs scored off the additional delivery do not count.All runs, whether off the bat or not are
    included. For example, a wide with three extra runs taken equates to 4 runs in total off that delivery.</p>
  <p>6.18.20. Exact Runs off DeliveryDescription: Exactly how many runs will be scored off the specified delivery?
    Rules: As \u201CRuns off Delivery\u201D.</p>
  <p>6.18.21. Over Markets Runs in OverDescription: How many runs will be scored in the specified over?Rules: The
    specified over must be completed for bets to stand unless settlement has alreadybeen determined. If an innings ends
    during an over then that over will be deemed to be complete unless the innings is ended due to external factors,
    including bad weather, in which case all bets will be void, unless settlement has already been determined.If the
    over does not commence for any reason, all bets will be void.Extras and penalty runs in the particular over count
    towards settlement.</p>
  <p>6.18.22. Boundary in OverDescription: Will there be a boundary scored in the specified over?Rules: As \u201CRuns in
    Over\u201D. Only boundaries scored from the bat (off any delivery \u2013 legal or not) will count as a boundary. Overthrows,
    all run fours and extras do not count as boundaries.</p>
  <p>6.18.23. Wicket in Over Description: Will a wicket fall in the specified over?Rules: As \u201CRuns in Over\u201D.For
    settlement purposes, any wicket will count, including run outs. A batsman retiring hurt does not count as a wicket.
    If a batsman is timed out or retired out then the wicket is deemed to have taken place on the previous ball. Retired
    hurt does not count as a dismissal.</p>
  <p>6.18.24. Over Odd/EvenDescription: Will the number of runs scored in the specified over be odd or even? Rules: As
    \u201CRuns in Over\u201D. Zero will be deemed to be an even number.</p>
  <p>6.18.25. Group Markets Runs in Groups of OversDescription: How many runs will be scored in the specified number of
    overs?Rules: If the specified number of overs are not complete the bet will be void, unless the team is all out,
    declares, reaches their target or settlement of the bet has already been determined.In limited overs matches, bets
    will be void if the total innings is reduced at any stage to less than 80% of the stated maximum overs at the time
    the bet was placed, unless settlement of the bet was already determined before the reduction.</p>
  <p>6.18.26. Wickets in Groups of OversDescription: How many wickets will fall in the specified number of overs?Rules:
    If the specified number of overs are not complete the bet will be void, unless the team is all out, declares,
    reaches their target or settlement of the bet has already been determined.In limited overs matches, bets will be
    void if the total innings is reduced at any stage to less than 80% of the stated maximum overs at the time the bet
    was placed, unless settlement of the bet was already determined.For settlement purposes, if a batsman is timed out
    or retired out then the wicket is deemed to have taken place on the previous ball. Retired hurt does not count as a
    dismissal.</p>
  <p>6.18.27. Runs in SessionDescription: How many runs will be scored in the specified session?Rules: The result is
    determined by the total number of runs scored in the specified session, regardless of which team has scored them.If
    fewer than 20 overs are bowled in a session, bets will be void unless settlement has already been determined.</p>
  <p>6.18.28. Innings Markets Innings RunsDescription: How many runs will a team score in a specified innings?Rules: In
    limited overs matches, bets will be void if it has not been possible to complete at least 80% of the overs scheduled
    to have been bowled at the time the bet was placed due to external factors, including bad weather, unless settlement
    of the bet has already been determined before the reduction. Bets placed on a future innings will remain valid
    regardless of the runs scored in any current or previous innings.In drawn First Class matches, will be void if fewer
    than 200 overs have been bowled, unless settlement of the bet has already been determined. Bets will also be void in
    drawn first class matches, if less than 60 overs have been bowled in an incomplete innings, unless settlement ofthe
    bet has already been determined. If a team declares, that innings will be considered complete for the purposes of
    settlement.</p>
  <p>6.18.29. Innings WicketsDescription: How many wickets will the batting team lose in the current innings?Rules: In
    limited overs matches, bets will be void if it has not been possible to complete at least 80% of the overs scheduled
    to have been bowled at the time the bet was placed due to external factors, including bad weather, unless settlement
    of the bet has already been determined before the reduction.In drawn First Class matches, bets will be void if fewer
    than 200 overs have been bowled, unless settlement of the bet has already been determined.Retired hurt does not
    count as a dismissal.</p>
  <p>6.18.30. Innings FoursDescription: How many fours will the batting team hit in their current innings? Rules: Same
    as Most Fours.</p>
  <p>6.18.31. Innings SixesDescription: How many sixes will the batting team hit in their current innings? Rules: Same
    as Most Sixes.</p>
  <p>6.18.32. Innings ExtrasDescription: How many extras will be added to the named team\u2019s batting innings? Rules: Same
    as Most Extras.</p>
  <p>6.18.33. Innings Run OutsDescription: How many run outs will be conceded in the innings? Rules: Same as Most
    Extras.</p>
  <p>6.18.34. Maximum Over in InningsDescription: How many runs will be scored off the highest scoring over of the
    current innings? Rules: Same as Maximum Over in Match</p>
  <p>6.18.35. Innings Runs, Odd or Even?Description: Will the total innings runs be odd or even?Rules: If the innings is
    abandoned, forfeited or there is no official result, all bets will be void.</p>
  <p>6.18.36. Innings to finish with a BoundaryDescription: Will the last ball of the innings be a boundary?Rules: Only
    boundaries scored from the bat (off any delivery \u2013 legal or not) will count as a boundary. Overthrows, all run fours
    and extras do not count as boundaries.In limited overs matches, bets will be void if there is any reduction in the
    number of overs scheduled to have been bowled at the time the bet was placed due to external factors, including bad
    weather. If the match is abandoned or there is no official result, all bets will be void.</p>
  <p>6.18.37. Exact Runs in InningsDescription: How many runs exactly will the team batting in the final innings score?
    Rules: Bets will be settled according to the official result.In limited overs matches, bets will be void if there is
    any reduction in the number of overs scheduled to have been bowled at the time the bet was placed due to external
    factors, including bad weather.If the match is abandoned or there is no official result, all bets will be void.</p>
  <p>6.18.38. Top Batsman in InningsDescription: Which batsman will score the most runs for the named team?Rules: The
    result of this market is determined on the batsman with the highest individual score in a team\u2019s innings.In limited
    overs matches, bets will be void if it has not been possible to complete at least 50% of the overs scheduled to have
    been bowled at the time the bet was placed due to external factors, including bad weather.Top batsmen bets for First
    Class matches apply only to the first innings of each team, and will be void if fewer than 200 overs have been
    bowled, unless settlement of the bet has already been determined. If a player was named at the toss, but later is
    removed as a concussion sub, thatplayer will still be counted, as will the replacement player.If a batsman does not
    bat, but was named in the starting XI, bets on that batsman will stand.If a substitute (concussion, or otherwise)
    not named in the original XI scores the highest individual score in the team\u2019s innings, bets on the market will be
    void.When two or more players score the same number of runs, in the innings dead-heat rules will apply.Runs scored
    in a super over do not count.</p>
  <p>6.18.39. Top Bowler in InningsDescription: Which bowler will take the most wickets for the named team?Rules: The
    result of this market is determined on the bowler with the highest individual number of wickets in an individual
    innings.In limited overs matches, bets will be void if it has not been possible to complete at least 50% of the
    overs scheduled to have been bowled at the time the bet was placed due to external factors, including bad
    weather.Top bowler bets for First Class matches apply only to the first innings of each team, and will be void if
    fewer than 200 overs have been bowled, unless settlement of the bet has already been determined.If a player was
    named at the toss, but later is removed as a concussion sub, that player will still be counted, as will the
    replacement player.If a bowler does not bowl, but was named in the starting XI, bets on that bowler will stand.If a
    substitute (concussion, or otherwise) not named in the original XI takes the most wickets, bets on the market will
    be void.If two or more bowlers have taken the same number of wickets, the bowler who has concededthe fewest runs
    will be the winner. If there are two or more bowlers with the same wickets taken and runs conceded, dead heat rules
    will apply. Wickets taken in a super over don\u2019t count.If no bowlers take a wicket in an innings then all bets will
    be void.</p>
  <p>6.18.40. Last Man StandingDescription: Which batsman will be not out upon completion of the innings?Rules: If there
    are two or more batsmen who are not out upon completion of the innings, the winner for the purpose of settlement
    will be the last batsman to face a delivery (legal or not).Players will not be deemed to have been not out if they
    were no longer at the crease having retired hurt or did not bat. If more than 11 players bat, the market will be
    void.In limited overs matches, bets will be void if, subsequent to placing the bet, the innings has been reduced in
    any way due to external factors, including bad weather.</p>
  <p>6.18.41. Batsmen Markets Batsman RunsDescription: How many runs will the named batsman score?Rules: If the batsman
    finishes the innings not out, as a result of a declaration, the team reachingthe end of their allotted overs, or the
    team reaching their target; his score will be the final result. If a batsman does not bat, the bet will be void. If
    a batsman is not in the starting XI, bets will be void.If a batsman retires hurt, but returns later, the total runs
    scored by that batsman in the innings will count. If the batsman does not return later, the final result will be as
    it stood when thebatsman retired.In limited overs matches, bets will be void if it has not been possible to complete
    at least 80% of the scheduled overs in either innings due to external factors, including bad weather, unless
    settlement has been determined, or goes on to be determined. Result will be considered determined if the line at
    which the bet was placed is passed, or the batsman is dismissed.In drawn First Class matches, bets will be void if
    fewer than 200 overs are bowled, unless settlement of the bet has already been determined.Runs scored in a super
    over do not count.</p>
  <p>6.18.42. Combined Batsman RunsDescription: How many total runs will the named batsmen score?Rules: As \u201CBatsman
    Runs\u201D, and if any of the named batsmen do not bat, the bet will be void, unless settlement of the bet has already
    been determined or goes on to be determined.</p>
  <p>6.18.43. Batsman FoursDescription: How many fours will the named batsman hit?Rules: If a batsman finishes the
    innings not out, as a result of a declaration, the team reaching the end of their allotted overs, or the team
    reaching their target; his number of fours will be the final result. If a batsman does not bat, the bet will be
    void. If a batsman is not in the starting XI, bets will be void.If a batsman retires hurt, but returns later, the
    total fours hit by that batsman in the innings will count. If the batsman does not return later, the final result
    will be as it stood when the batsman retired.In limited overs matches, bets will be void if it has not been possible
    to complete at least 80% of the scheduled overs in either innings due to external factors, including bad weather,
    unless settlement has been determined, or goes on to be determined. Result will be considered determined if the line
    at which the bet was placed is passed, or the batsman is dismissed.In drawn First Class matches, bets will be void
    if fewer than 200 overs are bowled, unless settlement of the bet has already been determined.Only fours scored from
    the bat (off any delivery \u2013 legal or not) will count towards the total fours. Overthrows, all run fours and extras
    do not count.Fours scored in a super over do not count.</p>
  <p>6.18.44. Batsman SixesDescription: How many sixes will the named batsman hit?Rules: If a batsman finishes the
    innings not out, as a result of a declaration, the team reaching the end of their allotted overs, or the team
    reaching their target; his number of sixes will be the final result. If a batsman does not bat, the bet will be
    void. If a batsman is not in the starting XI, bets will be void.If a batsman retires hurt, but returns later, the
    total sixes hit by that batsman in the innings will count. If the batsman does not return later, the final result
    will be as it stood when the batsman retired.In limited overs matches, bets will be void if it has not been possible
    to complete at least 80% of the scheduled overs in either innings due to external factors, including bad weather,
    unless settlement has been determined, or goes on to be determined. Result will be considered determined if the line
    at which the bet was placed is passed, or the batsman is dismissed.In drawn First Class matches, bets will be void
    if fewer than 200 overs are bowled, unless settlement of the bet has already been determined. Only sixes scored from
    the bat (off any delivery \u2013 legal or not) will count towards the total fours. Overthrows and extras do not
    count.Sixes scored in a super over do not count.</p>
  <p>6.18.45. Batsman MilestonesDescription: Will the named batsman reach the specified milestone?Rules: As \u201CBatsman
    Runs\u201D. Method of Dismissal Description: How will the named batsman be out?Rules: If the specified batsman is not
    out, all bets will be void. If the specified batsman retires, and does not return to bat later, all bets will be
    void. If that batsman does return to bat later and is out, bets will stand.</p>
  <p>6.18.46. Partnership Markets Fall of Next WicketDescription: How many runs will the batting team have scored when
    the next wicket falls?Rules: If the batting team reaches the end of their allotted overs, reaches their target or
    declares before the specified wicket falls, the result will be the total amassed.For settlement purposes, a batsman
    retiring hurt does not count as a wicket.In limited overs matches, bets will be void if it has not been possible to
    complete at least 80% of the scheduled overs in either innings due to external factors, unless settlement has
    already beendetermined, or goes on to be determined. Result will be considered determined if the line at which the
    bet was placed is passed, or the wicket in question falls.In drawn First Class matches, bets will be void if fewer
    than 200 overs have been bowled, unless settlement of the bet has already been determined.</p>
  <p>6.18.47. Next Man OutDescription: Which batsman will be the next to be dismissed?Rules: If either batsman retires
    hurt or the batsmen at the crease are different from those quoted, the bets placed on both batsmen will be declared
    void. If no more wickets fall, all bets will be void.6.18.48, Batsman Match BetDescription: Which batsman in the
    current partnership will score the most runs in this innings?Rules: Bets will settle based on the official scores
    for the specified batsmen in the innings, as detailed in the \u201CBatsman Runs\u201D section above.In limited overs matches,
    bets will be void if it has not been possible to complete at least 80% of the scheduled overs in either innings due
    to external factors, including bad weather, after the bet is placed unless settlement has already been
    determined.Method of Next Wicket DismissalDescription: How will the next batsman be out?Rules: The result will be
    determined by the dismissal method of the next wicket that falls. Abatsman retiring hurt does not count as a wicket.
    If a batsman is retired out, all bets will be void. If the specified wicket does not fall, all bets will be
    void.Player Markets Batsman MatchbetDescription: Which of the named players will score the most runs?Rules: In
    limited overs matches, bets will be void if it has not been possible to complete at least 80% of the scheduled overs
    in either innings due to external factors, including bad weather, unless settlement has been determined.In drawn
    First Class matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet has
    already been determined.Both players must be named in the starting XI, or appear as a substitute. If either does not
    then subsequently bat all bets are still settled.Runs scored in a super over do not count.Bowler
    MatchbetDescription: Which of the named players will take the most wickets?Rules: In limited overs matches, bets
    will be void if it has not been possible to complete at least 80% of the scheduled overs in either innings due to
    external factors, including bad weather, unless settlement has been determined.In drawn First Class matches, bets
    will be void if fewer than 200 overs have been bowled, unless settlement of the bet has already been determined.Both
    players must be named in the starting XI, or appear as a substitute. If either does not then subsequently bowl all
    bets are still settled.Wickets taken in a super over do not count.All-Rounder MatchbetDescription: Which of the
    named players will score the most points in the player performance scoring system?Rules: Points are scored as
    follows: 1 point per run, 20 points per wicket, 10 points per catch, 25 points per stumping.In limited overs
    matches, bets will be void if it has not been possible to complete at least 80% of the scheduled overs in either
    innings due to external factors, including bad weather, unless settlement has been determined.In drawn First Class
    matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet has already been
    determined.Both players must be named in the starting XI, or appear as a substitute. If either player does not then
    subsequently bat or bowl then all bets are still settled.Points scored in a super over do not count.Keeper
    MatchbetDescription: Which of the named wicket keepers score more points in the player performance scoring
    system?Rules: Points are scored as above. In limited overs matches, bets will be void if it has not beenpossible to
    complete at least 80% of the scheduled overs in either innings due to external factors, including bad weather,
    unless settlement has been determined.In drawn First Class matches, bets will be void if fewer than 200 overs have
    been bowled, unless settlement of the bet has already been determined.Both named players must start the match as a
    wicket keeper, or appear as a substitute, but iftheir playing role changes for any reason all bets will still be
    settled in accordance with scoring system above.Points scored in a super over do not count.Pop Up Markets Free
    HitDescription: How many team runs will be scored off the free hit delivery?Rules: The result will be determined by
    the number of runs added to the team total, off the specified delivery. If the free hit is re-bowled because of an
    illegal delivery, the runs scored off the second free hit do not count.Extras and penalty runs will count towards
    settlement.For example, if a wide is bowled on the free hit delivery specified, the result will be 1. Then another
    free hit market may be offered.Race to \u2018X\u2019 RunsDescription: Which batsman will reach the specified number of runs
    first? Rules: All bets stand, regardless of any curtailment.If neither batsman reaches the specified number of runs
    the markets will be settled as \u2018Neither\u2019.Next to Hit SixDescription: Which batsman will hit the next six?Rules: All
    bets stand, regardless of any curtailment. If neither batsman scores a six after the bet is offered, then the market
    will be settled as \u2018Neither\u2019.Overthrows and extras do not count.Next to Take a WicketDescription: Which bowler will
    take the next wicket in this innings?Rules: All bets stand, regardless of any curtailment. If none of the named
    bowlers take a wicket the market will be settled as \u2018None of the above\u2019.For settlement purposes, a batsman retiring
    hurt does not count as a wicket. Run outs, timed out, retired out and any other method of dismissal not awarded to a
    particular bowler will be settled as \u2018None of the above\u2019.Winning OverDescription: In which over of the named team\u2019s
    innings will the match be completed? Rules: All bets will be void if there is no official result.In limited overs
    matches, all bets will be void if, subsequent to placing the bet, the maximum overs possible are reduced in any
    way.One-sided Markets Both Teams to Score \u2018X\u2019 RunsDescription: Will both teams score the specified number of
    runs?Rules: In limited overs matches, bets will be void if it has not been possible to complete at least 80% of the
    overs scheduled to have been bowled in both innings at the time the bet was placed due to external factors,
    including bad weather, unless settlement of the bet has already been determined before the reduction.In drawn First
    Class matches, bets will be void if fewer than 100 overs have been bowled in either teams first innings, unless
    settlement of the bet has already been determined. Only runs scored in the first innings count If a team declares
    that innings will be considered complete for thepurposes of settlement.Either Batsman Method of
    DismissalDescription: Will either of the named batsmen be dismissed in the specified method?Rules: All bets will
    settle, regardless of whether either batsman remains not out, or retired hurt, at the end of the innings.Both
    Batsmen Method of DismissalDescription: Will both of the named batsmen be dismissed in the specified method? Rules:
    As \u201CEither Batsman Method of Dismissal\u201D.Runs off Consecutive DeliveriesDescription: How many runs will be scored off
    each of the specified deliveries?Rules: As \u201CRuns off Delivery\u201D except the specified number of runs must be scored
    off both named deliveries.Wicket off DeliveryDescription: Will a wicket fall in the specified delivery?Rules: The
    specified delivery must be completed for bets to stand.For settlement purposes, any wicket will count, including run
    outs. A batsman retiring hurt does not count as a wicket. If a batsman is timed out or retired out then the wicket
    is deemed to have taken place on the previous ball.Both Batsmen to Score \u2018X\u2019 Runs in OverDescription: Will both
    batsmen score the specified number of runs in the over?Rules: The specified over must be completed for bets to stand
    unless settlement has alreadybeen determined. If an innings ends during an over then that over will be deemed to be
    complete unless the innings is ended due to external factors, including bad weather, in which case all bets will be
    void, unless settlement has already been determined.If the over does not commence for any reason, all bets will be
    void. Runs must be scored off the bat to count towards settlement.Bets will settle regardless of whether or not
    either of the specified batsmen are dismissed or retired hurt before the over commences.Both Batsmen to Score a
    Boundary in OverDescription: Will both batsmen score a boundary in the over?Rules: As \u201CBoth Batsmen to Score \u2018X\u2019
    Runs in Over\u201D. Both fours and sixes count as boundaries. Only fours or sixes scored from the bat (off any delivery \u2013
    legal or not) will count. Overthrows, all run fours and extras do not count.Both a Four and a Six to be Scored in an
    OverDescription: Will both a four and a six be scored in the over?Rules: The specified over must be completed for
    bets to stand unless settlement has alreadybeen determined. If an innings ends during an over then that over will be
    deemed to be complete unless the innings is ended due to external factors, including bad weather, in which case all
    bets will be void, unless settlement has already been determined. If the over does not commence for any reason, all
    bets will be void.Only fours or sixes scored from the bat (off any delivery \u2013 legal or not) will count. Overthrows,
    all run fours and extras do not count.Batsman and Bowler Combo MilestonesDescription: Will the named batsman, and
    the named bowler, reach their specified milestones?Rules: For batsman \u2013 same as \u201CBatsman Runs\u201D. In first class
    games, only runs scored in the first innings will count. If a batsman is not in the starting XI, or substituted in,
    bets will be void.For bowler \u2013 if a bowler does not bowl, they will be deemed to have taken 0 wickets. If a bowler
    is not in the starting XI, or substituted in, bets will be void. In limited overs matches, bets will be void if it
    has not been possible to complete at least 80% of the scheduled overs in the relevant innings due to external
    factors, including bad weather, unless settlement has been determined.In drawn First Class matches, bets will be
    void if fewer than 200 overs have been bowled, unless the player\u2019s bowling innings is complete. The result will be
    considered determined if the lines at which the bet was placed are passed. In First Class games, only first innings
    wickets will count and runs. Wickets and runs scored in a super over do not count.Batsmen Combo
    MilestonesDescription: Will both the batsmen reach their specified milestones? Rules: Same as \u201CCombined Batsman
    Runs\u201D.Notes for all MarketsPlayers sent off/retired out A player being sent off is viewed as retired out, so will be
    settled as a wicket.Concussion substitutions When a player leaves the field as a concussion substitute, this will
    not count as a wicket. If the player does not return later, the final result will be as it stood when the player
    left the field. When a player enters the match as a concussion substitute, for settlementpurposes both they and the
    player replaced will be looked upon as to have played a full part in the match.Penalty runs after the conclusion of
    an innings Penalty runs added to a team\u2019s total after the start of the other team\u2019s innings will not count towards
    settlement of markets in the previous innings.Player PerformancesDescription: choose whether a player will score
    more or less than a certain score - based on Fantasy-style points.Rules: Players score 1 point per run, 20 points
    per wicket, 10 points per catch, and 25 points per stumping.</p>
  <p>6.18.49. Method of Next Wicket DismissalDescription: How will the next batsman be out?Rules: The result will be
    determined by the dismissal method of the next wicket that falls. Abatsman retiring hurt does not count as a wicket.
    If a batsman is retired out, all bets will be void. If the specified wicket does not fall, all bets will be void.
  </p>
  <p>6.18.50. Player Markets Batsman MatchbetDescription: Which of the named players will score the most runs?Rules: In
    limited overs matches, bets will be void if it has not been possible to complete at least 80% of the scheduled overs
    in either innings due to external factors, including bad weather, unless settlement has been determined.In drawn
    First Class matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet has
    already been determined.Both players must be named in the starting XI, or appear as a substitute. If either does not
    then subsequently bat all bets are still settled.Runs scored in a super over do not count.</p>
  <p>6.18.51. Bowler MatchbetDescription: Which of the named players will take the most wickets?Rules: In limited overs
    matches, bets will be void if it has not been possible to complete at least 80% of the scheduled overs in either
    innings due to external factors, including bad weather, unless settlement has been determined.In drawn First Class
    matches, bets will be void if fewer than 200 overs have been bowled, unless settlement of the bet has already been
    determined.Both players must be named in the starting XI, or appear as a substitute. If either does not then
    subsequently bowl all bets are still settled.Wickets taken in a super over do not count.</p>
  <p>6.18.52. All-Rounder MatchbetDescription: Which of the named players will score the most points in the player
    performance scoring system?Rules: Points are scored as follows: 1 point per run, 20 points per wicket, 10 points per
    catch, 25 points per stumping.In limited overs matches, bets will be void if it has not been possible to complete at
    least 80% of the scheduled overs in either innings due to external factors, including bad weather, unless settlement
    has been determined.In drawn First Class matches, bets will be void if fewer than 200 overs have been bowled, unless
    settlement of the bet has already been determined.Both players must be named in the starting XI, or appear as a
    substitute. If either player does not then subsequently bat or bowl then all bets are still settled.Points scored in
    a super over do not count.</p>
  <p>6.18.53. Keeper MatchbetDescription: Which of the named wicket keepers score more points in the player performance
    scoring system?Rules: Points are scored as above. In limited overs matches, bets will be void if it has not
    beenpossible to complete at least 80% of the scheduled overs in either innings due to external factors, including
    bad weather, unless settlement has been determined.In drawn First Class matches, bets will be void if fewer than 200
    overs have been bowled, unless settlement of the bet has already been determined.Both named players must start the
    match as a wicket keeper, or appear as a substitute, but iftheir playing role changes for any reason all bets will
    still be settled in accordance with scoring system above.Points scored in a super over do not count.</p>
  <p>6.18.54. Pop Up Markets Free HitDescription: How many team runs will be scored off the free hit delivery?Rules: The
    result will be determined by the number of runs added to the team total, off the specified delivery. If the free hit
    is re-bowled because of an illegal delivery, the runs scored off the second free hit do not count.Extras and penalty
    runs will count towards settlement.For example, if a wide is bowled on the free hit delivery specified, the result
    will be 1. Then another free hit market may be offered.</p>
  <p>6.18.55. Race to \u2018X\u2019 RunsDescription: Which batsman will reach the specified number of runs first? Rules: All bets
    stand, regardless of any curtailment.If neither batsman reaches the specified number of runs the markets will be
    settled as \u2018Neither\u2019.</p>
  <p>6.18.56. Next to Hit SixDescription: Which batsman will hit the next six?Rules: All bets stand, regardless of any
    curtailment. If neither batsman scores a six after the bet is offered, then the market will be settled as
    \u2018Neither\u2019.Overthrows and extras do not count.</p>
  <p>6.18.57. Next to Take a WicketDescription: Which bowler will take the next wicket in this innings?Rules: All bets
    stand, regardless of any curtailment. If none of the named bowlers take a wicket the market will be settled as \u2018None
    of the above\u2019.For settlement purposes, a batsman retiring hurt does not count as a wicket. Run outs, timed out,
    retired out and any other method of dismissal not awarded to a particular bowler will be settled as \u2018None of the
    above\u2019.</p>
  <p>6.18.58. Winning OverDescription: In which over of the named team\u2019s innings will the match be completed? Rules: All
    bets will be void if there is no official result.In limited overs matches, all bets will be void if, subsequent to
    placing the bet, the maximum overs possible are reduced in any way.</p>
  <p>6.18.59. One-sided Markets Both Teams to Score \u2018X\u2019 RunsDescription: Will both teams score the specified number of
    runs?Rules: In limited overs matches, bets will be void if it has not been possible to complete at least 80% of the
    overs scheduled to have been bowled in both innings at the time the bet was placed due to external factors,
    including bad weather, unless settlement of the bet has already been determined before the reduction.In drawn First
    Class matches, bets will be void if fewer than 100 overs have been bowled in either teams first innings, unless
    settlement of the bet has already been determined. Only runs scored in the first innings count If a team declares
    that innings will be considered complete for thepurposes of settlement.</p>
  <p>6.18.60. Either Batsman Method of DismissalDescription: Will either of the named batsmen be dismissed in the
    specified method?Rules: All bets will settle, regardless of whether either batsman remains not out, or retired hurt,
    at the end of the innings.</p>
  <p>6.18.61. Both Batsmen Method of DismissalDescription: Will both of the named batsmen be dismissed in the specified
    method? Rules: As \u201CEither Batsman Method of Dismissal\u201D.</p>
  <p>6.18.62. Runs off Consecutive DeliveriesDescription: How many runs will be scored off each of the specified
    deliveries?Rules: As \u201CRuns off Delivery\u201D except the specified number of runs must be scored off both named
    deliveries.</p>
  <p>6.18.63. Wicket off DeliveryDescription: Will a wicket fall in the specified delivery?Rules: The specified delivery
    must be completed for bets to stand.For settlement purposes, any wicket will count, including run outs. A batsman
    retiring hurt does not count as a wicket. If a batsman is timed out or retired out then the wicket is deemed to have
    taken place on the previous ball.</p>
  <p>6.18.64. Both Batsmen to Score \u2018X\u2019 Runs in OverDescription: Will both batsmen score the specified number of runs in
    the over?Rules: The specified over must be completed for bets to stand unless settlement has alreadybeen determined.
    If an innings ends during an over then that over will be deemed to be complete unless the innings is ended due to
    external factors, including bad weather, in which case all bets will be void, unless settlement has already been
    determined.If the over does not commence for any reason, all bets will be void. Runs must be scored off the bat to
    count towards settlement.Bets will settle regardless of whether or not either of the specified batsmen are dismissed
    or retired hurt before the over commences.</p>
  <p>6.18.65. Both Batsmen to Score a Boundary in OverDescription: Will both batsmen score a boundary in the over?Rules:
    As \u201CBoth Batsmen to Score \u2018X\u2019 Runs in Over\u201D. Both fours and sixes count as boundaries. Only fours or sixes scored
    from the bat (off any delivery \u2013 legal or not) will count. Overthrows, all run fours and extras do not count.</p>
  <p>6.18.66. Both a Four and a Six to be Scored in an OverDescription: Will both a four and a six be scored in the
    over?Rules: The specified over must be completed for bets to stand unless settlement has alreadybeen determined. If
    an innings ends during an over then that over will be deemed to be complete unless the innings is ended due to
    external factors, including bad weather, in which case all bets will be void, unless settlement has already been
    determined. If the over does not commence for any reason, all bets will be void.Only fours or sixes scored from the
    bat (off any delivery \u2013 legal or not) will count. Overthrows, all run fours and extras do not count.</p>
  <p>6.18.67. Batsman and Bowler Combo MilestonesDescription: Will the named batsman, and the named bowler, reach their
    specified milestones?Rules: For batsman \u2013 same as \u201CBatsman Runs\u201D. In first class games, only runs scored in the
    first innings will count. If a batsman is not in the starting XI, or substituted in, bets will be void.For bowler \u2013
    if a bowler does not bowl, they will be deemed to have taken 0 wickets. If a bowler is not in the starting XI, or
    substituted in, bets will be void. In limited overs matches, bets will be void if it has not been possible to
    complete at least 80% of the scheduled overs in the relevant innings due to external factors, including bad weather,
    unless settlement has been determined.In drawn First Class matches, bets will be void if fewer than 200 overs have
    been bowled, unless the player\u2019s bowling innings is complete. The result will be considered determined if the lines
    at which the bet was placed are passed. In First Class games, only first innings wickets will count and runs.
    Wickets and runs scored in a super over do not count.</p>
  <p>6.18.68. Batsmen Combo MilestonesDescription: Will both the batsmen reach their specified milestones? Rules: Same
    as \u201CCombined Batsman Runs\u201D.</p>
  <p>6.18.69. Notes for all MarketsPlayers sent off/retired out A player being sent off is viewed as retired out, so
    will be settled as a wicket.Concussion substitutions When a player leaves the field as a concussion substitute, this
    will not count as a wicket. If the player does not return later, the final result will be as it stood when the
    player left the field. When a player enters the match as a concussion substitute, for settlementpurposes both they
    and the player replaced will be looked upon as to have played a full part in the match.Penalty runs after the
    conclusion of an innings Penalty runs added to a team\u2019s total after the start of the other team\u2019s innings will not
    count towards settlement of markets in the previous innings.</p>
  <p>6.18.70. Player Performances</p>
  <p>6.19. Squash</p>
  <p>6.19.1. If a set ends before the Xth point is reached, this market (Who scores [Xth] point in set [y]) is
    considered void (cancelled)</p>
  <p>6.19.2. If markets remain open with an incorrect score which has a significant impact on the prices, we reserve the
    right to void betting.</p>
  <p>6.19.3. If the players/teams are displayed incorrectly, we reserve the right to void betting.</p>
  <p>6.19.4. If a player retires, forfeits the match or is disqualified all undecided markets are considered void</p>
  <p>6.19.5. Official points deductions will be taken into account for all undetermined markets. Markets which have
    already been determined will not take deductions into account.</p>
  <p>6.19.6. If penalty point(s) are awarded by the umpire, all bets on that game will stand.</p>
  <p>6.20. Aussie Rules</p>
  <p>6.20.1. All markets exclude overtime unless otherwise stated</p>
  <p>6.20.2. Regular 80 Minutes: Markets are based on the result at the end of a scheduled 80 minutes play unless
    otherwise stated. This includes any added injury or stoppage time but does not include extra-time.</p>
  <p>6.20.3. If odds were offered with an incorrect match time (more than 2 minutes), we reserve the right to void
    betting.</p>
  <p>6.20.4. If the team names or category are displayed incorrectly, we reserve the right to void betting</p>
  <p>6.21. Counter-Strike: Global Offensive</p>
  <p>6.21.1. If no bomb is planted, market ([mapNr!] Map [roundNr!] Round - Bomb defused) will be considered void</p>
  <p>6.21.2. Markets do not consider overtime unless otherwise stated.</p>
  <p>6.21.3. Markets will be settled based on officially published results.</p>
  <p>6.21.4. If the fixture is listed incorrectly, we reserve the right to void betting.</p>
  <p>6.21.5. In case of a walkover or retirement, all undecided markets are void.</p>
  <p>6.21.6. If a match or map is replayed due to a disconnection, or technical issues which are not player-related, all
    undecided markets will be void. The replayed match or map will be handled separately.</p>
  <p>6.21.7. If the standard number of maps is changed or differs from those offered for betting purposes, we reserve
    the right to void betting.</p>
  <p>6.22. Dota 2</p>
  <p>6.22.1. Xth map \u2013 1st aegis: Settlement is determined by the team which picks up the Aegis of the Immortal, and not
    who slays Roshan</p>
  <p>6.22.2. Xth map \u2013 1st tower and Xth map \u2013 1st barracks: For settlement purposes every method of tower destruction
    will be taken into account (Opponent & Creep destroy; destroy by Deny)</p>
  <p>6.22.3. Markets will be settled based on officially published results.</p>
  <p>6.22.4. If the fixture is listed incorrectly, we reserve the right to void betting.</p>
  <p>6.22.5. In case of a walkover or retirement, all undecided markets are void.</p>
  <p>6.22.6. If a match or map is replayed due to a disconnection, or technical issues which are not player-related, all
    undecided markets will be void. The replayed match or map will be handled separately.</p>
  <p>6.22.7. If the standard number of maps is changed or differs from those offered for betting purposes, we reserve
    the right to void betting.</p>
  <p>6.23. League of Legends</p>
  <p>6.23.1. Xth map \u2013 1st inhibitor and Xth map \u2013 1st tower: For settlement purposes every method of destruction will
    be taken into account</p>
  <p>6.23.2. Markets do not consider overtime unless otherwise stated.</p>
  <p>6.23.3. Markets will be settled based on officially published results.</p>
  <p>6.23.4. If the fixture is listed incorrectly, we reserve the right to void betting.</p>
  <p>6.23.5. In case of a walkover or retirement, all undecided markets are void.</p>
  <p>6.23.6. If a match or map is replayed due to a disconnection, or technical issues which are not player-related, all
    undecided markets will be void. The replayed match or map will be handled separately.</p>
  <p>6.23.7. If the standard number of maps is changed or differs from those offered for betting purposes, we reserve
    the right to void betting.</p>
  <p>6.24. eSports FIFA</p>
  <p>6.24.1. eSports Battle match duration - 2x4 minutes.</p>
  <p>6.24.2. Liga Pro EFootball match duration - 2x6 minutes.</p>
  <p>6.24.3. All Markets will be settled as set out in the General and Soccer Market Rules.</p>
  <p>6.25. eSports NBA2K</p>
  <p>6.25.1. Match duration \u2013 4x5 minutes. This includes overtime.</p>
  <p>6.25.2. All Markets will be settled as set out in the General and Basketball Market Rules.</p>
  <p>6.26. Formula1</p>
  <p>6.26.1. All race bets are settled on the official FIA classification at the time of the podium presentation, with
    subsequent disqualifications/penalties disregarded.</p>
  <p>6.26.2. All drivers who complete 90% of the race laps are deemed as classified finishers in line with the official
    FIA classification. However all drivers are given a ranking, and for the purpose of head to headl betting this
    ranking shall apply.</p>
</section>

<section>
  <h2>7. Virtual Sports</h2>
  <p>7.1. Virtual Football</p>
  <p>7.1.1. The Virtual Football Modes provide 24/7/365 real money betting experience on virtual football. Competitions
    are generated continuously and bets can be placed at any time, even within a season.</p>
  <p>7.1.2. Game structureEach mode has a different tournament structure: Virtual Football League Mode VFLM:16 TeamsHome
    & away matches30 match days8 concurrent matches per match day240 matches per season Group Stage Virtual Football
    World Cup VFWC:32 Teams (8 groups of 4 teams per group)12 match day chunks (3 match days of 4 chunks per match day)4
    concurrent matches per match day chunk48 matches per group stageKnock-Out-Stage16 Teams5 round (R16[1..4];
    R16[5...8]; R8; Semi Finals; Final & 3rd Place)4 concurrent matches (R16[1..4]; R16[5...8]; R8);2 concurrent matches
    (Semi Finals; Final & 3rd Place)16 matches per knock-out-stage.</p>
  <p>\u25CF 16 Teams</p>
  <p>\u25CF Home & away matches</p>
  <p>\u25CF 30 match days</p>
  <p>\u25CF 8 concurrent matches per match day</p>
  <p>\u25CF 240 matches per season Group Stage Virtual Football World Cup VFWC:</p>
  <p>\u25CF 32 Teams (8 groups of 4 teams per group)</p>
  <p>\u25CF 12 match day chunks (3 match days of 4 chunks per match day)</p>
  <p>\u25CF 4 concurrent matches per match day chunk</p>
  <p>\u25CF 48 matches per group stage</p>
  <p>\u25CF Knock-Out-Stage</p>
  <p>\u25CF 16 Teams</p>
  <p>\u25CF 5 round (R16[1..4]; R16[5...8]; R8; Semi Finals; Final & 3rd Place)</p>
  <p>\u25CF 4 concurrent matches (R16[1..4]; R16[5...8]; R8);</p>
  <p>\u25CF 2 concurrent matches (Semi Finals; Final & 3rd Place)</p>
  <p>\u25CF 16 matches per knock-out-stage.</p>
  <p>7.2. Virtual Basketball</p>
  <p>7.2.1. The VBL provides 24/7/365 real money betting experience on virtual basketball. The league consists of 16
    teams and seasons run continuously. Each season comprises 30 match days (home and away matches). Bets can be placed
    at any time \u2013 even within a season.</p>
  <p>7.2.2. Season Details.For the online version one season lasts 106:30 minutes in total, separated into a
    \u2018Pre-League\u2019 period, a \u2018Match day Loop\u2019, and a \u2018Post league\u2019 period. The \u2018Pre-League\u2019 period runs prior to thestart
    of a season and lasts 60 seconds. All match days are summarized as the \u2018Match day Loop\u2019 period with a total duration
    of 105:00 minutes. At the end of every season there is a 30 second \u2018Post Season\u2019 period.</p>
  <p>7.2.3. Betting on a VBL match is allowed up to 10 seconds before tip-off. Betting markets forfuture match days of
    the current season remain open. When a future match day from the \u2018Match Day\u2019 bar at the bottom is selected, the
    matches related to that day along with the odds will be displayed in the lower odds section.</p>
  <p>7.3. Virtual horses.</p>
  <p>7.3.1. The VHK provides 24/7/365 real money betting experience on virtual horse races. Bets can be placed up to 10
    seconds prior to the start of the next upcoming race as well as on all future races of the current race days at any
    time.</p>
  <p>7.3.2. Races are generated continuously - a new one will be started as soon as the current one has finished.
    Betting is possible in the next 10 upcoming races.:2 minutes total event cycle40 seconds betting phase,65 seconds
    event phase,15 seconds results phase2 grass and 1 dirt track with a 1000m race randomly scheduled8, 10, 12, 14
    runners randomly assigned</p>
  <p>\u25CF 2 minutes total event cycle</p>
  <p>\u25CF 40 seconds betting phase,</p>
  <p>\u25CF 65 seconds event phase,</p>
  <p>\u25CF 15 seconds results phase</p>
  <p>\u25CF 2 grass and 1 dirt track with a 1000m race randomly scheduled</p>
  <p>\u25CF 8, 10, 12, 14 runners randomly assigned</p>
  <p>7.3.3. MarketsWin - select the runner which will finish firstPlace - select the runner which will finish either
    1st, and 2nd (6-7 Runners), select the runner which will finish either 1st, 2nd and 3rd (7+ runners)Forecast
    (Correct Order) - select the runners that will finish 1st and 2nd in the correct order (exacta)Forecast (Any Order)
    - select the runners that will finish 1st and 2nd in any order (quinella)Tricast (Correct Order) - select the
    runners that will finish 1st, 2nd and 3rd in the correct order (trifecta)Tricast (Any Order) - select the runners
    that will finish 1st, 2nd and 3rd in any order (trio)</p>
  <p>\u25CF Win - select the runner which will finish first</p>
  <p>\u25CF Place - select the runner which will finish either 1st, and 2nd (6-7 Runners), select the runner which will
    finish either 1st, 2nd and 3rd (7+ runners)</p>
  <p>\u25CF Forecast (Correct Order) - select the runners that will finish 1st and 2nd in the correct order (exacta)</p>
  <p>\u25CF Forecast (Any Order) - select the runners that will finish 1st and 2nd in any order (quinella)</p>
  <p>\u25CF Tricast (Correct Order) - select the runners that will finish 1st, 2nd and 3rd in the correct order (trifecta)
  </p>
  <p>\u25CF Tricast (Any Order) - select the runners that will finish 1st, 2nd and 3rd in any order (trio)</p>
  <p>7.4. Virtual Dogs</p>
  <p>7.4.1. The VDK provides 24/7/365 real money betting experience on virtual dog races. Bets can be placed up to 10
    seconds prior to the start of the next upcoming race as well as on the tenfuture races at any time.</p>
  <p>7.4.2. Game information. Races are generated continuously - a new one will be started as soon as the current one
    has finished.2 minute total event cycle37 seconds or 67 seconds betting phase,38 seconds or 68 seconds event
    phase,15 seconds results phasenight and day track with distance 360m and 720m randomly scheduled6 or 8 runners
    randomly assigned</p>
  <p>\u25CF 2 minute total event cycle</p>
  <p>\u25CF 37 seconds or 67 seconds betting phase,</p>
  <p>\u25CF 38 seconds or 68 seconds event phase,</p>
  <p>\u25CF 15 seconds results phase</p>
  <p>\u25CF night and day track with distance 360m and 720m randomly scheduled</p>
  <p>\u25CF 6 or 8 runners randomly assigned</p>
  <p>7.4.3. MarketsWin - select the runner which will finish firstPlace - select the runner which will finish either
    1st, and 2nd (6-7 Runners), select the runner which will finish either 1st, 2nd and 3rd (7+ runners)Forecast
    (Correct Order) - select the runners that will finish 1st and 2nd in the correct order (exacta)Forecast (Any Order)
    - select the runners that will finish 1st and 2nd in any order (quinella)Tricast (Correct Order) - select the
    runners that will finish 1st, 2nd and 3rd in the correct order (trifecta)Tricast (Any Order) - select the runners
    that will finish 1st, 2nd and 3rd in any order (trio)</p>
  <p>\u25CF Win - select the runner which will finish first</p>
  <p>\u25CF Place - select the runner which will finish either 1st, and 2nd (6-7 Runners), select the runner which will
    finish either 1st, 2nd and 3rd (7+ runners)</p>
  <p>\u25CF Forecast (Correct Order) - select the runners that will finish 1st and 2nd in the correct order (exacta)</p>
  <p>\u25CF Forecast (Any Order) - select the runners that will finish 1st and 2nd in any order (quinella)</p>
  <p>\u25CF Tricast (Correct Order) - select the runners that will finish 1st, 2nd and 3rd in the correct order (trifecta)
  </p>
  <p>\u25CF Tricast (Any Order) - select the runners that will finish 1st, 2nd and 3rd in any order (trio)</p>
</section>

<section>
  <h2>8. Bonuses</h2>
  <p>8.1. Comboboost</p>
  <p>
    <table class="ui-table is-stripe">
      <thead>
        <tr>
          <th>Multiplier</th>
          <th>Selections</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>2</td>
          <td>1.01</td>
        </tr>
        <tr>
          <td>3</td>
          <td>1.02</td>
        </tr>
        <tr>
          <td>4</td>
          <td>1.04</td>
        </tr>
        <tr>
          <td>5</td>
          <td>1.05</td>
        </tr>
        <tr>
          <td>6</td>
          <td>1.07</td>
        </tr>
        <tr>
          <td>7</td>
          <td>1.1</td>
        </tr>
        <tr>
          <td>8</td>
          <td>1.15</td>
        </tr>
        <tr>
          <td>9</td>
          <td>1.17</td>
        </tr>
        <tr>
          <td>10</td>
          <td>1.2</td>
        </tr>
        <tr>
          <td>11</td>
          <td>1.25</td>
        </tr>
        <tr>
          <td>12</td>
          <td>1.3</td>
        </tr>
        <tr>
          <td>13</td>
          <td>1.35</td>
        </tr>
        <tr>
          <td>14</td>
          <td>1.4</td>
        </tr>
        <tr>
          <td>15</td>
          <td>1.45</td>
        </tr>
        <tr>
          <td>16</td>
          <td>1.5</td>
        </tr>
        <tr>
          <td>17</td>
          <td>1.65</td>
        </tr>
        <tr>
          <td>18</td>
          <td>1.75</td>
        </tr>
        <tr>
          <td>19</td>
          <td>1.85</td>
        </tr>
        <tr>
          <td>20</td>
          <td>2</td>
        </tr>
      </tbody>
    </table>
  </p>
  <p>8.1.2 The final bonus amount calculation is based on the final odds of the Combo once all outcomes are settled.</p>
  <p>8.1.3 Cashed Out
    bets are not eligible to have a Combo boost.</p>
  <p>8.1.4 Operator
    reserves the right to amend, cancel, reclaim or refuse any promotion at its own discretion.</p>
  <p>8.1.5 Combo boost is only
    available on selections with odds of 1.50 or above.</p>
  <p>8.2 Bet refund, freemoney, no risk
    bet.</p>
  <p>8.2.1 Bet
    refund - player get just a winning part of the bet. For example, freebet5 on odd 3.5 player get on
    account 5*3.5 - 5 = 12.5</p>
  <p>8.2.2 Freemoney -
    player gets a stake and winning a part on the account. For example, freebet 5 on the odd 3.5 the player
    get on account 5*3.5 = 17.50</p>
  <p>8.2.3 No risk bet
    - usual bet, but if player loses he get back his money on account</p>
  <p><table class="ui-table is-stripe">
    <thead>
      <tr>
        <th>Type of Freebet</th>
        <th>Refund or Voided</th>
        <th>Half Lost</th>
        <th>Half Win</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Bet refund</td>
        <td>count as a lost bet</td>
        <td>count as a lost bet</td>
        <td>
          as a usual bet, but without the stake
          <div>(2.5*3.5+2.5*1)-5=6.25</div>
        </td>
      </tr>
      <tr>
        <td>Free Money</td>
        <td>the player gets stake amount on his account</td>
        <td>as a usual bet</td>
        <td>as a usual bet</td>
      </tr>
      <tr>
        <td>No Risk Bet</td>
        <td>as a usual bet</td>
        <td>the player gets stake amount on his account</td>
        <td>as a usual bet</td>
      </tr>
    </tbody>
  </table></p>
</section>

<section>
  <h2>9. Betby Games Rules</h2>
  <p>9.1. General Rules.</p>
  <p>9.1.1. Sportsbook platform reserves the right to cancel any bet made on obviously \u201Cbad\u201D odds, switched odds or a
    bet made after an event has started or match was affected by obvioustechnical problems.</p>
  <p>9.1.2. All bets will be settled, when outcome of the market is decided.</p>
  <p>9.2. FIFA</p>
  <p>9.2.1. Match duration \u2013 2x6 minutes. This includes injury time but does not include extra time or penalty
    shootouts.</p>
  <p>9.2.2. All Markets will be settled as set out in the General Market Rules.</p>
  <p>9.3. NBA 2K</p>
  <p>9.3.1. Match duration \u2013 4x6 minutes. This includes overtime.</p>
  <p>9.3.2. All Markets will be settled as set out in the General and Basketball Market Rules.</p>
  <p>9.4. eTennis</p>
  <p>9.4.1. The winner of match is the first player to win 2 sets.</p>
  <p>9.4.2. Player must win 3 games to win a set. If the score is tied at 2-2, then a player can win 4-2, or if players
    are still tied at 3-3 then the set is decided by a tie-break.</p>
  <p>9.4.3. The winner of tie-break is the first player to win 5 points with minimum 2 points difference. If the score
    is tied at 5-5, the player can win 7-5, 8-6, 9-7, etc.</p>
  <p>9.5. Rocket League</p>
  <p>9.5.1. Match duration \u2013 5 minutes. This doesn\u2019t include overtime.</p>
  <p>9.5.2. All Markets will be settled as set out in the General Market Rules.</p>
  <p>9.6. eFighting</p>
  <p>9.6.1. The winner of the match is the character, who wins the fight.</p>
  <p>9.6.2. Explanation of eFighting market terms.Health Bar - Each character has 2 Health Bars. The second bar is
    active only after the first is completely spent.First damage \u2013 first successful attack.Clash \u2013 Situation in the
    fight, when both characters challenge each other in special occasions. to increase hit points. Both fighters can win
    the clash, but there can also be draw.Supermove \u2013 Special move for each character, that occurs very rarely.</p>
  <p>9.6.3. All markets will be settled according to the definitions above.</p>
  <p>9.7. eCricket</p>
  <p>9.7.1. Match consists of two innings - one for each team.</p>
  <p>9.7.2. Each inning consists of five overs with 6 deliveries of each.</p>
  <p>9.7.3. All Markets will be settled as set out in the Cricket Market Rules.</p>
</section>`,
    t = `<section>\r
  <h2>1.Introdu\xE7\xE3o</h2>\r
  <p>1.1 Este conjunto de termos e condi\xE7\xF5es rege o uso da plataforma de apostas esportivas. Ao fazer uma aposta com a plataforma Sportsbook, o Titular da Conta concorda, portanto, que o Titular da Conta leu, entendeu e estar\xE1 aderindo a estes Termos e Condi\xE7\xF5es, incluindo os Termos e Condi\xE7\xF5es gerais aplic\xE1veis a qualquer momento \xE0 plataforma Sportsbook, clique em  .</p>\r
  <p>1.2A utiliza\xE7\xE3o desta plataforma de Sportsbook est\xE1 sujeita aos regulamentos impostos pelo <b style="color: var(--title-color);">(Cura\xE7ao license.)</b>.</p>\r
  <p>1.3Qualquer disputa relacionada de alguma forma ao uso desta plataforma de apostas esportivas deve ser enviada por e-mail para <b style="color: var(--title-color);">(support@bc.game)</b>. Caso a resposta n\xE3o seja considerada satisfat\xF3ria, um pedido de arbitragem confidencial pode ser enviado ao <b style="color: var(--title-color);">(info@curacaolicensing.com)</b>. A sua decis\xE3o ser\xE1 vinculativa e poder\xE1 ser proferida como senten\xE7a em qualquer tribunal de jurisdi\xE7\xE3o competente.</p>\r
  <p>1.4 A plataforma de apostas esportivas se reserva o direito de fazer altera\xE7\xF5es no site, limites de apostas, limites de pagamento e ofertas.</p>\r
   <p>1.5 A plataforma Sportsbook pode atualizar, alterar, editar e complementar estes Termos e Condi\xE7\xF5es a qualquer momento.</p>\r
  <p>1.6 Qualquer refer\xEAncia nestes Termos e Condi\xE7\xF5es a palavras/objetos que aparecem no singular tamb\xE9m se aplica ao plural. As refer\xEAncias ao g\xEAnero n\xE3o s\xE3o vinculativas e devem ser tratadas apenas para fins informativos.</p>\r
</section>\r
\r
<section>\r
  <h2>2. Defini\xE7\xE3o</h2>\r
  <p>2.1 Plataforma de apostas esportivas \u2013 pessoa jur\xEDdica envolvida em atividades de apostas de acordo com os requisitos de licenciamento e legisla\xE7\xE3o do pa\xEDs.</p>\r
  <p>2.2 Cliente - um indiv\xEDduo que concordou com as Regras para aceitar apostas, registrado no site<b style="color: var(--title-color);">(https://BC.GAME/) </b>(e outras vers\xF5es de subdom\xEDnio do site).</p>\r
  <p>2.3 Aposta \u2013 acordo baseado em risco conclu\xEDdo entre o Cliente e a Empresa de Apostas sobre o resultado de um evento\r
    em que n\xE3o participam, envolvendo uma vit\xF3ria. As apostas s\xE3o feitas nos termos previamente propostos pelo\r
  Plataforma de apostas esportivas.</p>\r
  <p>2.4 Stake - a quantidade de dinheiro transferida pelo cliente para a plataforma Sportsbook e quais s\xE3o os principais\r
  condi\xE7\xE3o para participa\xE7\xE3o em uma aposta de acordo com estas Regras.</p>\r
  <p>2.5 O resultado \xE9 o resultado do evento no qual a plataforma Sportsbook \xE9 convidada a fazer uma aposta.</p>\r
  <p>2.6 \xCDmpar \u2014 o n\xFAmero pelo qual o valor da aposta da parte interessada \xE9 multiplicado ao determinar o valor do pagamento se a aposta vencer.</p>\r
  <p>2.7 Ganhos - dinheiro a ser pago ao Cliente no resultado, no qual uma aposta foi feita.</p>\r
  <p>2.8 B\xF4nus:</p>\r
  <p>2.81 Reembolso da aposta - reembolso da aposta, o cliente recebe o valor que acabou de ganhar em sua conta. Por exemplo, aposta gr\xE1tis 5 no cliente \xEDmpar de 3,5 recebe 5*3,5 - 5 = 12,50</p>\r
  <p>2.82 Dinheiro gr\xE1tis - o cliente recebe o valor da aposta e ganha em sua conta. Por exemplo, aposta gr\xE1tis 5 no cliente \xEDmpar de 3,5 recebe 5*3,5 = 18,50</p>\r
  <p>2.83 Aposta sem risco - o jogador usa seu dinheiro para apostar, mas se a aposta perder, ele recebe seu dinheiro de volta.</p>\r
</section>\r
\r
\r
<section>\r
 <h2>3. Regras de apostas</h2>\r
  <p>3.1 A plataforma de apostas esportivas se reserva o direito de cancelar qualquer aposta feita com probabilidades obviamente \u201Cruins\u201D, probabilidades trocadas ou uma aposta feita ap\xF3s o in\xEDcio de um evento.</p>\r
  <p>3.2 Todas as apostas aceitas pela plataforma Sportsbook est\xE3o sujeitas a estas regras, bem como \xE0s condi\xE7\xF5es de licen\xE7a aplic\xE1veis.</p>\r
  <p>3.3 A plataforma Sportsbook reserva-se o direito de recusar, restringir, cancelar ou limitar qualquer aposta.</p>\r
  <p>3.4 A plataforma de apostas esportivas se reserva o direito de resolver ap\xF3s a finaliza\xE7\xE3o do concurso ou com resultados oficiais</p>\r
  <p>3.5 O vencedor de um evento ser\xE1 determinado na data de conclus\xE3o do evento. A plataforma de apostas esportivas faz\r
    n\xE3o reconhece decis\xF5es protestadas ou anuladas para fins de apostas. A liquida\xE7\xE3o de um evento suspenso\r
    ap\xF3s o in\xEDcio da competi\xE7\xE3o ser\xE1 decidido de acordo com as regras de apostas especificadas para esse esporte\r
    pela plataforma Sportsbook</p>\r
  <p>3.6 Ningu\xE9m com menos de 18 anos tem permiss\xE3o para fazer uma aposta.</p>\r
  <p>3.7 Todas as regras aqui contidas est\xE3o sujeitas a altera\xE7\xF5es e revis\xF5es pela plataforma Sportsbook sem aviso pr\xE9vio por escrito.\r
    Todas as altera\xE7\xF5es e revis\xF5es das nossas regras ser\xE3o publicadas no site da plataforma Sportsbook.</p>\r
  <p>3.8 Os valores m\xE1ximos de aposta em todos os eventos esportivos ser\xE3o determinados pela plataforma Sportsbook e est\xE3o sujeitos a altera\xE7\xF5es sem\r
    aviso pr\xE9vio por escrito. A plataforma Sportsbook tamb\xE9m se reserva o direito de ajustar os limites das contas individuais conforme\r
    bem.</p>\r
  <p>3.9 Para contas com saldos negativos, a plataforma Sportsbook reserva-se o direito de cancelar quaisquer jogadas pendentes,\r
    se colocado com fundos resultantes do erro ou n\xE3o.</p>\r
  <p>3.10 Os membros s\xE3o os \xFAnicos respons\xE1veis \u200B\u200Bpelas transa\xE7\xF5es de sua pr\xF3pria conta. Certifique-se de revisar e confirmar sua\r
    apostas para quaisquer erros antes de envi\xE1-los. Uma vez que uma transa\xE7\xE3o \xE9 conclu\xEDda, ela n\xE3o pode ser alterada.\r
    A plataforma Sportsbook n\xE3o se responsabiliza por apostas perdidas ou duplicadas feitas pelo cliente e\r
    n\xE3o atender pedidos de altera\xE7\xF5es porque uma pe\xE7a est\xE1 faltando ou duplicada. Os clientes podem rever os seus\r
    transa\xE7\xF5es em "Minhas Apostas" do site ap\xF3s cada sess\xE3o para garantir que todas as apostas solicitadas sejam aceitas.</p>\r
  <p>3.11 As disputas devem ser apresentadas no prazo de sete (7) dias a partir da data em que a aposta em quest\xE3o foi decidida. Nenhuma reclama\xE7\xE3o ser\xE1\r
    homenageado ap\xF3s este per\xEDodo. O cliente \xE9 o \xFAnico respons\xE1vel pelas transa\xE7\xF5es de sua conta.</p>\r
  <p>3.12 Os ganhos ser\xE3o sempre calculados usando probabilidades decimais. Por favor, note que ao converter as probabilidades em\r
    Padr\xE3o brit\xE2nico, erros de arredondamento podem ocorrer, pois algumas probabilidades n\xE3o t\xEAm uma tradu\xE7\xE3o exata para\r
    Fra\xE7\xF5es de estilo brit\xE2nico. Aqui, mostraremos as probabilidades fracion\xE1rias mais pr\xF3ximas.</p>\r
  <p>3.13 A plataforma Sportsbook reserva-se o direito de suspender uma conta de cliente sem aviso pr\xE9vio.</p>\r
  <p>3.14 No caso de haver uma discrep\xE2ncia entre a vers\xE3o em ingl\xEAs destas regras e qualquer outra vers\xE3o em outro idioma, a vers\xE3o em ingl\xEAs ser\xE1 considerada correta.</p>\r
  <p>3.15 Apostas combinadas (acumuladores, parlays, multis) n\xE3o s\xE3o aceitas quando o resultado de uma parte da aposta contribui para o resultado de outra. Se esse tipo de aposta for aceito, temos o direito de cancelar esse tipo de aposta. exemplo: fazer uma aposta no Barcelona para vencer a La Liga combinada com uma vit\xF3ria do Barcelona no jogo decisivo.</p>\r
  <p>3.16 Quaisquer apostas feitas com uma aposta do sistema n\xE3o contar\xE3o para o requisito de aposta no B\xF4nus.</p>\r
  <p>3.17 A atualiza\xE7\xE3o do placar ao vivo \xE9 apenas para orienta\xE7\xE3o. A plataforma Sportsbook n\xE3o se responsabiliza por quaisquer erros. A plataforma Sportsbook reserva-se o direito de cancelar quaisquer apostas se o resultado j\xE1 for conhecido ou se o\r
    as probabilidades n\xE3o foram atualizadas corretamente devido a problemas t\xE9cnicos.</p>\r
  <p>3.18 As apostas definitivas s\xE3o consideradas todas em execu\xE7\xE3o ou n\xE3o e, portanto, ser\xE3o consideradas como perda se a sele\xE7\xE3o n\xE3o\r
    participar do evento, salvo indica\xE7\xE3o em contr\xE1rio. As regras de empate se aplicam quando h\xE1 mais de um vencedor.\r
    As apostas dos apostadores s\xE3o divididas primeiro pelo n\xFAmero de sele\xE7\xF5es que empataram e, em seguida, essa parte de suas apostas\r
    \xE9 liquidado como vencedor e o restante como perdedor.</p>\r
  <p>3.19 A plataforma Sportsbook reserva-se o direito de anular ou cancelar quaisquer apostas cujo resultado tenha sido alterado pelo\r
    imposi\xE7\xE3o de pontos de penalidade, rebaixamentos for\xE7ados ou qualquer outra medida aplicada como\r
    resultado de qualquer outra coisa que n\xE3o os resultados normais dos jogos/competi\xE7\xF5es em quest\xE3o.</p>\r
  <p>3.20 Todas as apostas s\xE3o liquidadas usando as informa\xE7\xF5es fornecidas pelo \xF3rg\xE3o oficial que administra a competi\xE7\xE3o no momento\r
    do resultado, salvo indica\xE7\xE3o em contr\xE1rio. No caso de quaisquer eventos fora das competi\xE7\xF5es oficiais, ent\xE3o\r
    as apostas s\xE3o resolvidas usando as informa\xE7\xF5es fornecidas.</p>\r
  <p>3.21 Se um dos concorrentes n\xE3o iniciou a plataforma Sportsbook, cancele este mercado direto.</p>\r
  <p>3.22 Se ambos os competidores n\xE3o terminarem, os vencedores ser\xE3o os competidores que tiverem mais voltas. Se ambos os competidores sa\xEDrem na mesma volta, a plataforma Sportsbook cancelar\xE1 este mercado frente a frente.</p>\r
  <p>3.23 Se os concorrentes estiverem na mesma posi\xE7\xE3o, a plataforma Sportsbook cancela as apostas neste mercado frente a frente.</p>\r
  <p>3.24 A plataforma Sportsbook n\xE3o se responsabiliza pelos danos sofridos pelo cliente como resultado de um mau funcionamento do sistema, defeitos, atrasos, manipula\xE7\xF5es ou erros na transfer\xEAncia de dados.</p>\r
  <p>3.25 Clientes' as reclama\xE7\xF5es s\xE3o consideradas pela plataforma Sportsbook no prazo de trinta dias a partir do momento em que o Cliente envia um pedido por escrito \xE0 plataforma Sportsbook. Ap\xF3s a tomada de decis\xE3o, a plataforma Sportsbook notifica o cliente por meio de um e-mail vinculado \xE0 conta do jogo.</p>\r
  <p>3.26 Em caso de suspeita de atividade desleal, a plataforma Sportsbook reserva-se o direito de anular qualquer aposta ou parte dela, assim\r
    tornar a aposta question\xE1vel inv\xE1lida (nestes casos, o pagamento \xE9 feito com odds de \u201C1\u201D) ou suspender qualquer\r
    saques por at\xE9 31 dias corridos.</p>\r
  <p>3.27 Os clientes podem apostar apenas como indiv\xEDduos, n\xE3o s\xE3o permitidas apostas em grupo. Apostas repetidas nos mesmos resultados /\r
    vencedores do mesmo ou de clientes diferentes podem ser posteriormente declarados inv\xE1lidos. Mesmo depois do oficial\r
    resultado da competi\xE7\xE3o/atletas j\xE1 \xE9 conhecido, a plataforma Sportsbook pode\r
    considerar as apostas indicadas inv\xE1lidas se considerar que os Clientes atuam em conluio ou como sindicato, ou\r
    as apostas consideradas foram feitas por um ou mais Clientes em um curto per\xEDodo de tempo. A empresa de apostas tamb\xE9m tem o direito de recusar a aceita\xE7\xE3o de apostas ou de contar as apostas j\xE1 feitas como\r
    inv\xE1lidas se forem feitas de contas de jogos diferentes com o mesmo endere\xE7o IP.</p>\r
  <p>3.28 Apostas AO VIVO: Se a partida for interrompida ou adiada e n\xE3o continuar em 48 horas ap\xF3s o hor\xE1rio agendado,\r
    as apostas ser\xE3o canceladas (exceto para os resultados claramente definidos quando o jogo foi interrompido).\r
  </p>\r
  <p>3.29 Estat\xEDsticas ou textos editoriais publicados no site da plataforma Sportsbook devem ser considerados como adicionados\r
    informa\xE7\xF5es, mas a plataforma Sportsbook n\xE3o reconhece ou aceita qualquer responsabilidade se o\r
    informa\xE7\xE3o n\xE3o est\xE1 correta. Em todos os momentos, \xE9 responsabilidade do Titular da Conta estar ciente sobre\r
    circunst\xE2ncias relacionadas a um evento.</p>\r
  <p>3.30 \xC9 proibido o uso de sistemas automatizados (qualquer tipo de scanner ou rob\xF4) no Sportsbook. Plataforma de apostas esportivas\r
    reserva-se o direito de cancelar qualquer aposta feita usando sistemas autom\xE1ticos</p>\r
  <p>3.31 \xC9 proibido usar contas pertencentes a outras pessoas ou contas registradas em outros</p>\r
  <p>pessoas. A plataforma Sportsbook reserva-se o direito de cancelar qualquer aposta que n\xE3o seja propriet\xE1ria de uma conta.</p>\r
</section>\r
<section>\r
<h2>4. Tipos de Apostas</h2>\r
  <p>4.1 Simples (Ordin\xE1rio) - aposta em um resultado separado do evento. Pagamento de aposta \xFAnica igual ao produto do valor do lance definido para o pre\xE7o do resultado.</p>\r
  <p>4.2 Combo - aposta em v\xE1rios resultados independentes de eventos. Para ganhar no expresso \xE9 necess\xE1rio que nenhum dos\r
    resultados que est\xE3o inclu\xEDdos no expresso, n\xE3o houve perda. Perder um dos resultados do combo significa\r
    perdendo todo o combo. O pagamento do combo \xE9 igual ao produto o valor da aposta nas probabilidades de todos\r
    resultados inclu\xEDdos no combo.</p>\r
  <p>4.3 Sistema - um conjunto de combos, que \xE9 uma busca completa de variantes de combos do mesmo tamanho a partir de um conjunto fixo de\r
    resultados. Caracteriza-se pela mesma aposta para cada expresso (sistema de op\xE7\xE3o) e o mesmo n\xFAmero de\r
    resultados em cada expresso. Apostar no sistema deve especificar o n\xFAmero total de resultados e o n\xFAmero de combos (op\xE7\xE3o do sistema). O pagamento no sistema \xE9 igual ao valor dos pagamentos\r
    no combo inclu\xEDdo no sistema.</p>\r
  <p>4.4 Uma "Trixie" \xE9 uma combina\xE7\xE3o que inclui um triplo e tr\xEAs duplos de uma sele\xE7\xE3o de tr\xEAs partidas.</p>\r
  <p>4.5 Uma 'Patent' \xE9 uma combina\xE7\xE3o que inclui um triplo, tr\xEAs duplos e tr\xEAs simples de uma sele\xE7\xE3o de tr\xEAs partidas.</p>\r
  <p>4.6 Um 'Yankee' \xE9 uma combina\xE7\xE3o, que inclui um qu\xE1druplo, quatro triplos e seis duplos de uma sele\xE7\xE3o de quatro partidas.</p>\r
  <p>4.7 Um 'Canadian' (tamb\xE9m conhecido como 'Super Yankee') \xE9 uma combina\xE7\xE3o que inclui um qu\xEDntuplo, cinco qu\xE1druplos, dez triplos e dez duplos de uma sele\xE7\xE3o de cinco partidas.</p>\r
  <p>4.8 Um 'Heinz' \xE9 uma combina\xE7\xE3o que inclui um s\xEAxtuplo, seis qu\xEDntuplos, quinze qu\xE1druplos, vinte triplos e quinze duplos de uma sele\xE7\xE3o de seis partidas.</p>\r
  <p>4.9 Um 'Super Heinz' \xE9 uma combina\xE7\xE3o, que inclui um sete vezes, sete seis vezes, vinte e uma cinco vezes, trinta e cinco quatro vezes, trinta e cinco triplas e vinte e uma duplas de uma sele\xE7\xE3o de sete partidas.</p>\r
  <p>4.10 Um 'Goliath' \xE9 uma combina\xE7\xE3o, que inclui um oito vezes, oito sete vezes, vinte e oito seis vezes, cinquenta e seis cinco vezes, setenta quatro vezes, cinquenta e seis triplas e vinte e oito duplas de uma sele\xE7\xE3o de oito partidas.&lt; /p&gt;\r
  </p><p>4.11 Se as probabilidades considerarem mais de 2 d\xEDgitos ap\xF3s o ponto decimal, o pagamento ser\xE1 arredondado para o segundo d\xEDgito ap\xF3s o ponto decimal.</p>\r
  <p>4.12 "Cash out" \xE9 uma oferta individual iniciada pela plataforma Sportsbook, dirigida a um participante da aposta, destinada a alterar uma ou v\xE1rias condi\xE7\xF5es essenciais de aposta (coeficiente, tempo de c\xE1lculo do evento, etc.) para fixar um novo resultado e completar a aposta no momento atual (mais - Cash out). A oferta de\r
    resgatar uma aposta pode ser aceita e rejeitada pelo participante da aposta. Ao selecionar \u201CCash out\u201D, o participante da aposta confirma a sua aceita\xE7\xE3o da\r
    novas condi\xE7\xF5es essenciais da aposta. As taxas de saque podem ser oferecidas tanto para pr\xE9-jogo quanto para apostas ao vivo.\r
    O escrit\xF3rio da casa de apostas reserva-se o direito de alterar a oferta para recomprar o lance ao longo do tempo, ou n\xE3o\r
  fa\xE7a uma oferta para recomprar a aposta sem dar uma raz\xE3o.</p>\r
</section>\r
\r
<section>\r
  <h2>5. Mercados </h2>\r
  <p>5.1 "Jogo" (1X2) \xE9 onde \xE9 poss\xEDvel apostar no resultado (parcial ou definitivo) de um jogo ou evento. As op\xE7\xF5es s\xE3o: "1" = Time da casa, ou time listado ao lado esquerdo da oferta; "X" = Draw, ou a sele\xE7\xE3o no meio; "2" = Equipe visitante ou equipe listada ao lado direito da oferta.\r
  </p>\r
  <p>5.2 "Pontua\xE7\xE3o Correta" (\xE9 onde \xE9 poss\xEDvel apostar na pontua\xE7\xE3o exata (parcial ou definitiva) de uma partida ou evento.</p>\r
  <p>5.3 "Acima/Abaixo" (Totais) \xE9 onde \xE9 poss\xEDvel apostar no valor (parcial ou definitivo) de uma ocorr\xEAncia predefinida (por exemplo, gols, pontos, escanteios, rebotes, minutos de penalidade, etc.). Se o valor total das ocorr\xEAncias listadas for exatamente igual \xE0 linha de aposta, todas as apostas nesta oferta ser\xE3o declaradas nulas. Exemplo: uma oferta onde a linha de aposta \xE9 de 128,0 pontos e a partida termina com o resultado 64-64 ser\xE1 declarada nula.</p>\r
  <p>5.4 "\xCDmpar/Par" \xE9 onde \xE9 poss\xEDvel apostar no valor (parcial ou definitivo) de uma ocorr\xEAncia predefinida (por exemplo, gols, pontos, escanteios, rebotes, minutos de penalidade, etc.). "\xCDmpar" \xE9 1,3, 5 etc.; "Par" \xE9 0,2,4 etc.\r
</p>\r
  <p>5.5 Um "Head-to-Head" e/ou "Triple-Head" \xE9 \u200B\u200Buma competi\xE7\xE3o entre dois ou tr\xEAs participantes/resultados, oriundos de um evento organizado oficialmente, ou ent\xE3o, conforme definido virtualmente pela plataforma Sportsbook</p>\r
  <p>5.6 "Meio tempo/Tempo completo" \xE9 onde \xE9 poss\xEDvel apostar no resultado do intervalo e no resultado final da partida. Por exemplo. se ao intervalo o resultado for 1-0 e o jogo terminar 1-1, o resultado vencedor \xE9 1/X. A aposta \xE9 anulada se o tempo normal da partida for jogado em um formato de tempo diferente dos listados na aposta (ou seja, diferente de dois tempos).</p>\r
  <p>5.7 "Apostas de per\xEDodo" \xE9 onde \xE9 poss\xEDvel apostar no resultado de cada per\xEDodo separado dentro de uma partida/evento.</p>\r
  <p>5.8 "Empate Sem Aposta" \xE9 onde \xE9 poss\xEDvel apostar em "1" ou "2", conforme definido em . Tamb\xE9m \xE9 pr\xE1tica comum referir-se a "Draw No Bet" nos casos em que n\xE3o s\xE3o oferecidas probabilidades de empate. Se a partida espec\xEDfica n\xE3o tiver vencedor (por exemplo, a partida terminar empatada) ou a ocorr\xEAncia espec\xEDfica n\xE3o acontecer (por exemplo, empate sem aposta e a partida terminar em 0-0), as apostas ser\xE3o reembolsadas.</p>\r
  <p>5.9 "Handicap" \xE9 onde \xE9 poss\xEDvel apostar se o resultado escolhido ser\xE1 vitorioso assim que o handicap listado for adicionado/subtra\xEDdo (conforme aplic\xE1vel) ao jogo/per\xEDodo/pontua\xE7\xE3o total a que a aposta se refere. Nas circunst\xE2ncias em que o resultado ap\xF3s o ajuste da linha de handicap for exatamente igual \xE0 linha de aposta, todas as apostas nesta oferta ser\xE3o declaradas nulas.</p>\r
  <p>5.10 Exemplo: uma aposta em -3,0 golos ser\xE1 anulada se a equipa escolhida vencer o jogo por exactamente 3 golos de diferen\xE7a (3-0,4-1, 5-2, etc).</p>\r
  <p>5.11 Handicap Asi\xE1tico: Equipa da casa (-1,75) vs Equipa visitante (+1,75). Isso significa que a aposta \xE9 dividida em 2 apostas iguais e colocada nos resultados -1,5 e -2,0. Para que a aposta seja totalmente paga com as probabilidades listadas, a Equipe A deve vencer a partida com uma margem maior do que ambos os handicaps listados (ou seja, 3 gols ou mais de margem). Na eventualidade de a Equipa A ganhar com apenas 2 golos de margem, a aposta ser\xE1 considerada parcialmente ganha com um pagamento total na parte -1,5 da aposta e um reembolso na parte -2,0 desde que o resultado nessa parte da aposta aposta seria considerada um \u201Cempate\u201D. Se a partida produzir qualquer outro resultado, incluindo uma vit\xF3ria do Time A com apenas 1 gol de margem, toda a aposta ser\xE1 perdida. A equipe visitante recebe uma vantagem de +1,75 gol na partida. Isso significa que a aposta \xE9 dividida em 2 apostas iguais e colocada nos resultados +1,5 e +2,0.</p>\r
  <p>5.12 "Dupla Chance" \xE9 onde \xE9 poss\xEDvel apostar simultaneamente em dois resultados (parciais ou definitivos) de uma partida ou evento. As op\xE7\xF5es s\xE3o: 1X, 12 e X2 com "1", "X" e "2" conforme definido em .</p>\r
  <p>5.13 As apostas "Outright" ou "Place" s\xE3o aquelas em que \xE9 poss\xEDvel escolher de uma lista de alternativas e apostar na eventualidade de um participante vencer ou ficar dentro de uma determinada posi\xE7\xE3o na classifica\xE7\xE3o do evento/competi\xE7\xE3o listado.</p>\r
  <p>5.14 As apostas em "Quarto / Metade / Per\xEDodo X" referem-se ao resultado/pontua\xE7\xE3o alcan\xE7ado no per\xEDodo de tempo relevante e n\xE3o incluem quaisquer outros pontos/gols/eventos contabilizados de outras partes do evento/jogo. As apostas ser\xE3o anuladas se a partida for disputada em qualquer outro formato que n\xE3o o estipulado na oferta.</p>\r
  <p>5.15 As apostas em "Resultado no final do quarto/meia/per\xEDodo X" referem-se ao resultado da partida/evento ap\xF3s o t\xE9rmino do prazo estipulado e levar\xE3o em considera\xE7\xE3o todos os outros pontos/gols/eventos contabilizados em partes anteriores do evento/ Combine.</p>\r
  <p>5.16 Apostas em "Corrida para X Pontos / Corrida para X Gols..." e ofertas semelhantes referem-se \xE0 equipe/participante que atinge mais cedo a contagem espec\xEDfica de pontos/gols/eventos. Se a oferta listar um per\xEDodo de tempo (ou qualquer outra restri\xE7\xE3o de per\xEDodo), n\xE3o incluir\xE1 outros pontos/objetivos/eventos contabilizados de outras partes do evento/jogo que n\xE3o estejam relacionados ao per\xEDodo de tempo mencionado. Caso a pontua\xE7\xE3o listada n\xE3o seja alcan\xE7ada dentro do prazo estipulado (se houver), todas as apostas ser\xE3o declaradas nulas, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>5.17 Apostas em "Vencedor do Ponto X / Marcador do Gol X" e ofertas semelhantes referem-se \xE0 equipe/participante pontuando/vencendo a ocorr\xEAncia listada. Para a liquida\xE7\xE3o dessas ofertas, n\xE3o ser\xE1 considerada qualquer refer\xEAncia a eventos anteriores \xE0 ocorr\xEAncia listada. se o evento listado n\xE3o for pontuado/vencido dentro do prazo estipulado (se houver), todas as apostas ser\xE3o declaradas nulas, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>5.18 As apostas referentes \xE0 ocorr\xEAncia de uma determinada ocorr\xEAncia em uma ordem de tempo pr\xE9-definida, como \u201CPrimeiro Cart\xE3o\u201D ou \u201CPr\xF3xima Equipe a receber minutos de penalidade\u201D ser\xE3o consideradas nulas caso n\xE3o seja poss\xEDvel, sem qualquer d\xFAvida razo\xE1vel, para decidir o resultado vencedor, por exemplo, no caso de jogadores de equipes diferentes que recebem um cart\xE3o na mesma interrup\xE7\xE3o do jogo.</p>\r
  <p>5.19 "Equipe que marca primeiro e vence" refere-se \xE0 equipe listada que marca o primeiro gol na partida e vence a partida. Caso n\xE3o haja gols na partida, todas as apostas ser\xE3o consideradas nulas.</p>\r
  <p>5.20 Qualquer refer\xEAncia a "folha limpa" indica que a equipe listada n\xE3o deve sofrer nenhum gol durante a partida.</p>\r
  <p>5.21 "Equipe a vencer por tr\xE1s" refere-se \xE0 equipe listada vencendo a partida depois de ter perdido pelo menos 1 gol em qualquer ponto da partida.</p>\r
  <p>5.22 Qualquer refer\xEAncia para uma equipe ganhar todos os tempos/tempos (por exemplo, equipe para ganhar os dois tempos) significa que o time listado deve marcar mais gols do que seu oponente durante todos os tempos/tempos estipulados da partida.</p>\r
  <p>5.23 Qualquer refer\xEAncia a "Tempo de les\xE3o" refere-se ao valor exibido pelo oficial designado e n\xE3o ao valor real jogado.</p>\r
  <p>5.24 A liquida\xE7\xE3o de apostas em ofertas como "Homem do Jogo", "Jogador Mais Valioso" etc. ser\xE1 baseada na decis\xE3o dos organizadores da competi\xE7\xE3o, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
</section>\r
\r
<section>\r
  <h2>6. <span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$3969" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Regras especiais para esportes</span></span></span></h2>\r
  <p>6.1. Futebol</p>\r
  <p>6.1.1. As apostas no resultado de uma partida ser\xE3o decididas com base em duas metades do n\xFAmero de minutos programados cada e a qualquer momento que o \xE1rbitro adicionar para compensar les\xF5es e outras paralisa\xE7\xF5es. N\xE3o inclui per\xEDodos de prorroga\xE7\xE3o nem p\xEAnaltis, se n\xE3o indicado.</p>\r
  <p>6.1.2. Escanteios concedidos mas n\xE3o marcados n\xE3o s\xE3o considerados.</p>\r
  <p>6.1.3. Gols contra n\xE3o ser\xE3o considerados para o goleador a qualquer momento ou jogador marcar X ou pr\xF3ximo goleador ou mais para fins de liquida\xE7\xE3o e s\xE3o ignorados</p>\r
  <p>6.1.4. Todos os jogadores que participaram da partida desde o pontap\xE9 inicial ou gol anterior s\xE3o considerados corredores</p>\r
  <p>6.1.5. Se um jogador n\xE3o estiver no XI inicial, todos os mercados de jogadores ser\xE3o anulados.</p>\r
  <p>6.1.6. Se, por qualquer motivo, um jogador n\xE3o listado marcar um gol, todas as apostas nos jogadores listados ser\xE3o v\xE1lidas</p>\r
  <p>6.1.7. A qualquer momento o mercado de Marcador ou Jogador para marcar X ou Pr\xF3ximo Marcador ser\xE1 liquidado com base na inser\xE7\xE3o de TV e nas estat\xEDsticas fornecidas pela Press Association, a menos que haja evid\xEAncias claras de que essas estat\xEDsticas n\xE3o estejam corretas.</p>\r
  <p>6.1.8. Os mercados de intervalo ser\xE3o liquidados com base no tempo do objetivo anunciado pela TV. Se isso n\xE3o estiver dispon\xEDvel, o tempo de acordo com o rel\xF3gio da partida \xE9 considerado.</p>\r
  <p>6.1.9. Os mercados de gols de intervalo s\xE3o determinados com base no momento em que a bola cruza a linha, e n\xE3o no momento em que o chute \xE9 feito.</p>\r
  <p>6.1.10. Os mercados de intervalo de escanteio s\xE3o liquidados com base no momento em que o escanteio \xE9 cobrado e n\xE3o no momento em que o escanteio \xE9 concedido ou concedido.</p>\r
  <p>6.1.11. Os mercados de intervalo de reserva s\xE3o liquidados com base no momento em que o cart\xE3o \xE9 mostrado e n\xE3o no momento em que a infra\xE7\xE3o \xE9 feita</p>\r
  <p>6.1.12. Os impedimentos ser\xE3o resolvidos com base no momento em que o \xE1rbitro decidir. Esta regra ser\xE1 aplicada em qualquer situa\xE7\xE3o de \xE1rbitro assistente de v\xEDdeo (VAR).</p>\r
  <p>6.1.13. Os mercados de p\xEAnaltis ser\xE3o resolvidos com base no momento em que o \xE1rbitro tomar a decis\xE3o. Esta regra ser\xE1 aplicada em qualquer situa\xE7\xE3o de \xE1rbitro assistente de v\xEDdeo (VAR).</p>\r
  <p>6.1.14. As penalidades atribu\xEDdas mas n\xE3o cumpridas n\xE3o s\xE3o consideradas</p>\r
  <p>6.1.15. Pr\xF3ximo tipo de pontua\xE7\xE3o. Livre: O gol tem que ser marcado diretamente da cobran\xE7a de falta ou escanteio para se qualificar como gol por cobran\xE7a de falta. Chutes desviados contam desde que o gol seja concedido ao cobrador de falta ou escanteio. P\xEAnalti: O gol deve ser marcado diretamente do p\xEAnalti. Gols ap\xF3s um rebote de um p\xEAnalti perdido n\xE3o contam. Gol Contra: Se o gol for declarado como um gol contra. Cabeceamento: O \xFAltimo toque do marcador tem que ser com a cabe\xE7a. Chute: Gol tem que ser com qualquer outra parte do corpo que n\xE3o a cabe\xE7a e os outros tipos n\xE3o se aplicam. Sem Gol.</p>\r
  <p><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$4026" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">6.1.16. Se o mercado foi aberto com um cart\xE3o vermelho ausente ou incorreto, nos reservamos o direito de anular as apostas    6.1.17. Se as probabilidades foram oferecidas com um tempo de jogo incorreto (mais de 5 minutos), nos reservamos o direito de anular as apostas.    6.1.18. Se uma pontua\xE7\xE3o errada for inserida, todos os mercados ser\xE3o cancelados pelo tempo em que a pontua\xE7\xE3o incorreta foi exibida    6.1.19. Se os nomes ou categorias das equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.    6.1.20. Cart\xE3o amarelo conta como 1 cart\xE3o e cart\xE3o vermelho ou amarelo-vermelho como 2. O 2\xBA amarelo para um jogador que leva a um cart\xE3o amarelo vermelho n\xE3o \xE9 considerado. Como consequ\xEAncia, um jogador n\xE3o pode causar mais de 3 cartas.    6.1.21. A liquida\xE7\xE3o ser\xE1 feita de acordo com todas as evid\xEAncias dispon\xEDveis das cartas mostradas durante os 90 minutos normais de jogo.    6.1.22. Os cart\xF5es mostrados ap\xF3s a partida n\xE3o s\xE3o considerados.    6.1.23. Cart\xF5es para n\xE3o jogadores (jogadores j\xE1 substitu\xEDdos, treinadores, jogadores no banco) n\xE3o s\xE3o considerados    6.1.24. O cart\xE3o amarelo conta como 10 pontos e os cart\xF5es vermelhos ou amarelos vermelhos como 25. O 2\xBA amarelo para um jogador que leva a um cart\xE3o amarelo vermelho n\xE3o \xE9 considerado. Como consequ\xEAncia, um jogador n\xE3o pode causar mais de 35 pontos de reserva.    6.1.25. A liquida\xE7\xE3o ser\xE1 feita de acordo com todas as evid\xEAncias dispon\xEDveis para as cartas mostradas durante os 90 minutos normais de jogo.    6.1.26. Cart\xF5es para n\xE3o jogadores (jogadores j\xE1 substitu\xEDdos, treinadores, jogadores no banco) n\xE3o s\xE3o considerados.    6.1.27. Se o formato da partida foi alterado, as apostas esportivas se reservam o direito de anular todas as apostas.    6.1.28. Se um amistoso terminou por decis\xE3o do \xE1rbitro antes dos 80 minutos.    6.1.29. Se um amistoso terminar por decis\xE3o do \xE1rbitro antes dos 80 minutos    6.1.30. Todas as apostas de adere\xE7os de jogadores de futebol s\xE3o liquidadas usando as informa\xE7\xF5es fornecidas pela OPTA (https://soccerstats.info/)</span></span></span></p>\r
  <p>6.1.31. Defini\xE7\xE3o de Adere\xE7os do JogadorGol/Pr\xF3prio GoloDiversos \xF3rg\xE3os governamentais t\xEAm regras diferentes e, sempre que poss\xEDvel, a Opta trabalha com as pessoas relevantes para refletir suas decis\xF5es oficiais sobre os artilheiros. Em rela\xE7\xE3o a desvios, normalmente um gol \xE9 concedido se a tentativa original for no alvo. Um autogolo \xE9 normalmente concedido se a tentativa for fora do alvo e desviada para a baliza por um advers\xE1rio.RematesUm remate ao alvo \xE9 definido como qualquer tentativa clara de marcar que:Entra na rede independentemente da inten\xE7\xE3o.\xC9 uma tentativa clara de marcar que ter ido para a rede, mas por ser defendido pelo goleiro ou ser parado por um jogador que \xE9 o \xFAltimo homem com o goleiro n\xE3o tendo chance de impedir o gol (bloqueio da \xFAltima linha). com outro jogador. Teria ido por cima ou ao lado da baliza, mas por ter sido parado por defesa de um guarda-redes ou por um jogador de campo. Bate directamente na baliza e n\xE3o \xE9 marcado golo. Remates bloqueados n\xE3o s\xE3o contados como remates. no gol - qualquer tentativa de gol que:Entre na rede independentemente da inten\xE7\xE3o.\xC9 uma tentativa clara de gol que teria ido para a rede, mas por ser defendida pelo goleiro ou ser interrompida por um jogador que \xE9 o \xFAltimo homem com o gol. goleiro sem chance de impedir o gol (l bloqueio da linha traseira). Os remates que atingem directamente a baliza n\xE3o s\xE3o contados como remates \xE0 baliza, a menos que a bola entre e seja concedida como golo. Os remates bloqueados por outro jogador, que n\xE3o seja o \xFAltimo homem, n\xE3o s\xE3o contados como chutes no alvo.Assist\xEAncia de GolO toque final (passe, passe-cum-chute ou qualquer outro toque) que leva o receptor da bola a marcar um gol. Se o toque final (conforme definido em negrito) for desviado por um jogador advers\xE1rio, o iniciador s\xF3 recebe uma assist\xEAncia de gol se o jogador recebedor provavelmente receber a bola sem que a deflex\xE3o tenha ocorrido. Gols contra, tiros livres diretos, gols de escanteio direto e p\xEAnaltis n\xE3o recebem assist\xEAncia. Desarme Um desarme \xE9 definido como quando um jogador se conecta com a bola em um desafio de solo onde ele tira a bola com sucesso do jogador com a posse de bola. o jogador deve estar claramente em posse da bola antes que o tackle seja feito. Considera-se que um tackle ganho ocorre quando o tackleador ou um de seus companheiros de equipe recupera a posse como resultado do desafio, ou que a bola sai de jogo e \xE9 \u201Cseguro\u201D. Um tackle perdido \xE9 quando um tackle \xE9 feito, mas a bola vai para um jogador advers\xE1rio. Ambos s\xE3o considerados como tackles bem-sucedidos, no entanto, o resultado do tackle (ganho ou perdido) \xE9 diferente com base em onde a bola vai ap\xF3s o tackle.N\xE3o \xE9 um tackle, quando um jogador corta um passe por qualquer meio.</p>\r
  <p>6.1.31.1. Golo/Golo Diferentes \xF3rg\xE3os governamentais t\xEAm regras diferentes e, sempre que poss\xEDvel, a Opta trabalha com as pessoas relevantes para refletir suas decis\xF5es oficiais sobre os artilheiros. Em rela\xE7\xE3o a desvios, normalmente um gol \xE9 concedido se a tentativa original for no alvo. Um gol contra \xE9 geralmente concedido se a tentativa for fora do alvo e desviada para o gol por um advers\xE1rio.</p>\r
  <p>6.1.31.2. ChutesUm alvo de chute \xE9 definido como qualquer tentativa clara de gol que: Entra na rede independentemente da inten\xE7\xE3o. \xFAltimo homem com o goleiro sem chance de impedir o gol (\xFAltima linha de bloqueio). Passa por cima ou para fora do gol sem fazer contato com outro jogador. Teria passado por cima ou ao lado do gol se fosse parado por uma defesa do goleiro ou por um jogador de campo. Atinge diretamente a arma\xE7\xE3o do gol e um gol n\xE3o \xE9 marcado. Chutes bloqueados n\xE3o s\xE3o contados como chutes.</p>\r
  <p>\u25CF Entra na rede independentemente da inten\xE7\xE3o.</p>\r
  <p>\u25CF \xC9 uma tentativa clara de gol que teria ido para a rede, mas por ser defendida pelo goleiro ou ser parada por um jogador que \xE9 o \xFAltimo homem com o goleiro sem chance de impedir o gol (bloqueio da \xFAltima linha).</p>\r
  <p>\u25CF Passa por cima ou para longe do gol sem tocar em outro jogador.</p>\r
  <p>\u25CF Teria passado por cima ou ao lado do gol se n\xE3o fosse parado por uma defesa do goleiro ou por um jogador de campo.</p>\r
  <p>\u25CF Atinge diretamente a estrutura do gol e o gol n\xE3o \xE9 marcado. Chutes bloqueados n\xE3o s\xE3o contados como chutes.</p>\r
  <p>6.1.31.3. Chutes a gol - qualquer tentativa de gol que: Entra na rede independentemente da inten\xE7\xE3o. o goleiro n\xE3o tem chance de impedir o gol (bloqueio da \xFAltima linha). Chutes que atingem diretamente a estrutura do gol n\xE3o s\xE3o contados como chutes ao gol, a menos que a bola entre e seja concedida como gol. n\xE3o \xE9 o \xFAltimo homem, n\xE3o s\xE3o contados como tiros no alvo.</p>\r
  <p>\u25CF Entra na rede independentemente da inten\xE7\xE3o.</p>\r
  <p>\u25CF \xC9 uma tentativa clara de gol que teria ido para a rede se n\xE3o fosse defendida pelo goleiro ou parado por um jogador que \xE9 o \xFAltimo homem com o goleiro n\xE3o tendo chance de impedir o gol (bloqueio da \xFAltima linha). acertar diretamente na baliza n\xE3o s\xE3o contados como remates \xE0 baliza, a menos que a bola entre e seja validada como golo. Os remates bloqueados por outro jogador, que n\xE3o seja o \xFAltimo homem, n\xE3o s\xE3o contados como remates \xE0 baliza.</p>\r
  <p>6.1.31.4. Assist\xEAncia ao GolO toque final (passe, passe e chute ou qualquer outro toque) que leva o recebedor da bola a marcar um gol. Se o toque final (conforme definido em negrito) for desviado por um jogador advers\xE1rio, o iniciador s\xF3 recebe uma assist\xEAncia de gol se o jogador recebedor provavelmente receber a bola sem que a deflex\xE3o tenha ocorrido. Gols contra, tiros livres diretos, gols de escanteio direto e p\xEAnaltis n\xE3o recebem assist\xEAncia.</p>\r
  <p>6.1.31.5. TackleUm tackle \xE9 definido como quando um jogador se conecta com a bola em um desafio de solo onde ele tira a bola com sucesso do jogador com a posse de bola. considerado como quando o tackleador ou um de seus companheiros de equipe recupera a posse como resultado do desafio, ou que a bola sai de jogo e \xE9 \u201Csegura\u201D. Um tackle perdido \xE9 quando um tackle \xE9 feito, mas a bola vai para um jogador advers\xE1rio. Ambos s\xE3o considerados como tackles bem sucedidos, no entanto, o resultado do tackle (ganho ou derrota) \xE9 diferente dependendo de onde a bola vai ap\xF3s o tackle. N\xE3o \xE9 um tackle, quando um jogador corta um passe por qualquer meio.</p>\r
  <p>\u25CF Considera-se um tackle ganho quando o tackleador ou um de seus companheiros de equipe recupera a posse como resultado do desafio, ou quando a bola sai de jogo e est\xE1 \u201Csegura\u201D.</p>\r
  <p>\u25CF Um desarme perdido \xE9 quando um desarme \xE9 feito, mas a bola vai para um jogador advers\xE1rio. Ambos s\xE3o considerados como desarmes bem-sucedidos, no entanto, o resultado do desarme (ganho ou perdido) \xE9 diferente com base em onde a bola vai ap\xF3s o desarme. n\xE3o \xE9 um tackle, quando um jogador corta um passe por qualquer meio.</p>\r
  <p>6.2. t\xEAnis</p>\r
  <p>6.2.1. Em caso de abandono e abandono de qualquer jogador, todas as apostas indecisas s\xE3o consideradas nulas.</p>\r
  <p>6.2.2. Em caso de atraso (chuva, escurid\xE3o...) todos os mercados permanecem inst\xE1veis \u200B\u200Be a negocia\xE7\xE3o continuar\xE1 assim que a partida continuar.</p>\r
  <p>6.2.3. Se os pontos de penaliza\xE7\xE3o forem atribu\xEDdos pelo \xE1rbitro, todas as apostas nesse jogo ser\xE3o v\xE1lidas.</p>\r
  <p>6.2.4. No caso de uma partida terminar antes de certos pontos/jogos terem terminado, todos os mercados relacionados a pontos/jogos afetados s\xE3o considerados nulos.</p>\r
  <p>6.2.5. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.2.6. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.2.7. Se um jogador se aposentar, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.2.8. Se uma partida for decidida por um Match tie-break, ser\xE1 considerado o 3\xBA set</p>\r
  <p>6.2.9. Cada tie-break ou Match tie-break conta como 1 jogo</p>\r
  <p>6.3. Basquetebol</p>\r
  <p>6.3.1. Os mercados n\xE3o consideram horas extras, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>6.3.2. Se as probabilidades forem oferecidas com um tempo de jogo incorreto (mais de 2 minutos), nos reservamos o direito de anular as apostas.</p>\r
  <p>6.3.3. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.3.4. No caso de uma partida n\xE3o terminar empatada, mas a prorroga\xE7\xE3o for disputada para fins de qualifica\xE7\xE3o, os mercados ser\xE3o liquidados de acordo com o resultado no final do tempo regulamentar.</p>\r
  <p>6.3.5. Se uma partida terminar antes que o X seja alcan\xE7ado, este mercado \xE9 considerado nulo (cancelado). Quem marca o X ponto? (incl. ot), Qual equipe vencer\xE1 a corrida para x pontos? (incluindo AT).</p>\r
  <p>6.3.6. Mercado (Haver\xE1 prorroga\xE7\xE3o?) ser\xE1 liquidado como sim se no final do tempo regulamentar a partida terminar empatada, independentemente de haver ou n\xE3o prorroga\xE7\xE3o.</p>\r
  <p>6.4. futebol americano</p>\r
  <p>6.4.1. Em caso de atraso (chuva, escurid\xE3o...) todos os mercados permanecem inst\xE1veis \u200B\u200Be a negocia\xE7\xE3o continuar\xE1 assim que a partida continuar.</p>\r
  <p>6.4.2. Os mercados n\xE3o consideram horas extras, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>6.4.3. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.4.4. Se as probabilidades foram oferecidas com um tempo de jogo incorreto (mais de 89 segundos), nos reservamos o direito de anular as apostas.</p>\r
  <p>6.4.5. Se uma pontua\xE7\xE3o errada for exibida, nos reservamos o direito de anular as apostas para este per\xEDodo</p>\r
  <p>6.4.6. Em caso de partidas abandonadas ou adiadas, todos os mercados s\xE3o considerados nulos, a menos que a partida continue na mesma programa\xE7\xE3o semanal da NFL (quinta a quarta-feira, hor\xE1rio local do est\xE1dio).</p>\r
  <p>6.4.7. Se as equipes forem exibidas incorretamente, nos reservamos o direito de anular as apostas</p>\r
  <p>6.4.8. Todos os jogadores oferecidos s\xE3o considerados como corredores.</p>\r
  <p>6.4.9. Se nenhum outro touchdown for marcado, o mercado (Pontuador do pr\xF3ximo touchdown (incluindo prorroga\xE7\xE3o)) ser\xE1 anulado.</p>\r
  <p>6.4.10. Os jogadores que n\xE3o est\xE3o listados s\xE3o considerados como \u201COutro jogador Competidor1\u201D ou \u201COutro jogador Competidor2\u201D para fins de liquida\xE7\xE3o. Observe que isso n\xE3o inclui jogadores listados sem um pre\xE7o ativo.</p>\r
  <p>6.4.11. Os jogadores da equipe de Defesa ou Especial s\xE3o considerados como \u201CCompetidor 1 d/st jogador\u201D ou \u201CCompetidor 2 d/st jogador\u201D para fins de liquida\xE7\xE3o, mesmo que o jogador seja listado como resultado dedicado.</p>\r
  <p>6.4.12. O mercado ser\xE1 liquidado com base na inser\xE7\xE3o da TV e nas estat\xEDsticas fornecidas pelas associa\xE7\xF5es oficiais, a menos que haja evid\xEAncias claras de que as estat\xEDsticas n\xE3o estejam corretas.</p>\r
  <p>6.5. Hockey no gelo</p>\r
  <p>6.5.1. Todos os mercados (exceto os mercados de per\xEDodo, prorroga\xE7\xE3o e p\xEAnaltis) s\xE3o considerados apenas para o tempo regular, a menos que seja mencionado no mercado.</p>\r
  <p>6.5.2. No caso de um jogo ser decidido por uma disputa de p\xEAnaltis, um gol ser\xE1 adicionado \xE0 pontua\xE7\xE3o da equipe vencedora e ao total do jogo para fins de liquida\xE7\xE3o. Isso se aplica a todos os mercados, incluindo prorroga\xE7\xE3o e p\xEAnaltis</p>\r
  <p>6.5.3. Se o mercado permanecer aberto quando os seguintes eventos j\xE1 tiverem ocorrido: gols e p\xEAnaltis, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.5.4. Se as probabilidades forem oferecidas com um tempo de jogo incorreto (mais de 2 minutos), nos reservamos o direito de anular as apostas.</p>\r
  <p>6.5.5. Se uma pontua\xE7\xE3o errada for inserida, todos os mercados ser\xE3o cancelados no momento em que a pontua\xE7\xE3o incorreta foi exibida.</p>\r
  <p>6.6. Beisebol</p>\r
  <p>6.6.1. Se uma entrada terminar antes que o ponto X seja alcan\xE7ado (incluindo entradas extras), este mercado (Qual equipe vence a corrida para x pontos?, Quem marca o ponto X (incluindo ot)) \xE9 considerado nulo (cancelado).</p>\r
  <p>6.6.2. O mercado (quando a partida ser\xE1 decidida?) ser\xE1 determinado como \u201CQualquer entrada extra\u201D se no final do tempo regulamentar (ap\xF3s 9 entradas completas) a partida terminar empatada, independentemente de haver ou n\xE3o prorroga\xE7\xE3o (entradas extras) \xE9 jogado</p>\r
  <p>6.6.3. Market (Haver\xE1 prorroga\xE7\xE3o?) ser\xE1 definido como "Sim" se no final do tempo regulamentar (Ap\xF3s 9 Innings completos) a partida terminar empatada, independentemente de se jogar ou n\xE3o prorroga\xE7\xE3o (Innings Extra)</p>\r
  <p>6.6.4. Poss\xEDveis entradas extras n\xE3o s\xE3o consideradas em nenhum mercado, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>6.6.5. Todos os mercados ser\xE3o apurados de acordo com o resultado final ap\xF3s 9 entradas (8 \xB9\u2044\uFEA3 entradas se o time da casa estiver liderando neste momento)</p>\r
  <p>6.6.6. Se uma partida for interrompida ou cancelada e n\xE3o for continuada no mesmo dia, todos os mercados indecisos ser\xE3o considerados nulos.</p>\r
  <p>6.6.7. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta ou status de partida incorreto que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.7. Handebol</p>\r
  <p>6.7.1. Se uma partida terminar antes que o X seja alcan\xE7ado, este mercado (Quem marca o X ponto? (incl. ot)) \xE9 considerado nulo (cancelado)</p>\r
  <p>6.7.2. Se uma partida terminar antes que o X seja alcan\xE7ado, este mercado (Qual equipe vencer\xE1 a corrida para x pontos? (incl. ot)) \xE9 considerado nulo (cancelado).</p>\r
  <p>6.7.3. Todos os mercados (exceto Quem marca o X ponto e Qual equipe vencer\xE1 a corrida para X pontos) s\xE3o considerados apenas para o tempo regular.</p>\r
  <p>6.7.4. Se a partida for para um tiroteio de 7 metros; os mercados \u201CQuem marca o X ponto?\u201D e "Qual equipe vencer\xE1 a corrida para X pontos?" ser\xE1 anulado.</p>\r
  <p>6.7.5. Se as probabilidades forem oferecidas com um tempo de jogo incorreto (mais de 3 minutos), nos reservamos o direito de anular as apostas.</p>\r
  <p>6.7.6. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.8. V\xF4lei</p>\r
  <p>6.8.1. Se um set terminar antes que o ponto X seja alcan\xE7ado, este mercado (Quem marca [Xth] ponto no set [y]) \xE9 considerado nulo (cancelado)</p>\r
  <p>6.8.2. No caso de uma partida n\xE3o ser conclu\xEDda, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.8.3. O conjunto dourado n\xE3o \xE9 considerado em nenhum dos mercados mencionados</p>\r
  <p>6.8.4. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.8.5. As dedu\xE7\xF5es oficiais de pontos ser\xE3o levadas em considera\xE7\xE3o para todos os mercados indeterminados. Os mercados que j\xE1 foram determinados n\xE3o levar\xE3o em conta as dedu\xE7\xF5es.</p>\r
  <p>6.9. V\xF4lei de praia</p>\r
  <p>6.9.1. se um set terminar antes que o ponto X seja alcan\xE7ado, este mercado (Quem marca [Xth] ponto no set [y]) \xE9 considerado nulo (cancelado)</p>\r
  <p>6.9.2. No caso de uma partida n\xE3o ser finalizada, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.9.3. O conjunto dourado n\xE3o \xE9 considerado em nenhum dos mercados mencionados</p>\r
  <p>6.9.4. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.9.5. Se uma equipe se aposentar, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.9.6. As dedu\xE7\xF5es oficiais de pontos ser\xE3o levadas em considera\xE7\xE3o para todos os mercados indeterminados. Os mercados que j\xE1 foram determinados n\xE3o levar\xE3o em conta as dedu\xE7\xF5es.</p>\r
  <p>6.10. Futsal</p>\r
  <p>6.10.1. Todos os mercados (exceto intervalo, mercados do primeiro tempo, prorroga\xE7\xE3o e disputa de p\xEAnaltis) s\xE3o considerados apenas para o tempo regulamentar.</p>\r
  <p>6.10.2. Se uma partida for interrompida e continuada dentro de 48h ap\xF3s a data inicial de in\xEDcio, todas as apostas abertas ser\xE3o liquidadas com o resultado final. Caso contr\xE1rio, todas as apostas indecisas s\xE3o consideradas nulas.</p>\r
  <p>6.10.3. Se o mercado permanecer aberto quando os seguintes eventos j\xE1 tiverem ocorrido: gols, cart\xF5es vermelhos ou amarelo-vermelhos e p\xEAnaltis, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.10.4. Se o mercado foi aberto com um cart\xE3o vermelho ausente ou incorreto, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.10.5. Se as probabilidades foram oferecidas com um tempo de jogo incorreto (mais de 2 minutos), nos reservamos o direito de anular as apostas.6.10.6 Se uma pontua\xE7\xE3o errada for inserida, todos os mercados ser\xE3o cancelados pelo tempo em que a pontua\xE7\xE3o incorreta foi exibida.6.10 .7. Se os nomes ou categorias das equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.11. Badminton</p>\r
  <p>6.11.1. Se um set terminar antes que o ponto X seja alcan\xE7ado, este mercado (Quem marca [Xth] ponto no [Nth] set) \xE9 considerado nulo (cancelado)</p>\r
  <p>6.11.2. No caso de uma partida n\xE3o ser finalizada, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.11.3. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.11.4. Se uma equipe se aposentar, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.11.5. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.11.6. As dedu\xE7\xF5es oficiais de pontos ser\xE3o levadas em considera\xE7\xE3o para todos os mercados indeterminados. Os mercados que j\xE1 foram determinados n\xE3o levar\xE3o em conta as dedu\xE7\xF5es.</p>\r
  <p>6.12. Rugby Union e Rugby League</p>\r
  <p>6.12.1. Todos os mercados (exceto intervalo, mercados do primeiro tempo, prorroga\xE7\xE3o e disputa de p\xEAnaltis) s\xE3o considerados apenas para o tempo regulamentar.</p>\r
  <p>6.12.2. Regular 80 Minutos: Os mercados s\xE3o baseados no resultado no final de um jogo programado de 80 minutos, salvo indica\xE7\xE3o em contr\xE1rio. Isso inclui qualquer les\xE3o adicional ou tempo de paralisa\xE7\xE3o, mas n\xE3o inclui prorroga\xE7\xE3o, tempo alocado para uma disputa de p\xEAnaltis ou morte s\xFAbita.</p>\r
  <p>6.12.3. Se o mercado permanecer aberto quando os seguintes eventos j\xE1 tiverem ocorrido: altera\xE7\xF5es de pontua\xE7\xE3o ou cart\xF5es vermelhos, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.12.4. Se o mercado foi aberto com um cart\xE3o vermelho ausente ou incorreto, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.12.5. Se as probabilidades forem oferecidas com um tempo de jogo incorreto (mais de 2 minutos), nos reservamos o direito de anular as apostas.</p>\r
  <p>6.12.6. Se os nomes ou categorias das equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.13. Rugby Sevens</p>\r
  <p>6.13.1. Todos os mercados (exceto intervalo, mercados do primeiro tempo, prorroga\xE7\xE3o e disputa de p\xEAnaltis) s\xE3o considerados apenas para o tempo regulamentar.</p>\r
  <p>6.13.2. Regular 14/20 Minutos: Os mercados s\xE3o baseados no resultado no final de um jogo programado de 14/20 minutos, salvo indica\xE7\xE3o em contr\xE1rio. Isso inclui qualquer les\xE3o adicional ou tempo de paralisa\xE7\xE3o, mas n\xE3o inclui prorroga\xE7\xE3o, tempo alocado para uma disputa de p\xEAnaltis ou morte s\xFAbita</p>\r
  <p>6.13.3. Se o mercado permanecer aberto quando os seguintes eventos j\xE1 tiverem ocorrido: altera\xE7\xF5es de pontua\xE7\xE3o ou cart\xF5es vermelhos, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.13.4. Se o mercado foi aberto com um cart\xE3o vermelho ausente ou incorreto, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.13.5. Se as probabilidades foram oferecidas com um tempo de jogo incorreto (mais de 1 minuto), nos reservamos o direito de anular as apostas.1</p>\r
  <p>6.13.6. Se os nomes ou categorias das equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.14. Dardos</p>\r
  <p>6.14.1. No caso de uma partida n\xE3o ser finalizada, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.14.2. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.14.3. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.14.4. Se uma partida n\xE3o for conclu\xEDda, todos os mercados indecisos ser\xE3o considerados nulos.</p>\r
  <p>6.14.5. Bullseye conta como vermelho check out color.</p>\r
  <p>6.15. sinuca</p>\r
  <p>6.15.1. No caso de desist\xEAncia de um jogador ou desqualifica\xE7\xE3o, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.15.2. No caso de uma reinstala\xE7\xE3o, a liquida\xE7\xE3o permanece se o resultado foi determinado antes da reinstala\xE7\xE3o</p>\r
  <p>6.15.3. Nenhuma falta ou bola livre \xE9 considerada para a liquida\xE7\xE3o de qualquer mercado Potted-Color</p>\r
  <p>6.15.4. No caso de um quadro come\xE7ar, mas n\xE3o ser conclu\xEDdo, todos os mercados relacionados a quadros ser\xE3o anulados, a menos que o resultado j\xE1 tenha sido determinado</p>\r
  <p>6.15.5. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.15.6. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.15.7. Se uma partida n\xE3o for conclu\xEDda, todos os mercados indecisos ser\xE3o considerados nulos.</p>\r
  <p>6.16. T\xEAnis de mesa</p>\r
  <p>6.16.1. Se um set terminar antes que o ponto X seja alcan\xE7ado, este mercado (Quem marca [Xth] ponto no set [y]) \xE9 considerado nulo (cancelado).</p>\r
  <p>6.16.2. No caso de uma partida n\xE3o ser finalizada, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.16.3. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.16.4. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.16.5. Se um jogador se aposentar, todos os mercados indecisos s\xE3o considerados nulos.</p>\r
  <p>6.16.6. As dedu\xE7\xF5es oficiais de pontos ser\xE3o levadas em considera\xE7\xE3o para todos os mercados indeterminados. Os mercados que j\xE1 foram determinados n\xE3o levar\xE3o em conta as dedu\xE7\xF5es.</p>\r
  <p>6.17. Tigelas</p>\r
  <p>6.17.1. Se um set terminar antes do X\xBA ponto ser alcan\xE7ado, este mercado (X\xBA set - qual equipe ganha a corrida para x pontos, X\xBA set - qual equipe marca X\xBA ponto) \xE9 considerado nulo (cancelado)</p>\r
  <p>6.17.2. Em caso de abandono e abandono de qualquer jogador, todas as apostas indecisas s\xE3o consideradas nulas.</p>\r
  <p>6.17.3. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.17.4. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.18. Cricket</p>\r
  <p>6.18.1. Descri\xE7\xE3o da Aposta da Partida: Quem vencer\xE1 a partida?Regras: Todas as apostas de partidas ser\xE3o pagas de acordo com as regras oficiais da competi\xE7\xE3o. Em partidas afetadas por condi\xE7\xF5es meteorol\xF3gicas adversas, as apostas ser\xE3o determinadas de acordo com o resultado oficial. Se n\xE3o houver resultado oficial, todas as apostas ser\xE3o anuladas. Em caso de empate, se as regras oficiais da competi\xE7\xE3o n\xE3o determinarem um vencedor, as regras de empate vai aplicar. Em competi\xE7\xF5es em que um bowl off ou super over determina um vencedor, as apostas ser\xE3o liquidadas com base no resultado oficial. Em partidas de primeira classe, se o resultado oficial for um empate, as apostas ser\xE3o liquidadas como um empate entre ambas as equipes. As apostas no sorteio ser\xE3o consideradas perdedoras. Se uma partida for abandonada devido a fatores externos, as apostas ser\xE3o anuladas, a menos que um vencedor seja declarado com base nas regras oficiais da competi\xE7\xE3o. Se uma partida for cancelada, todas as apostas ser\xE3o anuladas se n\xE3o \xE9 reproduzido ou reiniciado dentro de 36 horas ap\xF3s o hor\xE1rio de in\xEDcio anunciado.</p>\r
  <p>6.18.2. Dupla Chance Descri\xE7\xE3o: O resultado da partida ser\xE1 uma das tr\xEAs op\xE7\xF5es dadas?Regras: Um empate ser\xE1 considerado um empate. Todas as apostas em jogos ser\xE3o resolvidas de acordo com as regras oficiais da competi\xE7\xE3o. Se n\xE3o houver um resultado oficial, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.3. Apostas na Partida: Empate N\xE3o Descri\xE7\xE3o da Aposta: Quem vencer\xE1 a partida, uma vez que todas as apostas ser\xE3o anuladas se a partida terminar empatada?Regras: Um empate ser\xE1 considerado um empate. Todas as apostas em jogos ser\xE3o liquidadas de acordo com as regras oficiais da competi\xE7\xE3o. Se n\xE3o houver resultado oficial, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.4. Jogo empatado Descri\xE7\xE3o: O jogo ficar\xE1 empatado?Regras: Todas as apostas ser\xE3o liquidadas de acordo com o resultado oficial. Se a partida for abandonada ou n\xE3o houver resultado oficial, todas as apostas ser\xE3o anuladas. Para partidas de primeira classe, um empate \xE9 quando o segundo lado rebatedor \xE9 eliminado pela segunda vez com o mesmo n\xEDvel de pontua\xE7\xE3o.</p>\r
  <p>6.18.5. Mais Fours Descri\xE7\xE3o: Qual time acertar\xE1 mais fours?Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. bat (fora de qualquer entrega \u2013 legal ou n\xE3o) contar\xE1 para o total de quatros. Overthrows, all run fours e extras n\xE3o contam. Fours marcados em um super over n\xE3o contam.</p>\r
  <p>6.18.6. Mais Seis Descri\xE7\xE3o: Qual time acertar\xE1 mais seis?Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. bat (fora de qualquer entrega \u2013 legal ou n\xE3o) contar\xE1 para o total de seis. Derrubadas e extras n\xE3o contam. Seis marcados em um super over n\xE3o contam.</p>\r
  <p>6.18.7. Mais Extras Descri\xE7\xE3o: Qual equipe ter\xE1 mais extras adicionados \xE0 sua pontua\xE7\xE3o de rebatidas?Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Todos os lan\xE7amentos largos, sem bolas, byes, leg byes e p\xEAnaltis na partida contam para o resultado final. Se houver corridas sem bast\xE3o, bem como extras da mesma entrega, as corridas sem bast\xE3o n\xE3o contam para o total final. Extras em um super over n\xE3o contam. Em jogos de Primeira Classe, apenas os extras de primeira entrada contam.</p>\r
  <p>6.18.8. Mais elimina\xE7\xF5es concedidas Descri\xE7\xE3o: Qual equipe conceder\xE1 mais elimina\xE7\xF5es na partida? Regras: Uma elimina\xE7\xE3o "concedida" significa que um membro dessa equipe ser\xE1 eliminado enquanto rebate. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o foi poss\xEDvel completar pelo menos 80% dos overs programados em nenhuma das entradas devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada antes da redu\xE7\xE3o. overs foram lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Run Outs em um super over n\xE3o contam.</p>\r
  <p>6.18.9. Mais alto primeiro over Descri\xE7\xE3o: Qual equipe marcar\xE1 mais corridas no primeiro over de suas entradas?Regras: O primeiro over deve ser conclu\xEDdo para que as apostas sejam v\xE1lidas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se durante o primeiro turno o turno for encerrado devido a fatores externos, incluindo mau tempo, todas as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Extras e penalidades s\xE3o executados na contagem em excesso para a liquida\xE7\xE3o.</p>\r
  <p>6.18.10. Maior n\xFAmero de corridas em grupos de overs Descri\xE7\xE3o: Qual equipe marcar\xE1 mais corridas ap\xF3s o primeiro n\xFAmero especificado de overs de suas entradas? , atinge seu objetivo ou a liquida\xE7\xE3o da aposta j\xE1 foi determinada. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs especificados foram lan\xE7ados no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Nos jogos da Primeira Classe, o mercado refere-se apenas aos primeiros turnos de cada equipe.</p>\r
  <p>6.18.11. Descri\xE7\xE3o da primeira parceria mais alta: Qual equipe marcar\xE1 mais corridas antes de perder seu primeiro wicket?Regras: Se a equipe rebatedora chegar ao final de seus overs atribu\xEDdos, atingir seu alvo ou declarar antes que o primeiro wicket caia, o resultado ser\xE1 o total acumulado . Para fins de liquida\xE7\xE3o, a les\xE3o do batedor que se retira n\xE3o conta como um postigo. Em partidas de overs limitados, as apostas ser\xE3o anuladas se as entradas forem reduzidas devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em empate Partidas de Primeira Classe, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Em partidas de Primeira Classe, o mercado refere-se apenas \xE0s primeiras entradas de cada equipe.</p>\r
  <p>6.18.12. Mercados de Partidas Descri\xE7\xE3o da Partida: Quantos quatros ser\xE3o atingidos na partida?Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados devido a fatores externos fatores, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de primeira classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Apenas quatros pontuado a partir do bast\xE3o (fora de qualquer lan\xE7amento - legal ou n\xE3o) contar\xE1 para o total de quatros. Overthrows, all run fours e extras n\xE3o contam. Fours marcados em um super over n\xE3o contam.</p>\r
  <p>6.18.13. Jogo Seis Descri\xE7\xE3o: Quantos seis ser\xE3o acertados na partida?Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. bat (fora de qualquer entrega \u2013 legal ou n\xE3o) contar\xE1 para o total de quatros. Derrubadas e extras n\xE3o contam. Seis marcados em um super over n\xE3o contam.</p>\r
  <p>6.18.14. Extras da Partida Descri\xE7\xE3o: Quantos extras ser\xE3o marcados na partida?Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Todas as entregas amplas, n\xE3o bolas, byes, leg byes e p\xEAnaltis na partida contam para o resultado final. Se houver corridas fora do bast\xE3o, bem como extras da mesma entrega, as corridas fora do bast\xE3o n\xE3o contam para o total final. Extras em um super over n\xE3o contam.</p>\r
  <p>6.18.15. Run Outs da Partida Descri\xE7\xE3o: Quantos run outs haver\xE1 na partida? Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes do redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Run outs em um super over n\xE3o contam. ser\xE1 pontuado na pontua\xE7\xE3o mais alta da partida?Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados devido a fatores externos, incluindo mau tempo , a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Todas as corridas, incluindo extras , conta para liquida\xE7\xE3o. Super overs n\xE3o contam.</p>\r
  <p>6.18.16. Top Batsman da Partida Descri\xE7\xE3o: Qual batedor marcar\xE1 mais corridas na partida? Regras: O resultado deste mercado \xE9 determinado no batedor com a maior pontua\xE7\xE3o individual na partida. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 50% dos overs programados para serem lan\xE7ados em qualquer um dos turnos no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo. As melhores apostas de batedores para partidas de Primeira Classe aplicam-se apenas aos primeiros turnos de cada equipe e ser\xE3o anuladas se menos de 200 overs tiverem sido arremessados, a menos que a liquida\xE7\xE3o da aposta j\xE1 foi determinada. Se um jogador foi nomeado no sorteio, mas depois \xE9 removido como um substituto de concuss\xE3o, esse jogador ainda ser\xE1 contado, assim como o jogador substituto. Se um batedor n\xE3o bate, mas foi nomeado no XI inicial, as apostas nesse batedor ser\xE3o Stand.Se um substituto (concuss\xE3o ou outro) n\xE3o nomeado no XI original obtiver a pontua\xE7\xE3o individual mais alta nas entradas da equipe, as apostas no mercado ser\xE3o anuladas. Quando dois ou mais jogadores marcarem o mesmo n\xFAmero de corridas, empate regras ser\xE3o aplicadas. Runs marcados em um super over n\xE3o contam.</p>\r
  <p>6.18.17. Match Top Bowler Descri\xE7\xE3o: Qual jogador levar\xE1 mais wickets na partida? Regras: O resultado deste mercado \xE9 determinado pelo jogador com mais wickets na partida. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 50% dos overs programados para serem lan\xE7ados em qualquer um innings no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo. As melhores apostas do jogador para partidas de Primeira Classe aplicam-se apenas \xE0s primeiras entradas de cada equipe e ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o de a aposta j\xE1 foi determinada. Se um jogador foi nomeado no sorteio, mas depois \xE9 removido como um substituto de concuss\xE3o, esse jogador ainda ser\xE1 contado, assim como o jogador substituto. Se um jogador n\xE3o lan\xE7ar, mas foi nomeado no XI inicial, as apostas nesse jogador ser\xE3o Stand. Se um substituto (concuss\xE3o, ou outro) n\xE3o nomeado no XI original conseguir o maior n\xFAmero de wickets, as apostas no mercado ser\xE3o anuladas. ser\xE1 o vencedor. Se houver dois ou mais jogadores com os mesmos wickets conquistados e corridas concedidas, as regras de dead heat ser\xE3o aplicadas. Os wickets conquistados em um super over n\xE3o contam. Se nenhum jogador fizer um wicket em uma entrada, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.18. Man of the Match Descri\xE7\xE3o: Quem ser\xE1 nomeado o homem do jogo? Regras: As apostas ser\xE3o determinadas no homem do jogo oficialmente declarado. Aplicam-se as regras de empate. Se nenhum homem do jogo for declarado oficialmente, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.19. Mercados de entregas fora da entrega Descri\xE7\xE3o: Quantas corridas ser\xE3o pontuadas na entrega especificada? Regras: O resultado ser\xE1 determinado pelo n\xFAmero de corridas adicionadas ao total da equipe, fora da entrega especificada. Para fins de liquida\xE7\xE3o, todas as bolas ilegais contam como entregas. Por exemplo, se um over come\xE7a com um largo, ent\xE3o a primeira entrega ser\xE1 liquidada como 1 e, embora n\xE3o tenha havido um ballbowl legal, a pr\xF3xima bola ser\xE1 considerada como entrega 2 para aquele over. rebatida ou uma rebatida livre deve ser rebatida por causa de um lan\xE7amento ilegal, as corridas marcadas com a entrega adicional n\xE3o contam. Todas as corridas, sem o bast\xE3o ou n\xE3o, est\xE3o inclu\xEDdas. Por exemplo, um largo com tr\xEAs corridas extras equivale a 4 corridas no total dessa entrega.</p>\r
  <p>6.18.20. Exact Runs Off Delivery Descri\xE7\xE3o: Exatamente quantas corridas ser\xE3o pontuadas na entrega especificada? Regras: Como \u201CFora de Entrega\u201D.</p>\r
  <p>6.18.21. Over Markets Runs in Over Descri\xE7\xE3o: Quantas corridas ser\xE3o pontuadas no over especificado? Regras: O over especificado deve ser conclu\xEDdo para que as apostas sejam v\xE1lidas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se um turno terminar durante um over, esse over ser\xE1 considerado completo, a menos que o turno seja encerrado devido a fatores externos, incluindo mau tempo, caso em que todas as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. n\xE3o come\xE7ar por qualquer motivo, todas as apostas ser\xE3o anuladas.Extras e execu\xE7\xF5es de penalidade na contagem especial para liquida\xE7\xE3o.</p>\r
  <p>6.18.22. Limite no Over Descri\xE7\xE3o: Haver\xE1 um limite marcado no over especificado? Regras: Como \u201CRuns in Over\u201D. Apenas os limites marcados a partir do bast\xE3o (fora de qualquer lan\xE7amento \u2013 legal ou n\xE3o) contar\xE3o como um limite. Derrubadas, todas as quatro corridas e extras n\xE3o contam como limites.</p>\r
  <p>6.18.23. Wicket in Over Descri\xE7\xE3o: Um wicket cair\xE1 no over especificado? Regras: Como \u201CRuns in Over\u201D. Para fins de liquida\xE7\xE3o, qualquer wicket contar\xE1, incluindo run outs. Um batedor se aposentando ferido n\xE3o conta como um postigo. Se um batedor estiver com o tempo esgotado ou for retirado, o wicket ser\xE1 considerado como tendo ocorrido na bola anterior. Ferido aposentado n\xE3o conta como demiss\xE3o.</p>\r
  <p>6.18.24. Over \xCDmpar/Par Descri\xE7\xE3o: O n\xFAmero de corridas marcadas no over especificado ser\xE1 par ou \xEDmpar? Regras: Como \u201CRuns in Over\u201D. Zero ser\xE1 considerado um n\xFAmero par.</p>\r
  <p>6.18.25. Mercados de Grupo Runs em Grupos de Overs Descri\xE7\xE3o: Quantas corridas ser\xE3o pontuadas no n\xFAmero especificado de overs? Regras: Se o n\xFAmero especificado de overs n\xE3o estiver completo, a aposta ser\xE1 anulada, a menos que a equipe esteja totalmente fora, declare, atinja sua meta ou a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. o total de entradas \xE9 reduzido em qualquer fase para menos de 80% dos overs m\xE1ximos declarados no momento em que a aposta foi feita, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o.</p>\r
  <p>6.18.26. Wickets em Grupos de Overs Descri\xE7\xE3o: Quantos postigos cair\xE3o no n\xFAmero especificado de overs? Regras: Se o n\xFAmero especificado de overs n\xE3o estiver completo, a aposta ser\xE1 anulada, a menos que a equipe esteja totalmente fora, declare, atinja sua meta ou a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. o total de entradas \xE9 reduzido em qualquer fase para menos de 80% dos overs m\xE1ximos declarados no momento em que a aposta foi feita, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. \xE9 considerado como tendo ocorrido na bola anterior. Ferido aposentado n\xE3o conta como demiss\xE3o.</p>\r
  <p>6.18.27. Execu\xE7\xF5es na Descri\xE7\xE3o da Sess\xE3o: Quantas execu\xE7\xF5es ser\xE3o pontuadas na sess\xE3o especificada? Regras: O resultado \xE9 determinado pelo n\xFAmero total de corridas marcadas na sess\xE3o especificada, independentemente de qual equipe as marcou. Se menos de 20 overs forem lan\xE7ados em uma sess\xE3o, as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada.</p>\r
  <p>6.18.28. Innings Markets Innings Runs Descri\xE7\xE3o: Quantas corridas uma equipe marcar\xE1 em um innings especificado? Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o de a aposta j\xE1 foi determinada antes da redu\xE7\xE3o. As apostas feitas em um turno futuro permanecer\xE3o v\xE1lidas independentemente das corridas marcadas em qualquer turno atual ou anterior. Em partidas de Primeira Classe empatadas, ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. As apostas tamb\xE9m ser\xE3o anuladas em partidas de primeira classe empatadas, se menos de 60 overs tiverem sido lan\xE7ados em entradas incompletas, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Se uma equipe declarar, esse turno ser\xE1 considerado completo para fins de liquida\xE7\xE3o.</p>\r
  <p>6.18.29. Innings Wickets Descri\xE7\xE3o: Quantos wickets a equipe de rebatidas perder\xE1 nas entradas atuais? Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o de a aposta j\xE1 foi determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Les\xF5es aposentadas n\xE3o contam como demiss\xE3o.</p>\r
  <p>6.18.30. Innings Fours Description: Quantos fours a equipe rebatedora acertar\xE1 em seus innings atuais? Regras: Igual \xE0 maioria dos Quatros.</p>\r
  <p>6.18.31. Innings Sixes Descri\xE7\xE3o: Quantos sixes a equipe de batedores acertar\xE1 em seus innings atuais? Regras: O mesmo que a maioria dos Seis.</p>\r
  <p>6.18.32. Innings Extras Descri\xE7\xE3o: Quantos extras ser\xE3o adicionados \xE0s entradas de rebatidas da equipe nomeada? Regras: Igual \xE0 maioria dos Extras.</p>\r
  <p>18.6.33. Innings Run Outs Descri\xE7\xE3o: Quantos run outs ser\xE3o concedidos nas entradas? Regras: Igual \xE0 maioria dos Extras.</p>\r
  <p>18.6.34. M\xE1ximo Over em Innings Descri\xE7\xE3o: Quantas corridas ser\xE3o pontuadas na pontua\xE7\xE3o mais alta das entradas atuais? Regras: Igual ao M\xE1ximo Over na Partida</p>\r
  <p>18.6.35. Innings Runs, \xCDmpar ou Par? Descri\xE7\xE3o: O total de entradas ser\xE1 par ou \xEDmpar? Regras: Se a entrada for abandonada, perdida ou n\xE3o houver resultado oficial, todas as apostas ser\xE3o anuladas.</p>\r
  <p>18.6.36. Innings para terminar com um limite Descri\xE7\xE3o: A \xFAltima bola do innings ser\xE1 um limite? Regras: Apenas os limites marcados a partir do bast\xE3o (fora de qualquer lan\xE7amento \u2013 legal ou n\xE3o) contar\xE3o como limite. Overthrows, all run fours e extras n\xE3o contam como limites. Em partidas de overs limitados, as apostas ser\xE3o anuladas se houver qualquer redu\xE7\xE3o no n\xFAmero de overs programados para serem lan\xE7ados no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo. Se a partida for abandonada ou n\xE3o houver resultado oficial, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.37. Corridas Exatas nas Entradas Descri\xE7\xE3o: Quantas corridas exatamente a equipe que rebater na entrada final pontuar\xE1? Regras: As apostas ser\xE3o determinadas de acordo com o resultado oficial. Em partidas com overs limitados, as apostas ser\xE3o anuladas se houver qualquer redu\xE7\xE3o no n\xFAmero de overs programados para serem lan\xE7ados no momento em que a aposta foi feita devido a fatores externos, incluindo clima. Se a partida for abandonada ou n\xE3o houver resultado oficial, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.38. Top Batsman in Innings Descri\xE7\xE3o: Qual batedor marcar\xE1 mais corridas para o time nomeado? Regras: O resultado deste mercado \xE9 determinado no batedor com a maior pontua\xE7\xE3o individual nas entradas de uma equipe. jogadas no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo. As melhores apostas de batedores para partidas de Primeira Classe aplicam-se apenas \xE0s primeiras entradas de cada equipe e ser\xE3o anuladas se menos de 200 saldos forem lan\xE7ados, a menos que a liquida\xE7\xE3o de a aposta j\xE1 foi determinada. Se um jogador foi nomeado no sorteio, mas depois \xE9 removido como um substituto de concuss\xE3o, esse jogador ainda ser\xE1 contado, assim como o jogador substituto. Se um batedor n\xE3o bate, mas foi nomeado no XI inicial, as apostas nesse batedor ser\xE3o Stand.Se um substituto (concuss\xE3o ou outro) n\xE3o nomeado no XI original obtiver a pontua\xE7\xE3o individual mais alta nas entradas da equipe, as apostas no mercado ser\xE3o anuladas. Quando dois ou mais jogadores marcarem o mesmo n\xFAmero de corridas, nas entradas As regras do dead-heat ser\xE3o aplicadas. Runs marcados em um super over n\xE3o contam.</p>\r
  <p>6.18.39. Top Bowler in Innings Descri\xE7\xE3o: Qual jogador levar\xE1 mais wickets para a equipe nomeada? Regras: O resultado deste mercado \xE9 determinado no lan\xE7ador com o maior n\xFAmero individual de wickets em uma entrada individual. foram arremessadas no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo. As melhores apostas do arremessador para partidas de Primeira Classe aplicam-se apenas \xE0s primeiras entradas de cada equipe e ser\xE3o anuladas se menos de 200 saldos forem arremessados, a menos que a liquida\xE7\xE3o da aposta j\xE1 foi determinada. Se um jogador foi nomeado no sorteio, mas depois \xE9 removido como um substituto de concuss\xE3o, esse jogador ainda ser\xE1 contado, assim como o jogador substituto. Se um jogador n\xE3o lan\xE7ar, mas foi nomeado no XI inicial, as apostas nesse jogador ser\xE3o v\xE1lidas.Se um substituto (concuss\xE3o, ou outro) n\xE3o nomeado no XI original tirar mais wickets, as apostas no mercado ser\xE3o anuladas.Se dois ou mais jogadores tiverem tirado o mesmo n\xFAmero de postigos, o jogador que tem conc ededo menor n\xFAmero de corridas ser\xE1 o vencedor. Se houver dois ou mais jogadores com os mesmos wickets conquistados e corridas concedidas, as regras de dead heat ser\xE3o aplicadas. Os wickets conquistados em um super over n\xE3o contam. Se nenhum jogador fizer um wicket em uma entrada, todas as apostas ser\xE3o anuladas.</p>\r
  <p>18.6.40. Last Man Standing Descri\xE7\xE3o: Qual batedor n\xE3o ser\xE1 eliminado ap\xF3s a conclus\xE3o do turno? Regras: Se houver dois ou mais batedores que n\xE3o estejam fora ap\xF3s a conclus\xE3o do turno, o vencedor para fins de liquida\xE7\xE3o ser\xE1 o \xFAltimo batedor a enfrentar uma entrega (legal ou n\xE3o). fora se eles n\xE3o estivessem mais no vinco tendo se retirado machucados ou n\xE3o batessem. Se mais de 11 jogadores baterem, o mercado ser\xE1 anulado. Em partidas de overs limitados, as apostas ser\xE3o anuladas se, ap\xF3s a coloca\xE7\xE3o da aposta, as entradas forem reduzidas de alguma forma devido a fatores externos, incluindo mau tempo.</p>\r
  <p>18.6.41. Batsmen Markets Batsman Runs Descri\xE7\xE3o: Quantas corridas o batedor nomeado marcar\xE1? Regras: Se o batedor terminar as entradas n\xE3o fora, como resultado de uma declara\xE7\xE3o, a equipe chegando ao final de seus overs atribu\xEDdos, ou a equipe atingindo seu alvo; sua pontua\xE7\xE3o ser\xE1 o resultado final. Se um batedor n\xE3o rebater, a aposta ser\xE1 anulada. Se um batedor n\xE3o estiver no 11 inicial, as apostas ser\xE3o anuladas. Se o batedor n\xE3o retornar mais tarde, o resultado final ser\xE1 o mesmo quando o batedor se retirou. Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno fatores externos, incluindo o mau tempo, a menos que o assentamento tenha sido determinado ou continue a ser determinado. O resultado ser\xE1 considerado determinado se a linha na qual a aposta foi feita for ultrapassada ou o batedor for dispensado. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada .Corridas marcadas em um super over n\xE3o contam.</p>\r
  <p>18.6.42. Combinadas Batsman Runs Descri\xE7\xE3o: Quantas corridas totais os batedores nomeados pontuar\xE3o? Regras: Como \u201CBatsman Runs\u201D, e se algum dos batedores nomeados n\xE3o rebater, a aposta ser\xE1 anulada, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada ou continue a ser determinada.</p>\r
  <p>18.6.43. Batsman Fours Descri\xE7\xE3o: Quantos fours o batedor nomeado acertar\xE1? Regras: Se um batedor terminar o innings n\xE3o fora, como resultado de uma declara\xE7\xE3o, a equipe chegando ao final de seus overs atribu\xEDdos, ou a equipe atingindo seu alvo; seu n\xFAmero de quatros ser\xE1 o resultado final. Se um batedor n\xE3o rebater, a aposta ser\xE1 anulada. Se um batedor n\xE3o estiver no XI inicial, as apostas ser\xE3o anuladas. Se um batedor se retirar machucado, mas retornar mais tarde, o total de quatros rebatidos por aquele batedor no turno contar\xE1. Se o batedor n\xE3o retornar mais tarde, o resultado final ser\xE1 o mesmo quando o batedor se retirou. a fatores externos, incluindo o mau tempo, a menos que o assentamento tenha sido determinado ou continue a ser determinado. O resultado ser\xE1 considerado determinado se a linha na qual a aposta foi feita for ultrapassada ou o batedor for dispensado. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada .Apenas quatros marcados a partir do bast\xE3o (fora de qualquer lan\xE7amento \u2013 legal ou n\xE3o) contar\xE3o para o total de quatros. Overthrows, all run fours e extras n\xE3o contam. Fours marcados em um super over n\xE3o contam.</p>\r
  <p>18.6.44. Batsman Sixes Descri\xE7\xE3o: Quantos seis o batedor nomeado acertar\xE1? Regras: Se um batedor terminar o innings n\xE3o fora, como resultado de uma declara\xE7\xE3o, a equipe chegando ao final de seus overs atribu\xEDdos, ou a equipe atingindo seu alvo; seu n\xFAmero de seis ser\xE1 o resultado final. Se um batedor n\xE3o rebater, a aposta ser\xE1 anulada. Se um batedor n\xE3o estiver no XI inicial, as apostas ser\xE3o anuladas. Se um batedor se retirar machucado, mas retornar mais tarde, o total de seis rebatidos por aquele batedor no turno contar\xE1. Se o batedor n\xE3o retornar mais tarde, o resultado final ser\xE1 o mesmo quando o batedor se retirou. a fatores externos, incluindo o mau tempo, a menos que o assentamento tenha sido determinado ou continue a ser determinado. O resultado ser\xE1 considerado determinado se a linha na qual a aposta foi feita for ultrapassada ou o batedor for dispensado. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada . Apenas seis marcados a partir do bast\xE3o (fora de qualquer lan\xE7amento \u2013 legal ou n\xE3o) contar\xE3o para o total de quatros. Derrubadas e extras n\xE3o contam. Seis marcados em um super over n\xE3o contam.</p>\r
  <p>18.6.45. Batsman Milestones Descri\xE7\xE3o: O batedor nomeado atingir\xE1 o marco especificado? Regras: Como \u201CBatsman Runs\u201D. Descri\xE7\xE3o do m\xE9todo de dispensa: Como o batedor nomeado ser\xE1 eliminado? Regras: Se o batedor especificado n\xE3o estiver fora, todas as apostas ser\xE3o anuladas. Se o batedor especificado se aposentar e n\xE3o retornar ao batedor mais tarde, todas as apostas ser\xE3o anuladas. Se esse batedor voltar a bater mais tarde e estiver fora, as apostas ser\xE3o v\xE1lidas.</p>\r
  <p>18.6.46. Mercados de parceria Queda do pr\xF3ximo postigo Descri\xE7\xE3o: Quantas corridas a equipe rebatedora ter\xE1 marcado quando o pr\xF3ximo postigo cair? Regras: Se a equipa rebatedora chegar ao fim dos overs atribu\xEDdos, atingir o alvo ou declarar antes do wicket especificado cair, o resultado ser\xE1 o total acumulado. partidas de overs, as apostas ser\xE3o anuladas se n\xE3o tiver sido poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada ou continue a ser determinada. O resultado ser\xE1 considerado determinado se a linha na qual a aposta foi colocada for ultrapassada ou o postigo em quest\xE3o cair. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido foi determinado.</p>\r
  <p>18.6.47. Next Man Out Descri\xE7\xE3o: Qual batedor ser\xE1 o pr\xF3ximo a ser dispensado? Regras: Se um dos batedores se retirar lesionado ou os batedores no vinco forem diferentes dos citados, as apostas feitas em ambos os batedores ser\xE3o declaradas nulas. Se n\xE3o houver mais postigos, todas as apostas ser\xE3o anuladas.</p>\r
  <p>6.18.48, Batsman Match Descri\xE7\xE3o da Aposta: Qual batedor na parceria atual marcar\xE1 mais corridas neste turno? Regras: As apostas ser\xE3o determinadas com base nas pontua\xE7\xF5es oficiais para os batedores especificados nas entradas, conforme detalhado na se\xE7\xE3o \u201CBatsman Runs\u201D acima. dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, ap\xF3s a aposta ser feita, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Regras: O resultado ser\xE1 determinado pelo m\xE9todo de dispensa do pr\xF3ximo postigo que cair. A aposentadoria do batedor n\xE3o conta como um postigo. Se um batedor for retirado, todas as apostas ser\xE3o anuladas. Se o postigo especificado n\xE3o cair, todas as apostas ser\xE3o anuladas. Mercados de Jogadores Batsman Matchbet Descri\xE7\xE3o: Qual dos jogadores nomeados marcar\xE1 mais corridas? Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. , as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores devem ser nomeados no XI inicial ou aparecer como substitutos. Se um deles n\xE3o bater, todas as apostas ainda ser\xE3o pagas. As corridas marcadas em um super over n\xE3o contam. Descri\xE7\xE3o da Aposta de Jogo do Bowler: Qual dos jogadores nomeados levar\xE1 mais wickets? Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. , as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores devem ser nomeados no XI inicial ou aparecer como substitutos. Se um deles n\xE3o for lan\xE7ado, todas as apostas ainda ser\xE3o pagas. Os wickets obtidos em um super over n\xE3o contam. All-Rounder Matchbet Descri\xE7\xE3o: Qual dos jogadores nomeados marcar\xE1 mais pontos no sistema de pontua\xE7\xE3o de desempenho do jogador? Regras: Os pontos s\xE3o marcados da seguinte forma: 1 ponto por corrida, 20 pontos por postigo, 10 pontos por recep\xE7\xE3o, 25 pontos por stumping. os overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs tiverem sido lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores devem ser nomeados no XI inicial, ou aparecer como substitutos. Se um dos jogadores n\xE3o rebater ou arremessar posteriormente, todas as apostas ainda ser\xE3o liquidadas. Os pontos marcados em um super over n\xE3o contam. Descri\xE7\xE3o da Aposta de Jogo do Guardi\xE3o: Qual dos goleiros nomeados marca mais pontos no sistema de pontua\xE7\xE3o de desempenho do jogador? Regras: Os pontos s\xE3o marcados como acima. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores nomeados devem iniciar a partida como goleiros ou aparecer como substitutos, mas se sua fun\xE7\xE3o de jogador mudar por qualquer motivo, todas as apostas ser\xE3o ainda ser\xE3o resolvidos de acordo com o sistema de pontua\xE7\xE3o acima. Os pontos marcados em um super over n\xE3o contam. Mercados pop-up Free Hit Descri\xE7\xE3o: Quantas corridas de equipe ser\xE3o pontuadas com a entrega de free hit? Regras: O resultado ser\xE1 determinado pelo n\xFAmero de corridas somado ao total da equipe, fora da entrega especificada. Se o livre for lan\xE7ado novamente por causa de um lan\xE7amento ilegal, as corridas marcadas com o segundo livre n\xE3o contam. Extras e corridas de penalidade contar\xE3o para a liquida\xE7\xE3o. o resultado ser\xE1 1. Em seguida, outro mercado de hits gr\xE1tis pode ser oferecido.Corrida para 'X' Runs Descri\xE7\xE3o: Qual batedor atingir\xE1 o n\xFAmero especificado de corridas primeiro? Regras: Todas as apostas s\xE3o v\xE1lidas, independentemente de qualquer redu\xE7\xE3o. Se nenhum dos batedores atingir o n\xFAmero especificado de corridas, os mercados ser\xE3o resolvidos como 'Nenhum'. Pr\xF3ximo ao Hit Six Descri\xE7\xE3o: Qual batedor vai acertar os pr\xF3ximos seis? Regras: Todas as apostas s\xE3o v\xE1lidas, independentemente de qualquer redu\xE7\xE3o. Se nenhum dos batedores marcar um seis ap\xF3s a aposta ser oferecida, ent\xE3o o mercado ser\xE1 definido como 'Nenhum'. Derrubadas e extras n\xE3o contam. Pr\xF3ximo a tirar um postigo Descri\xE7\xE3o: Qual jogador vai levar o pr\xF3ximo postigo neste turno? Regras: Todas as apostas s\xE3o v\xE1lidas, independentemente de qualquer redu\xE7\xE3o. Se nenhum dos jogadores nomeados receber um wicket, o mercado ser\xE1 liquidado como "Nenhuma das op\xE7\xF5es acima".<br>\r
    Run outs, tempo esgotado, aposentado e qualquer outro m\xE9todo de expuls\xE3o n\xE3o concedido a um jogador espec\xEDfico ser\xE1 definido como 'Nenhuma das op\xE7\xF5es acima'. Descri\xE7\xE3o da vit\xF3ria: Em qual das entradas da equipe nomeada a partida ser\xE1 conclu\xEDda? Regras: Todas as apostas ser\xE3o anuladas se n\xE3o houver um resultado oficial. Em partidas de overs limitados, todas as apostas ser\xE3o anuladas se, ap\xF3s a coloca\xE7\xE3o da aposta, o m\xE1ximo de overs poss\xEDvel for reduzido de alguma forma. Mercados Unilaterais Ambas as equipes marcam 'X' Descri\xE7\xE3o das corridas: Ambas as equipes marcar\xE3o o n\xFAmero especificado de corridas? Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados em ambos os turnos no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 100 overs forem lan\xE7ados nas primeiras entradas de qualquer equipe, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Apenas as corridas marcadas no primeiro turno contam Se uma equipe declarar que o turno ser\xE1 considerado completo para fins de liquida\xE7\xE3o. M\xE9todo de dispensa do batedor Descri\xE7\xE3o: Algum dos batedores nomeados ser\xE1 dispensado no m\xE9todo especificado? Regras: Todas as apostas ser\xE3o liquidadas, independentemente de o batedor permanecer fora ou se aposentar lesionado, no final do turno. M\xE9todo de dispensa de ambos os batedores Descri\xE7\xE3o: Ambos os batedores nomeados ser\xE3o dispensados \u200B\u200Bno m\xE9todo especificado? Regras: Como \u201CM\xE9todo de dispensa do batedor\u201D. Corridas de entregas consecutivas Descri\xE7\xE3o: Quantas corridas ser\xE3o pontuadas em cada uma das entregas especificadas? Regras: Como \u201CEntrega de sa\xEDda\u201D, exceto que o n\xFAmero especificado de corridas deve ser pontuado em ambas as entregas nomeadas. Descri\xE7\xE3o da entrega de wicket: Um wicket cair\xE1 na entrega especificada? Regras: A entrega especificada deve ser conclu\xEDda para que as apostas sejam v\xE1lidas. Para fins de liquida\xE7\xE3o, qualquer wicket contar\xE1, incluindo run outs. Um batedor se aposentando ferido n\xE3o conta como um postigo. Se um batedor estiver esgotado ou for retirado, o wicket ser\xE1 considerado como tendo ocorrido na bola anterior.Ambos os batedores marcam 'X' corridas em over Descri\xE7\xE3o: Ambos os batedores marcar\xE3o o n\xFAmero especificado de corridas na over? Regras: O over especificado deve ser conclu\xEDdo para que as apostas sejam v\xE1lidas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se um turno terminar durante um over, esse over ser\xE1 considerado completo, a menos que o turno seja encerrado devido a fatores externos, incluindo mau tempo, caso em que todas as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. n\xE3o come\xE7ar por qualquer motivo, todas as apostas ser\xE3o anuladas. As corridas devem ser pontuadas fora do bast\xE3o para contar para a liquida\xE7\xE3o. As apostas ser\xE3o liquidadas independentemente de qualquer um dos batedores especificados ser dispensado ou aposentado lesionado antes do in\xEDcio do over.Ambos os batedores marcam um limite no over Descri\xE7\xE3o: Ambos os batedores pontuam um fronteira no fim? Regras: Como "Ambos os batedores marcam 'X' Runs in Over". Ambos os quatros e seis contam como limites. Apenas quatro ou seis marcados a partir do bast\xE3o (fora de qualquer lan\xE7amento \u2013 legal ou n\xE3o) contar\xE3o.Derrubadas, todas as corridas de quatro e extras n\xE3o contam. Tanto um quatro quanto um seis devem ser pontuados em um over Descri\xE7\xE3o: Tanto um quatro quanto um seis ser\xE3o pontuados no over? Regras: O over especificado deve ser conclu\xEDdo para que as apostas sejam v\xE1lidas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se um turno terminar durante um over, esse over ser\xE1 considerado completo, a menos que o turno seja encerrado devido a fatores externos, incluindo mau tempo, caso em que todas as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se o over n\xE3o come\xE7ar por qualquer motivo, todas as apostas ser\xE3o anuladas. Apenas quatro ou seis marcados do bast\xE3o (fora de qualquer entrega \u2013 legal ou n\xE3o) contar\xE3o. Derrubadas, todas as quatro corridas e extras n\xE3o contam.Marcos do Combo Batsman e Bowler Descri\xE7\xE3o: O batedor nomeado e o jogador nomeado alcan\xE7ar\xE3o seus marcos especificados? Regras: Para batedor \u2013 o mesmo que \u201CBatsman Runs\u201D. Em jogos de primeira classe, apenas as corridas marcadas nas primeiras entradas contar\xE3o. Se um batedor n\xE3o estiver no XI inicial ou for substitu\xEDdo, as apostas ser\xE3o anuladas. Para arremessador \u2013 se um arremessador n\xE3o arremessar, ser\xE1 considerado que ele tirou 0 postigos. Se um jogador n\xE3o estiver no XI inicial ou for substitu\xEDdo, as apostas ser\xE3o anuladas. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados nas entradas relevantes devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. as apostas ser\xE3o anuladas se menos de 200 overs tiverem sido lan\xE7ados, a menos que as entradas de boliche do jogador estejam completas. O resultado ser\xE1 considerado determinado se as linhas nas quais a aposta foi feita forem ultrapassadas. Nos jogos de Primeira Classe, apenas os wickets do primeiro turno contar\xE3o e ser\xE3o executados. Wickets e corridas marcados em um super over n\xE3o contam.Batsmen Combo Milestones Descri\xE7\xE3o: Ambos os batedores alcan\xE7ar\xE3o seus marcos especificados? Regras: Igual a \u201CCombined Batsman Runs\u201D.Notas para todos os MarketsJogadores expulsos/aposentados Um jogador expulso \xE9 visto como retirado, ent\xE3o ser\xE1 considerado um wicket.Substitui\xE7\xF5es por concuss\xE3o Quando um jogador deixa o campo como substituto por concuss\xE3o , isso n\xE3o contar\xE1 como um postigo. Se o jogador n\xE3o retornar mais tarde, o resultado final ser\xE1 como estava quando o jogador deixou o campo. Quando um jogador entra na partida como substituto de concuss\xE3o, para fins de liquida\xE7\xE3o, tanto ele quanto o jogador substitu\xEDdo ser\xE3o considerados como tendo desempenhado um papel completo na partida.P\xEAnaltis ap\xF3s a conclus\xE3o de um turno. o in\xEDcio do turno do outro time n\xE3o contar\xE1 para a liquida\xE7\xE3o dos mercados nos turnos anteriores. Descri\xE7\xE3o do Desempenho do Jogador: escolha se um jogador marcar\xE1 mais ou menos do que uma determinada pontua\xE7\xE3o - com base em pontos no estilo Fantasia. Regras: Os jogadores marcam 1 ponto por corrida, 20 pontos por postigo, 10 pontos por captura e 25 pontos por stumping.</p>\r
<p>18.6.49. M\xE9todo da pr\xF3xima dispensa do wicket Descri\xE7\xE3o: Como o pr\xF3ximo batedor ser\xE1 eliminado? Regras: O resultado ser\xE1 determinado pelo m\xE9todo de dispensa do pr\xF3ximo postigo que cair. A aposentadoria do batedor n\xE3o conta como um postigo. Se um batedor for retirado, todas as apostas ser\xE3o anuladas. Se o postigo especificado n\xE3o cair, todas as apostas ser\xE3o anuladas.</p>\r
<p>6.18.50. Mercados de jogadores Batsman Matchbet Descri\xE7\xE3o: Qual dos jogadores nomeados marcar\xE1 mais corridas? Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. , as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores devem ser nomeados no XI inicial ou aparecer como substitutos. Se um deles n\xE3o bater, todas as apostas ainda ser\xE3o liquidadas. As corridas marcadas em um super over n\xE3o contam.</p>\r
<p>18.6.51. Bowler Matchbet Descri\xE7\xE3o: Qual dos jogadores nomeados levar\xE1 mais wickets? Regras: Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. , as apostas ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores devem ser nomeados no XI inicial ou aparecer como substitutos. Se qualquer um n\xE3o rolar, todas as apostas ainda ser\xE3o pagas. Os wickets recebidos em um super over n\xE3o contam.</p>\r
  <p>18.6.52. All-Rounder Matchbet Descri\xE7\xE3o: Qual dos jogadores nomeados marcar\xE1 mais pontos no sistema de pontua\xE7\xE3o de desempenho do jogador? Regras: Os pontos s\xE3o marcados da seguinte forma: 1 ponto por corrida, 20 pontos por postigo, 10 pontos por recep\xE7\xE3o, 25 pontos por stumping. os overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 200 overs tiverem sido lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores devem ser nomeados no XI inicial, ou aparecer como substitutos. Se um dos jogadores n\xE3o rebater ou arremessar posteriormente, todas as apostas ainda ser\xE3o liquidadas. Os pontos marcados em um super over n\xE3o contam.</p>\r
  <p>18.6.53. Keeper Matchbet Descri\xE7\xE3o: Qual dos goleiros nomeados marca mais pontos no sistema de pontua\xE7\xE3o de desempenho do jogador? Regras: Os pontos s\xE3o marcados como acima. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados em qualquer turno devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. ser\xE3o anuladas se menos de 200 overs forem lan\xE7ados, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Ambos os jogadores nomeados devem iniciar a partida como goleiros ou aparecer como substitutos, mas se sua fun\xE7\xE3o de jogador mudar por qualquer motivo, todas as apostas ser\xE3o ainda ser\xE3o liquidados de acordo com o sistema de pontua\xE7\xE3o acima. Os pontos marcados em um super over n\xE3o contam.</p>\r
  <p>18.6.54. Mercados pop-up Descri\xE7\xE3o do acerto gratuito: Quantas corridas de equipe ser\xE3o pontuadas com a entrega de acertos gratuitos? Regras: O resultado ser\xE1 determinado pelo n\xFAmero de corridas somado ao total da equipe, fora da entrega especificada. Se o livre for lan\xE7ado novamente por causa de um lan\xE7amento ilegal, as corridas marcadas com o segundo livre n\xE3o contam. Extras e corridas de penalidade contar\xE3o para a liquida\xE7\xE3o. o resultado ser\xE1 1. Em seguida, outro mercado de hits gr\xE1tis pode ser oferecido.</p>\r
  <p>18.6.55. Race to 'X' Runs Descri\xE7\xE3o: Qual batedor atingir\xE1 o n\xFAmero especificado de corridas primeiro? Regras: Todas as apostas s\xE3o v\xE1lidas, independentemente de qualquer redu\xE7\xE3o. Se nenhum dos batedores atingir o n\xFAmero especificado de corridas, os mercados ser\xE3o resolvidos como 'Nenhum'.</p>\r
  <p>18.6.56. Pr\xF3ximo ao Hit Six Descri\xE7\xE3o: Qual batedor vai acertar os pr\xF3ximos seis? Regras: Todas as apostas s\xE3o v\xE1lidas, independentemente de qualquer redu\xE7\xE3o. Se nenhum dos batedores marcar seis ap\xF3s a aposta ser oferecida, o mercado ser\xE1 liquidado como 'Nenhum'. Derrubadas e extras n\xE3o contam.</p>\r
  <p>18.6.57. Next to Take a Wicket Descri\xE7\xE3o: Qual jogador levar\xE1 o pr\xF3ximo postigo neste turno? Regras: Todas as apostas s\xE3o v\xE1lidas, independentemente de qualquer redu\xE7\xE3o. Se nenhum dos jogadores nomeados receber um wicket, o mercado ser\xE1 liquidado como "Nenhuma das op\xE7\xF5es acima". Run outs, time out, aposentado e qualquer outro m\xE9todo de expuls\xE3o n\xE3o concedido a um jogador espec\xEDfico ser\xE3o resolvidos como "Nenhuma das op\xE7\xF5es acima".</p>\r
  <p>18.6.58. Descri\xE7\xE3o da vit\xF3ria: Em qual das entradas da equipe nomeada a partida ser\xE1 conclu\xEDda? Regras: Todas as apostas ser\xE3o anuladas se n\xE3o houver um resultado oficial. Em partidas de overs limitados, todas as apostas ser\xE3o anuladas se, ap\xF3s a coloca\xE7\xE3o da aposta, o m\xE1ximo de overs poss\xEDvel for reduzido de alguma forma.</p>\r
  <p>18.6.59. Mercados unilaterais Ambas as equipes marcam 'X' corridas Descri\xE7\xE3o: Ambas as equipes marcar\xE3o o n\xFAmero especificado de corridas? Regras: Em partidas de overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados para serem lan\xE7ados em ambos os turnos no momento em que a aposta foi feita devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada antes da redu\xE7\xE3o. Em partidas de Primeira Classe empatadas, as apostas ser\xE3o anuladas se menos de 100 overs forem lan\xE7ados nas primeiras entradas de qualquer equipe, a menos que a liquida\xE7\xE3o da aposta j\xE1 tenha sido determinada. Apenas corridas marcadas no primeiro turno contam Se uma equipe declarar que o turno ser\xE1 considerado completo para fins de liquida\xE7\xE3o.</p>\r
  <p>18.6.60. Qualquer um dos batedores do m\xE9todo de dispensa Descri\xE7\xE3o: Algum dos batedores nomeados ser\xE1 dispensado no m\xE9todo especificado? Regras: Todas as apostas ser\xE3o liquidadas, independentemente de o batedor permanecer fora ou se aposentar lesionado, no final das entradas.</p>\r
  <p>6.18.61. M\xE9todo de dispensa de ambos os batedores Descri\xE7\xE3o: Os dois batedores nomeados ser\xE3o dispensados \u200B\u200Bno m\xE9todo especificado? Regras: Como \u201CM\xE9todo de demiss\xE3o de qualquer batedor\u201D.</p>\r
  <p>18.6.62. Runs off entregas consecutivas Descri\xE7\xE3o: Quantas corridas ser\xE3o pontuadas em cada uma das entregas especificadas? Regras: Como \u201CRuns Off Delivery\u201D, exceto que o n\xFAmero especificado de corridas deve ser pontuado em ambas as entregas nomeadas.</p>\r
  <p>18.6.63. Wicket off Descri\xE7\xE3o da entrega: Um postigo cair\xE1 na entrega especificada? Regras: A entrega especificada deve ser conclu\xEDda para que as apostas sejam v\xE1lidas. Para fins de liquida\xE7\xE3o, qualquer wicket contar\xE1, incluindo run outs. Um batedor se aposentando ferido n\xE3o conta como um postigo. Se um batedor estiver com o tempo esgotado ou for retirado, o wicket ser\xE1 considerado como tendo ocorrido na bola anterior.</p>\r
  <p>18.6.64. Ambos os batedores marcam 'X' corridas no over Descri\xE7\xE3o: Ambos os batedores marcar\xE3o o n\xFAmero especificado de corridas no over? Regras: O over especificado deve ser conclu\xEDdo para que as apostas sejam v\xE1lidas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se um turno terminar durante um over, esse over ser\xE1 considerado completo, a menos que o turno seja encerrado devido a fatores externos, incluindo mau tempo, caso em que todas as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. n\xE3o come\xE7ar por qualquer motivo, todas as apostas ser\xE3o anuladas. As corridas devem ser pontuadas fora do bast\xE3o para contar para a liquida\xE7\xE3o. As apostas ser\xE3o liquidadas independentemente de qualquer um dos batedores especificados ser dispensado ou aposentado lesionado antes do in\xEDcio do over.</p>\r
  <p>18.6.65. Ambos os batedores marcar\xE3o um limite no over Descri\xE7\xE3o: Ambos os batedores marcar\xE3o um limite no over? Regras: Como "Ambos os batedores marcam 'X' Runs in Over". Ambos os quatros e seis contam como limites. Apenas quatro ou seis marcados a partir do bast\xE3o (fora de qualquer lan\xE7amento \u2013 legal ou n\xE3o) contar\xE3o. Derrubadas, todas as quatro corridas e extras n\xE3o contam.</p>\r
  <p>18.6.66. Tanto um quatro quanto um seis ser\xE3o pontuados em um over Descri\xE7\xE3o: Tanto um quatro quanto um seis ser\xE3o pontuados no over? Regras: O over especificado deve ser conclu\xEDdo para que as apostas sejam v\xE1lidas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se um turno terminar durante um over, esse over ser\xE1 considerado completo, a menos que o turno seja encerrado devido a fatores externos, incluindo mau tempo, caso em que todas as apostas ser\xE3o anuladas, a menos que a liquida\xE7\xE3o j\xE1 tenha sido determinada. Se o over n\xE3o come\xE7ar por qualquer motivo, todas as apostas ser\xE3o anuladas. Apenas quatro ou seis marcados do bast\xE3o (fora de qualquer entrega \u2013 legal ou n\xE3o) contar\xE3o. Derrubadas, todas as quatro corridas e extras n\xE3o contam.</p>\r
  <p>18.6.67. Marcos do combo Batsman e Bowler Descri\xE7\xE3o: O batedor nomeado e o jogador nomeado alcan\xE7ar\xE3o seus marcos especificados? Regras: Para batedor \u2013 o mesmo que \u201CBatsman Runs\u201D. Em jogos de primeira classe, apenas as corridas marcadas nas primeiras entradas contar\xE3o. Se um batedor n\xE3o estiver no XI inicial, ou substitu\xEDdo, as apostas ser\xE3o anuladas. Se um jogador n\xE3o estiver no XI inicial ou for substitu\xEDdo, as apostas ser\xE3o anuladas. Em partidas com overs limitados, as apostas ser\xE3o anuladas se n\xE3o for poss\xEDvel completar pelo menos 80% dos overs programados nas entradas relevantes devido a fatores externos, incluindo mau tempo, a menos que a liquida\xE7\xE3o tenha sido determinada. as apostas ser\xE3o anuladas se menos de 200 overs tiverem sido lan\xE7ados, a menos que as entradas de boliche do jogador estejam completas. O resultado ser\xE1 considerado determinado se as linhas nas quais a aposta foi feita forem ultrapassadas. Nos jogos de Primeira Classe, apenas os wickets do primeiro turno contar\xE3o e ser\xE3o executados. Wickets e corridas marcados em um super over n\xE3o contam.</p>\r
  <p>18.6.68. Marcos do Combo Batsmen Descri\xE7\xE3o: Ambos os batedores atingir\xE3o seus marcos especificados? Regras: O mesmo que \u201CCorridas de Batedor Combinadas\u201D.</p>\r
  <p>18.6.69. Notas para todos os MarketsJogadores expulsos/aposentados Um jogador expulso \xE9 visto como desistente, por isso ser\xE1 considerado um postigo. Se o jogador n\xE3o retornar mais tarde, o resultado final ser\xE1 como estava quando o jogador deixou o campo. Quando um jogador entra na partida como substituto de concuss\xE3o, para fins de liquida\xE7\xE3o, tanto ele quanto o jogador substitu\xEDdo ser\xE3o considerados como tendo desempenhado um papel completo na partida.P\xEAnaltis ap\xF3s a conclus\xE3o de um turno. o in\xEDcio das entradas da outra equipe n\xE3o contar\xE1 para a liquida\xE7\xE3o dos mercados nas entradas anteriores.</p>\r
  <p>6.18.70. Desempenho do jogador</p>\r
  <p>6.19. Ab\xF3bora</p>\r
  <p>6.19.1. Se um set terminar antes que o ponto X seja alcan\xE7ado, este mercado (Quem marca [Xth] ponto no set [y]) \xE9 considerado nulo (cancelado)</p>\r
  <p>6.19.2. Se os mercados permanecerem abertos com uma pontua\xE7\xE3o incorreta que tenha um impacto significativo nos pre\xE7os, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.19.3. Se os jogadores/equipes forem exibidos incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.19.4. Se um jogador se aposentar, perder a partida ou for desqualificado, todos os mercados indecisos ser\xE3o considerados nulos</p>\r
  <p>6.19.5. As dedu\xE7\xF5es oficiais de pontos ser\xE3o levadas em considera\xE7\xE3o para todos os mercados indeterminados. Os mercados que j\xE1 foram determinados n\xE3o levar\xE3o em conta as dedu\xE7\xF5es.</p>\r
  <p>6.19.6. Se os pontos de penaliza\xE7\xE3o forem atribu\xEDdos pelo \xE1rbitro, todas as apostas nesse jogo ser\xE3o v\xE1lidas.</p>\r
  <p>6.20. Regras australianas</p>\r
  <p>6.20.1. Todos os mercados excluem horas extras, salvo indica\xE7\xE3o em contr\xE1rio</p>\r
  <p>6.20.2. Regular 80 Minutos: Os mercados s\xE3o baseados no resultado no final de um jogo programado de 80 minutos, salvo indica\xE7\xE3o em contr\xE1rio. Isso inclui qualquer les\xE3o adicional ou tempo de paralisa\xE7\xE3o, mas n\xE3o inclui tempo extra.</p>\r
  <p>6.20.3. Se as probabilidades forem oferecidas com um tempo de jogo incorreto (mais de 2 minutos), nos reservamos o direito de anular as apostas.</p>\r
  <p>6.20.4. Se os nomes das equipes ou a categoria forem exibidos incorretamente, nos reservamos o direito de anular as apostas</p>\r
  <p>6.21. Counter-Strike: Ofensiva Global</p>\r
  <p>6.21.1. Se nenhuma bomba for plantada, o mercado ([mapNr!] Map [roundNr!] Round - Bomba desativada) ser\xE1 considerado nulo</p>\r
  <p>6.21.2. Os mercados n\xE3o consideram horas extras, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>6.21.3. Os mercados ser\xE3o liquidados com base nos resultados publicados oficialmente.</p>\r
  <p>6.21.4. Se o jogo estiver listado incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.21.5. No caso de um walkover ou aposentadoria, todos os mercados indecisos s\xE3o anulados.</p>\r
  <p>6.21.6. Se uma partida ou mapa for repetido devido a uma desconex\xE3o ou problemas t\xE9cnicos n\xE3o relacionados ao jogador, todos os mercados indecisos ser\xE3o anulados. A partida ou mapa repetido ser\xE1 tratado separadamente.</p>\r
  <p>6.21.7. Se o n\xFAmero padr\xE3o de mapas for alterado ou diferir daqueles oferecidos para fins de apostas, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.22. Dota 2</p>\r
  <p>6.22.1. X\xBA mapa \u2013 1\xBA \xE9gide: A liquida\xE7\xE3o \xE9 determinada pela equipe que pega a \xC9gide do Imortal, e n\xE3o por quem mata Roshan</p>\r
  <p>6.22.2. X\xBA mapa \u2013 1\xAA torre e X\xBA mapa \u2013 1\xBA quartel: Para fins de liquida\xE7\xE3o, todos os m\xE9todos de destrui\xE7\xE3o da torre ser\xE3o levados em considera\xE7\xE3o (destruir o oponente e o Creep; destruir por Negar)</p>\r
  <p>6.22.3. Os mercados ser\xE3o liquidados com base nos resultados publicados oficialmente.</p>\r
  <p>6.22.4. Se o jogo estiver listado incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.22.5. No caso de um walkover ou aposentadoria, todos os mercados indecisos s\xE3o anulados.</p>\r
  <p>6.22.6. Se uma partida ou mapa for repetido devido a uma desconex\xE3o ou problemas t\xE9cnicos n\xE3o relacionados ao jogador, todos os mercados indecisos ser\xE3o anulados. A partida ou mapa repetido ser\xE1 tratado separadamente.</p>\r
  <p>6.22.7. Se o n\xFAmero padr\xE3o de mapas for alterado ou diferir daqueles oferecidos para fins de apostas, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.23. Liga dos lend\xE1rios</p>\r
  <p>6.23.1. X\xBA mapa \u2013 1\xBA inibidor e X\xBA mapa \u2013 1\xAA torre: Para fins de liquida\xE7\xE3o, todos os m\xE9todos de destrui\xE7\xE3o ser\xE3o levados em considera\xE7\xE3o</p>\r
  <p>6.23.2. Os mercados n\xE3o consideram horas extras, salvo indica\xE7\xE3o em contr\xE1rio.</p>\r
  <p>6.23.3. Os mercados ser\xE3o liquidados com base nos resultados publicados oficialmente.</p>\r
  <p>6.23.4. Se o jogo estiver listado incorretamente, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.23.5. No caso de um walkover ou aposentadoria, todos os mercados indecisos s\xE3o anulados.</p>\r
  <p>6.23.6. Se uma partida ou mapa for repetido devido a uma desconex\xE3o ou problemas t\xE9cnicos n\xE3o relacionados ao jogador, todos os mercados indecisos ser\xE3o anulados. A partida ou mapa repetido ser\xE1 tratado separadamente.</p>\r
  <p>6.23.7. Se o n\xFAmero padr\xE3o de mapas for alterado ou diferir daqueles oferecidos para fins de apostas, nos reservamos o direito de anular as apostas.</p>\r
  <p>6.24. eSports FIFA</p>\r
  <p>6.24.1. Dura\xE7\xE3o da partida de eSports Battle - 2x4 minutos.</p>\r
  <p>6.24.2. Dura\xE7\xE3o da partida da Liga Pro EFootball - 2x6 minutos.</p>\r
  <p>6.24.3. Todos os Mercados ser\xE3o liquidados conforme estabelecido nas Regras Gerais e do Mercado de Futebol.</p>\r
  <p>6.25. eSports NBA2K</p>\r
  <p>6.25.1. Dura\xE7\xE3o da partida \u2013 4x5 minutos. Isso inclui horas extras.</p>\r
  <p>6.25.2. Todos os Mercados ser\xE3o liquidados conforme estabelecido nas Regras Gerais e de Mercado de Basquetebol.</p>\r
  <p>6.26. F\xF3rmula 1</p>\r
  <p>6.26.1. Todas as apostas de corrida s\xE3o liquidadas com base na classifica\xE7\xE3o oficial da FIA no momento da apresenta\xE7\xE3o do p\xF3dio, com desqualifica\xE7\xF5es/penaliza\xE7\xF5es subsequentes desconsideradas.</p>\r
  <p>6.26.2. Todos os pilotos que completam 90% das voltas da corrida s\xE3o considerados finalistas classificados de acordo com a classifica\xE7\xE3o oficial da FIA. No entanto, todos os pilotos recebem uma classifica\xE7\xE3o e, para fins de apostas frente a frente, essa classifica\xE7\xE3o deve ser aplicada.</p>\r
</section>\r
\r
<section>\r
  <p><strong>7. Esportes Virtuais</strong></p>\r
  <p>7.1. Futebol virtual</p>\r
  <p>7.1.1. Os Modos de Futebol Virtual fornecem experi\xEAncia de apostas com dinheiro real 24/7/365 no futebol virtual. As competi\xE7\xF5es s\xE3o geradas continuamente e as apostas podem ser feitas a qualquer momento, mesmo dentro de uma temporada.</p>\r
  <p>7.1.2. Estrutura de jogoCada \u200B\u200Bmodo tem uma estrutura de torneio diferente: Virtual Football League Mode VFLM:16 TeamsJogos em casa e fora30 dias de jogo8 partidas simult\xE2neas por dia de jogo240 partidas por temporada Fase de Grupos Virtual Football World Cup VFWC:32 Times (8 grupos de 4 times por grupo)12 partes da jornada (3 jornadas de 4 partes por dia da partida)4 partidas simult\xE2neas por rodada da jornada48 partidas por fase de gruposKnock-Out-Stage16 Equipes5 rodada (R16[1..4]; R16[5...8]; R8 ; Semifinais; Final e 3\xBA Lugar)4 partidas simult\xE2neas (R16[1..4]; R16[5...8]; R8);2 partidas simult\xE2neas (Semi Finais; Final e 3\xBA Lugar)16 partidas por knock- fora do palco.</p>\r
  <p>\u25CF 16 equipes</p>\r
  <p>\u25CF Jogos em casa e fora</p>\r
  <p>\u25CF 30 dias de jogo</p>\r
  <p>\u25CF 8 partidas simult\xE2neas por dia de partida</p>\r
  <p>\u25CF 240 partidas por temporada Fase de Grupos Virtual Football World Cup VFWC:</p>\r
  <p>\u25CF 32 equipes (8 grupos de 4 equipes por grupo)</p>\r
  <p>\u25CF 12 partes do dia de jogo (3 dias de jogo de 4 partes por dia de jogo)</p>\r
  <p>\u25CF 4 partidas simult\xE2neas por dia de partida</p>\r
  <p>\u25CF 48 partidas por fase de grupos</p>\r
  <p>\u25CF Palco Knock-Out</p>\r
  <p>\u25CF 16 equipes</p>\r
  <p>\u25CF 5 rodadas (R16[1..4]; R16[5...8]; R8; Semifinais; Final e 3\xBA lugar)</p>\r
  <p>\u25CF 4 partidas simult\xE2neas (R16[1..4]; R16[5...8]; R8);</p>\r
  <p>\u25CF 2 partidas simult\xE2neas (semi-finais; final e 3\xBA lugar)</p>\r
  <p>\u25CF 16 partidas por fase eliminat\xF3ria.</p>\r
  <p>7.2. basquete virtual</p>\r
  <p>7.2.1. O VBL oferece experi\xEAncia de apostas com dinheiro real 24/7/365 no basquete virtual. A liga \xE9 composta por 16 equipes e as temporadas acontecem continuamente. Cada temporada compreende 30 dias de jogos (jogos em casa e fora). As apostas podem ser feitas a qualquer momento \u2013 mesmo dentro de uma temporada.</p>\r
  <p>7.2.2. Detalhes da temporada.Para a vers\xE3o online, uma temporada dura 106:30 minutos no total, separados em um per\xEDodo de 'Pr\xE9-Liga', um 'Loop do dia de jogo' e um per\xEDodo de 'P\xF3s-liga'. O per\xEDodo de 'Pr\xE9-Liga' ocorre antes do in\xEDcio de uma temporada e dura 60 segundos. Todos os dias de jogo s\xE3o resumidos como o per\xEDodo de 'Loop do dia de jogo' com uma dura\xE7\xE3o total de 105:00 minutos. No final de cada temporada, h\xE1 um per\xEDodo de 30 segundos "P\xF3s-temporada".</p>\r
  <p>7.2.3. Apostar em uma partida de VBL \xE9 permitido at\xE9 10 segundos antes do in\xEDcio do jogo. Os mercados de apostas para os pr\xF3ximos dias de jogo da temporada atual permanecem abertos. Quando um dia de jogo futuro da barra 'Match Day' na parte inferior for selecionado, os jogos relacionados a esse dia, juntamente com as probabilidades, ser\xE3o exibidos na se\xE7\xE3o de probabilidades mais baixas.  </p>\r
  <p>7.3. Virtual horses.7.3.1. O VHK oferece experi\xEAncia de apostas com dinheiro real 24/7/365 em corridas de cavalos virtuais. As apostas podem ser feitas at\xE9 10 segundos antes do in\xEDcio da pr\xF3xima corrida, bem como em todas as corridas futuras dos dias de corrida atuais a qualquer momento.</p>\r
  <p>7.3.2. As corridas s\xE3o geradas continuamente - uma nova ser\xE1 iniciada assim que a atual terminar. As apostas s\xE3o poss\xEDveis nas pr\xF3ximas 10 corridas: 2 minutos de ciclo total do evento 40 segundos de fase de apostas, 65 segundos de fase de eventos, 15 segundos de resultados de fase2 grama e 1 pista de terra com uma corrida de 1000m agendada aleatoriamente8, 10, 12, 14 corredores atribu\xEDdos aleatoriamente</p>\r
  <p>\u25CF Ciclo de evento total de 2 minutos</p>\r
  <p>\u25CF Fase de apostas de 40 segundos,</p>\r
  <p>\u25CF Fase de evento de 65 segundos,</p>\r
  <p>\u25CF 15 segundos de fase de resultados</p>\r
  <p>\u25CF 2 pistas de grama e 1 de terra com uma corrida de 1000m agendada aleatoriamente</p>\r
  <p>\u25CF 8, 10, 12, 14 corredores designados aleatoriamente</p>\r
  <p>7.3.3. MarketsWin - selecione o corredor que terminar\xE1 em primeiro lugar - selecione o corredor que terminar\xE1 em 1\xBA e 2\xBA (6-7 corredores), selecione o corredor que terminar\xE1 em 1\xBA, 2\xBA e 3\xBA (mais de 7 corredores) Previs\xE3o (Ordem correta) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA na ordem correta (exata)Previs\xE3o (Qualquer Ordem) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA em qualquer ordem (quinella)Tricast (Ordem Correta) - selecione os corredores que terminar\xE3o 1\xBA, 2\xBA e 3\xBA na ordem correta (trifecta)Tricast (Any Order) - selecione os corredores que terminar\xE3o em 1\xBA, 2\xBA e 3\xBA em qualquer ordem (trio)</p>\r
  <p>\u25CF Vencer - selecione o corredor que terminar\xE1 primeiro</p>\r
  <p>\u25CF Lugar - selecione o corredor que terminar\xE1 em 1\xBA e 2\xBA (6-7 corredores), selecione o corredor que terminar\xE1 em 1\xBA, 2\xBA e 3\xBA (mais de 7 corredores)</p>\r
  <p>\u25CF Previs\xE3o (Ordem Correta) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA na ordem correta (exata)</p>\r
  <p>\u25CF Previs\xE3o (Qualquer Ordem) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA em qualquer ordem (quinella)</p>\r
  <p>\u25CF Tricast (Ordem Correta) - selecione os corredores que terminar\xE3o em 1\xBA, 2\xBA e 3\xBA na ordem correta (trifecta)</p>\r
  <p>\u25CF Tricast (Qualquer Ordem) - selecione os corredores que terminar\xE3o em 1\xBA, 2\xBA e 3\xBA em qualquer ordem (trio)</p>\r
  <p>7.4. C\xE3es virtuais</p>\r
  <p>7.4.1. O VDK oferece experi\xEAncia de apostas com dinheiro real 24/7/365 em corridas virtuais de c\xE3es. As apostas podem ser feitas at\xE9 10 segundos antes do in\xEDcio da pr\xF3xima corrida, bem como nas dez corridas futuras a qualquer momento.</p>\r
  <p>7.4.2. Informa\xE7\xF5es do jogo. As corridas s\xE3o geradas continuamente - uma nova ser\xE1 iniciada assim que a atual terminar.Ciclo total do evento de 2 minutos37 segundos ou 67 segundos fase de apostas,38 segundos ou 68 segundos fase do evento,15 segundos resultados fasenoite e dia pista com dist\xE2ncia 360m e 720m aleatoriamente programados6 ou 8 corredores aleatoriamente designados</p>\r
  <p>\u25CF Ciclo de evento total de 2 minutos</p>\r
  <p>\u25CF Fase de apostas de 37 segundos ou 67 segundos,</p>\r
  <p>\u25CF 38 segundos ou 68 segundos de fase de evento,</p>\r
  <p>\u25CF 15 segundos de fase de resultados</p>\r
  <p>\u25CF trilha noturna e diurna com dist\xE2ncia de 360m e 720m programadas aleatoriamente</p>\r
  <p>\u25CF 6 ou 8 corredores designados aleatoriamente</p>\r
  <p>7.4.3. MarketsWin - selecione o corredor que terminar\xE1 em primeiro lugar - selecione o corredor que terminar\xE1 em 1\xBA e 2\xBA (6-7 corredores), selecione o corredor que terminar\xE1 em 1\xBA, 2\xBA e 3\xBA (mais de 7 corredores) Previs\xE3o (Ordem correta) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA na ordem correta (exata)Previs\xE3o (Qualquer Ordem) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA em qualquer ordem (quinella)Tricast (Ordem Correta) - selecione os corredores que terminar\xE3o 1\xBA, 2\xBA e 3\xBA na ordem correta (trifecta)Tricast (Any Order) - selecione os corredores que terminar\xE3o em 1\xBA, 2\xBA e 3\xBA em qualquer ordem (trio)</p>\r
  <p>\u25CF Vencer - selecione o corredor que terminar\xE1 primeiro</p>\r
  <p>\u25CF Lugar - selecione o corredor que terminar\xE1 em 1\xBA e 2\xBA (6-7 corredores), selecione o corredor que terminar\xE1 em 1\xBA, 2\xBA e 3\xBA (mais de 7 corredores)</p>\r
  <p>\u25CF Previs\xE3o (Ordem Correta) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA na ordem correta (exata)</p>\r
  <p>\u25CF Previs\xE3o (Qualquer Ordem) - selecione os corredores que terminar\xE3o em 1\xBA e 2\xBA em qualquer ordem (quinella)</p>\r
  <p>\u25CF Tricast (Ordem Correta) - selecione os corredores que terminar\xE3o em 1\xBA, 2\xBA e 3\xBA na ordem correta (trifecta)</p>\r
  <p>\u25CF Tricast (Qualquer Ordem) - selecione os corredores que terminar\xE3o em 1\xBA, 2\xBA e 3\xBA em qualquer ordem (trio)</p>\r
</section>\r
\r
<section>\r
  <h2>8. <span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="4" jscontroller="Zl5N8" jsdata="uqLsIf;_;$5811" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">B\xF4nus</span></span></span></h2>\r
  <p>8.1. Comboboost</p>\r
  <p>\r
    <table class="ui-table is-stripe">\r
      <thead>\r
        <tr>\r
          <th>Multiplier</th>\r
          <th>Selections</th>\r
        </tr>\r
      </thead>\r
      <tbody>\r
        <tr>\r
          <td>2</td>\r
          <td>1.01</td>\r
        </tr>\r
        <tr>\r
          <td>3</td>\r
          <td>1.02</td>\r
        </tr>\r
        <tr>\r
          <td>4</td>\r
          <td>1.04</td>\r
        </tr>\r
        <tr>\r
          <td>5</td>\r
          <td>1.05</td>\r
        </tr>\r
        <tr>\r
          <td>6</td>\r
          <td>1.07</td>\r
        </tr>\r
        <tr>\r
          <td>7</td>\r
          <td>1.1</td>\r
        </tr>\r
        <tr>\r
          <td>8</td>\r
          <td>1.15</td>\r
        </tr>\r
        <tr>\r
          <td>9</td>\r
          <td>1.17</td>\r
        </tr>\r
        <tr>\r
          <td>10</td>\r
          <td>1.2</td>\r
        </tr>\r
        <tr>\r
          <td>11</td>\r
          <td>1.25</td>\r
        </tr>\r
        <tr>\r
          <td>12</td>\r
          <td>1.3</td>\r
        </tr>\r
        <tr>\r
          <td>13</td>\r
          <td>1.35</td>\r
        </tr>\r
        <tr>\r
          <td>14</td>\r
          <td>1.4</td>\r
        </tr>\r
        <tr>\r
          <td>15</td>\r
          <td>1.45</td>\r
        </tr>\r
        <tr>\r
          <td>16</td>\r
          <td>1.5</td>\r
        </tr>\r
        <tr>\r
          <td>17</td>\r
          <td>1.65</td>\r
        </tr>\r
        <tr>\r
          <td>18</td>\r
          <td>1.75</td>\r
        </tr>\r
        <tr>\r
          <td>19</td>\r
          <td>1.85</td>\r
        </tr>\r
        <tr>\r
          <td>20</td>\r
          <td>2</td>\r
        </tr>\r
      </tbody>\r
    </table>\r
  </p>\r
  <p>8.1.2 O c\xE1lculo do valor final do b\xF4nus \xE9 baseado nas probabilidades finais do Combo assim que todos os resultados forem liquidados.</p>\r
  <p>8.1.3 Apostas com Cash Out n\xE3o s\xE3o eleg\xEDveis para aumento de Combo.</p>\r
  <p>8.1.4 O Operador reserva-se o direito de alterar, cancelar, reclamar ou recusar qualquer promo\xE7\xE3o a seu crit\xE9rio.</p>\r
  <p>8.1.5 O combo boost s\xF3 est\xE1 dispon\xEDvel em sele\xE7\xF5es com odds de 1,50 ou superior.</p>\r
  <p>8.2 Reembolso da aposta, dinheiro gr\xE1tis, aposta sem risco.</p>\r
  <p>8.2.1 Reembolso da aposta - o jogador recebe apenas uma parte vencedora da aposta. Por exemplo, freebet5 no jogador \xEDmpar de 3,5 fica na conta 5*3,5 - 5 = 12,5</p>\r
  <p>8.2.2 Freemoney - o jogador recebe uma aposta e ganha uma parte na conta. Por exemplo, aposta gr\xE1tis 5 na odd 3,5 que o jogador recebe na conta 5*3,5 = 17,50</p>\r
  <p>8.2.3 Aposta sem risco - aposta normal, mas se o jogador perder ele recebe de volta seu dinheiro na conta</p>\r
  <p><table class="ui-table is-stripe">\r
    <thead>\r
      <tr>\r
        <th><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$5918" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Tipo de Aposta Gr\xE1tis</span></span></span></th>\r
        <th><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$5942" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Reembolso ou Anulado</span></span></span></th>\r
        <th><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$5966" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Meio perdido</span></span></span></th>\r
        <th><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$5990" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Meia Vit\xF3ria</span></span></span></th>\r
      </tr>\r
    </thead>\r
    <tbody>\r
      <tr>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6017" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Reembolso da aposta</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="2" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6019" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">contar como uma aposta perdida</span></span><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="3" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6020" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb"> </span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="5" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6021" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">contar como uma aposta perdida</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6048" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">como uma aposta habitual, mas sem a aposta</span></span></span>          <div>(2.5*3.5+2.5*1)-5=6.25</div>\r
        </td>\r
      </tr>\r
      <tr>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="7" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6075" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Dinheiro gratuito</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="2" data-number-of-phrases="7" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6077" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">o jogador recebe o valor da aposta em sua conta</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="7" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6079" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">como uma aposta normal</span></span></span>t</td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="7" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6079" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">como uma aposta normal</span></span></span></td>\r
      </tr>\r
      <tr>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6108" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">Aposta sem risco</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="7" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6079" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">como uma aposta normal</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="0" data-number-of-phrases="1" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6126" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">o jogador recebe o valor da aposta em sua conta</span></span></span></td>\r
        <td><span lang="pt" jsaction="mouseup:BR6jm" jsname="jqKxS" xml:lang="pt"><span jsaction="agoMJf:PFBcW;usxOmf:aWLT7;jhKsnd:P7O7bd,F8DmGf;Q4AGo:Gm7gYd,qAKMYb;uFUCPb:pvnm0e,pfE8Hb,PFBcW;f56efd:dJXsye;EnoYf:KNzws,ZJsZZ,JgVSJc;zdMJQc:cCQNKb,ZJsZZ,zchEXc;Ytrrj:JJDvdc;tNR8yc:GeFvjb;oFN6Ye:hij5Wb;bmeZHc:iURhpf;Oxj3Xe:qAKMYb,yaf12d" jsname="txFAF" data-language-for-alternatives="pt" data-language-to-translate-into="en" data-phrase-index="4" data-number-of-phrases="7" jscontroller="Zl5N8" jsdata="uqLsIf;_;$6079" jsmodel="SsMkhd"><span jsaction="click:qtZ4nf,GFf3ac,tMZCfe; contextmenu:Nqw7Te,QP7LD; mouseout:Nqw7Te; mouseover:qtZ4nf,c2aHje" jsname="W297wb">como uma aposta normal</span></span></span></td>\r
      </tr>\r
    </tbody>\r
  </table></p>\r
</section>\r
\r
<section>\r
  <p>9. Regras dos Jogos Betby</p>\r
  <p>9.1. Regras gerais.</p>\r
  <p>9.1.1. A plataforma de apostas esportivas reserva-se o direito de cancelar qualquer aposta feita em probabilidades obviamente \u201Cruins\u201D, probabilidades trocadas ou uma aposta feita ap\xF3s o in\xEDcio de um evento ou partida afetada por problemas t\xE9cnicos \xF3bvios.</p>\r
  <p>9.1.2. Todas as apostas ser\xE3o liquidadas, quando o resultado do mercado for decidido.</p>\r
  <p>9.2. FIFA</p>\r
  <p>9.2.1. Dura\xE7\xE3o da partida \u2013 2x6 minutos. Isso inclui tempo de les\xE3o, mas n\xE3o inclui tempo extra ou p\xEAnaltis.</p>\r
  <p>9.2.2. Todos os Mercados ser\xE3o liquidados conforme estabelecido nas Regras Gerais do Mercado.</p>\r
  <p>9.3. NBA 2K</p>\r
  <p>9.3.1. Dura\xE7\xE3o da partida \u2013 4x6 minutos. Isso inclui horas extras.</p>\r
  <p>9.3.2. Todos os Mercados ser\xE3o liquidados conforme estabelecido nas Regras Gerais e de Mercado de Basquetebol.</p>\r
  <p>9.4. eT\xEAnis</p>\r
  <p>9.4.1. O vencedor da partida \xE9 o primeiro jogador a vencer 2 sets.</p>\r
  <p>9.4.2. O jogador deve ganhar 3 jogos para ganhar um set. Se o placar estiver empatado em 2 a 2, um jogador pode vencer por 4 a 2, ou se os jogadores ainda estiverem empatados em 3 a 3, o set ser\xE1 decidido por um tie-break.</p>\r
  <p>9.4.3. O vencedor do tie-break \xE9 o primeiro jogador a ganhar 5 pontos com uma diferen\xE7a m\xEDnima de 2 pontos. Se o placar estiver empatado em 5-5, o jogador pode ganhar 7-5, 8-6, 9-7, etc.</p>\r
  <p>9.5. Liga de foguetes</p>\r
  <p>9.5.1. Dura\xE7\xE3o da partida \u2013 5 minutos. Isso n\xE3o inclui horas extras.</p>\r
  <p>9.5.2. Todos os Mercados ser\xE3o liquidados conforme estabelecido nas Regras Gerais do Mercado.</p>\r
  <p>9.6. eFighting</p>\r
  <p>9.6.1. O vencedor da partida \xE9 o personagem, que vence a luta.</p>\r
  <p>9.6.2. Explica\xE7\xE3o dos termos do mercado eFighting.Health Bar - Cada personagem tem 2 Health Bars. A segunda barra fica ativa somente depois que a primeira \xE9 completamente gasta. Primeiro dano \u2013 primeiro ataque bem sucedido. Clash \u2013 Situa\xE7\xE3o na luta, quando ambos os personagens se desafiam em ocasi\xF5es especiais. para aumentar os pontos de vida. Ambos os lutadores podem vencer o confronto, mas tamb\xE9m pode haver empate.Supermove \u2013 Movimento especial para cada personagem, que ocorre muito raramente.</p>\r
  <p>9.6.3. Todos os mercados ser\xE3o liquidados de acordo com as defini\xE7\xF5es acima.</p>\r
  <p>9.7. eCricket</p>\r
  <p>9.7.1. A partida consiste em duas entradas - uma para cada equipe.</p>\r
  <p>9.7.2. Cada entrada consiste em cinco overs com 6 entregas de cada.</p>\r
  <p>9.7.3. Todos os Mercados ser\xE3o liquidados conforme estabelecido nas Regras do Mercado de Cr\xEDquete.</p>\r
  <h2>&nbsp;</h2>\r
</section>`,
    o = `<section>
  <h2>1.Pengantar</h2>
  <p>1.1 Kumpulan syarat dan ketentuan ini mengatur penggunaan platform Sportsbook. Saat memasang taruhan dengan platform Sportsbook, Pemegang Akun dengan demikian setuju bahwa Pemegang Akun telah membaca, memahami dan akan mematuhi Syarat dan Ketentuan ini termasuk Syarat dan Ketentuan umum yang setiap saat berlaku untuk platform Sportsbook.</p >
  <p>1.2 Penggunaan platform Sportsbook ini tunduk pada peraturan yang diberlakukan oleh <b style="color: var(--title-color);">(lisensi Curacao.)</b>.</p>
  <p>1.3 Setiap perselisihan yang berkaitan dengan penggunaan platform Sportsbook ini dengan cara apa pun harus dikirim melalui email ke <b style="color: var(--title-color);">(support@bc.game)</b>. Jika jawaban tidak dianggap memuaskan, permintaan untuk arbitrase rahasia dapat dikirim ke <b style="color: var(--title-color);">(info@curacaolicensing.com)</b>. Keputusan mereka akan mengikat dan dapat dimasukkan sebagai keputusan di pengadilan mana pun dengan yurisdiksi yang kompeten.</p>
  <p>1.4 Platform Sportsbook berhak melakukan perubahan pada situs, batas taruhan, batas pembayaran, dan penawaran.</p>
  <p>1.5 Platform Sportsbook dapat memperbarui, mengubah, mengedit, dan melengkapi Persyaratan dan Ketentuan ini kapan saja.</p>
  <p>1.6 Setiap referensi dalam Syarat dan Ketentuan ini untuk kata/objek yang muncul dalam bentuk tunggal juga berlaku untuk jamak. Rujukan ke gender tidak mengikat dan harus diperlakukan sebagai informasi</p>
  <p>hanya untuk tujuan.</p>
</section>

<section>
  <h2>2. Definisi</h2>
  <p>2.1 Sportsbook
     platform \u2013 badan hukum yang terlibat dalam aktivitas taruhan sesuai dengan lisensi dan legislatif
     persyaratan negara.</p>
   <p>2.2 Klien - individu yang telah menyetujui Aturan untuk menerima taruhan, terdaftar di situs<b style="color: var(--title-color);">(https://BC.GAME/) </b>(dan versi subdomain situs lainnya).</p>
  <p>2.3 Taruhan \u2013 perjanjian berbasis risiko yang disepakati antara Klien dan Perusahaan Taruhan tentang hasil dari suatu peristiwa di mana mereka tidak berpartisipasi, yang melibatkan kemenangan. Taruhan dibuat dengan persyaratan yang sebelumnya diusulkan oleh platform Sportsbook.</p>
  <p>2.4 Taruhan - jumlah uang yang ditransfer oleh klien ke platform Sportsbook dan yang merupakan syarat utama untuk berpartisipasi dalam taruhan sesuai dengan Aturan ini.</p>
  <p>2.5 Hasilnya adalah hasil dari acara di mana platform Sportsbook diundang untuk bertaruh.</p>
  <p>2.6 Odd \u2014 nomor di mana jumlah taruhan pemangku kepentingan dikalikan saat menentukan jumlah pembayaran jika taruhan menang.</p>
  <p>2.7 Kemenangan - uang tunai yang harus dibayarkan kepada Klien berdasarkan hasil, di mana taruhan dibuat.</p>
  <p>2.8 Bonus:</p>
  <p>2.81 Pengembalian dana taruhan - pengembalian dana taruhan, klien baru saja mendapatkan jumlah yang dimenangkan di akunnya. Misalnya, freebet 5 di odd 3.5 klien mendapatkan 5*3.5 - 5 = 12.50</p>
  <p>2.82 Uang gratis - klien mendapat jumlah taruhan dan menang di akunnya. Misalnya, freebet 5 di odd 3.5 klien dapat 5*3.5 = 18.50</p>
  <p>2.83 Tidak ada taruhan risiko - pemain menggunakan uangnya untuk bertaruh, tetapi jika taruhan kalah, dia mendapatkan uangnya kembali.</p>
</section>

<section>
  <h2>3. Aturan Taruhan</h2>
  <p>3.1 Sportsbook platform berhak untuk membatalkan taruhan apa pun yang dibuat dengan sangat "buruk" odds, menukar odds atau taruhan yang dibuat setelah acara dimulai.</p>
  <p>3.2 Semua taruhan yang diterima oleh platform Sportsbook tunduk pada aturan ini, serta ketentuan lisensi yang berlaku.</p>
  <p>3.3 Platform Sportsbook berhak menolak, membatasi, membatalkan, atau membatasi taruhan apa pun.</p>
  <p>3.4 Platform Sportsbook berhak untuk menyelesaikan setelah kontes final atau dengan hasil resmi</p>
  <p>3.5 Pemenang suatu acara akan ditentukan pada tanggal penutupan acara. Platform Sportsbook tidak mengakui keputusan yang diprotes atau dibatalkan untuk tujuan taruhan. Penyelesaian acara yang ditangguhkan setelah dimulainya kompetisi akan diputuskan sesuai dengan aturan taruhan yang ditentukan untuk olahraga tersebut oleh platform Sportsbook</p>
  <p>3.6 Tidak seorang pun yang berusia di bawah 18 tahun diizinkan untuk bertaruh.</p>
   <p>3.7 Semua aturan yang terkandung di sini dapat diubah dan direvisi oleh platform Sportsbook tanpa pemberitahuan tertulis sebelumnya. Semua perubahan dan revisi aturan kami akan diposting di situs web platform Sportsbook.</p>
   <p>3.8 Jumlah taruhan maksimum pada semua acara olahraga akan ditentukan oleh platform Sportsbook dan dapat berubah tanpa pemberitahuan tertulis sebelumnya. Platform Sportsbook juga berhak untuk menyesuaikan batas pada akun individu juga.</p>
  <p>3.9 Untuk akun dengan saldo minus, platform Sportsbook berhak untuk membatalkan setiap permainan yang tertunda, baik ditempatkan dengan dana yang dihasilkan dari kesalahan atau tidak.</p>
   <p>3.10 Anggota bertanggung jawab penuh atas transaksi akun mereka sendiri. Harap pastikan untuk meninjau dan mengkonfirmasi taruhan Anda untuk setiap kesalahan sebelum mengirimkannya. Setelah transaksi selesai, itu tidak dapat diubah. Platform Sportsbook tidak bertanggung jawab atas kehilangan atau duplikat taruhan yang dibuat oleh klien dan tidak akan melayani permintaan perubahan karena permainan hilang atau digandakan. Klien dapat meninjau transaksi mereka di \u201CTaruhan Saya\u201D situs setelah setiap sesi untuk memastikan semua taruhan yang diminta diterima.</p>
  <p>3.11 Perselisihan harus diajukan dalam waktu tujuh (7) hari sejak tanggal taruhan yang bersangkutan telah diputuskan. Tidak ada klaim yang akan dihormati setelah periode ini. Klien bertanggung jawab penuh atas transaksi akun mereka.</p>
   <p>3.12 Kemenangan akan selalu dihitung menggunakan Desimal Taruhan . Harap dicatat, bahwa ketika mengonversi Taruhan ke standar Inggris, kesalahan pembulatan dapat terjadi, karena beberapa Taruhan tidak memiliki terjemahan yang tepat ke dalam pecahan gaya Inggris. Di sini, kami akan menunjukkan Taruhan  pecahan terdekat.</p>
  <p>3.13 Platform Sportsbook berhak untuk menangguhkan akun klien tanpa pemberitahuan sebelumnya.</p>
  <p>3.14 Jika ada perbedaan antara versi bahasa Inggris dari aturan ini dan versi bahasa lainnya, versi bahasa Inggris akan dianggap benar.</p>
  <p>3.15 Taruhan kombo (akumulator, parlay, multis) tidak diterima jika hasil dari satu bagian taruhan berkontribusi pada hasil bagian lainnya. Jika jenis taruhan tersebut diterima, kami berhak untuk membatalkan jenis taruhan ini. contoh: memasang taruhan pada Barcelona untuk memenangkan La Liga dikombinasikan dengan kemenangan Barcelona di pertandingan penentuan.</p>
  <p>3.16 Taruhan apa pun yang dipasang dengan sistem taruhan tidak akan dihitung untuk persyaratan taruhan dalam Bonus</p>
  <p>3.17 Pembaruan Skor Langsung hanya untuk panduan. Platform Sportsbook tidak bertanggung jawab atas kesalahan apa pun. Platform Sportsbook berhak untuk membatalkan taruhan apa pun jika hasilnya sudah diketahui atau jika odds belum diperbarui dengan benar karena masalah teknis.</p>
  <p>3.18 Taruhan outright dianggap all in run atau tidak dan akan dianggap kalah jika seleksi tidak ambil bagian dalam pertandingan, kecuali dinyatakan lain. Aturan panas mati berlaku di mana ada lebih dari satu pemenang. Taruhan petaruh pertama-tama dibagi dengan jumlah pilihan yang diikat dan kemudian bagian dari taruhan mereka diselesaikan sebagai pemenang dan sisanya diselesaikan sebagai pihak yang kalah.</p>
  <p>3.19 Platform Sportsbook berhak untuk membatalkan atau membatalkan taruhan apa pun di mana hasilnya telah diubah oleh pengenaan poin penalti, degradasi yang dipaksakan, atau tindakan lain apa pun yang diberlakukan sebagai akibat dari apa pun selain hasil normal dari permainan/kompetisi yang bersangkutan.</p>
  <p>3.20 Semua taruhan diselesaikan dengan menggunakan informasi yang diberikan oleh badan resmi yang menjalankan kompetisi pada saat hasil, kecuali dinyatakan lain. Dalam hal kejadian apapun di luar kompetisi resmi maka taruhan diselesaikan dengan menggunakan informasi yang disediakan.</p>
  <p>3.21 Jika salah satu pesaing tidak memulai platform Sportsbook, batalkan pasar head-to-head ini.</p>
  <p>3.22 Jika kedua kompetitor tidak selesai,pemenangnya adalah kompetitor yang memiliki lap lebih banyak. Jika kedua pesaing keluar di lap yang sama, platform Sportsbook membatalkan pasar head to head ini.</p>
  <p>3.23 Jika pesaing di posisi yang sama, platform Sportsbook membatalkan taruhan di pasar head to head ini.</p>
  <p>3.24 Platform Sportsbook tidak bertanggung jawab atas kerusakan yang ditimbulkan oleh klien sebagai akibat dari malfungsi sistem, cacat, keterlambatan, manipulasi atau kesalahan dalam transfer data.</p>
  <p>3.25 Klaim Klien dipertimbangkan oleh platform Sportsbook dalam waktu tiga puluh hari sejak Klien mengajukan aplikasi tertulis ke platform Sportsbook. Setelah membuat keputusan, platform Sportsbook memberi tahu klien melalui email yang ditautkan ke akun permainan.</p>
  <p>3.26 Dalam kasus kecurigaan aktivitas yang tidak adil, platform Sportsbook berhak untuk membatalkan taruhan atau bagian apa pun darinya, sehingga membuat taruhan yang dipertanyakan menjadi tidak valid (dalam kasus ini, pembayaran dilakukan dengan odds \u201C1\u201D) atau menangguhkan penarikan untuk hingga 31 hari kalender.</p>
  <p>3.27 Klien diperbolehkan bertaruh hanya sebagai individu, taruhan grup tidak diperbolehkan. Taruhan berulang pada hasil/pemenang yang sama dari pelanggan yang sama atau berbeda selanjutnya dapat dinyatakan tidak valid. Bahkan setelah hasil resmi dari kompetisi / atlet diketahui, platform Sportsbook dapat menganggap taruhan yang ditunjukkan tidak valid jika menganggap bahwa Klien bertindak dalam kolusi atau sindikat, atau taruhan yang dianggap dibuat oleh satu atau lebih Klien dalam waktu singkat. periode waktu. Perusahaan taruhan juga berhak menolak untuk menerima taruhan atau menghitung taruhan yang sudah dibuat sebagai tidak valid jika dibuat dari akun game yang berbeda dari alamat IP yang sama.</p>
  <p>3.28 Taruhan LANGSUNG: Jika pertandingan dihentikan atau ditunda dan tidak berlanjut dalam 48 jam setelah waktu yang dijadwalkan, taruhan akan dibatalkan (kecuali untuk hasil yang ditentukan dengan jelas saat pertandingan dihentikan).
  </p>
  <p>3.29 Statistik atau teks editorial yang diterbitkan di situs platform Sportsbook dianggap sebagai informasi tambahan tetapi platform Sportsbook tidak mengakui atau menerima kewajiban apa pun jika informasi tersebut tidak benar. Setiap saat adalah tanggung jawab Pemegang Rekening untuk mengetahui keadaan yang berkaitan dengan suatu peristiwa.</p>
  <p>3.30 Dilarang menggunakan sistem otomatis (pemindai atau robot apa pun) di Sportsbook. Platform Sportsbook berhak untuk membatalkan setiap taruhan yang dibuat menggunakan sistem otomatis</p>
  <p>3.31 Dilarang menggunakan akun milik orang lain atau akun yang terdaftar di pihak lain</p>
  <p>Platform Sportsbook berhak untuk membatalkan taruhan apa pun yang bukan merupakan pemilik akun.</p>
</section>
  
<section>
  <h2>4. Jenis Taruhan</h2>
  <p>4.1 Tunggal (Biasa) - bertaruh pada hasil terpisah dari acara tersebut. Pembayaran taruhan tunggal sama dengan produk dari jumlah tawaran yang ditetapkan untuk harga hasil.</p>
  <p>4.2 Combo - bertaruh pada beberapa hasil acara yang independen. Untuk menang di express perlu tidak ada hasil yang termasuk dalam express, tidak ada yang kalah. Kehilangan salah satu hasil kombo berarti kalah di seluruh kombo. Pembayaran kombo sama dengan produk jumlah taruhan pada odds semua hasil yang termasuk dalam kombo.</p>
  <p>4.3 Sistem - satu set kombo, yang merupakan varian pencarian lengkap kombo dengan ukuran yang sama dari serangkaian hasil tetap. Hal ini ditandai dengan taruhan yang sama untuk setiap ekspres (sistem opsi) dan jumlah hasil yang sama di setiap ekspres. Taruhan sistem harus menentukan jumlah total hasil dan jumlah kombo (opsi sistem). Pembayaran pada sistem sama dengan jumlah pembayaran pada kombo yang termasuk dalam sistem.</p>
  <p>4.4 'Trixie' adalah kombinasi, yang mencakup satu treble dan tiga ganda dari pilihan tiga pertandingan.</p>
  <p>4.5 'Paten' adalah kombinasi, yang mencakup satu treble, tiga ganda dan tiga tunggal dari pilihan tiga pertandingan.</p>
  <p>4.6 'Yankee' adalah kombinasi, yang mencakup satu empat kali lipat, empat treble dan enam ganda dari pilihan empat pertandingan.</p>
  <p>4.7 'Canadian' (juga dikenal sebagai 'Super Yankee') adalah kombinasi, yang mencakup satu lima kali lipat, lima empat kali lipat, sepuluh treble dan sepuluh ganda dari pilihan lima pertandingan.</p>
  <p>4.8 'Heinz' adalah kombinasi, yang mencakup satu enam kali lipat, enam kali lipat lima, lima belas kali lipat empat, dua puluh treble dan lima belas ganda dari pilihan enam pertandingan.</p>
  <p>4.9 'Super Heinz' adalah kombinasi, yang mencakup satu tujuh kali lipat, tujuh kali lipat enam, dua puluh satu kali lipat lima, tiga puluh lima kali lipat empat, tiga puluh lima treble dan dua puluh satu ganda dari pilihan tujuh pertandingan.</p>
  <p>4.10 'Goliath' adalah kombinasi, yang mencakup satu delapan kali lipat, delapan kali lipat tujuh, dua puluh delapan kali lipat enam, lima puluh enam kali lipat lima, tujuh puluh empat kali lipat, lima puluh enam treble dan dua puluh delapan ganda dari pilihan delapan pertandingan.</p>
  <p>4.11 Jika odds mempertimbangkan lebih dari 2 digit setelah titik desimal, pembayaran akan dibulatkan untuk digit kedua setelah titik desimal.</p>
  <p>4.12 "Cash out" adalah penawaran individu yang diprakarsai oleh platform Sportsbook, ditujukan kepada peserta taruhan, yang ditujukan untuk mengubah satu atau beberapa kondisi taruhan penting (koefisien, waktu perhitungan acara, dll.) untuk memperbaiki hasil baru dan menyelesaikan taruhan di waktu saat ini (lebih lanjut - Cash out). Tawaran untuk menebus taruhan dapat diterima dan ditolak oleh peserta taruhan. Dengan memilih \u201CCash out\u201D, peserta taruhan mengonfirmasi penerimaannya terhadap persyaratan penting baru dari taruhan. Tarif pembayaran tunai dapat ditawarkan untuk pra-pertandingan dan untuk taruhan langsung. Kantor bandar berhak mengubah tawaran untuk membeli kembali tawaran dari waktu ke waktu, atau tidak membentuk tawaran untuk membeli kembali taruhan tanpa memberikan alasan.</p>
</section>

<section>
  <h2>5. Pasar</h2>
  <p>5.1 "Pertandingan" (1X2) adalah di mana dimungkinkan untuk bertaruh pada hasil (sebagian atau pasti) dari pertandingan atau acara. Pilihannya adalah: "1" = Tim tuan rumah, atau tim yang terdaftar di sisi kiri penawaran; "X" = Draw, atau seleksi di tengah; "2" = Tim tamu, atau tim yang terdaftar di sisi kanan penawaran.</p>
  <p>5.2 "Skor Benar" ( adalah di mana dimungkinkan untuk bertaruh pada skor yang tepat (sebagian atau pasti) dari suatu pertandingan atau peristiwa.</p>
  <p>5.3 "Over/Under" (Total) adalah di mana dimungkinkan untuk bertaruh pada jumlah (sebagian atau pasti) dari kejadian yang telah ditentukan (misalnya gol, poin, tendangan sudut, rebound, menit penalti, dll.). Jika jumlah total kejadian yang terdaftar sama persis dengan garis taruhan, maka semua taruhan pada penawaran ini akan dinyatakan batal. Contoh: penawaran dengan garis taruhan 128,0 poin dan pertandingan berakhir dengan hasil 64-64 akan dinyatakan batal.</p>
  <p>5.4 "Ganjil/Genap" adalah di mana dimungkinkan untuk bertaruh pada jumlah (sebagian atau pasti) dari kejadian yang telah ditentukan (misalnya gol, poin, tendangan sudut, rebound, menit penalti, dll.)."Ganjil" adalah 1,3,5 dll.; "Genap" adalah 0,2,4 dst.</p>
  <p>5.5 "Head-to-Head" dan/atau "Triple-Head" adalah kompetisi antara dua atau tiga peserta/hasil, yang berasal dari acara yang diselenggarakan secara resmi, atau lainnya, seperti yang didefinisikan secara virtual oleh platform Sportsbook.</p>

<p>5.6 "Half time/Full time" adalah di mana dimungkinkan untuk bertaruh pada hasil di babak pertama dan hasil akhir pertandingan. Misalnya. jika pada babak pertama skor 1-0 dan pertandingan berakhir 1-1, hasil kemenangan adalah 1/X. Taruhan batal jika waktu reguler pertandingan dimainkan dalam format waktu yang berbeda dari yang tercantum dalam taruhan (yaitu selain dua babak).</p>

<p>5.7 "Pertaruhan periode" adalah di mana dimungkinkan untuk bertaruh pada hasil dari setiap periode terpisah dalam pertandingan/acara.</p>

<p>5.8 "Draw No Bet" adalah di mana dimungkinkan untuk bertaruh pada "1" atau "2" seperti yang didefinisikan dalam . Ini juga merupakan praktik umum untuk merujuk ke "Draw No Bet" dalam kasus di mana tidak ada peluang draw yang ditawarkan. Jika pertandingan tertentu tidak mengandung pemenang (Misalnya pertandingan berakhir seri), atau kejadian tertentu tidak terjadi (Misalnya, Tanpa Taruhan Seri dan pertandingan berakhir 0-0), taruhannya akan dikembalikan.</p>

<p>5.9 "Handicap" adalah di mana dimungkinkan untuk bertaruh pada apakah hasil yang dipilih akan menang setelah handicap yang terdaftar ditambahkan/dikurangi (sebagaimana berlaku) ke pertandingan/periode/total skor yang mengacu pada taruhan. Dalam keadaan di mana hasil setelah penyesuaian garis handicap sama persis dengan garis taruhan, maka semua taruhan pada penawaran ini akan dinyatakan batal.</p>

<p>5.10 Contoh: taruhan pada -3.0 gol akan dinyatakan batal jika tim yang dipilih memenangkan pertandingan dengan selisih tepat 3 gol (3-0,4-1, 5-2, dst).</p>

  <p>5.11 Asian Handicap: Tim Tuan Rumah (-1,75) vs Tim Tamu (+1,75). Ini berarti bahwa taruhan dibagi menjadi 2 taruhan yang sama dan ditempatkan pada hasil -1.5 dan -2.0. Agar taruhan dibayar penuh pada odds yang terdaftar, Tim A harus memenangkan pertandingan dengan margin yang lebih besar dari kedua handicap mereka yang terdaftar (yaitu 3 gol atau lebih banyak margin). Jika Tim A menang dengan hanya margin 2 gol, taruhan akan dianggap menang sebagian dengan pembayaran penuh pada bagian -1,5 dari taruhan dan pengembalian dana di sisi -2,0 karena hasil pada bagian tersebut taruhan akan dianggap sebagai \u201Cdasi\u201D. Jika pertandingan menghasilkan hasil lain, termasuk kemenangan Tim A dengan hanya selisih 1 gol, seluruh taruhan akan hilang. Tim tamu diberi keunggulan +1,75 gol dalam pertandingan. Ini berarti bahwa taruhan dibagi menjadi 2 taruhan yang sama dan ditempatkan pada hasil +1.5 dan +2.0.</p>

<p>5.10 "Peluang Ganda" adalah di mana dimungkinkan untuk bertaruh secara bersamaan pada dua hasil (sebagian atau pasti) dari pertandingan atau acara. Pilihannya adalah: 1X, 12 dan X2 dengan "1", "X" dan "2" seperti yang didefinisikan dalam .</p>

<p>5.11 Taruhan "Outright" atau "Place" adalah di mana dimungkinkan untuk memilih dari daftar alternatif dan bertaruh pada kemungkinan bahwa seorang peserta menang atau ditempatkan dalam posisi tertentu dalam klasifikasi acara/kompetisi yang terdaftar.</p>

<p>5.12 Taruhan pada "Quarter / Half / Period X" mengacu pada hasil/skor yang dicapai dalam jangka waktu yang relevan dan tidak termasuk poin/gol/event lain yang dihitung dari bagian lain dari event/pertandingan. Taruhan akan dibatalkan jika pertandingan dimainkan dalam format lain selain format yang ditentukan dalam penawaran.</p>

<p>5.13 Taruhan pada "Hasil pada akhir Kuartal / Babak / Periode X" mengacu pada hasil pertandingan/acara setelah penghentian jangka waktu yang ditentukan dan akan memperhitungkan semua poin/gol/acara lain yang dihitung dari bagian sebelumnya dari acara/ cocok.</p>
  <p>5.14 Taruhan pada "Balapan ke Poin X / Perlombaan ke Gol X..." dan penawaran serupa mengacu pada tim/peserta yang mencapai penghitungan poin/gol/event tertentu paling awal. Jika penawaran mencantumkan jangka waktu (atau batasan periode lainnya), penawaran tersebut tidak akan menyertakan poin/gol/acara lain yang dihitung dari bagian lain dari acara/pertandingan yang tidak terkait dengan jangka waktu yang disebutkan. Jika skor yang tercantum tidak tercapai dalam jangka waktu yang ditentukan (jika ada), semua taruhan akan dinyatakan batal, kecuali dinyatakan lain.</p>

<p>5.15 Taruhan pada "Pemenang Poin X / Pencetak Gol X" dan penawaran serupa mengacu pada tim/peserta yang mencetak/memenangkan kejadian yang terdaftar. Untuk penyelesaian penawaran ini, tidak ada referensi ke peristiwa yang terjadi sebelum kejadian yang terdaftar yang akan dipertimbangkan. jika acara yang terdaftar tidak dicetak/dimenangkan dalam jangka waktu yang ditentukan (jika ada), semua taruhan akan dinyatakan batal, kecuali dinyatakan lain.</p>

<p>5.16 Taruhan yang mengacu pada terjadinya kejadian tertentu dalam urutan waktu yang telah ditentukan sebelumnya, seperti \u201CKartu Pertama\u201D, atau \u201CTim Berikutnya yang menerima menit penalti\u201D akan dianggap batal jika tidak memungkinkan, tanpa keraguan yang wajar, untuk memutuskan hasil kemenangan, misalnya dalam kasus pemain dari tim yang berbeda yang ditunjukkan kartu dalam interupsi permainan yang sama.</p>

<p>5.17 "Tim yang mencetak gol pertama dan menang" mengacu pada tim yang terdaftar yang mencetak gol pertama dalam pertandingan dan memenangkan pertandingan. Jika tidak ada gol dalam pertandingan, semua taruhan akan dianggap batal.</p>

<p>5.18 Referensi apa pun untuk "clean sheet" menunjukkan bahwa tim yang terdaftar tidak boleh kebobolan gol apa pun selama pertandingan.</p>

<p>5.19 "Tim untuk menang dari belakang" mengacu pada tim yang terdaftar yang memenangkan pertandingan setelah setidaknya tertinggal 1 gol di setiap titik dalam pertandingan.</p>

<p>5.20 Referensi apa pun untuk tim untuk memenangkan semua babak/periode (mis. Tim yang memenangkan kedua babak) berarti bahwa tim yang terdaftar harus mencetak lebih banyak gol daripada lawannya selama semua babak/periode pertandingan yang ditentukan.</p>

<p>5.21 Setiap referensi ke "Injury Time" mengacu pada jumlah yang ditampilkan oleh ofisial yang ditunjuk dan bukan jumlah sebenarnya yang dimainkan.</p>

</p>5.22 Penyelesaian taruhan pada penawaran seperti "Man of the Match", "Pemain Paling Berharga", dll. akan didasarkan pada keputusan penyelenggara kompetisi, kecuali dinyatakan lain.</p>
</section>

<section>
  <h2>6. Aturan khusus untuk olahraga</h2>
  <p>6.1. Sepak bola</p>

6.1.1. Taruhan pada hasil pertandingan akan diputuskan berdasarkan dua bagian dari jumlah menit yang dijadwalkan masing-masing dan setiap kali wasit menambahkan untuk mengkompensasi cedera dan penghentian lainnya. Itu tidak termasuk periode perpanjangan waktu atau adu penalti jika tidak disebutkan.</p>

6.1.2. Tendangan sudut yang diberikan tetapi tidak dilakukan tidak dianggap.

<p>6.1.3. Gol bunuh diri tidak akan dipertimbangkan untuk Pencetak Gol atau Pemain Kapan Saja yang mencetak X atau Pencetak Gol Berikutnya atau lebih banyak tujuan penyelesaian dan diabaikan.</p>

<p>6.1.4. Semua pemain yang ikut serta dalam pertandingan sejak kick off atau gol sebelumnya dianggap sebagai pelari</p>

<p>6.1.5. Jika seorang pemain tidak berada di starting XI, semua pasar pemain akan dibatalkan.</p>

<p>6.1.6. Jika karena alasan apa pun pemain yang tidak terdaftar mencetak gol, semua taruhan pada pemain yang terdaftar berlaku</p>

<p>6.1.7. Kapan saja Pencetak Gol atau Pemain yang mencetak X atau Pasar Pencetak Gol Berikutnya akan diselesaikan berdasarkan sisipan TV dan statistik yang disediakan oleh Asosiasi Pers kecuali ada bukti yang jelas bahwa statistik ini tidak benar.</p>

<p>6.1.8. Pasar interval akan diselesaikan berdasarkan waktu gol yang diumumkan oleh TV. Jika ini tidak tersedia, waktu menurut jam pertandingan akan dipertimbangkan.</p>

<p>6.1.9. Pasaran gol interval diselesaikan berdasarkan waktu bola melewati garis, dan bukan waktu tendangan dilakukan.</p>

<p>6.1.10. Pasaran interval tendangan sudut diselesaikan berdasarkan waktu tendangan sudut dilakukan dan bukan waktu tendangan sudut diberikan atau diberikan.</p>

<p>6.1.11. Pasar interval pemesanan diselesaikan berdasarkan waktu kartu ditampilkan dan bukan waktu pelanggaran dilakukan</p>

<p>6.1.12. Offside akan diselesaikan berdasarkan waktu ketika wasit memberikan keputusan. Aturan ini akan diterapkan pada situasi asisten wasit video (VAR) apa pun.</p>

<p>6.1.13. Pasaran penalti akan diselesaikan berdasarkan waktu ketika wasit memberikan keputusan. Aturan ini akan diterapkan pada situasi asisten wasit video (VAR) apa pun.</p>

<p>6.1.14. Penalti yang diberikan tetapi tidak diambil tidak dianggap

<p>6.1.15. Jenis skor berikutnya.Freekick: Gol harus dicetak langsung dari tendangan bebas atau tendangan sudut untuk memenuhi syarat sebagai gol melalui tendangan bebas. Tembakan yang dibelokkan dihitung selama tendangan bebas atau penendang sudut diberikan gol. Penalti: Gol harus dicetak langsung dari penalti. Gol setelah rebound dari penalti yang gagal tidak dihitung. Gol Bunuh Diri: Jika gol dinyatakan sebagai gol bunuh diri. Header: Sentuhan terakhir pencetak gol harus dengan kepala. Tembakan: Gol harus dengan bagian tubuh lain selain kepala dan jenis lainnya tidak berlaku. Tidak Ada Gol.</p>

<p>6.1.16. Jika pasar dibuka dengan kartu merah yang hilang atau salah, kami berhak untuk membatalkan taruhan</p>

<p>6.1.17. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 5 menit), kami berhak untuk membatalkan taruhan.</p>

<p>6.1.18. Jika skor yang salah dimasukkan, semua pasar akan dibatalkan pada saat skor yang salah ditampilkan</p>

<p>6.1.19. Jika nama tim atau kategori ditampilkan secara tidak benar, kami berhak untuk membatalkan taruhan.</p>

<p>6.1.20. Kartu kuning dihitung sebagai 1 kartu dan kartu merah atau kuning-merah sebagai 2. Kartu kuning ke-2 untuk satu pemain yang menghasilkan kartu merah kuning tidak dihitung. Akibatnya satu pemain tidak dapat menyebabkan lebih dari 3 kartu.</p>

<p>6.1.21. Penyelesaian akan dilakukan sesuai dengan semua bukti kartu yang tersedia yang ditunjukkan selama permainan reguler 90 menit.</p>

<p>6.1.22. Kartu yang ditampilkan setelah pertandingan tidak dianggap.</p>

<p>6.1.23. Kartu untuk non-pemain (pemain yang sudah diganti, manajer, pemain di bangku cadangan) tidak dipertimbangkan</p>

<p>6.1.24. Kartu kuning dihitung sebagai 10 poin dan kartu merah atau kuning merah sebagai 25. Kuning ke-2 untuk satu pemain yang mengarah ke kartu merah kuning tidak dianggap. Akibatnya satu pemain tidak dapat menyebabkan lebih dari 35 poin pemesanan.</p>

<p>6.1.25. Penyelesaian akan dilakukan sesuai dengan semua bukti yang tersedia untuk kartu yang ditampilkan selama permainan reguler 90 menit.</p>

<p>6.1.26. Kartu untuk non-pemain (pemain yang sudah diganti, manajer, pemain di bangku cadangan) tidak dipertimbangkan.</p>

<p>6.1.27. Jika format pertandingan diubah, sportsbook berhak membatalkan semua taruhan.</p>

<p>6.1.28. Jika pertandingan persahabatan berakhir dengan keputusan wasit lebih awal dari 80 menit.</p>

<p>6.1.29. Jika pertandingan persahabatan berakhir dengan keputusan wasit lebih awal dari 80 menit</p>

<p>6.1.30. Semua taruhan alat peraga pemain sepak bola diselesaikan menggunakan informasi yang disediakan oleh OPTA<a href="https://soccerstats.info/" target="_blank" class="cl-primary"> (https://soccerstats.info/)</a></p>
  <p>6.1.31. Definisi Alat Peraga PemainGol/Gol Sendiri Badan pengatur yang berbeda memiliki aturan yang berbeda, dan jika memungkinkan Opta bekerja dengan orang yang relevan untuk mencerminkan keputusan resmi mereka tentang pencetak gol. Mengenai defleksi, biasanya gol diberikan jika upaya awal tepat sasaran. Gol bunuh diri biasanya diberikan jika upaya meleset dari target dan dibelokkan ke gawang oleh lawan.Tembakan Target tembakan didefinisikan sebagai setiap upaya yang jelas untuk mencetak gol yang: Masuk ke gawang terlepas dari niatnya. Merupakan upaya yang jelas untuk mencetak gol yang akan telah masuk ke dalam jaring tetapi karena diselamatkan oleh penjaga gawang atau dihentikan oleh pemain yang menjadi orang terakhir dengan penjaga gawang tidak memiliki peluang untuk mencegah gawang (blok baris terakhir). Melewati atau melebar gawang tanpa melakukan kontak dengan pemain lain. Akan melewati atau melebar dari gawang tetapi karena dihentikan oleh penyelamatan kiper atau oleh pemain outfield. Langsung mengenai bingkai gawang dan tidak ada gol yang tercipta. Tembakan yang diblok tidak dihitung sebagai tembakan. Tembakan on goal - setiap upaya mencetak gol yang: Masuk ke gawang tanpa memperhatikan niat. Merupakan upaya yang jelas untuk mencetak gol yang seharusnya masuk ke gawang tetapi karena diselamatkan oleh penjaga gawang atau dihentikan oleh pemain yang menjadi pemain terakhir dengan penjaga gawang tidak memiliki peluang untuk mencegah gol (l blok garis ast).Tembakan yang langsung mengenai bingkai gawang tidak dihitung sebagai tembakan tepat sasaran, kecuali bola masuk dan diberikan sebagai gol.Tembakan yang diblok oleh pemain lain, yang bukan orang terakhir, tidak dihitung sebagai tembakan tepat sasaran.Gol Assist Sentuhan terakhir (pass, pass-cum-shot atau sentuhan lainnya) yang mengarah ke penerima bola untuk mencetak gol. Jika sentuhan terakhir (sebagaimana didefinisikan dalam huruf tebal) dibelokkan oleh pemain lawan, inisiator hanya diberikan assist gol jika pemain penerima kemungkinan besar akan menerima bola tanpa terjadi defleksi. Gol bunuh diri, tendangan bebas yang dilakukan secara langsung, tendangan sudut langsung, dan penalti tidak diberikan asis. Tekel Tekel didefinisikan sebagai pemain yang terhubung dengan bola dalam tantangan tanah di mana ia berhasil mengambil bola dari pemain yang menguasainya. Tekel pemain harus dengan jelas menguasai bola sebelum tekel dilakukan. Tekel yang dimenangkan dianggap di mana tekel atau salah satu rekan satu timnya mendapatkan kembali penguasaannya sebagai akibat dari tekel, atau bola keluar dari permainan dan \u201Caman\u201D. Tekel yang hilang adalah saat tekel dilakukan tetapi bola jatuh ke tangan pemain lawan. Keduanya dianggap sebagai tekel yang berhasil, namun hasil tekel (menang atau kalah) berbeda berdasarkan ke mana bola pergi setelah tekel. Ini bukan tekel, ketika seorang pemain memotong operan dengan cara apa pun.</p>

<p>6.1.31.1. Gol/Gol Bunuh Diri Badan pengatur yang berbeda memiliki aturan yang berbeda, dan jika memungkinkan Opta bekerja dengan orang yang relevan untuk mencerminkan keputusan resmi mereka tentang pencetak gol. Mengenai defleksi, biasanya gol diberikan jika upaya awal tepat sasaran. Gol bunuh diri biasanya diberikan jika upayanya tidak mengenai sasaran dan dibelokkan ke gawang oleh lawan.</p>

<p>6.1.31.2. Tembakan Target tembakan didefinisikan sebagai setiap upaya yang jelas untuk mencetak gol yang: Masuk ke gawang terlepas dari niatnya. Adalah upaya yang jelas untuk mencetak gol yang seharusnya masuk ke gawang tetapi karena diselamatkan oleh penjaga gawang atau dihentikan oleh pemain yang orang terakhir dengan penjaga gawang yang tidak memiliki peluang untuk mencegah gawang (blok baris terakhir).Melewati atau melebar dari gawang tanpa melakukan kontak dengan pemain lain. Akan melewati atau melebar dari gawang tetapi dihentikan oleh penyelamatan kiper atau oleh pemain outfield.Langsung mengenai bingkai gawang dan tidak ada gol yang tercipta.Tembakan yang terhalang tidak dihitung sebagai tembakan.</p>
  <p>\u25CF Masuk ke jaring apa pun tujuannya.</p>

<p>\u25CF Merupakan upaya yang jelas untuk mencetak gol yang seharusnya masuk ke gawang tetapi karena diselamatkan oleh penjaga gawang atau dihentikan oleh pemain yang merupakan orang terakhir dengan penjaga gawang tidak memiliki peluang untuk mencegah gol (blok baris terakhir ).</p>

<p>\u25CF Melewati atau melebar dari gawang tanpa melakukan kontak dengan pemain lain.</p>

<p>\u25CF Akan melewati atau melebar dari gawang tetapi dihentikan oleh penyelamatan kiper atau pemain outfield.</p>

<p>\u25CF Langsung mengenai bingkai gawang dan tidak ada gol yang tercipta. Tembakan yang terhalang tidak dihitung sebagai tembakan.</p>

<p>6.1.1.31.3. Tembakan ke gawang - setiap upaya gawang yang: Masuk ke gawang terlepas dari niatnya. Merupakan upaya yang jelas untuk mencetak gol yang seharusnya masuk ke gawang tetapi karena diselamatkan oleh penjaga gawang atau dihentikan oleh pemain yang menjadi orang terakhir dengan penjaga gawang tidak memiliki peluang untuk mencegah gawang (blok baris terakhir).Tembakan yang langsung mengenai bingkai gawang tidak dihitung sebagai tembakan tepat sasaran, kecuali bola masuk dan diberikan sebagai gol.Tembakan diblok oleh pemain lain, yang bukan orang terakhir, tidak dihitung sebagai tembakan tepat sasaran.</p>

<p>\u25CF Masuk ke jaring apa pun tujuannya.</p>

<p>\u25CF Merupakan upaya yang jelas untuk mencetak gol yang seharusnya masuk ke gawang tetapi karena diselamatkan oleh penjaga gawang atau dihentikan oleh pemain yang merupakan orang terakhir dengan penjaga gawang tidak memiliki peluang untuk mencegah gol (blok baris terakhir). Tembakan langsung mengenai bingkai gawang tidak dihitung sebagai tembakan tepat sasaran, kecuali bola masuk dan diberikan sebagai gol. Tembakan yang diblok oleh pemain lain, yang bukan orang terakhir, tidak dihitung sebagai tembakan tepat sasaran.</p>
  <p>6.1.31.4. Goal Assist Sentuhan terakhir (pass, pass-cum-shot atau sentuhan lainnya) yang mengarah ke penerima bola untuk mencetak gol. Jika sentuhan akhir (sebagaimana didefinisikan dalam huruf tebal) dibelokkan oleh pemain lawan, inisiator hanya diberikan assist gol jika pemain penerima kemungkinan besar akan menerima bola tanpa terjadi defleksi. Gol bunuh diri, tendangan bebas langsung, gol sudut langsung, dan penalti tidak mendapatkan assist yang diberikan.</p>
  <p>6.1.31.5. Tekel ,Tekel didefinisikan sebagai di mana seorang pemain terhubung dengan bola dalam tantangan tanah di mana ia berhasil mengambil bola dari pemain yang dikuasai. Pemain yang ditekel harus dengan jelas menguasai bola sebelum tekel dilakukan. Tekel yang dimenangkan adalah dianggap di mana tekel atau salah satu rekan satu timnya mendapatkan kembali kepemilikan sebagai akibat dari tantangan, atau bahwa bola keluar dari permainan dan "aman". Tekel hilang adalah saat tekel dilakukan tetapi bola masuk ke pemain lawan.Keduanya dianggap sebagai tekel yang berhasil, namun hasil tekel (menang atau kalah) berbeda berdasarkan ke mana bola pergi setelah tekel. Ini bukan tekel, ketika seorang pemain memotong operan dengan cara apa pun.</p>
  <p>\u25CF Tekel yang dimenangkan dianggap di mana tekel atau salah satu rekan satu timnya mendapatkan kembali penguasaannya sebagai akibat dari tekel tersebut, atau bola keluar dari permainan dan \u201Caman\u201D.</p>

<p>\u25CF Tekel kalah adalah saat tekel dilakukan tetapi bola jatuh ke pemain lawan. Keduanya dianggap sebagai tekel yang berhasil, namun hasil tekel (menang atau kalah) berbeda berdasarkan ke mana bola pergi setelah tekel. bukan tekel, ketika seorang pemain memotong operan dengan cara apa pun.</p>
  <p>6.2. Tenis </p>

<p>6.2.1. Jika pemain mengundurkan diri dan walk over, semua taruhan yang belum diputuskan dianggap batal.</p>

<p>6.2.2. Jika ada penundaan (hujan, gelap...) semua pasar tetap tidak stabil dan perdagangan akan dilanjutkan segera setelah pertandingan berlanjut.</p>

<p>6.2.3. Jika poin penalti diberikan oleh wasit, semua taruhan pada permainan itu akan berlaku.</p>

<p>6.2.4. Jika pertandingan selesai sebelum poin/permainan tertentu selesai, semua pasar terkait poin/permainan yang terpengaruh dianggap batal.</p>

<p>6.2.5. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.2.6. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.2.7. Jika seorang pemain pensiun, semua pasar yang belum diputuskan dianggap batal. </p>

<p>6.2.8. Jika pertandingan ditentukan dengan tie-break Pertandingan maka itu akan dianggap sebagai set ke-3</p>

<p>6.2.9. Setiap tie-break atau tie-break Pertandingan dihitung sebagai 1 pertandingan</p>
  <p>6.3. Bola Basket</p>

<p>6.3.1. Pasar tidak mempertimbangkan lembur kecuali dinyatakan lain.</p>

<p>6.3.2. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 2 menit), kami berhak membatalkan taruhan.</p>

<p>6.3.3. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.3.4. Jika pertandingan tidak berakhir seri, tetapi perpanjangan waktu dimainkan untuk tujuan kualifikasi, pasar akan diselesaikan sesuai dengan hasil di akhir waktu reguler.</p>

<p>6.3.5. Jika pertandingan berakhir sebelum Xth tercapai, pasar ini dianggap batal (dibatalkan). Siapa yang mendapat poin X? (termasuk ot), Tim mana yang akan memenangkan perlombaan untuk mendapatkan x poin? (termasuk. Lembur).</p>

<p>6.3.6. Pasaran (Apakah akan ada perpanjangan waktu?) akan diselesaikan sebagai ya jika pada akhir waktu reguler pertandingan berakhir seri, terlepas dari apakah perpanjangan waktu dimainkan atau tidak.</p>
  <p>6.4. Sepak Bola Amerika</p>

<p>6.4.1. Jika ada penundaan (hujan, gelap...) semua pasar tetap tidak stabil dan perdagangan akan dilanjutkan segera setelah pertandingan berlanjut.</p>

<p>6.4.2. Pasar tidak mempertimbangkan lembur kecuali dinyatakan lain.</p>

<p>6.4.3. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.4.4. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 89 detik), kami berhak membatalkan taruhan.</p>

<p>6.4.5. Jika skor yang ditampilkan salah, kami berhak membatalkan taruhan untuk jangka waktu ini</p>

<p>6.4.6. Jika pertandingan ditinggalkan atau ditunda, semua pasar dianggap batal kecuali pertandingan berlanjut dalam jadwal mingguan NFL yang sama (Kamis - Rabu waktu stadion setempat).</p>

<p>6.4.7. Jika tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan</p>

<p>6.4.8. Semua pemain yang ditawarkan dianggap sebagai pelari.</p>

<p>6.4.9. Jika tidak ada touchdown lebih lanjut yang dicetak, pasar (Pencetak touchdown berikutnya (termasuk perpanjangan waktu)) akan dibatalkan.</p>

<p>6.4.10. Pemain yang tidak terdaftar dianggap sebagai "Pesaing1 pemain lain" atau "Pesaing2 pemain lain" untuk tujuan penyelesaian. Perhatikan bahwa ini tidak termasuk pemain yang terdaftar tanpa harga aktif.</p>

<p>6.4.11. Pemain dari tim Pertahanan- atau Khusus dianggap sebagai \u201CPesaing pertama\u201D atau \u201CPesaing kedua\u201D untuk tujuan penyelesaian, meskipun pemain tersebut terdaftar sebagai hasil khusus.</p>

<p>6.4.12. Pasar akan diselesaikan berdasarkan sisipan TV dan statistik yang disediakan oleh asosiasi resmi kecuali ada bukti jelas bahwa statistik tidak benar.</p>
  <p>6.5. Hoki Es</p>

<p>6.5.1. Semua pasar (kecuali pasar periode, perpanjangan waktu, dan adu penalti) dianggap hanya untuk waktu reguler kecuali disebutkan di pasar.</p>

<p>6.5.2. Jika suatu pertandingan ditentukan melalui adu penalti, maka satu gol akan ditambahkan ke skor tim pemenang dan total pertandingan untuk tujuan penyelesaian. Ini berlaku untuk semua pasar termasuk perpanjangan waktu dan adu penalti</p>

<p>6.5.3. Jika pasar tetap terbuka saat peristiwa berikut telah terjadi: gol dan penalti, kami berhak membatalkan taruhan.</p>

<p>6.5.4. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 2 menit), kami berhak membatalkan taruhan.</p>

<p>6.5.5. Jika skor yang salah dimasukkan, semua pasar akan dibatalkan pada saat skor yang salah ditampilkan.</p>
  <p>6.6. Bisbol</p>

<p>6.6.1. Jika sebuah inning berakhir sebelum poin X tercapai (termasuk inning tambahan), pasar ini (Tim mana yang memenangkan perlombaan untuk mendapatkan x poin?, Siapa yang mencetak poin X (termasuk ot)) dianggap batal (dibatalkan).</p >

<p>6.6.2. Pasaran (Kapan pertandingan akan diputuskan?) akan diselesaikan sebagai \u201CSetiap babak tambahan\u201D jika pada akhir waktu reguler (Setelah 9 babak penuh) pertandingan berakhir seri, terlepas dari apakah perpanjangan waktu atau tidak (Babak tambahan) dimainkan</p>

<p>6.6.3. Pasaran (Apakah akan ada perpanjangan waktu?) akan diselesaikan sebagai \u201CYa\u201D jika pada akhir waktu reguler (Setelah 9 babak penuh) pertandingan berakhir seri, terlepas dari apakah perpanjangan waktu (Babak tambahan) dimainkan atau tidak</p >

<p>6.6.4. Kemungkinan babak tambahan tidak dipertimbangkan di pasar mana pun kecuali dinyatakan lain.</p>

<p>6.6.6.5. Semua pasar akan diselesaikan sesuai dengan hasil akhir setelah 9 inning (8 inning jika tim tuan rumah memimpin pada saat ini)</p>

<p>6.6.6. Jika pertandingan terganggu atau dibatalkan dan tidak akan dilanjutkan pada hari yang sama, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.6.7. Jika pasar tetap terbuka dengan skor yang salah atau status pertandingan yang salah yang berdampak signifikan pada harga, kami berhak untuk membatalkan taruhan.</p>

<p>6.7. Bola tangan</p>

<p>6.7.1. Jika pertandingan berakhir sebelum Xth tercapai, pasar ini (Siapa yang mencetak poin Xth? (termasuk ot)) dianggap batal (dibatalkan)</p>

<p>6.7.2. Jika pertandingan berakhir sebelum Xth tercapai, pasar ini (Tim mana yang akan memenangkan perlombaan untuk mendapatkan x poin? (termasuk ot)) dianggap batal (dibatalkan).</p>

<p>6.7.3. Semua pasar (kecuali Siapa yang mencetak poin X dan tim mana yang akan memenangkan perlombaan untuk mendapatkan poin X) dianggap hanya untuk waktu reguler.</p>

<p>6.7.4. Jika pertandingan berlanjut ke adu penalti 7 meter; pasar "Siapa yang mendapat poin X?" dan \u201CTim mana yang akan memenangkan perlombaan untuk mendapatkan poin X?\u201D akan dibatalkan.</p>

<p>6.7.5. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 3 menit), kami berhak untuk membatalkan taruhan.</p>

<p>6.7.6. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan..</p>

  <p>6.8. Bola voli</p>

<p>6.8.1. Jika set berakhir sebelum poin X tercapai, pasar ini (Siapa yang mencetak poin [X] di set [y]) dianggap batal (dibatalkan)</p>

<p>6.8.2. Jika pertandingan tidak selesai, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.8.3. Set emas tidak dipertimbangkan di salah satu pasar yang disebutkan</p>

<p>6.8.4. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.8.5. Pengurangan poin resmi akan diperhitungkan untuk semua pasar yang belum ditentukan. Pasar yang telah ditentukan tidak akan memperhitungkan pemotongan.</p>
  <p>6,9. Bola Voli Pantai</p>

<p>6.9.1. jika set berakhir sebelum poin X tercapai, pasar ini (Siapa yang mencetak poin [X] di set [y]) dianggap batal (dibatalkan)</p>

<p>6.9.2. Jika pertandingan tidak selesai, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.9.3. Set emas tidak dipertimbangkan di salah satu pasar yang disebutkan</p>

<p>6.9.4. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.9.5. Jika tim pensiun, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.9.6. Pengurangan poin resmi akan diperhitungkan untuk semua pasar yang belum ditentukan. Pasar yang telah ditentukan tidak akan memperhitungkan pemotongan.</p>

<p>6.10. Futsal</p>

<p>6.10.1. Semua pasar (kecuali babak pertama, babak pertama, perpanjangan waktu, dan adu penalti) dianggap hanya untuk waktu reguler.</p>

<p>6.10.2. Jika pertandingan dihentikan dan dilanjutkan dalam waktu 48 jam setelah tanggal kick-off awal, semua taruhan terbuka akan diselesaikan dengan hasil akhir. Jika tidak, semua taruhan yang belum diputuskan dianggap batal.</p>

<p>6.10.3. Jika pasar tetap terbuka saat peristiwa berikut telah terjadi: gol, kartu merah atau kuning-merah, dan penalti, kami berhak membatalkan taruhan.</p>

<p>6.10.4. Jika pasar dibuka dengan kartu merah yang hilang atau salah, kami berhak untuk membatalkan taruhan.</p>

<p>6.10.5. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 2 menit), kami berhak untuk membatalkan taruhan.6.10.6 Jika skor yang dimasukkan salah, semua pasar akan dibatalkan pada saat skor yang salah ditampilkan.6.10 .7. Jika nama atau kategori tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>
  <p>6.11. Bulutangkis</p>

<p>6.11.1. Jika set berakhir sebelum poin X tercapai, pasar ini (Siapa yang mencetak poin [X] di set [N]) dianggap batal (dibatalkan)</p>

<p>6.11.2. Jika pertandingan tidak selesai, semua pasar yang belum diputuskan dianggap batal.</p>

<p><p>6.11.3. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.11.4. Jika tim pensiun, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.11.5. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.11.6. Pengurangan poin resmi akan diperhitungkan untuk semua pasar yang belum ditentukan. Pasar yang telah ditentukan tidak akan memperhitungkan pemotongan.</p>

<p>6.12. Persatuan Rugbi dan Liga Rugbi</p>

<p>6.12.1. Semua pasar (kecuali babak pertama, babak pertama, perpanjangan waktu, dan adu penalti) dianggap hanya untuk waktu reguler.</p>

<p>6.12.2. Reguler 80 Menit: Pasaran didasarkan pada hasil di akhir permainan 80 menit yang dijadwalkan kecuali dinyatakan lain. Ini termasuk cedera tambahan atau waktu penghentian tetapi tidak termasuk perpanjangan waktu, waktu yang dialokasikan untuk adu penalti, atau kematian mendadak.</p>

<p>6.12.3. Jika pasar tetap terbuka saat peristiwa berikut telah terjadi: perubahan skor atau kartu merah, kami berhak untuk membatalkan taruhan.</p>

<p>6.12.4. Jika pasar dibuka dengan kartu merah yang hilang atau salah, kami berhak untuk membatalkan taruhan.</p>

<p>6.12.5. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 2 menit), kami berhak membatalkan taruhan.</p>

<p>6.12.6. Jika nama atau kategori tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.13. Rugby Sevens</p>

<p>6.13.1. Semua pasar (kecuali babak pertama, babak pertama, perpanjangan waktu, dan adu penalti) dianggap hanya untuk waktu reguler.</p>

<p>6.13.2. Reguler 14 / 20 Menit: Pasaran didasarkan pada hasil di akhir permainan 14 / 20 menit yang dijadwalkan kecuali dinyatakan lain. Ini termasuk cedera tambahan atau waktu penghentian tetapi tidak termasuk perpanjangan waktu, waktu yang dialokasikan untuk adu penalti, atau kematian mendadak</p>

<p>6.13.3. Jika pasar tetap terbuka saat peristiwa berikut telah terjadi: perubahan skor atau kartu merah, kami berhak untuk membatalkan taruhan.</p>

<p>6.13.4. Jika pasar dibuka dengan kartu merah yang hilang atau salah, kami berhak untuk membatalkan taruhan.</p>

<p>6.13.5. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 1 menit), kami berhak untuk membatalkan taruhan.</p>

<p>6.13.6. Jika nama atau kategori tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

  <p>6.14. Anak panah</p>

<p>6.14.1. Jika pertandingan tidak selesai, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.14.2. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.14.3. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.14.4. Jika pertandingan tidak diselesaikan, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.14.5. Bullseye dianggap sebagai warna check out merah.</p>

<p>6.15. Snooker</p>

<p>6.15.1. Dalam kasus pengunduran diri pemain atau diskualifikasi, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.15.2. Dalam hal penyelesaian rak ulang tetap jika hasilnya ditentukan sebelum rak ulang</p>

<p>6.15.3. Tidak ada pelanggaran atau bola bebas yang dipertimbangkan untuk penyelesaian pasar Pot-Warna mana pun</p>

<p>6.15.4. Jika sebuah frame dimulai tetapi tidak selesai, semua pasar terkait frame akan dibatalkan kecuali jika hasilnya telah ditentukan</p>

<p>6.15.5. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.15.6. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.15.7. Jika pertandingan tidak diselesaikan, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.16. Tenis Meja</p>

<p>6.16.1. Jika set berakhir sebelum poin X tercapai, pasar ini (Siapa yang mencetak poin [X] di set [y]) dianggap batal (dibatalkan).</p>

<p>6.16.2. Jika pertandingan tidak selesai, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.16.3. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.16.4. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.16.5. Jika seorang pemain pensiun, semua pasar yang belum diputuskan dianggap batal.</p>

<p>6.16.6. Pengurangan poin resmi akan diperhitungkan untuk semua pasar yang belum ditentukan. Pasar yang telah ditentukan tidak akan memperhitungkan pemotongan.</p>

<p>6.17. Bowls</p>

<p>6.17.1. Jika satu set berakhir sebelum poin X tercapai, pasar ini (set X - tim mana yang memenangkan perlombaan ke x poin, set X - tim mana yang mencetak poin X) dianggap batal (dibatalkan)</p>

<p>6.17.2. Jika pemain mengundurkan diri dan walk over, semua taruhan yang belum diputuskan dianggap batal.</p>

<p>6.17.3. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.17.4. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>
  <p>6.18. Kriket</p>

<p>6.18.1. Taruhan PertandinganDeskripsi: Siapa yang akan memenangkan pertandingan?Aturan: Semua taruhan pertandingan akan diselesaikan sesuai dengan aturan kompetisi resmi. Dalam pertandingan yang dipengaruhi oleh cuaca buruk, taruhan akan diselesaikan sesuai dengan hasil resmi. Jika tidak ada hasil resmi, semua taruhan akan dibatalkan. Dalam kasus seri, jika aturan kompetisi resmi tidak menentukan pemenang, maka aturan deadheat akan mengajukan. Dalam kompetisi di mana bowl off atau super over menentukan pemenang, taruhan akan diselesaikan pada hasil resmi. Dalam Pertandingan Kelas Satu, jika hasil resminya seri, taruhan akan diselesaikan sebagai pertandingan mati-matian antara kedua tim. Taruhan pada undian akan diselesaikan sebagai pecundang. Jika pertandingan ditinggalkan karena faktor eksternal, maka taruhan akan dibatalkan kecuali pemenang diumumkan berdasarkan peraturan resmi kompetisi. Jika pertandingan dibatalkan maka semua taruhan akan dibatalkan jika pertandingan tersebut dibatalkan. tidak diputar ulang atau dimulai ulang dalam waktu 36 jam dari waktu mulai yang diiklankan.</p>

<p>6.18.2. Peluang GandaDeskripsi: Apakah hasil pertandingan akan menjadi salah satu dari tiga opsi yang diberikan?Aturan: Seri akan diselesaikan sebagai putaran mati. Semua taruhan pertandingan akan diselesaikan sesuai dengan aturan kompetisi resmi. Jika tidak ada hasil resmi, semua taruhan akan dibatalkan.</p>

<p>6.18.3. Match Betting: Draw No BetDeskripsi: Siapa yang akan memenangkan pertandingan mengingat semua taruhan akan dibatalkan jika pertandingan seri? Aturan: Tie akan diselesaikan sebagai dead heat. Semua taruhan pertandingan akan diselesaikan sesuai dengan aturan kompetisi resmi. Jika tidak ada hasil resmi, semua taruhan akan dibatalkan.</p>

<p>6.18.4. Tied MatchDeskripsi: Apakah pertandingan akan seri?Aturan: Semua taruhan akan diselesaikan sesuai dengan hasil resmi. Jika pertandingan ditinggalkan atau tidak ada hasil resmi, semua taruhan akan dibatalkan. Untuk pertandingan Kelas Satu, seri adalah saat sisi pukulan kedua dilempar keluar untuk kedua kalinya dengan tingkat skor.</p>

<p>6.18.5. Fours TerbanyakDeskripsi: Tim mana yang akan mencapai fours paling banyak?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk di-bow di kedua inning karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang telah di-bow, kecuali penyelesaian taruhan telah ditentukan. Hanya fours yang dicetak dari bat (dari pengiriman apa pun \u2013 legal atau tidak) akan dihitung dalam total fours. Menggulingkan, semua lari empat dan ekstra tidak dihitung. Empat yang dicetak dalam super over tidak dihitung. Dalam permainan Kelas Satu, hanya empat babak pertama yang akan dihitung.</p>

  <p>6.18.6. Kebanyakan SixesDeskripsi: Tim mana yang akan mencapai sixes paling banyak?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk di-bow di kedua inning karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Hanya enam yang dicetak dari bat (dari pengiriman apa pun \u2013 legal atau tidak) akan dihitung terhadap total berenam. Penggulingan dan tambahan tidak dihitung. Enam yang dicetak dalam super over tidak dihitung. Dalam permainan Kelas Satu, hanya enam babak pertama yang akan dihitung.</p>

<p>6.18.7. Ekstra TerbanyakDeskripsi: Tim mana yang akan memiliki lebih banyak ekstra yang ditambahkan ke skor pukulan mereka? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk dilempar di salah satu babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over telah di-bow, kecuali penyelesaian taruhan telah ditentukan. Semua pengiriman melebar, tidak ada bola, bye, leg bye, dan tendangan penalti dalam pertandingan diperhitungkan dalam hasil akhir. Jika ada run off bat serta ekstra dari pengiriman yang sama, run off bat tidak dihitung terhadap total akhir. Ekstra dalam super over tidak dihitung. Dalam permainan Kelas Satu, hanya ekstra inning pertama yang akan dihitung. </p>

<p>6.18.8. Kebobolan Run Out TerbanyakDeskripsi: Tim mana yang akan kebobolan run out paling banyak dalam pertandingan? Aturan: Run out \u201Ckebobolan\u201D berarti bahwa anggota tim tersebut akan kehabisan saat memukul. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari over yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 overs telah di-bow, kecuali penyelesaian taruhan telah ditentukan.Run Out dalam super over tidak dihitung.Dalam game First Class, hanya run out inning pertama yang akan dihitung.</p>

<p>6.18.9. Deskripsi Over Pertama Tertinggi: Tim mana yang akan mencetak skor run paling banyak di over pertama dari inning mereka? Aturan: Over pertama harus diselesaikan agar taruhan tetap berlaku kecuali penyelesaian telah ditentukan. Jika selama babak pertama berakhir karena faktor eksternal, termasuk cuaca buruk, semua taruhan akan dibatalkan, kecuali penyelesaian telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu pasar hanya mengacu pada babak pertama masing-masing tim. Ekstra dan penalti berjalan di atas hitungan tertentu menuju penyelesaian.</p>

<p>6.18.10. Lari Terbanyak di Grup OverDescription: Tim mana yang akan mencetak run terbanyak setelah jumlah overs pertama yang ditentukan dari inning mereka?Aturan: Jika jumlah overs yang ditentukan tidak selesai, taruhan akan dibatalkan, kecuali tim tersebut habis, demikian, mencapai target atau penyelesaian taruhan telah ditentukan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang ditentukan telah di-bow pada saat taruhan ditempatkan karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu, pasar hanya mengacu pada babak pertama masing-masing tim.</p>
  <p>6.18.11. Kemitraan Pertama TertinggiDeskripsi: Tim mana yang akan mencetak skor lari paling banyak sebelum kehilangan gawang pertama mereka? Aturan: Jika tim pemukul mencapai akhir dari over yang diberikan, mencapai target mereka atau menyatakan sebelum gawang pertama jatuh, hasilnya akan menjadi jumlah total. Untuk tujuan penyelesaian, abatsman yang mengundurkan diri terluka tidak dihitung sebagai gawang. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika babak telah dikurangi karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan sebelum pengurangan. Pertandingan Kelas Satu, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Dalam pertandingan Kelas Satu, pasar hanya mengacu pada babak pertama masing-masing tim.</p>

<p>6.18.12. Match Markets Match FoursDeskripsi: Berapa fours yang akan di hit dalam pertandingan?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk di-bow karena faktor eksternal , termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Hanya skor fours dari kelelawar (dari pengiriman apa pun \u2013 legal atau tidak) akan dihitung dalam total fours. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung. Skor empat dalam super over tidak dihitung.</p>

<p>6.18.13. Match SixesDeskripsi: Berapa sixes yang akan dipukul dalam pertandingan?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk di-bow karena faktor eksternal, termasuk buruk cuaca, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Hanya enam yang dicetak dari kelelawar (dari pengiriman apa pun \u2013 legal atau tidak) akan dihitung dalam jumlah empat. Penggulingan dan ekstra tidak dihitung. Enam yang dicetak dalam super over tidak dihitung.</p>

<p>6.18.14. Match ExtrasDeskripsi: Berapa banyak ekstra yang akan dicetak dalam pertandingan?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk di-bow karena faktor eksternal, termasuk buruk cuaca, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Semua pengiriman lebar, tidak ada bola , bye, leg bye, dan penalti run dalam pertandingan dihitung terhadap hasil akhir. Jika ada run off bat serta ekstra dari pengiriman yang sama, run off bat tidak dihitung terhadap total akhir. Ekstra dalam super over tidak dihitung.</p>

<p>6.18.15. Match Run OutsDeskripsi: Berapa banyak run out yang akan terjadi dalam pertandingan?Aturan: Dalam pertandingan terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Kehabisan dalam a super over tidak dihitung. Maksimum Over dalam Pertandingan Deskripsi: Berapa banyak run yang akan dicetak pada skor tertinggi pertandingan? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari over yang dijadwalkan untuk di-bow karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan First Class yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang telah di-bow, kecuali ditetapkan elemen taruhan telah ditentukan. Semua putaran, termasuk ekstra, dihitung untuk penyelesaian. Super over tidak dihitung.</p>


  <p>6.18.16. Match Top BatsmanDeskripsi: Batsman mana yang akan mencetak run paling banyak dalam pertandingan?Aturan: Hasil pasaran ini ditentukan pada batsman dengan skor individu tertinggi dalam pertandingan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika belum mungkin untuk menyelesaikan setidaknya 50% dari overs yang dijadwalkan untuk dilempar di kedua babak pada saat taruhan ditempatkan karena faktor eksternal, termasuk cuaca buruk. Taruhan batsmen teratas untuk pertandingan Kelas Satu hanya berlaku untuk babak pertama setiap tim, dan akan dibatalkan jika kurang dari 200 over telah di-bow, kecuali penyelesaian taruhan telah ditentukan. Jika seorang pemain disebutkan namanya pada saat lemparan, tetapi kemudian dikeluarkan sebagai pengganti gegar otak, pemain itu akan tetap dihitung, begitu juga dengan pemain pengganti. stand.Jika pemain pengganti (gegar otak, atau lainnya) yang tidak disebutkan dalam XI asli mencetak skor individu tertinggi di babak tim, taruhan di pasar akan dibatalkan. Ketika dua atau lebih pemain mencetak jumlah run yang sama, dead-heat aturan akan berlaku. Skor lari dalam super over tidak dihitung.</p>

<p>6.18.17. Match Top BowlerDeskripsi: Bowler mana yang akan mengambil wicket paling banyak dalam pertandingan?Aturan: Hasil pasaran ini ditentukan pada bowler dengan wicket terbanyak dalam pertandingan. Dalam pertandingan limited overs, taruhan akan dibatalkan jika tidak dimungkinkan untuk menyelesaikan setidaknya 50% dari overs yang dijadwalkan untuk dilempar di salah satu babak pada saat taruhan ditempatkan karena faktor eksternal, termasuk cuaca buruk. Taruhan bowler teratas untuk pertandingan Kelas Satu hanya berlaku untuk babak pertama dari setiap tim, dan akan dibatalkan jika kurang dari 200 over telah dilempar, kecuali penyelesaian taruhan telah ditentukan. Jika seorang pemain disebutkan dalam undian, tetapi kemudian dikeluarkan sebagai pengganti gegar otak, pemain itu akan tetap dihitung, begitu juga dengan pemain pengganti. stand.Jika pengganti (gegar otak, atau lainnya) yang tidak disebutkan dalam XI asli mengambil wicket paling banyak, taruhan di pasar akan dibatalkan. Jika dua atau lebih bowler telah mengambil jumlah wicket yang sama, bowler yang kebobolan lari paling sedikit akan menjadi pemenangnya. Jika ada dua atau lebih bowler dengan wicket yang sama diambil dan kebobolan, aturan dead heat akan berlaku. Gawang yang diambil dalam super over tidak dihitung. Jika tidak ada pemain yang mengambil gawang di babak maka semua taruhan akan dibatalkan.</p>

<p>6.18.18. Man of the MatchDeskripsi: Siapa yang akan dinobatkan sebagai man of the match?Aturan: Taruhan akan diselesaikan pada man of the match yang dinyatakan secara resmi. Aturan panas mati berlaku. Jika tidak ada man of the match yang diumumkan secara resmi maka semua taruhan akan dibatalkan.</p>

<p>6.18.19. Pasar Pengiriman Runs PengirimanDeskripsi: Berapa banyak run yang akan dinilai dari pengiriman yang ditentukan?Aturan: Hasilnya akan ditentukan oleh jumlah run yang ditambahkan ke total tim, dari pengiriman yang ditentukan.Untuk tujuan penyelesaian, semua bola ilegal dihitung sebagai pengiriman . Misalnya, jika sebuah over dimulai dengan lebar, maka pengiriman pertama akan diselesaikan sebagai 1 dan, meskipun belum ada ballbowled yang sah, bola berikutnya akan dianggap sebagai pengiriman 2 untuk over itu. Jika pengiriman mengarah ke free hit atau free hit akan di-bowling ulang karena pengiriman ilegal, skor run dari pengiriman tambahan tidak dihitung. Semua run, baik off the bat atau tidak disertakan. Misalnya, lebar dengan tiga lari ekstra yang diambil sama dengan total 4 lari dari pengiriman itu.</p>

<p>6.18.21. Over Markets Runs in OverDescription: Berapa banyak run yang akan dicetak dalam over yang ditentukan? Aturan: Over yang ditentukan harus diselesaikan agar taruhan tetap berlaku kecuali penyelesaian telah ditentukan. Jika babak berakhir selama over maka over itu akan dianggap selesai kecuali babak berakhir karena faktor eksternal, termasuk cuaca buruk, dalam hal ini semua taruhan akan dibatalkan, kecuali penyelesaian telah ditentukan. Jika over tidak tidak dimulai karena alasan apa pun, semua taruhan akan dibatalkan. Ekstra dan penalti berjalan di atas penghitungan tertentu menuju penyelesaian.</p>

<p>6.18.22. Batas dalam OverDescription: Apakah akan ada skor batas di over yang ditentukan?Aturan: Sebagai \u201CBerlari di Over\u201D. Hanya batasan yang dicetak dari bat (dari pengiriman apa pun \u2013 legal atau tidak) yang akan dihitung sebagai batasan. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung sebagai batas.</p>

<p>6.18.23. Wicket in Over Deskripsi: Akankah wicket jatuh dalam over yang ditentukan? Aturan: Sebagai \u201CRuns in Over\u201D. Untuk tujuan penyelesaian, setiap gawang akan dihitung, termasuk run out. Sebuah batsman pensiun terluka tidak dihitung sebagai gawang. Jika seorang batsman time out atau mengundurkan diri maka gawang dianggap telah terjadi pada bola sebelumnya. Pensiunan terluka tidak dihitung sebagai pemecatan.</p>

<p>6.18.24. Over Odd/EvenDescription: Apakah jumlah run yang dicetak pada over yang ditentukan akan ganjil atau genap? Aturan: Sebagai \u201CBerjalan di Over\u201D. Nol akan dianggap sebagai bilangan genap.</p>

<p>6.18.25. Group Markets Runs di Groups of OversDescription: Berapa banyak run yang akan dicetak dalam jumlah overs yang ditentukan?Aturan: Jika jumlah overs yang ditentukan tidak lengkap, taruhan akan dibatalkan, kecuali tim all out, menyatakan, mencapai target mereka atau penyelesaian taruhan telah ditentukan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika total inning dikurangi pada tahap apa pun menjadi kurang dari 80% dari overs maksimum yang dinyatakan pada saat taruhan dipasang, kecuali penyelesaian taruhan sudah ditentukan sebelum pengurangan.</p>

  <p>6.18.26. Gawang dalam Grup OverDeskripsi: Berapa banyak wicket yang akan jatuh dalam jumlah overs yang ditentukan?Aturan: Jika jumlah overs yang ditentukan tidak lengkap, taruhan akan dibatalkan, kecuali tim all out, menyatakan, mencapai target atau penyelesaian taruhan telah ditentukan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika total babak dikurangi pada setiap tahap menjadi kurang dari 80% dari overs maksimum yang dinyatakan pada saat taruhan ditempatkan, kecuali penyelesaian taruhan sudah ditentukan. Untuk tujuan penyelesaian, jika batsman time out atau mundur maka gawang dianggap telah terjadi pada bola sebelumnya. Pensiunan terluka tidak dihitung sebagai pemecatan.</p>

<p>6.18.27. Lari dalam SesiDeskripsi: Berapa banyak lari yang akan dicetak dalam sesi yang ditentukan?Aturan: Hasil ditentukan oleh jumlah total lari yang dicetak dalam sesi yang ditentukan, terlepas dari tim mana yang mencetaknya.Jika kurang dari 20 over yang dilempar dalam a sesi, taruhan akan dibatalkan kecuali penyelesaian telah ditentukan.</p>

<p>6.18.28. Innings Markets Innings RunsDeskripsi: Berapa banyak run yang akan dicetak oleh tim dalam inning yang ditentukan?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk dilempar di waktu taruhan dipasang karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Taruhan yang ditempatkan pada babak berikutnya akan tetap berlaku terlepas dari jumlah run yang dicetak di babak saat ini atau sebelumnya. Dalam pertandingan Kelas Satu yang ditarik, akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Taruhan juga akan dibatalkan dalam pertandingan kelas satu yang ditarik, jika kurang dari 60 over yang dilakukan pada babak yang tidak lengkap, kecuali penyelesaian taruhan telah ditentukan. Jika sebuah tim menyatakan, babak itu akan dianggap selesai untuk tujuan penyelesaian.</p>

<p>6.18.29. Innings WicketsDeskripsi: Berapa banyak wicket yang akan hilang dari tim pemukul di babak saat ini?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk di-bow pada saat itu taruhan ditempatkan karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over telah dilakukan, kecuali penyelesaian taruhan telah ditentukan. Pensiun terluka tidak dihitung sebagai pemecatan.</p>

<p>6.18.30. Innings FoursDeskripsi: Berapa fours yang akan dicapai tim batting di babak mereka saat ini? Aturan: Sama seperti Kebanyakan Four.</p>

  <p>6.18.31. Innings SixesDeskripsi: Berapa sixes yang akan dicapai tim batting di babak mereka saat ini? Aturan: Sama seperti Kebanyakan Enam.</p>

<p>6.18.32. Ekstra InningDeskripsi: Berapa banyak ekstra yang akan ditambahkan ke inning batting tim yang disebutkan? Aturan: Sama seperti Kebanyakan Ekstra.</p>

<p>6.18.33. Innings Run OutsDeskripsi: Berapa banyak run out yang akan terjadi pada inning? Aturan: Sama seperti Kebanyakan Ekstra.</p>

<p>6.18.34. Over Maksimum di InningDescription: Berapa banyak run yang akan dicetak dari skor tertinggi di inning saat ini? Aturan: Sama dengan Over Maksimum dalam Pertandingan</p>

<p>6.18.35. Babak Berlari, Ganjil atau Genap? Deskripsi: Apakah total babak berjalan ganjil atau genap? Aturan: Jika babak ditinggalkan, hangus atau tidak ada hasil resmi, semua taruhan akan dibatalkan.</p>

<p>6.18.36. Inning untuk diselesaikan dengan BoundaryDeskripsi: Akankah bola terakhir dari inning menjadi batasan? Aturan: Hanya batasan yang dicetak dari bat (tidak ada pengiriman \u2013 legal atau tidak) yang akan dihitung sebagai batasan. Overthrows, all run fours dan ekstra tidak dihitung sebagai batasan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika ada pengurangan jumlah over yang dijadwalkan untuk di-bow pada saat taruhan ditempatkan karena faktor eksternal, termasuk cuaca jelek. Jika pertandingan ditinggalkan atau tidak ada hasil resmi, semua taruhan akan dibatalkan.</p>

<p>6.18.37. Lari Tepat dalam Babak AkhirDeskripsi: Berapa jumlah lari tepat yang akan dicapai tim pada babak akhir skor? Aturan: Taruhan akan diselesaikan sesuai dengan hasil resmi. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika ada pengurangan jumlah over yang dijadwalkan untuk di-bow pada saat taruhan dipasang karena faktor eksternal, termasuk buruk cuaca.Jika pertandingan ditinggalkan atau tidak ada hasil resmi, semua taruhan akan dibatalkan.</p>

<p>6.18.38. Top Batsman in InningsDescription: Batsman mana yang akan mencetak run terbanyak untuk tim yang disebutkan?Aturan: Hasil pasaran ini ditentukan pada batsman dengan skor individu tertinggi dalam inning tim. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika itu belum mungkin untuk menyelesaikan setidaknya 50% dari over yang dijadwalkan untuk di-bow pada saat taruhan dipasang karena faktor eksternal, termasuk cuaca buruk. Taruhan batsmen teratas untuk pertandingan Kelas Satu hanya berlaku untuk babak pertama setiap tim , dan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Jika seorang pemain disebutkan namanya pada saat lemparan, tetapi kemudian dikeluarkan sebagai pengganti gegar otak, pemain itu akan tetap dihitung, begitu juga dengan pemain pengganti. stand.Jika pengganti (gegar otak, atau lainnya) yang tidak disebutkan dalam XI asli mencetak skor individu tertinggi di babak tim, taruhan di pasar akan dibatalkan. Ketika dua atau lebih pemain mencetak jumlah run yang sama, di babak aturan dead-heat akan berlaku. Lari yang mendapat skor super over tidak dihitung.</p>

<p>6.18.39. Top Bowler in InningsDeskripsi: Bowler mana yang akan mengambil wicket paling banyak untuk tim yang disebutkan? Aturan: Hasil pasar ini ditentukan pada bowler dengan jumlah wicket individu tertinggi di inning individu. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 50% dari over yang dijadwalkan untuk di-bow pada saat taruhan dipasang karena faktor eksternal, termasuk cuaca buruk. Taruhan top bowler untuk pertandingan First Class hanya berlaku untuk inning pertama dari masing-masing tim, dan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Jika seorang pemain disebutkan namanya pada undian, tetapi kemudian dikeluarkan sebagai sub gegar otak, pemain itu masih akan dihitung , seperti pemain pengganti.Jika seorang pemain bowling tidak melakukan bowling, tetapi disebutkan dalam starting XI, taruhan pada pemain bowler itu akan berlaku.Jika pemain pengganti (gegar otak, atau lainnya) yang tidak disebutkan dalam XI asli mengambil wicket paling banyak, taruhan di pasar akan dibatalkan. Jika dua atau lebih bowler mengambil jumlah wicket yang sama, bowler yang kebobolan run paling sedikit akan menjadi pemenangnya. Jika ada dua atau lebih bowler dengan wicket yang sama diambil dan kebobolan, aturan dead heat akan berlaku. Gawang yang diambil dalam super over tidak dihitung. Jika tidak ada pemain yang mengambil gawang di babak maka semua taruhan akan dibatalkan.</p>

<p>6.18.40. Last Man StandingDeskripsi: Pemukul mana yang tidak akan keluar setelah menyelesaikan babak? Aturan: Jika ada dua atau lebih pemukul yang tidak keluar setelah menyelesaikan babak, pemenang untuk tujuan penyelesaian akan menjadi batsman terakhir yang menghadapi pengiriman (legal atau tidak). Pemain tidak akan dianggap tidak keluar jika mereka tidak lagi berada di lipatan setelah pensiun terluka atau tidak memukul. Jika lebih dari 11 pemain memukul, pasar akan dibatalkan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika, setelah memasang taruhan, babak telah dikurangi dengan cara apa pun karena faktor eksternal, termasuk cuaca buruk.</p >
  <p>6.18.41. Batsmen Markets Batsman RunsDeskripsi: Berapa banyak run yang akan dicetak oleh batsman yang disebutkan?Aturan: Jika batsman menyelesaikan babak tidak keluar, sebagai akibat dari deklarasi, tim mencapai akhir dari over yang diberikan, atau tim mencapai target mereka; skornya akan menjadi hasil akhir. Jika pemukul tidak memukul, taruhan akan dibatalkan. Jika seorang batsman tidak berada di starting XI, taruhan akan dibatalkan. Jika seorang batsman mundur dengan cedera, tetapi kembali lagi nanti, total run yang dicetak oleh batsman itu di babak akan dihitung. Jika batsman tidak kembali nanti, hasil akhirnya akan seperti saat batsman pensiun. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua inning karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan, atau terus ditentukan. Hasil akan dianggap ditentukan jika garis di mana taruhan dipasang dilewati, atau batsman diberhentikan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan .Jalan yang dicetak dalam super over tidak dihitung.</p>

<p>6.18.42. Combined Batsman RunsDeskripsi: Berapa banyak total run yang akan dicetak oleh batsmen yang disebutkan? Aturan: Saat "Batsman Runs", dan jika salah satu batsman yang disebutkan tidak memukul, taruhan akan dibatalkan, kecuali penyelesaian taruhan telah ditentukan atau pergi akan ditentukan.</p>

<p>6.18.43. Batsman FoursDeskripsi: Berapa banyak empat yang akan dipukul oleh batsman yang disebutkan?Aturan: Jika batsman menyelesaikan babak tidak keluar, sebagai akibat dari deklarasi, tim mencapai akhir over yang ditentukan, atau tim mencapai target mereka; jumlah empatnya akan menjadi hasil akhir. Jika pemukul tidak memukul, taruhan akan dibatalkan. Jika seorang batsman tidak berada di starting XI, taruhan akan dibatalkan. Jika seorang batsman mundur dengan cedera, tetapi kembali lagi nanti, total four yang dipukul oleh batsman itu di babak akan dihitung. Jika batsman tidak kembali nanti, hasil akhirnya akan seperti saat batsman pensiun. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan, atau terus ditentukan. Hasil akan dianggap ditentukan jika garis di mana taruhan dipasang dilewati, atau batsman diberhentikan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan .Hanya skor merangkak dari kelelawar (dari pengiriman apa pun \u2013 legal atau tidak) yang akan dihitung untuk total merangkak. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung. Skor empat dalam super over tidak dihitung.</p>

<p>6.18.44. Batsman SixesDeskripsi: Berapa sixes yang akan dipukul oleh batsman yang disebutkan?Aturan: Jika seorang batsman menyelesaikan babak tidak keluar, sebagai akibat dari deklarasi, tim mencapai akhir dari over yang ditentukan, atau tim mencapai target mereka; jumlah enamnya akan menjadi hasil akhir. Jika pemukul tidak memukul, taruhan akan dibatalkan. Jika seorang batsman tidak berada di starting XI, taruhan akan dibatalkan. Jika seorang batsman mundur dengan cedera, tetapi kembali lagi nanti, total enam pukulan oleh batsman itu di babak akan dihitung. Jika batsman tidak kembali nanti, hasil akhirnya akan seperti saat batsman pensiun. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan, atau terus ditentukan. Hasil akan dianggap ditentukan jika garis di mana taruhan dipasang dilewati, atau batsman diberhentikan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan . Hanya enam yang dicetak dari kelelawar (dari pengiriman apa pun \u2013 legal atau tidak) yang akan dihitung untuk total merangkak. Penggulingan dan ekstra tidak dihitung. Enam yang dicetak dalam super over tidak dihitung.</p>

<p>6.18.45. Batsman MilestonesDeskripsi: Akankah batsman yang disebutkan mencapai milestone yang ditentukan?Aturan: Sebagai "Batsman Runs". Metode Pemberhentian Deskripsi: Bagaimana batsman yang disebutkan akan keluar? Aturan: Jika batsman yang ditentukan tidak keluar, semua taruhan akan dibatalkan. Jika pemukul yang ditentukan pensiun, dan tidak kembali ke pemukul nanti, semua taruhan akan dibatalkan. Jika pemukul itu kembali ke pemukul nanti dan keluar, taruhan akan tetap berlaku.</p>

  <p>6.18.46. Partnership Markets Fall of Next WicketDeskripsi: Berapa banyak run yang akan dicetak oleh tim pemukul ketika gawang berikutnya jatuh? Aturan: Jika tim pemukul mencapai akhir dari over yang diberikan, mencapai target atau menyatakan sebelum gawang yang ditentukan jatuh, hasilnya akan menjadi total yang dikumpulkan.Untuk tujuan penyelesaian, seorang batsman yang pensiun cedera tidak dihitung sebagai gawang. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, kecuali penyelesaian telah ditentukan, atau terus ditentukan. Hasil akan dianggap ditentukan jika garis di mana taruhan ditempatkan telah dilewati, atau gawang yang bersangkutan jatuh. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang telah di-bow, kecuali penyelesaian taruhan telah dilakukan. telah ditentukan.</p>

  <p>6.18.47. Next Man OutDeskripsi: Pemukul mana yang selanjutnya akan diberhentikan? Aturan: Jika salah satu pemukul yang pensiun terluka atau pemukul di lipatan berbeda dari yang dikutip, taruhan yang dipasang pada kedua pemukul akan dinyatakan batal. Jika tidak ada lagi wicket yang jatuh, semua taruhan akan dibatalkan.6.18.48, Batsman Match BetDeskripsi: Batsman mana dalam kemitraan saat ini yang akan mencetak skor run terbanyak di babak ini? Aturan: Taruhan akan diselesaikan berdasarkan skor resmi untuk batsmen yang ditentukan di inning, sebagaimana dirinci di bagian \u201CBatsman Runs\u201D di atas. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua inning karena faktor eksternal, termasuk cuaca buruk , setelah taruhan ditempatkan kecuali penyelesaian telah ditentukan.Metode Pembubaran Gawang BerikutnyaDeskripsi: Bagaimana batsman berikutnya akan keluar?Aturan: Hasil akan ditentukan oleh metode pemecatan gawang berikutnya yang jatuh. Abatsman pensiun terluka tidak dihitung sebagai gawang. Jika seorang batsman dipensiunkan, semua taruhan akan dibatalkan. Jika gawang yang ditentukan tidak jatuh, semua taruhan akan dibatalkan. Player Markets Batsman MatchbetDeskripsi: Manakah dari pemain yang disebutkan yang akan mencetak skor run terbanyak? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin diselesaikan pada setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over telah di-bow, kecuali penyelesaian taruhan telah sudah ditentukan. Kedua pemain harus masuk dalam starting XI, atau tampil sebagai pemain pengganti. Jika salah satu tidak maka selanjutnya pemukul semua taruhan masih diselesaikan. Skor yang dicetak dalam super over tidak dihitung. Taruhan Bowler Deskripsi: Manakah dari pemain yang disebutkan akan mengambil wicket paling banyak? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika itu belum mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over telah dilempar , kecuali penyelesaian taruhan telah ditentukan. Kedua pemain harus disebutkan dalam starting XI, atau tampil sebagai pemain pengganti. Jika salah satunya tidak, maka semua taruhan akan tetap diselesaikan.Gawang yang diambil dalam super over tidak dihitung.Pertandingan All-RounderDeskripsi: Manakah dari nama pemain yang akan mencetak poin terbanyak dalam sistem penilaian kinerja pemain?Aturan: Poin dihitung sebagai berikut: 1 poin per run, 20 poin per wicket, 10 poin per catch, 25 poin per stumping. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di salah satu inning karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over telah di-bow, kecuali penyelesaian taruhan telah ditentukan. Kedua pemain harus disebutkan namanya di starting XI, atau tampil sebagai pemain pengganti. Jika salah satu pemain tidak maka selanjutnya bat atau bowl maka semua taruhan masih diselesaikan. Poin yang dicetak dalam super over tidak dihitung. Penjaga PertandinganbetDeskripsi: Penjaga gawang mana yang mencetak poin lebih banyak dalam sistem penilaian kinerja pemain? Aturan: Poin adalah mencetak gol seperti di atas. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang seri, taruhan akan dibatalkan jika kurang dari 200 over telah dilempar, kecuali penyelesaian taruhan telah ditentukan. Kedua pemain yang disebutkan harus memulai pertandingan sebagai penjaga gawang, atau tampil sebagai pemain pengganti, tetapi jika peran permainan mereka berubah karena alasan apa pun, semua taruhan akan dibatalkan. masih diselesaikan sesuai dengan sistem penilaian di atas. Poin yang dicetak dalam super over tidak dihitung. Pasar Pop Up Hit GratisDeskripsi: Berapa banyak tim yang akan dinilai dari pengiriman hit gratis? Aturan: Hasil akan ditentukan oleh jumlah berjalan ditambahkan ke total tim, dari pengiriman yang ditentukan. Jika pukulan bebas dilempar ulang karena pengiriman ilegal, skor lari dari pukulan bebas kedua tidak dihitung. Ekstra dan tendangan penalti akan dihitung untuk penyelesaian. Misalnya, jika pukulan melebar pada pengiriman pukulan gratis yang ditentukan, hasilnya akan menjadi 1. Kemudian pasar hit gratis lainnya mungkin ditawarkan. Berlomba ke Lari 'X'Deskripsi: Pemukul mana yang akan mencapai jumlah lari yang ditentukan terlebih dahulu? Aturan: Semua taruhan berlaku, terlepas dari pembatasan apa pun. Jika tidak ada batsman yang mencapai jumlah lari yang ditentukan, pasar akan diselesaikan sebagai 'Tidak Juga'. Di sebelah Hit SixDescription: Batsman mana yang akan mencapai enam berikutnya?Aturan: Semua taruhan berlaku, terlepas dari dari pembatasan apapun. Jika batsman tidak mencetak enam setelah taruhan ditawarkan, maka pasar akan diselesaikan

'Tidak keduanya'.Overthrow dan ekstra tidak dihitung.Berikutnya Take a WicketDeskripsi: Bowler mana yang akan mengambil gawang berikutnya di babak ini?Aturan: Semua taruhan berlaku, terlepas dari pembatasan apa pun. Jika tidak ada pemain bowling yang disebutkan mengambil gawang, pasar akan diselesaikan sebagai 'Tidak satu pun dari yang di atas'. Untuk tujuan penyelesaian, batsman yang pensiun terluka tidak dihitung sebagai gawang. Run out, time out, pensiun dan metode pemberhentian lainnya yang tidak diberikan kepada bowler tertentu akan diselesaikan sebagai 'Tidak satu pun dari yang di atas'.Kemenangan OverDescription: Di babak mana dari tim yang disebutkan akan menyelesaikan pertandingan? Aturan: Semua taruhan akan dibatalkan jika tidak ada hasil resmi. Dalam pertandingan overs terbatas, semua taruhan akan dibatalkan jika, setelah memasang taruhan, overs maksimum yang mungkin dikurangi dengan cara apa pun. Pasarkan Satu Sisi Kedua Tim untuk Mencetak Skor 'X' RunsDeskripsi: Apakah kedua tim akan mencetak jumlah run yang ditentukan? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan untuk dilempar di kedua inning pada waktu taruhan ditempatkan karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 100 over yang dilakukan di salah satu tim terlebih dahulu babak, kecuali penyelesaian taruhan telah ditentukan. Hanya lari yang dicetak dalam hitungan babak pertama Jika sebuah tim menyatakan bahwa babak akan dianggap selesai untuk tujuan penyelesaian. Salah satu Metode Pemberhentian Batsman Deskripsi: Akankah salah satu dari batsmen yang disebutkan diberhentikan dalam metode yang ditentukan? Aturan: Semua taruhan akan diselesaikan, terlepas dari apakah salah satu batsman tetap tidak keluar, atau pensiun terluka, di akhir babak. Metode Pemberhentian Kedua Batsmen Deskripsi: Akankah kedua batsmen yang disebutkan diberhentikan dalam metode yang ditentukan? Aturan: Sebagai "Metode Pemberhentian Salah Satu Batsman". Runs of Consecutive DeliveryDeskripsi: Berapa banyak run yang akan dinilai dari setiap pengiriman yang ditentukan?Aturan: Sebagai "Runs off Delivery" kecuali jumlah run yang ditentukan harus dinilai dari kedua pengiriman yang disebutkan .Gawang dari PengirimanDeskripsi: Akankah gawang jatuh dalam pengiriman yang ditentukan?Aturan: Pengiriman yang ditentukan harus diselesaikan agar taruhan tetap berlaku.Untuk tujuan penyelesaian, setiap gawang akan dihitung, termasuk run out. Sebuah batsman pensiun terluka tidak dihitung sebagai gawang. Jika batsman time out atau mundur maka wicket dianggap telah terjadi pada bola sebelumnya.Kedua Batsmen yang Mencetak 'X' Runs in OverDescription: Akankah kedua batsmen mencetak jumlah run yang ditentukan di over?Aturan: The ditentukan di atas harus diselesaikan agar taruhan tetap berlaku kecuali penyelesaian telah ditentukan. Jika babak berakhir selama over maka over itu akan dianggap selesai kecuali babak berakhir karena faktor eksternal, termasuk cuaca buruk, dalam hal ini semua taruhan akan dibatalkan, kecuali penyelesaian telah ditentukan. Jika over tidak tidak dimulai dengan alasan apapun, semua taruhan akan dibatalkan. Lari harus dinilai dari kelelawar untuk menghitung penyelesaian. Taruhan akan diselesaikan terlepas dari apakah salah satu batsmen yang ditentukan dipecat atau dihentikan dengan cedera sebelum over dimulai. Kedua Batsmen Mencetak Batas di OverDescription: Akankah kedua batsmen mencetak batas di atas?Aturan: Sebagai "Kedua Batsmen untuk Skor 'X' Runs in Over". Baik merangkak dan berenam dihitung sebagai batas. Hanya skor empat atau enam dari kelelawar (dari pengiriman apa pun \u2013 legal atau tidak) yang akan dihitung. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung. Baik Empat dan Enam untuk Dicetak dalam OverDeskripsi: Apakah empat dan enam akan dicetak di atas? Aturan: Over yang ditentukan harus diselesaikan agar taruhan tetap berlaku kecuali penyelesaian sudah ditentukan. Jika babak berakhir selama over maka over itu akan dianggap selesai kecuali babak berakhir karena faktor eksternal, termasuk cuaca buruk, dalam hal ini semua taruhan akan dibatalkan, kecuali penyelesaian telah ditentukan. Jika over tidak dimulai karena alasan apa pun, semua taruhan akan dibatalkan. Hanya skor empat atau enam dari kelelawar (dari pengiriman apa pun \u2013 sah atau tidak) yang akan dihitung. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung. Tonggak Kombo Batsman dan BowlerDeskripsi: Akankah batsman bernama, dan bowler bernama, mencapai tonggak yang ditentukan? Aturan: Untuk batsman \u2013 sama seperti "Batsman Runs". Dalam permainan kelas satu, hanya skor lari pada babak pertama yang akan dihitung. Jika seorang batsman tidak berada di starting XI, atau diganti, taruhan akan dibatalkan. Untuk bowler \u2013 jika seorang bowler tidak melakukan bowling, mereka akan dianggap telah mengambil 0 wicket. Jika seorang bowler tidak ada di starting XI, atau diganti, taruhan akan dibatalkan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan pada inning yang relevan karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan First Class yang imbang, taruhan akan batal jika f lebih dari 200 over telah di-bow, kecuali inning bowling pemain selesai. Hasilnya akan dianggap ditentukan jika garis di mana taruhan ditempatkan dilewati. Dalam permainan Kelas Satu, hanya gawang babak pertama yang akan dihitung dan dijalankan. Gawang dan lari yang dicetak dalam super over tidak dihitung. Tonggak Kombo BatsmenDeskripsi: Akankah kedua pemukul mencapai tonggak yang ditentukan? Aturan: Sama seperti \u201CCombined Batsman Runs\u201D.Catatan untuk semua PasarPemain diusir/dipensiunkan Seorang pemain yang dikeluarkan dianggap mengundurkan diri, jadi akan ditetapkan sebagai gawang. Pergantian gegar otak Ketika seorang pemain meninggalkan lapangan sebagai pengganti gegar otak , ini tidak akan dihitung sebagai gawang. Jika pemain tidak kembali nanti, hasil akhirnya akan seperti saat pemain meninggalkan lapangan. Ketika seorang pemain memasuki pertandingan sebagai pengganti gegar otak, untuk tujuan penyelesaian baik mereka dan pemain yang digantikan akan dianggap telah memainkan peran penuh dalam pertandingan. Penalti berjalan setelah akhir babak Penalti berjalan ditambahkan ke total tim setelah awal babak tim lain tidak akan dihitung untuk penyelesaian pasar di babak sebelumnya.Pertunjukan PemainDeskripsi: pilih apakah pemain akan mencetak skor lebih atau kurang dari skor tertentu - berdasarkan poin gaya Fantasi.Aturan: Pemain mencetak 1 poin per lari, 20 poin per gawang, 10 poin per tangkapan, dan 25 poin per stumping.</p>

  <p>6.18.49. Metode Pembubaran Gawang Berikutnya Deskripsi: Bagaimana batsman berikutnya akan keluar? Aturan: Hasil akan ditentukan oleh metode pemecatan gawang berikutnya yang jatuh. Abatsman pensiun terluka tidak dihitung sebagai gawang. Jika seorang batsman dipensiunkan, semua taruhan akan dibatalkan. Jika gawang yang ditentukan tidak jatuh, semua taruhan akan dibatalkan.</p>

<p>6.18.50. Player Markets Batsman MatchbetDeskripsi: Manakah dari pemain yang disebutkan yang akan mencetak skor run terbanyak? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua inning karena faktor eksternal , termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Kedua pemain harus disebutkan dalam starting XI, atau tampil sebagai pengganti. Jika salah satunya tidak, maka semua taruhan akan tetap diselesaikan. Skor yang dicetak dalam super over tidak dihitung.</p>

  <p>6.18.51. Bowler MatchbetDeskripsi: Manakah dari nama pemain yang akan mengambil wicket paling banyak? Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua inning karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over telah dilempar, kecuali penyelesaian taruhan telah ditentukan. Kedua pemain harus disebutkan dalam starting XI, atau muncul sebagai pengganti. Jika salah satu tidak, maka semua taruhan tetap diselesaikan.Gawang yang diambil dalam super over tidak dihitung.</p>

<p>6.18.52. All-Rounder MatchbetDeskripsi: Manakah dari nama pemain yang akan mencetak poin terbanyak dalam sistem penilaian performa pemain? Aturan: Poin dihitung sebagai berikut: 1 poin per lari, 20 poin per gawang, 10 poin per tangkapan, 25 poin per stumping. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 200 over yang dilempar, kecuali penyelesaian taruhan telah ditentukan. Kedua pemain harus disebutkan dalam starting XI, atau tampil sebagai pemain pengganti. Jika salah satu pemain tidak melakukan bat atau bowl, maka semua taruhan tetap diselesaikan. Poin yang dicetak dalam super over tidak dihitung.</p>

<p>6.18.53. Keeper MatchbetDeskripsi: Manakah dari nama penjaga gawang yang mencetak poin lebih banyak dalam sistem penilaian kinerja pemain? Aturan: Poin dihitung seperti di atas. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan di kedua babak karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan Kelas Satu yang seri, taruhan akan dibatalkan jika kurang dari 200 over telah dilempar, kecuali penyelesaian taruhan telah ditentukan. Kedua pemain yang disebutkan harus memulai pertandingan sebagai penjaga gawang, atau tampil sebagai pemain pengganti, tetapi jika peran permainan mereka berubah karena alasan apa pun, semua taruhan akan dibatalkan. tetap diselesaikan sesuai dengan sistem penilaian di atas. Poin yang dicetak dalam super over tidak dihitung.</p>

<p>6.18.54. Pasar Pop Up Hit GratisDeskripsi: Berapa banyak run tim yang akan dinilai dari pengiriman hit gratis? Aturan: Hasilnya akan ditentukan oleh jumlah run yang ditambahkan ke total tim, dari pengiriman yang ditentukan. Jika pukulan bebas dilempar ulang karena pengiriman ilegal, skor lari dari pukulan bebas kedua tidak dihitung. Ekstra dan tendangan penalti akan diperhitungkan dalam penyelesaian. Misalnya, jika pukulan melebar pada pengiriman pukulan gratis yang ditentukan, hasilnya adalah 1. Kemudian pasar hit gratis lainnya mungkin akan ditawarkan.</p>

<p>6.18.55. Race to 'X' RunsDescription: Batsman mana yang akan mencapai jumlah run yang ditentukan terlebih dahulu? Aturan: Semua taruhan berlaku, terlepas dari pembatasan apa pun. Jika batsman tidak mencapai jumlah lari yang ditentukan, pasar akan diselesaikan sebagai 'Tidak Keduanya'.</p>
  <p>6.18.56. Di sebelah Hit SixDescription: Pemukul mana yang akan memukul enam berikutnya?Aturan: Semua taruhan berlaku, terlepas dari pembatasan apa pun. Jika tidak ada batsman yang mendapat skor enam setelah taruhan ditawarkan, maka pasar akan diselesaikan sebagai 'Tidak Keduanya'. Penggulingan dan tambahan tidak dihitung.</p>

<p>6.18.57. Di sebelah Ambil GawangDeskripsi: Bowler mana yang akan mengambil gawang berikutnya di babak ini?Aturan: Semua taruhan berlaku, terlepas dari pembatasan apa pun. Jika tidak ada pemain bowling yang disebutkan mengambil gawang, pasar akan diselesaikan sebagai 'Tidak satu pun dari yang di atas'. Untuk tujuan penyelesaian, batsman yang pensiun terluka tidak dihitung sebagai gawang. Run out, time out, pensiun dan metode pemecatan lainnya yang tidak diberikan kepada bowler tertentu akan diselesaikan sebagai 'Tidak satu pun dari yang di atas'.</p>

<p>6.18.58. Winning OverDescription: Di babak mana dari tim yang disebutkan namanya akan menyelesaikan pertandingan? Aturan: Semua taruhan akan dibatalkan jika tidak ada hasil resmi. Dalam pertandingan overs terbatas, semua taruhan akan dibatalkan jika, setelah memasang taruhan, jumlah overs maksimum yang mungkin dikurangi dengan cara apa pun.</p>

<p>6.18.59. Pasaran Satu Sisi Kedua Tim Mencetak Runs 'X'Deskripsi: Apakah kedua tim akan mencetak jumlah run yang ditentukan?Aturan: Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin menyelesaikan setidaknya 80% dari overs yang dijadwalkan telah terlempar di kedua babak pada saat taruhan ditempatkan karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian taruhan telah ditentukan sebelum pengurangan. Dalam pertandingan Kelas Satu yang ditarik, taruhan akan dibatalkan jika kurang dari 100 overs telah dilempar ke salah satu babak pertama tim, kecuali penyelesaian taruhan telah ditentukan. Hanya skor lari di babak pertama yang dihitung Jika tim menyatakan bahwa babak akan dianggap selesai untuk tujuan penyelesaian.</p>

<p>6.18.60. Salah satu Metode Pemberhentian BatsmanDeskripsi: Akankah salah satu dari batsmen yang disebutkan diberhentikan dalam metode yang ditentukan?Aturan: Semua taruhan akan diselesaikan, terlepas dari apakah salah satu batsman tidak keluar, atau cedera, di akhir babak.</p>

  <p>6.18.61. Kedua Batsmen Method of DismissalDescription: Akankah kedua batsmen yang disebutkan diberhentikan dalam metode yang ditentukan? Aturan: Sebagai \u201CMetode Pemberhentian Salah Satunya Batsman\u201D.</p>

<p>6.18.62. Pengiriman Pengiriman Berturut-turutDeskripsi: Berapa banyak putaran yang akan dinilai dari masing-masing pengiriman yang ditentukan?Aturan: Sebagai "Pengiriman Runs off" kecuali jumlah run yang ditentukan harus dinilai dari kedua pengiriman yang disebutkan.</p>

<p>6.18.63. Wicket off DeliveryDeskripsi: Akankah gawang jatuh dalam pengiriman yang ditentukan?Aturan: Pengiriman yang ditentukan harus diselesaikan agar taruhan tetap berlaku.Untuk tujuan penyelesaian, setiap gawang akan dihitung, termasuk run out. Sebuah batsman pensiun terluka tidak dihitung sebagai gawang. Jika batsman time out atau mundur maka gawang dianggap telah terjadi pada bola sebelumnya.</p>

<p>6.18.64. Kedua Batsmen Mencetak Skor 'X' Berlari di OverDescription: Akankah kedua batsmen mencetak jumlah run yang ditentukan di over? Aturan: Over yang ditentukan harus diselesaikan agar taruhan tetap berlaku kecuali penyelesaian telah ditentukan. Jika babak berakhir selama over maka over itu akan dianggap selesai kecuali babak berakhir karena faktor eksternal, termasuk cuaca buruk, dalam hal ini semua taruhan akan dibatalkan, kecuali penyelesaian telah ditentukan. Jika over tidak tidak dimulai dengan alasan apapun, semua taruhan akan dibatalkan. Lari harus dinilai dari kelelawar untuk dihitung menuju penyelesaian. Taruhan akan diselesaikan terlepas dari apakah salah satu batsmen yang ditentukan dipecat atau dihentikan dengan cedera sebelum over dimulai.</p>

<p>6.18.65. Kedua Batsmen Mencetak Batas di OverDescription: Akankah kedua batsmen mencetak batas di over? Aturan: Sebagai "Kedua Batsmen Mencetak 'X' Berlari di Over". Baik merangkak dan berenam dihitung sebagai batas. Hanya skor empat atau enam dari kelelawar (dari pengiriman apa pun \u2013 legal atau tidak) yang akan dihitung. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung.</p>

<p>6.18.66. Empat dan Enam akan Dicetak dalam OverDeskripsi: Apakah skor empat dan enam akan dicetak di over?Aturan: Over yang ditentukan harus diselesaikan agar taruhan tetap berlaku kecuali penyelesaian telah ditentukan. Jika babak berakhir selama over maka over itu akan dianggap selesai kecuali babak berakhir karena faktor eksternal, termasuk cuaca buruk, dalam hal ini semua taruhan akan dibatalkan, kecuali penyelesaian telah ditentukan. Jika over tidak dimulai karena alasan apa pun, semua taruhan akan dibatalkan. Hanya skor empat atau enam dari kelelawar (dari pengiriman apa pun \u2013 sah atau tidak) yang akan dihitung. Menggulingkan, semua lari merangkak dan ekstra tidak dihitung.</p>

<p>6.18.67. Tonggak Kombo Batsman dan BowlerDeskripsi: Akankah batsman bernama, dan bowler bernama, mencapai tonggak yang ditentukan?Aturan: Untuk batsman \u2013 sama dengan \u201CBatsman Runs\u201D. Dalam permainan kelas satu, hanya skor lari pada babak pertama yang akan dihitung. Jika seorang batsman tidak berada di starting XI, atau diganti, taruhan akan dibatalkan. Untuk bowler \u2013 jika seorang bowler tidak melakukan bowling, mereka akan dianggap telah mengambil 0 wicket. Jika seorang bowler tidak ada di starting XI, atau diganti, taruhan akan dibatalkan. Dalam pertandingan overs terbatas, taruhan akan dibatalkan jika tidak mungkin untuk menyelesaikan setidaknya 80% dari overs yang dijadwalkan pada inning yang relevan karena faktor eksternal, termasuk cuaca buruk, kecuali penyelesaian telah ditentukan. Dalam pertandingan First Class yang imbang, taruhan akan dibatalkan jika kurang dari 200 over telah di-bow, kecuali inning bowling pemain selesai. Hasilnya akan dianggap ditentukan jika garis di mana taruhan ditempatkan dilewati. Dalam permainan Kelas Satu, hanya gawang babak pertama yang akan dihitung dan dijalankan. Gol dan skor lari dalam super over tidak dihitung.</p>

<p>6.18.68. Batsmen Combo MilestonesDescription: Akankah kedua batsmen mencapai milestone yang ditentukan? Aturan: Sama seperti \u201CCombined Batsman Run\u201D.</p>

<p>6.18.69. Catatan untuk semua MarketsPemain yang dikeluarkan/dipensiunkan Seorang pemain yang dikeluarkan dari lapangan dianggap mengundurkan diri, jadi akan ditetapkan sebagai wicket.Pergantian gegar otak Ketika seorang pemain meninggalkan lapangan sebagai pengganti gegar otak, ini tidak akan dihitung sebagai wicket. Jika pemain tidak kembali nanti, hasil akhirnya akan seperti saat pemain meninggalkan lapangan. Ketika seorang pemain memasuki pertandingan sebagai pengganti gegar otak, untuk tujuan penyelesaian baik mereka dan pemain yang digantikan akan dianggap telah memainkan peran penuh dalam pertandingan. Penalti berjalan setelah akhir babak Penalti berjalan ditambahkan ke total tim setelah awal babak tim lain tidak akan diperhitungkan dalam penyelesaian pasar di babak sebelumnya.</p>

  <p>6.18.70. Penampilan Pemain</p>

<p>6.19. Squash</p>

<p>6.19.1. Jika set berakhir sebelum poin X tercapai, pasar ini (Siapa yang mencetak poin [X] di set [y]) dianggap batal (dibatalkan)</p>

<p>6.19.2. Jika pasar tetap terbuka dengan skor yang salah yang berdampak signifikan pada harga, kami berhak membatalkan taruhan.</p>

<p>6.19.3. Jika pemain/tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan.</p>

<p>6.19.4. Jika seorang pemain mengundurkan diri, kehilangan pertandingan, atau didiskualifikasi, semua pasar yang belum diputuskan dianggap batal</p>

<p>6.19.5. Pengurangan poin resmi akan diperhitungkan untuk semua pasar yang belum ditentukan. Pasar yang telah ditentukan tidak akan memperhitungkan pemotongan.</p>

<p>6.19.6. Jika poin penalti diberikan oleh wasit, semua taruhan pada permainan itu akan berlaku.</p>

  <p>6.20. Aturan Australia</p>

<p>6.20.1. Semua pasar tidak termasuk lembur kecuali dinyatakan lain</p>

<p>6.20.2. Reguler 80 Menit: Pasaran didasarkan pada hasil di akhir permainan 80 menit yang dijadwalkan kecuali dinyatakan lain. Ini termasuk cedera tambahan atau waktu penghentian tetapi tidak termasuk perpanjangan waktu.</p>

<p>6.20.3. Jika odds ditawarkan dengan waktu pertandingan yang salah (lebih dari 2 menit), kami berhak membatalkan taruhan.</p>

<p>6.20.4. Jika nama atau kategori tim ditampilkan secara tidak benar, kami berhak membatalkan taruhan</p>

<p>6.21. Counter-Strike: Serangan Global</p>

<p>6.21.1. Jika tidak ada bom yang ditanam, pasar ([mapNr!] Map [roundNr!] Round - Bom dijinakkan) akan dianggap batal</p>
6.21.2. Pasar tidak mempertimbangkan lembur kecuali dinyatakan lain.</p>

<p>6.21.3. Pasar akan diselesaikan berdasarkan hasil yang dipublikasikan secara resmi.</p>

<p>6.21.4. Jika jadwal pertandingan tidak dicantumkan dengan benar, kami berhak membatalkan taruhan.</p>

<p>6.21.5. Jika terjadi walkover atau pensiun, semua pasar yang belum diputuskan akan batal.</p>

<p>6.21.6. Jika pertandingan atau peta diputar ulang karena pemutusan, atau masalah teknis yang tidak terkait dengan pemain, semua pasar yang belum diputuskan akan dibatalkan. Pertandingan atau peta yang diputar ulang akan ditangani secara terpisah.</p>

<p>6.21.7. Jika jumlah standar peta berubah atau berbeda dari yang ditawarkan untuk tujuan taruhan, kami berhak membatalkan taruhan.</p>
  <p>6.22. Dota2</p>

<p>6.22.1. Peta X \u2013 Aegis ke-1: Penyelesaian ditentukan oleh tim yang mengambil Aegis of the Immortal, dan bukan siapa yang membunuh Roshan</p>

<p>6.22.2. Peta X \u2013 menara 1 dan peta X \u2013 barak pertama: Untuk tujuan penyelesaian, setiap metode penghancuran menara akan diperhitungkan (Lawan & Creep hancurkan; hancurkan oleh Deny)</p>

<p>6.22.3. Pasar akan diselesaikan berdasarkan hasil yang dipublikasikan secara resmi.</p>

<p>6.22.4. Jika jadwal pertandingan tidak dicantumkan dengan benar, kami berhak membatalkan taruhan.</p>

<p>6.22.5. Jika terjadi walkover atau pensiun, semua pasar yang belum diputuskan akan batal.</p>

<p>6.22.6. Jika pertandingan atau peta diputar ulang karena pemutusan, atau masalah teknis yang tidak terkait dengan pemain, semua pasar yang belum diputuskan akan dibatalkan. Pertandingan atau peta yang diputar ulang akan ditangani secara terpisah.</p>

<p>6.22.7. Jika jumlah standar peta berubah atau berbeda dari yang ditawarkan untuk tujuan taruhan, kami berhak membatalkan taruhan.</p>

<p>6.23. Liga Legenda</p>

<p>6.23.1. Peta ke-X \u2013 Penghalang ke-1 dan Peta ke-X \u2013 Menara ke-1: Untuk tujuan penyelesaian, setiap metode penghancuran akan diperhitungkan</p>

<p>6.23.2. Pasar tidak mempertimbangkan lembur kecuali dinyatakan lain.</p>

<p>6.23.3. Pasar akan diselesaikan berdasarkan hasil yang dipublikasikan secara resmi.</p>

<p>6.23.4. Jika jadwal pertandingan tidak dicantumkan dengan benar, kami berhak membatalkan taruhan.</p>

<p>6.23.5. Jika terjadi walkover atau pensiun, semua pasar yang belum diputuskan akan batal.</p>

<p>6.23.6. Jika pertandingan atau peta diputar ulang karena pemutusan, atau masalah teknis yang tidak terkait dengan pemain, semua pasar yang belum diputuskan akan dibatalkan. Pertandingan atau peta yang diputar ulang akan ditangani secara terpisah.</p>

<p>6.23.7. Jika jumlah standar peta berubah atau berbeda dari yang ditawarkan untuk tujuan taruhan, kami berhak membatalkan taruhan.</p>

<p>6.24. FIFA eSports</p>

<p>6.24.1. Durasi pertandingan eSports Battle - 2x4 menit.</p>

<p>6.24.2. Durasi pertandingan Liga Pro EFootball - 2x6 menit.</p>

<p>6.24.3. Semua Pasaran akan diselesaikan sebagaimana diatur dalam Aturan Umum dan Pasar Sepak Bola.</p>

<p>6.25. eSports NBA2K</p>

<p>6.25.1. Durasi pertandingan \u2013 4x5 menit. Ini termasuk lembur.</p>

<p>6.25.2. Semua Pasaran akan diselesaikan sebagaimana diatur dalam Aturan Pasar Umum dan Bola Basket.</p>

<p>6.26. Formula1</p>

<p>6.26.1. Semua taruhan balapan diselesaikan pada klasifikasi resmi FIA pada saat presentasi podium, dengan diskualifikasi/penalti berikutnya diabaikan.</p>

<p>6.26.2. Semua pembalap yang menyelesaikan 90% dari putaran balapan dianggap sebagai finisher yang diklasifikasikan sesuai dengan klasifikasi resmi FIA. Namun semua pembalap diberi peringkat, dan untuk tujuan taruhan head to head, peringkat ini akan berlaku.</p>
</section>

<section>
  <h2>7. Olahraga Virtual</h2>
  <p>7.1. Sepak Bola Virtual</p>
  <p>7.1. Sepak Bola Virtual</p>

<p>7.1.1. Mode Sepak Bola Virtual memberikan pengalaman bertaruh uang nyata 24/7/365 di sepakbola virtual. Kompetisi dibuat terus menerus dan taruhan dapat dipasang kapan saja, bahkan dalam satu musim.</p>

<p>7.1.2. Struktur permainanSetiap mode memiliki struktur turnamen yang berbeda: Mode Liga Sepak Bola Virtual VFLM:16 Tim Pertandingan kandang & tandang30 hari pertandingan8 pertandingan serentak per hari pertandingan240 pertandingan per musim Tahap Grup Piala Dunia Sepak Bola Virtual VFWC:32 Tim (8 grup terdiri dari 4 tim per grup)12 potongan hari pertandingan (3 hari pertandingan dari 4 potongan per hari pertandingan)4 pertandingan bersamaan per hari pertandingan potongan48 pertandingan per babak grupKnock-Out-Stage16 Tim5 putaran (R16[1.4]; R16[5...8]; R8 ; Semi Final; Final & Juara 3)4 pertandingan serentak (R16[1..4]; R16[5...8]; R8);2 pertandingan serentak (Semi Final; Final & Juara 3)16 pertandingan per ketukan di luar panggung.</p>

<p>\u25CF 16 Tim</p>

<p>\u25CF Pertandingan kandang & tandang</p>

<p>\u25CF 30 hari pertandingan</p>

<p>\u25CF 8 pertandingan serentak per hari pertandingan</p>

<p>\u25CF 240 pertandingan per musim Tahap Grup Virtual Football World Cup VFWC:</p>

<p>\u25CF 32 Tim (8 grup terdiri dari 4 tim per grup)</p>

<p>\u25CF 12 potongan hari pertandingan (3 hari pertandingan dari 4 potongan per hari pertandingan)</p>

<p>\u25CF 4 pertandingan serentak per potongan hari pertandingan</p>

<p>\u25CF 48 pertandingan per babak penyisihan grup</p>

<p>\u25CF Tahap Knock-Out</p>

<p>\u25CF 16 Tim</p>

<p>\u25CF 5 babak (R16[1.4]; R16[5...8]; R8; Semi Final; Final & Juara 3)</p>

<p>\u25CF 4 kecocokan bersamaan (R16[1.4]; R16[5...8]; R8);</p>

<p>\u25CF 2 pertandingan serentak (Semi Final; Final & Juara 3)</p>

<p>\u25CF 16 pertandingan per babak knock-out.</p>

  <p>7.2. Bola Basket Virtual</p>

<p>7.2.1. VBL menyediakan pengalaman bertaruh uang nyata 24/7/365 di bola basket virtual. Liga terdiri dari 16 tim dan musim berjalan terus menerus. Setiap musim terdiri dari 30 hari pertandingan (pertandingan kandang dan tandang). Taruhan dapat dipasang kapan saja \u2013 bahkan dalam satu musim.</p>

<p>7.2.2. Detail Musim.Untuk versi online satu musim berlangsung total 106:30 menit, dipisahkan menjadi periode 'Pra-Liga', 'Lingkaran hari pertandingan', dan periode 'Pasca liga'. Periode 'Pra-Liga' berlangsung sebelum dimulainya musim dan berlangsung selama 60 detik. Semua hari pertandingan diringkas sebagai periode 'Pertandingan hari Loop' dengan total durasi 105:00 menit. Di akhir setiap musim ada periode 'Pasca Musim' selama 30 detik.</p>

<p>7.2.3. Bertaruh pada pertandingan VBL diperbolehkan hingga 10 detik sebelum tip-off. Pasar taruhan untuk hari pertandingan mendatang dari musim saat ini tetap terbuka. Ketika hari pertandingan mendatang dari bilah 'Hari Pertandingan' di bagian bawah dipilih, pertandingan yang terkait dengan hari itu beserta peluangnya akan ditampilkan di bagian peluang yang lebih rendah.</p>

<p>7.3. Kuda virtual.</p>

<p>7.3.1. VHK menyediakan pengalaman bertaruh uang nyata 24/7/365 pada pacuan kuda virtual. Taruhan dapat ditempatkan hingga 10 detik sebelum dimulainya balapan berikutnya yang akan datang serta pada semua balapan mendatang pada hari balapan saat ini kapan saja.</p>

<p>7.3.2. Balapan dihasilkan terus menerus - balapan baru akan dimulai segera setelah balapan saat ini selesai. Taruhan dimungkinkan dalam 10 balapan mendatang berikutnya.: 2 menit siklus acara total 40 detik fase taruhan, 65 detik fase acara, 15 detik hasil fase 2 rumput dan 1 trek tanah dengan lomba 1000m dijadwalkan secara acak8, 10, 12, 14 pelari ditugaskan secara acak< /p>

<p>\u25CF siklus acara total 2 menit</p>

<p>\u25CF Fase taruhan 40 detik,</p>

<p>\u25CF Fase peristiwa 65 detik,</p>

<p>\u25CF Fase hasil 15 detik</p>

<p>\u25CF 2 trek rumput dan 1 trek tanah dengan balapan 1000m yang dijadwalkan secara acak</p>

<p>\u25CF 8, 10, 12, 14 pelari ditetapkan secara acak</p>

  <p>7.3.3. MarketsWin - pilih pelari yang akan finis pertama Tempat - pilih pelari yang akan menyelesaikan salah satu dari 1, dan 2 (6-7 Runners), pilih runner yang akan menyelesaikan 1, 2 dan 3 (7+ pelari) Prakiraan (Urutan Benar) - pilih pelari yang akan menyelesaikan 1 dan 2 dalam urutan yang benar (tepat) Prakiraan (Any Order) - pilih pelari yang akan menyelesaikan 1 dan 2 dalam urutan apa pun (quinella) Tricast (Urutan Benar) - pilih pelari yang akan selesai 1, 2 dan 3 dalam urutan yang benar (trifecta)Tricast (Any Order) - pilih pelari yang akan menyelesaikan 1, 2 dan 3 dalam urutan apapun (trio)</p>

<p>\u25CF Menang - pilih pelari yang akan finis lebih dulu</p>

<p>\u25CF Tempat - pilih pelari yang akan finis sebagai juara 1, dan 2 (6-7 Pelari), pilih pelari yang akan finis 1, 2, dan 3 (7+ pelari)</p>

<p>\u25CF Prakiraan (Urutan Benar) - pilih pelari yang akan finis ke-1 dan ke-2 dengan urutan yang benar (tepat)</p>

<p>\u25CF Forecast (Any Order) - pilih pelari yang akan menyelesaikan 1 dan 2 dalam urutan apapun (quinella)</p>

<p>\u25CF Tricast (Urutan Benar) - pilih pelari yang akan menyelesaikan 1, 2 dan 3 dalam urutan yang benar (trifecta)</p>

<p>\u25CF Tricast (Any Order) - pilih pelari yang akan menyelesaikan 1, 2 dan 3 dalam urutan apapun (trio)</p>

<p>7.4. Anjing Virtual</p>

<p>7.4.1. VDK memberikan pengalaman bertaruh uang nyata 24/7/365 pada balapan anjing virtual. Taruhan dapat dipasang hingga 10 detik sebelum dimulainya balapan berikutnya yang akan datang serta pada balapan tenfuture kapan saja.</p>

<p>7.4.2. Informasi permainan. Balapan dihasilkan terus menerus - yang baru akan dimulai segera setelah yang sekarang selesai. Siklus peristiwa total 2 menit37 detik atau fase taruhan 67 detik, fase peristiwa 38 detik atau 68 detik, fase hasil 15 detik, lintasan malam dan siang dengan jarak 360m dan 720m dijadwalkan secara acak6 atau 8 pelari ditetapkan secara acak</p>

<p>\u25CF siklus acara total 2 menit</p>

<p>\u25CF Fase taruhan 37 detik atau 67 detik,</p>

<p>\u25CF Fase peristiwa 38 detik atau 68 detik,</p>

<p>\u25CF Fase hasil 15 detik</p>

<p>\u25CF trek siang dan malam dengan jarak 360m dan 720m dijadwalkan secara acak</p>

<p>\u25CF 6 atau 8 pelari ditetapkan secara acak</p>

<p>7.4.3. MarketsWin - pilih pelari yang akan finis pertama Tempat - pilih pelari yang akan menyelesaikan salah satu dari 1, dan 2 (6-7 Runners), pilih runner yang akan menyelesaikan 1, 2 dan 3 (7+ pelari) Prakiraan (Urutan Benar) - pilih pelari yang akan menyelesaikan 1 dan 2 dalam urutan yang benar (tepat) Prakiraan (Any Order) - pilih pelari yang akan menyelesaikan 1 dan 2 dalam urutan apa pun (quinella) Tricast (Urutan Benar) - pilih pelari yang akan selesai 1, 2 dan 3 dalam urutan yang benar (trifecta)Tricast (Any Order) - pilih pelari yang akan menyelesaikan 1, 2 dan 3 dalam urutan apapun (trio)</p>

<p>\u25CF Menang - pilih pelari yang akan finis lebih dulu</p>

<p>\u25CF Tempat - pilih pelari yang akan finis sebagai juara 1, dan 2 (6-7 Pelari), pilih pelari yang akan finis 1, 2, dan 3 (7+ pelari)</p>

<p>\u25CF Prakiraan (Urutan Benar) - pilih pelari yang akan finis ke-1 dan ke-2 dengan urutan yang benar (tepat)</p>

<p>\u25CF Forecast (Any Order) - pilih pelari yang akan menyelesaikan 1 dan 2 dalam urutan apapun (quinella)</p>

<p>\u25CF Tricast (Urutan Benar) - pilih pelari yang akan menyelesaikan 1, 2 dan 3 dalam urutan yang benar (trifecta)</p>

<p>\u25CF Tricast (Any Order) - pilih pelari yang akan menyelesaikan 1, 2 dan 3 dalam urutan apapun (trio)</p>
</section>

<section>
  <h2>8. Bonus</h2>
  <p>8.1. Comboboost</p>
  <p>
    <table class="ui-table is-stripe">
      <thead>
        <tr>
          <th>Pengganda</th>
          <th>Pilihan</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>2</td>
          <td>1.01</td>
        </tr>
        <tr>
          <td>3</td>
          <td>1.02</td>
        </tr>
        <tr>
          <td>4</td>
          <td>1.04</td>
        </tr>
        <tr>
          <td>5</td>
          <td>1.05</td>
        </tr>
        <tr>
          <td>6</td>
          <td>1.07</td>
        </tr>
        <tr>
          <td>7</td>
          <td>1.1</td>
        </tr>
        <tr>
          <td>8</td>
          <td>1.15</td>
        </tr>
        <tr>
          <td>9</td>
          <td>1.17</td>
        </tr>
        <tr>
          <td>10</td>
          <td>1.2</td>
        </tr>
        <tr>
          <td>11</td>
          <td>1.25</td>
        </tr>
        <tr>
          <td>12</td>
          <td>1.3</td>
        </tr>
        <tr>
          <td>13</td>
          <td>1.35</td>
        </tr>
        <tr>
          <td>14</td>
          <td>1.4</td>
        </tr>
        <tr>
          <td>15</td>
          <td>1.45</td>
        </tr>
        <tr>
          <td>16</td>
          <td>1.5</td>
        </tr>
        <tr>
          <td>17</td>
          <td>1.65</td>
        </tr>
        <tr>
          <td>18</td>
          <td>1.75</td>
        </tr>
        <tr>
          <td>19</td>
          <td>1.85</td>
        </tr>
        <tr>
          <td>20</td>
          <td>2</td>
        </tr>
      </tbody>
    </table>
  </p>
  <p>8.1.2 Perhitungan jumlah bonus akhir didasarkan pada odds akhir Combo setelah semua hasil diselesaikan.</p>

<p>8.1.3 Taruhan yang diuangkan tidak memenuhi syarat untuk mendapatkan peningkatan Kombo.</p>

<p>8.1.4 Operator berhak mengubah, membatalkan, mengklaim kembali, atau menolak promosi apa pun atas kebijakannya sendiri.</p>

<p>8.1.5 Peningkatan kombo hanya tersedia pada pilihan dengan odds 1,50 atau lebih.</p>

<p>8.2 Pengembalian dana taruhan, uang gratis, tanpa taruhan berisiko.</p>

<p>8.2.1 Pengembalian dana taruhan - pemain hanya mendapatkan bagian kemenangan dari taruhan. Misalnya, freebet5 pada pemain ganjil 3,5 mendapatkan akun 5*3,5 - 5 = 12,5</p>

<p>8.2.2 Uang Gratis - pemain mendapat taruhan dan memenangkan bagian di akun. Sebagai contoh, freebet 5 pada odd 3.5 yang didapat pemain pada akun 5*3.5 = 17.50</p>

<p>8.2.3 Tidak ada taruhan risiko - taruhan biasa, tetapi jika pemain kalah, dia mendapatkan kembali uangnya di akun</p>
  <p><table class="ui-table is-stripe">
    <thead>
      <tr>
        <th>Jenis Freebet</th>
        <th>Pengembalian Dana atau Dibatalkan</th>
        <th>Setengah Hilang</th>
        <th>Setengah Menang</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Pengembalian uang taruhan</td>
        <td>dihitung sebagai taruhan yang kalah</td>
        <td>dihitung sebagai taruhan yang kalah</td>
        <td>
          sebagai taruhan biasa, tetapi tanpa taruhan
          <div>(2.5*3.5+2.5*1)-5=6.25</div>
        </td>
      </tr>
      <tr>
        <td>Uang Gratis</td>
        <td>pemain mendapat jumlah taruhan di akunnya</td>
        <td>sebagai taruhan biasa</td>
        <td>sebagai taruhan biasa</td>
      </tr>
      <tr>
        <td>Tanpa Taruhan Risiko</td>
        <td>sebagai taruhan biasa</td>
        <td>pemain mendapat jumlah taruhan di akunnya</td>
        <td>sebagai taruhan biasa</td>
      </tr>
    </tbody>
  </table></p>
</section>

<section>
  <h2>9. Aturan Permainan Taruhan</h2>
  <p>9.1. Aturan Umum.</p>

<p>9.1.1. Platform Sportsbook berhak untuk membatalkan taruhan apa pun yang dibuat pada odds yang jelas-jelas \u201Cburuk\u201D, odds yang dialihkan, atau taruhan yang dibuat setelah pertandingan dimulai atau pertandingan dipengaruhi oleh masalah teknis yang jelas.</p>

<p>9.1.2. Semua taruhan akan diselesaikan, ketika hasil pasar ditentukan.</p>

<p>9.2. FIFA</p>

<p>9.2.1. Durasi pertandingan \u2013 2x6 menit. Ini termasuk waktu tambahan tetapi tidak termasuk waktu tambahan atau adu penalti.</p>

<p>9.2.2. Semua Pasar akan diselesaikan sebagaimana diatur dalam Aturan Pasar Umum.</p>

<p>9.3. NBA 2K</p>

<p>9.3.1. Durasi pertandingan \u2013 4x6 menit. Ini termasuk lembur.</p>

<p>9.3.2. Semua Pasaran akan diselesaikan sebagaimana diatur dalam Aturan Pasar Umum dan Bola Basket.</p>

<p>9.4. eTenis</p>

<p>9.4.1. Pemenang pertandingan adalah pemain pertama yang memenangkan 2 set.</p>

<p>9.4.2. Pemain harus memenangkan 3 game untuk memenangkan satu set. Jika skor imbang 2-2, maka pemain bisa menang 4-2, atau jika pemain masih seri 3-3 maka set ditentukan dengan tie-break.</p>

<p>9.4.3. Pemenang tie-break adalah pemain pertama yang memenangkan 5 poin dengan selisih minimal 2 poin. Jika skor seri 5-5, pemain bisa menang 7-5, 8-6, 9-7, dll.</p>

<p>9.5. Liga Roket</p>

<p>9.5.1. Durasi pertandingan \u2013 5 menit. Ini tidak termasuk lembur.</p>

<p>9.5.2. Semua Pasar akan diselesaikan sebagaimana diatur dalam Aturan Pasar Umum.</p>

<p>9.6. eFighting</p>

<p>9.6.1. Pemenang pertandingan adalah karakter yang memenangkan pertarungan.</p>

<p>9.6.2. Penjelasan istilah pasar eFighting.Health Bar - Setiap karakter memiliki 2 Health Bar. Bar kedua aktif hanya setelah yang pertama benar-benar habis. Kerusakan pertama \u2013 serangan pertama yang berhasil. Bentrokan \u2013 Situasi dalam pertarungan, ketika kedua karakter saling menantang dalam acara-acara khusus. untuk meningkatkan poin hit. Kedua petarung bisa memenangkan bentrokan, tetapi ada juga yang seri. Supermove \u2013 Gerakan khusus untuk setiap karakter, yang sangat jarang terjadi.</p>

<p>9.6.3. Semua pasar akan diselesaikan sesuai dengan definisi di atas.</p>

<p>9.7. eKriket</p>

<p>9.7.1. Pertandingan terdiri dari dua babak - satu untuk setiap tim.</p>

<p>9.7.2. Setiap inning terdiri dari lima over dengan 6 pengiriman masing-masing.</p>

<p>9.7.3. Semua Pasar akan diselesaikan sebagaimana diatur dalam Aturan Pasar Kriket.</p>`;

function r() {
    return e(a, {
        br: t,
        en: n,
        id: o
    })
}
export {
    r as
    default
};
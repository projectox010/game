var Qe = Object.defineProperty;
var ie = Object.getOwnPropertySymbols;
var qe = Object.prototype.hasOwnProperty,
    Ke = Object.prototype.propertyIsEnumerable;
var q = (t, n, e) => n in t ? Qe(t, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : t[n] = e,
    F = (t, n) => {
        for (var e in n || (n = {})) qe.call(n, e) && q(t, e, n[e]);
        if (ie)
            for (var e of ie(n)) Ke.call(n, e) && q(t, e, n[e]);
        return t
    };
var b = (t, n, e) => (q(t, typeof n != "symbol" ? n + "" : n, e), e);
import {
    ev as Z,
    et as Ye,
    ew as Be,
    ex as ze,
    ey as Ze,
    ez as Xe,
    e8 as Se,
    eA as et,
    eB as Ie,
    eC as tt,
    eD as st,
    eE as nt,
    eF as ae,
    eG as oe,
    aJ as Me,
    eH as X,
    eI as D,
    eJ as xe,
    aI as it,
    eK as at,
    eL as ot,
    eM as rt,
    dp as O,
    a as i,
    dx as Ge,
    j as d,
    dy as lt,
    dz as ct,
    y,
    du as B,
    dA as ut,
    o as T,
    r as j,
    l as w,
    M as ee,
    u as _,
    T as dt,
    h as re,
    k as ht,
    C as je,
    eN as Pe,
    a$ as mt,
    s as S,
    F as Oe,
    dj as ft,
    dk as gt,
    dl as pt,
    bh as Re,
    b as P,
    p as bt,
    bg as vt,
    A as R,
    b0 as _e,
    G as H,
    a5 as J,
    dG as yt,
    ed as wt,
    dY as At,
    dC as Nt,
    dD as kt,
    dZ as Tt,
    dE as Ct,
    bN as V,
    d_ as Bt,
    ba as St,
    bb as A,
    bc as It,
    d as le,
    aH as ce,
    J as Mt,
    a2 as xt,
    bo as Gt,
    D as jt,
    x as Pt,
    S as Ot,
    am as K,
    ax as Rt,
    cJ as _t,
    t as Vt,
    q as ue,
    df as Wt,
    n as Lt
} from "./index.28e31dff.js";
import {
    s as U
} from "./index.dd8128e8.js";
import {
    G as M
} from "./index.06a59a68.js";
import {
    b as Ve
} from "./_baseAssignValue.0532e777.js";
import {
    c as Ft
} from "./_copyArray.2183cf44.js";
import {
    i as de
} from "./isNumber.3847f240.js";
import {
    u as Et
} from "./useLocalStore.f739c306.js";
var he = Object.create,
    $t = function() {
        function t() {}
        return function(n) {
            if (!Z(n)) return {};
            if (he) return he(n);
            t.prototype = n;
            var e = new t;
            return t.prototype = void 0, e
        }
    }(),
    Dt = $t;

function Ht(t, n) {
    for (var e = -1, s = t == null ? 0 : t.length; ++e < s && n(t[e], e, t) !== !1;);
    return t
}
var Ut = Object.prototype,
    Jt = Ut.hasOwnProperty;

function We(t, n, e) {
    var s = t[n];
    (!(Jt.call(t, n) && Ye(s, e)) || e === void 0 && !(n in t)) && Ve(t, n, e)
}

function Q(t, n, e, s) {
    var a = !e;
    e || (e = {});
    for (var o = -1, r = n.length; ++o < r;) {
        var l = n[o],
            h = s ? s(e[l], t[l], l, e, t) : void 0;
        h === void 0 && (h = t[l]), a ? Ve(e, l, h) : We(e, l, h)
    }
    return e
}

function Qt(t) {
    var n = [];
    if (t != null)
        for (var e in Object(t)) n.push(e);
    return n
}
var qt = Object.prototype,
    Kt = qt.hasOwnProperty;

function Yt(t) {
    if (!Z(t)) return Qt(t);
    var n = Be(t),
        e = [];
    for (var s in t) s == "constructor" && (n || !Kt.call(t, s)) || e.push(s);
    return e
}

function te(t) {
    return ze(t) ? Ze(t, !0) : Yt(t)
}
var zt = Xe(Object.getPrototypeOf, Object),
    Le = zt;

function Zt(t, n) {
    return t && Q(n, Se(n), t)
}

function Xt(t, n) {
    return t && Q(n, te(n), t)
}
var Fe = typeof exports == "object" && exports && !exports.nodeType && exports,
    me = Fe && typeof module == "object" && module && !module.nodeType && module,
    es = me && me.exports === Fe,
    fe = es ? et.Buffer : void 0,
    ge = fe ? fe.allocUnsafe : void 0;

function ts(t, n) {
    if (n) return t.slice();
    var e = t.length,
        s = ge ? ge(e) : new t.constructor(e);
    return t.copy(s), s
}

function ss(t, n) {
    return Q(t, Ie(t), n)
}
var ns = Object.getOwnPropertySymbols,
    is = ns ? function(t) {
        for (var n = []; t;) st(n, Ie(t)), t = Le(t);
        return n
    } : tt,
    Ee = is;

function as(t, n) {
    return Q(t, Ee(t), n)
}

function os(t) {
    return nt(t, te, Ee)
}
var rs = Object.prototype,
    ls = rs.hasOwnProperty;

function cs(t) {
    var n = t.length,
        e = new t.constructor(n);
    return n && typeof t[0] == "string" && ls.call(t, "index") && (e.index = t.index, e.input = t.input), e
}

function se(t) {
    var n = new t.constructor(t.byteLength);
    return new ae(n).set(new ae(t)), n
}

function us(t, n) {
    var e = n ? se(t.buffer) : t.buffer;
    return new t.constructor(e, t.byteOffset, t.byteLength)
}
var ds = /\w*$/;

function hs(t) {
    var n = new t.constructor(t.source, ds.exec(t));
    return n.lastIndex = t.lastIndex, n
}
var pe = oe ? oe.prototype : void 0,
    be = pe ? pe.valueOf : void 0;

function ms(t) {
    return be ? Object(be.call(t)) : {}
}

function fs(t, n) {
    var e = n ? se(t.buffer) : t.buffer;
    return new t.constructor(e, t.byteOffset, t.length)
}
var gs = "[object Boolean]",
    ps = "[object Date]",
    bs = "[object Map]",
    vs = "[object Number]",
    ys = "[object RegExp]",
    ws = "[object Set]",
    As = "[object String]",
    Ns = "[object Symbol]",
    ks = "[object ArrayBuffer]",
    Ts = "[object DataView]",
    Cs = "[object Float32Array]",
    Bs = "[object Float64Array]",
    Ss = "[object Int8Array]",
    Is = "[object Int16Array]",
    Ms = "[object Int32Array]",
    xs = "[object Uint8Array]",
    Gs = "[object Uint8ClampedArray]",
    js = "[object Uint16Array]",
    Ps = "[object Uint32Array]";

function Os(t, n, e) {
    var s = t.constructor;
    switch (n) {
        case ks:
            return se(t);
        case gs:
        case ps:
            return new s(+t);
        case Ts:
            return us(t, e);
        case Cs:
        case Bs:
        case Ss:
        case Is:
        case Ms:
        case xs:
        case Gs:
        case js:
        case Ps:
            return fs(t, e);
        case bs:
            return new s;
        case vs:
        case As:
            return new s(t);
        case ys:
            return hs(t);
        case ws:
            return new s;
        case Ns:
            return ms(t)
    }
}

function Rs(t) {
    return typeof t.constructor == "function" && !Be(t) ? Dt(Le(t)) : {}
}
var _s = "[object Map]";

function Vs(t) {
    return Me(t) && X(t) == _s
}
var ve = D && D.isMap,
    Ws = ve ? xe(ve) : Vs,
    Ls = Ws,
    Fs = "[object Set]";

function Es(t) {
    return Me(t) && X(t) == Fs
}
var ye = D && D.isSet,
    $s = ye ? xe(ye) : Es,
    Ds = $s,
    Hs = 1,
    Us = 2,
    Js = 4,
    $e = "[object Arguments]",
    Qs = "[object Array]",
    qs = "[object Boolean]",
    Ks = "[object Date]",
    Ys = "[object Error]",
    De = "[object Function]",
    zs = "[object GeneratorFunction]",
    Zs = "[object Map]",
    Xs = "[object Number]",
    He = "[object Object]",
    en = "[object RegExp]",
    tn = "[object Set]",
    sn = "[object String]",
    nn = "[object Symbol]",
    an = "[object WeakMap]",
    on = "[object ArrayBuffer]",
    rn = "[object DataView]",
    ln = "[object Float32Array]",
    cn = "[object Float64Array]",
    un = "[object Int8Array]",
    dn = "[object Int16Array]",
    hn = "[object Int32Array]",
    mn = "[object Uint8Array]",
    fn = "[object Uint8ClampedArray]",
    gn = "[object Uint16Array]",
    pn = "[object Uint32Array]",
    f = {};
f[$e] = f[Qs] = f[on] = f[rn] = f[qs] = f[Ks] = f[ln] = f[cn] = f[un] = f[dn] = f[hn] = f[Zs] = f[Xs] = f[He] = f[en] = f[tn] = f[sn] = f[nn] = f[mn] = f[fn] = f[gn] = f[pn] = !0;
f[Ys] = f[De] = f[an] = !1;

function $(t, n, e, s, a, o) {
    var r, l = n & Hs,
        h = n & Us,
        m = n & Js;
    if (e && (r = a ? e(t, s, a, o) : e(t)), r !== void 0) return r;
    if (!Z(t)) return t;
    var c = it(t);
    if (c) {
        if (r = cs(t), !l) return Ft(t, r)
    } else {
        var u = X(t),
            g = u == De || u == zs;
        if (at(t)) return ts(t, l);
        if (u == He || u == $e || g && !a) {
            if (r = h || g ? {} : Rs(t), !l) return h ? as(t, Xt(r, t)) : ss(t, Zt(r, t))
        } else {
            if (!f[u]) return a ? t : {};
            r = Os(t, u, l)
        }
    }
    o || (o = new ot);
    var p = o.get(t);
    if (p) return p;
    o.set(t, r), Ds(t) ? t.forEach(function(k) {
        r.add($(k, n, e, k, t, o))
    }) : Ls(t) && t.forEach(function(k, I) {
        r.set(I, $(k, n, e, I, t, o))
    });
    var G = m ? h ? os : rt : h ? te : Se,
        L = c ? void 0 : G(t);
    return Ht(L || t, function(k, I) {
        L && (I = k, k = t[I]), We(r, I, $(k, n, e, I, t, o))
    }), r
}
var bn = 1,
    vn = 4;

function Y(t) {
    return $(t, bn | vn)
}
const C = O.Reader,
    W = O.Writer,
    z = O.util,
    v = O.roots.gameTower || (O.roots.gameTower = {});
v.BetValue = (() => {
    function t(n) {
        if (n)
            for (let e = Object.keys(n), s = 0; s < e.length; ++s) n[e[s]] != null && (this[e[s]] = n[e[s]])
    }
    return t.prototype.mode = 0, t.encode = function(e, s) {
        return s || (s = W.create()), e.mode != null && Object.hasOwnProperty.call(e, "mode") && s.uint32(8).sint32(e.mode), s
    }, t.decode = function(e, s) {
        e instanceof C || (e = C.create(e));
        let a = s === void 0 ? e.len : e.pos + s,
            o = new v.BetValue;
        for (; e.pos < a;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    o.mode = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return o
    }, t
})();
v.GameValue = (() => {
    function t(n) {
        if (this.fields = [], this.cards = [], n)
            for (let e = Object.keys(n), s = 0; s < e.length; ++s) n[e[s]] != null && (this[e[s]] = n[e[s]])
    }
    return t.prototype.odds = 0, t.prototype.fields = z.emptyArray, t.prototype.cards = z.emptyArray, t.encode = function(e, s) {
        if (s || (s = W.create()), e.odds != null && Object.hasOwnProperty.call(e, "odds") && s.uint32(9).double(e.odds), e.fields != null && e.fields.length) {
            s.uint32(18).fork();
            for (let a = 0; a < e.fields.length; ++a) s.sint32(e.fields[a]);
            s.ldelim()
        }
        if (e.cards != null && e.cards.length)
            for (let a = 0; a < e.cards.length; ++a) v.CardValues.encode(e.cards[a], s.uint32(26).fork()).ldelim();
        return s
    }, t.decode = function(e, s) {
        e instanceof C || (e = C.create(e));
        let a = s === void 0 ? e.len : e.pos + s,
            o = new v.GameValue;
        for (; e.pos < a;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    o.odds = e.double();
                    break;
                case 2:
                    if (o.fields && o.fields.length || (o.fields = []), (r & 7) === 2) {
                        let l = e.uint32() + e.pos;
                        for (; e.pos < l;) o.fields.push(e.sint32())
                    } else o.fields.push(e.sint32());
                    break;
                case 3:
                    o.cards && o.cards.length || (o.cards = []), o.cards.push(v.CardValues.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return o
    }, t
})();
v.CardValues = (() => {
    function t(n) {
        if (this.value = [], n)
            for (let e = Object.keys(n), s = 0; s < e.length; ++s) n[e[s]] != null && (this[e[s]] = n[e[s]])
    }
    return t.prototype.value = z.emptyArray, t.encode = function(e, s) {
        if (s || (s = W.create()), e.value != null && e.value.length) {
            s.uint32(10).fork();
            for (let a = 0; a < e.value.length; ++a) s.sint32(e.value[a]);
            s.ldelim()
        }
        return s
    }, t.decode = function(e, s) {
        e instanceof C || (e = C.create(e));
        let a = s === void 0 ? e.len : e.pos + s,
            o = new v.CardValues;
        for (; e.pos < a;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    if (o.value && o.value.length || (o.value = []), (r & 7) === 2) {
                        let l = e.uint32() + e.pos;
                        for (; e.pos < l;) o.value.push(e.sint32())
                    } else o.value.push(e.sint32());
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return o
    }, t
})();
v.Next = (() => {
    function t(n) {
        if (n)
            for (let e = Object.keys(n), s = 0; s < e.length; ++s) n[e[s]] != null && (this[e[s]] = n[e[s]])
    }
    return t.prototype.fields = 0, t.encode = function(e, s) {
        return s || (s = W.create()), e.fields != null && Object.hasOwnProperty.call(e, "fields") && s.uint32(8).sint32(e.fields), s
    }, t.decode = function(e, s) {
        e instanceof C || (e = C.create(e));
        let a = s === void 0 ? e.len : e.pos + s,
            o = new v.Next;
        for (; e.pos < a;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    o.fields = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return o
    }, t
})();
v.CashoutValue = (() => {
    function t(n) {
        if (n)
            for (let e = Object.keys(n), s = 0; s < e.length; ++s) n[e[s]] != null && (this[e[s]] = n[e[s]])
    }
    return t.prototype.frontgroundId = 0, t.encode = function(e, s) {
        return s || (s = W.create()), e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && s.uint32(120).sint32(e.frontgroundId), s
    }, t.decode = function(e, s) {
        e instanceof C || (e = C.create(e));
        let a = s === void 0 ? e.len : e.pos + s,
            o = new v.CashoutValue;
        for (; e.pos < a;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 15:
                    o.frontgroundId = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return o
    }, t
})();
const yn = function({
        game: n
    }) {
        return i(Ge, {
            children: d("div", {
                className: "item",
                children: [i("h2", {
                    children: "What Is Tower?"
                }), i("div", {
                    className: "content",
                    children: n.gameInfo.detail.split(`
`).map((e, s) => i("p", {
                        children: `${e}`
                    }, s.toString()))
                })]
            })
        })
    },
    wn = function({
        game: n
    }) {
        return i(lt, {
            game: n,
            children: d("div", {
                className: "item",
                children: [i("h2", {
                    children: "What is the bankroll?"
                }), d("div", {
                    className: "help-content",
                    children: [i("p", {
                        children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                    }), i("p", {
                        children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                    }), i("p", {
                        children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                    }), i("p", {
                        onClick: () => ct(n, 1),
                        className: "cl-primary pointer",
                        children: "Read more about bankrollers."
                    })]
                }), i("h2", {
                    children: "How does the pool of funds operate? "
                }), d("div", {
                    className: "help-content",
                    children: [i("p", {
                        children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                    }), d("p", {
                        children: [i("b", {
                            className: "cl-primary",
                            children: "The house edge is 1%."
                        }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                    }), i("p", {
                        children: "Payouts made to the winning players will be deducted from the bankroll."
                    })]
                }), i("h2", {
                    children: "How does leverage investment work?"
                }), d("div", {
                    className: "help-content",
                    children: [i("p", {
                        children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                    }), i("p", {
                        children: "Hint: You can also use this feature as an Off-Site investment."
                    }), i("p", {
                        children: "Let's make an example:"
                    }), i("p", {
                        children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                    })]
                }), i("h2", {
                    children: "What is the bankroller dilution fee?"
                }), d("div", {
                    className: "help-content",
                    children: [i("p", {
                        children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                    }), i("p", {
                        children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                    }), i("p", {
                        children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                    }), i("p", {
                        children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                    })]
                })]
            })
        })
    };
var An = wn;
const we = {
        resultOdds: new y(-1),
        resultAmount: 0,
        resultCurrency: "",
        totalWin: !1,
        bigLose: !1
    },
    x = [{
        label: "Easy",
        value: 0,
        totalChose: 4,
        errorChose: 1,
        level: 9
    }, {
        label: "Medium",
        value: 1,
        totalChose: 3,
        errorChose: 1,
        level: 9
    }, {
        label: "Hard",
        value: 2,
        totalChose: 2,
        errorChose: 1,
        level: 9
    }, {
        label: "Extreme",
        value: 3,
        totalChose: 3,
        errorChose: 2,
        level: 6
    }, {
        label: "Nightmare",
        value: 4,
        totalChose: 4,
        errorChose: 3,
        level: 6
    }];

function Ue(t, n, e) {
    let s = new y(t),
        a = n;
    for (; a > 0;) s = s.div(e), a === 1 && (s = s.mul(.99)), a--;
    return s
}

function Nn(t) {
    let n = !1,
        e = "status-common";
    return t.resultOdds.lt(0) ? e = "status-common" : t.resultOdds.lte(1) ? t.bigLose ? e = "status-biglose" : e = "status-lose" : (n = !0, t.totalWin ? e = "status-totalwin" : e = "status-win"), {
        statusName: e,
        isGameWin: n
    }
}
var kn = "/assets/big_bg.29d8487c.png",
    Tn = "/assets/bg.971bf6c8.png",
    Cn = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKkAAABJAgMAAAA7/+4+AAAACVBMVEXNzc0AAADW1ta3VP2IAAAAA3RSTlMJAATyyjtIAAACeUlEQVRIx5VWMW7tIBDkWUpBeh+B4uUUHOEVH2S5ooz+KVx+/Z4inRtLiU+Zx7IwBhyjTBPiDONhdxlHGGMeIkCaRSR408AKEbh/RMDNuMyVDZWEaAuB95wLv4enI+2JK3EunOVenivHK/ej8JIVJjY8gTsU1JUfwjBvb12seBsMOwHcW6pQMBxeALxG5hyFKsMDTETsTyRRnILt4HQNYFizHQjXgOEHV60nLFE13xMe0BhFb7gAjYRjEz3hlzyXwl84XliN5TBJLZRmNWZgOhrIVFeYGLGsqMyVZALLv6d11Wkac7H8GfnNgKtgU+brBXyYyAXBHW/PvGKQvWHukgkT9pGPTyrMHtbMddmEWSDcwPonNwVJIdxSl6BrkgkIbydUqm++axAeauocTFpKJv47hGVDFVR/jO5hFFQdZZJoGF1+Xlum0o3kT2F0j7nxhSCJDnVSh0m7IEnwq2J3mJokBBdzLozDnqK5T/YO9xVFnzd3xUWf+L6dNBeZhzi6a16WZcW4Q/bL6FhZVzfXxvcjjDZ26o1FPqP+eDYNm2Guij9xPFvF83/Ps86GChdzFe48K4E1IsUkioBWp3cFlszCsLwvYth9QRXU4Ty6IAM4AdVAIfFaMiwRayDrSBmg6EuMurGIUipn2xe2KqMwpDN7Tn1BknsWBnZC9cWCcAd0J6fYMNcl+yisqIgdKAhPl0R8ANh4B+YXwuogrLsmIGz7JiD86JmAcPd4tyR8v3aBG2l58d4zEeD4mGvvPxMW3mheuyZwPNstMc8mrleNNkI2JvdOR9fU98g3xMCr6Xn2cMHkf1enw4ePl6WPN10LW5zU2P3A9EZ/AxsqxLQAUOguAAAAAElFTkSuQmCC",
    Bn = "/assets/cbg_item.93024a7e.png",
    Sn = "/assets/cby_item.abb9c140.png",
    In = "/assets/cbr_item.6e3b9d58.png",
    Mn = "/assets/fruit.980edde5.png",
    xn = "/assets/fruit_gray.00db0b1b.png",
    Gn = "/assets/fruit_gray_w.73068a29.png",
    jn = "/assets/fruit_green.a84d4f16.png",
    Pn = "/assets/fruit_yellow.da5666cb.png",
    On = "/assets/select_wrap.fd4717b2.png",
    Rn = "/assets/m_warp.2ce9c8e8.png",
    _n = "/assets/skull.29f82c7d.png",
    Vn = "/assets/box.8a710030.png",
    Wn = "/assets/fire_b.d5612fb1.png",
    Ln = "/assets/fire.406b28b8.png",
    Fn = "/assets/artboard.f0c9501f.png";
const N = {
    big_bg: kn,
    bg: Tn,
    cb_item: Cn,
    cbg_item: Bn,
    cby_item: Sn,
    cbr_item: In,
    fruit: Mn,
    fruit_gray: xn,
    fruit_gray_w: Gn,
    fruit_green: jn,
    fruit_yellow: Pn,
    select_wrap: On,
    m_warp: Rn,
    skull: _n,
    box: Vn,
    fire: Ln,
    fire_b: Wn,
    artboard: Fn
};

function En(t, n, e, s) {
    let a = !0;
    const o = n === t - 1;
    return e === 0 ? n >= t && (a = !1) : a = !1, {
        isSelectCurrent: o,
        isShowAmount: a
    }
}

function $n(t, n) {
    const e = B(),
        s = ut(),
        a = e.rounds.length + 1;
    let r = t % 3 === 0 ? "common-third" : "common",
        l = s ? N.fruit_gray : N.fruit_gray_w,
        h = !1;
    const c = e.isBetting && a === t && !e.guessing && !e.autoBet.isRunning;
    if (e.cards.length === 0) a === t && e.isBetting ? (l = N.fruit_green, r = "green") : a > t && e.rounds[t - 1] === n && (l = N.fruit_yellow, r = "yellow");
    else if (e.cards && e.cards.length > 0) {
        const u = e.cards[t - 1].value;
        (u ? u.includes(n) : !1) ? (l = N.fruit, r = "no-color", e.rounds.length >= t && e.rounds[t - 1] === n && (l = N.fruit_yellow, r = "yellow")) : e.odds.eq(0) && e.rounds.length === t && e.rounds[t - 1] === n && (l = N.skull, r = "red", h = !0)
    }
    return {
        fruitImg: l,
        climgItemType: r,
        canSelect: c,
        isSkull: h,
        mode: e.mode,
        handleNext: u => e.handleNext(u)
    }
}
const Dn = T(function({
        round: n,
        field: e
    }) {
        const [s, a] = j.exports.useState(!1), {
            isSkull: o,
            mode: r,
            handleNext: l,
            climgItemType: h,
            fruitImg: m,
            canSelect: c
        } = $n(n, e);
        return j.exports.useEffect(() => {
            c && a(!1)
        }, [c]), i("div", {
            className: w(Hn, "climb-item", h, c && "bet-select"),
            onClick: () => c && l(e),
            children: i("div", {
                className: "img-wrap",
                children: i("div", {
                    className: w("img-bg", "bg-" + r.value, o && "skull", h, s && "end"),
                    onAnimationEnd: () => a(!0),
                    style: {
                        backgroundImage: `url(${m})`
                    }
                })
            })
        })
    }),
    Hn = "c1ov09g2";
const Un = T(function({
        round: n
    }) {
        const e = B(),
            {
                cards: s,
                rounds: a,
                isBetting: o,
                amount: r,
                currencyName: l,
                isJoinGame: h,
                autoModeWaitTime: m
            } = e,
            {
                totalChose: c,
                errorChose: u
            } = e.mode,
            {
                isSelectCurrent: g,
                isShowAmount: p
            } = En(n, a.length, s.length),
            G = new y(c).sub(u).div(c),
            L = Ue(r, n, G),
            k = o && !m && g;
        return d("div", {
            className: w(Jn, k && "bet-current"),
            style: {
                zIndex: 10 - n
            },
            children: [p && i("div", {
                className: "top-amount",
                children: i("div", {
                    className: "in-wrap monospace",
                    children: i(ee, {
                        amount: L,
                        name: l,
                        icon: !0
                    })
                })
            }), i("div", {
                className: "bg-wrap",
                children: Array(c).fill(1).map((I, ne) => i(Dn, {
                    round: n,
                    field: ne + 1
                }, "item-" + ne))
            }), k && i("div", {
                className: "wrap-border"
            })]
        })
    }),
    Jn = "c1m0c4nm";
const Qn = T(function({
        style: n
    }) {
        const e = _(),
            s = B(),
            {
                resultOdds: a,
                resultAmount: o,
                resultCurrency: r
            } = s.result,
            [l, h] = j.exports.useState(a.gt(0)),
            m = a.toDP(2, y.ROUND_DOWN);
        return j.exports.useEffect(() => {
            const c = s.result.resultOdds.gt(0);
            c && s.sounds.playSound("bigwin"), h(c)
        }, [s.result]), i(dt, {
            config: l ? re.wobbly : re.default,
            children: l ? i(ht.div, {
                style: n,
                className: w(qn, l && "win", s.result.totalWin && "bigwin"),
                children: i("div", {
                    className: "inner-bg",
                    children: d("div", {
                        className: "inner-wrap",
                        children: [i(je, {
                            onClick: () => h(!1)
                        }), i("p", {
                            className: "t",
                            children: e("common.congratulations")
                        }), d("p", {
                            className: "sub-t",
                            children: [e("crash.common.won"), " \u{1F389}"]
                        }), d("div", {
                            className: "inner-result-wrap",
                            children: [d("p", {
                                className: "odds-t",
                                children: ["X", m.toString()]
                            }), i(ee, {
                                icon: !0,
                                name: r,
                                disableLocal: !0,
                                amount: o
                            })]
                        })]
                    })
                })
            }) : null
        })
    }),
    qn = "gq3rxz";
const Ae = 820,
    Kn = T(function() {
        const [n, e] = j.exports.useState(1), {
            isMobileStyle: s
        } = Pe(), a = B(), o = mt(m => {
            m.width > Ae ? e(1) : e(m.width / Ae)
        }), {
            statusName: r,
            isGameWin: l
        } = Nn(a.result), h = S.isMobile ? 1 : n;
        return i("div", {
            className: Yn,
            ref: o,
            children: i("div", {
                className: "tower-main",
                style: {
                    transform: `scale(${h})`
                },
                children: d("div", {
                    className: w("tower-bg", r, s && "mtower-bg"),
                    children: [d("div", {
                        className: "tower-head-area",
                        children: [i("div", {
                            className: "head-img"
                        }), l && d("div", {
                            className: "artboard-wrap",
                            children: [i("img", {
                                alt: "artboard",
                                className: "artboard-one",
                                src: N.artboard
                            }), i("img", {
                                alt: "artboard",
                                className: "artboard-two",
                                src: N.artboard
                            }), i("img", {
                                alt: "artboard",
                                className: "artboard-three",
                                src: N.artboard
                            }), i("img", {
                                alt: "artboard",
                                className: "artboard-four",
                                src: N.artboard
                            })]
                        })]
                    }), d("div", {
                        className: w("climb-area", "level-" + a.mode.level),
                        children: [Array(a.mode.level).fill(1).map((m, c) => i(Un, {
                            round: c + 1
                        }, "wrap-" + c)), i(Qn, {})]
                    })]
                })
            })
        })
    }),
    Yn = "gy3ssq9";
const zn = () => {
        const t = B(),
            n = U.useSingleDetail();
        return d(Oe, {
            children: [i(ft, {
                hideJackpot: !0,
                list: t.myBets,
                keyof: "betId",
                onDetail: n
            }), i(gt, {
                className: Zn,
                children: d("div", {
                    className: "inner-bg",
                    children: [i(Kn, {}), i(pt, {
                        className: "tower-house-edge"
                    })]
                })
            }), i(Re, {
                id: "tower-autobet-dialog"
            })]
        })
    },
    Zn = "g1fovrfo";
var Xn = T(zn);
const Ne = T(function() {
        const n = B(),
            {
                isMobileStyle: e
            } = Pe();
        return d("div", {
            className: ti,
            children: [i(P, {
                className: "preview-btn",
                onClick: () => {
                    e ? bt.push(i(vt, {
                        closeable: !0,
                        title: "Preview",
                        children: i(ke, {
                            isMobileStyle: e,
                            game: n
                        })
                    })) : n.openPreview = !n.openPreview
                },
                children: "Preview"
            }), i(Re, {
                id: "tower-autobet-dialog",
                children: !n.openPreview || e ? i(Oe, {}) : i(ke, {
                    isMobileStyle: e,
                    game: n
                })
            })]
        })
    }),
    ke = T(function({
        isMobileStyle: n,
        game: e
    }) {
        const s = e.previewTab,
            a = Math.max(e.guessQueue.length, 1);
        return i("div", {
            className: w(ei, n && "preview-mobile-pop"),
            children: d("div", {
                className: "preview-inner-wrap",
                children: [i(je, {
                    onClick: () => e.openPreview = !1
                }), i("p", {
                    className: "title",
                    children: "Preview"
                }), d("div", {
                    className: "list-wrap",
                    children: [d("div", {
                        className: "guess-tabs",
                        children: [Array(a).fill(1).map((o, r) => i(P, {
                            className: w("guesstab-item", s === r && "select"),
                            onClick: () => e.previewTab = r,
                            children: r + 1
                        }, "guess-item-" + r)), a < 5 && i(P, {
                            onClick: () => {
                                e.addRound(), e.previewTab = e.guessQueue.length - 1
                            },
                            children: i(R, {
                                name: "Close"
                            })
                        })]
                    }), i("div", {
                        className: "guess-step",
                        children: Array(e.mode.level).fill(1).map((o, r) => {
                            const l = Y(e.guessQueue),
                                h = (r + 1) % 3 === 0,
                                m = l[s] || [],
                                c = !e.isBetting && r <= m.length;
                            return i("div", {
                                className: w("round-wrap", c && "select-wrap"),
                                children: Array(e.mode.totalChose).fill(1).map((u, g) => {
                                    const p = m[r] ? m[r] === g + 1 : !1;
                                    return i("div", {
                                        className: w("mode-item", h && "sp", p && "over-select"),
                                        onClick: () => c && e.addField(s, r, g + 1),
                                        children: i("img", {
                                            alt: "box",
                                            src: N.box
                                        })
                                    }, "mode-item-" + g)
                                })
                            }, "round-wrap-" + r)
                        })
                    })]
                }), d("div", {
                    className: "bottom-area",
                    children: [i("button", {
                        onClick: () => {
                            e.isBetting || e.clearField(s)
                        },
                        children: "CLEAR"
                    }), i("button", {
                        onClick: () => {
                            e.isBetting || e.randomField(s)
                        },
                        children: "RANDOM"
                    }), i("button", {
                        className: "delete-btn",
                        onClick: () => {
                            e.isBetting || (e.deleteRound(s), e.previewTab = 0)
                        },
                        children: i(R, {
                            name: "Delete"
                        })
                    })]
                })]
            })
        })
    }),
    ei = "p1mq8do1",
    ti = "pc6ph4v";
const si = T(function() {
        return d("div", {
            className: w(ni, "game-form"),
            children: [S.isMobile && i(Te, {}), S.isMobile && i(Ne, {}), i(M.CoinInput, {
                checkIncrease: !0
            }), i(M.TimesInput, {}), i(M.IncreaseInput, {}), i(M.StopInput, {}), i(M.IncreaseInput, {
                isLose: !0
            }), i(M.StopInput, {
                isLose: !0
            }), !S.isMobile && i(Ne, {}), !S.isMobile && i(Te, {})]
        })
    }),
    Te = T(function() {
        const t = B(),
            n = _(),
            e = j.exports.useRef(_e(() => {
                if (t.autoBet.isRunning || t.isBetting) t.autoBet.stop();
                else {
                    if (t.isBetting) return;
                    t.autobetRoundIndex = 0, t.openPreview = !1, t.resetStatus(), t.autoBet.start().catch(H)
                }
            }, 1e3));
        return i(P, {
            className: "bet-button",
            type: "conic",
            size: "big",
            disabled: t.disableAutoBet,
            onClick: () => {
                e.current()
            },
            children: t.autoBet.isRunning ? n("common.stop_auto_bet") : n("common.start_auto_bet")
        })
    }),
    ni = "admitv0";
const ii = J.memo(function({
        mode: n,
        disabled: e,
        onChange: s
    }) {
        const a = [...x];
        return i(M.LabelSelect, {
            className: ri,
            label: "Select Difficulty",
            value: n,
            options: a.reverse(),
            disabled: e,
            onChange: s,
            renderLabel: o => i(ai, F({}, o)),
            renderOption: o => i(oi, F({}, o))
        })
    }),
    ai = J.memo(function(t) {
        return d("div", {
            className: "tigger-label",
            children: [i("div", {
                className: "fruit-img-wrap img-value-" + t.value,
                children: i("div", {
                    className: "img"
                })
            }), i("p", {
                children: t.label
            })]
        })
    }),
    oi = J.memo(function(t) {
        return d("div", {
            className: "option-item",
            children: [i("div", {
                className: "left-img fruit-img-wrap img-value-" + t.value,
                children: i("div", {
                    className: "img"
                })
            }), d("div", {
                className: "main-option",
                children: [i("p", {
                    children: t.label
                }), i("div", {
                    className: "list-wrap",
                    children: Array(t.totalChose).fill(1).map((n, e) => {
                        const s = e + 1 <= t.errorChose;
                        return i("div", {
                            className: w("item", s && "error"),
                            children: i(R, {
                                name: s ? "Close" : "Check"
                            })
                        }, String(e))
                    })
                })]
            })]
        })
    }),
    ri = "miqxta9";
const li = T(function() {
        const n = B();
        return d("div", {
            className: ci,
            children: [S.isMobile && i(Ce, {}), i(M.CoinInput, {}), i(ii, {
                mode: n.mode.value,
                disabled: n.isBetting,
                onChange: e => n.setMode(e)
            }), !S.isMobile && i(Ce, {})]
        })
    }),
    Ce = T(function() {
        const n = _(),
            e = B(),
            s = e.odds.lt(1) ? 1 : e.odds;
        if (e.isBetting && e.isJoinGame) {
            const a = e.jackpot[e.currencyName].maxProfitAmount,
                o = y.min(e.amount.mul(s), e.amount.add(a));
            return d(P, {
                className: "bet-button cashout-btn",
                size: "big",
                disabled: !e.canCashout,
                onClick: () => e.cashout(),
                children: [i("span", {
                    children: "TAKE"
                }), i(ee, {
                    name: e.currencyName,
                    amount: o,
                    icon: !0
                })]
            })
        }
        return i(P, {
            className: "bet-button",
            type: "conic",
            size: "big",
            disabled: e.isBetting,
            loading: e.isBetting && !e.isJoinGame,
            onClick: () => {
                e.handleBet().catch(a => {
                    H(a)
                })
            },
            children: n("common.bet")
        })
    }),
    ci = "m1wty80m";
const ui = J.memo(() => {
        const t = _(),
            n = B(),
            e = [{
                title: t("common.game_intro"),
                node: i(yn, {
                    game: n
                })
            }, {
                title: t("common.fairness"),
                node: "/tower_help/fairness"
            }, {
                title: t("common.bankroll"),
                node: i(An, {
                    game: n
                })
            }];
        return i(yt, {
            manualControl: i(li, {}),
            autoControl: i(si, {}),
            className: di,
            gameView: i(Xn, {}),
            tabs: [{
                label: t("common.all_bet"),
                value: U.AllBet
            }, {
                label: t("common.my_bet"),
                value: U.MyBet
            }],
            actions: [i(wt, {}), i(At, {}), i(Nt, {}), i(kt, {}), i(Tt, {}), i(Ct, {
                list: e
            })]
        })
    }),
    di = "gc98njm";
var hi = "/assets/sound_bet.42530855.mp3",
    mi = "/assets/click.4076d5bf.mp3",
    fi = "/assets/lose.1a683f53.mp3",
    gi = "/assets/win.45a5ff16.mp3",
    pi = "/assets/cashout.4a954d3d.mp3",
    bi = "/assets/sound_bg.3b4a5b17.mp3",
    vi = "/assets/biglose.f4662f0c.mp3";
const yi = V.encode(v.CashoutValue),
    wi = V.encode(v.BetValue),
    Ai = V.encode(v.Next),
    Ni = V.decode(v.BetValue),
    E = V.decode(v.GameValue);
class ki extends Bt {
    constructor() {
        super({
            name: "Tower",
            namespace: "/g/tower",
            sounds: {
                bet: hi,
                lose: fi,
                win: gi,
                click: mi,
                bigwin: pi,
                biglose: vi,
                bg: {
                    src: bi,
                    loop: !0,
                    isBackground: !0
                }
            }
        }, ui);
        b(this, "payout", 1.98);
        b(this, "mode", x[1]);
        b(this, "guessing", !1);
        b(this, "rounds", []);
        b(this, "cards", []);
        b(this, "guessQueue", [
            []
        ]);
        b(this, "isJoinGame", !1);
        b(this, "autobetRoundIndex", 0);
        b(this, "odds", new y(0));
        b(this, "result", we);
        b(this, "openPreview", !0);
        b(this, "autoModeWaitTime", !1);
        b(this, "needDeduction", !1);
        b(this, "maxbetAlertTime", !1);
        b(this, "previewTab", 0);
        b(this, "hotkeyBetfn", _e(() => {
            if (this.isAutoMode)
                if (this.autoBet.isRunning || this.isBetting) this.autoBet.stop();
                else {
                    if (this.disableAutoBet) {
                        this.openPreview = !0;
                        return
                    }
                    if (this.isBetting) return;
                    this.autobetRoundIndex = 0, this.openPreview = !1, this.resetStatus(), this.autoBet.start().catch(H)
                }
            else {
                if (this.isBetting) return;
                this.handleBet().catch(H)
            }
        }, 1e3));
        b(this, "addPayout", () => {
            this.isBetting || (this.payout = this.payout + .02)
        });
        b(this, "deletePayout", () => {
            this.isBetting || (this.payout = this.payout - .02)
        });
        b(this, "getChance", e => {
            const s = new y(99).div(e).toNumber();
            let a = S.isMobile ? 2 : 5;
            return s.toFixed(a)
        });
        St(this, {
            payout: A,
            mode: A,
            guessing: A,
            rounds: A,
            odds: A,
            result: A,
            cards: A,
            isJoinGame: A,
            openPreview: A,
            guessQueue: A,
            previewTab: A,
            autoModeWaitTime: A,
            maxProfit: It
        }), this.socket.on("connect", () => this.join()), le.waitLogin().then(() => this.join()), this.addHotkey("w", () => this.cashout(), "Cashout"), this.addHotkey("p", () => this.pickTile(), "Pick a Tile");
        const e = this.hotkeyList.find(s => s.key == "space");
        e && (e.handler = () => (this.hotkeyBetfn(), !1)), S.isMobile && (this.settings.hotkeyEnable = !1)
    }
    get maxProfit() {
        const {
            totalChose: e,
            errorChose: s
        } = this.mode, a = new y(e).sub(s).div(e), o = this.isBetting ? this.rounds.length + 1 : 0;
        return Ue(this.amount, o, a).sub(this.amount)
    }
    get canCashout() {
        return this.rounds.length >= 1
    }
    get disableAutoBet() {
        let e = !(this.guessQueue.length > 0);
        return e || (e = this.guessQueue.some(s => s.length === 0)), this.isBetting ? !1 : e
    }
    canGuess() {
        return this.isBetting && !this.guessing
    }
    get isAutoMode() {
        return this.controlIdx === 1
    }
    pickTile() {
        if (!this.autoBet.isRunning)
            if (this.isAutoMode) this.openPreview && this.randomField(this.previewTab);
            else {
                if (!this.canGuess() || this.maxbetAlertTime) return;
                const e = this.mode.totalChose,
                    s = Math.ceil(Math.random() * e);
                this.handleNext(s)
            }
    }
    betValue() {
        return wi({
            mode: this.mode.value
        })
    }
    setMode(e) {
        this.isBetting || (this.resetStatus(), this.guessQueue = [
            []
        ], this.mode = F({}, x[e]))
    }
    async join() {
        if (!this.isActived || !le.login) return;
        this.resetStatus();
        const e = await this.socketRequest("join").then(this.betResultDecoder),
            s = E(e.gameValue),
            a = Ni(e.betValue);
        if (this.controlIdx = 0, e.odds > 0) {
            this.setMode(a.mode), this.odds = new y(s.odds), this.guessing = !1, this.setBetStatus(!0);
            let o = this.getBetlog(e);
            s.fields.length > 0 && (this.currencyName = o.currencyName, setTimeout(() => this.amount = new y(o.betAmount), 100));
            try {
                await this.bet(new y(o.betAmount), o), this.setBetStatus(!1)
            } catch (r) {
                console.log("join error"), this.setBetStatus(!1)
            }
        }
    }
    resetStatus() {
        this.rounds = [], this.cards = [], this.result = we, this.maxbetAlertTime = !1, this.previewTab = 0
    }
    updateGrids(e, s) {
        this.cards = [...e], this.rounds = [...s]
    }
    async handleNext(e) {
        if (!!this.canGuess()) {
            this.maxbetAlertTime = !0, await this.checkMaxProfit(), this.maxbetAlertTime = !1, this.guessing = !0, this.sounds.playSound("click");
            try {
                const s = await this.socketRequest("next", Ai({
                    fields: e
                })).then(E);
                if (this.odds = new y(s.odds), s.odds !== 0) {
                    if (this.rounds.push(e), this.sounds.playSound("win"), s.cards.length > 0) {
                        this.updateGrids(s.cards, s.fields);
                        const a = this.jackpot[this.currencyName].maxProfitAmount,
                            o = y.min(this.amount.mul(s.odds + 1), this.amount.add(a));
                        this.emit("end", {
                            odds: s.odds,
                            winAmount: o,
                            totalWin: !0,
                            bigLose: !1
                        })
                    }
                } else {
                    this.rounds.push(e), this.sounds.playSound("lose");
                    const a = s.fields.length >= 5;
                    a && setTimeout(() => {
                        this.sounds.playSound("biglose")
                    }, 100), this.updateGrids(s.cards, s.fields), this.emit("end", {
                        odds: 0,
                        winAmount: 0,
                        totalWin: !1,
                        bigLose: a
                    })
                }
                this.guessing = !1
            } catch (s) {
                console.log("bet error", s), this.guessing = !1, this.join()
            }
        }
    }
    async handleAutoNext(e) {
        if (this.guessing || !this.isBetting || !this.autoBet.isRunning) return;
        const s = this.guessQueue[e];
        if (!(!s || s.length === 0)) {
            for (let a = 0; a < s.length; a++) {
                await this.handleNext(s[a]);
                const o = a === s.length - 1,
                    r = this.isBetting ? 500 : 0;
                if (this.odds.gt(0) && !o) await ce(r);
                else break
            }
            this.autoBet.isRunning && this.odds.gt(0) && s.length < this.mode.level && this.cashout()
        }
    }
    async cashout() {
        if (!(this.guessing || !this.canCashout)) {
            this.guessing = !0;
            try {
                const e = await this.socketRequest("cashout", yi({
                    frontgroundId: this.txId
                })).then(this.betResultDecoder);
                let {
                    odds: s,
                    winAmount: a,
                    currencyName: o
                } = e, r = E(e.gameValue);
                s /= this.oddsScale;
                const l = Mt.bn2amount(a, o);
                this.rounds.length !== r.fields.length && (console.log("cashout update"), this.isAutoMode || this.join()), this.updateGrids(r.cards, r.fields), this.emit("end", {
                    odds: s,
                    winAmount: l,
                    totalWin: !1,
                    bigLose: !1
                })
            } catch (e) {
                console.log("cashout error", e)
            } finally {
                this.guessing = !1
            }
        }
    }
    async bet(e = this.amount, s = 0) {
        if (this.isAutoMode && this.autobetRoundIndex >= 0 && (this.autoModeWaitTime = !0, await ce(1e3), this.autoModeWaitTime = !1), this.resetStatus(), de(s)) {
            this.sounds.playSound("bet"), this.guessing = !0;
            try {
                let m = this.betRequest(e, this.betValue(), s);
                this.onBetRequest && (m = this.onBetRequest(m)), s = await m, this.odds = new y(s.odds)
            } finally {
                de(s) && this.join(), this.guessing = !1
            }
        }
        let a = E(s.gameValue);
        this.rounds = a.fields, this.isJoinGame = !0;
        let {
            odds: o,
            winAmount: r
        } = await new Promise((m, c) => {
            const u = p => {
                    this.removeListener("deactivate", g), this.isJoinGame = !1, this.result = {
                        resultOdds: new y(p.odds),
                        resultAmount: p.winAmount,
                        resultCurrency: this.currencyName,
                        totalWin: p.totalWin,
                        bigLose: p.bigLose
                    }, m(p)
                },
                g = () => {
                    this.removeListener("end", u), c()
                };
            if (this.once("end", u), this.once("deactivate", g), this.isAutoMode) {
                const p = this.guessQueue.length || 1;
                this.handleAutoNext(this.autobetRoundIndex % p), this.autobetRoundIndex++
            }
        });
        s.odds = o, s.winAmount = r, s.profitAmount = r - s.betAmount, delete s.gameValue;
        let l = s.betId;
        return this.myBets.find(m => m.betId === l) || (this.addMyBet(s), this.emit("betEnd", {
            amount: new y(s.betAmount),
            odds: s.odds,
            currencyName: s.currencyName
        })), s
    }
    addRound() {
        this.guessQueue.push([])
    }
    deleteRound(e) {
        const s = Y(this.guessQueue);
        s.splice(e, 1), s.length === 0 && s.push([]), this.guessQueue = [...s]
    }
    addField(e, s, a) {
        const o = Y(this.guessQueue);
        o[e] ? o[e][s] ? o[e][s] === a ? o[e].pop() : o[e][s] = a : o[e].push(a) : o[e] = [a], this.guessQueue = [...o]
    }
    randomField(e) {
        const s = this.guessQueue[e] || [];
        if (s.length === this.mode.level) return;
        const a = Math.ceil(Math.random() * this.mode.totalChose);
        this.addField(e, s.length, a)
    }
    clearField(e) {
        this.guessQueue[e] = []
    }
}
const Je = new ki;
var $i = Je;
window.twg = Je;

function Di({
    bodyLock: t
}) {
    return i(Ge, {
        bodyLock: t,
        children: d("div", {
            className: "item",
            children: [i("h2", {
                children: "How are results calculated?"
            }), d("div", {
                className: "help-content",
                children: [i("div", {
                    children: "To get the results, we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce:row, serverSeed)."
                }), i("p", {
                    children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                }), i("p", {}), i("p", {
                    children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                }), i("p", {
                    children: "We put our \u201Ccards on the table.\u201D "
                }), i("p", {
                    children: "Good luck!"
                })]
            })]
        })
    })
}
const Ti = "https://bcgame-project.github.io/verify/tower.html",
    Ci = x.map(t => ({
        value: t.value,
        label: t.label
    })),
    Bi = () => {
        const t = _(),
            n = xt(),
            e = Gt(n),
            s = Et(() => ({
                serverSeed: e[0] || "",
                clientSeed: e[1] || "",
                nonce: parseInt(e[2]) || 0,
                mode: parseInt(e[3]) || 0
            })),
            {
                serverSeed: a,
                clientSeed: o,
                nonce: r,
                mode: l
            } = s,
            h = Mi(a, o, r, l),
            m = x[l];
        return i(jt, {
            title: Pt.t("common.fairness"),
            children: d(Ot, {
                className: xi,
                children: [i("h2", {
                    children: "Input"
                }), i(K, {
                    label: "Server Seed",
                    value: a,
                    onChange: c => s.serverSeed = c
                }), i(K, {
                    label: "Client Seed",
                    value: o,
                    onChange: c => s.clientSeed = c
                }), i(K, {
                    label: "Nonce",
                    value: r,
                    onChange: c => s.nonce = Number(c)
                }), i("div", {
                    className: "mode-label",
                    children: t("common.mode")
                }), i(Rt, {
                    value: l,
                    onChange: c => {},
                    options: Ci
                }), i("h2", {
                    children: "Final Result"
                }), d("div", {
                    className: "result-wrap",
                    children: [i("div", {
                        className: "result-table",
                        children: h.map((c, u) => i("div", {
                            className: "round-item",
                            children: c.sort().map((g, p) => i("div", {
                                className: "field-item",
                                children: g
                            }, "item-" + p))
                        }, "row-" + u))
                    }), i("div", {
                        className: "result-line",
                        children: i(R, {
                            name: "Direction"
                        })
                    }), i("div", {
                        className: "result-list",
                        children: Array(m.level).fill(1).map((c, u) => i("div", {
                            className: "round-item",
                            children: Array(m.totalChose).fill(1).map((g, p) => {
                                const G = h[u].includes(p + 1);
                                return i("div", {
                                    className: "field-item " + (G ? "right" : "error"),
                                    children: i(R, {
                                        name: G ? "Check" : "Close"
                                    })
                                }, "field-" + p)
                            })
                        }, "round-" + u))
                    })]
                }), i("p", {
                    className: "githubverify",
                    children: i("a", {
                        href: `${Ti}?s=${s.serverSeed}&c=${s.clientSeed}&n=${s.nonce}&m=${s.mode}`,
                        target: "_blank",
                        children: t("common.verify_on_github")
                    })
                })]
            })
        })
    };
var Hi = Bi;

function Si(t) {
    const n = [];
    for (let e = 0; e < t.length; e += 2) {
        let s = t[e] + t[e + 1],
            a = parseInt(s, 16);
        n.push(a)
    }
    return n
}

function Ii(t, n, e) {
    const s = t.substring(n * 8, (n + 1) * 8),
        a = Si(s),
        o = a[0] / Math.pow(256, 1),
        r = a[1] / Math.pow(256, 2),
        l = a[2] / Math.pow(256, 3),
        h = a[3] / Math.pow(256, 4),
        m = o + r + l + h;
    return Math.floor(m * e)
}

function Mi(t, n, e, s) {
    const a = x[s],
        o = [];
    for (let r = 0; r < a.level; r++) {
        const l = [],
            m = _t([n, e, r].join(":"), t).toString(),
            c = [];
        for (let u = 1; u <= a.totalChose; u++) c.push(u);
        for (let u = 0; u < a.totalChose - a.errorChose; u++) {
            const g = Ii(m, u, c.length);
            l.push(c[g]), c.splice(g, 1)
        }
        o.push(l)
    }
    return o
}
Vt({
    cl1: [ue("#99a4b0", .8), ue("#5f6975", .8)],
    cl2: ["rgba(153,164,176,0.6)", "rgba(95,105,117,0.8)"],
    cl3: ["rgba(45,48,53,0.5)", "#f5f6fa"],
    cl4: ["#2d3035", "#e9eaf2"],
    cl5: ["#f5f6f7", "#31373d"]
});
const xi = "fo9t0gs";
const Gi = (t, n, e, s, a) => {
        const o = a.betLog.bv.mode || "0";
        Lt(`/tower_help/validate/${t}/${n}/${e}/${o}`)
    },
    ji = U.withSingleDetail({
        onValidate: Gi,
        result: ({
            betLog: t
        }) => {
            const n = t.bv.mode,
                e = x[n];
            if (!e) return null;
            const {
                cards: s,
                fields: a,
                odds: o
            } = t.gv;
            return i(Wt, {
                className: "rt_items",
                style: {
                    padding: 0,
                    backgroundColor: "transparent"
                },
                children: i("div", {
                    className: w(Pi, "level-" + e.level),
                    children: Array(e.level).fill(1).map((r, l) => {
                        const h = (l + 1) % 3 === 0;
                        return i("div", {
                            className: w("round-item", "mode-" + e.value),
                            children: Array(e.totalChose).fill(1).map((m, c) => {
                                let u = "common";
                                const g = c + 1;
                                return s[l].includes(g) && (u = "over-right"), a[l] && (a[l] === g && (u = "over-select"), o === 0 && l + 1 === a.length && g === a[l] && (u = "over-lose")), i("div", {
                                    className: w("field-item", h && "third", u),
                                    children: i("div", {
                                        className: "fruit-wrap",
                                        children: i("div", {
                                            className: "fruit-img"
                                        })
                                    })
                                }, "field-" + c)
                            })
                        }, "round-" + l)
                    })
                })
            })
        }
    }),
    Pi = "dcaef74";
var Ui = ji;
export {
    An as Bankroll, Ui as Detail, Di as Fairness, $i as Game, Hi as Validate
};
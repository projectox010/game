import {
    a5 as C,
    a as e,
    ck as ue,
    l as w,
    r,
    j as a,
    F as x,
    b2 as me,
    o as m,
    e as T,
    cl as o,
    K as $,
    aU as he,
    a9 as U,
    u as b,
    d as _,
    aZ as B,
    s as N,
    a4 as Y,
    cm as fe,
    cn as pe,
    co as ge,
    a3 as D,
    S as H,
    A as p,
    cp as be,
    T as V,
    k as J,
    t as M,
    q as g,
    al as Q,
    D as S,
    ak as X,
    cq as ve,
    H as ee,
    p as z,
    G as k,
    ab as ye,
    cr as F,
    Z as Ne,
    cs as Ce,
    ct as xe,
    b as Re,
    cu as Le,
    a2 as te,
    br as ke,
    cv as Ie,
    cw as Se,
    bY as we,
    cx as j
} from "./index.28e31dff.js";
import {
    s as Te
} from "./sortedIndex.6b9ffc19.js";
const q = C.memo(function({
        num: t,
        className: s = ""
    }) {
        return e(ue, {
            className: w("pri-badge", _e, s),
            num: t
        })
    }),
    se = C.memo(function({
        value: t,
        options: s,
        onChange: c
    }) {
        const i = r.exports.useMemo(() => s.map((d, h) => ({
            label: a(x, {
                children: [d.label, d.badge > 0 && e(q, {
                    num: d.badge
                })]
            }),
            value: null
        })), [s]);
        return e(me, {
            className: Ve,
            type: "line",
            value: t,
            tabs: i,
            onChange: c
        })
    }),
    _e = "b1xozo51",
    Ve = "p1jmax55";
const ne = C.memo(function({
        title: t,
        avatar: s,
        content: c,
        children: i,
        className: d,
        onClick: h
    }) {
        return a("div", {
            onClick: h,
            className: w(Pe, d),
            children: [e("div", {
                className: "avatar-wrap",
                children: s
            }), a("div", {
                className: "middle-wrap",
                children: [e("div", {
                    className: "title-wrap",
                    children: t
                }), e("div", {
                    className: "content-wrap",
                    children: c
                })]
            }), i]
        })
    }),
    ae = ({
        room: n
    }) => a(x, {
        children: [e("div", {
            className: "name",
            children: n.user.name
        }), e(U, {
            className: "titles",
            code: n.titles,
            desc: n.titleDesc
        })]
    }),
    Me = m(function({
        data: t
    }) {
        const s = T();
        r.exports.useEffect(() => {
            t.user.syncOnlineStatus()
        }, [t]);
        const c = t === o.openedRoom,
            i = () => {
                s(`/chat/${t.user.userId}`)
            };
        return a(ne, {
            className: w(qe, c && "is-active"),
            onClick: i,
            avatar: e(Fe, {
                userId: t.user.userId,
                name: t.user.name,
                level: t.level
            }),
            title: e(ae, {
                room: t
            }),
            content: e("div", {
                className: "msg",
                children: t.lastMsg.slice(0, 30)
            }),
            children: [a("div", {
                className: "other-wrap",
                children: [e("div", {
                    className: "time",
                    children: new Date(t.lastSpeakTime).toLocaleTimeString()
                }), e(q, {
                    num: t.unread
                })]
            }), t.isOnline && e("div", {
                className: "is-online"
            })]
        })
    }),
    Fe = C.memo(function({
        userId: t,
        name: s,
        level: c
    }) {
        return a(x, {
            children: [e($, {
                userId: t,
                name: s
            }), e(he, {
                level: c
            })]
        })
    });
var P = {
    Item: ne,
    Recent: Me,
    Title: ae
};
const qe = "r1hinv9c",
    Pe = "sdqnh85";
var Ae = m(function({
    userId: n = 0
}) {
    const t = b(),
        [s, c] = r.exports.useState(0),
        i = r.exports.useCallback(() => o.recentList, []),
        d = r.exports.useCallback(() => o.adminList, []),
        h = r.exports.useCallback(() => o.strangerList, []),
        l = r.exports.useCallback(() => o.recentVipList, []),
        f = [{
            label: t("page.prichat.recent"),
            badge: o.recentUnread,
            node: e(I, {
                getList: i
            }, "recent")
        }, o.adminList.length > 0 && {
            label: t("common.official"),
            badge: 0,
            node: e(I, {
                getList: d
            }, "official")
        }, _.chatRoomPermission.vipable && {
            label: "VIP",
            badge: 0,
            node: e(I, {
                getList: l
            }, "vip")
        }, {
            label: t("common.stranger"),
            badge: 0,
            node: e(I, {
                getList: h
            }, "stranger")
        }].filter(Boolean);
    return a("div", {
        className: Ue,
        children: [e(se, {
            options: f,
            value: s,
            onChange: c
        }), e(B, {
            className: "tab-list",
            value: s,
            onChange: c,
            drag: N.isMobile,
            children: f.map(v => v.node)
        })]
    })
});
const I = m(function({
        getList: t
    }) {
        return t().length === 0 ? e(Y, {}) : e(Ee, {
            getList: t
        })
    }),
    Ee = m(function({
        getList: t
    }) {
        const s = r.exports.useRef([]),
            c = fe(),
            i = t();
        c && (s.current = i);
        const d = r.exports.useCallback(l => e(P.Recent, {
                data: l
            }), []),
            h = r.exports.useCallback(() => pe(66), []);
        return e(ge, {
            className: $e,
            data: s.current,
            renderItem: d,
            estimateSize: h
        })
    }),
    $e = "s11yv2du",
    Ue = "r1d80394";
var Be = m(function() {
    return _.chatRoomPermission.vipable ? e(De, {}) : e(ce, {})
});
const De = m(function() {
        const t = b(),
            [s, c] = r.exports.useState(0),
            i = [{
                label: t("page.prichat.friends"),
                badge: o.unReadRequest
            }, {
                label: "VIP",
                badge: 0
            }],
            d = r.exports.useCallback(() => o.vipList, []);
        return o.inited ? a("div", {
            className: ze,
            children: [e(se, {
                options: i,
                value: s,
                onChange: c
            }), a(B, {
                value: s,
                onChange: c,
                drag: N.isMobile,
                children: [e(ce, {}), e(I, {
                    getList: d
                })]
            })]
        }) : e(D, {})
    }),
    ce = m(function() {
        return a(H, {
            className: Oe,
            children: [e(He, {}), o.friendList.map(t => e(P.Recent, {
                data: t
            }, t.user.userId))]
        })
    }),
    He = m(function() {
        const t = b(),
            s = T();
        return e(P.Item, {
            className: je,
            avatar: e("div", {
                className: "circle",
                children: e(p, {
                    name: "AddFirend"
                })
            }),
            title: e("div", {
                style: {
                    marginRight: "auto"
                },
                children: t("user.friend_request")
            }),
            content: e("div", {
                className: "msg",
                children: t("user.friend_request_msg")
            }),
            onClick: () => s("/chat/requests"),
            children: e("div", {
                className: "other-wrap",
                children: e(q, {
                    num: o.unReadRequest
                })
            })
        })
    }),
    Oe = "sf5g1se",
    ze = "f1ohdb78",
    je = "f4coauu";
const re = m(function() {
    const t = b(),
        s = r.exports.useCallback(i => o.searchMsg = i.target.value, []),
        c = r.exports.useCallback(() => be(() => {
            o.searchMsg = "", o.searchVisible = !1
        }), []);
    return a("div", {
        className: `${Ye} pri-search`,
        "aria-expanded": o.searchVisible,
        children: [a("label", {
            children: [e("div", {
                className: "zoom",
                children: e(p, {
                    name: "Search"
                })
            }), e("input", {
                onFocus: () => o.searchVisible = !0,
                value: o.searchMsg,
                placeholder: t("page.prichat.search_input"),
                onChange: s
            })]
        }), e(V, {
            children: o.searchVisible && e(J.button, {
                className: "cancel",
                onClick: c,
                children: t("common.actions.cancel")
            })
        })]
    })
});
var ie = m(function() {
    return e(x, {
        children: e(V, {
            from: Ge,
            enter: Ze,
            config: Ke,
            children: o.searchVisible && e(We, {})
        })
    })
});
const We = m(function({
        style: t
    }) {
        return e(H, {
            className: Je,
            style: t,
            children: o.searchedRooms.length === 0 ? e(Y, {}) : o.searchedRooms.map(s => e(P.Recent, {
                data: s
            }, s.groupId))
        })
    }),
    Ke = {
        tension: 400,
        friction: 45
    },
    Ge = {
        x: "100%"
    },
    Ze = {
        x: "0%"
    };
M({
    cl1: ["#99a4b0", "#31373d"],
    cl2: ["#17181b", "#f6f7fa"],
    cl3: [g("#99a4b0", .5), g("#31373d", .5)]
});
const Ye = "e5d61nz",
    Je = "saqwthe";

function oe({
    className: n
}) {
    const t = b();
    return a(Q, {
        className: w(Qe, n),
        to: "/privacy_setting",
        children: [e(p, {
            name: "Setting"
        }), !N.isMobile && t("common.options")]
    })
}
const Qe = "w16ige16";
const Xe = C.memo(function({
        path: n
    }) {
        const t = b();
        return e(S, {
            className: st,
            title: t("page.prichat.title"),
            nostyle: !0,
            children: a("div", {
                className: `${de} chat-category`,
                children: [e(X, {
                    children: a(x, {
                        children: [e(oe, {
                            className: "privacy"
                        }), e(re, {})]
                    })
                }), e(le, {
                    children: e(ie, {})
                })]
            })
        })
    }),
    et = C.memo(function() {
        return a("div", {
            className: `${de} chat-category`,
            children: [e("div", {
                className: "search-box",
                children: e(re, {})
            }), e(le, {
                children: e(ie, {})
            })]
        })
    }),
    le = C.memo(function({
        children: t
    }) {
        const [s, c] = r.exports.useState(1);
        return a("div", {
            id: "private-chat-list",
            className: "pri-tabbox",
            children: [a(B, {
                value: s,
                onChange: c,
                drag: !1,
                children: [e(Be, {}), e(Ae, {})]
            }), e(tt, {
                value: s,
                onChange: c
            }), t]
        })
    }),
    tt = m(function({
        value: t,
        onChange: s
    }) {
        const c = b(),
            i = [{
                label: e(W, {
                    label: c("page.prichat.friends"),
                    badge: o.unReadRequest,
                    icon: e(p, {
                        name: "Firends"
                    })
                }),
                value: 0
            }, {
                label: e(W, {
                    label: c("page.prichat.messages"),
                    badge: o.recentUnread,
                    icon: e(p, {
                        name: "Message"
                    })
                }),
                value: 1
            }];
        return e("div", {
            className: "tabs",
            children: e(ve, {
                value: t,
                onChange: s,
                options: i,
                children: ({
                    active: d,
                    option: h
                }) => e("div", {
                    className: `tab-item${d?" is-active":""}`,
                    children: h.label
                })
            })
        })
    });

function W({
    icon: n,
    badge: t,
    label: s
}) {
    return a(x, {
        children: [n, e("div", {
            className: "label",
            children: s
        }), t > 0 && e(q, {
            num: t
        })]
    })
}
var K = Xe;
const st = "p1i6mfnf";
M({
    cl1: ["#17181b", "#fff"],
    cl2: ["#1e2024", "transparent"],
    cl3: ["transparent", "#f6f7fa"],
    cl4: [g("#99a4b0", .1), "#e9eaf2"],
    cl5: ["#1e2024", "#fff"],
    cl6: [g("#98a7b5", .8), g("#5f6975", .8)],
    cl7: [g("#2d3035", .45), "#f5f6fa"],
    cl8: ["#f5f6f7", "#31373d"]
});
const de = "w9psqzn";
var nt = m(function({
    room: t
}) {
    return a("div", {
        className: `${rt} pri-head`,
        children: [a("div", {
            className: "user-info",
            children: [a("div", {
                className: "info",
                children: [e("div", {
                    className: "pri-title",
                    children: t.user.name
                }), e(U, {
                    code: t.titles,
                    desc: t.titleDesc
                })]
            }), t.user.isOnline && e("div", {
                className: "online",
                children: "Online"
            })]
        }), e(at, {
            room: t
        })]
    })
});
const at = m(function({
        room: t
    }) {
        const s = b(),
            c = T(),
            [i, d] = r.exports.useState(!1),
            h = ee(() => d(!1)),
            l = !t.isAdmin && !t.isBot,
            f = async () => {
                try {
                    await t.user.report();
                    let u = s("common.messages.success@", s("common.report"));
                    await z.confirm(`${u},${s("common.messages.confirm_block_user")}`) && t.blockRoom()
                } catch (u) {
                    k(u)
                }
            },
            v = async () => {
                if (await z.confirm(s("common.messages.confirm_clear_chat"))) try {
                    await t.deleteRoom(), c("/chat")
                } catch (u) {
                    k(u)
                }
            },
            y = async () => {
                try {
                    t.isRequest ? await t.user.agreeRequest() : (await t.user.friendRequest(), ye.trackEvent("add_friends", {
                        member_name: t.user.name,
                        member_id: String(t.user.userId),
                        member_level: t.level
                    }))
                } catch (u) {
                    k(u)
                }
            },
            R = async () => {
                try {
                    await t.friendRemove(), c("/chat")
                } catch (u) {
                    k(u)
                }
            },
            A = l && a(x, {
                children: [a("button", {
                    onClick: f,
                    children: [e(p, {
                        name: "Caution"
                    }), e("span", {
                        children: s("common.report")
                    })]
                }), t.isFriend ? a("button", {
                    onClick: R,
                    children: [e(p, {
                        name: "DeleteFirend"
                    }), e("span", {
                        children: s("common.friend_remove")
                    })]
                }) : a("button", {
                    onClick: y,
                    children: [e(p, {
                        name: "AddFirend"
                    }), e("span", {
                        children: s("common.friend_add")
                    })]
                }), t.isBlock ? a("button", {
                    onClick: () => t.unBlockRoom(),
                    children: [e(p, {
                        name: "Blocked"
                    }), e("span", {
                        children: s("common.unblock")
                    })]
                }) : a("button", {
                    onClick: () => t.blockRoom(),
                    children: [e(p, {
                        name: "Block"
                    }), e("span", {
                        children: s("common.block")
                    })]
                }), a("button", {
                    onClick: v,
                    children: [e(p, {
                        name: "Delete"
                    }), e("span", {
                        children: s("page.prichat.room_remove")
                    })]
                })]
            });
        return e("div", {
            className: ct,
            ref: h,
            children: a("div", {
                className: "btn",
                onClick: () => d(!i),
                onMouseEnter: () => !N.isMobile && d(!0),
                onMouseLeave: () => !N.isMobile && d(!1),
                children: [e($, {
                    userId: t.user.userId,
                    name: t.user.name
                }), e("span", {
                    className: "flex-center",
                    children: e(p, {
                        name: "Menu"
                    })
                }), e(V, {
                    from: {
                        y: "7%",
                        scale: 1,
                        opacity: 0
                    },
                    enter: {
                        y: "0%",
                        scale: 1,
                        opacity: 1
                    },
                    children: i && e(J.div, {
                        className: "pop-layer",
                        children: a("div", {
                            className: "pop-wrap",
                            children: [a("button", {
                                onClick: () => c(`/user/profile/${t.user.userId}`),
                                children: [e(p, {
                                    name: "UserProfile"
                                }), e("span", {
                                    children: s("title.profile")
                                })]
                            }), A]
                        })
                    })
                })]
            })
        })
    }),
    ct = "a1rdemgx",
    rt = "hzkz3mc";
var it = m(function() {
    const t = F(),
        s = b(),
        [c, i] = r.exports.useState(!1),
        d = r.exports.useRef(null),
        h = ee(r.exports.useCallback(() => i(!1), [])),
        l = r.exports.useCallback(u => {
            t.inputValue = u
        }, [t]),
        f = r.exports.useCallback(u => {
            t.sendChat(`[gif=${u}]`)
        }, [t]),
        v = r.exports.useCallback(u => {
            const O = u + " ",
                L = d.current;
            L.setRangeText(O), t.inputValue = L.value, L.focus(), L.selectionStart = L.selectionEnd = (L.selectionStart || 0) + O.length
        }, [t]),
        y = r.exports.useCallback(async () => {
            if (t.inputValue != "") return t.sendChat().catch(k)
        }, [t]),
        R = r.exports.useCallback(u => {
            u.keyCode == 13 && !u.shiftKey && (y(), u.preventDefault())
        }, [t]),
        A = r.exports.useCallback(() => i(!0), []);
    return a("div", {
        className: lt,
        "aria-expanded": c,
        ref: h,
        children: [a(Ne, {
            ref: d,
            className: "input",
            placeholder: s("common.you_message"),
            value: t.inputValue,
            onChange: l,
            onKeyDown: R,
            onFocus: A,
            maxHeight: 96,
            children: [e(Ce, {
                className: "gift-btn",
                onChange: f
            }), e(xe, {
                className: "emoji-btn",
                onChange: v
            }), e(ot, {})]
        }), e(V, {
            enter: G.enter,
            from: G.from,
            children: c && e(Re, {
                className: "send-button",
                onClick: y,
                children: e(p, {
                    name: "Send"
                })
            })
        })]
    })
});
const G = {
        from: {
            x: "100%",
            opacity: 0
        },
        enter: {
            x: "0%",
            opacity: 1
        }
    },
    ot = C.memo(() => {
        const n = F(),
            [t, s] = r.exports.useState(!1);
        return e(Le, {
            onChange: i => {
                i[0] && (s(!0), n.sendImage(i[0]).then(() => s(!1)).catch(() => s(!1)))
            },
            children: t ? e(D, {
                size: 20
            }) : e(p, {
                name: "Image"
            })
        })
    });
M({
    cl1: [g("#17181b", .8), g("#e9eaf2", .4)],
    cl2: ["#cad1d9", "#5f6975"],
    cl3: [g("#99a4b0", .8), g("#5f6975", .8)],
    cl4: ["#f5f6f7", "#5f6975"]
});
const lt = "i1naqzwh";
let E = "";
var Nt = m(function() {
    const {
        path: n = "empty"
    } = te(), [t] = ke(), s = t.get("phrase") || "", c = b();
    return r.exports.useState(() => (E = s, null)), N.isMobile ? e(S, {
        className: ft,
        nostyle: !0,
        children: e(Z, {
            path: n
        })
    }) : e(S, {
        className: pt,
        title: c("page.prichat.title"),
        nostyle: !0,
        size: [780, 800],
        children: a(x, {
            children: [e(X, {
                children: e(oe, {})
            }), e(et, {}), e(Z, {
                path: n
            })]
        })
    })
});
const Z = C.memo(function({
        path: t
    }) {
        const s = o.routes[t];
        return s ? e(s, {}) : e(dt, {
            userId: Number(t)
        })
    }),
    dt = m(function({
        userId: n
    }) {
        b();
        const t = o.openedRoom;
        return r.exports.useEffect(() => o.joinEffect(n), [n]), r.exports.useEffect(() => {
            E === "claim_weekly" && t && (t.sendChat("Claim my weekly VIP bonus"), E = "")
        }, [t]), t ? e(Ie.Provider, {
            value: t,
            children: e(Se, {
                className: gt,
                id: "private-chat-room",
                header: e(nt, {
                    room: t
                }),
                footer: e(it, {}),
                children: e(ut, {})
            })
        }) : null
    }),
    ut = m(function() {
        return F().inited ? e(mt, {}) : e(D, {})
    }),
    mt = m(function() {
        const t = b(),
            s = F(),
            c = r.exports.useRef(!1),
            i = r.exports.useRef([]),
            d = r.exports.useCallback(l => {
                const f = l.currentTarget,
                    v = f.scrollTop + f.offsetHeight;
                c.current = v >= f.scrollHeight - 30;
                const y = Te(i.current, v),
                    R = s.history[y - 1];
                R && s.readIdx(R)
            }, [s]);
        r.exports.useLayoutEffect(() => {
            const l = s.ref.current;
            s.history.length > 0 && (l.scrollTop = l.scrollHeight - l.clientHeight)
        }, [s]), r.exports.useLayoutEffect(() => {
            const l = s.ref.current;
            i.current = Array.from(l.getElementsByClassName("chat-item")).map(f => f.offsetTop), s.history.length > 0 && (c.current || s.history[s.history.length - 1].userId === _.userId) && (l.scrollTop = l.scrollHeight - l.clientHeight)
        }, [s.history]);
        const h = we(s.history.map((l, f) => {
            let v = !1;
            (f == 0 || l.createTime - s.history[f - 1].createTime > 12e5) && (v = !0);
            const y = e(ht, {
                msg: l
            }, l.id);
            return v ? [e("div", {
                className: "chat-date",
                children: e("div", {
                    children: new Date(l.createTime).toLocaleString()
                })
            }, `t-${l.id}`), y] : y
        }));
        return e(H, {
            ref: s.ref,
            onScroll: d,
            className: "chat-list",
            children: h.length == 0 ? a("div", {
                className: "gm-warning",
                children: [e("span", {
                    children: t("page.prichat.gm_warning", N.domain)
                }), e(U, {
                    code: [99]
                })]
            }) : h
        })
    });

function ht({
    msg: n
}) {
    let t;
    const s = n.chat;
    return s instanceof Array ? s[0].type === "img" || s[0].type === "gif" ? t = e(j, {
        msg: s
    }) : t = e("div", {
        className: "content",
        children: e(j, {
            msg: s
        })
    }) : s.subType === "Tip" ? t = a("div", {
        className: "content",
        children: [e("span", {
            children: "Tipped"
        }), a("strong", {
            children: ["\xA0", s.systemMessage[1]]
        })]
    }) : t = e("div", {
        className: "content",
        dangerouslySetInnerHTML: {
            __html: s.systemMessage
        }
    }), a("div", {
        className: `chat-item${_.userId==n.userId?" is-self":""}`,
        children: [e(Q, {
            className: "head",
            to: `/user/profile/${n.userId}`,
            children: e($, {
                userId: n.userId,
                name: n.name
            })
        }), t]
    })
}
const ft = "rbpp7s0",
    pt = "p1wiwhrk";
M({
    cl1: [g("#99a4b0", .6), g("#5f6975", .6)],
    cl2: ["#1e2024", "#f5f6fa"],
    cl3: ["#cad1d9", "#17181b"],
    cl4: [g("#31343a", .8), "#f5f6fa"]
});
const gt = "r1nlsbww";

function Ct() {
    const n = te(),
        t = b(),
        s = T(),
        c = Number(n.userId);
    return r.exports.useEffect(() => {
        N.isMobile && c !== 0 && s(`/chat/${c}`)
    }, []), N.isMobile ? e(K, {}) : e(S, {
        title: t("title.user_chat"),
        size: [780, 700],
        nostyle: !0,
        children: e("div", {
            className: bt,
            children: e(K, {})
        })
    })
}
const bt = "clx0oag";
export {
    Ct as Chat, K as ListView, Nt as RoomView
};
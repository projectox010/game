import {
    o as F,
    c,
    w as A,
    x as m,
    r as E,
    s as y,
    j as a,
    l as w,
    F as S,
    a as e,
    C as W,
    p as I,
    t as j,
    q as f,
    u as M,
    e as R,
    y as P,
    L as B,
    I as T,
    B as U,
    v as z,
    D as V
} from "./index.28e31dff.js";

function L() {
    return [{
        gradientItem: [{ in: "#F6C722",
            out: "#FF832B"
        }, { in: "#FFA22B",
            out: "#ED6300"
        }, { in: "#C037FF",
            out: "#9701DD"
        }],
        wordWhite: !1,
        gradientBgColor: "#eca832",
        title: m.t("wallet.bcd.deposit.first_title"),
        borderColor: "#ffbc00",
        bgList: [4, 5, 6]
    }, {
        gradientItem: [{ in: "#FFA22B",
            out: "#ED6300"
        }, { in: "#FF7237",
            out: "#DD5101"
        }, { in: "#09C056",
            out: "#02AB56"
        }],
        wordWhite: !1,
        gradientBgColor: "#e56237",
        title: m.t("wallet.bcd.deposit.second_title"),
        borderColor: "#e56237",
        bgList: [5, 7, 8]
    }, {
        gradientItem: [{ in: "#C037FF",
            out: "#9701DD"
        }, { in: "#9037FF",
            out: "#7101DD"
        }, { in: "#C30BCE",
            out: "#BD02C0"
        }],
        wordWhite: !0,
        gradientBgColor: "#bc08e2",
        title: m.t("wallet.bcd.deposit.third_title"),
        borderColor: "#bc08e2",
        bgList: [6, 9, 10]
    }, {
        gradientItem: [{ in: "#9037FF",
            out: "#7101DD"
        }, { in: "#1EE077",
            out: "#10CF68"
        }, { in: "#E0980A",
            out: "#AA4D0B"
        }],
        wordWhite: !0,
        gradientBgColor: "#721afc",
        title: m.t("wallet.bcd.deposit.fourth_title"),
        borderColor: "#721afc",
        bgList: [1, 2, 3]
    }]
}
const q = F(function({
    topDom: s
}) {
    const i = c.rechargeValidNum || 0,
        l = A(c.bonusItems, "rechargeUsd"),
        {
            gradientItem: n,
            wordWhite: g,
            gradientBgColor: d,
            title: h,
            borderColor: b,
            bgList: C
        } = L()[i],
        [r, v] = E.exports.useState(c.selectStatus.bonusRatio * 100),
        u = o => {
            const t = Math.floor(o / 20),
                _ = o % 20 !== 0,
                k = (o - t * 20) / 20 * 100;
            return [1, 1, 1, 1, 1].map((K, N) => {
                const $ = N < t ? "item full-item" : "item";
                return e("div", {
                    className: $,
                    children: _ && N === t ? e("span", {
                        style: {
                            width: `${k}%`
                        }
                    }) : e("span", {})
                }, N)
            })
        },
        D = y.isDarken ? `radial-gradient(circle at 100% -20%, ${d}, #1e2024 70%)` : `radial-gradient(circle at 120% -35%, ${d}, #e9eaf2 75%)`;
    return a("div", {
        className: w(x, s && "has-top"),
        style: {
            backgroundImage: D
        },
        children: [s || a(S, {
            children: [e(W, {
                onClick: () => I.close()
            }), e("p", {
                className: "title",
                children: h
            })]
        }), e("div", {
            className: "mid",
            children: l.map((o, t) => e(G, {
                depositnNum: l[t].rechargeUsd,
                percent: l[t].bonusRatio,
                changeHoverBonus: v,
                wordWhite: g,
                gradientItem: n[t],
                bgNum: C[t],
                borderColor: b,
                last: t === l.length - 1,
                gradientBgColor: d
            }, t))
        }), e("div", {
            className: "percent",
            children: u(r)
        }), e("div", {
            className: "percent-num",
            children: a("span", {
                className: "num",
                style: {
                    left: r > 100 ? "100%" : `${r}%`
                },
                children: ["+", r, "%"]
            })
        })]
    })
});
j({
    cl1: ["rgba(245, 246, 252, 0.92)", "rgba(245, 246, 252, 0.5)"],
    cl2: ["#ffffff", "#31373d"],
    cl3: [f("#d8d8d8", .1), f("#ffffff", .9)],
    cl4: [f("#ffffff", .2), f("#b2b2b2", .1)]
});
const x = "d2jz8rw",
    G = F(function({
        depositnNum: s,
        percent: i,
        changeHoverBonus: l,
        last: n,
        wordWhite: g,
        gradientItem: d,
        bgNum: h,
        borderColor: b,
        gradientBgColor: C
    }) {
        const r = M(),
            v = R(),
            u = new P(i).mul(100).toNumber(),
            D = U["sf_" + h],
            o = g ? "#ffffff" : "#000000";
        return e("div", {
            className: w(H, "item", c.selectStatus.bonusRatio === i && "select"),
            onMouseEnter: () => l(u),
            onMouseLeave: () => l(c.selectStatus.bonusRatio * 100),
            onClick: () => {
                c.setSeleteStatus(i), I.close(), v("/wallet/deposit")
            },
            children: e("div", {
                className: "deposit-bg",
                style: {
                    borderColor: b
                },
                children: a("div", {
                    className: "main-bg",
                    children: [a("div", {
                        className: "top",
                        style: {
                            backgroundImage: `radial-gradient(circle at 50% 50%, ${d.in}, ${d.out} 67%)`
                        },
                        children: [e("img", {
                            className: "sf-img",
                            alt: "sf",
                            src: D
                        }), a("div", {
                            className: "top-info",
                            children: [e("p", {
                                className: "p_1",
                                style: {
                                    color: n ? "#fff" : o
                                },
                                children: r("common.deposit")
                            }), e("p", {
                                className: "p_2",
                                style: {
                                    color: n ? "#ffd005" : o
                                },
                                children: e(B, {
                                    amount: s
                                })
                            }), e("div", {
                                className: "add"
                            }), a("p", {
                                className: "p_3",
                                style: {
                                    color: n ? "#ffd005" : o
                                },
                                children: [u, "%"]
                            }), e("p", {
                                className: "p_4",
                                style: {
                                    color: n ? "#fff" : o
                                },
                                children: r("page.vip.dialog.table.head5")
                            })]
                        })]
                    }), e("div", {
                        className: "bottom-gradient",
                        style: {
                            backgroundImage: `linear-gradient(to bottom, ${y.isDarken?"#17181b":"#e9eaf2"} 74%, ${C} 131%)`
                        }
                    }), a("div", {
                        className: "bottom",
                        children: [a("p", {
                            children: [r("common.deposit"), " ", e(B, {
                                amount: s
                            })]
                        }), e("p", {
                            children: e(T, {
                                k: "wallet.bcd.deposit.extra",
                                children: e("span", {
                                    children: e(B, {
                                        amount: s * i
                                    })
                                })
                            })
                        })]
                    })]
                })
            })
        })
    }),
    H = "d1spgnjo",
    Q = p => {
        const s = c.rechargeValidNum || 0,
            i = L()[s].title;
        z.push(e(V, {
            title: i,
            nostyle: !0,
            children: e(q, {
                topDom: p
            })
        }))
    };
export {
    q as D, Q as a
};
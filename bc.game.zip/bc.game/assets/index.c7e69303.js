var Fs = Object.defineProperty,
    Ls = Object.defineProperties;
var Es = Object.getOwnPropertyDescriptors;
var sr = Object.getOwnPropertySymbols;
var zs = Object.prototype.hasOwnProperty,
    Ws = Object.prototype.propertyIsEnumerable;
var Ga = (g, b, s) => b in g ? Fs(g, b, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : g[b] = s,
    lr = (g, b) => {
        for (var s in b || (b = {})) zs.call(b, s) && Ga(g, s, b[s]);
        if (sr)
            for (var s of sr(b)) Ws.call(b, s) && Ga(g, s, b[s]);
        return g
    },
    cr = (g, b) => Ls(g, Es(b));
var O = (g, b, s) => (Ga(g, typeof b != "symbol" ? b + "" : b, s), s);
import {
    aM as js,
    de as Ft,
    u as Y,
    j as S,
    df as Hs,
    a as m,
    A as Ae,
    am as ur,
    b as le,
    o as Q,
    r as H,
    cW as Vs,
    bv as yt,
    ah as kr,
    ao as _r,
    s as ke,
    q as Z,
    Y as Gs,
    F as wt,
    t as kt,
    a5 as Ue,
    v as $s,
    D as Et,
    bh as Mr,
    dg as qs,
    e as Us,
    b2 as Ys,
    dh as Ya,
    aO as Ir,
    db as Xs,
    a$ as sa,
    di as Ks,
    k as Js,
    J as de,
    y as $e,
    dj as Zs,
    dk as Qs,
    dl as el,
    G as bt,
    dm as tl,
    bP as al,
    P as Sr,
    b0 as Za,
    d as Ce,
    dn as Xa,
    a4 as Cr,
    U as Pr,
    l as zt,
    S as Tr,
    M as na,
    bM as Nr,
    cn as Dr,
    dp as Lt,
    bN as ye,
    dq as nl,
    ba as Qa,
    bb as ne,
    dr as De,
    ds as rl,
    dt as Ka,
    du as la,
    dv as il,
    dw as Or,
    an as ol,
    dx as ca,
    dy as sl,
    dz as ll,
    a2 as cl,
    dA as ul,
    dB as dl,
    dC as hl,
    dD as fl,
    dE as vl,
    dF as pl,
    dG as dr,
    bf as ml,
    cJ as gl,
    dH as bl,
    cR as yl,
    bc as Ja,
    x as $a,
    dI as xl,
    a6 as wl,
    dJ as kl,
    bn as _l,
    $ as hr,
    cp as Ml,
    dK as Il
} from "./index.28e31dff.js";
import {
    G as qe
} from "./index.06a59a68.js";
import {
    h as Sl
} from "./enc-hex.afd532ef.js";
var Ar = {
    exports: {}
};
/*!
 * Chart.js v2.9.4
 * https://www.chartjs.org
 * (c) 2020 Chart.js Contributors
 * Released under the MIT License
 */
(function(g, b) {
    (function(s, d) {
        g.exports = d(function() {
            try {
                return require("moment")
            } catch (k) {}
        }())
    })(js, function(s) {
        s = s && s.hasOwnProperty("default") ? s.default : s;

        function d(e, t) {
            return t = {
                exports: {}
            }, e(t, t.exports), t.exports
        }

        function k(e) {
            return e && e.default || e
        }
        var y = {
                aliceblue: [240, 248, 255],
                antiquewhite: [250, 235, 215],
                aqua: [0, 255, 255],
                aquamarine: [127, 255, 212],
                azure: [240, 255, 255],
                beige: [245, 245, 220],
                bisque: [255, 228, 196],
                black: [0, 0, 0],
                blanchedalmond: [255, 235, 205],
                blue: [0, 0, 255],
                blueviolet: [138, 43, 226],
                brown: [165, 42, 42],
                burlywood: [222, 184, 135],
                cadetblue: [95, 158, 160],
                chartreuse: [127, 255, 0],
                chocolate: [210, 105, 30],
                coral: [255, 127, 80],
                cornflowerblue: [100, 149, 237],
                cornsilk: [255, 248, 220],
                crimson: [220, 20, 60],
                cyan: [0, 255, 255],
                darkblue: [0, 0, 139],
                darkcyan: [0, 139, 139],
                darkgoldenrod: [184, 134, 11],
                darkgray: [169, 169, 169],
                darkgreen: [0, 100, 0],
                darkgrey: [169, 169, 169],
                darkkhaki: [189, 183, 107],
                darkmagenta: [139, 0, 139],
                darkolivegreen: [85, 107, 47],
                darkorange: [255, 140, 0],
                darkorchid: [153, 50, 204],
                darkred: [139, 0, 0],
                darksalmon: [233, 150, 122],
                darkseagreen: [143, 188, 143],
                darkslateblue: [72, 61, 139],
                darkslategray: [47, 79, 79],
                darkslategrey: [47, 79, 79],
                darkturquoise: [0, 206, 209],
                darkviolet: [148, 0, 211],
                deeppink: [255, 20, 147],
                deepskyblue: [0, 191, 255],
                dimgray: [105, 105, 105],
                dimgrey: [105, 105, 105],
                dodgerblue: [30, 144, 255],
                firebrick: [178, 34, 34],
                floralwhite: [255, 250, 240],
                forestgreen: [34, 139, 34],
                fuchsia: [255, 0, 255],
                gainsboro: [220, 220, 220],
                ghostwhite: [248, 248, 255],
                gold: [255, 215, 0],
                goldenrod: [218, 165, 32],
                gray: [128, 128, 128],
                green: [0, 128, 0],
                greenyellow: [173, 255, 47],
                grey: [128, 128, 128],
                honeydew: [240, 255, 240],
                hotpink: [255, 105, 180],
                indianred: [205, 92, 92],
                indigo: [75, 0, 130],
                ivory: [255, 255, 240],
                khaki: [240, 230, 140],
                lavender: [230, 230, 250],
                lavenderblush: [255, 240, 245],
                lawngreen: [124, 252, 0],
                lemonchiffon: [255, 250, 205],
                lightblue: [173, 216, 230],
                lightcoral: [240, 128, 128],
                lightcyan: [224, 255, 255],
                lightgoldenrodyellow: [250, 250, 210],
                lightgray: [211, 211, 211],
                lightgreen: [144, 238, 144],
                lightgrey: [211, 211, 211],
                lightpink: [255, 182, 193],
                lightsalmon: [255, 160, 122],
                lightseagreen: [32, 178, 170],
                lightskyblue: [135, 206, 250],
                lightslategray: [119, 136, 153],
                lightslategrey: [119, 136, 153],
                lightsteelblue: [176, 196, 222],
                lightyellow: [255, 255, 224],
                lime: [0, 255, 0],
                limegreen: [50, 205, 50],
                linen: [250, 240, 230],
                magenta: [255, 0, 255],
                maroon: [128, 0, 0],
                mediumaquamarine: [102, 205, 170],
                mediumblue: [0, 0, 205],
                mediumorchid: [186, 85, 211],
                mediumpurple: [147, 112, 219],
                mediumseagreen: [60, 179, 113],
                mediumslateblue: [123, 104, 238],
                mediumspringgreen: [0, 250, 154],
                mediumturquoise: [72, 209, 204],
                mediumvioletred: [199, 21, 133],
                midnightblue: [25, 25, 112],
                mintcream: [245, 255, 250],
                mistyrose: [255, 228, 225],
                moccasin: [255, 228, 181],
                navajowhite: [255, 222, 173],
                navy: [0, 0, 128],
                oldlace: [253, 245, 230],
                olive: [128, 128, 0],
                olivedrab: [107, 142, 35],
                orange: [255, 165, 0],
                orangered: [255, 69, 0],
                orchid: [218, 112, 214],
                palegoldenrod: [238, 232, 170],
                palegreen: [152, 251, 152],
                paleturquoise: [175, 238, 238],
                palevioletred: [219, 112, 147],
                papayawhip: [255, 239, 213],
                peachpuff: [255, 218, 185],
                peru: [205, 133, 63],
                pink: [255, 192, 203],
                plum: [221, 160, 221],
                powderblue: [176, 224, 230],
                purple: [128, 0, 128],
                rebeccapurple: [102, 51, 153],
                red: [255, 0, 0],
                rosybrown: [188, 143, 143],
                royalblue: [65, 105, 225],
                saddlebrown: [139, 69, 19],
                salmon: [250, 128, 114],
                sandybrown: [244, 164, 96],
                seagreen: [46, 139, 87],
                seashell: [255, 245, 238],
                sienna: [160, 82, 45],
                silver: [192, 192, 192],
                skyblue: [135, 206, 235],
                slateblue: [106, 90, 205],
                slategray: [112, 128, 144],
                slategrey: [112, 128, 144],
                snow: [255, 250, 250],
                springgreen: [0, 255, 127],
                steelblue: [70, 130, 180],
                tan: [210, 180, 140],
                teal: [0, 128, 128],
                thistle: [216, 191, 216],
                tomato: [255, 99, 71],
                turquoise: [64, 224, 208],
                violet: [238, 130, 238],
                wheat: [245, 222, 179],
                white: [255, 255, 255],
                whitesmoke: [245, 245, 245],
                yellow: [255, 255, 0],
                yellowgreen: [154, 205, 50]
            },
            I = d(function(e) {
                var t = {};
                for (var a in y) y.hasOwnProperty(a) && (t[y[a]] = a);
                var n = e.exports = {
                    rgb: {
                        channels: 3,
                        labels: "rgb"
                    },
                    hsl: {
                        channels: 3,
                        labels: "hsl"
                    },
                    hsv: {
                        channels: 3,
                        labels: "hsv"
                    },
                    hwb: {
                        channels: 3,
                        labels: "hwb"
                    },
                    cmyk: {
                        channels: 4,
                        labels: "cmyk"
                    },
                    xyz: {
                        channels: 3,
                        labels: "xyz"
                    },
                    lab: {
                        channels: 3,
                        labels: "lab"
                    },
                    lch: {
                        channels: 3,
                        labels: "lch"
                    },
                    hex: {
                        channels: 1,
                        labels: ["hex"]
                    },
                    keyword: {
                        channels: 1,
                        labels: ["keyword"]
                    },
                    ansi16: {
                        channels: 1,
                        labels: ["ansi16"]
                    },
                    ansi256: {
                        channels: 1,
                        labels: ["ansi256"]
                    },
                    hcg: {
                        channels: 3,
                        labels: ["h", "c", "g"]
                    },
                    apple: {
                        channels: 3,
                        labels: ["r16", "g16", "b16"]
                    },
                    gray: {
                        channels: 1,
                        labels: ["gray"]
                    }
                };
                for (var r in n)
                    if (n.hasOwnProperty(r)) {
                        if (!("channels" in n[r])) throw new Error("missing channels property: " + r);
                        if (!("labels" in n[r])) throw new Error("missing channel labels property: " + r);
                        if (n[r].labels.length !== n[r].channels) throw new Error("channel and label counts mismatch: " + r);
                        var i = n[r].channels,
                            o = n[r].labels;
                        delete n[r].channels, delete n[r].labels, Object.defineProperty(n[r], "channels", {
                            value: i
                        }), Object.defineProperty(n[r], "labels", {
                            value: o
                        })
                    }
                n.rgb.hsl = function(l) {
                    var u = l[0] / 255,
                        h = l[1] / 255,
                        f = l[2] / 255,
                        p = Math.min(u, h, f),
                        x = Math.max(u, h, f),
                        w = x - p,
                        _, M, C;
                    return x === p ? _ = 0 : u === x ? _ = (h - f) / w : h === x ? _ = 2 + (f - u) / w : f === x && (_ = 4 + (u - h) / w), _ = Math.min(_ * 60, 360), _ < 0 && (_ += 360), C = (p + x) / 2, x === p ? M = 0 : C <= .5 ? M = w / (x + p) : M = w / (2 - x - p), [_, M * 100, C * 100]
                }, n.rgb.hsv = function(l) {
                    var u, h, f, p, x, w = l[0] / 255,
                        _ = l[1] / 255,
                        M = l[2] / 255,
                        C = Math.max(w, _, M),
                        T = C - Math.min(w, _, M),
                        N = function(W) {
                            return (C - W) / 6 / T + 1 / 2
                        };
                    return T === 0 ? p = x = 0 : (x = T / C, u = N(w), h = N(_), f = N(M), w === C ? p = f - h : _ === C ? p = 1 / 3 + u - f : M === C && (p = 2 / 3 + h - u), p < 0 ? p += 1 : p > 1 && (p -= 1)), [p * 360, x * 100, C * 100]
                }, n.rgb.hwb = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2],
                        p = n.rgb.hsl(l)[0],
                        x = 1 / 255 * Math.min(u, Math.min(h, f));
                    return f = 1 - 1 / 255 * Math.max(u, Math.max(h, f)), [p, x * 100, f * 100]
                }, n.rgb.cmyk = function(l) {
                    var u = l[0] / 255,
                        h = l[1] / 255,
                        f = l[2] / 255,
                        p, x, w, _;
                    return _ = Math.min(1 - u, 1 - h, 1 - f), p = (1 - u - _) / (1 - _) || 0, x = (1 - h - _) / (1 - _) || 0, w = (1 - f - _) / (1 - _) || 0, [p * 100, x * 100, w * 100, _ * 100]
                };

                function c(l, u) {
                    return Math.pow(l[0] - u[0], 2) + Math.pow(l[1] - u[1], 2) + Math.pow(l[2] - u[2], 2)
                }
                n.rgb.keyword = function(l) {
                    var u = t[l];
                    if (u) return u;
                    var h = 1 / 0,
                        f;
                    for (var p in y)
                        if (y.hasOwnProperty(p)) {
                            var x = y[p],
                                w = c(l, x);
                            w < h && (h = w, f = p)
                        }
                    return f
                }, n.keyword.rgb = function(l) {
                    return y[l]
                }, n.rgb.xyz = function(l) {
                    var u = l[0] / 255,
                        h = l[1] / 255,
                        f = l[2] / 255;
                    u = u > .04045 ? Math.pow((u + .055) / 1.055, 2.4) : u / 12.92, h = h > .04045 ? Math.pow((h + .055) / 1.055, 2.4) : h / 12.92, f = f > .04045 ? Math.pow((f + .055) / 1.055, 2.4) : f / 12.92;
                    var p = u * .4124 + h * .3576 + f * .1805,
                        x = u * .2126 + h * .7152 + f * .0722,
                        w = u * .0193 + h * .1192 + f * .9505;
                    return [p * 100, x * 100, w * 100]
                }, n.rgb.lab = function(l) {
                    var u = n.rgb.xyz(l),
                        h = u[0],
                        f = u[1],
                        p = u[2],
                        x, w, _;
                    return h /= 95.047, f /= 100, p /= 108.883, h = h > .008856 ? Math.pow(h, 1 / 3) : 7.787 * h + 16 / 116, f = f > .008856 ? Math.pow(f, 1 / 3) : 7.787 * f + 16 / 116, p = p > .008856 ? Math.pow(p, 1 / 3) : 7.787 * p + 16 / 116, x = 116 * f - 16, w = 500 * (h - f), _ = 200 * (f - p), [x, w, _]
                }, n.hsl.rgb = function(l) {
                    var u = l[0] / 360,
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p, x, w, _, M;
                    if (h === 0) return M = f * 255, [M, M, M];
                    f < .5 ? x = f * (1 + h) : x = f + h - f * h, p = 2 * f - x, _ = [0, 0, 0];
                    for (var C = 0; C < 3; C++) w = u + 1 / 3 * -(C - 1), w < 0 && w++, w > 1 && w--, 6 * w < 1 ? M = p + (x - p) * 6 * w : 2 * w < 1 ? M = x : 3 * w < 2 ? M = p + (x - p) * (2 / 3 - w) * 6 : M = p, _[C] = M * 255;
                    return _
                }, n.hsl.hsv = function(l) {
                    var u = l[0],
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p = h,
                        x = Math.max(f, .01),
                        w, _;
                    return f *= 2, h *= f <= 1 ? f : 2 - f, p *= x <= 1 ? x : 2 - x, _ = (f + h) / 2, w = f === 0 ? 2 * p / (x + p) : 2 * h / (f + h), [u, w * 100, _ * 100]
                }, n.hsv.rgb = function(l) {
                    var u = l[0] / 60,
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p = Math.floor(u) % 6,
                        x = u - Math.floor(u),
                        w = 255 * f * (1 - h),
                        _ = 255 * f * (1 - h * x),
                        M = 255 * f * (1 - h * (1 - x));
                    switch (f *= 255, p) {
                        case 0:
                            return [f, M, w];
                        case 1:
                            return [_, f, w];
                        case 2:
                            return [w, f, M];
                        case 3:
                            return [w, _, f];
                        case 4:
                            return [M, w, f];
                        case 5:
                            return [f, w, _]
                    }
                }, n.hsv.hsl = function(l) {
                    var u = l[0],
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p = Math.max(f, .01),
                        x, w, _;
                    return _ = (2 - h) * f, x = (2 - h) * p, w = h * p, w /= x <= 1 ? x : 2 - x, w = w || 0, _ /= 2, [u, w * 100, _ * 100]
                }, n.hwb.rgb = function(l) {
                    var u = l[0] / 360,
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p = h + f,
                        x, w, _, M;
                    p > 1 && (h /= p, f /= p), x = Math.floor(6 * u), w = 1 - f, _ = 6 * u - x, (x & 1) !== 0 && (_ = 1 - _), M = h + _ * (w - h);
                    var C, T, N;
                    switch (x) {
                        default:
                            case 6:
                            case 0:
                            C = w,
                        T = M,
                        N = h;
                        break;
                        case 1:
                                C = M,
                            T = w,
                            N = h;
                            break;
                        case 2:
                                C = h,
                            T = w,
                            N = M;
                            break;
                        case 3:
                                C = h,
                            T = M,
                            N = w;
                            break;
                        case 4:
                                C = M,
                            T = h,
                            N = w;
                            break;
                        case 5:
                                C = w,
                            T = h,
                            N = M;
                            break
                    }
                    return [C * 255, T * 255, N * 255]
                }, n.cmyk.rgb = function(l) {
                    var u = l[0] / 100,
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p = l[3] / 100,
                        x, w, _;
                    return x = 1 - Math.min(1, u * (1 - p) + p), w = 1 - Math.min(1, h * (1 - p) + p), _ = 1 - Math.min(1, f * (1 - p) + p), [x * 255, w * 255, _ * 255]
                }, n.xyz.rgb = function(l) {
                    var u = l[0] / 100,
                        h = l[1] / 100,
                        f = l[2] / 100,
                        p, x, w;
                    return p = u * 3.2406 + h * -1.5372 + f * -.4986, x = u * -.9689 + h * 1.8758 + f * .0415, w = u * .0557 + h * -.204 + f * 1.057, p = p > .0031308 ? 1.055 * Math.pow(p, 1 / 2.4) - .055 : p * 12.92, x = x > .0031308 ? 1.055 * Math.pow(x, 1 / 2.4) - .055 : x * 12.92, w = w > .0031308 ? 1.055 * Math.pow(w, 1 / 2.4) - .055 : w * 12.92, p = Math.min(Math.max(0, p), 1), x = Math.min(Math.max(0, x), 1), w = Math.min(Math.max(0, w), 1), [p * 255, x * 255, w * 255]
                }, n.xyz.lab = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2],
                        p, x, w;
                    return u /= 95.047, h /= 100, f /= 108.883, u = u > .008856 ? Math.pow(u, 1 / 3) : 7.787 * u + 16 / 116, h = h > .008856 ? Math.pow(h, 1 / 3) : 7.787 * h + 16 / 116, f = f > .008856 ? Math.pow(f, 1 / 3) : 7.787 * f + 16 / 116, p = 116 * h - 16, x = 500 * (u - h), w = 200 * (h - f), [p, x, w]
                }, n.lab.xyz = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2],
                        p, x, w;
                    x = (u + 16) / 116, p = h / 500 + x, w = x - f / 200;
                    var _ = Math.pow(x, 3),
                        M = Math.pow(p, 3),
                        C = Math.pow(w, 3);
                    return x = _ > .008856 ? _ : (x - 16 / 116) / 7.787, p = M > .008856 ? M : (p - 16 / 116) / 7.787, w = C > .008856 ? C : (w - 16 / 116) / 7.787, p *= 95.047, x *= 100, w *= 108.883, [p, x, w]
                }, n.lab.lch = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2],
                        p, x, w;
                    return p = Math.atan2(f, h), x = p * 360 / 2 / Math.PI, x < 0 && (x += 360), w = Math.sqrt(h * h + f * f), [u, w, x]
                }, n.lch.lab = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2],
                        p, x, w;
                    return w = f / 360 * 2 * Math.PI, p = h * Math.cos(w), x = h * Math.sin(w), [u, p, x]
                }, n.rgb.ansi16 = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2],
                        p = 1 in arguments ? arguments[1] : n.rgb.hsv(l)[2];
                    if (p = Math.round(p / 50), p === 0) return 30;
                    var x = 30 + (Math.round(f / 255) << 2 | Math.round(h / 255) << 1 | Math.round(u / 255));
                    return p === 2 && (x += 60), x
                }, n.hsv.ansi16 = function(l) {
                    return n.rgb.ansi16(n.hsv.rgb(l), l[2])
                }, n.rgb.ansi256 = function(l) {
                    var u = l[0],
                        h = l[1],
                        f = l[2];
                    if (u === h && h === f) return u < 8 ? 16 : u > 248 ? 231 : Math.round((u - 8) / 247 * 24) + 232;
                    var p = 16 + 36 * Math.round(u / 255 * 5) + 6 * Math.round(h / 255 * 5) + Math.round(f / 255 * 5);
                    return p
                }, n.ansi16.rgb = function(l) {
                    var u = l % 10;
                    if (u === 0 || u === 7) return l > 50 && (u += 3.5), u = u / 10.5 * 255, [u, u, u];
                    var h = (~~(l > 50) + 1) * .5,
                        f = (u & 1) * h * 255,
                        p = (u >> 1 & 1) * h * 255,
                        x = (u >> 2 & 1) * h * 255;
                    return [f, p, x]
                }, n.ansi256.rgb = function(l) {
                    if (l >= 232) {
                        var u = (l - 232) * 10 + 8;
                        return [u, u, u]
                    }
                    l -= 16;
                    var h, f = Math.floor(l / 36) / 5 * 255,
                        p = Math.floor((h = l % 36) / 6) / 5 * 255,
                        x = h % 6 / 5 * 255;
                    return [f, p, x]
                }, n.rgb.hex = function(l) {
                    var u = ((Math.round(l[0]) & 255) << 16) + ((Math.round(l[1]) & 255) << 8) + (Math.round(l[2]) & 255),
                        h = u.toString(16).toUpperCase();
                    return "000000".substring(h.length) + h
                }, n.hex.rgb = function(l) {
                    var u = l.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
                    if (!u) return [0, 0, 0];
                    var h = u[0];
                    u[0].length === 3 && (h = h.split("").map(function(_) {
                        return _ + _
                    }).join(""));
                    var f = parseInt(h, 16),
                        p = f >> 16 & 255,
                        x = f >> 8 & 255,
                        w = f & 255;
                    return [p, x, w]
                }, n.rgb.hcg = function(l) {
                    var u = l[0] / 255,
                        h = l[1] / 255,
                        f = l[2] / 255,
                        p = Math.max(Math.max(u, h), f),
                        x = Math.min(Math.min(u, h), f),
                        w = p - x,
                        _, M;
                    return w < 1 ? _ = x / (1 - w) : _ = 0, w <= 0 ? M = 0 : p === u ? M = (h - f) / w % 6 : p === h ? M = 2 + (f - u) / w : M = 4 + (u - h) / w + 4, M /= 6, M %= 1, [M * 360, w * 100, _ * 100]
                }, n.hsl.hcg = function(l) {
                    var u = l[1] / 100,
                        h = l[2] / 100,
                        f = 1,
                        p = 0;
                    return h < .5 ? f = 2 * u * h : f = 2 * u * (1 - h), f < 1 && (p = (h - .5 * f) / (1 - f)), [l[0], f * 100, p * 100]
                }, n.hsv.hcg = function(l) {
                    var u = l[1] / 100,
                        h = l[2] / 100,
                        f = u * h,
                        p = 0;
                    return f < 1 && (p = (h - f) / (1 - f)), [l[0], f * 100, p * 100]
                }, n.hcg.rgb = function(l) {
                    var u = l[0] / 360,
                        h = l[1] / 100,
                        f = l[2] / 100;
                    if (h === 0) return [f * 255, f * 255, f * 255];
                    var p = [0, 0, 0],
                        x = u % 1 * 6,
                        w = x % 1,
                        _ = 1 - w,
                        M = 0;
                    switch (Math.floor(x)) {
                        case 0:
                            p[0] = 1, p[1] = w, p[2] = 0;
                            break;
                        case 1:
                            p[0] = _, p[1] = 1, p[2] = 0;
                            break;
                        case 2:
                            p[0] = 0, p[1] = 1, p[2] = w;
                            break;
                        case 3:
                            p[0] = 0, p[1] = _, p[2] = 1;
                            break;
                        case 4:
                            p[0] = w, p[1] = 0, p[2] = 1;
                            break;
                        default:
                            p[0] = 1, p[1] = 0, p[2] = _
                    }
                    return M = (1 - h) * f, [(h * p[0] + M) * 255, (h * p[1] + M) * 255, (h * p[2] + M) * 255]
                }, n.hcg.hsv = function(l) {
                    var u = l[1] / 100,
                        h = l[2] / 100,
                        f = u + h * (1 - u),
                        p = 0;
                    return f > 0 && (p = u / f), [l[0], p * 100, f * 100]
                }, n.hcg.hsl = function(l) {
                    var u = l[1] / 100,
                        h = l[2] / 100,
                        f = h * (1 - u) + .5 * u,
                        p = 0;
                    return f > 0 && f < .5 ? p = u / (2 * f) : f >= .5 && f < 1 && (p = u / (2 * (1 - f))), [l[0], p * 100, f * 100]
                }, n.hcg.hwb = function(l) {
                    var u = l[1] / 100,
                        h = l[2] / 100,
                        f = u + h * (1 - u);
                    return [l[0], (f - u) * 100, (1 - f) * 100]
                }, n.hwb.hcg = function(l) {
                    var u = l[1] / 100,
                        h = l[2] / 100,
                        f = 1 - h,
                        p = f - u,
                        x = 0;
                    return p < 1 && (x = (f - p) / (1 - p)), [l[0], p * 100, x * 100]
                }, n.apple.rgb = function(l) {
                    return [l[0] / 65535 * 255, l[1] / 65535 * 255, l[2] / 65535 * 255]
                }, n.rgb.apple = function(l) {
                    return [l[0] / 255 * 65535, l[1] / 255 * 65535, l[2] / 255 * 65535]
                }, n.gray.rgb = function(l) {
                    return [l[0] / 100 * 255, l[0] / 100 * 255, l[0] / 100 * 255]
                }, n.gray.hsl = n.gray.hsv = function(l) {
                    return [0, 0, l[0]]
                }, n.gray.hwb = function(l) {
                    return [0, 100, l[0]]
                }, n.gray.cmyk = function(l) {
                    return [0, 0, 0, l[0]]
                }, n.gray.lab = function(l) {
                    return [l[0], 0, 0]
                }, n.gray.hex = function(l) {
                    var u = Math.round(l[0] / 100 * 255) & 255,
                        h = (u << 16) + (u << 8) + u,
                        f = h.toString(16).toUpperCase();
                    return "000000".substring(f.length) + f
                }, n.rgb.gray = function(l) {
                    var u = (l[0] + l[1] + l[2]) / 3;
                    return [u / 255 * 100]
                }
            });
        I.rgb, I.hsl, I.hsv, I.hwb, I.cmyk, I.xyz, I.lab, I.lch, I.hex, I.keyword, I.ansi16, I.ansi256, I.hcg, I.apple, I.gray;

        function P() {
            for (var e = {}, t = Object.keys(I), a = t.length, n = 0; n < a; n++) e[t[n]] = {
                distance: -1,
                parent: null
            };
            return e
        }

        function B(e) {
            var t = P(),
                a = [e];
            for (t[e].distance = 0; a.length;)
                for (var n = a.pop(), r = Object.keys(I[n]), i = r.length, o = 0; o < i; o++) {
                    var c = r[o],
                        l = t[c];
                    l.distance === -1 && (l.distance = t[n].distance + 1, l.parent = n, a.unshift(c))
                }
            return t
        }

        function L(e, t) {
            return function(a) {
                return t(e(a))
            }
        }

        function D(e, t) {
            for (var a = [t[e].parent, e], n = I[t[e].parent][e], r = t[e].parent; t[r].parent;) a.unshift(t[r].parent), n = L(I[t[r].parent][r], n), r = t[r].parent;
            return n.conversion = a, n
        }
        var z = function(e) {
                for (var t = B(e), a = {}, n = Object.keys(t), r = n.length, i = 0; i < r; i++) {
                    var o = n[i],
                        c = t[o];
                    c.parent !== null && (a[o] = D(o, t))
                }
                return a
            },
            X = {},
            xe = Object.keys(I);

        function Pe(e) {
            var t = function(a) {
                return a == null ? a : (arguments.length > 1 && (a = Array.prototype.slice.call(arguments)), e(a))
            };
            return "conversion" in e && (t.conversion = e.conversion), t
        }

        function oe(e) {
            var t = function(a) {
                if (a == null) return a;
                arguments.length > 1 && (a = Array.prototype.slice.call(arguments));
                var n = e(a);
                if (typeof n == "object")
                    for (var r = n.length, i = 0; i < r; i++) n[i] = Math.round(n[i]);
                return n
            };
            return "conversion" in e && (t.conversion = e.conversion), t
        }
        xe.forEach(function(e) {
            X[e] = {}, Object.defineProperty(X[e], "channels", {
                value: I[e].channels
            }), Object.defineProperty(X[e], "labels", {
                value: I[e].labels
            });
            var t = z(e),
                a = Object.keys(t);
            a.forEach(function(n) {
                var r = t[n];
                X[e][n] = oe(r), X[e][n].raw = Pe(r)
            })
        });
        var ce = X,
            Be = {
                aliceblue: [240, 248, 255],
                antiquewhite: [250, 235, 215],
                aqua: [0, 255, 255],
                aquamarine: [127, 255, 212],
                azure: [240, 255, 255],
                beige: [245, 245, 220],
                bisque: [255, 228, 196],
                black: [0, 0, 0],
                blanchedalmond: [255, 235, 205],
                blue: [0, 0, 255],
                blueviolet: [138, 43, 226],
                brown: [165, 42, 42],
                burlywood: [222, 184, 135],
                cadetblue: [95, 158, 160],
                chartreuse: [127, 255, 0],
                chocolate: [210, 105, 30],
                coral: [255, 127, 80],
                cornflowerblue: [100, 149, 237],
                cornsilk: [255, 248, 220],
                crimson: [220, 20, 60],
                cyan: [0, 255, 255],
                darkblue: [0, 0, 139],
                darkcyan: [0, 139, 139],
                darkgoldenrod: [184, 134, 11],
                darkgray: [169, 169, 169],
                darkgreen: [0, 100, 0],
                darkgrey: [169, 169, 169],
                darkkhaki: [189, 183, 107],
                darkmagenta: [139, 0, 139],
                darkolivegreen: [85, 107, 47],
                darkorange: [255, 140, 0],
                darkorchid: [153, 50, 204],
                darkred: [139, 0, 0],
                darksalmon: [233, 150, 122],
                darkseagreen: [143, 188, 143],
                darkslateblue: [72, 61, 139],
                darkslategray: [47, 79, 79],
                darkslategrey: [47, 79, 79],
                darkturquoise: [0, 206, 209],
                darkviolet: [148, 0, 211],
                deeppink: [255, 20, 147],
                deepskyblue: [0, 191, 255],
                dimgray: [105, 105, 105],
                dimgrey: [105, 105, 105],
                dodgerblue: [30, 144, 255],
                firebrick: [178, 34, 34],
                floralwhite: [255, 250, 240],
                forestgreen: [34, 139, 34],
                fuchsia: [255, 0, 255],
                gainsboro: [220, 220, 220],
                ghostwhite: [248, 248, 255],
                gold: [255, 215, 0],
                goldenrod: [218, 165, 32],
                gray: [128, 128, 128],
                green: [0, 128, 0],
                greenyellow: [173, 255, 47],
                grey: [128, 128, 128],
                honeydew: [240, 255, 240],
                hotpink: [255, 105, 180],
                indianred: [205, 92, 92],
                indigo: [75, 0, 130],
                ivory: [255, 255, 240],
                khaki: [240, 230, 140],
                lavender: [230, 230, 250],
                lavenderblush: [255, 240, 245],
                lawngreen: [124, 252, 0],
                lemonchiffon: [255, 250, 205],
                lightblue: [173, 216, 230],
                lightcoral: [240, 128, 128],
                lightcyan: [224, 255, 255],
                lightgoldenrodyellow: [250, 250, 210],
                lightgray: [211, 211, 211],
                lightgreen: [144, 238, 144],
                lightgrey: [211, 211, 211],
                lightpink: [255, 182, 193],
                lightsalmon: [255, 160, 122],
                lightseagreen: [32, 178, 170],
                lightskyblue: [135, 206, 250],
                lightslategray: [119, 136, 153],
                lightslategrey: [119, 136, 153],
                lightsteelblue: [176, 196, 222],
                lightyellow: [255, 255, 224],
                lime: [0, 255, 0],
                limegreen: [50, 205, 50],
                linen: [250, 240, 230],
                magenta: [255, 0, 255],
                maroon: [128, 0, 0],
                mediumaquamarine: [102, 205, 170],
                mediumblue: [0, 0, 205],
                mediumorchid: [186, 85, 211],
                mediumpurple: [147, 112, 219],
                mediumseagreen: [60, 179, 113],
                mediumslateblue: [123, 104, 238],
                mediumspringgreen: [0, 250, 154],
                mediumturquoise: [72, 209, 204],
                mediumvioletred: [199, 21, 133],
                midnightblue: [25, 25, 112],
                mintcream: [245, 255, 250],
                mistyrose: [255, 228, 225],
                moccasin: [255, 228, 181],
                navajowhite: [255, 222, 173],
                navy: [0, 0, 128],
                oldlace: [253, 245, 230],
                olive: [128, 128, 0],
                olivedrab: [107, 142, 35],
                orange: [255, 165, 0],
                orangered: [255, 69, 0],
                orchid: [218, 112, 214],
                palegoldenrod: [238, 232, 170],
                palegreen: [152, 251, 152],
                paleturquoise: [175, 238, 238],
                palevioletred: [219, 112, 147],
                papayawhip: [255, 239, 213],
                peachpuff: [255, 218, 185],
                peru: [205, 133, 63],
                pink: [255, 192, 203],
                plum: [221, 160, 221],
                powderblue: [176, 224, 230],
                purple: [128, 0, 128],
                rebeccapurple: [102, 51, 153],
                red: [255, 0, 0],
                rosybrown: [188, 143, 143],
                royalblue: [65, 105, 225],
                saddlebrown: [139, 69, 19],
                salmon: [250, 128, 114],
                sandybrown: [244, 164, 96],
                seagreen: [46, 139, 87],
                seashell: [255, 245, 238],
                sienna: [160, 82, 45],
                silver: [192, 192, 192],
                skyblue: [135, 206, 235],
                slateblue: [106, 90, 205],
                slategray: [112, 128, 144],
                slategrey: [112, 128, 144],
                snow: [255, 250, 250],
                springgreen: [0, 255, 127],
                steelblue: [70, 130, 180],
                tan: [210, 180, 140],
                teal: [0, 128, 128],
                thistle: [216, 191, 216],
                tomato: [255, 99, 71],
                turquoise: [64, 224, 208],
                violet: [238, 130, 238],
                wheat: [245, 222, 179],
                white: [255, 255, 255],
                whitesmoke: [245, 245, 245],
                yellow: [255, 255, 0],
                yellowgreen: [154, 205, 50]
            },
            re = {
                getRgba: Te,
                getHsla: Re,
                getRgb: $r,
                getHsl: qr,
                getHwb: Ze,
                getAlpha: Ur,
                hexString: Yr,
                rgbString: Xr,
                rgbaString: en,
                percentString: Kr,
                percentaString: tn,
                hslString: Jr,
                hslaString: an,
                hwbString: Zr,
                keyword: Qr
            };

        function Te(e) {
            if (!!e) {
                var t = /^#([a-fA-F0-9]{3,4})$/i,
                    a = /^#([a-fA-F0-9]{6}([a-fA-F0-9]{2})?)$/i,
                    n = /^rgba?\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/i,
                    r = /^rgba?\(\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/i,
                    i = /(\w+)/,
                    o = [0, 0, 0],
                    c = 1,
                    l = e.match(t),
                    u = "";
                if (l) {
                    l = l[1], u = l[3];
                    for (var h = 0; h < o.length; h++) o[h] = parseInt(l[h] + l[h], 16);
                    u && (c = Math.round(parseInt(u + u, 16) / 255 * 100) / 100)
                } else if (l = e.match(a)) {
                    u = l[2], l = l[1];
                    for (var h = 0; h < o.length; h++) o[h] = parseInt(l.slice(h * 2, h * 2 + 2), 16);
                    u && (c = Math.round(parseInt(u, 16) / 255 * 100) / 100)
                } else if (l = e.match(n)) {
                    for (var h = 0; h < o.length; h++) o[h] = parseInt(l[h + 1]);
                    c = parseFloat(l[4])
                } else if (l = e.match(r)) {
                    for (var h = 0; h < o.length; h++) o[h] = Math.round(parseFloat(l[h + 1]) * 2.55);
                    c = parseFloat(l[4])
                } else if (l = e.match(i)) {
                    if (l[1] == "transparent") return [0, 0, 0, 0];
                    if (o = Be[l[1]], !o) return
                }
                for (var h = 0; h < o.length; h++) o[h] = Fe(o[h], 0, 255);
                return !c && c != 0 ? c = 1 : c = Fe(c, 0, 1), o[3] = c, o
            }
        }

        function Re(e) {
            if (!!e) {
                var t = /^hsla?\(\s*([+-]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)/,
                    a = e.match(t);
                if (a) {
                    var n = parseFloat(a[4]),
                        r = Fe(parseInt(a[1]), 0, 360),
                        i = Fe(parseFloat(a[2]), 0, 100),
                        o = Fe(parseFloat(a[3]), 0, 100),
                        c = Fe(isNaN(n) ? 1 : n, 0, 1);
                    return [r, i, o, c]
                }
            }
        }

        function Ze(e) {
            if (!!e) {
                var t = /^hwb\(\s*([+-]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)/,
                    a = e.match(t);
                if (a) {
                    var n = parseFloat(a[4]),
                        r = Fe(parseInt(a[1]), 0, 360),
                        i = Fe(parseFloat(a[2]), 0, 100),
                        o = Fe(parseFloat(a[3]), 0, 100),
                        c = Fe(isNaN(n) ? 1 : n, 0, 1);
                    return [r, i, o, c]
                }
            }
        }

        function $r(e) {
            var t = Te(e);
            return t && t.slice(0, 3)
        }

        function qr(e) {
            var t = Re(e);
            return t && t.slice(0, 3)
        }

        function Ur(e) {
            var t = Te(e);
            if (t) return t[3];
            if (t = Re(e)) return t[3];
            if (t = Ze(e)) return t[3]
        }

        function Yr(e, a) {
            var a = a !== void 0 && e.length === 3 ? a : e[3];
            return "#" + Wt(e[0]) + Wt(e[1]) + Wt(e[2]) + (a >= 0 && a < 1 ? Wt(Math.round(a * 255)) : "")
        }

        function Xr(e, t) {
            return t < 1 || e[3] && e[3] < 1 ? en(e, t) : "rgb(" + e[0] + ", " + e[1] + ", " + e[2] + ")"
        }

        function en(e, t) {
            return t === void 0 && (t = e[3] !== void 0 ? e[3] : 1), "rgba(" + e[0] + ", " + e[1] + ", " + e[2] + ", " + t + ")"
        }

        function Kr(e, t) {
            if (t < 1 || e[3] && e[3] < 1) return tn(e, t);
            var a = Math.round(e[0] / 255 * 100),
                n = Math.round(e[1] / 255 * 100),
                r = Math.round(e[2] / 255 * 100);
            return "rgb(" + a + "%, " + n + "%, " + r + "%)"
        }

        function tn(e, t) {
            var a = Math.round(e[0] / 255 * 100),
                n = Math.round(e[1] / 255 * 100),
                r = Math.round(e[2] / 255 * 100);
            return "rgba(" + a + "%, " + n + "%, " + r + "%, " + (t || e[3] || 1) + ")"
        }

        function Jr(e, t) {
            return t < 1 || e[3] && e[3] < 1 ? an(e, t) : "hsl(" + e[0] + ", " + e[1] + "%, " + e[2] + "%)"
        }

        function an(e, t) {
            return t === void 0 && (t = e[3] !== void 0 ? e[3] : 1), "hsla(" + e[0] + ", " + e[1] + "%, " + e[2] + "%, " + t + ")"
        }

        function Zr(e, t) {
            return t === void 0 && (t = e[3] !== void 0 ? e[3] : 1), "hwb(" + e[0] + ", " + e[1] + "%, " + e[2] + "%" + (t !== void 0 && t !== 1 ? ", " + t : "") + ")"
        }

        function Qr(e) {
            return nn[e.slice(0, 3)]
        }

        function Fe(e, t, a) {
            return Math.min(Math.max(t, e), a)
        }

        function Wt(e) {
            var t = e.toString(16).toUpperCase();
            return t.length < 2 ? "0" + t : t
        }
        var nn = {};
        for (var rn in Be) nn[Be[rn]] = rn;
        var we = function(e) {
            if (e instanceof we) return e;
            if (!(this instanceof we)) return new we(e);
            this.valid = !1, this.values = {
                rgb: [0, 0, 0],
                hsl: [0, 0, 0],
                hsv: [0, 0, 0],
                hwb: [0, 0, 0],
                cmyk: [0, 0, 0, 0],
                alpha: 1
            };
            var t;
            typeof e == "string" ? (t = re.getRgba(e), t ? this.setValues("rgb", t) : (t = re.getHsla(e)) ? this.setValues("hsl", t) : (t = re.getHwb(e)) && this.setValues("hwb", t)) : typeof e == "object" && (t = e, t.r !== void 0 || t.red !== void 0 ? this.setValues("rgb", t) : t.l !== void 0 || t.lightness !== void 0 ? this.setValues("hsl", t) : t.v !== void 0 || t.value !== void 0 ? this.setValues("hsv", t) : t.w !== void 0 || t.whiteness !== void 0 ? this.setValues("hwb", t) : (t.c !== void 0 || t.cyan !== void 0) && this.setValues("cmyk", t))
        };
        we.prototype = {
            isValid: function() {
                return this.valid
            },
            rgb: function() {
                return this.setSpace("rgb", arguments)
            },
            hsl: function() {
                return this.setSpace("hsl", arguments)
            },
            hsv: function() {
                return this.setSpace("hsv", arguments)
            },
            hwb: function() {
                return this.setSpace("hwb", arguments)
            },
            cmyk: function() {
                return this.setSpace("cmyk", arguments)
            },
            rgbArray: function() {
                return this.values.rgb
            },
            hslArray: function() {
                return this.values.hsl
            },
            hsvArray: function() {
                return this.values.hsv
            },
            hwbArray: function() {
                var e = this.values;
                return e.alpha !== 1 ? e.hwb.concat([e.alpha]) : e.hwb
            },
            cmykArray: function() {
                return this.values.cmyk
            },
            rgbaArray: function() {
                var e = this.values;
                return e.rgb.concat([e.alpha])
            },
            hslaArray: function() {
                var e = this.values;
                return e.hsl.concat([e.alpha])
            },
            alpha: function(e) {
                return e === void 0 ? this.values.alpha : (this.setValues("alpha", e), this)
            },
            red: function(e) {
                return this.setChannel("rgb", 0, e)
            },
            green: function(e) {
                return this.setChannel("rgb", 1, e)
            },
            blue: function(e) {
                return this.setChannel("rgb", 2, e)
            },
            hue: function(e) {
                return e && (e %= 360, e = e < 0 ? 360 + e : e), this.setChannel("hsl", 0, e)
            },
            saturation: function(e) {
                return this.setChannel("hsl", 1, e)
            },
            lightness: function(e) {
                return this.setChannel("hsl", 2, e)
            },
            saturationv: function(e) {
                return this.setChannel("hsv", 1, e)
            },
            whiteness: function(e) {
                return this.setChannel("hwb", 1, e)
            },
            blackness: function(e) {
                return this.setChannel("hwb", 2, e)
            },
            value: function(e) {
                return this.setChannel("hsv", 2, e)
            },
            cyan: function(e) {
                return this.setChannel("cmyk", 0, e)
            },
            magenta: function(e) {
                return this.setChannel("cmyk", 1, e)
            },
            yellow: function(e) {
                return this.setChannel("cmyk", 2, e)
            },
            black: function(e) {
                return this.setChannel("cmyk", 3, e)
            },
            hexString: function() {
                return re.hexString(this.values.rgb)
            },
            rgbString: function() {
                return re.rgbString(this.values.rgb, this.values.alpha)
            },
            rgbaString: function() {
                return re.rgbaString(this.values.rgb, this.values.alpha)
            },
            percentString: function() {
                return re.percentString(this.values.rgb, this.values.alpha)
            },
            hslString: function() {
                return re.hslString(this.values.hsl, this.values.alpha)
            },
            hslaString: function() {
                return re.hslaString(this.values.hsl, this.values.alpha)
            },
            hwbString: function() {
                return re.hwbString(this.values.hwb, this.values.alpha)
            },
            keyword: function() {
                return re.keyword(this.values.rgb, this.values.alpha)
            },
            rgbNumber: function() {
                var e = this.values.rgb;
                return e[0] << 16 | e[1] << 8 | e[2]
            },
            luminosity: function() {
                for (var e = this.values.rgb, t = [], a = 0; a < e.length; a++) {
                    var n = e[a] / 255;
                    t[a] = n <= .03928 ? n / 12.92 : Math.pow((n + .055) / 1.055, 2.4)
                }
                return .2126 * t[0] + .7152 * t[1] + .0722 * t[2]
            },
            contrast: function(e) {
                var t = this.luminosity(),
                    a = e.luminosity();
                return t > a ? (t + .05) / (a + .05) : (a + .05) / (t + .05)
            },
            level: function(e) {
                var t = this.contrast(e);
                return t >= 7.1 ? "AAA" : t >= 4.5 ? "AA" : ""
            },
            dark: function() {
                var e = this.values.rgb,
                    t = (e[0] * 299 + e[1] * 587 + e[2] * 114) / 1e3;
                return t < 128
            },
            light: function() {
                return !this.dark()
            },
            negate: function() {
                for (var e = [], t = 0; t < 3; t++) e[t] = 255 - this.values.rgb[t];
                return this.setValues("rgb", e), this
            },
            lighten: function(e) {
                var t = this.values.hsl;
                return t[2] += t[2] * e, this.setValues("hsl", t), this
            },
            darken: function(e) {
                var t = this.values.hsl;
                return t[2] -= t[2] * e, this.setValues("hsl", t), this
            },
            saturate: function(e) {
                var t = this.values.hsl;
                return t[1] += t[1] * e, this.setValues("hsl", t), this
            },
            desaturate: function(e) {
                var t = this.values.hsl;
                return t[1] -= t[1] * e, this.setValues("hsl", t), this
            },
            whiten: function(e) {
                var t = this.values.hwb;
                return t[1] += t[1] * e, this.setValues("hwb", t), this
            },
            blacken: function(e) {
                var t = this.values.hwb;
                return t[2] += t[2] * e, this.setValues("hwb", t), this
            },
            greyscale: function() {
                var e = this.values.rgb,
                    t = e[0] * .3 + e[1] * .59 + e[2] * .11;
                return this.setValues("rgb", [t, t, t]), this
            },
            clearer: function(e) {
                var t = this.values.alpha;
                return this.setValues("alpha", t - t * e), this
            },
            opaquer: function(e) {
                var t = this.values.alpha;
                return this.setValues("alpha", t + t * e), this
            },
            rotate: function(e) {
                var t = this.values.hsl,
                    a = (t[0] + e) % 360;
                return t[0] = a < 0 ? 360 + a : a, this.setValues("hsl", t), this
            },
            mix: function(e, t) {
                var a = this,
                    n = e,
                    r = t === void 0 ? .5 : t,
                    i = 2 * r - 1,
                    o = a.alpha() - n.alpha(),
                    c = ((i * o === -1 ? i : (i + o) / (1 + i * o)) + 1) / 2,
                    l = 1 - c;
                return this.rgb(c * a.red() + l * n.red(), c * a.green() + l * n.green(), c * a.blue() + l * n.blue()).alpha(a.alpha() * r + n.alpha() * (1 - r))
            },
            toJSON: function() {
                return this.rgb()
            },
            clone: function() {
                var e = new we,
                    t = this.values,
                    a = e.values,
                    n, r;
                for (var i in t) t.hasOwnProperty(i) && (n = t[i], r = {}.toString.call(n), r === "[object Array]" ? a[i] = n.slice(0) : r === "[object Number]" ? a[i] = n : console.error("unexpected color value:", n));
                return e
            }
        }, we.prototype.spaces = {
            rgb: ["red", "green", "blue"],
            hsl: ["hue", "saturation", "lightness"],
            hsv: ["hue", "saturation", "value"],
            hwb: ["hue", "whiteness", "blackness"],
            cmyk: ["cyan", "magenta", "yellow", "black"]
        }, we.prototype.maxes = {
            rgb: [255, 255, 255],
            hsl: [360, 100, 100],
            hsv: [360, 100, 100],
            hwb: [360, 100, 100],
            cmyk: [100, 100, 100, 100]
        }, we.prototype.getValues = function(e) {
            for (var t = this.values, a = {}, n = 0; n < e.length; n++) a[e.charAt(n)] = t[e][n];
            return t.alpha !== 1 && (a.a = t.alpha), a
        }, we.prototype.setValues = function(e, t) {
            var a = this.values,
                n = this.spaces,
                r = this.maxes,
                i = 1,
                o;
            if (this.valid = !0, e === "alpha") i = t;
            else if (t.length) a[e] = t.slice(0, e.length), i = t[e.length];
            else if (t[e.charAt(0)] !== void 0) {
                for (o = 0; o < e.length; o++) a[e][o] = t[e.charAt(o)];
                i = t.a
            } else if (t[n[e][0]] !== void 0) {
                var c = n[e];
                for (o = 0; o < e.length; o++) a[e][o] = t[c[o]];
                i = t.alpha
            }
            if (a.alpha = Math.max(0, Math.min(1, i === void 0 ? a.alpha : i)), e === "alpha") return !1;
            var l;
            for (o = 0; o < e.length; o++) l = Math.max(0, Math.min(r[e][o], a[e][o])), a[e][o] = Math.round(l);
            for (var u in n) u !== e && (a[u] = ce[e][u](a[e]));
            return !0
        }, we.prototype.setSpace = function(e, t) {
            var a = t[0];
            return a === void 0 ? this.getValues(e) : (typeof a == "number" && (a = Array.prototype.slice.call(t)), this.setValues(e, a), this)
        }, we.prototype.setChannel = function(e, t, a) {
            var n = this.values[e];
            return a === void 0 ? n[t] : a === n[t] ? this : (n[t] = a, this.setValues(e, n), this)
        }, typeof window < "u" && (window.Color = we);
        var jt = we;

        function on(e) {
            return ["__proto__", "prototype", "constructor"].indexOf(e) === -1
        }
        var V = {
                noop: function() {},
                uid: function() {
                    var e = 0;
                    return function() {
                        return e++
                    }
                }(),
                isNullOrUndef: function(e) {
                    return e === null || typeof e > "u"
                },
                isArray: function(e) {
                    if (Array.isArray && Array.isArray(e)) return !0;
                    var t = Object.prototype.toString.call(e);
                    return t.substr(0, 7) === "[object" && t.substr(-6) === "Array]"
                },
                isObject: function(e) {
                    return e !== null && Object.prototype.toString.call(e) === "[object Object]"
                },
                isFinite: function(e) {
                    return (typeof e == "number" || e instanceof Number) && isFinite(e)
                },
                valueOrDefault: function(e, t) {
                    return typeof e > "u" ? t : e
                },
                valueAtIndexOrDefault: function(e, t, a) {
                    return V.valueOrDefault(V.isArray(e) ? e[t] : e, a)
                },
                callback: function(e, t, a) {
                    if (e && typeof e.call == "function") return e.apply(a, t)
                },
                each: function(e, t, a, n) {
                    var r, i, o;
                    if (V.isArray(e))
                        if (i = e.length, n)
                            for (r = i - 1; r >= 0; r--) t.call(a, e[r], r);
                        else
                            for (r = 0; r < i; r++) t.call(a, e[r], r);
                    else if (V.isObject(e))
                        for (o = Object.keys(e), i = o.length, r = 0; r < i; r++) t.call(a, e[o[r]], o[r])
                },
                arrayEquals: function(e, t) {
                    var a, n, r, i;
                    if (!e || !t || e.length !== t.length) return !1;
                    for (a = 0, n = e.length; a < n; ++a)
                        if (r = e[a], i = t[a], r instanceof Array && i instanceof Array) {
                            if (!V.arrayEquals(r, i)) return !1
                        } else if (r !== i) return !1;
                    return !0
                },
                clone: function(e) {
                    if (V.isArray(e)) return e.map(V.clone);
                    if (V.isObject(e)) {
                        for (var t = Object.create(e), a = Object.keys(e), n = a.length, r = 0; r < n; ++r) t[a[r]] = V.clone(e[a[r]]);
                        return t
                    }
                    return e
                },
                _merger: function(e, t, a, n) {
                    if (!!on(e)) {
                        var r = t[e],
                            i = a[e];
                        V.isObject(r) && V.isObject(i) ? V.merge(r, i, n) : t[e] = V.clone(i)
                    }
                },
                _mergerIf: function(e, t, a) {
                    if (!!on(e)) {
                        var n = t[e],
                            r = a[e];
                        V.isObject(n) && V.isObject(r) ? V.mergeIf(n, r) : t.hasOwnProperty(e) || (t[e] = V.clone(r))
                    }
                },
                merge: function(e, t, a) {
                    var n = V.isArray(t) ? t : [t],
                        r = n.length,
                        i, o, c, l, u;
                    if (!V.isObject(e)) return e;
                    for (a = a || {}, i = a.merger || V._merger, o = 0; o < r; ++o)
                        if (t = n[o], !!V.isObject(t))
                            for (c = Object.keys(t), u = 0, l = c.length; u < l; ++u) i(c[u], e, t, a);
                    return e
                },
                mergeIf: function(e, t) {
                    return V.merge(e, t, {
                        merger: V._mergerIf
                    })
                },
                extend: Object.assign || function(e) {
                    return V.merge(e, [].slice.call(arguments, 1), {
                        merger: function(t, a, n) {
                            a[t] = n[t]
                        }
                    })
                },
                inherits: function(e) {
                    var t = this,
                        a = e && e.hasOwnProperty("constructor") ? e.constructor : function() {
                            return t.apply(this, arguments)
                        },
                        n = function() {
                            this.constructor = a
                        };
                    return n.prototype = t.prototype, a.prototype = new n, a.extend = V.inherits, e && V.extend(a.prototype, e), a.__super__ = t.prototype, a
                },
                _deprecated: function(e, t, a, n) {
                    t !== void 0 && console.warn(e + ': "' + a + '" is deprecated. Please use "' + n + '" instead')
                }
            },
            _e = V;
        V.callCallback = V.callback, V.indexOf = function(e, t, a) {
            return Array.prototype.indexOf.call(e, t, a)
        }, V.getValueOrDefault = V.valueOrDefault, V.getValueAtIndexOrDefault = V.valueAtIndexOrDefault;
        var _t = {
                linear: function(e) {
                    return e
                },
                easeInQuad: function(e) {
                    return e * e
                },
                easeOutQuad: function(e) {
                    return -e * (e - 2)
                },
                easeInOutQuad: function(e) {
                    return (e /= .5) < 1 ? .5 * e * e : -.5 * (--e * (e - 2) - 1)
                },
                easeInCubic: function(e) {
                    return e * e * e
                },
                easeOutCubic: function(e) {
                    return (e = e - 1) * e * e + 1
                },
                easeInOutCubic: function(e) {
                    return (e /= .5) < 1 ? .5 * e * e * e : .5 * ((e -= 2) * e * e + 2)
                },
                easeInQuart: function(e) {
                    return e * e * e * e
                },
                easeOutQuart: function(e) {
                    return -((e = e - 1) * e * e * e - 1)
                },
                easeInOutQuart: function(e) {
                    return (e /= .5) < 1 ? .5 * e * e * e * e : -.5 * ((e -= 2) * e * e * e - 2)
                },
                easeInQuint: function(e) {
                    return e * e * e * e * e
                },
                easeOutQuint: function(e) {
                    return (e = e - 1) * e * e * e * e + 1
                },
                easeInOutQuint: function(e) {
                    return (e /= .5) < 1 ? .5 * e * e * e * e * e : .5 * ((e -= 2) * e * e * e * e + 2)
                },
                easeInSine: function(e) {
                    return -Math.cos(e * (Math.PI / 2)) + 1
                },
                easeOutSine: function(e) {
                    return Math.sin(e * (Math.PI / 2))
                },
                easeInOutSine: function(e) {
                    return -.5 * (Math.cos(Math.PI * e) - 1)
                },
                easeInExpo: function(e) {
                    return e === 0 ? 0 : Math.pow(2, 10 * (e - 1))
                },
                easeOutExpo: function(e) {
                    return e === 1 ? 1 : -Math.pow(2, -10 * e) + 1
                },
                easeInOutExpo: function(e) {
                    return e === 0 ? 0 : e === 1 ? 1 : (e /= .5) < 1 ? .5 * Math.pow(2, 10 * (e - 1)) : .5 * (-Math.pow(2, -10 * --e) + 2)
                },
                easeInCirc: function(e) {
                    return e >= 1 ? e : -(Math.sqrt(1 - e * e) - 1)
                },
                easeOutCirc: function(e) {
                    return Math.sqrt(1 - (e = e - 1) * e)
                },
                easeInOutCirc: function(e) {
                    return (e /= .5) < 1 ? -.5 * (Math.sqrt(1 - e * e) - 1) : .5 * (Math.sqrt(1 - (e -= 2) * e) + 1)
                },
                easeInElastic: function(e) {
                    var t = 1.70158,
                        a = 0,
                        n = 1;
                    return e === 0 ? 0 : e === 1 ? 1 : (a || (a = .3), t = a / (2 * Math.PI) * Math.asin(1 / n), -(n * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / a)))
                },
                easeOutElastic: function(e) {
                    var t = 1.70158,
                        a = 0,
                        n = 1;
                    return e === 0 ? 0 : e === 1 ? 1 : (a || (a = .3), t = a / (2 * Math.PI) * Math.asin(1 / n), n * Math.pow(2, -10 * e) * Math.sin((e - t) * (2 * Math.PI) / a) + 1)
                },
                easeInOutElastic: function(e) {
                    var t = 1.70158,
                        a = 0,
                        n = 1;
                    return e === 0 ? 0 : (e /= .5) === 2 ? 1 : (a || (a = .45), t = a / (2 * Math.PI) * Math.asin(1 / n), e < 1 ? -.5 * (n * Math.pow(2, 10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / a)) : n * Math.pow(2, -10 * (e -= 1)) * Math.sin((e - t) * (2 * Math.PI) / a) * .5 + 1)
                },
                easeInBack: function(e) {
                    var t = 1.70158;
                    return e * e * ((t + 1) * e - t)
                },
                easeOutBack: function(e) {
                    var t = 1.70158;
                    return (e = e - 1) * e * ((t + 1) * e + t) + 1
                },
                easeInOutBack: function(e) {
                    var t = 1.70158;
                    return (e /= .5) < 1 ? .5 * (e * e * (((t *= 1.525) + 1) * e - t)) : .5 * ((e -= 2) * e * (((t *= 1.525) + 1) * e + t) + 2)
                },
                easeInBounce: function(e) {
                    return 1 - _t.easeOutBounce(1 - e)
                },
                easeOutBounce: function(e) {
                    return e < 1 / 2.75 ? 7.5625 * e * e : e < 2 / 2.75 ? 7.5625 * (e -= 1.5 / 2.75) * e + .75 : e < 2.5 / 2.75 ? 7.5625 * (e -= 2.25 / 2.75) * e + .9375 : 7.5625 * (e -= 2.625 / 2.75) * e + .984375
                },
                easeInOutBounce: function(e) {
                    return e < .5 ? _t.easeInBounce(e * 2) * .5 : _t.easeOutBounce(e * 2 - 1) * .5 + .5
                }
            },
            ei = {
                effects: _t
            };
        _e.easingEffects = _t;
        var ve = Math.PI,
            ti = ve / 180,
            ai = ve * 2,
            Me = ve / 2,
            Mt = ve / 4,
            sn = ve * 2 / 3,
            Ht = {
                clear: function(e) {
                    e.ctx.clearRect(0, 0, e.width, e.height)
                },
                roundedRect: function(e, t, a, n, r, i) {
                    if (i) {
                        var o = Math.min(i, r / 2, n / 2),
                            c = t + o,
                            l = a + o,
                            u = t + n - o,
                            h = a + r - o;
                        e.moveTo(t, l), c < u && l < h ? (e.arc(c, l, o, -ve, -Me), e.arc(u, l, o, -Me, 0), e.arc(u, h, o, 0, Me), e.arc(c, h, o, Me, ve)) : c < u ? (e.moveTo(c, a), e.arc(u, l, o, -Me, Me), e.arc(c, l, o, Me, ve + Me)) : l < h ? (e.arc(c, l, o, -ve, 0), e.arc(c, h, o, 0, ve)) : e.arc(c, l, o, -ve, ve), e.closePath(), e.moveTo(t, a)
                    } else e.rect(t, a, n, r)
                },
                drawPoint: function(e, t, a, n, r, i) {
                    var o, c, l, u, h, f = (i || 0) * ti;
                    if (t && typeof t == "object" && (o = t.toString(), o === "[object HTMLImageElement]" || o === "[object HTMLCanvasElement]")) {
                        e.save(), e.translate(n, r), e.rotate(f), e.drawImage(t, -t.width / 2, -t.height / 2, t.width, t.height), e.restore();
                        return
                    }
                    if (!(isNaN(a) || a <= 0)) {
                        switch (e.beginPath(), t) {
                            default: e.arc(n, r, a, 0, ai),
                            e.closePath();
                            break;
                            case "triangle":
                                    e.moveTo(n + Math.sin(f) * a, r - Math.cos(f) * a),
                                f += sn,
                                e.lineTo(n + Math.sin(f) * a, r - Math.cos(f) * a),
                                f += sn,
                                e.lineTo(n + Math.sin(f) * a, r - Math.cos(f) * a),
                                e.closePath();
                                break;
                            case "rectRounded":
                                    h = a * .516,
                                u = a - h,
                                c = Math.cos(f + Mt) * u,
                                l = Math.sin(f + Mt) * u,
                                e.arc(n - c, r - l, h, f - ve, f - Me),
                                e.arc(n + l, r - c, h, f - Me, f),
                                e.arc(n + c, r + l, h, f, f + Me),
                                e.arc(n - l, r + c, h, f + Me, f + ve),
                                e.closePath();
                                break;
                            case "rect":
                                    if (!i) {
                                    u = Math.SQRT1_2 * a, e.rect(n - u, r - u, 2 * u, 2 * u);
                                    break
                                }f += Mt;
                            case "rectRot":
                                    c = Math.cos(f) * a,
                                l = Math.sin(f) * a,
                                e.moveTo(n - c, r - l),
                                e.lineTo(n + l, r - c),
                                e.lineTo(n + c, r + l),
                                e.lineTo(n - l, r + c),
                                e.closePath();
                                break;
                            case "crossRot":
                                    f += Mt;
                            case "cross":
                                    c = Math.cos(f) * a,
                                l = Math.sin(f) * a,
                                e.moveTo(n - c, r - l),
                                e.lineTo(n + c, r + l),
                                e.moveTo(n + l, r - c),
                                e.lineTo(n - l, r + c);
                                break;
                            case "star":
                                    c = Math.cos(f) * a,
                                l = Math.sin(f) * a,
                                e.moveTo(n - c, r - l),
                                e.lineTo(n + c, r + l),
                                e.moveTo(n + l, r - c),
                                e.lineTo(n - l, r + c),
                                f += Mt,
                                c = Math.cos(f) * a,
                                l = Math.sin(f) * a,
                                e.moveTo(n - c, r - l),
                                e.lineTo(n + c, r + l),
                                e.moveTo(n + l, r - c),
                                e.lineTo(n - l, r + c);
                                break;
                            case "line":
                                    c = Math.cos(f) * a,
                                l = Math.sin(f) * a,
                                e.moveTo(n - c, r - l),
                                e.lineTo(n + c, r + l);
                                break;
                            case "dash":
                                    e.moveTo(n, r),
                                e.lineTo(n + Math.cos(f) * a, r + Math.sin(f) * a);
                                break
                        }
                        e.fill(), e.stroke()
                    }
                },
                _isPointInArea: function(e, t) {
                    var a = 1e-6;
                    return e.x > t.left - a && e.x < t.right + a && e.y > t.top - a && e.y < t.bottom + a
                },
                clipArea: function(e, t) {
                    e.save(), e.beginPath(), e.rect(t.left, t.top, t.right - t.left, t.bottom - t.top), e.clip()
                },
                unclipArea: function(e) {
                    e.restore()
                },
                lineTo: function(e, t, a, n) {
                    var r = a.steppedLine;
                    if (r) {
                        if (r === "middle") {
                            var i = (t.x + a.x) / 2;
                            e.lineTo(i, n ? a.y : t.y), e.lineTo(i, n ? t.y : a.y)
                        } else r === "after" && !n || r !== "after" && n ? e.lineTo(t.x, a.y) : e.lineTo(a.x, t.y);
                        e.lineTo(a.x, a.y);
                        return
                    }
                    if (!a.tension) {
                        e.lineTo(a.x, a.y);
                        return
                    }
                    e.bezierCurveTo(n ? t.controlPointPreviousX : t.controlPointNextX, n ? t.controlPointPreviousY : t.controlPointNextY, n ? a.controlPointNextX : a.controlPointPreviousX, n ? a.controlPointNextY : a.controlPointPreviousY, a.x, a.y)
                }
            },
            ni = Ht;
        _e.clear = Ht.clear, _e.drawRoundedRectangle = function(e) {
            e.beginPath(), Ht.roundedRect.apply(Ht, arguments)
        };
        var ln = {
            _set: function(e, t) {
                return _e.merge(this[e] || (this[e] = {}), t)
            }
        };
        ln._set("global", {
            defaultColor: "rgba(0,0,0,0.1)",
            defaultFontColor: "#666",
            defaultFontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
            defaultFontSize: 12,
            defaultFontStyle: "normal",
            defaultLineHeight: 1.2,
            showLines: !0
        });
        var A = ln,
            Vt = _e.valueOrDefault;

        function ri(e) {
            return !e || _e.isNullOrUndef(e.size) || _e.isNullOrUndef(e.family) ? null : (e.style ? e.style + " " : "") + (e.weight ? e.weight + " " : "") + e.size + "px " + e.family
        }
        var ii = {
                toLineHeight: function(e, t) {
                    var a = ("" + e).match(/^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/);
                    if (!a || a[1] === "normal") return t * 1.2;
                    switch (e = +a[2], a[3]) {
                        case "px":
                            return e;
                        case "%":
                            e /= 100;
                            break
                    }
                    return t * e
                },
                toPadding: function(e) {
                    var t, a, n, r;
                    return _e.isObject(e) ? (t = +e.top || 0, a = +e.right || 0, n = +e.bottom || 0, r = +e.left || 0) : t = a = n = r = +e || 0, {
                        top: t,
                        right: a,
                        bottom: n,
                        left: r,
                        height: t + n,
                        width: r + a
                    }
                },
                _parseFont: function(e) {
                    var t = A.global,
                        a = Vt(e.fontSize, t.defaultFontSize),
                        n = {
                            family: Vt(e.fontFamily, t.defaultFontFamily),
                            lineHeight: _e.options.toLineHeight(Vt(e.lineHeight, t.defaultLineHeight), a),
                            size: a,
                            style: Vt(e.fontStyle, t.defaultFontStyle),
                            weight: null,
                            string: ""
                        };
                    return n.string = ri(n), n
                },
                resolve: function(e, t, a, n) {
                    var r = !0,
                        i, o, c;
                    for (i = 0, o = e.length; i < o; ++i)
                        if (c = e[i], c !== void 0 && (t !== void 0 && typeof c == "function" && (c = c(t), r = !1), a !== void 0 && _e.isArray(c) && (c = c[a], r = !1), c !== void 0)) return n && !r && (n.cacheable = !1), c
                }
            },
            cn = {
                _factorize: function(e) {
                    var t = [],
                        a = Math.sqrt(e),
                        n;
                    for (n = 1; n < a; n++) e % n === 0 && (t.push(n), t.push(e / n));
                    return a === (a | 0) && t.push(a), t.sort(function(r, i) {
                        return r - i
                    }).pop(), t
                },
                log10: Math.log10 || function(e) {
                    var t = Math.log(e) * Math.LOG10E,
                        a = Math.round(t),
                        n = e === Math.pow(10, a);
                    return n ? a : t
                }
            },
            oi = cn;
        _e.log10 = cn.log10;
        var si = function(e, t) {
                return {
                    x: function(a) {
                        return e + e + t - a
                    },
                    setWidth: function(a) {
                        t = a
                    },
                    textAlign: function(a) {
                        return a === "center" ? a : a === "right" ? "left" : "right"
                    },
                    xPlus: function(a, n) {
                        return a - n
                    },
                    leftForLtr: function(a, n) {
                        return a - n
                    }
                }
            },
            li = function() {
                return {
                    x: function(e) {
                        return e
                    },
                    setWidth: function(e) {},
                    textAlign: function(e) {
                        return e
                    },
                    xPlus: function(e, t) {
                        return e + t
                    },
                    leftForLtr: function(e, t) {
                        return e
                    }
                }
            },
            ci = function(e, t, a) {
                return e ? si(t, a) : li()
            },
            ui = function(e, t) {
                var a, n;
                (t === "ltr" || t === "rtl") && (a = e.canvas.style, n = [a.getPropertyValue("direction"), a.getPropertyPriority("direction")], a.setProperty("direction", t, "important"), e.prevTextDirection = n)
            },
            di = function(e) {
                var t = e.prevTextDirection;
                t !== void 0 && (delete e.prevTextDirection, e.canvas.style.setProperty("direction", t[0], t[1]))
            },
            hi = {
                getRtlAdapter: ci,
                overrideTextDirection: ui,
                restoreTextDirection: di
            },
            v = _e,
            fi = ei,
            vi = ni,
            pi = ii,
            mi = oi,
            gi = hi;
        v.easing = fi, v.canvas = vi, v.options = pi, v.math = mi, v.rtl = gi;

        function bi(e, t, a, n) {
            var r = Object.keys(a),
                i, o, c, l, u, h, f, p, x;
            for (i = 0, o = r.length; i < o; ++i)
                if (c = r[i], h = a[c], t.hasOwnProperty(c) || (t[c] = h), l = t[c], !(l === h || c[0] === "_")) {
                    if (e.hasOwnProperty(c) || (e[c] = l), u = e[c], f = typeof h, f === typeof u) {
                        if (f === "string") {
                            if (p = jt(u), p.valid && (x = jt(h), x.valid)) {
                                t[c] = x.mix(p, n).rgbString();
                                continue
                            }
                        } else if (v.isFinite(u) && v.isFinite(h)) {
                            t[c] = u + (h - u) * n;
                            continue
                        }
                    }
                    t[c] = h
                }
        }
        var ua = function(e) {
            v.extend(this, e), this.initialize.apply(this, arguments)
        };
        v.extend(ua.prototype, {
            _type: void 0,
            initialize: function() {
                this.hidden = !1
            },
            pivot: function() {
                var e = this;
                return e._view || (e._view = v.extend({}, e._model)), e._start = {}, e
            },
            transition: function(e) {
                var t = this,
                    a = t._model,
                    n = t._start,
                    r = t._view;
                return !a || e === 1 ? (t._view = v.extend({}, a), t._start = null, t) : (r || (r = t._view = {}), n || (n = t._start = {}), bi(n, r, a, e), t)
            },
            tooltipPosition: function() {
                return {
                    x: this._model.x,
                    y: this._model.y
                }
            },
            hasValue: function() {
                return v.isNumber(this._model.x) && v.isNumber(this._model.y)
            }
        }), ua.extend = v.inherits;
        var Le = ua,
            da = Le.extend({
                chart: null,
                currentStep: 0,
                numSteps: 60,
                easing: "",
                render: null,
                onAnimationProgress: null,
                onAnimationComplete: null
            }),
            ha = da;
        Object.defineProperty(da.prototype, "animationObject", {
            get: function() {
                return this
            }
        }), Object.defineProperty(da.prototype, "chartInstance", {
            get: function() {
                return this.chart
            },
            set: function(e) {
                this.chart = e
            }
        }), A._set("global", {
            animation: {
                duration: 1e3,
                easing: "easeOutQuart",
                onProgress: v.noop,
                onComplete: v.noop
            }
        });
        var fa = {
                animations: [],
                request: null,
                addAnimation: function(e, t, a, n) {
                    var r = this.animations,
                        i, o;
                    for (t.chart = e, t.startTime = Date.now(), t.duration = a, n || (e.animating = !0), i = 0, o = r.length; i < o; ++i)
                        if (r[i].chart === e) {
                            r[i] = t;
                            return
                        }
                    r.push(t), r.length === 1 && this.requestAnimationFrame()
                },
                cancelAnimation: function(e) {
                    var t = v.findIndex(this.animations, function(a) {
                        return a.chart === e
                    });
                    t !== -1 && (this.animations.splice(t, 1), e.animating = !1)
                },
                requestAnimationFrame: function() {
                    var e = this;
                    e.request === null && (e.request = v.requestAnimFrame.call(window, function() {
                        e.request = null, e.startDigest()
                    }))
                },
                startDigest: function() {
                    var e = this;
                    e.advance(), e.animations.length > 0 && e.requestAnimationFrame()
                },
                advance: function() {
                    for (var e = this.animations, t, a, n, r, i = 0; i < e.length;) t = e[i], a = t.chart, n = t.numSteps, r = Math.floor((Date.now() - t.startTime) / t.duration * n) + 1, t.currentStep = Math.min(r, n), v.callback(t.render, [a, t], a), v.callback(t.onAnimationProgress, [t], a), t.currentStep >= n ? (v.callback(t.onAnimationComplete, [t], a), a.animating = !1, e.splice(i, 1)) : ++i
                }
            },
            ct = v.options.resolve,
            un = ["push", "pop", "shift", "splice", "unshift"];

        function yi(e, t) {
            if (e._chartjs) {
                e._chartjs.listeners.push(t);
                return
            }
            Object.defineProperty(e, "_chartjs", {
                configurable: !0,
                enumerable: !1,
                value: {
                    listeners: [t]
                }
            }), un.forEach(function(a) {
                var n = "onData" + a.charAt(0).toUpperCase() + a.slice(1),
                    r = e[a];
                Object.defineProperty(e, a, {
                    configurable: !0,
                    enumerable: !1,
                    value: function() {
                        var i = Array.prototype.slice.call(arguments),
                            o = r.apply(this, i);
                        return v.each(e._chartjs.listeners, function(c) {
                            typeof c[n] == "function" && c[n].apply(c, i)
                        }), o
                    }
                })
            })
        }

        function dn(e, t) {
            var a = e._chartjs;
            if (!!a) {
                var n = a.listeners,
                    r = n.indexOf(t);
                r !== -1 && n.splice(r, 1), !(n.length > 0) && (un.forEach(function(i) {
                    delete e[i]
                }), delete e._chartjs)
            }
        }
        var va = function(e, t) {
            this.initialize(e, t)
        };
        v.extend(va.prototype, {
            datasetElementType: null,
            dataElementType: null,
            _datasetElementOptions: ["backgroundColor", "borderCapStyle", "borderColor", "borderDash", "borderDashOffset", "borderJoinStyle", "borderWidth"],
            _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "pointStyle"],
            initialize: function(e, t) {
                var a = this;
                a.chart = e, a.index = t, a.linkScales(), a.addElements(), a._type = a.getMeta().type
            },
            updateIndex: function(e) {
                this.index = e
            },
            linkScales: function() {
                var e = this,
                    t = e.getMeta(),
                    a = e.chart,
                    n = a.scales,
                    r = e.getDataset(),
                    i = a.options.scales;
                (t.xAxisID === null || !(t.xAxisID in n) || r.xAxisID) && (t.xAxisID = r.xAxisID || i.xAxes[0].id), (t.yAxisID === null || !(t.yAxisID in n) || r.yAxisID) && (t.yAxisID = r.yAxisID || i.yAxes[0].id)
            },
            getDataset: function() {
                return this.chart.data.datasets[this.index]
            },
            getMeta: function() {
                return this.chart.getDatasetMeta(this.index)
            },
            getScaleForId: function(e) {
                return this.chart.scales[e]
            },
            _getValueScaleId: function() {
                return this.getMeta().yAxisID
            },
            _getIndexScaleId: function() {
                return this.getMeta().xAxisID
            },
            _getValueScale: function() {
                return this.getScaleForId(this._getValueScaleId())
            },
            _getIndexScale: function() {
                return this.getScaleForId(this._getIndexScaleId())
            },
            reset: function() {
                this._update(!0)
            },
            destroy: function() {
                this._data && dn(this._data, this)
            },
            createMetaDataset: function() {
                var e = this,
                    t = e.datasetElementType;
                return t && new t({
                    _chart: e.chart,
                    _datasetIndex: e.index
                })
            },
            createMetaData: function(e) {
                var t = this,
                    a = t.dataElementType;
                return a && new a({
                    _chart: t.chart,
                    _datasetIndex: t.index,
                    _index: e
                })
            },
            addElements: function() {
                var e = this,
                    t = e.getMeta(),
                    a = e.getDataset().data || [],
                    n = t.data,
                    r, i;
                for (r = 0, i = a.length; r < i; ++r) n[r] = n[r] || e.createMetaData(r);
                t.dataset = t.dataset || e.createMetaDataset()
            },
            addElementAndReset: function(e) {
                var t = this.createMetaData(e);
                this.getMeta().data.splice(e, 0, t), this.updateElement(t, e, !0)
            },
            buildOrUpdateElements: function() {
                var e = this,
                    t = e.getDataset(),
                    a = t.data || (t.data = []);
                e._data !== a && (e._data && dn(e._data, e), a && Object.isExtensible(a) && yi(a, e), e._data = a), e.resyncElements()
            },
            _configure: function() {
                var e = this;
                e._config = v.merge(Object.create(null), [e.chart.options.datasets[e._type], e.getDataset()], {
                    merger: function(t, a, n) {
                        t !== "_meta" && t !== "data" && v._merger(t, a, n)
                    }
                })
            },
            _update: function(e) {
                var t = this;
                t._configure(), t._cachedDataOpts = null, t.update(e)
            },
            update: v.noop,
            transition: function(e) {
                for (var t = this.getMeta(), a = t.data || [], n = a.length, r = 0; r < n; ++r) a[r].transition(e);
                t.dataset && t.dataset.transition(e)
            },
            draw: function() {
                var e = this.getMeta(),
                    t = e.data || [],
                    a = t.length,
                    n = 0;
                for (e.dataset && e.dataset.draw(); n < a; ++n) t[n].draw()
            },
            getStyle: function(e) {
                var t = this,
                    a = t.getMeta(),
                    n = a.dataset,
                    r;
                return t._configure(), n && e === void 0 ? r = t._resolveDatasetElementOptions(n || {}) : (e = e || 0, r = t._resolveDataElementOptions(a.data[e] || {}, e)), (r.fill === !1 || r.fill === null) && (r.backgroundColor = r.borderColor), r
            },
            _resolveDatasetElementOptions: function(e, t) {
                var a = this,
                    n = a.chart,
                    r = a._config,
                    i = e.custom || {},
                    o = n.options.elements[a.datasetElementType.prototype._type] || {},
                    c = a._datasetElementOptions,
                    l = {},
                    u, h, f, p, x = {
                        chart: n,
                        dataset: a.getDataset(),
                        datasetIndex: a.index,
                        hover: t
                    };
                for (u = 0, h = c.length; u < h; ++u) f = c[u], p = t ? "hover" + f.charAt(0).toUpperCase() + f.slice(1) : f, l[f] = ct([i[p], r[p], o[p]], x);
                return l
            },
            _resolveDataElementOptions: function(e, t) {
                var a = this,
                    n = e && e.custom,
                    r = a._cachedDataOpts;
                if (r && !n) return r;
                var i = a.chart,
                    o = a._config,
                    c = i.options.elements[a.dataElementType.prototype._type] || {},
                    l = a._dataElementOptions,
                    u = {},
                    h = {
                        chart: i,
                        dataIndex: t,
                        dataset: a.getDataset(),
                        datasetIndex: a.index
                    },
                    f = {
                        cacheable: !n
                    },
                    p, x, w, _;
                if (n = n || {}, v.isArray(l))
                    for (x = 0, w = l.length; x < w; ++x) _ = l[x], u[_] = ct([n[_], o[_], c[_]], h, t, f);
                else
                    for (p = Object.keys(l), x = 0, w = p.length; x < w; ++x) _ = p[x], u[_] = ct([n[_], o[l[_]], o[_], c[_]], h, t, f);
                return f.cacheable && (a._cachedDataOpts = Object.freeze(u)), u
            },
            removeHoverStyle: function(e) {
                v.merge(e._model, e.$previousStyle || {}), delete e.$previousStyle
            },
            setHoverStyle: function(e) {
                var t = this.chart.data.datasets[e._datasetIndex],
                    a = e._index,
                    n = e.custom || {},
                    r = e._model,
                    i = v.getHoverColor;
                e.$previousStyle = {
                    backgroundColor: r.backgroundColor,
                    borderColor: r.borderColor,
                    borderWidth: r.borderWidth
                }, r.backgroundColor = ct([n.hoverBackgroundColor, t.hoverBackgroundColor, i(r.backgroundColor)], void 0, a), r.borderColor = ct([n.hoverBorderColor, t.hoverBorderColor, i(r.borderColor)], void 0, a), r.borderWidth = ct([n.hoverBorderWidth, t.hoverBorderWidth, r.borderWidth], void 0, a)
            },
            _removeDatasetHoverStyle: function() {
                var e = this.getMeta().dataset;
                e && this.removeHoverStyle(e)
            },
            _setDatasetHoverStyle: function() {
                var e = this.getMeta().dataset,
                    t = {},
                    a, n, r, i, o, c;
                if (!!e) {
                    for (c = e._model, o = this._resolveDatasetElementOptions(e, !0), i = Object.keys(o), a = 0, n = i.length; a < n; ++a) r = i[a], t[r] = c[r], c[r] = o[r];
                    e.$previousStyle = t
                }
            },
            resyncElements: function() {
                var e = this,
                    t = e.getMeta(),
                    a = e.getDataset().data,
                    n = t.data.length,
                    r = a.length;
                r < n ? t.data.splice(r, n - r) : r > n && e.insertElements(n, r - n)
            },
            insertElements: function(e, t) {
                for (var a = 0; a < t; ++a) this.addElementAndReset(e + a)
            },
            onDataPush: function() {
                var e = arguments.length;
                this.insertElements(this.getDataset().data.length - e, e)
            },
            onDataPop: function() {
                this.getMeta().data.pop()
            },
            onDataShift: function() {
                this.getMeta().data.shift()
            },
            onDataSplice: function(e, t) {
                this.getMeta().data.splice(e, t), this.insertElements(e, arguments.length - 2)
            },
            onDataUnshift: function() {
                this.insertElements(0, arguments.length)
            }
        }), va.extend = v.inherits;
        var Ie = va,
            Ee = Math.PI * 2;
        A._set("global", {
            elements: {
                arc: {
                    backgroundColor: A.global.defaultColor,
                    borderColor: "#fff",
                    borderWidth: 2,
                    borderAlign: "center"
                }
            }
        });

        function hn(e, t) {
            var a = t.startAngle,
                n = t.endAngle,
                r = t.pixelMargin,
                i = r / t.outerRadius,
                o = t.x,
                c = t.y;
            e.beginPath(), e.arc(o, c, t.outerRadius, a - i, n + i), t.innerRadius > r ? (i = r / t.innerRadius, e.arc(o, c, t.innerRadius - r, n + i, a - i, !0)) : e.arc(o, c, r, n + Math.PI / 2, a - Math.PI / 2), e.closePath(), e.clip()
        }

        function xi(e, t, a, n) {
            var r = a.endAngle,
                i;
            for (n && (a.endAngle = a.startAngle + Ee, hn(e, a), a.endAngle = r, a.endAngle === a.startAngle && a.fullCircles && (a.endAngle += Ee, a.fullCircles--)), e.beginPath(), e.arc(a.x, a.y, a.innerRadius, a.startAngle + Ee, a.startAngle, !0), i = 0; i < a.fullCircles; ++i) e.stroke();
            for (e.beginPath(), e.arc(a.x, a.y, t.outerRadius, a.startAngle, a.startAngle + Ee), i = 0; i < a.fullCircles; ++i) e.stroke()
        }

        function wi(e, t, a) {
            var n = t.borderAlign === "inner";
            n ? (e.lineWidth = t.borderWidth * 2, e.lineJoin = "round") : (e.lineWidth = t.borderWidth, e.lineJoin = "bevel"), a.fullCircles && xi(e, t, a, n), n && hn(e, a), e.beginPath(), e.arc(a.x, a.y, t.outerRadius, a.startAngle, a.endAngle), e.arc(a.x, a.y, a.innerRadius, a.endAngle, a.startAngle, !0), e.closePath(), e.stroke()
        }
        var ki = Le.extend({
                _type: "arc",
                inLabelRange: function(e) {
                    var t = this._view;
                    return t ? Math.pow(e - t.x, 2) < Math.pow(t.radius + t.hoverRadius, 2) : !1
                },
                inRange: function(e, t) {
                    var a = this._view;
                    if (a) {
                        for (var n = v.getAngleFromPoint(a, {
                                x: e,
                                y: t
                            }), r = n.angle, i = n.distance, o = a.startAngle, c = a.endAngle; c < o;) c += Ee;
                        for (; r > c;) r -= Ee;
                        for (; r < o;) r += Ee;
                        var l = r >= o && r <= c,
                            u = i >= a.innerRadius && i <= a.outerRadius;
                        return l && u
                    }
                    return !1
                },
                getCenterPoint: function() {
                    var e = this._view,
                        t = (e.startAngle + e.endAngle) / 2,
                        a = (e.innerRadius + e.outerRadius) / 2;
                    return {
                        x: e.x + Math.cos(t) * a,
                        y: e.y + Math.sin(t) * a
                    }
                },
                getArea: function() {
                    var e = this._view;
                    return Math.PI * ((e.endAngle - e.startAngle) / (2 * Math.PI)) * (Math.pow(e.outerRadius, 2) - Math.pow(e.innerRadius, 2))
                },
                tooltipPosition: function() {
                    var e = this._view,
                        t = e.startAngle + (e.endAngle - e.startAngle) / 2,
                        a = (e.outerRadius - e.innerRadius) / 2 + e.innerRadius;
                    return {
                        x: e.x + Math.cos(t) * a,
                        y: e.y + Math.sin(t) * a
                    }
                },
                draw: function() {
                    var e = this._chart.ctx,
                        t = this._view,
                        a = t.borderAlign === "inner" ? .33 : 0,
                        n = {
                            x: t.x,
                            y: t.y,
                            innerRadius: t.innerRadius,
                            outerRadius: Math.max(t.outerRadius - a, 0),
                            pixelMargin: a,
                            startAngle: t.startAngle,
                            endAngle: t.endAngle,
                            fullCircles: Math.floor(t.circumference / Ee)
                        },
                        r;
                    if (e.save(), e.fillStyle = t.backgroundColor, e.strokeStyle = t.borderColor, n.fullCircles) {
                        for (n.endAngle = n.startAngle + Ee, e.beginPath(), e.arc(n.x, n.y, n.outerRadius, n.startAngle, n.endAngle), e.arc(n.x, n.y, n.innerRadius, n.endAngle, n.startAngle, !0), e.closePath(), r = 0; r < n.fullCircles; ++r) e.fill();
                        n.endAngle = n.startAngle + t.circumference % Ee
                    }
                    e.beginPath(), e.arc(n.x, n.y, n.outerRadius, n.startAngle, n.endAngle), e.arc(n.x, n.y, n.innerRadius, n.endAngle, n.startAngle, !0), e.closePath(), e.fill(), t.borderWidth && wi(e, t, n), e.restore()
                }
            }),
            fn = v.valueOrDefault,
            vn = A.global.defaultColor;
        A._set("global", {
            elements: {
                line: {
                    tension: .4,
                    backgroundColor: vn,
                    borderWidth: 3,
                    borderColor: vn,
                    borderCapStyle: "butt",
                    borderDash: [],
                    borderDashOffset: 0,
                    borderJoinStyle: "miter",
                    capBezierPoints: !0,
                    fill: !0
                }
            }
        });
        var _i = Le.extend({
                _type: "line",
                draw: function() {
                    var e = this,
                        t = e._view,
                        a = e._chart.ctx,
                        n = t.spanGaps,
                        r = e._children.slice(),
                        i = A.global,
                        o = i.elements.line,
                        c = -1,
                        l = e._loop,
                        u, h, f;
                    if (!!r.length) {
                        if (e._loop) {
                            for (u = 0; u < r.length; ++u)
                                if (h = v.previousItem(r, u), !r[u]._view.skip && h._view.skip) {
                                    r = r.slice(u).concat(r.slice(0, u)), l = n;
                                    break
                                }
                            l && r.push(r[0])
                        }
                        for (a.save(), a.lineCap = t.borderCapStyle || o.borderCapStyle, a.setLineDash && a.setLineDash(t.borderDash || o.borderDash), a.lineDashOffset = fn(t.borderDashOffset, o.borderDashOffset), a.lineJoin = t.borderJoinStyle || o.borderJoinStyle, a.lineWidth = fn(t.borderWidth, o.borderWidth), a.strokeStyle = t.borderColor || i.defaultColor, a.beginPath(), f = r[0]._view, f.skip || (a.moveTo(f.x, f.y), c = 0), u = 1; u < r.length; ++u) f = r[u]._view, h = c === -1 ? v.previousItem(r, u) : r[c], f.skip || (c !== u - 1 && !n || c === -1 ? a.moveTo(f.x, f.y) : v.canvas.lineTo(a, h._view, f), c = u);
                        l && a.closePath(), a.stroke(), a.restore()
                    }
                }
            }),
            Mi = v.valueOrDefault,
            pn = A.global.defaultColor;
        A._set("global", {
            elements: {
                point: {
                    radius: 3,
                    pointStyle: "circle",
                    backgroundColor: pn,
                    borderColor: pn,
                    borderWidth: 1,
                    hitRadius: 1,
                    hoverRadius: 4,
                    hoverBorderWidth: 1
                }
            }
        });

        function mn(e) {
            var t = this._view;
            return t ? Math.abs(e - t.x) < t.radius + t.hitRadius : !1
        }

        function Ii(e) {
            var t = this._view;
            return t ? Math.abs(e - t.y) < t.radius + t.hitRadius : !1
        }
        var Si = Le.extend({
                _type: "point",
                inRange: function(e, t) {
                    var a = this._view;
                    return a ? Math.pow(e - a.x, 2) + Math.pow(t - a.y, 2) < Math.pow(a.hitRadius + a.radius, 2) : !1
                },
                inLabelRange: mn,
                inXRange: mn,
                inYRange: Ii,
                getCenterPoint: function() {
                    var e = this._view;
                    return {
                        x: e.x,
                        y: e.y
                    }
                },
                getArea: function() {
                    return Math.PI * Math.pow(this._view.radius, 2)
                },
                tooltipPosition: function() {
                    var e = this._view;
                    return {
                        x: e.x,
                        y: e.y,
                        padding: e.radius + e.borderWidth
                    }
                },
                draw: function(e) {
                    var t = this._view,
                        a = this._chart.ctx,
                        n = t.pointStyle,
                        r = t.rotation,
                        i = t.radius,
                        o = t.x,
                        c = t.y,
                        l = A.global,
                        u = l.defaultColor;
                    t.skip || (e === void 0 || v.canvas._isPointInArea(t, e)) && (a.strokeStyle = t.borderColor || u, a.lineWidth = Mi(t.borderWidth, l.elements.point.borderWidth), a.fillStyle = t.backgroundColor || u, v.canvas.drawPoint(a, n, i, o, c, r))
                }
            }),
            gn = A.global.defaultColor;
        A._set("global", {
            elements: {
                rectangle: {
                    backgroundColor: gn,
                    borderColor: gn,
                    borderSkipped: "bottom",
                    borderWidth: 0
                }
            }
        });

        function Gt(e) {
            return e && e.width !== void 0
        }

        function bn(e) {
            var t, a, n, r, i;
            return Gt(e) ? (i = e.width / 2, t = e.x - i, a = e.x + i, n = Math.min(e.y, e.base), r = Math.max(e.y, e.base)) : (i = e.height / 2, t = Math.min(e.x, e.base), a = Math.max(e.x, e.base), n = e.y - i, r = e.y + i), {
                left: t,
                top: n,
                right: a,
                bottom: r
            }
        }

        function yn(e, t, a) {
            return e === t ? a : e === a ? t : e
        }

        function Ci(e) {
            var t = e.borderSkipped,
                a = {};
            return t && (e.horizontal ? e.base > e.x && (t = yn(t, "left", "right")) : e.base < e.y && (t = yn(t, "bottom", "top")), a[t] = !0), a
        }

        function Pi(e, t, a) {
            var n = e.borderWidth,
                r = Ci(e),
                i, o, c, l;
            return v.isObject(n) ? (i = +n.top || 0, o = +n.right || 0, c = +n.bottom || 0, l = +n.left || 0) : i = o = c = l = +n || 0, {
                t: r.top || i < 0 ? 0 : i > a ? a : i,
                r: r.right || o < 0 ? 0 : o > t ? t : o,
                b: r.bottom || c < 0 ? 0 : c > a ? a : c,
                l: r.left || l < 0 ? 0 : l > t ? t : l
            }
        }

        function Ti(e) {
            var t = bn(e),
                a = t.right - t.left,
                n = t.bottom - t.top,
                r = Pi(e, a / 2, n / 2);
            return {
                outer: {
                    x: t.left,
                    y: t.top,
                    w: a,
                    h: n
                },
                inner: {
                    x: t.left + r.l,
                    y: t.top + r.t,
                    w: a - r.l - r.r,
                    h: n - r.t - r.b
                }
            }
        }

        function It(e, t, a) {
            var n = t === null,
                r = a === null,
                i = !e || n && r ? !1 : bn(e);
            return i && (n || t >= i.left && t <= i.right) && (r || a >= i.top && a <= i.bottom)
        }
        var Ni = Le.extend({
                _type: "rectangle",
                draw: function() {
                    var e = this._chart.ctx,
                        t = this._view,
                        a = Ti(t),
                        n = a.outer,
                        r = a.inner;
                    e.fillStyle = t.backgroundColor, e.fillRect(n.x, n.y, n.w, n.h), !(n.w === r.w && n.h === r.h) && (e.save(), e.beginPath(), e.rect(n.x, n.y, n.w, n.h), e.clip(), e.fillStyle = t.borderColor, e.rect(r.x, r.y, r.w, r.h), e.fill("evenodd"), e.restore())
                },
                height: function() {
                    var e = this._view;
                    return e.base - e.y
                },
                inRange: function(e, t) {
                    return It(this._view, e, t)
                },
                inLabelRange: function(e, t) {
                    var a = this._view;
                    return Gt(a) ? It(a, e, null) : It(a, null, t)
                },
                inXRange: function(e) {
                    return It(this._view, e, null)
                },
                inYRange: function(e) {
                    return It(this._view, null, e)
                },
                getCenterPoint: function() {
                    var e = this._view,
                        t, a;
                    return Gt(e) ? (t = e.x, a = (e.y + e.base) / 2) : (t = (e.x + e.base) / 2, a = e.y), {
                        x: t,
                        y: a
                    }
                },
                getArea: function() {
                    var e = this._view;
                    return Gt(e) ? e.width * Math.abs(e.y - e.base) : e.height * Math.abs(e.x - e.base)
                },
                tooltipPosition: function() {
                    var e = this._view;
                    return {
                        x: e.x,
                        y: e.y
                    }
                }
            }),
            pe = {},
            Di = ki,
            Oi = _i,
            Ai = Si,
            Bi = Ni;
        pe.Arc = Di, pe.Line = Oi, pe.Point = Ai, pe.Rectangle = Bi;
        var St = v._deprecated,
            ut = v.valueOrDefault;
        A._set("bar", {
            hover: {
                mode: "label"
            },
            scales: {
                xAxes: [{
                    type: "category",
                    offset: !0,
                    gridLines: {
                        offsetGridLines: !0
                    }
                }],
                yAxes: [{
                    type: "linear"
                }]
            }
        }), A._set("global", {
            datasets: {
                bar: {
                    categoryPercentage: .8,
                    barPercentage: .9
                }
            }
        });

        function Ri(e, t) {
            var a = e._length,
                n, r, i, o;
            for (i = 1, o = t.length; i < o; ++i) a = Math.min(a, Math.abs(t[i] - t[i - 1]));
            for (i = 0, o = e.getTicks().length; i < o; ++i) r = e.getPixelForTick(i), a = i > 0 ? Math.min(a, Math.abs(r - n)) : a, n = r;
            return a
        }

        function Fi(e, t, a) {
            var n = a.barThickness,
                r = t.stackCount,
                i = t.pixels[e],
                o = v.isNullOrUndef(n) ? Ri(t.scale, t.pixels) : -1,
                c, l;
            return v.isNullOrUndef(n) ? (c = o * a.categoryPercentage, l = a.barPercentage) : (c = n * r, l = 1), {
                chunk: c / r,
                ratio: l,
                start: i - c / 2
            }
        }

        function Li(e, t, a) {
            var n = t.pixels,
                r = n[e],
                i = e > 0 ? n[e - 1] : null,
                o = e < n.length - 1 ? n[e + 1] : null,
                c = a.categoryPercentage,
                l, u;
            return i === null && (i = r - (o === null ? t.end - t.start : o - r)), o === null && (o = r + r - i), l = r - (r - Math.min(i, o)) / 2 * c, u = Math.abs(o - i) / 2 * c, {
                chunk: u / t.stackCount,
                ratio: a.barPercentage,
                start: l
            }
        }
        var xn = Ie.extend({
                dataElementType: pe.Rectangle,
                _dataElementOptions: ["backgroundColor", "borderColor", "borderSkipped", "borderWidth", "barPercentage", "barThickness", "categoryPercentage", "maxBarThickness", "minBarLength"],
                initialize: function() {
                    var e = this,
                        t, a;
                    Ie.prototype.initialize.apply(e, arguments), t = e.getMeta(), t.stack = e.getDataset().stack, t.bar = !0, a = e._getIndexScale().options, St("bar chart", a.barPercentage, "scales.[x/y]Axes.barPercentage", "dataset.barPercentage"), St("bar chart", a.barThickness, "scales.[x/y]Axes.barThickness", "dataset.barThickness"), St("bar chart", a.categoryPercentage, "scales.[x/y]Axes.categoryPercentage", "dataset.categoryPercentage"), St("bar chart", e._getValueScale().options.minBarLength, "scales.[x/y]Axes.minBarLength", "dataset.minBarLength"), St("bar chart", a.maxBarThickness, "scales.[x/y]Axes.maxBarThickness", "dataset.maxBarThickness")
                },
                update: function(e) {
                    var t = this,
                        a = t.getMeta().data,
                        n, r;
                    for (t._ruler = t.getRuler(), n = 0, r = a.length; n < r; ++n) t.updateElement(a[n], n, e)
                },
                updateElement: function(e, t, a) {
                    var n = this,
                        r = n.getMeta(),
                        i = n.getDataset(),
                        o = n._resolveDataElementOptions(e, t);
                    e._xScale = n.getScaleForId(r.xAxisID), e._yScale = n.getScaleForId(r.yAxisID), e._datasetIndex = n.index, e._index = t, e._model = {
                        backgroundColor: o.backgroundColor,
                        borderColor: o.borderColor,
                        borderSkipped: o.borderSkipped,
                        borderWidth: o.borderWidth,
                        datasetLabel: i.label,
                        label: n.chart.data.labels[t]
                    }, v.isArray(i.data[t]) && (e._model.borderSkipped = null), n._updateElementGeometry(e, t, a, o), e.pivot()
                },
                _updateElementGeometry: function(e, t, a, n) {
                    var r = this,
                        i = e._model,
                        o = r._getValueScale(),
                        c = o.getBasePixel(),
                        l = o.isHorizontal(),
                        u = r._ruler || r.getRuler(),
                        h = r.calculateBarValuePixels(r.index, t, n),
                        f = r.calculateBarIndexPixels(r.index, t, u, n);
                    i.horizontal = l, i.base = a ? c : h.base, i.x = l ? a ? c : h.head : f.center, i.y = l ? f.center : a ? c : h.head, i.height = l ? f.size : void 0, i.width = l ? void 0 : f.size
                },
                _getStacks: function(e) {
                    var t = this,
                        a = t._getIndexScale(),
                        n = a._getMatchingVisibleMetas(t._type),
                        r = a.options.stacked,
                        i = n.length,
                        o = [],
                        c, l;
                    for (c = 0; c < i && (l = n[c], (r === !1 || o.indexOf(l.stack) === -1 || r === void 0 && l.stack === void 0) && o.push(l.stack), l.index !== e); ++c);
                    return o
                },
                getStackCount: function() {
                    return this._getStacks().length
                },
                getStackIndex: function(e, t) {
                    var a = this._getStacks(e),
                        n = t !== void 0 ? a.indexOf(t) : -1;
                    return n === -1 ? a.length - 1 : n
                },
                getRuler: function() {
                    var e = this,
                        t = e._getIndexScale(),
                        a = [],
                        n, r;
                    for (n = 0, r = e.getMeta().data.length; n < r; ++n) a.push(t.getPixelForValue(null, n, e.index));
                    return {
                        pixels: a,
                        start: t._startPixel,
                        end: t._endPixel,
                        stackCount: e.getStackCount(),
                        scale: t
                    }
                },
                calculateBarValuePixels: function(e, t, a) {
                    var n = this,
                        r = n.chart,
                        i = n._getValueScale(),
                        o = i.isHorizontal(),
                        c = r.data.datasets,
                        l = i._getMatchingVisibleMetas(n._type),
                        u = i._parseValue(c[e].data[t]),
                        h = a.minBarLength,
                        f = i.options.stacked,
                        p = n.getMeta().stack,
                        x = u.start === void 0 ? 0 : u.max >= 0 && u.min >= 0 ? u.min : u.max,
                        w = u.start === void 0 ? u.end : u.max >= 0 && u.min >= 0 ? u.max - u.min : u.min - u.max,
                        _ = l.length,
                        M, C, T, N, W, E, $;
                    if (f || f === void 0 && p !== void 0)
                        for (M = 0; M < _ && (C = l[M], C.index !== e); ++M) C.stack === p && ($ = i._parseValue(c[C.index].data[t]), T = $.start === void 0 ? $.end : $.min >= 0 && $.max >= 0 ? $.max : $.min, (u.min < 0 && T < 0 || u.max >= 0 && T > 0) && (x += T));
                    return N = i.getPixelForValue(x), W = i.getPixelForValue(x + w), E = W - N, h !== void 0 && Math.abs(E) < h && (E = h, w >= 0 && !o || w < 0 && o ? W = N - h : W = N + h), {
                        size: E,
                        base: N,
                        head: W,
                        center: W + E / 2
                    }
                },
                calculateBarIndexPixels: function(e, t, a, n) {
                    var r = this,
                        i = n.barThickness === "flex" ? Li(t, a, n) : Fi(t, a, n),
                        o = r.getStackIndex(e, r.getMeta().stack),
                        c = i.start + i.chunk * o + i.chunk / 2,
                        l = Math.min(ut(n.maxBarThickness, 1 / 0), i.chunk * i.ratio);
                    return {
                        base: c - l / 2,
                        head: c + l / 2,
                        center: c,
                        size: l
                    }
                },
                draw: function() {
                    var e = this,
                        t = e.chart,
                        a = e._getValueScale(),
                        n = e.getMeta().data,
                        r = e.getDataset(),
                        i = n.length,
                        o = 0;
                    for (v.canvas.clipArea(t.ctx, t.chartArea); o < i; ++o) {
                        var c = a._parseValue(r.data[o]);
                        !isNaN(c.min) && !isNaN(c.max) && n[o].draw()
                    }
                    v.canvas.unclipArea(t.ctx)
                },
                _resolveDataElementOptions: function() {
                    var e = this,
                        t = v.extend({}, Ie.prototype._resolveDataElementOptions.apply(e, arguments)),
                        a = e._getIndexScale().options,
                        n = e._getValueScale().options;
                    return t.barPercentage = ut(a.barPercentage, t.barPercentage), t.barThickness = ut(a.barThickness, t.barThickness), t.categoryPercentage = ut(a.categoryPercentage, t.categoryPercentage), t.maxBarThickness = ut(a.maxBarThickness, t.maxBarThickness), t.minBarLength = ut(n.minBarLength, t.minBarLength), t
                }
            }),
            pa = v.valueOrDefault,
            Ei = v.options.resolve;
        A._set("bubble", {
            hover: {
                mode: "single"
            },
            scales: {
                xAxes: [{
                    type: "linear",
                    position: "bottom",
                    id: "x-axis-0"
                }],
                yAxes: [{
                    type: "linear",
                    position: "left",
                    id: "y-axis-0"
                }]
            },
            tooltips: {
                callbacks: {
                    title: function() {
                        return ""
                    },
                    label: function(e, t) {
                        var a = t.datasets[e.datasetIndex].label || "",
                            n = t.datasets[e.datasetIndex].data[e.index];
                        return a + ": (" + e.xLabel + ", " + e.yLabel + ", " + n.r + ")"
                    }
                }
            }
        });
        var zi = Ie.extend({
                dataElementType: pe.Point,
                _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "hoverBackgroundColor", "hoverBorderColor", "hoverBorderWidth", "hoverRadius", "hitRadius", "pointStyle", "rotation"],
                update: function(e) {
                    var t = this,
                        a = t.getMeta(),
                        n = a.data;
                    v.each(n, function(r, i) {
                        t.updateElement(r, i, e)
                    })
                },
                updateElement: function(e, t, a) {
                    var n = this,
                        r = n.getMeta(),
                        i = e.custom || {},
                        o = n.getScaleForId(r.xAxisID),
                        c = n.getScaleForId(r.yAxisID),
                        l = n._resolveDataElementOptions(e, t),
                        u = n.getDataset().data[t],
                        h = n.index,
                        f = a ? o.getPixelForDecimal(.5) : o.getPixelForValue(typeof u == "object" ? u : NaN, t, h),
                        p = a ? c.getBasePixel() : c.getPixelForValue(u, t, h);
                    e._xScale = o, e._yScale = c, e._options = l, e._datasetIndex = h, e._index = t, e._model = {
                        backgroundColor: l.backgroundColor,
                        borderColor: l.borderColor,
                        borderWidth: l.borderWidth,
                        hitRadius: l.hitRadius,
                        pointStyle: l.pointStyle,
                        rotation: l.rotation,
                        radius: a ? 0 : l.radius,
                        skip: i.skip || isNaN(f) || isNaN(p),
                        x: f,
                        y: p
                    }, e.pivot()
                },
                setHoverStyle: function(e) {
                    var t = e._model,
                        a = e._options,
                        n = v.getHoverColor;
                    e.$previousStyle = {
                        backgroundColor: t.backgroundColor,
                        borderColor: t.borderColor,
                        borderWidth: t.borderWidth,
                        radius: t.radius
                    }, t.backgroundColor = pa(a.hoverBackgroundColor, n(a.backgroundColor)), t.borderColor = pa(a.hoverBorderColor, n(a.borderColor)), t.borderWidth = pa(a.hoverBorderWidth, a.borderWidth), t.radius = a.radius + a.hoverRadius
                },
                _resolveDataElementOptions: function(e, t) {
                    var a = this,
                        n = a.chart,
                        r = a.getDataset(),
                        i = e.custom || {},
                        o = r.data[t] || {},
                        c = Ie.prototype._resolveDataElementOptions.apply(a, arguments),
                        l = {
                            chart: n,
                            dataIndex: t,
                            dataset: r,
                            datasetIndex: a.index
                        };
                    return a._cachedDataOpts === c && (c = v.extend({}, c)), c.radius = Ei([i.radius, o.r, a._config.radius, n.options.elements.point.radius], l, t), c
                }
            }),
            $t = v.valueOrDefault,
            Qe = Math.PI,
            We = Qe * 2,
            et = Qe / 2;
        A._set("doughnut", {
            animation: {
                animateRotate: !0,
                animateScale: !1
            },
            hover: {
                mode: "single"
            },
            legendCallback: function(e) {
                var t = document.createElement("ul"),
                    a = e.data,
                    n = a.datasets,
                    r = a.labels,
                    i, o, c, l;
                if (t.setAttribute("class", e.id + "-legend"), n.length)
                    for (i = 0, o = n[0].data.length; i < o; ++i) c = t.appendChild(document.createElement("li")), l = c.appendChild(document.createElement("span")), l.style.backgroundColor = n[0].backgroundColor[i], r[i] && c.appendChild(document.createTextNode(r[i]));
                return t.outerHTML
            },
            legend: {
                labels: {
                    generateLabels: function(e) {
                        var t = e.data;
                        return t.labels.length && t.datasets.length ? t.labels.map(function(a, n) {
                            var r = e.getDatasetMeta(0),
                                i = r.controller.getStyle(n);
                            return {
                                text: a,
                                fillStyle: i.backgroundColor,
                                strokeStyle: i.borderColor,
                                lineWidth: i.borderWidth,
                                hidden: isNaN(t.datasets[0].data[n]) || r.data[n].hidden,
                                index: n
                            }
                        }) : []
                    }
                },
                onClick: function(e, t) {
                    var a = t.index,
                        n = this.chart,
                        r, i, o;
                    for (r = 0, i = (n.data.datasets || []).length; r < i; ++r) o = n.getDatasetMeta(r), o.data[a] && (o.data[a].hidden = !o.data[a].hidden);
                    n.update()
                }
            },
            cutoutPercentage: 50,
            rotation: -et,
            circumference: We,
            tooltips: {
                callbacks: {
                    title: function() {
                        return ""
                    },
                    label: function(e, t) {
                        var a = t.labels[e.index],
                            n = ": " + t.datasets[e.datasetIndex].data[e.index];
                        return v.isArray(a) ? (a = a.slice(), a[0] += n) : a += n, a
                    }
                }
            }
        });
        var wn = Ie.extend({
            dataElementType: pe.Arc,
            linkScales: v.noop,
            _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "borderAlign", "hoverBackgroundColor", "hoverBorderColor", "hoverBorderWidth"],
            getRingIndex: function(e) {
                for (var t = 0, a = 0; a < e; ++a) this.chart.isDatasetVisible(a) && ++t;
                return t
            },
            update: function(e) {
                var t = this,
                    a = t.chart,
                    n = a.chartArea,
                    r = a.options,
                    i = 1,
                    o = 1,
                    c = 0,
                    l = 0,
                    u = t.getMeta(),
                    h = u.data,
                    f = r.cutoutPercentage / 100 || 0,
                    p = r.circumference,
                    x = t._getRingWeight(t.index),
                    w, _, M, C;
                if (p < We) {
                    var T = r.rotation % We;
                    T += T >= Qe ? -We : T < -Qe ? We : 0;
                    var N = T + p,
                        W = Math.cos(T),
                        E = Math.sin(T),
                        $ = Math.cos(N),
                        G = Math.sin(N),
                        U = T <= 0 && N >= 0 || N >= We,
                        J = T <= et && N >= et || N >= We + et,
                        ie = T === -Qe || N >= Qe,
                        ae = T <= -et && N >= -et || N >= Qe + et,
                        te = ie ? -1 : Math.min(W, W * f, $, $ * f),
                        se = ae ? -1 : Math.min(E, E * f, G, G * f),
                        pt = U ? 1 : Math.max(W, W * f, $, $ * f),
                        mt = J ? 1 : Math.max(E, E * f, G, G * f);
                    i = (pt - te) / 2, o = (mt - se) / 2, c = -(pt + te) / 2, l = -(mt + se) / 2
                }
                for (M = 0, C = h.length; M < C; ++M) h[M]._options = t._resolveDataElementOptions(h[M], M);
                for (a.borderWidth = t.getMaxBorderWidth(), w = (n.right - n.left - a.borderWidth) / i, _ = (n.bottom - n.top - a.borderWidth) / o, a.outerRadius = Math.max(Math.min(w, _) / 2, 0), a.innerRadius = Math.max(a.outerRadius * f, 0), a.radiusLength = (a.outerRadius - a.innerRadius) / (t._getVisibleDatasetWeightTotal() || 1), a.offsetX = c * a.outerRadius, a.offsetY = l * a.outerRadius, u.total = t.calculateTotal(), t.outerRadius = a.outerRadius - a.radiusLength * t._getRingWeightOffset(t.index), t.innerRadius = Math.max(t.outerRadius - a.radiusLength * x, 0), M = 0, C = h.length; M < C; ++M) t.updateElement(h[M], M, e)
            },
            updateElement: function(e, t, a) {
                var n = this,
                    r = n.chart,
                    i = r.chartArea,
                    o = r.options,
                    c = o.animation,
                    l = (i.left + i.right) / 2,
                    u = (i.top + i.bottom) / 2,
                    h = o.rotation,
                    f = o.rotation,
                    p = n.getDataset(),
                    x = a && c.animateRotate || e.hidden ? 0 : n.calculateCircumference(p.data[t]) * (o.circumference / We),
                    w = a && c.animateScale ? 0 : n.innerRadius,
                    _ = a && c.animateScale ? 0 : n.outerRadius,
                    M = e._options || {};
                v.extend(e, {
                    _datasetIndex: n.index,
                    _index: t,
                    _model: {
                        backgroundColor: M.backgroundColor,
                        borderColor: M.borderColor,
                        borderWidth: M.borderWidth,
                        borderAlign: M.borderAlign,
                        x: l + r.offsetX,
                        y: u + r.offsetY,
                        startAngle: h,
                        endAngle: f,
                        circumference: x,
                        outerRadius: _,
                        innerRadius: w,
                        label: v.valueAtIndexOrDefault(p.label, t, r.data.labels[t])
                    }
                });
                var C = e._model;
                (!a || !c.animateRotate) && (t === 0 ? C.startAngle = o.rotation : C.startAngle = n.getMeta().data[t - 1]._model.endAngle, C.endAngle = C.startAngle + C.circumference), e.pivot()
            },
            calculateTotal: function() {
                var e = this.getDataset(),
                    t = this.getMeta(),
                    a = 0,
                    n;
                return v.each(t.data, function(r, i) {
                    n = e.data[i], !isNaN(n) && !r.hidden && (a += Math.abs(n))
                }), a
            },
            calculateCircumference: function(e) {
                var t = this.getMeta().total;
                return t > 0 && !isNaN(e) ? We * (Math.abs(e) / t) : 0
            },
            getMaxBorderWidth: function(e) {
                var t = this,
                    a = 0,
                    n = t.chart,
                    r, i, o, c, l, u, h, f;
                if (!e) {
                    for (r = 0, i = n.data.datasets.length; r < i; ++r)
                        if (n.isDatasetVisible(r)) {
                            o = n.getDatasetMeta(r), e = o.data, r !== t.index && (l = o.controller);
                            break
                        }
                }
                if (!e) return 0;
                for (r = 0, i = e.length; r < i; ++r) c = e[r], l ? (l._configure(), u = l._resolveDataElementOptions(c, r)) : u = c._options, u.borderAlign !== "inner" && (h = u.borderWidth, f = u.hoverBorderWidth, a = h > a ? h : a, a = f > a ? f : a);
                return a
            },
            setHoverStyle: function(e) {
                var t = e._model,
                    a = e._options,
                    n = v.getHoverColor;
                e.$previousStyle = {
                    backgroundColor: t.backgroundColor,
                    borderColor: t.borderColor,
                    borderWidth: t.borderWidth
                }, t.backgroundColor = $t(a.hoverBackgroundColor, n(a.backgroundColor)), t.borderColor = $t(a.hoverBorderColor, n(a.borderColor)), t.borderWidth = $t(a.hoverBorderWidth, a.borderWidth)
            },
            _getRingWeightOffset: function(e) {
                for (var t = 0, a = 0; a < e; ++a) this.chart.isDatasetVisible(a) && (t += this._getRingWeight(a));
                return t
            },
            _getRingWeight: function(e) {
                return Math.max($t(this.chart.data.datasets[e].weight, 1), 0)
            },
            _getVisibleDatasetWeightTotal: function() {
                return this._getRingWeightOffset(this.chart.data.datasets.length)
            }
        });
        A._set("horizontalBar", {
            hover: {
                mode: "index",
                axis: "y"
            },
            scales: {
                xAxes: [{
                    type: "linear",
                    position: "bottom"
                }],
                yAxes: [{
                    type: "category",
                    position: "left",
                    offset: !0,
                    gridLines: {
                        offsetGridLines: !0
                    }
                }]
            },
            elements: {
                rectangle: {
                    borderSkipped: "left"
                }
            },
            tooltips: {
                mode: "index",
                axis: "y"
            }
        }), A._set("global", {
            datasets: {
                horizontalBar: {
                    categoryPercentage: .8,
                    barPercentage: .9
                }
            }
        });
        var Wi = xn.extend({
                _getValueScaleId: function() {
                    return this.getMeta().xAxisID
                },
                _getIndexScaleId: function() {
                    return this.getMeta().yAxisID
                }
            }),
            je = v.valueOrDefault,
            ji = v.options.resolve,
            ma = v.canvas._isPointInArea;
        A._set("line", {
            showLines: !0,
            spanGaps: !1,
            hover: {
                mode: "label"
            },
            scales: {
                xAxes: [{
                    type: "category",
                    id: "x-axis-0"
                }],
                yAxes: [{
                    type: "linear",
                    id: "y-axis-0"
                }]
            }
        });

        function kn(e, t) {
            var a = e && e.options.ticks || {},
                n = a.reverse,
                r = a.min === void 0 ? t : 0,
                i = a.max === void 0 ? t : 0;
            return {
                start: n ? i : r,
                end: n ? r : i
            }
        }

        function Hi(e, t, a) {
            var n = a / 2,
                r = kn(e, n),
                i = kn(t, n);
            return {
                top: i.end,
                right: r.end,
                bottom: i.start,
                left: r.start
            }
        }

        function Vi(e) {
            var t, a, n, r;
            return v.isObject(e) ? (t = e.top, a = e.right, n = e.bottom, r = e.left) : t = a = n = r = e, {
                top: t,
                right: a,
                bottom: n,
                left: r
            }
        }
        var _n = Ie.extend({
                datasetElementType: pe.Line,
                dataElementType: pe.Point,
                _datasetElementOptions: ["backgroundColor", "borderCapStyle", "borderColor", "borderDash", "borderDashOffset", "borderJoinStyle", "borderWidth", "cubicInterpolationMode", "fill"],
                _dataElementOptions: {
                    backgroundColor: "pointBackgroundColor",
                    borderColor: "pointBorderColor",
                    borderWidth: "pointBorderWidth",
                    hitRadius: "pointHitRadius",
                    hoverBackgroundColor: "pointHoverBackgroundColor",
                    hoverBorderColor: "pointHoverBorderColor",
                    hoverBorderWidth: "pointHoverBorderWidth",
                    hoverRadius: "pointHoverRadius",
                    pointStyle: "pointStyle",
                    radius: "pointRadius",
                    rotation: "pointRotation"
                },
                update: function(e) {
                    var t = this,
                        a = t.getMeta(),
                        n = a.dataset,
                        r = a.data || [],
                        i = t.chart.options,
                        o = t._config,
                        c = t._showLine = je(o.showLine, i.showLines),
                        l, u;
                    for (t._xScale = t.getScaleForId(a.xAxisID), t._yScale = t.getScaleForId(a.yAxisID), c && (o.tension !== void 0 && o.lineTension === void 0 && (o.lineTension = o.tension), n._scale = t._yScale, n._datasetIndex = t.index, n._children = r, n._model = t._resolveDatasetElementOptions(n), n.pivot()), l = 0, u = r.length; l < u; ++l) t.updateElement(r[l], l, e);
                    for (c && n._model.tension !== 0 && t.updateBezierControlPoints(), l = 0, u = r.length; l < u; ++l) r[l].pivot()
                },
                updateElement: function(e, t, a) {
                    var n = this,
                        r = n.getMeta(),
                        i = e.custom || {},
                        o = n.getDataset(),
                        c = n.index,
                        l = o.data[t],
                        u = n._xScale,
                        h = n._yScale,
                        f = r.dataset._model,
                        p, x, w = n._resolveDataElementOptions(e, t);
                    p = u.getPixelForValue(typeof l == "object" ? l : NaN, t, c), x = a ? h.getBasePixel() : n.calculatePointY(l, t, c), e._xScale = u, e._yScale = h, e._options = w, e._datasetIndex = c, e._index = t, e._model = {
                        x: p,
                        y: x,
                        skip: i.skip || isNaN(p) || isNaN(x),
                        radius: w.radius,
                        pointStyle: w.pointStyle,
                        rotation: w.rotation,
                        backgroundColor: w.backgroundColor,
                        borderColor: w.borderColor,
                        borderWidth: w.borderWidth,
                        tension: je(i.tension, f ? f.tension : 0),
                        steppedLine: f ? f.steppedLine : !1,
                        hitRadius: w.hitRadius
                    }
                },
                _resolveDatasetElementOptions: function(e) {
                    var t = this,
                        a = t._config,
                        n = e.custom || {},
                        r = t.chart.options,
                        i = r.elements.line,
                        o = Ie.prototype._resolveDatasetElementOptions.apply(t, arguments);
                    return o.spanGaps = je(a.spanGaps, r.spanGaps), o.tension = je(a.lineTension, i.tension), o.steppedLine = ji([n.steppedLine, a.steppedLine, i.stepped]), o.clip = Vi(je(a.clip, Hi(t._xScale, t._yScale, o.borderWidth))), o
                },
                calculatePointY: function(e, t, a) {
                    var n = this,
                        r = n.chart,
                        i = n._yScale,
                        o = 0,
                        c = 0,
                        l, u, h, f, p, x, w;
                    if (i.options.stacked) {
                        for (p = +i.getRightValue(e), x = r._getSortedVisibleDatasetMetas(), w = x.length, l = 0; l < w && (h = x[l], h.index !== a); ++l) u = r.data.datasets[h.index], h.type === "line" && h.yAxisID === i.id && (f = +i.getRightValue(u.data[t]), f < 0 ? c += f || 0 : o += f || 0);
                        return p < 0 ? i.getPixelForValue(c + p) : i.getPixelForValue(o + p)
                    }
                    return i.getPixelForValue(e)
                },
                updateBezierControlPoints: function() {
                    var e = this,
                        t = e.chart,
                        a = e.getMeta(),
                        n = a.dataset._model,
                        r = t.chartArea,
                        i = a.data || [],
                        o, c, l, u;
                    n.spanGaps && (i = i.filter(function(f) {
                        return !f._model.skip
                    }));

                    function h(f, p, x) {
                        return Math.max(Math.min(f, x), p)
                    }
                    if (n.cubicInterpolationMode === "monotone") v.splineCurveMonotone(i);
                    else
                        for (o = 0, c = i.length; o < c; ++o) l = i[o]._model, u = v.splineCurve(v.previousItem(i, o)._model, l, v.nextItem(i, o)._model, n.tension), l.controlPointPreviousX = u.previous.x, l.controlPointPreviousY = u.previous.y, l.controlPointNextX = u.next.x, l.controlPointNextY = u.next.y;
                    if (t.options.elements.line.capBezierPoints)
                        for (o = 0, c = i.length; o < c; ++o) l = i[o]._model, ma(l, r) && (o > 0 && ma(i[o - 1]._model, r) && (l.controlPointPreviousX = h(l.controlPointPreviousX, r.left, r.right), l.controlPointPreviousY = h(l.controlPointPreviousY, r.top, r.bottom)), o < i.length - 1 && ma(i[o + 1]._model, r) && (l.controlPointNextX = h(l.controlPointNextX, r.left, r.right), l.controlPointNextY = h(l.controlPointNextY, r.top, r.bottom)))
                },
                draw: function() {
                    var e = this,
                        t = e.chart,
                        a = e.getMeta(),
                        n = a.data || [],
                        r = t.chartArea,
                        i = t.canvas,
                        o = 0,
                        c = n.length,
                        l;
                    for (e._showLine && (l = a.dataset._model.clip, v.canvas.clipArea(t.ctx, {
                            left: l.left === !1 ? 0 : r.left - l.left,
                            right: l.right === !1 ? i.width : r.right + l.right,
                            top: l.top === !1 ? 0 : r.top - l.top,
                            bottom: l.bottom === !1 ? i.height : r.bottom + l.bottom
                        }), a.dataset.draw(), v.canvas.unclipArea(t.ctx)); o < c; ++o) n[o].draw(r)
                },
                setHoverStyle: function(e) {
                    var t = e._model,
                        a = e._options,
                        n = v.getHoverColor;
                    e.$previousStyle = {
                        backgroundColor: t.backgroundColor,
                        borderColor: t.borderColor,
                        borderWidth: t.borderWidth,
                        radius: t.radius
                    }, t.backgroundColor = je(a.hoverBackgroundColor, n(a.backgroundColor)), t.borderColor = je(a.hoverBorderColor, n(a.borderColor)), t.borderWidth = je(a.hoverBorderWidth, a.borderWidth), t.radius = je(a.hoverRadius, a.radius)
                }
            }),
            Gi = v.options.resolve;
        A._set("polarArea", {
            scale: {
                type: "radialLinear",
                angleLines: {
                    display: !1
                },
                gridLines: {
                    circular: !0
                },
                pointLabels: {
                    display: !1
                },
                ticks: {
                    beginAtZero: !0
                }
            },
            animation: {
                animateRotate: !0,
                animateScale: !0
            },
            startAngle: -.5 * Math.PI,
            legendCallback: function(e) {
                var t = document.createElement("ul"),
                    a = e.data,
                    n = a.datasets,
                    r = a.labels,
                    i, o, c, l;
                if (t.setAttribute("class", e.id + "-legend"), n.length)
                    for (i = 0, o = n[0].data.length; i < o; ++i) c = t.appendChild(document.createElement("li")), l = c.appendChild(document.createElement("span")), l.style.backgroundColor = n[0].backgroundColor[i], r[i] && c.appendChild(document.createTextNode(r[i]));
                return t.outerHTML
            },
            legend: {
                labels: {
                    generateLabels: function(e) {
                        var t = e.data;
                        return t.labels.length && t.datasets.length ? t.labels.map(function(a, n) {
                            var r = e.getDatasetMeta(0),
                                i = r.controller.getStyle(n);
                            return {
                                text: a,
                                fillStyle: i.backgroundColor,
                                strokeStyle: i.borderColor,
                                lineWidth: i.borderWidth,
                                hidden: isNaN(t.datasets[0].data[n]) || r.data[n].hidden,
                                index: n
                            }
                        }) : []
                    }
                },
                onClick: function(e, t) {
                    var a = t.index,
                        n = this.chart,
                        r, i, o;
                    for (r = 0, i = (n.data.datasets || []).length; r < i; ++r) o = n.getDatasetMeta(r), o.data[a].hidden = !o.data[a].hidden;
                    n.update()
                }
            },
            tooltips: {
                callbacks: {
                    title: function() {
                        return ""
                    },
                    label: function(e, t) {
                        return t.labels[e.index] + ": " + e.yLabel
                    }
                }
            }
        });
        var $i = Ie.extend({
            dataElementType: pe.Arc,
            linkScales: v.noop,
            _dataElementOptions: ["backgroundColor", "borderColor", "borderWidth", "borderAlign", "hoverBackgroundColor", "hoverBorderColor", "hoverBorderWidth"],
            _getIndexScaleId: function() {
                return this.chart.scale.id
            },
            _getValueScaleId: function() {
                return this.chart.scale.id
            },
            update: function(e) {
                var t = this,
                    a = t.getDataset(),
                    n = t.getMeta(),
                    r = t.chart.options.startAngle || 0,
                    i = t._starts = [],
                    o = t._angles = [],
                    c = n.data,
                    l, u, h;
                for (t._updateRadius(), n.count = t.countVisibleElements(), l = 0, u = a.data.length; l < u; l++) i[l] = r, h = t._computeAngle(l), o[l] = h, r += h;
                for (l = 0, u = c.length; l < u; ++l) c[l]._options = t._resolveDataElementOptions(c[l], l), t.updateElement(c[l], l, e)
            },
            _updateRadius: function() {
                var e = this,
                    t = e.chart,
                    a = t.chartArea,
                    n = t.options,
                    r = Math.min(a.right - a.left, a.bottom - a.top);
                t.outerRadius = Math.max(r / 2, 0), t.innerRadius = Math.max(n.cutoutPercentage ? t.outerRadius / 100 * n.cutoutPercentage : 1, 0), t.radiusLength = (t.outerRadius - t.innerRadius) / t.getVisibleDatasetCount(), e.outerRadius = t.outerRadius - t.radiusLength * e.index, e.innerRadius = e.outerRadius - t.radiusLength
            },
            updateElement: function(e, t, a) {
                var n = this,
                    r = n.chart,
                    i = n.getDataset(),
                    o = r.options,
                    c = o.animation,
                    l = r.scale,
                    u = r.data.labels,
                    h = l.xCenter,
                    f = l.yCenter,
                    p = o.startAngle,
                    x = e.hidden ? 0 : l.getDistanceFromCenterForValue(i.data[t]),
                    w = n._starts[t],
                    _ = w + (e.hidden ? 0 : n._angles[t]),
                    M = c.animateScale ? 0 : l.getDistanceFromCenterForValue(i.data[t]),
                    C = e._options || {};
                v.extend(e, {
                    _datasetIndex: n.index,
                    _index: t,
                    _scale: l,
                    _model: {
                        backgroundColor: C.backgroundColor,
                        borderColor: C.borderColor,
                        borderWidth: C.borderWidth,
                        borderAlign: C.borderAlign,
                        x: h,
                        y: f,
                        innerRadius: 0,
                        outerRadius: a ? M : x,
                        startAngle: a && c.animateRotate ? p : w,
                        endAngle: a && c.animateRotate ? p : _,
                        label: v.valueAtIndexOrDefault(u, t, u[t])
                    }
                }), e.pivot()
            },
            countVisibleElements: function() {
                var e = this.getDataset(),
                    t = this.getMeta(),
                    a = 0;
                return v.each(t.data, function(n, r) {
                    !isNaN(e.data[r]) && !n.hidden && a++
                }), a
            },
            setHoverStyle: function(e) {
                var t = e._model,
                    a = e._options,
                    n = v.getHoverColor,
                    r = v.valueOrDefault;
                e.$previousStyle = {
                    backgroundColor: t.backgroundColor,
                    borderColor: t.borderColor,
                    borderWidth: t.borderWidth
                }, t.backgroundColor = r(a.hoverBackgroundColor, n(a.backgroundColor)), t.borderColor = r(a.hoverBorderColor, n(a.borderColor)), t.borderWidth = r(a.hoverBorderWidth, a.borderWidth)
            },
            _computeAngle: function(e) {
                var t = this,
                    a = this.getMeta().count,
                    n = t.getDataset(),
                    r = t.getMeta();
                if (isNaN(n.data[e]) || r.data[e].hidden) return 0;
                var i = {
                    chart: t.chart,
                    dataIndex: e,
                    dataset: n,
                    datasetIndex: t.index
                };
                return Gi([t.chart.options.elements.arc.angle, 2 * Math.PI / a], i, e)
            }
        });
        A._set("pie", v.clone(A.doughnut)), A._set("pie", {
            cutoutPercentage: 0
        });
        var qi = wn,
            tt = v.valueOrDefault;
        A._set("radar", {
            spanGaps: !1,
            scale: {
                type: "radialLinear"
            },
            elements: {
                line: {
                    fill: "start",
                    tension: 0
                }
            }
        });
        var Ui = Ie.extend({
            datasetElementType: pe.Line,
            dataElementType: pe.Point,
            linkScales: v.noop,
            _datasetElementOptions: ["backgroundColor", "borderWidth", "borderColor", "borderCapStyle", "borderDash", "borderDashOffset", "borderJoinStyle", "fill"],
            _dataElementOptions: {
                backgroundColor: "pointBackgroundColor",
                borderColor: "pointBorderColor",
                borderWidth: "pointBorderWidth",
                hitRadius: "pointHitRadius",
                hoverBackgroundColor: "pointHoverBackgroundColor",
                hoverBorderColor: "pointHoverBorderColor",
                hoverBorderWidth: "pointHoverBorderWidth",
                hoverRadius: "pointHoverRadius",
                pointStyle: "pointStyle",
                radius: "pointRadius",
                rotation: "pointRotation"
            },
            _getIndexScaleId: function() {
                return this.chart.scale.id
            },
            _getValueScaleId: function() {
                return this.chart.scale.id
            },
            update: function(e) {
                var t = this,
                    a = t.getMeta(),
                    n = a.dataset,
                    r = a.data || [],
                    i = t.chart.scale,
                    o = t._config,
                    c, l;
                for (o.tension !== void 0 && o.lineTension === void 0 && (o.lineTension = o.tension), n._scale = i, n._datasetIndex = t.index, n._children = r, n._loop = !0, n._model = t._resolveDatasetElementOptions(n), n.pivot(), c = 0, l = r.length; c < l; ++c) t.updateElement(r[c], c, e);
                for (t.updateBezierControlPoints(), c = 0, l = r.length; c < l; ++c) r[c].pivot()
            },
            updateElement: function(e, t, a) {
                var n = this,
                    r = e.custom || {},
                    i = n.getDataset(),
                    o = n.chart.scale,
                    c = o.getPointPositionForValue(t, i.data[t]),
                    l = n._resolveDataElementOptions(e, t),
                    u = n.getMeta().dataset._model,
                    h = a ? o.xCenter : c.x,
                    f = a ? o.yCenter : c.y;
                e._scale = o, e._options = l, e._datasetIndex = n.index, e._index = t, e._model = {
                    x: h,
                    y: f,
                    skip: r.skip || isNaN(h) || isNaN(f),
                    radius: l.radius,
                    pointStyle: l.pointStyle,
                    rotation: l.rotation,
                    backgroundColor: l.backgroundColor,
                    borderColor: l.borderColor,
                    borderWidth: l.borderWidth,
                    tension: tt(r.tension, u ? u.tension : 0),
                    hitRadius: l.hitRadius
                }
            },
            _resolveDatasetElementOptions: function() {
                var e = this,
                    t = e._config,
                    a = e.chart.options,
                    n = Ie.prototype._resolveDatasetElementOptions.apply(e, arguments);
                return n.spanGaps = tt(t.spanGaps, a.spanGaps), n.tension = tt(t.lineTension, a.elements.line.tension), n
            },
            updateBezierControlPoints: function() {
                var e = this,
                    t = e.getMeta(),
                    a = e.chart.chartArea,
                    n = t.data || [],
                    r, i, o, c;
                t.dataset._model.spanGaps && (n = n.filter(function(u) {
                    return !u._model.skip
                }));

                function l(u, h, f) {
                    return Math.max(Math.min(u, f), h)
                }
                for (r = 0, i = n.length; r < i; ++r) o = n[r]._model, c = v.splineCurve(v.previousItem(n, r, !0)._model, o, v.nextItem(n, r, !0)._model, o.tension), o.controlPointPreviousX = l(c.previous.x, a.left, a.right), o.controlPointPreviousY = l(c.previous.y, a.top, a.bottom), o.controlPointNextX = l(c.next.x, a.left, a.right), o.controlPointNextY = l(c.next.y, a.top, a.bottom)
            },
            setHoverStyle: function(e) {
                var t = e._model,
                    a = e._options,
                    n = v.getHoverColor;
                e.$previousStyle = {
                    backgroundColor: t.backgroundColor,
                    borderColor: t.borderColor,
                    borderWidth: t.borderWidth,
                    radius: t.radius
                }, t.backgroundColor = tt(a.hoverBackgroundColor, n(a.backgroundColor)), t.borderColor = tt(a.hoverBorderColor, n(a.borderColor)), t.borderWidth = tt(a.hoverBorderWidth, a.borderWidth), t.radius = tt(a.hoverRadius, a.radius)
            }
        });
        A._set("scatter", {
            hover: {
                mode: "single"
            },
            scales: {
                xAxes: [{
                    id: "x-axis-1",
                    type: "linear",
                    position: "bottom"
                }],
                yAxes: [{
                    id: "y-axis-1",
                    type: "linear",
                    position: "left"
                }]
            },
            tooltips: {
                callbacks: {
                    title: function() {
                        return ""
                    },
                    label: function(e) {
                        return "(" + e.xLabel + ", " + e.yLabel + ")"
                    }
                }
            }
        }), A._set("global", {
            datasets: {
                scatter: {
                    showLine: !1
                }
            }
        });
        var Yi = _n,
            Mn = {
                bar: xn,
                bubble: zi,
                doughnut: wn,
                horizontalBar: Wi,
                line: _n,
                polarArea: $i,
                pie: qi,
                radar: Ui,
                scatter: Yi
            };

        function at(e, t) {
            return e.native ? {
                x: e.x,
                y: e.y
            } : v.getRelativePosition(e, t)
        }

        function Ct(e, t) {
            var a = e._getSortedVisibleDatasetMetas(),
                n, r, i, o, c, l;
            for (r = 0, o = a.length; r < o; ++r)
                for (n = a[r].data, i = 0, c = n.length; i < c; ++i) l = n[i], l._view.skip || t(l)
        }

        function ga(e, t) {
            var a = [];
            return Ct(e, function(n) {
                n.inRange(t.x, t.y) && a.push(n)
            }), a
        }

        function ba(e, t, a, n) {
            var r = Number.POSITIVE_INFINITY,
                i = [];
            return Ct(e, function(o) {
                if (!(a && !o.inRange(t.x, t.y))) {
                    var c = o.getCenterPoint(),
                        l = n(t, c);
                    l < r ? (i = [o], r = l) : l === r && i.push(o)
                }
            }), i
        }

        function ya(e) {
            var t = e.indexOf("x") !== -1,
                a = e.indexOf("y") !== -1;
            return function(n, r) {
                var i = t ? Math.abs(n.x - r.x) : 0,
                    o = a ? Math.abs(n.y - r.y) : 0;
                return Math.sqrt(Math.pow(i, 2) + Math.pow(o, 2))
            }
        }

        function xa(e, t, a) {
            var n = at(t, e);
            a.axis = a.axis || "x";
            var r = ya(a.axis),
                i = a.intersect ? ga(e, n) : ba(e, n, !1, r),
                o = [];
            return i.length ? (e._getSortedVisibleDatasetMetas().forEach(function(c) {
                var l = c.data[i[0]._index];
                l && !l._view.skip && o.push(l)
            }), o) : []
        }
        var dt = {
                modes: {
                    single: function(e, t) {
                        var a = at(t, e),
                            n = [];
                        return Ct(e, function(r) {
                            if (r.inRange(a.x, a.y)) return n.push(r), n
                        }), n.slice(0, 1)
                    },
                    label: xa,
                    index: xa,
                    dataset: function(e, t, a) {
                        var n = at(t, e);
                        a.axis = a.axis || "xy";
                        var r = ya(a.axis),
                            i = a.intersect ? ga(e, n) : ba(e, n, !1, r);
                        return i.length > 0 && (i = e.getDatasetMeta(i[0]._datasetIndex).data), i
                    },
                    "x-axis": function(e, t) {
                        return xa(e, t, {
                            intersect: !1
                        })
                    },
                    point: function(e, t) {
                        var a = at(t, e);
                        return ga(e, a)
                    },
                    nearest: function(e, t, a) {
                        var n = at(t, e);
                        a.axis = a.axis || "xy";
                        var r = ya(a.axis);
                        return ba(e, n, a.intersect, r)
                    },
                    x: function(e, t, a) {
                        var n = at(t, e),
                            r = [],
                            i = !1;
                        return Ct(e, function(o) {
                            o.inXRange(n.x) && r.push(o), o.inRange(n.x, n.y) && (i = !0)
                        }), a.intersect && !i && (r = []), r
                    },
                    y: function(e, t, a) {
                        var n = at(t, e),
                            r = [],
                            i = !1;
                        return Ct(e, function(o) {
                            o.inYRange(n.y) && r.push(o), o.inRange(n.x, n.y) && (i = !0)
                        }), a.intersect && !i && (r = []), r
                    }
                }
            },
            wa = v.extend;

        function Pt(e, t) {
            return v.where(e, function(a) {
                return a.pos === t
            })
        }

        function qt(e, t) {
            return e.sort(function(a, n) {
                var r = t ? n : a,
                    i = t ? a : n;
                return r.weight === i.weight ? r.index - i.index : r.weight - i.weight
            })
        }

        function Xi(e) {
            var t = [],
                a, n, r;
            for (a = 0, n = (e || []).length; a < n; ++a) r = e[a], t.push({
                index: a,
                box: r,
                pos: r.position,
                horizontal: r.isHorizontal(),
                weight: r.weight
            });
            return t
        }

        function Ki(e, t) {
            var a, n, r;
            for (a = 0, n = e.length; a < n; ++a) r = e[a], r.width = r.horizontal ? r.box.fullWidth && t.availableWidth : t.vBoxMaxWidth, r.height = r.horizontal && t.hBoxMaxHeight
        }

        function Ji(e) {
            var t = Xi(e),
                a = qt(Pt(t, "left"), !0),
                n = qt(Pt(t, "right")),
                r = qt(Pt(t, "top"), !0),
                i = qt(Pt(t, "bottom"));
            return {
                leftAndTop: a.concat(r),
                rightAndBottom: n.concat(i),
                chartArea: Pt(t, "chartArea"),
                vertical: a.concat(n),
                horizontal: r.concat(i)
            }
        }

        function In(e, t, a, n) {
            return Math.max(e[a], t[a]) + Math.max(e[n], t[n])
        }

        function Zi(e, t, a) {
            var n = a.box,
                r = e.maxPadding,
                i, o;
            if (a.size && (e[a.pos] -= a.size), a.size = a.horizontal ? n.height : n.width, e[a.pos] += a.size, n.getPadding) {
                var c = n.getPadding();
                r.top = Math.max(r.top, c.top), r.left = Math.max(r.left, c.left), r.bottom = Math.max(r.bottom, c.bottom), r.right = Math.max(r.right, c.right)
            }
            if (i = t.outerWidth - In(r, e, "left", "right"), o = t.outerHeight - In(r, e, "top", "bottom"), i !== e.w || o !== e.h) {
                e.w = i, e.h = o;
                var l = a.horizontal ? [i, e.w] : [o, e.h];
                return l[0] !== l[1] && (!isNaN(l[0]) || !isNaN(l[1]))
            }
        }

        function Qi(e) {
            var t = e.maxPadding;

            function a(n) {
                var r = Math.max(t[n] - e[n], 0);
                return e[n] += r, r
            }
            e.y += a("top"), e.x += a("left"), a("right"), a("bottom")
        }

        function eo(e, t) {
            var a = t.maxPadding;

            function n(r) {
                var i = {
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0
                };
                return r.forEach(function(o) {
                    i[o] = Math.max(t[o], a[o])
                }), i
            }
            return n(e ? ["left", "right"] : ["top", "bottom"])
        }

        function Ut(e, t, a) {
            var n = [],
                r, i, o, c, l, u;
            for (r = 0, i = e.length; r < i; ++r) o = e[r], c = o.box, c.update(o.width || t.w, o.height || t.h, eo(o.horizontal, t)), Zi(t, a, o) && (u = !0, n.length && (l = !0)), c.fullWidth || n.push(o);
            return l && Ut(n, t, a) || u
        }

        function Sn(e, t, a) {
            var n = a.padding,
                r = t.x,
                i = t.y,
                o, c, l, u;
            for (o = 0, c = e.length; o < c; ++o) l = e[o], u = l.box, l.horizontal ? (u.left = u.fullWidth ? n.left : t.left, u.right = u.fullWidth ? a.outerWidth - n.right : t.left + t.w, u.top = i, u.bottom = i + u.height, u.width = u.right - u.left, i = u.bottom) : (u.left = r, u.right = r + u.width, u.top = t.top, u.bottom = t.top + t.h, u.height = u.bottom - u.top, r = u.right);
            t.x = r, t.y = i
        }
        A._set("global", {
            layout: {
                padding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                }
            }
        });
        var Se = {
                defaults: {},
                addBox: function(e, t) {
                    e.boxes || (e.boxes = []), t.fullWidth = t.fullWidth || !1, t.position = t.position || "top", t.weight = t.weight || 0, t._layers = t._layers || function() {
                        return [{
                            z: 0,
                            draw: function() {
                                t.draw.apply(t, arguments)
                            }
                        }]
                    }, e.boxes.push(t)
                },
                removeBox: function(e, t) {
                    var a = e.boxes ? e.boxes.indexOf(t) : -1;
                    a !== -1 && e.boxes.splice(a, 1)
                },
                configure: function(e, t, a) {
                    for (var n = ["fullWidth", "position", "weight"], r = n.length, i = 0, o; i < r; ++i) o = n[i], a.hasOwnProperty(o) && (t[o] = a[o])
                },
                update: function(e, t, a) {
                    if (!!e) {
                        var n = e.options.layout || {},
                            r = v.options.toPadding(n.padding),
                            i = t - r.width,
                            o = a - r.height,
                            c = Ji(e.boxes),
                            l = c.vertical,
                            u = c.horizontal,
                            h = Object.freeze({
                                outerWidth: t,
                                outerHeight: a,
                                padding: r,
                                availableWidth: i,
                                vBoxMaxWidth: i / 2 / l.length,
                                hBoxMaxHeight: o / 2
                            }),
                            f = wa({
                                maxPadding: wa({}, r),
                                w: i,
                                h: o,
                                x: r.left,
                                y: r.top
                            }, r);
                        Ki(l.concat(u), h), Ut(l, f, h), Ut(u, f, h) && Ut(l, f, h), Qi(f), Sn(c.leftAndTop, f, h), f.x += f.w, f.y += f.h, Sn(c.rightAndBottom, f, h), e.chartArea = {
                            left: f.left,
                            top: f.top,
                            right: f.left + f.w,
                            bottom: f.top + f.h
                        }, v.each(c.chartArea, function(p) {
                            var x = p.box;
                            wa(x, e.chartArea), x.update(f.w, f.h)
                        })
                    }
                }
            },
            to = {
                acquireContext: function(e) {
                    return e && e.canvas && (e = e.canvas), e && e.getContext("2d") || null
                }
            },
            ao = `/*\r
 * DOM element rendering detection\r
 * https://davidwalsh.name/detect-node-insertion\r
 */\r
@keyframes chartjs-render-animation {\r
	from { opacity: 0.99; }\r
	to { opacity: 1; }\r
}\r
\r
.chartjs-render-monitor {\r
	animation: chartjs-render-animation 0.001s;\r
}\r
\r
/*\r
 * DOM element resizing detection\r
 * https://github.com/marcj/css-element-queries\r
 */\r
.chartjs-size-monitor,\r
.chartjs-size-monitor-expand,\r
.chartjs-size-monitor-shrink {\r
	position: absolute;\r
	direction: ltr;\r
	left: 0;\r
	top: 0;\r
	right: 0;\r
	bottom: 0;\r
	overflow: hidden;\r
	pointer-events: none;\r
	visibility: hidden;\r
	z-index: -1;\r
}\r
\r
.chartjs-size-monitor-expand > div {\r
	position: absolute;\r
	width: 1000000px;\r
	height: 1000000px;\r
	left: 0;\r
	top: 0;\r
}\r
\r
.chartjs-size-monitor-shrink > div {\r
	position: absolute;\r
	width: 200%;\r
	height: 200%;\r
	left: 0;\r
	top: 0;\r
}\r
`,
            no = Object.freeze({
                __proto__: null,
                default: ao
            }),
            ro = k(no),
            ue = "$chartjs",
            ka = "chartjs-",
            _a = ka + "size-monitor",
            Cn = ka + "render-monitor",
            io = ka + "render-animation",
            Pn = ["animationstart", "webkitAnimationStart"],
            oo = {
                touchstart: "mousedown",
                touchmove: "mousemove",
                touchend: "mouseup",
                pointerenter: "mouseenter",
                pointerdown: "mousedown",
                pointermove: "mousemove",
                pointerup: "mouseup",
                pointerleave: "mouseout",
                pointerout: "mouseout"
            };

        function Tn(e, t) {
            var a = v.getStyle(e, t),
                n = a && a.match(/^(\d+)(\.\d+)?px$/);
            return n ? Number(n[1]) : void 0
        }

        function so(e, t) {
            var a = e.style,
                n = e.getAttribute("height"),
                r = e.getAttribute("width");
            if (e[ue] = {
                    initial: {
                        height: n,
                        width: r,
                        style: {
                            display: a.display,
                            height: a.height,
                            width: a.width
                        }
                    }
                }, a.display = a.display || "block", r === null || r === "") {
                var i = Tn(e, "width");
                i !== void 0 && (e.width = i)
            }
            if (n === null || n === "")
                if (e.style.height === "") e.height = e.width / (t.options.aspectRatio || 2);
                else {
                    var o = Tn(e, "height");
                    i !== void 0 && (e.height = o)
                }
            return e
        }
        var lo = function() {
                var e = !1;
                try {
                    var t = Object.defineProperty({}, "passive", {
                        get: function() {
                            e = !0
                        }
                    });
                    window.addEventListener("e", null, t)
                } catch (a) {}
                return e
            }(),
            Nn = lo ? {
                passive: !0
            } : !1;

        function Tt(e, t, a) {
            e.addEventListener(t, a, Nn)
        }

        function Ma(e, t, a) {
            e.removeEventListener(t, a, Nn)
        }

        function Ia(e, t, a, n, r) {
            return {
                type: e,
                chart: t,
                native: r || null,
                x: a !== void 0 ? a : null,
                y: n !== void 0 ? n : null
            }
        }

        function co(e, t) {
            var a = oo[e.type] || e.type,
                n = v.getRelativePosition(e, t);
            return Ia(a, t, n.x, n.y, e)
        }

        function uo(e, t) {
            var a = !1,
                n = [];
            return function() {
                n = Array.prototype.slice.call(arguments), t = t || this, a || (a = !0, v.requestAnimFrame.call(window, function() {
                    a = !1, e.apply(t, n)
                }))
            }
        }

        function Nt(e) {
            var t = document.createElement("div");
            return t.className = e || "", t
        }

        function ho(e) {
            var t = 1e6,
                a = Nt(_a),
                n = Nt(_a + "-expand"),
                r = Nt(_a + "-shrink");
            n.appendChild(Nt()), r.appendChild(Nt()), a.appendChild(n), a.appendChild(r), a._reset = function() {
                n.scrollLeft = t, n.scrollTop = t, r.scrollLeft = t, r.scrollTop = t
            };
            var i = function() {
                a._reset(), e()
            };
            return Tt(n, "scroll", i.bind(n, "expand")), Tt(r, "scroll", i.bind(r, "shrink")), a
        }

        function fo(e, t) {
            var a = e[ue] || (e[ue] = {}),
                n = a.renderProxy = function(r) {
                    r.animationName === io && t()
                };
            v.each(Pn, function(r) {
                Tt(e, r, n)
            }), a.reflow = !!e.offsetParent, e.classList.add(Cn)
        }

        function vo(e) {
            var t = e[ue] || {},
                a = t.renderProxy;
            a && (v.each(Pn, function(n) {
                Ma(e, n, a)
            }), delete t.renderProxy), e.classList.remove(Cn)
        }

        function po(e, t, a) {
            var n = e[ue] || (e[ue] = {}),
                r = n.resizer = ho(uo(function() {
                    if (n.resizer) {
                        var i = a.options.maintainAspectRatio && e.parentNode,
                            o = i ? i.clientWidth : 0;
                        t(Ia("resize", a)), i && i.clientWidth < o && a.canvas && t(Ia("resize", a))
                    }
                }));
            fo(e, function() {
                if (n.resizer) {
                    var i = e.parentNode;
                    i && i !== r.parentNode && i.insertBefore(r, i.firstChild), r._reset()
                }
            })
        }

        function mo(e) {
            var t = e[ue] || {},
                a = t.resizer;
            delete t.resizer, vo(e), a && a.parentNode && a.parentNode.removeChild(a)
        }

        function go(e, t) {
            var a = e[ue] || (e[ue] = {});
            if (!a.containsStyles) {
                a.containsStyles = !0, t = `/* Chart.js */
` + t;
                var n = document.createElement("style");
                n.setAttribute("type", "text/css"), n.appendChild(document.createTextNode(t)), e.appendChild(n)
            }
        }
        var Dn = {
            disableCSSInjection: !1,
            _enabled: typeof window < "u" && typeof document < "u",
            _ensureLoaded: function(e) {
                if (!this.disableCSSInjection) {
                    var t = e.getRootNode ? e.getRootNode() : document,
                        a = t.host ? t : document.head;
                    go(a, ro)
                }
            },
            acquireContext: function(e, t) {
                typeof e == "string" ? e = document.getElementById(e) : e.length && (e = e[0]), e && e.canvas && (e = e.canvas);
                var a = e && e.getContext && e.getContext("2d");
                return a && a.canvas === e ? (this._ensureLoaded(e), so(e, t), a) : null
            },
            releaseContext: function(e) {
                var t = e.canvas;
                if (!!t[ue]) {
                    var a = t[ue].initial;
                    ["height", "width"].forEach(function(n) {
                        var r = a[n];
                        v.isNullOrUndef(r) ? t.removeAttribute(n) : t.setAttribute(n, r)
                    }), v.each(a.style || {}, function(n, r) {
                        t.style[r] = n
                    }), t.width = t.width, delete t[ue]
                }
            },
            addEventListener: function(e, t, a) {
                var n = e.canvas;
                if (t === "resize") {
                    po(n, a, e);
                    return
                }
                var r = a[ue] || (a[ue] = {}),
                    i = r.proxies || (r.proxies = {}),
                    o = i[e.id + "_" + t] = function(c) {
                        a(co(c, e))
                    };
                Tt(n, t, o)
            },
            removeEventListener: function(e, t, a) {
                var n = e.canvas;
                if (t === "resize") {
                    mo(n);
                    return
                }
                var r = a[ue] || {},
                    i = r.proxies || {},
                    o = i[e.id + "_" + t];
                !o || Ma(n, t, o)
            }
        };
        v.addEvent = Tt, v.removeEvent = Ma;
        var bo = Dn._enabled ? Dn : to,
            ht = v.extend({
                initialize: function() {},
                acquireContext: function() {},
                releaseContext: function() {},
                addEventListener: function() {},
                removeEventListener: function() {}
            }, bo);
        A._set("global", {
            plugins: {}
        });
        var K = {
                _plugins: [],
                _cacheId: 0,
                register: function(e) {
                    var t = this._plugins;
                    [].concat(e).forEach(function(a) {
                        t.indexOf(a) === -1 && t.push(a)
                    }), this._cacheId++
                },
                unregister: function(e) {
                    var t = this._plugins;
                    [].concat(e).forEach(function(a) {
                        var n = t.indexOf(a);
                        n !== -1 && t.splice(n, 1)
                    }), this._cacheId++
                },
                clear: function() {
                    this._plugins = [], this._cacheId++
                },
                count: function() {
                    return this._plugins.length
                },
                getAll: function() {
                    return this._plugins
                },
                notify: function(e, t, a) {
                    var n = this.descriptors(e),
                        r = n.length,
                        i, o, c, l, u;
                    for (i = 0; i < r; ++i)
                        if (o = n[i], c = o.plugin, u = c[t], typeof u == "function" && (l = [e].concat(a || []), l.push(o.options), u.apply(c, l) === !1)) return !1;
                    return !0
                },
                descriptors: function(e) {
                    var t = e.$plugins || (e.$plugins = {});
                    if (t.id === this._cacheId) return t.descriptors;
                    var a = [],
                        n = [],
                        r = e && e.config || {},
                        i = r.options && r.options.plugins || {};
                    return this._plugins.concat(r.plugins || []).forEach(function(o) {
                        var c = a.indexOf(o);
                        if (c === -1) {
                            var l = o.id,
                                u = i[l];
                            u !== !1 && (u === !0 && (u = v.clone(A.global.plugins[l])), a.push(o), n.push({
                                plugin: o,
                                options: u || {}
                            }))
                        }
                    }), t.descriptors = n, t.id = this._cacheId, n
                },
                _invalidate: function(e) {
                    delete e.$plugins
                }
            },
            Dt = {
                constructors: {},
                defaults: {},
                registerScaleType: function(e, t, a) {
                    this.constructors[e] = t, this.defaults[e] = v.clone(a)
                },
                getScaleConstructor: function(e) {
                    return this.constructors.hasOwnProperty(e) ? this.constructors[e] : void 0
                },
                getScaleDefaults: function(e) {
                    return this.defaults.hasOwnProperty(e) ? v.merge(Object.create(null), [A.scale, this.defaults[e]]) : {}
                },
                updateScaleDefaults: function(e, t) {
                    var a = this;
                    a.defaults.hasOwnProperty(e) && (a.defaults[e] = v.extend(a.defaults[e], t))
                },
                addScalesToLayout: function(e) {
                    v.each(e.scales, function(t) {
                        t.fullWidth = t.options.fullWidth, t.position = t.options.position, t.weight = t.options.weight, Se.addBox(e, t)
                    })
                }
            },
            He = v.valueOrDefault,
            Sa = v.rtl.getRtlAdapter;
        A._set("global", {
            tooltips: {
                enabled: !0,
                custom: null,
                mode: "nearest",
                position: "average",
                intersect: !0,
                backgroundColor: "rgba(0,0,0,0.8)",
                titleFontStyle: "bold",
                titleSpacing: 2,
                titleMarginBottom: 6,
                titleFontColor: "#fff",
                titleAlign: "left",
                bodySpacing: 2,
                bodyFontColor: "#fff",
                bodyAlign: "left",
                footerFontStyle: "bold",
                footerSpacing: 2,
                footerMarginTop: 6,
                footerFontColor: "#fff",
                footerAlign: "left",
                yPadding: 6,
                xPadding: 6,
                caretPadding: 2,
                caretSize: 5,
                cornerRadius: 6,
                multiKeyBackground: "#fff",
                displayColors: !0,
                borderColor: "rgba(0,0,0,0)",
                borderWidth: 0,
                callbacks: {
                    beforeTitle: v.noop,
                    title: function(e, t) {
                        var a = "",
                            n = t.labels,
                            r = n ? n.length : 0;
                        if (e.length > 0) {
                            var i = e[0];
                            i.label ? a = i.label : i.xLabel ? a = i.xLabel : r > 0 && i.index < r && (a = n[i.index])
                        }
                        return a
                    },
                    afterTitle: v.noop,
                    beforeBody: v.noop,
                    beforeLabel: v.noop,
                    label: function(e, t) {
                        var a = t.datasets[e.datasetIndex].label || "";
                        return a && (a += ": "), v.isNullOrUndef(e.value) ? a += e.yLabel : a += e.value, a
                    },
                    labelColor: function(e, t) {
                        var a = t.getDatasetMeta(e.datasetIndex),
                            n = a.data[e.index],
                            r = n._view;
                        return {
                            borderColor: r.borderColor,
                            backgroundColor: r.backgroundColor
                        }
                    },
                    labelTextColor: function() {
                        return this._options.bodyFontColor
                    },
                    afterLabel: v.noop,
                    afterBody: v.noop,
                    beforeFooter: v.noop,
                    footer: v.noop,
                    afterFooter: v.noop
                }
            }
        });
        var On = {
            average: function(e) {
                if (!e.length) return !1;
                var t, a, n = 0,
                    r = 0,
                    i = 0;
                for (t = 0, a = e.length; t < a; ++t) {
                    var o = e[t];
                    if (o && o.hasValue()) {
                        var c = o.tooltipPosition();
                        n += c.x, r += c.y, ++i
                    }
                }
                return {
                    x: n / i,
                    y: r / i
                }
            },
            nearest: function(e, t) {
                var a = t.x,
                    n = t.y,
                    r = Number.POSITIVE_INFINITY,
                    i, o, c;
                for (i = 0, o = e.length; i < o; ++i) {
                    var l = e[i];
                    if (l && l.hasValue()) {
                        var u = l.getCenterPoint(),
                            h = v.distanceBetweenPoints(t, u);
                        h < r && (r = h, c = l)
                    }
                }
                if (c) {
                    var f = c.tooltipPosition();
                    a = f.x, n = f.y
                }
                return {
                    x: a,
                    y: n
                }
            }
        };

        function ze(e, t) {
            return t && (v.isArray(t) ? Array.prototype.push.apply(e, t) : e.push(t)), e
        }

        function Ve(e) {
            return (typeof e == "string" || e instanceof String) && e.indexOf(`
`) > -1 ? e.split(`
`) : e
        }

        function yo(e) {
            var t = e._xScale,
                a = e._yScale || e._scale,
                n = e._index,
                r = e._datasetIndex,
                i = e._chart.getDatasetMeta(r).controller,
                o = i._getIndexScale(),
                c = i._getValueScale();
            return {
                xLabel: t ? t.getLabelForIndex(n, r) : "",
                yLabel: a ? a.getLabelForIndex(n, r) : "",
                label: o ? "" + o.getLabelForIndex(n, r) : "",
                value: c ? "" + c.getLabelForIndex(n, r) : "",
                index: n,
                datasetIndex: r,
                x: e._model.x,
                y: e._model.y
            }
        }

        function An(e) {
            var t = A.global;
            return {
                xPadding: e.xPadding,
                yPadding: e.yPadding,
                xAlign: e.xAlign,
                yAlign: e.yAlign,
                rtl: e.rtl,
                textDirection: e.textDirection,
                bodyFontColor: e.bodyFontColor,
                _bodyFontFamily: He(e.bodyFontFamily, t.defaultFontFamily),
                _bodyFontStyle: He(e.bodyFontStyle, t.defaultFontStyle),
                _bodyAlign: e.bodyAlign,
                bodyFontSize: He(e.bodyFontSize, t.defaultFontSize),
                bodySpacing: e.bodySpacing,
                titleFontColor: e.titleFontColor,
                _titleFontFamily: He(e.titleFontFamily, t.defaultFontFamily),
                _titleFontStyle: He(e.titleFontStyle, t.defaultFontStyle),
                titleFontSize: He(e.titleFontSize, t.defaultFontSize),
                _titleAlign: e.titleAlign,
                titleSpacing: e.titleSpacing,
                titleMarginBottom: e.titleMarginBottom,
                footerFontColor: e.footerFontColor,
                _footerFontFamily: He(e.footerFontFamily, t.defaultFontFamily),
                _footerFontStyle: He(e.footerFontStyle, t.defaultFontStyle),
                footerFontSize: He(e.footerFontSize, t.defaultFontSize),
                _footerAlign: e.footerAlign,
                footerSpacing: e.footerSpacing,
                footerMarginTop: e.footerMarginTop,
                caretSize: e.caretSize,
                cornerRadius: e.cornerRadius,
                backgroundColor: e.backgroundColor,
                opacity: 0,
                legendColorBackground: e.multiKeyBackground,
                displayColors: e.displayColors,
                borderColor: e.borderColor,
                borderWidth: e.borderWidth
            }
        }

        function xo(e, t) {
            var a = e._chart.ctx,
                n = t.yPadding * 2,
                r = 0,
                i = t.body,
                o = i.reduce(function(w, _) {
                    return w + _.before.length + _.lines.length + _.after.length
                }, 0);
            o += t.beforeBody.length + t.afterBody.length;
            var c = t.title.length,
                l = t.footer.length,
                u = t.titleFontSize,
                h = t.bodyFontSize,
                f = t.footerFontSize;
            n += c * u, n += c ? (c - 1) * t.titleSpacing : 0, n += c ? t.titleMarginBottom : 0, n += o * h, n += o ? (o - 1) * t.bodySpacing : 0, n += l ? t.footerMarginTop : 0, n += l * f, n += l ? (l - 1) * t.footerSpacing : 0;
            var p = 0,
                x = function(w) {
                    r = Math.max(r, a.measureText(w).width + p)
                };
            return a.font = v.fontString(u, t._titleFontStyle, t._titleFontFamily), v.each(t.title, x), a.font = v.fontString(h, t._bodyFontStyle, t._bodyFontFamily), v.each(t.beforeBody.concat(t.afterBody), x), p = t.displayColors ? h + 2 : 0, v.each(i, function(w) {
                v.each(w.before, x), v.each(w.lines, x), v.each(w.after, x)
            }), p = 0, a.font = v.fontString(f, t._footerFontStyle, t._footerFontFamily), v.each(t.footer, x), r += 2 * t.xPadding, {
                width: r,
                height: n
            }
        }

        function wo(e, t) {
            var a = e._model,
                n = e._chart,
                r = e._chart.chartArea,
                i = "center",
                o = "center";
            a.y < t.height ? o = "top" : a.y > n.height - t.height && (o = "bottom");
            var c, l, u, h, f, p = (r.left + r.right) / 2,
                x = (r.top + r.bottom) / 2;
            o === "center" ? (c = function(_) {
                return _ <= p
            }, l = function(_) {
                return _ > p
            }) : (c = function(_) {
                return _ <= t.width / 2
            }, l = function(_) {
                return _ >= n.width - t.width / 2
            }), u = function(_) {
                return _ + t.width + a.caretSize + a.caretPadding > n.width
            }, h = function(_) {
                return _ - t.width - a.caretSize - a.caretPadding < 0
            }, f = function(_) {
                return _ <= x ? "top" : "bottom"
            }, c(a.x) ? (i = "left", u(a.x) && (i = "center", o = f(a.y))) : l(a.x) && (i = "right", h(a.x) && (i = "center", o = f(a.y)));
            var w = e._options;
            return {
                xAlign: w.xAlign ? w.xAlign : i,
                yAlign: w.yAlign ? w.yAlign : o
            }
        }

        function ko(e, t, a, n) {
            var r = e.x,
                i = e.y,
                o = e.caretSize,
                c = e.caretPadding,
                l = e.cornerRadius,
                u = a.xAlign,
                h = a.yAlign,
                f = o + c,
                p = l + c;
            return u === "right" ? r -= t.width : u === "center" && (r -= t.width / 2, r + t.width > n.width && (r = n.width - t.width), r < 0 && (r = 0)), h === "top" ? i += f : h === "bottom" ? i -= t.height + f : i -= t.height / 2, h === "center" ? u === "left" ? r += f : u === "right" && (r -= f) : u === "left" ? r -= p : u === "right" && (r += p), {
                x: r,
                y: i
            }
        }

        function Yt(e, t) {
            return t === "center" ? e.x + e.width / 2 : t === "right" ? e.x + e.width - e.xPadding : e.x + e.xPadding
        }

        function Bn(e) {
            return ze([], Ve(e))
        }
        var _o = Le.extend({
                initialize: function() {
                    this._model = An(this._options), this._lastActive = []
                },
                getTitle: function() {
                    var e = this,
                        t = e._options,
                        a = t.callbacks,
                        n = a.beforeTitle.apply(e, arguments),
                        r = a.title.apply(e, arguments),
                        i = a.afterTitle.apply(e, arguments),
                        o = [];
                    return o = ze(o, Ve(n)), o = ze(o, Ve(r)), o = ze(o, Ve(i)), o
                },
                getBeforeBody: function() {
                    return Bn(this._options.callbacks.beforeBody.apply(this, arguments))
                },
                getBody: function(e, t) {
                    var a = this,
                        n = a._options.callbacks,
                        r = [];
                    return v.each(e, function(i) {
                        var o = {
                            before: [],
                            lines: [],
                            after: []
                        };
                        ze(o.before, Ve(n.beforeLabel.call(a, i, t))), ze(o.lines, n.label.call(a, i, t)), ze(o.after, Ve(n.afterLabel.call(a, i, t))), r.push(o)
                    }), r
                },
                getAfterBody: function() {
                    return Bn(this._options.callbacks.afterBody.apply(this, arguments))
                },
                getFooter: function() {
                    var e = this,
                        t = e._options.callbacks,
                        a = t.beforeFooter.apply(e, arguments),
                        n = t.footer.apply(e, arguments),
                        r = t.afterFooter.apply(e, arguments),
                        i = [];
                    return i = ze(i, Ve(a)), i = ze(i, Ve(n)), i = ze(i, Ve(r)), i
                },
                update: function(e) {
                    var t = this,
                        a = t._options,
                        n = t._model,
                        r = t._model = An(a),
                        i = t._active,
                        o = t._data,
                        c = {
                            xAlign: n.xAlign,
                            yAlign: n.yAlign
                        },
                        l = {
                            x: n.x,
                            y: n.y
                        },
                        u = {
                            width: n.width,
                            height: n.height
                        },
                        h = {
                            x: n.caretX,
                            y: n.caretY
                        },
                        f, p;
                    if (i.length) {
                        r.opacity = 1;
                        var x = [],
                            w = [];
                        h = On[a.position].call(t, i, t._eventPosition);
                        var _ = [];
                        for (f = 0, p = i.length; f < p; ++f) _.push(yo(i[f]));
                        a.filter && (_ = _.filter(function(M) {
                            return a.filter(M, o)
                        })), a.itemSort && (_ = _.sort(function(M, C) {
                            return a.itemSort(M, C, o)
                        })), v.each(_, function(M) {
                            x.push(a.callbacks.labelColor.call(t, M, t._chart)), w.push(a.callbacks.labelTextColor.call(t, M, t._chart))
                        }), r.title = t.getTitle(_, o), r.beforeBody = t.getBeforeBody(_, o), r.body = t.getBody(_, o), r.afterBody = t.getAfterBody(_, o), r.footer = t.getFooter(_, o), r.x = h.x, r.y = h.y, r.caretPadding = a.caretPadding, r.labelColors = x, r.labelTextColors = w, r.dataPoints = _, u = xo(this, r), c = wo(this, u), l = ko(r, u, c, t._chart)
                    } else r.opacity = 0;
                    return r.xAlign = c.xAlign, r.yAlign = c.yAlign, r.x = l.x, r.y = l.y, r.width = u.width, r.height = u.height, r.caretX = h.x, r.caretY = h.y, t._model = r, e && a.custom && a.custom.call(t, r), t
                },
                drawCaret: function(e, t) {
                    var a = this._chart.ctx,
                        n = this._view,
                        r = this.getCaretPosition(e, t, n);
                    a.lineTo(r.x1, r.y1), a.lineTo(r.x2, r.y2), a.lineTo(r.x3, r.y3)
                },
                getCaretPosition: function(e, t, a) {
                    var n, r, i, o, c, l, u = a.caretSize,
                        h = a.cornerRadius,
                        f = a.xAlign,
                        p = a.yAlign,
                        x = e.x,
                        w = e.y,
                        _ = t.width,
                        M = t.height;
                    if (p === "center") c = w + M / 2, f === "left" ? (n = x, r = n - u, i = n, o = c + u, l = c - u) : (n = x + _, r = n + u, i = n, o = c - u, l = c + u);
                    else if (f === "left" ? (r = x + h + u, n = r - u, i = r + u) : f === "right" ? (r = x + _ - h - u, n = r - u, i = r + u) : (r = a.caretX, n = r - u, i = r + u), p === "top") o = w, c = o - u, l = o;
                    else {
                        o = w + M, c = o + u, l = o;
                        var C = i;
                        i = n, n = C
                    }
                    return {
                        x1: n,
                        x2: r,
                        x3: i,
                        y1: o,
                        y2: c,
                        y3: l
                    }
                },
                drawTitle: function(e, t, a) {
                    var n = t.title,
                        r = n.length,
                        i, o, c;
                    if (r) {
                        var l = Sa(t.rtl, t.x, t.width);
                        for (e.x = Yt(t, t._titleAlign), a.textAlign = l.textAlign(t._titleAlign), a.textBaseline = "middle", i = t.titleFontSize, o = t.titleSpacing, a.fillStyle = t.titleFontColor, a.font = v.fontString(i, t._titleFontStyle, t._titleFontFamily), c = 0; c < r; ++c) a.fillText(n[c], l.x(e.x), e.y + i / 2), e.y += i + o, c + 1 === r && (e.y += t.titleMarginBottom - o)
                    }
                },
                drawBody: function(e, t, a) {
                    var n = t.bodyFontSize,
                        r = t.bodySpacing,
                        i = t._bodyAlign,
                        o = t.body,
                        c = t.displayColors,
                        l = 0,
                        u = c ? Yt(t, "left") : 0,
                        h = Sa(t.rtl, t.x, t.width),
                        f = function($) {
                            a.fillText($, h.x(e.x + l), e.y + n / 2), e.y += n + r
                        },
                        p, x, w, _, M, C, T, N, W = h.textAlign(i);
                    for (a.textAlign = i, a.textBaseline = "middle", a.font = v.fontString(n, t._bodyFontStyle, t._bodyFontFamily), e.x = Yt(t, W), a.fillStyle = t.bodyFontColor, v.each(t.beforeBody, f), l = c && W !== "right" ? i === "center" ? n / 2 + 1 : n + 2 : 0, M = 0, T = o.length; M < T; ++M) {
                        for (p = o[M], x = t.labelTextColors[M], w = t.labelColors[M], a.fillStyle = x, v.each(p.before, f), _ = p.lines, C = 0, N = _.length; C < N; ++C) {
                            if (c) {
                                var E = h.x(u);
                                a.fillStyle = t.legendColorBackground, a.fillRect(h.leftForLtr(E, n), e.y, n, n), a.lineWidth = 1, a.strokeStyle = w.borderColor, a.strokeRect(h.leftForLtr(E, n), e.y, n, n), a.fillStyle = w.backgroundColor, a.fillRect(h.leftForLtr(h.xPlus(E, 1), n - 2), e.y + 1, n - 2, n - 2), a.fillStyle = x
                            }
                            f(_[C])
                        }
                        v.each(p.after, f)
                    }
                    l = 0, v.each(t.afterBody, f), e.y -= r
                },
                drawFooter: function(e, t, a) {
                    var n = t.footer,
                        r = n.length,
                        i, o;
                    if (r) {
                        var c = Sa(t.rtl, t.x, t.width);
                        for (e.x = Yt(t, t._footerAlign), e.y += t.footerMarginTop, a.textAlign = c.textAlign(t._footerAlign), a.textBaseline = "middle", i = t.footerFontSize, a.fillStyle = t.footerFontColor, a.font = v.fontString(i, t._footerFontStyle, t._footerFontFamily), o = 0; o < r; ++o) a.fillText(n[o], c.x(e.x), e.y + i / 2), e.y += i + t.footerSpacing
                    }
                },
                drawBackground: function(e, t, a, n) {
                    a.fillStyle = t.backgroundColor, a.strokeStyle = t.borderColor, a.lineWidth = t.borderWidth;
                    var r = t.xAlign,
                        i = t.yAlign,
                        o = e.x,
                        c = e.y,
                        l = n.width,
                        u = n.height,
                        h = t.cornerRadius;
                    a.beginPath(), a.moveTo(o + h, c), i === "top" && this.drawCaret(e, n), a.lineTo(o + l - h, c), a.quadraticCurveTo(o + l, c, o + l, c + h), i === "center" && r === "right" && this.drawCaret(e, n), a.lineTo(o + l, c + u - h), a.quadraticCurveTo(o + l, c + u, o + l - h, c + u), i === "bottom" && this.drawCaret(e, n), a.lineTo(o + h, c + u), a.quadraticCurveTo(o, c + u, o, c + u - h), i === "center" && r === "left" && this.drawCaret(e, n), a.lineTo(o, c + h), a.quadraticCurveTo(o, c, o + h, c), a.closePath(), a.fill(), t.borderWidth > 0 && a.stroke()
                },
                draw: function() {
                    var e = this._chart.ctx,
                        t = this._view;
                    if (t.opacity !== 0) {
                        var a = {
                                width: t.width,
                                height: t.height
                            },
                            n = {
                                x: t.x,
                                y: t.y
                            },
                            r = Math.abs(t.opacity < .001) ? 0 : t.opacity,
                            i = t.title.length || t.beforeBody.length || t.body.length || t.afterBody.length || t.footer.length;
                        this._options.enabled && i && (e.save(), e.globalAlpha = r, this.drawBackground(n, t, e, a), n.y += t.yPadding, v.rtl.overrideTextDirection(e, t.textDirection), this.drawTitle(n, t, e), this.drawBody(n, t, e), this.drawFooter(n, t, e), v.rtl.restoreTextDirection(e, t.textDirection), e.restore())
                    }
                },
                handleEvent: function(e) {
                    var t = this,
                        a = t._options,
                        n = !1;
                    return t._lastActive = t._lastActive || [], e.type === "mouseout" ? t._active = [] : (t._active = t._chart.getElementsAtEventForMode(e, a.mode, a), a.reverse && t._active.reverse()), n = !v.arrayEquals(t._active, t._lastActive), n && (t._lastActive = t._active, (a.enabled || a.custom) && (t._eventPosition = {
                        x: e.x,
                        y: e.y
                    }, t.update(!0), t.pivot())), n
                }
            }),
            Mo = On,
            Ca = _o;
        Ca.positioners = Mo;
        var Pa = v.valueOrDefault;
        A._set("global", {
            elements: {},
            events: ["mousemove", "mouseout", "click", "touchstart", "touchmove"],
            hover: {
                onHover: null,
                mode: "nearest",
                intersect: !0,
                animationDuration: 400
            },
            onClick: null,
            maintainAspectRatio: !0,
            responsive: !0,
            responsiveAnimationDuration: 0
        });

        function Rn() {
            return v.merge(Object.create(null), [].slice.call(arguments), {
                merger: function(e, t, a, n) {
                    if (e === "xAxes" || e === "yAxes") {
                        var r = a[e].length,
                            i, o, c;
                        for (t[e] || (t[e] = []), i = 0; i < r; ++i) c = a[e][i], o = Pa(c.type, e === "xAxes" ? "category" : "linear"), i >= t[e].length && t[e].push({}), !t[e][i].type || c.type && c.type !== t[e][i].type ? v.merge(t[e][i], [Dt.getScaleDefaults(o), c]) : v.merge(t[e][i], c)
                    } else v._merger(e, t, a, n)
                }
            })
        }

        function Ta() {
            return v.merge(Object.create(null), [].slice.call(arguments), {
                merger: function(e, t, a, n) {
                    var r = t[e] || Object.create(null),
                        i = a[e];
                    e === "scales" ? t[e] = Rn(r, i) : e === "scale" ? t[e] = v.merge(r, [Dt.getScaleDefaults(i.type), i]) : v._merger(e, t, a, n)
                }
            })
        }

        function Io(e) {
            e = e || Object.create(null);
            var t = e.data = e.data || {};
            return t.datasets = t.datasets || [], t.labels = t.labels || [], e.options = Ta(A.global, A[e.type], e.options || {}), e
        }

        function So(e) {
            var t = e.options;
            v.each(e.scales, function(a) {
                Se.removeBox(e, a)
            }), t = Ta(A.global, A[e.config.type], t), e.options = e.config.options = t, e.ensureScalesHaveIDs(), e.buildOrUpdateScales(), e.tooltip._options = t.tooltips, e.tooltip.initialize()
        }

        function Fn(e, t, a) {
            var n, r = function(i) {
                return i.id === n
            };
            do n = t + a++; while (v.findIndex(e, r) >= 0);
            return n
        }

        function Ln(e) {
            return e === "top" || e === "bottom"
        }

        function En(e, t) {
            return function(a, n) {
                return a[e] === n[e] ? a[t] - n[t] : a[e] - n[e]
            }
        }
        var Ye = function(e, t) {
            return this.construct(e, t), this
        };
        v.extend(Ye.prototype, {
            construct: function(e, t) {
                var a = this;
                t = Io(t);
                var n = ht.acquireContext(e, t),
                    r = n && n.canvas,
                    i = r && r.height,
                    o = r && r.width;
                if (a.id = v.uid(), a.ctx = n, a.canvas = r, a.config = t, a.width = o, a.height = i, a.aspectRatio = i ? o / i : null, a.options = t.options, a._bufferedRender = !1, a._layers = [], a.chart = a, a.controller = a, Ye.instances[a.id] = a, Object.defineProperty(a, "data", {
                        get: function() {
                            return a.config.data
                        },
                        set: function(c) {
                            a.config.data = c
                        }
                    }), !n || !r) {
                    console.error("Failed to create chart: can't acquire context from the given item");
                    return
                }
                a.initialize(), a.update()
            },
            initialize: function() {
                var e = this;
                return K.notify(e, "beforeInit"), v.retinaScale(e, e.options.devicePixelRatio), e.bindEvents(), e.options.responsive && e.resize(!0), e.initToolTip(), K.notify(e, "afterInit"), e
            },
            clear: function() {
                return v.canvas.clear(this), this
            },
            stop: function() {
                return fa.cancelAnimation(this), this
            },
            resize: function(e) {
                var t = this,
                    a = t.options,
                    n = t.canvas,
                    r = a.maintainAspectRatio && t.aspectRatio || null,
                    i = Math.max(0, Math.floor(v.getMaximumWidth(n))),
                    o = Math.max(0, Math.floor(r ? i / r : v.getMaximumHeight(n)));
                if (!(t.width === i && t.height === o) && (n.width = t.width = i, n.height = t.height = o, n.style.width = i + "px", n.style.height = o + "px", v.retinaScale(t, a.devicePixelRatio), !e)) {
                    var c = {
                        width: i,
                        height: o
                    };
                    K.notify(t, "resize", [c]), a.onResize && a.onResize(t, c), t.stop(), t.update({
                        duration: a.responsiveAnimationDuration
                    })
                }
            },
            ensureScalesHaveIDs: function() {
                var e = this.options,
                    t = e.scales || {},
                    a = e.scale;
                v.each(t.xAxes, function(n, r) {
                    n.id || (n.id = Fn(t.xAxes, "x-axis-", r))
                }), v.each(t.yAxes, function(n, r) {
                    n.id || (n.id = Fn(t.yAxes, "y-axis-", r))
                }), a && (a.id = a.id || "scale")
            },
            buildOrUpdateScales: function() {
                var e = this,
                    t = e.options,
                    a = e.scales || {},
                    n = [],
                    r = Object.keys(a).reduce(function(i, o) {
                        return i[o] = !1, i
                    }, {});
                t.scales && (n = n.concat((t.scales.xAxes || []).map(function(i) {
                    return {
                        options: i,
                        dtype: "category",
                        dposition: "bottom"
                    }
                }), (t.scales.yAxes || []).map(function(i) {
                    return {
                        options: i,
                        dtype: "linear",
                        dposition: "left"
                    }
                }))), t.scale && n.push({
                    options: t.scale,
                    dtype: "radialLinear",
                    isDefault: !0,
                    dposition: "chartArea"
                }), v.each(n, function(i) {
                    var o = i.options,
                        c = o.id,
                        l = Pa(o.type, i.dtype);
                    Ln(o.position) !== Ln(i.dposition) && (o.position = i.dposition), r[c] = !0;
                    var u = null;
                    if (c in a && a[c].type === l) u = a[c], u.options = o, u.ctx = e.ctx, u.chart = e;
                    else {
                        var h = Dt.getScaleConstructor(l);
                        if (!h) return;
                        u = new h({
                            id: c,
                            type: l,
                            options: o,
                            ctx: e.ctx,
                            chart: e
                        }), a[u.id] = u
                    }
                    u.mergeTicksOptions(), i.isDefault && (e.scale = u)
                }), v.each(r, function(i, o) {
                    i || delete a[o]
                }), e.scales = a, Dt.addScalesToLayout(this)
            },
            buildOrUpdateControllers: function() {
                var e = this,
                    t = [],
                    a = e.data.datasets,
                    n, r;
                for (n = 0, r = a.length; n < r; n++) {
                    var i = a[n],
                        o = e.getDatasetMeta(n),
                        c = i.type || e.config.type;
                    if (o.type && o.type !== c && (e.destroyDatasetMeta(n), o = e.getDatasetMeta(n)), o.type = c, o.order = i.order || 0, o.index = n, o.controller) o.controller.updateIndex(n), o.controller.linkScales();
                    else {
                        var l = Mn[o.type];
                        if (l === void 0) throw new Error('"' + o.type + '" is not a chart type.');
                        o.controller = new l(e, n), t.push(o.controller)
                    }
                }
                return t
            },
            resetElements: function() {
                var e = this;
                v.each(e.data.datasets, function(t, a) {
                    e.getDatasetMeta(a).controller.reset()
                }, e)
            },
            reset: function() {
                this.resetElements(), this.tooltip.initialize()
            },
            update: function(e) {
                var t = this,
                    a, n;
                if ((!e || typeof e != "object") && (e = {
                        duration: e,
                        lazy: arguments[1]
                    }), So(t), K._invalidate(t), K.notify(t, "beforeUpdate") !== !1) {
                    t.tooltip._data = t.data;
                    var r = t.buildOrUpdateControllers();
                    for (a = 0, n = t.data.datasets.length; a < n; a++) t.getDatasetMeta(a).controller.buildOrUpdateElements();
                    t.updateLayout(), t.options.animation && t.options.animation.duration && v.each(r, function(i) {
                        i.reset()
                    }), t.updateDatasets(), t.tooltip.initialize(), t.lastActive = [], K.notify(t, "afterUpdate"), t._layers.sort(En("z", "_idx")), t._bufferedRender ? t._bufferedRequest = {
                        duration: e.duration,
                        easing: e.easing,
                        lazy: e.lazy
                    } : t.render(e)
                }
            },
            updateLayout: function() {
                var e = this;
                K.notify(e, "beforeLayout") !== !1 && (Se.update(this, this.width, this.height), e._layers = [], v.each(e.boxes, function(t) {
                    t._configure && t._configure(), e._layers.push.apply(e._layers, t._layers())
                }, e), e._layers.forEach(function(t, a) {
                    t._idx = a
                }), K.notify(e, "afterScaleUpdate"), K.notify(e, "afterLayout"))
            },
            updateDatasets: function() {
                var e = this;
                if (K.notify(e, "beforeDatasetsUpdate") !== !1) {
                    for (var t = 0, a = e.data.datasets.length; t < a; ++t) e.updateDataset(t);
                    K.notify(e, "afterDatasetsUpdate")
                }
            },
            updateDataset: function(e) {
                var t = this,
                    a = t.getDatasetMeta(e),
                    n = {
                        meta: a,
                        index: e
                    };
                K.notify(t, "beforeDatasetUpdate", [n]) !== !1 && (a.controller._update(), K.notify(t, "afterDatasetUpdate", [n]))
            },
            render: function(e) {
                var t = this;
                (!e || typeof e != "object") && (e = {
                    duration: e,
                    lazy: arguments[1]
                });
                var a = t.options.animation,
                    n = Pa(e.duration, a && a.duration),
                    r = e.lazy;
                if (K.notify(t, "beforeRender") !== !1) {
                    var i = function(c) {
                        K.notify(t, "afterRender"), v.callback(a && a.onComplete, [c], t)
                    };
                    if (a && n) {
                        var o = new ha({
                            numSteps: n / 16.66,
                            easing: e.easing || a.easing,
                            render: function(c, l) {
                                var u = v.easing.effects[l.easing],
                                    h = l.currentStep,
                                    f = h / l.numSteps;
                                c.draw(u(f), f, h)
                            },
                            onAnimationProgress: a.onProgress,
                            onAnimationComplete: i
                        });
                        fa.addAnimation(t, o, n, r)
                    } else t.draw(), i(new ha({
                        numSteps: 0,
                        chart: t
                    }));
                    return t
                }
            },
            draw: function(e) {
                var t = this,
                    a, n;
                if (t.clear(), v.isNullOrUndef(e) && (e = 1), t.transition(e), !(t.width <= 0 || t.height <= 0) && K.notify(t, "beforeDraw", [e]) !== !1) {
                    for (n = t._layers, a = 0; a < n.length && n[a].z <= 0; ++a) n[a].draw(t.chartArea);
                    for (t.drawDatasets(e); a < n.length; ++a) n[a].draw(t.chartArea);
                    t._drawTooltip(e), K.notify(t, "afterDraw", [e])
                }
            },
            transition: function(e) {
                for (var t = this, a = 0, n = (t.data.datasets || []).length; a < n; ++a) t.isDatasetVisible(a) && t.getDatasetMeta(a).controller.transition(e);
                t.tooltip.transition(e)
            },
            _getSortedDatasetMetas: function(e) {
                var t = this,
                    a = t.data.datasets || [],
                    n = [],
                    r, i;
                for (r = 0, i = a.length; r < i; ++r)(!e || t.isDatasetVisible(r)) && n.push(t.getDatasetMeta(r));
                return n.sort(En("order", "index")), n
            },
            _getSortedVisibleDatasetMetas: function() {
                return this._getSortedDatasetMetas(!0)
            },
            drawDatasets: function(e) {
                var t = this,
                    a, n;
                if (K.notify(t, "beforeDatasetsDraw", [e]) !== !1) {
                    for (a = t._getSortedVisibleDatasetMetas(), n = a.length - 1; n >= 0; --n) t.drawDataset(a[n], e);
                    K.notify(t, "afterDatasetsDraw", [e])
                }
            },
            drawDataset: function(e, t) {
                var a = this,
                    n = {
                        meta: e,
                        index: e.index,
                        easingValue: t
                    };
                K.notify(a, "beforeDatasetDraw", [n]) !== !1 && (e.controller.draw(t), K.notify(a, "afterDatasetDraw", [n]))
            },
            _drawTooltip: function(e) {
                var t = this,
                    a = t.tooltip,
                    n = {
                        tooltip: a,
                        easingValue: e
                    };
                K.notify(t, "beforeTooltipDraw", [n]) !== !1 && (a.draw(), K.notify(t, "afterTooltipDraw", [n]))
            },
            getElementAtEvent: function(e) {
                return dt.modes.single(this, e)
            },
            getElementsAtEvent: function(e) {
                return dt.modes.label(this, e, {
                    intersect: !0
                })
            },
            getElementsAtXAxis: function(e) {
                return dt.modes["x-axis"](this, e, {
                    intersect: !0
                })
            },
            getElementsAtEventForMode: function(e, t, a) {
                var n = dt.modes[t];
                return typeof n == "function" ? n(this, e, a) : []
            },
            getDatasetAtEvent: function(e) {
                return dt.modes.dataset(this, e, {
                    intersect: !0
                })
            },
            getDatasetMeta: function(e) {
                var t = this,
                    a = t.data.datasets[e];
                a._meta || (a._meta = {});
                var n = a._meta[t.id];
                return n || (n = a._meta[t.id] = {
                    type: null,
                    data: [],
                    dataset: null,
                    controller: null,
                    hidden: null,
                    xAxisID: null,
                    yAxisID: null,
                    order: a.order || 0,
                    index: e
                }), n
            },
            getVisibleDatasetCount: function() {
                for (var e = 0, t = 0, a = this.data.datasets.length; t < a; ++t) this.isDatasetVisible(t) && e++;
                return e
            },
            isDatasetVisible: function(e) {
                var t = this.getDatasetMeta(e);
                return typeof t.hidden == "boolean" ? !t.hidden : !this.data.datasets[e].hidden
            },
            generateLegend: function() {
                return this.options.legendCallback(this)
            },
            destroyDatasetMeta: function(e) {
                var t = this.id,
                    a = this.data.datasets[e],
                    n = a._meta && a._meta[t];
                n && (n.controller.destroy(), delete a._meta[t])
            },
            destroy: function() {
                var e = this,
                    t = e.canvas,
                    a, n;
                for (e.stop(), a = 0, n = e.data.datasets.length; a < n; ++a) e.destroyDatasetMeta(a);
                t && (e.unbindEvents(), v.canvas.clear(e), ht.releaseContext(e.ctx), e.canvas = null, e.ctx = null), K.notify(e, "destroy"), delete Ye.instances[e.id]
            },
            toBase64Image: function() {
                return this.canvas.toDataURL.apply(this.canvas, arguments)
            },
            initToolTip: function() {
                var e = this;
                e.tooltip = new Ca({
                    _chart: e,
                    _chartInstance: e,
                    _data: e.data,
                    _options: e.options.tooltips
                }, e)
            },
            bindEvents: function() {
                var e = this,
                    t = e._listeners = {},
                    a = function() {
                        e.eventHandler.apply(e, arguments)
                    };
                v.each(e.options.events, function(n) {
                    ht.addEventListener(e, n, a), t[n] = a
                }), e.options.responsive && (a = function() {
                    e.resize()
                }, ht.addEventListener(e, "resize", a), t.resize = a)
            },
            unbindEvents: function() {
                var e = this,
                    t = e._listeners;
                !t || (delete e._listeners, v.each(t, function(a, n) {
                    ht.removeEventListener(e, n, a)
                }))
            },
            updateHoverStyle: function(e, t, a) {
                var n = a ? "set" : "remove",
                    r, i, o;
                for (i = 0, o = e.length; i < o; ++i) r = e[i], r && this.getDatasetMeta(r._datasetIndex).controller[n + "HoverStyle"](r);
                t === "dataset" && this.getDatasetMeta(e[0]._datasetIndex).controller["_" + n + "DatasetHoverStyle"]()
            },
            eventHandler: function(e) {
                var t = this,
                    a = t.tooltip;
                if (K.notify(t, "beforeEvent", [e]) !== !1) {
                    t._bufferedRender = !0, t._bufferedRequest = null;
                    var n = t.handleEvent(e);
                    a && (n = a._start ? a.handleEvent(e) : n | a.handleEvent(e)), K.notify(t, "afterEvent", [e]);
                    var r = t._bufferedRequest;
                    return r ? t.render(r) : n && !t.animating && (t.stop(), t.render({
                        duration: t.options.hover.animationDuration,
                        lazy: !0
                    })), t._bufferedRender = !1, t._bufferedRequest = null, t
                }
            },
            handleEvent: function(e) {
                var t = this,
                    a = t.options || {},
                    n = a.hover,
                    r = !1;
                return t.lastActive = t.lastActive || [], e.type === "mouseout" ? t.active = [] : t.active = t.getElementsAtEventForMode(e, n.mode, n), v.callback(a.onHover || a.hover.onHover, [e.native, t.active], t), (e.type === "mouseup" || e.type === "click") && a.onClick && a.onClick.call(t, e.native, t.active), t.lastActive.length && t.updateHoverStyle(t.lastActive, n.mode, !1), t.active.length && n.mode && t.updateHoverStyle(t.active, n.mode, !0), r = !v.arrayEquals(t.active, t.lastActive), t.lastActive = t.active, r
            }
        }), Ye.instances = {};
        var j = Ye;
        Ye.Controller = Ye, Ye.types = {}, v.configMerge = Ta, v.scaleMerge = Rn;
        var Co = function() {
            v.where = function(n, r) {
                if (v.isArray(n) && Array.prototype.filter) return n.filter(r);
                var i = [];
                return v.each(n, function(o) {
                    r(o) && i.push(o)
                }), i
            }, v.findIndex = Array.prototype.findIndex ? function(n, r, i) {
                return n.findIndex(r, i)
            } : function(n, r, i) {
                i = i === void 0 ? n : i;
                for (var o = 0, c = n.length; o < c; ++o)
                    if (r.call(i, n[o], o, n)) return o;
                return -1
            }, v.findNextWhere = function(n, r, i) {
                v.isNullOrUndef(i) && (i = -1);
                for (var o = i + 1; o < n.length; o++) {
                    var c = n[o];
                    if (r(c)) return c
                }
            }, v.findPreviousWhere = function(n, r, i) {
                v.isNullOrUndef(i) && (i = n.length);
                for (var o = i - 1; o >= 0; o--) {
                    var c = n[o];
                    if (r(c)) return c
                }
            }, v.isNumber = function(n) {
                return !isNaN(parseFloat(n)) && isFinite(n)
            }, v.almostEquals = function(n, r, i) {
                return Math.abs(n - r) < i
            }, v.almostWhole = function(n, r) {
                var i = Math.round(n);
                return i - r <= n && i + r >= n
            }, v.max = function(n) {
                return n.reduce(function(r, i) {
                    return isNaN(i) ? r : Math.max(r, i)
                }, Number.NEGATIVE_INFINITY)
            }, v.min = function(n) {
                return n.reduce(function(r, i) {
                    return isNaN(i) ? r : Math.min(r, i)
                }, Number.POSITIVE_INFINITY)
            }, v.sign = Math.sign ? function(n) {
                return Math.sign(n)
            } : function(n) {
                return n = +n, n === 0 || isNaN(n) ? n : n > 0 ? 1 : -1
            }, v.toRadians = function(n) {
                return n * (Math.PI / 180)
            }, v.toDegrees = function(n) {
                return n * (180 / Math.PI)
            }, v._decimalPlaces = function(n) {
                if (!!v.isFinite(n)) {
                    for (var r = 1, i = 0; Math.round(n * r) / r !== n;) r *= 10, i++;
                    return i
                }
            }, v.getAngleFromPoint = function(n, r) {
                var i = r.x - n.x,
                    o = r.y - n.y,
                    c = Math.sqrt(i * i + o * o),
                    l = Math.atan2(o, i);
                return l < -.5 * Math.PI && (l += 2 * Math.PI), {
                    angle: l,
                    distance: c
                }
            }, v.distanceBetweenPoints = function(n, r) {
                return Math.sqrt(Math.pow(r.x - n.x, 2) + Math.pow(r.y - n.y, 2))
            }, v.aliasPixel = function(n) {
                return n % 2 === 0 ? 0 : .5
            }, v._alignPixel = function(n, r, i) {
                var o = n.currentDevicePixelRatio,
                    c = i / 2;
                return Math.round((r - c) * o) / o + c
            }, v.splineCurve = function(n, r, i, o) {
                var c = n.skip ? r : n,
                    l = r,
                    u = i.skip ? r : i,
                    h = Math.sqrt(Math.pow(l.x - c.x, 2) + Math.pow(l.y - c.y, 2)),
                    f = Math.sqrt(Math.pow(u.x - l.x, 2) + Math.pow(u.y - l.y, 2)),
                    p = h / (h + f),
                    x = f / (h + f);
                p = isNaN(p) ? 0 : p, x = isNaN(x) ? 0 : x;
                var w = o * p,
                    _ = o * x;
                return {
                    previous: {
                        x: l.x - w * (u.x - c.x),
                        y: l.y - w * (u.y - c.y)
                    },
                    next: {
                        x: l.x + _ * (u.x - c.x),
                        y: l.y + _ * (u.y - c.y)
                    }
                }
            }, v.EPSILON = Number.EPSILON || 1e-14, v.splineCurveMonotone = function(n) {
                var r = (n || []).map(function(M) {
                        return {
                            model: M._model,
                            deltaK: 0,
                            mK: 0
                        }
                    }),
                    i = r.length,
                    o, c, l, u;
                for (o = 0; o < i; ++o)
                    if (l = r[o], !l.model.skip) {
                        if (c = o > 0 ? r[o - 1] : null, u = o < i - 1 ? r[o + 1] : null, u && !u.model.skip) {
                            var h = u.model.x - l.model.x;
                            l.deltaK = h !== 0 ? (u.model.y - l.model.y) / h : 0
                        }!c || c.model.skip ? l.mK = l.deltaK : !u || u.model.skip ? l.mK = c.deltaK : this.sign(c.deltaK) !== this.sign(l.deltaK) ? l.mK = 0 : l.mK = (c.deltaK + l.deltaK) / 2
                    }
                var f, p, x, w;
                for (o = 0; o < i - 1; ++o)
                    if (l = r[o], u = r[o + 1], !(l.model.skip || u.model.skip)) {
                        if (v.almostEquals(l.deltaK, 0, this.EPSILON)) {
                            l.mK = u.mK = 0;
                            continue
                        }
                        f = l.mK / l.deltaK, p = u.mK / l.deltaK, w = Math.pow(f, 2) + Math.pow(p, 2), !(w <= 9) && (x = 3 / Math.sqrt(w), l.mK = f * x * l.deltaK, u.mK = p * x * l.deltaK)
                    }
                var _;
                for (o = 0; o < i; ++o) l = r[o], !l.model.skip && (c = o > 0 ? r[o - 1] : null, u = o < i - 1 ? r[o + 1] : null, c && !c.model.skip && (_ = (l.model.x - c.model.x) / 3, l.model.controlPointPreviousX = l.model.x - _, l.model.controlPointPreviousY = l.model.y - _ * l.mK), u && !u.model.skip && (_ = (u.model.x - l.model.x) / 3, l.model.controlPointNextX = l.model.x + _, l.model.controlPointNextY = l.model.y + _ * l.mK))
            }, v.nextItem = function(n, r, i) {
                return i ? r >= n.length - 1 ? n[0] : n[r + 1] : r >= n.length - 1 ? n[n.length - 1] : n[r + 1]
            }, v.previousItem = function(n, r, i) {
                return i ? r <= 0 ? n[n.length - 1] : n[r - 1] : r <= 0 ? n[0] : n[r - 1]
            }, v.niceNum = function(n, r) {
                var i = Math.floor(v.log10(n)),
                    o = n / Math.pow(10, i),
                    c;
                return r ? o < 1.5 ? c = 1 : o < 3 ? c = 2 : o < 7 ? c = 5 : c = 10 : o <= 1 ? c = 1 : o <= 2 ? c = 2 : o <= 5 ? c = 5 : c = 10, c * Math.pow(10, i)
            }, v.requestAnimFrame = function() {
                return typeof window > "u" ? function(n) {
                    n()
                } : window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(n) {
                    return window.setTimeout(n, 1e3 / 60)
                }
            }(), v.getRelativePosition = function(n, r) {
                var i, o, c = n.originalEvent || n,
                    l = n.target || n.srcElement,
                    u = l.getBoundingClientRect(),
                    h = c.touches;
                h && h.length > 0 ? (i = h[0].clientX, o = h[0].clientY) : (i = c.clientX, o = c.clientY);
                var f = parseFloat(v.getStyle(l, "padding-left")),
                    p = parseFloat(v.getStyle(l, "padding-top")),
                    x = parseFloat(v.getStyle(l, "padding-right")),
                    w = parseFloat(v.getStyle(l, "padding-bottom")),
                    _ = u.right - u.left - f - x,
                    M = u.bottom - u.top - p - w;
                return i = Math.round((i - u.left - f) / _ * l.width / r.currentDevicePixelRatio), o = Math.round((o - u.top - p) / M * l.height / r.currentDevicePixelRatio), {
                    x: i,
                    y: o
                }
            };

            function e(n, r, i) {
                var o;
                return typeof n == "string" ? (o = parseInt(n, 10), n.indexOf("%") !== -1 && (o = o / 100 * r.parentNode[i])) : o = n, o
            }

            function t(n) {
                return n != null && n !== "none"
            }

            function a(n, r, i) {
                var o = document.defaultView,
                    c = v._getParentNode(n),
                    l = o.getComputedStyle(n)[r],
                    u = o.getComputedStyle(c)[r],
                    h = t(l),
                    f = t(u),
                    p = Number.POSITIVE_INFINITY;
                return h || f ? Math.min(h ? e(l, n, i) : p, f ? e(u, c, i) : p) : "none"
            }
            v.getConstraintWidth = function(n) {
                return a(n, "max-width", "clientWidth")
            }, v.getConstraintHeight = function(n) {
                return a(n, "max-height", "clientHeight")
            }, v._calculatePadding = function(n, r, i) {
                return r = v.getStyle(n, r), r.indexOf("%") > -1 ? i * parseInt(r, 10) / 100 : parseInt(r, 10)
            }, v._getParentNode = function(n) {
                var r = n.parentNode;
                return r && r.toString() === "[object ShadowRoot]" && (r = r.host), r
            }, v.getMaximumWidth = function(n) {
                var r = v._getParentNode(n);
                if (!r) return n.clientWidth;
                var i = r.clientWidth,
                    o = v._calculatePadding(r, "padding-left", i),
                    c = v._calculatePadding(r, "padding-right", i),
                    l = i - o - c,
                    u = v.getConstraintWidth(n);
                return isNaN(u) ? l : Math.min(l, u)
            }, v.getMaximumHeight = function(n) {
                var r = v._getParentNode(n);
                if (!r) return n.clientHeight;
                var i = r.clientHeight,
                    o = v._calculatePadding(r, "padding-top", i),
                    c = v._calculatePadding(r, "padding-bottom", i),
                    l = i - o - c,
                    u = v.getConstraintHeight(n);
                return isNaN(u) ? l : Math.min(l, u)
            }, v.getStyle = function(n, r) {
                return n.currentStyle ? n.currentStyle[r] : document.defaultView.getComputedStyle(n, null).getPropertyValue(r)
            }, v.retinaScale = function(n, r) {
                var i = n.currentDevicePixelRatio = r || typeof window < "u" && window.devicePixelRatio || 1;
                if (i !== 1) {
                    var o = n.canvas,
                        c = n.height,
                        l = n.width;
                    o.height = c * i, o.width = l * i, n.ctx.scale(i, i), !o.style.height && !o.style.width && (o.style.height = c + "px", o.style.width = l + "px")
                }
            }, v.fontString = function(n, r, i) {
                return r + " " + n + "px " + i
            }, v.longestText = function(n, r, i, o) {
                o = o || {};
                var c = o.data = o.data || {},
                    l = o.garbageCollect = o.garbageCollect || [];
                o.font !== r && (c = o.data = {}, l = o.garbageCollect = [], o.font = r), n.font = r;
                var u = 0,
                    h = i.length,
                    f, p, x, w, _;
                for (f = 0; f < h; f++)
                    if (w = i[f], w != null && v.isArray(w) !== !0) u = v.measureText(n, c, l, u, w);
                    else if (v.isArray(w))
                    for (p = 0, x = w.length; p < x; p++) _ = w[p], _ != null && !v.isArray(_) && (u = v.measureText(n, c, l, u, _));
                var M = l.length / 2;
                if (M > i.length) {
                    for (f = 0; f < M; f++) delete c[l[f]];
                    l.splice(0, M)
                }
                return u
            }, v.measureText = function(n, r, i, o, c) {
                var l = r[c];
                return l || (l = r[c] = n.measureText(c).width, i.push(c)), l > o && (o = l), o
            }, v.numberOfLabelLines = function(n) {
                var r = 1;
                return v.each(n, function(i) {
                    v.isArray(i) && i.length > r && (r = i.length)
                }), r
            }, v.color = jt ? function(n) {
                return n instanceof CanvasGradient && (n = A.global.defaultColor), jt(n)
            } : function(n) {
                return console.error("Color.js not found!"), n
            }, v.getHoverColor = function(n) {
                return n instanceof CanvasPattern || n instanceof CanvasGradient ? n : v.color(n).saturate(.5).darken(.1).rgbString()
            }
        };

        function nt() {
            throw new Error("This method is not implemented: either no adapter can be found or an incomplete integration was provided.")
        }

        function Xt(e) {
            this.options = e || {}
        }
        v.extend(Xt.prototype, {
            formats: nt,
            parse: nt,
            format: nt,
            add: nt,
            diff: nt,
            startOf: nt,
            endOf: nt,
            _create: function(e) {
                return e
            }
        }), Xt.override = function(e) {
            v.extend(Xt.prototype, e)
        };
        var Po = Xt,
            Na = {
                _date: Po
            },
            Ot = {
                formatters: {
                    values: function(e) {
                        return v.isArray(e) ? e : "" + e
                    },
                    linear: function(e, t, a) {
                        var n = a.length > 3 ? a[2] - a[1] : a[1] - a[0];
                        Math.abs(n) > 1 && e !== Math.floor(e) && (n = e - Math.floor(e));
                        var r = v.log10(Math.abs(n)),
                            i = "";
                        if (e !== 0) {
                            var o = Math.max(Math.abs(a[0]), Math.abs(a[a.length - 1]));
                            if (o < 1e-4) {
                                var c = v.log10(Math.abs(e)),
                                    l = Math.floor(c) - Math.floor(r);
                                l = Math.max(Math.min(l, 20), 0), i = e.toExponential(l)
                            } else {
                                var u = -1 * Math.floor(r);
                                u = Math.max(Math.min(u, 20), 0), i = e.toFixed(u)
                            }
                        } else i = "0";
                        return i
                    },
                    logarithmic: function(e, t, a) {
                        var n = e / Math.pow(10, Math.floor(v.log10(e)));
                        return e === 0 ? "0" : n === 1 || n === 2 || n === 5 || t === 0 || t === a.length - 1 ? e.toExponential() : ""
                    }
                }
            },
            rt = v.isArray,
            At = v.isNullOrUndef,
            it = v.valueOrDefault,
            ft = v.valueAtIndexOrDefault;
        A._set("scale", {
            display: !0,
            position: "left",
            offset: !1,
            gridLines: {
                display: !0,
                color: "rgba(0,0,0,0.1)",
                lineWidth: 1,
                drawBorder: !0,
                drawOnChartArea: !0,
                drawTicks: !0,
                tickMarkLength: 10,
                zeroLineWidth: 1,
                zeroLineColor: "rgba(0,0,0,0.25)",
                zeroLineBorderDash: [],
                zeroLineBorderDashOffset: 0,
                offsetGridLines: !1,
                borderDash: [],
                borderDashOffset: 0
            },
            scaleLabel: {
                display: !1,
                labelString: "",
                padding: {
                    top: 4,
                    bottom: 4
                }
            },
            ticks: {
                beginAtZero: !1,
                minRotation: 0,
                maxRotation: 50,
                mirror: !1,
                padding: 0,
                reverse: !1,
                display: !0,
                autoSkip: !0,
                autoSkipPadding: 0,
                labelOffset: 0,
                callback: Ot.formatters.values,
                minor: {},
                major: {}
            }
        });

        function To(e, t) {
            for (var a = [], n = e.length / t, r = 0, i = e.length; r < i; r += n) a.push(e[Math.floor(r)]);
            return a
        }

        function No(e, t, a) {
            var n = e.getTicks().length,
                r = Math.min(t, n - 1),
                i = e.getPixelForTick(r),
                o = e._startPixel,
                c = e._endPixel,
                l = 1e-6,
                u;
            if (!(a && (n === 1 ? u = Math.max(i - o, c - i) : t === 0 ? u = (e.getPixelForTick(1) - i) / 2 : u = (i - e.getPixelForTick(r - 1)) / 2, i += r < t ? u : -u, i < o - l || i > c + l))) return i
        }

        function Do(e, t) {
            v.each(e, function(a) {
                var n = a.gc,
                    r = n.length / 2,
                    i;
                if (r > t) {
                    for (i = 0; i < r; ++i) delete a.data[n[i]];
                    n.splice(0, r)
                }
            })
        }

        function Oo(e, t, a, n) {
            var r = a.length,
                i = [],
                o = [],
                c = [],
                l = 0,
                u = 0,
                h, f, p, x, w, _, M, C, T, N, W, E, $;
            for (h = 0; h < r; ++h) {
                if (x = a[h].label, w = a[h].major ? t.major : t.minor, e.font = _ = w.string, M = n[_] = n[_] || {
                        data: {},
                        gc: []
                    }, C = w.lineHeight, T = N = 0, !At(x) && !rt(x)) T = v.measureText(e, M.data, M.gc, T, x), N = C;
                else if (rt(x))
                    for (f = 0, p = x.length; f < p; ++f) W = x[f], !At(W) && !rt(W) && (T = v.measureText(e, M.data, M.gc, T, W), N += C);
                i.push(T), o.push(N), c.push(C / 2), l = Math.max(T, l), u = Math.max(N, u)
            }
            Do(n, r), E = i.indexOf(l), $ = o.indexOf(u);

            function G(U) {
                return {
                    width: i[U] || 0,
                    height: o[U] || 0,
                    offset: c[U] || 0
                }
            }
            return {
                first: G(0),
                last: G(r - 1),
                widest: G(E),
                highest: G($)
            }
        }

        function Bt(e) {
            return e.drawTicks ? e.tickMarkLength : 0
        }

        function Da(e) {
            var t, a;
            return e.display ? (t = v.options._parseFont(e), a = v.options.toPadding(e.padding), t.lineHeight + a.height) : 0
        }

        function zn(e, t) {
            return v.extend(v.options._parseFont({
                fontFamily: it(t.fontFamily, e.fontFamily),
                fontSize: it(t.fontSize, e.fontSize),
                fontStyle: it(t.fontStyle, e.fontStyle),
                lineHeight: it(t.lineHeight, e.lineHeight)
            }), {
                color: v.options.resolve([t.fontColor, e.fontColor, A.global.defaultFontColor])
            })
        }

        function Oa(e) {
            var t = zn(e, e.minor),
                a = e.major.enabled ? zn(e, e.major) : t;
            return {
                minor: t,
                major: a
            }
        }

        function Aa(e) {
            var t = [],
                a, n, r;
            for (n = 0, r = e.length; n < r; ++n) a = e[n], typeof a._index < "u" && t.push(a);
            return t
        }

        function Ao(e) {
            var t = e.length,
                a, n;
            if (t < 2) return !1;
            for (n = e[0], a = 1; a < t; ++a)
                if (e[a] - e[a - 1] !== n) return !1;
            return n
        }

        function Bo(e, t, a, n) {
            var r = Ao(e),
                i = (t.length - 1) / n,
                o, c, l, u;
            if (!r) return Math.max(i, 1);
            for (o = v.math._factorize(r), l = 0, u = o.length - 1; l < u; l++)
                if (c = o[l], c > i) return c;
            return Math.max(i, 1)
        }

        function Ro(e) {
            var t = [],
                a, n;
            for (a = 0, n = e.length; a < n; a++) e[a].major && t.push(a);
            return t
        }

        function Fo(e, t, a) {
            var n = 0,
                r = t[0],
                i, o;
            for (a = Math.ceil(a), i = 0; i < e.length; i++) o = e[i], i === r ? (o._index = i, n++, r = t[n * a]) : delete o.label
        }

        function Kt(e, t, a, n) {
            var r = it(a, 0),
                i = Math.min(it(n, e.length), e.length),
                o = 0,
                c, l, u, h;
            for (t = Math.ceil(t), n && (c = n - a, t = c / Math.floor(c / t)), h = r; h < 0;) o++, h = Math.round(r + o * t);
            for (l = Math.max(r, 0); l < i; l++) u = e[l], l === h ? (u._index = l, o++, h = Math.round(r + o * t)) : delete u.label
        }
        var Ba = Le.extend({
            zeroLineIndex: 0,
            getPadding: function() {
                var e = this;
                return {
                    left: e.paddingLeft || 0,
                    top: e.paddingTop || 0,
                    right: e.paddingRight || 0,
                    bottom: e.paddingBottom || 0
                }
            },
            getTicks: function() {
                return this._ticks
            },
            _getLabels: function() {
                var e = this.chart.data;
                return this.options.labels || (this.isHorizontal() ? e.xLabels : e.yLabels) || e.labels || []
            },
            mergeTicksOptions: function() {},
            beforeUpdate: function() {
                v.callback(this.options.beforeUpdate, [this])
            },
            update: function(e, t, a) {
                var n = this,
                    r = n.options.ticks,
                    i = r.sampleSize,
                    o, c, l, u, h;
                if (n.beforeUpdate(), n.maxWidth = e, n.maxHeight = t, n.margins = v.extend({
                        left: 0,
                        right: 0,
                        top: 0,
                        bottom: 0
                    }, a), n._ticks = null, n.ticks = null, n._labelSizes = null, n._maxLabelLines = 0, n.longestLabelWidth = 0, n.longestTextCache = n.longestTextCache || {}, n._gridLineItems = null, n._labelItems = null, n.beforeSetDimensions(), n.setDimensions(), n.afterSetDimensions(), n.beforeDataLimits(), n.determineDataLimits(), n.afterDataLimits(), n.beforeBuildTicks(), u = n.buildTicks() || [], u = n.afterBuildTicks(u) || u, (!u || !u.length) && n.ticks)
                    for (u = [], o = 0, c = n.ticks.length; o < c; ++o) u.push({
                        value: n.ticks[o],
                        major: !1
                    });
                return n._ticks = u, h = i < u.length, l = n._convertTicksToLabels(h ? To(u, i) : u), n._configure(), n.beforeCalculateTickRotation(), n.calculateTickRotation(), n.afterCalculateTickRotation(), n.beforeFit(), n.fit(), n.afterFit(), n._ticksToDraw = r.display && (r.autoSkip || r.source === "auto") ? n._autoSkip(u) : u, h && (l = n._convertTicksToLabels(n._ticksToDraw)), n.ticks = l, n.afterUpdate(), n.minSize
            },
            _configure: function() {
                var e = this,
                    t = e.options.ticks.reverse,
                    a, n;
                e.isHorizontal() ? (a = e.left, n = e.right) : (a = e.top, n = e.bottom, t = !t), e._startPixel = a, e._endPixel = n, e._reversePixels = t, e._length = n - a
            },
            afterUpdate: function() {
                v.callback(this.options.afterUpdate, [this])
            },
            beforeSetDimensions: function() {
                v.callback(this.options.beforeSetDimensions, [this])
            },
            setDimensions: function() {
                var e = this;
                e.isHorizontal() ? (e.width = e.maxWidth, e.left = 0, e.right = e.width) : (e.height = e.maxHeight, e.top = 0, e.bottom = e.height), e.paddingLeft = 0, e.paddingTop = 0, e.paddingRight = 0, e.paddingBottom = 0
            },
            afterSetDimensions: function() {
                v.callback(this.options.afterSetDimensions, [this])
            },
            beforeDataLimits: function() {
                v.callback(this.options.beforeDataLimits, [this])
            },
            determineDataLimits: v.noop,
            afterDataLimits: function() {
                v.callback(this.options.afterDataLimits, [this])
            },
            beforeBuildTicks: function() {
                v.callback(this.options.beforeBuildTicks, [this])
            },
            buildTicks: v.noop,
            afterBuildTicks: function(e) {
                var t = this;
                return rt(e) && e.length ? v.callback(t.options.afterBuildTicks, [t, e]) : (t.ticks = v.callback(t.options.afterBuildTicks, [t, t.ticks]) || t.ticks, e)
            },
            beforeTickToLabelConversion: function() {
                v.callback(this.options.beforeTickToLabelConversion, [this])
            },
            convertTicksToLabels: function() {
                var e = this,
                    t = e.options.ticks;
                e.ticks = e.ticks.map(t.userCallback || t.callback, this)
            },
            afterTickToLabelConversion: function() {
                v.callback(this.options.afterTickToLabelConversion, [this])
            },
            beforeCalculateTickRotation: function() {
                v.callback(this.options.beforeCalculateTickRotation, [this])
            },
            calculateTickRotation: function() {
                var e = this,
                    t = e.options,
                    a = t.ticks,
                    n = e.getTicks().length,
                    r = a.minRotation || 0,
                    i = a.maxRotation,
                    o = r,
                    c, l, u, h, f, p, x;
                if (!e._isVisible() || !a.display || r >= i || n <= 1 || !e.isHorizontal()) {
                    e.labelRotation = r;
                    return
                }
                c = e._getLabelSizes(), l = c.widest.width, u = c.highest.height - c.highest.offset, h = Math.min(e.maxWidth, e.chart.width - l), f = t.offset ? e.maxWidth / n : h / (n - 1), l + 6 > f && (f = h / (n - (t.offset ? .5 : 1)), p = e.maxHeight - Bt(t.gridLines) - a.padding - Da(t.scaleLabel), x = Math.sqrt(l * l + u * u), o = v.toDegrees(Math.min(Math.asin(Math.min((c.highest.height + 6) / f, 1)), Math.asin(Math.min(p / x, 1)) - Math.asin(u / x))), o = Math.max(r, Math.min(i, o))), e.labelRotation = o
            },
            afterCalculateTickRotation: function() {
                v.callback(this.options.afterCalculateTickRotation, [this])
            },
            beforeFit: function() {
                v.callback(this.options.beforeFit, [this])
            },
            fit: function() {
                var e = this,
                    t = e.minSize = {
                        width: 0,
                        height: 0
                    },
                    a = e.chart,
                    n = e.options,
                    r = n.ticks,
                    i = n.scaleLabel,
                    o = n.gridLines,
                    c = e._isVisible(),
                    l = n.position === "bottom",
                    u = e.isHorizontal();
                if (u ? t.width = e.maxWidth : c && (t.width = Bt(o) + Da(i)), u ? c && (t.height = Bt(o) + Da(i)) : t.height = e.maxHeight, r.display && c) {
                    var h = Oa(r),
                        f = e._getLabelSizes(),
                        p = f.first,
                        x = f.last,
                        w = f.widest,
                        _ = f.highest,
                        M = h.minor.lineHeight * .4,
                        C = r.padding;
                    if (u) {
                        var T = e.labelRotation !== 0,
                            N = v.toRadians(e.labelRotation),
                            W = Math.cos(N),
                            E = Math.sin(N),
                            $ = E * w.width + W * (_.height - (T ? _.offset : 0)) + (T ? 0 : M);
                        t.height = Math.min(e.maxHeight, t.height + $ + C);
                        var G = e.getPixelForTick(0) - e.left,
                            U = e.right - e.getPixelForTick(e.getTicks().length - 1),
                            J, ie;
                        T ? (J = l ? W * p.width + E * p.offset : E * (p.height - p.offset), ie = l ? E * (x.height - x.offset) : W * x.width + E * x.offset) : (J = p.width / 2, ie = x.width / 2), e.paddingLeft = Math.max((J - G) * e.width / (e.width - G), 0) + 3, e.paddingRight = Math.max((ie - U) * e.width / (e.width - U), 0) + 3
                    } else {
                        var ae = r.mirror ? 0 : w.width + C + M;
                        t.width = Math.min(e.maxWidth, t.width + ae), e.paddingTop = p.height / 2, e.paddingBottom = x.height / 2
                    }
                }
                e.handleMargins(), u ? (e.width = e._length = a.width - e.margins.left - e.margins.right, e.height = t.height) : (e.width = t.width, e.height = e._length = a.height - e.margins.top - e.margins.bottom)
            },
            handleMargins: function() {
                var e = this;
                e.margins && (e.margins.left = Math.max(e.paddingLeft, e.margins.left), e.margins.top = Math.max(e.paddingTop, e.margins.top), e.margins.right = Math.max(e.paddingRight, e.margins.right), e.margins.bottom = Math.max(e.paddingBottom, e.margins.bottom))
            },
            afterFit: function() {
                v.callback(this.options.afterFit, [this])
            },
            isHorizontal: function() {
                var e = this.options.position;
                return e === "top" || e === "bottom"
            },
            isFullWidth: function() {
                return this.options.fullWidth
            },
            getRightValue: function(e) {
                if (At(e)) return NaN;
                if ((typeof e == "number" || e instanceof Number) && !isFinite(e)) return NaN;
                if (e) {
                    if (this.isHorizontal()) {
                        if (e.x !== void 0) return this.getRightValue(e.x)
                    } else if (e.y !== void 0) return this.getRightValue(e.y)
                }
                return e
            },
            _convertTicksToLabels: function(e) {
                var t = this,
                    a, n, r;
                for (t.ticks = e.map(function(i) {
                        return i.value
                    }), t.beforeTickToLabelConversion(), a = t.convertTicksToLabels(e) || t.ticks, t.afterTickToLabelConversion(), n = 0, r = e.length; n < r; ++n) e[n].label = a[n];
                return a
            },
            _getLabelSizes: function() {
                var e = this,
                    t = e._labelSizes;
                return t || (e._labelSizes = t = Oo(e.ctx, Oa(e.options.ticks), e.getTicks(), e.longestTextCache), e.longestLabelWidth = t.widest.width), t
            },
            _parseValue: function(e) {
                var t, a, n, r;
                return rt(e) ? (t = +this.getRightValue(e[0]), a = +this.getRightValue(e[1]), n = Math.min(t, a), r = Math.max(t, a)) : (e = +this.getRightValue(e), t = void 0, a = e, n = e, r = e), {
                    min: n,
                    max: r,
                    start: t,
                    end: a
                }
            },
            _getScaleLabel: function(e) {
                var t = this._parseValue(e);
                return t.start !== void 0 ? "[" + t.start + ", " + t.end + "]" : +this.getRightValue(e)
            },
            getLabelForIndex: v.noop,
            getPixelForValue: v.noop,
            getValueForPixel: v.noop,
            getPixelForTick: function(e) {
                var t = this,
                    a = t.options.offset,
                    n = t._ticks.length,
                    r = 1 / Math.max(n - (a ? 0 : 1), 1);
                return e < 0 || e > n - 1 ? null : t.getPixelForDecimal(e * r + (a ? r / 2 : 0))
            },
            getPixelForDecimal: function(e) {
                var t = this;
                return t._reversePixels && (e = 1 - e), t._startPixel + e * t._length
            },
            getDecimalForPixel: function(e) {
                var t = (e - this._startPixel) / this._length;
                return this._reversePixels ? 1 - t : t
            },
            getBasePixel: function() {
                return this.getPixelForValue(this.getBaseValue())
            },
            getBaseValue: function() {
                var e = this,
                    t = e.min,
                    a = e.max;
                return e.beginAtZero ? 0 : t < 0 && a < 0 ? a : t > 0 && a > 0 ? t : 0
            },
            _autoSkip: function(e) {
                var t = this,
                    a = t.options.ticks,
                    n = t._length,
                    r = a.maxTicksLimit || n / t._tickSize() + 1,
                    i = a.major.enabled ? Ro(e) : [],
                    o = i.length,
                    c = i[0],
                    l = i[o - 1],
                    u, h, f, p;
                if (o > r) return Fo(e, i, o / r), Aa(e);
                if (f = Bo(i, e, n, r), o > 0) {
                    for (u = 0, h = o - 1; u < h; u++) Kt(e, f, i[u], i[u + 1]);
                    return p = o > 1 ? (l - c) / (o - 1) : null, Kt(e, f, v.isNullOrUndef(p) ? 0 : c - p, c), Kt(e, f, l, v.isNullOrUndef(p) ? e.length : l + p), Aa(e)
                }
                return Kt(e, f), Aa(e)
            },
            _tickSize: function() {
                var e = this,
                    t = e.options.ticks,
                    a = v.toRadians(e.labelRotation),
                    n = Math.abs(Math.cos(a)),
                    r = Math.abs(Math.sin(a)),
                    i = e._getLabelSizes(),
                    o = t.autoSkipPadding || 0,
                    c = i ? i.widest.width + o : 0,
                    l = i ? i.highest.height + o : 0;
                return e.isHorizontal() ? l * n > c * r ? c / n : l / r : l * r < c * n ? l / n : c / r
            },
            _isVisible: function() {
                var e = this,
                    t = e.chart,
                    a = e.options.display,
                    n, r, i;
                if (a !== "auto") return !!a;
                for (n = 0, r = t.data.datasets.length; n < r; ++n)
                    if (t.isDatasetVisible(n) && (i = t.getDatasetMeta(n), i.xAxisID === e.id || i.yAxisID === e.id)) return !0;
                return !1
            },
            _computeGridLineItems: function(e) {
                var t = this,
                    a = t.chart,
                    n = t.options,
                    r = n.gridLines,
                    i = n.position,
                    o = r.offsetGridLines,
                    c = t.isHorizontal(),
                    l = t._ticksToDraw,
                    u = l.length + (o ? 1 : 0),
                    h = Bt(r),
                    f = [],
                    p = r.drawBorder ? ft(r.lineWidth, 0, 0) : 0,
                    x = p / 2,
                    w = v._alignPixel,
                    _ = function(Rs) {
                        return w(a, Rs, p)
                    },
                    M, C, T, N, W, E, $, G, U, J, ie, ae, te, se, pt, mt, Va;
                for (i === "top" ? (M = _(t.bottom), $ = t.bottom - h, U = M - x, ie = _(e.top) + x, te = e.bottom) : i === "bottom" ? (M = _(t.top), ie = e.top, te = _(e.bottom) - x, $ = M + x, U = t.top + h) : i === "left" ? (M = _(t.right), E = t.right - h, G = M - x, J = _(e.left) + x, ae = e.right) : (M = _(t.left), J = e.left, ae = _(e.right) - x, E = M + x, G = t.left + h), C = 0; C < u; ++C) T = l[C] || {}, !(At(T.label) && C < l.length) && (C === t.zeroLineIndex && n.offset === o ? (se = r.zeroLineWidth, pt = r.zeroLineColor, mt = r.zeroLineBorderDash || [], Va = r.zeroLineBorderDashOffset || 0) : (se = ft(r.lineWidth, C, 1), pt = ft(r.color, C, "rgba(0,0,0,0.1)"), mt = r.borderDash || [], Va = r.borderDashOffset || 0), N = No(t, T._index || C, o), N !== void 0 && (W = w(a, N, se), c ? E = G = J = ae = W : $ = U = ie = te = W, f.push({
                    tx1: E,
                    ty1: $,
                    tx2: G,
                    ty2: U,
                    x1: J,
                    y1: ie,
                    x2: ae,
                    y2: te,
                    width: se,
                    color: pt,
                    borderDash: mt,
                    borderDashOffset: Va
                })));
                return f.ticksLength = u, f.borderValue = M, f
            },
            _computeLabelItems: function() {
                var e = this,
                    t = e.options,
                    a = t.ticks,
                    n = t.position,
                    r = a.mirror,
                    i = e.isHorizontal(),
                    o = e._ticksToDraw,
                    c = Oa(a),
                    l = a.padding,
                    u = Bt(t.gridLines),
                    h = -v.toRadians(e.labelRotation),
                    f = [],
                    p, x, w, _, M, C, T, N, W, E, $, G;
                for (n === "top" ? (C = e.bottom - u - l, T = h ? "left" : "center") : n === "bottom" ? (C = e.top + u + l, T = h ? "right" : "center") : n === "left" ? (M = e.right - (r ? 0 : u) - l, T = r ? "left" : "right") : (M = e.left + (r ? 0 : u) + l, T = r ? "right" : "left"), p = 0, x = o.length; p < x; ++p) w = o[p], _ = w.label, !At(_) && (N = e.getPixelForTick(w._index || p) + a.labelOffset, W = w.major ? c.major : c.minor, E = W.lineHeight, $ = rt(_) ? _.length : 1, i ? (M = N, G = n === "top" ? ((h ? 1 : .5) - $) * E : (h ? 0 : .5) * E) : (C = N, G = (1 - $) * E / 2), f.push({
                    x: M,
                    y: C,
                    rotation: h,
                    label: _,
                    font: W,
                    textOffset: G,
                    textAlign: T
                }));
                return f
            },
            _drawGrid: function(e) {
                var t = this,
                    a = t.options.gridLines;
                if (!!a.display) {
                    var n = t.ctx,
                        r = t.chart,
                        i = v._alignPixel,
                        o = a.drawBorder ? ft(a.lineWidth, 0, 0) : 0,
                        c = t._gridLineItems || (t._gridLineItems = t._computeGridLineItems(e)),
                        l, u, h, f, p;
                    for (h = 0, f = c.length; h < f; ++h) p = c[h], l = p.width, u = p.color, l && u && (n.save(), n.lineWidth = l, n.strokeStyle = u, n.setLineDash && (n.setLineDash(p.borderDash), n.lineDashOffset = p.borderDashOffset), n.beginPath(), a.drawTicks && (n.moveTo(p.tx1, p.ty1), n.lineTo(p.tx2, p.ty2)), a.drawOnChartArea && (n.moveTo(p.x1, p.y1), n.lineTo(p.x2, p.y2)), n.stroke(), n.restore());
                    if (o) {
                        var x = o,
                            w = ft(a.lineWidth, c.ticksLength - 1, 1),
                            _ = c.borderValue,
                            M, C, T, N;
                        t.isHorizontal() ? (M = i(r, t.left, x) - x / 2, C = i(r, t.right, w) + w / 2, T = N = _) : (T = i(r, t.top, x) - x / 2, N = i(r, t.bottom, w) + w / 2, M = C = _), n.lineWidth = o, n.strokeStyle = ft(a.color, 0), n.beginPath(), n.moveTo(M, T), n.lineTo(C, N), n.stroke()
                    }
                }
            },
            _drawLabels: function() {
                var e = this,
                    t = e.options.ticks;
                if (!!t.display) {
                    var a = e.ctx,
                        n = e._labelItems || (e._labelItems = e._computeLabelItems()),
                        r, i, o, c, l, u, h, f;
                    for (r = 0, o = n.length; r < o; ++r) {
                        if (l = n[r], u = l.font, a.save(), a.translate(l.x, l.y), a.rotate(l.rotation), a.font = u.string, a.fillStyle = u.color, a.textBaseline = "middle", a.textAlign = l.textAlign, h = l.label, f = l.textOffset, rt(h))
                            for (i = 0, c = h.length; i < c; ++i) a.fillText("" + h[i], 0, f), f += u.lineHeight;
                        else a.fillText(h, 0, f);
                        a.restore()
                    }
                }
            },
            _drawTitle: function() {
                var e = this,
                    t = e.ctx,
                    a = e.options,
                    n = a.scaleLabel;
                if (!!n.display) {
                    var r = it(n.fontColor, A.global.defaultFontColor),
                        i = v.options._parseFont(n),
                        o = v.options.toPadding(n.padding),
                        c = i.lineHeight / 2,
                        l = a.position,
                        u = 0,
                        h, f;
                    if (e.isHorizontal()) h = e.left + e.width / 2, f = l === "bottom" ? e.bottom - c - o.bottom : e.top + c + o.top;
                    else {
                        var p = l === "left";
                        h = p ? e.left + c + o.top : e.right - c - o.top, f = e.top + e.height / 2, u = p ? -.5 * Math.PI : .5 * Math.PI
                    }
                    t.save(), t.translate(h, f), t.rotate(u), t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = r, t.font = i.string, t.fillText(n.labelString, 0, 0), t.restore()
                }
            },
            draw: function(e) {
                var t = this;
                !t._isVisible() || (t._drawGrid(e), t._drawTitle(), t._drawLabels())
            },
            _layers: function() {
                var e = this,
                    t = e.options,
                    a = t.ticks && t.ticks.z || 0,
                    n = t.gridLines && t.gridLines.z || 0;
                return !e._isVisible() || a === n || e.draw !== e._draw ? [{
                    z: a,
                    draw: function() {
                        e.draw.apply(e, arguments)
                    }
                }] : [{
                    z: n,
                    draw: function() {
                        e._drawGrid.apply(e, arguments), e._drawTitle.apply(e, arguments)
                    }
                }, {
                    z: a,
                    draw: function() {
                        e._drawLabels.apply(e, arguments)
                    }
                }]
            },
            _getMatchingVisibleMetas: function(e) {
                var t = this,
                    a = t.isHorizontal();
                return t.chart._getSortedVisibleDatasetMetas().filter(function(n) {
                    return (!e || n.type === e) && (a ? n.xAxisID === t.id : n.yAxisID === t.id)
                })
            }
        });
        Ba.prototype._draw = Ba.prototype.draw;
        var me = Ba,
            Ra = v.isNullOrUndef,
            Lo = {
                position: "bottom"
            },
            Wn = me.extend({
                determineDataLimits: function() {
                    var e = this,
                        t = e._getLabels(),
                        a = e.options.ticks,
                        n = a.min,
                        r = a.max,
                        i = 0,
                        o = t.length - 1,
                        c;
                    n !== void 0 && (c = t.indexOf(n), c >= 0 && (i = c)), r !== void 0 && (c = t.indexOf(r), c >= 0 && (o = c)), e.minIndex = i, e.maxIndex = o, e.min = t[i], e.max = t[o]
                },
                buildTicks: function() {
                    var e = this,
                        t = e._getLabels(),
                        a = e.minIndex,
                        n = e.maxIndex;
                    e.ticks = a === 0 && n === t.length - 1 ? t : t.slice(a, n + 1)
                },
                getLabelForIndex: function(e, t) {
                    var a = this,
                        n = a.chart;
                    return n.getDatasetMeta(t).controller._getValueScaleId() === a.id ? a.getRightValue(n.data.datasets[t].data[e]) : a._getLabels()[e]
                },
                _configure: function() {
                    var e = this,
                        t = e.options.offset,
                        a = e.ticks;
                    me.prototype._configure.call(e), e.isHorizontal() || (e._reversePixels = !e._reversePixels), a && (e._startValue = e.minIndex - (t ? .5 : 0), e._valueRange = Math.max(a.length - (t ? 0 : 1), 1))
                },
                getPixelForValue: function(e, t, a) {
                    var n = this,
                        r, i, o;
                    return !Ra(t) && !Ra(a) && (e = n.chart.data.datasets[a].data[t]), Ra(e) || (r = n.isHorizontal() ? e.x : e.y), (r !== void 0 || e !== void 0 && isNaN(t)) && (i = n._getLabels(), e = v.valueOrDefault(r, e), o = i.indexOf(e), t = o !== -1 ? o : t, isNaN(t) && (t = e)), n.getPixelForDecimal((t - n._startValue) / n._valueRange)
                },
                getPixelForTick: function(e) {
                    var t = this.ticks;
                    return e < 0 || e > t.length - 1 ? null : this.getPixelForValue(t[e], e + this.minIndex)
                },
                getValueForPixel: function(e) {
                    var t = this,
                        a = Math.round(t._startValue + t.getDecimalForPixel(e) * t._valueRange);
                    return Math.min(Math.max(a, 0), t.ticks.length - 1)
                },
                getBasePixel: function() {
                    return this.bottom
                }
            }),
            Eo = Lo;
        Wn._defaults = Eo;
        var zo = v.noop,
            ot = v.isNullOrUndef;

        function Wo(e, t) {
            var a = [],
                n = 1e-14,
                r = e.stepSize,
                i = r || 1,
                o = e.maxTicks - 1,
                c = e.min,
                l = e.max,
                u = e.precision,
                h = t.min,
                f = t.max,
                p = v.niceNum((f - h) / o / i) * i,
                x, w, _, M;
            if (p < n && ot(c) && ot(l)) return [h, f];
            M = Math.ceil(f / p) - Math.floor(h / p), M > o && (p = v.niceNum(M * p / o / i) * i), r || ot(u) ? x = Math.pow(10, v._decimalPlaces(p)) : (x = Math.pow(10, u), p = Math.ceil(p * x) / x), w = Math.floor(h / p) * p, _ = Math.ceil(f / p) * p, r && (!ot(c) && v.almostWhole(c / p, p / 1e3) && (w = c), !ot(l) && v.almostWhole(l / p, p / 1e3) && (_ = l)), M = (_ - w) / p, v.almostEquals(M, Math.round(M), p / 1e3) ? M = Math.round(M) : M = Math.ceil(M), w = Math.round(w * x) / x, _ = Math.round(_ * x) / x, a.push(ot(c) ? w : c);
            for (var C = 1; C < M; ++C) a.push(Math.round((w + C * p) * x) / x);
            return a.push(ot(l) ? _ : l), a
        }
        var Jt = me.extend({
                getRightValue: function(e) {
                    return typeof e == "string" ? +e : me.prototype.getRightValue.call(this, e)
                },
                handleTickRangeOptions: function() {
                    var e = this,
                        t = e.options,
                        a = t.ticks;
                    if (a.beginAtZero) {
                        var n = v.sign(e.min),
                            r = v.sign(e.max);
                        n < 0 && r < 0 ? e.max = 0 : n > 0 && r > 0 && (e.min = 0)
                    }
                    var i = a.min !== void 0 || a.suggestedMin !== void 0,
                        o = a.max !== void 0 || a.suggestedMax !== void 0;
                    a.min !== void 0 ? e.min = a.min : a.suggestedMin !== void 0 && (e.min === null ? e.min = a.suggestedMin : e.min = Math.min(e.min, a.suggestedMin)), a.max !== void 0 ? e.max = a.max : a.suggestedMax !== void 0 && (e.max === null ? e.max = a.suggestedMax : e.max = Math.max(e.max, a.suggestedMax)), i !== o && e.min >= e.max && (i ? e.max = e.min + 1 : e.min = e.max - 1), e.min === e.max && (e.max++, a.beginAtZero || e.min--)
                },
                getTickLimit: function() {
                    var e = this,
                        t = e.options.ticks,
                        a = t.stepSize,
                        n = t.maxTicksLimit,
                        r;
                    return a ? r = Math.ceil(e.max / a) - Math.floor(e.min / a) + 1 : (r = e._computeTickLimit(), n = n || 11), n && (r = Math.min(n, r)), r
                },
                _computeTickLimit: function() {
                    return Number.POSITIVE_INFINITY
                },
                handleDirectionalChanges: zo,
                buildTicks: function() {
                    var e = this,
                        t = e.options,
                        a = t.ticks,
                        n = e.getTickLimit();
                    n = Math.max(2, n);
                    var r = {
                            maxTicks: n,
                            min: a.min,
                            max: a.max,
                            precision: a.precision,
                            stepSize: v.valueOrDefault(a.fixedStepSize, a.stepSize)
                        },
                        i = e.ticks = Wo(r, e);
                    e.handleDirectionalChanges(), e.max = v.max(i), e.min = v.min(i), a.reverse ? (i.reverse(), e.start = e.max, e.end = e.min) : (e.start = e.min, e.end = e.max)
                },
                convertTicksToLabels: function() {
                    var e = this;
                    e.ticksAsNumbers = e.ticks.slice(), e.zeroLineIndex = e.ticks.indexOf(0), me.prototype.convertTicksToLabels.call(e)
                },
                _configure: function() {
                    var e = this,
                        t = e.getTicks(),
                        a = e.min,
                        n = e.max,
                        r;
                    me.prototype._configure.call(e), e.options.offset && t.length && (r = (n - a) / Math.max(t.length - 1, 1) / 2, a -= r, n += r), e._startValue = a, e._endValue = n, e._valueRange = n - a
                }
            }),
            jo = {
                position: "left",
                ticks: {
                    callback: Ot.formatters.linear
                }
            },
            Ho = 0,
            Vo = 1;

        function Go(e, t, a) {
            var n = [a.type, t === void 0 && a.stack === void 0 ? a.index : "", a.stack].join(".");
            return e[n] === void 0 && (e[n] = {
                pos: [],
                neg: []
            }), e[n]
        }

        function $o(e, t, a, n) {
            var r = e.options,
                i = r.stacked,
                o = Go(t, i, a),
                c = o.pos,
                l = o.neg,
                u = n.length,
                h, f;
            for (h = 0; h < u; ++h) f = e._parseValue(n[h]), !(isNaN(f.min) || isNaN(f.max) || a.data[h].hidden) && (c[h] = c[h] || 0, l[h] = l[h] || 0, r.relativePoints ? c[h] = 100 : f.min < 0 || f.max < 0 ? l[h] += f.min : c[h] += f.max)
        }

        function qo(e, t, a) {
            var n = a.length,
                r, i;
            for (r = 0; r < n; ++r) i = e._parseValue(a[r]), !(isNaN(i.min) || isNaN(i.max) || t.data[r].hidden) && (e.min = Math.min(e.min, i.min), e.max = Math.max(e.max, i.max))
        }
        var jn = Jt.extend({
                determineDataLimits: function() {
                    var e = this,
                        t = e.options,
                        a = e.chart,
                        n = a.data.datasets,
                        r = e._getMatchingVisibleMetas(),
                        i = t.stacked,
                        o = {},
                        c = r.length,
                        l, u, h, f;
                    if (e.min = Number.POSITIVE_INFINITY, e.max = Number.NEGATIVE_INFINITY, i === void 0)
                        for (l = 0; !i && l < c; ++l) u = r[l], i = u.stack !== void 0;
                    for (l = 0; l < c; ++l) u = r[l], h = n[u.index].data, i ? $o(e, o, u, h) : qo(e, u, h);
                    v.each(o, function(p) {
                        f = p.pos.concat(p.neg), e.min = Math.min(e.min, v.min(f)), e.max = Math.max(e.max, v.max(f))
                    }), e.min = v.isFinite(e.min) && !isNaN(e.min) ? e.min : Ho, e.max = v.isFinite(e.max) && !isNaN(e.max) ? e.max : Vo, e.handleTickRangeOptions()
                },
                _computeTickLimit: function() {
                    var e = this,
                        t;
                    return e.isHorizontal() ? Math.ceil(e.width / 40) : (t = v.options._parseFont(e.options.ticks), Math.ceil(e.height / t.lineHeight))
                },
                handleDirectionalChanges: function() {
                    this.isHorizontal() || this.ticks.reverse()
                },
                getLabelForIndex: function(e, t) {
                    return this._getScaleLabel(this.chart.data.datasets[t].data[e])
                },
                getPixelForValue: function(e) {
                    var t = this;
                    return t.getPixelForDecimal((+t.getRightValue(e) - t._startValue) / t._valueRange)
                },
                getValueForPixel: function(e) {
                    return this._startValue + this.getDecimalForPixel(e) * this._valueRange
                },
                getPixelForTick: function(e) {
                    var t = this.ticksAsNumbers;
                    return e < 0 || e > t.length - 1 ? null : this.getPixelForValue(t[e])
                }
            }),
            Uo = jo;
        jn._defaults = Uo;
        var Fa = v.valueOrDefault,
            ge = v.math.log10;

        function Yo(e, t) {
            var a = [],
                n = Fa(e.min, Math.pow(10, Math.floor(ge(t.min)))),
                r = Math.floor(ge(t.max)),
                i = Math.ceil(t.max / Math.pow(10, r)),
                o, c;
            n === 0 ? (o = Math.floor(ge(t.minNotZero)), c = Math.floor(t.minNotZero / Math.pow(10, o)), a.push(n), n = c * Math.pow(10, o)) : (o = Math.floor(ge(n)), c = Math.floor(n / Math.pow(10, o)));
            var l = o < 0 ? Math.pow(10, Math.abs(o)) : 1;
            do a.push(n), ++c, c === 10 && (c = 1, ++o, l = o >= 0 ? 1 : l), n = Math.round(c * Math.pow(10, o) * l) / l; while (o < r || o === r && c < i);
            var u = Fa(e.max, n);
            return a.push(u), a
        }
        var Xo = {
            position: "left",
            ticks: {
                callback: Ot.formatters.logarithmic
            }
        };

        function Zt(e, t) {
            return v.isFinite(e) && e >= 0 ? e : t
        }
        var Hn = me.extend({
                determineDataLimits: function() {
                    var e = this,
                        t = e.options,
                        a = e.chart,
                        n = a.data.datasets,
                        r = e.isHorizontal();

                    function i(M) {
                        return r ? M.xAxisID === e.id : M.yAxisID === e.id
                    }
                    var o, c, l, u, h, f;
                    e.min = Number.POSITIVE_INFINITY, e.max = Number.NEGATIVE_INFINITY, e.minNotZero = Number.POSITIVE_INFINITY;
                    var p = t.stacked;
                    if (p === void 0) {
                        for (o = 0; o < n.length; o++)
                            if (c = a.getDatasetMeta(o), a.isDatasetVisible(o) && i(c) && c.stack !== void 0) {
                                p = !0;
                                break
                            }
                    }
                    if (t.stacked || p) {
                        var x = {};
                        for (o = 0; o < n.length; o++) {
                            c = a.getDatasetMeta(o);
                            var w = [c.type, t.stacked === void 0 && c.stack === void 0 ? o : "", c.stack].join(".");
                            if (a.isDatasetVisible(o) && i(c))
                                for (x[w] === void 0 && (x[w] = []), u = n[o].data, h = 0, f = u.length; h < f; h++) {
                                    var _ = x[w];
                                    l = e._parseValue(u[h]), !(isNaN(l.min) || isNaN(l.max) || c.data[h].hidden || l.min < 0 || l.max < 0) && (_[h] = _[h] || 0, _[h] += l.max)
                                }
                        }
                        v.each(x, function(M) {
                            if (M.length > 0) {
                                var C = v.min(M),
                                    T = v.max(M);
                                e.min = Math.min(e.min, C), e.max = Math.max(e.max, T)
                            }
                        })
                    } else
                        for (o = 0; o < n.length; o++)
                            if (c = a.getDatasetMeta(o), a.isDatasetVisible(o) && i(c))
                                for (u = n[o].data, h = 0, f = u.length; h < f; h++) l = e._parseValue(u[h]), !(isNaN(l.min) || isNaN(l.max) || c.data[h].hidden || l.min < 0 || l.max < 0) && (e.min = Math.min(l.min, e.min), e.max = Math.max(l.max, e.max), l.min !== 0 && (e.minNotZero = Math.min(l.min, e.minNotZero)));
                    e.min = v.isFinite(e.min) ? e.min : null, e.max = v.isFinite(e.max) ? e.max : null, e.minNotZero = v.isFinite(e.minNotZero) ? e.minNotZero : null, this.handleTickRangeOptions()
                },
                handleTickRangeOptions: function() {
                    var e = this,
                        t = e.options.ticks,
                        a = 1,
                        n = 10;
                    e.min = Zt(t.min, e.min), e.max = Zt(t.max, e.max), e.min === e.max && (e.min !== 0 && e.min !== null ? (e.min = Math.pow(10, Math.floor(ge(e.min)) - 1), e.max = Math.pow(10, Math.floor(ge(e.max)) + 1)) : (e.min = a, e.max = n)), e.min === null && (e.min = Math.pow(10, Math.floor(ge(e.max)) - 1)), e.max === null && (e.max = e.min !== 0 ? Math.pow(10, Math.floor(ge(e.min)) + 1) : n), e.minNotZero === null && (e.min > 0 ? e.minNotZero = e.min : e.max < 1 ? e.minNotZero = Math.pow(10, Math.floor(ge(e.max))) : e.minNotZero = a)
                },
                buildTicks: function() {
                    var e = this,
                        t = e.options.ticks,
                        a = !e.isHorizontal(),
                        n = {
                            min: Zt(t.min),
                            max: Zt(t.max)
                        },
                        r = e.ticks = Yo(n, e);
                    e.max = v.max(r), e.min = v.min(r), t.reverse ? (a = !a, e.start = e.max, e.end = e.min) : (e.start = e.min, e.end = e.max), a && r.reverse()
                },
                convertTicksToLabels: function() {
                    this.tickValues = this.ticks.slice(), me.prototype.convertTicksToLabels.call(this)
                },
                getLabelForIndex: function(e, t) {
                    return this._getScaleLabel(this.chart.data.datasets[t].data[e])
                },
                getPixelForTick: function(e) {
                    var t = this.tickValues;
                    return e < 0 || e > t.length - 1 ? null : this.getPixelForValue(t[e])
                },
                _getFirstTickValue: function(e) {
                    var t = Math.floor(ge(e)),
                        a = Math.floor(e / Math.pow(10, t));
                    return a * Math.pow(10, t)
                },
                _configure: function() {
                    var e = this,
                        t = e.min,
                        a = 0;
                    me.prototype._configure.call(e), t === 0 && (t = e._getFirstTickValue(e.minNotZero), a = Fa(e.options.ticks.fontSize, A.global.defaultFontSize) / e._length), e._startValue = ge(t), e._valueOffset = a, e._valueRange = (ge(e.max) - ge(t)) / (1 - a)
                },
                getPixelForValue: function(e) {
                    var t = this,
                        a = 0;
                    return e = +t.getRightValue(e), e > t.min && e > 0 && (a = (ge(e) - t._startValue) / t._valueRange + t._valueOffset), t.getPixelForDecimal(a)
                },
                getValueForPixel: function(e) {
                    var t = this,
                        a = t.getDecimalForPixel(e);
                    return a === 0 && t.min === 0 ? 0 : Math.pow(10, t._startValue + (a - t._valueOffset) * t._valueRange)
                }
            }),
            Ko = Xo;
        Hn._defaults = Ko;
        var Qt = v.valueOrDefault,
            La = v.valueAtIndexOrDefault,
            Vn = v.options.resolve,
            Jo = {
                display: !0,
                animate: !0,
                position: "chartArea",
                angleLines: {
                    display: !0,
                    color: "rgba(0,0,0,0.1)",
                    lineWidth: 1,
                    borderDash: [],
                    borderDashOffset: 0
                },
                gridLines: {
                    circular: !1
                },
                ticks: {
                    showLabelBackdrop: !0,
                    backdropColor: "rgba(255,255,255,0.75)",
                    backdropPaddingY: 2,
                    backdropPaddingX: 2,
                    callback: Ot.formatters.linear
                },
                pointLabels: {
                    display: !0,
                    fontSize: 10,
                    callback: function(e) {
                        return e
                    }
                }
            };

        function Ea(e) {
            var t = e.ticks;
            return t.display && e.display ? Qt(t.fontSize, A.global.defaultFontSize) + t.backdropPaddingY * 2 : 0
        }

        function Zo(e, t, a) {
            return v.isArray(a) ? {
                w: v.longestText(e, e.font, a),
                h: a.length * t
            } : {
                w: e.measureText(a).width,
                h: t
            }
        }

        function Gn(e, t, a, n, r) {
            return e === n || e === r ? {
                start: t - a / 2,
                end: t + a / 2
            } : e < n || e > r ? {
                start: t - a,
                end: t
            } : {
                start: t,
                end: t + a
            }
        }

        function Qo(e) {
            var t = v.options._parseFont(e.options.pointLabels),
                a = {
                    l: 0,
                    r: e.width,
                    t: 0,
                    b: e.height - e.paddingTop
                },
                n = {},
                r, i, o;
            e.ctx.font = t.string, e._pointLabelSizes = [];
            var c = e.chart.data.labels.length;
            for (r = 0; r < c; r++) {
                o = e.getPointPosition(r, e.drawingArea + 5), i = Zo(e.ctx, t.lineHeight, e.pointLabels[r]), e._pointLabelSizes[r] = i;
                var l = e.getIndexAngle(r),
                    u = v.toDegrees(l) % 360,
                    h = Gn(u, o.x, i.w, 0, 180),
                    f = Gn(u, o.y, i.h, 90, 270);
                h.start < a.l && (a.l = h.start, n.l = l), h.end > a.r && (a.r = h.end, n.r = l), f.start < a.t && (a.t = f.start, n.t = l), f.end > a.b && (a.b = f.end, n.b = l)
            }
            e.setReductions(e.drawingArea, a, n)
        }

        function es(e) {
            return e === 0 || e === 180 ? "center" : e < 180 ? "left" : "right"
        }

        function ts(e, t, a, n) {
            var r = a.y + n / 2,
                i, o;
            if (v.isArray(t))
                for (i = 0, o = t.length; i < o; ++i) e.fillText(t[i], a.x, r), r += n;
            else e.fillText(t, a.x, r)
        }

        function as(e, t, a) {
            e === 90 || e === 270 ? a.y -= t.h / 2 : (e > 270 || e < 90) && (a.y -= t.h)
        }

        function ns(e) {
            var t = e.ctx,
                a = e.options,
                n = a.pointLabels,
                r = Ea(a),
                i = e.getDistanceFromCenterForValue(a.ticks.reverse ? e.min : e.max),
                o = v.options._parseFont(n);
            t.save(), t.font = o.string, t.textBaseline = "middle";
            for (var c = e.chart.data.labels.length - 1; c >= 0; c--) {
                var l = c === 0 ? r / 2 : 0,
                    u = e.getPointPosition(c, i + l + 5),
                    h = La(n.fontColor, c, A.global.defaultFontColor);
                t.fillStyle = h;
                var f = e.getIndexAngle(c),
                    p = v.toDegrees(f);
                t.textAlign = es(p), as(p, e._pointLabelSizes[c], u), ts(t, e.pointLabels[c], u, o.lineHeight)
            }
            t.restore()
        }

        function rs(e, t, a, n) {
            var r = e.ctx,
                i = t.circular,
                o = e.chart.data.labels.length,
                c = La(t.color, n - 1),
                l = La(t.lineWidth, n - 1),
                u;
            if (!(!i && !o || !c || !l)) {
                if (r.save(), r.strokeStyle = c, r.lineWidth = l, r.setLineDash && (r.setLineDash(t.borderDash || []), r.lineDashOffset = t.borderDashOffset || 0), r.beginPath(), i) r.arc(e.xCenter, e.yCenter, a, 0, Math.PI * 2);
                else {
                    u = e.getPointPosition(0, a), r.moveTo(u.x, u.y);
                    for (var h = 1; h < o; h++) u = e.getPointPosition(h, a), r.lineTo(u.x, u.y)
                }
                r.closePath(), r.stroke(), r.restore()
            }
        }

        function ea(e) {
            return v.isNumber(e) ? e : 0
        }
        var $n = Jt.extend({
                setDimensions: function() {
                    var e = this;
                    e.width = e.maxWidth, e.height = e.maxHeight, e.paddingTop = Ea(e.options) / 2, e.xCenter = Math.floor(e.width / 2), e.yCenter = Math.floor((e.height - e.paddingTop) / 2), e.drawingArea = Math.min(e.height - e.paddingTop, e.width) / 2
                },
                determineDataLimits: function() {
                    var e = this,
                        t = e.chart,
                        a = Number.POSITIVE_INFINITY,
                        n = Number.NEGATIVE_INFINITY;
                    v.each(t.data.datasets, function(r, i) {
                        if (t.isDatasetVisible(i)) {
                            var o = t.getDatasetMeta(i);
                            v.each(r.data, function(c, l) {
                                var u = +e.getRightValue(c);
                                isNaN(u) || o.data[l].hidden || (a = Math.min(u, a), n = Math.max(u, n))
                            })
                        }
                    }), e.min = a === Number.POSITIVE_INFINITY ? 0 : a, e.max = n === Number.NEGATIVE_INFINITY ? 0 : n, e.handleTickRangeOptions()
                },
                _computeTickLimit: function() {
                    return Math.ceil(this.drawingArea / Ea(this.options))
                },
                convertTicksToLabels: function() {
                    var e = this;
                    Jt.prototype.convertTicksToLabels.call(e), e.pointLabels = e.chart.data.labels.map(function() {
                        var t = v.callback(e.options.pointLabels.callback, arguments, e);
                        return t || t === 0 ? t : ""
                    })
                },
                getLabelForIndex: function(e, t) {
                    return +this.getRightValue(this.chart.data.datasets[t].data[e])
                },
                fit: function() {
                    var e = this,
                        t = e.options;
                    t.display && t.pointLabels.display ? Qo(e) : e.setCenterPoint(0, 0, 0, 0)
                },
                setReductions: function(e, t, a) {
                    var n = this,
                        r = t.l / Math.sin(a.l),
                        i = Math.max(t.r - n.width, 0) / Math.sin(a.r),
                        o = -t.t / Math.cos(a.t),
                        c = -Math.max(t.b - (n.height - n.paddingTop), 0) / Math.cos(a.b);
                    r = ea(r), i = ea(i), o = ea(o), c = ea(c), n.drawingArea = Math.min(Math.floor(e - (r + i) / 2), Math.floor(e - (o + c) / 2)), n.setCenterPoint(r, i, o, c)
                },
                setCenterPoint: function(e, t, a, n) {
                    var r = this,
                        i = r.width - t - r.drawingArea,
                        o = e + r.drawingArea,
                        c = a + r.drawingArea,
                        l = r.height - r.paddingTop - n - r.drawingArea;
                    r.xCenter = Math.floor((o + i) / 2 + r.left), r.yCenter = Math.floor((c + l) / 2 + r.top + r.paddingTop)
                },
                getIndexAngle: function(e) {
                    var t = this.chart,
                        a = 360 / t.data.labels.length,
                        n = t.options || {},
                        r = n.startAngle || 0,
                        i = (e * a + r) % 360;
                    return (i < 0 ? i + 360 : i) * Math.PI * 2 / 360
                },
                getDistanceFromCenterForValue: function(e) {
                    var t = this;
                    if (v.isNullOrUndef(e)) return NaN;
                    var a = t.drawingArea / (t.max - t.min);
                    return t.options.ticks.reverse ? (t.max - e) * a : (e - t.min) * a
                },
                getPointPosition: function(e, t) {
                    var a = this,
                        n = a.getIndexAngle(e) - Math.PI / 2;
                    return {
                        x: Math.cos(n) * t + a.xCenter,
                        y: Math.sin(n) * t + a.yCenter
                    }
                },
                getPointPositionForValue: function(e, t) {
                    return this.getPointPosition(e, this.getDistanceFromCenterForValue(t))
                },
                getBasePosition: function(e) {
                    var t = this,
                        a = t.min,
                        n = t.max;
                    return t.getPointPositionForValue(e || 0, t.beginAtZero ? 0 : a < 0 && n < 0 ? n : a > 0 && n > 0 ? a : 0)
                },
                _drawGrid: function() {
                    var e = this,
                        t = e.ctx,
                        a = e.options,
                        n = a.gridLines,
                        r = a.angleLines,
                        i = Qt(r.lineWidth, n.lineWidth),
                        o = Qt(r.color, n.color),
                        c, l, u;
                    if (a.pointLabels.display && ns(e), n.display && v.each(e.ticks, function(h, f) {
                            f !== 0 && (l = e.getDistanceFromCenterForValue(e.ticksAsNumbers[f]), rs(e, n, l, f))
                        }), r.display && i && o) {
                        for (t.save(), t.lineWidth = i, t.strokeStyle = o, t.setLineDash && (t.setLineDash(Vn([r.borderDash, n.borderDash, []])), t.lineDashOffset = Vn([r.borderDashOffset, n.borderDashOffset, 0])), c = e.chart.data.labels.length - 1; c >= 0; c--) l = e.getDistanceFromCenterForValue(a.ticks.reverse ? e.min : e.max), u = e.getPointPosition(c, l), t.beginPath(), t.moveTo(e.xCenter, e.yCenter), t.lineTo(u.x, u.y), t.stroke();
                        t.restore()
                    }
                },
                _drawLabels: function() {
                    var e = this,
                        t = e.ctx,
                        a = e.options,
                        n = a.ticks;
                    if (!!n.display) {
                        var r = e.getIndexAngle(0),
                            i = v.options._parseFont(n),
                            o = Qt(n.fontColor, A.global.defaultFontColor),
                            c, l;
                        t.save(), t.font = i.string, t.translate(e.xCenter, e.yCenter), t.rotate(r), t.textAlign = "center", t.textBaseline = "middle", v.each(e.ticks, function(u, h) {
                            h === 0 && !n.reverse || (c = e.getDistanceFromCenterForValue(e.ticksAsNumbers[h]), n.showLabelBackdrop && (l = t.measureText(u).width, t.fillStyle = n.backdropColor, t.fillRect(-l / 2 - n.backdropPaddingX, -c - i.size / 2 - n.backdropPaddingY, l + n.backdropPaddingX * 2, i.size + n.backdropPaddingY * 2)), t.fillStyle = o, t.fillText(u, 0, -c))
                        }), t.restore()
                    }
                },
                _drawTitle: v.noop
            }),
            is = Jo;
        $n._defaults = is;
        var za = v._deprecated,
            qn = v.options.resolve,
            os = v.valueOrDefault,
            Un = Number.MIN_SAFE_INTEGER || -9007199254740991,
            Wa = Number.MAX_SAFE_INTEGER || 9007199254740991,
            ta = {
                millisecond: {
                    common: !0,
                    size: 1,
                    steps: 1e3
                },
                second: {
                    common: !0,
                    size: 1e3,
                    steps: 60
                },
                minute: {
                    common: !0,
                    size: 6e4,
                    steps: 60
                },
                hour: {
                    common: !0,
                    size: 36e5,
                    steps: 24
                },
                day: {
                    common: !0,
                    size: 864e5,
                    steps: 30
                },
                week: {
                    common: !1,
                    size: 6048e5,
                    steps: 4
                },
                month: {
                    common: !0,
                    size: 2628e6,
                    steps: 12
                },
                quarter: {
                    common: !1,
                    size: 7884e6,
                    steps: 4
                },
                year: {
                    common: !0,
                    size: 3154e7
                }
            },
            be = Object.keys(ta);

        function Yn(e, t) {
            return e - t
        }

        function ss(e) {
            var t = {},
                a = [],
                n, r, i;
            for (n = 0, r = e.length; n < r; ++n) i = e[n], t[i] || (t[i] = !0, a.push(i));
            return a
        }

        function Xn(e) {
            return v.valueOrDefault(e.time.min, e.ticks.min)
        }

        function Kn(e) {
            return v.valueOrDefault(e.time.max, e.ticks.max)
        }

        function ls(e, t, a, n) {
            if (n === "linear" || !e.length) return [{
                time: t,
                pos: 0
            }, {
                time: a,
                pos: 1
            }];
            var r = [],
                i = [t],
                o, c, l, u, h;
            for (o = 0, c = e.length; o < c; ++o) u = e[o], u > t && u < a && i.push(u);
            for (i.push(a), o = 0, c = i.length; o < c; ++o) h = i[o + 1], l = i[o - 1], u = i[o], (l === void 0 || h === void 0 || Math.round((h + l) / 2) !== u) && r.push({
                time: u,
                pos: o / (c - 1)
            });
            return r
        }

        function cs(e, t, a) {
            for (var n = 0, r = e.length - 1, i, o, c; n >= 0 && n <= r;)
                if (i = n + r >> 1, o = e[i - 1] || null, c = e[i], o)
                    if (c[t] < a) n = i + 1;
                    else if (o[t] > a) r = i - 1;
            else return {
                lo: o,
                hi: c
            };
            else return {
                lo: null,
                hi: c
            };
            return {
                lo: c,
                hi: null
            }
        }

        function vt(e, t, a, n) {
            var r = cs(e, t, a),
                i = r.lo ? r.hi ? r.lo : e[e.length - 2] : e[0],
                o = r.lo ? r.hi ? r.hi : e[e.length - 1] : e[1],
                c = o[t] - i[t],
                l = c ? (a - i[t]) / c : 0,
                u = (o[n] - i[n]) * l;
            return i[n] + u
        }

        function ja(e, t) {
            var a = e._adapter,
                n = e.options.time,
                r = n.parser,
                i = r || n.format,
                o = t;
            return typeof r == "function" && (o = r(o)), v.isFinite(o) || (o = typeof i == "string" ? a.parse(o, i) : a.parse(o)), o !== null ? +o : (!r && typeof i == "function" && (o = i(t), v.isFinite(o) || (o = a.parse(o))), o)
        }

        function st(e, t) {
            if (v.isNullOrUndef(t)) return null;
            var a = e.options.time,
                n = ja(e, e.getRightValue(t));
            return n === null || a.round && (n = +e._adapter.startOf(n, a.round)), n
        }

        function Jn(e, t, a, n) {
            var r = be.length,
                i, o, c;
            for (i = be.indexOf(e); i < r - 1; ++i)
                if (o = ta[be[i]], c = o.steps ? o.steps : Wa, o.common && Math.ceil((a - t) / (c * o.size)) <= n) return be[i];
            return be[r - 1]
        }

        function us(e, t, a, n, r) {
            var i, o;
            for (i = be.length - 1; i >= be.indexOf(a); i--)
                if (o = be[i], ta[o].common && e._adapter.diff(r, n, o) >= t - 1) return o;
            return be[a ? be.indexOf(a) : 0]
        }

        function ds(e) {
            for (var t = be.indexOf(e) + 1, a = be.length; t < a; ++t)
                if (ta[be[t]].common) return be[t]
        }

        function hs(e, t, a, n) {
            var r = e._adapter,
                i = e.options,
                o = i.time,
                c = o.unit || Jn(o.minUnit, t, a, n),
                l = qn([o.stepSize, o.unitStepSize, 1]),
                u = c === "week" ? o.isoWeekday : !1,
                h = t,
                f = [],
                p;
            if (u && (h = +r.startOf(h, "isoWeek", u)), h = +r.startOf(h, u ? "day" : c), r.diff(a, t, c) > 1e5 * l) throw t + " and " + a + " are too far apart with stepSize of " + l + " " + c;
            for (p = h; p < a; p = +r.add(p, l, c)) f.push(p);
            return (p === a || i.bounds === "ticks") && f.push(p), f
        }

        function fs(e, t, a, n, r) {
            var i = 0,
                o = 0,
                c, l;
            return r.offset && t.length && (c = vt(e, "time", t[0], "pos"), t.length === 1 ? i = 1 - c : i = (vt(e, "time", t[1], "pos") - c) / 2, l = vt(e, "time", t[t.length - 1], "pos"), t.length === 1 ? o = l : o = (l - vt(e, "time", t[t.length - 2], "pos")) / 2), {
                start: i,
                end: o,
                factor: 1 / (i + 1 + o)
            }
        }

        function vs(e, t, a, n) {
            var r = e._adapter,
                i = +r.startOf(t[0].value, n),
                o = t[t.length - 1].value,
                c, l;
            for (c = i; c <= o; c = +r.add(c, 1, n)) l = a[c], l >= 0 && (t[l].major = !0);
            return t
        }

        function Zn(e, t, a) {
            var n = [],
                r = {},
                i = t.length,
                o, c;
            for (o = 0; o < i; ++o) c = t[o], r[c] = o, n.push({
                value: c,
                major: !1
            });
            return i === 0 || !a ? n : vs(e, n, r, a)
        }
        var ps = {
                position: "bottom",
                distribution: "linear",
                bounds: "data",
                adapters: {},
                time: {
                    parser: !1,
                    unit: !1,
                    round: !1,
                    displayFormat: !1,
                    isoWeekday: !1,
                    minUnit: "millisecond",
                    displayFormats: {}
                },
                ticks: {
                    autoSkip: !1,
                    source: "auto",
                    major: {
                        enabled: !1
                    }
                }
            },
            Qn = me.extend({
                initialize: function() {
                    this.mergeTicksOptions(), me.prototype.initialize.call(this)
                },
                update: function() {
                    var e = this,
                        t = e.options,
                        a = t.time || (t.time = {}),
                        n = e._adapter = new Na._date(t.adapters.date);
                    return za("time scale", a.format, "time.format", "time.parser"), za("time scale", a.min, "time.min", "ticks.min"), za("time scale", a.max, "time.max", "ticks.max"), v.mergeIf(a.displayFormats, n.formats()), me.prototype.update.apply(e, arguments)
                },
                getRightValue: function(e) {
                    return e && e.t !== void 0 && (e = e.t), me.prototype.getRightValue.call(this, e)
                },
                determineDataLimits: function() {
                    var e = this,
                        t = e.chart,
                        a = e._adapter,
                        n = e.options,
                        r = n.time.unit || "day",
                        i = Wa,
                        o = Un,
                        c = [],
                        l = [],
                        u = [],
                        h, f, p, x, w, _, M, C = e._getLabels();
                    for (h = 0, p = C.length; h < p; ++h) u.push(st(e, C[h]));
                    for (h = 0, p = (t.data.datasets || []).length; h < p; ++h)
                        if (t.isDatasetVisible(h))
                            if (w = t.data.datasets[h].data, v.isObject(w[0]))
                                for (l[h] = [], f = 0, x = w.length; f < x; ++f) _ = st(e, w[f]), c.push(_), l[h][f] = _;
                            else l[h] = u.slice(0), M || (c = c.concat(u), M = !0);
                    else l[h] = [];
                    u.length && (i = Math.min(i, u[0]), o = Math.max(o, u[u.length - 1])), c.length && (c = p > 1 ? ss(c).sort(Yn) : c.sort(Yn), i = Math.min(i, c[0]), o = Math.max(o, c[c.length - 1])), i = st(e, Xn(n)) || i, o = st(e, Kn(n)) || o, i = i === Wa ? +a.startOf(Date.now(), r) : i, o = o === Un ? +a.endOf(Date.now(), r) + 1 : o, e.min = Math.min(i, o), e.max = Math.max(i + 1, o), e._table = [], e._timestamps = {
                        data: c,
                        datasets: l,
                        labels: u
                    }
                },
                buildTicks: function() {
                    var e = this,
                        t = e.min,
                        a = e.max,
                        n = e.options,
                        r = n.ticks,
                        i = n.time,
                        o = e._timestamps,
                        c = [],
                        l = e.getLabelCapacity(t),
                        u = r.source,
                        h = n.distribution,
                        f, p, x;
                    for (u === "data" || u === "auto" && h === "series" ? o = o.data : u === "labels" ? o = o.labels : o = hs(e, t, a, l), n.bounds === "ticks" && o.length && (t = o[0], a = o[o.length - 1]), t = st(e, Xn(n)) || t, a = st(e, Kn(n)) || a, f = 0, p = o.length; f < p; ++f) x = o[f], x >= t && x <= a && c.push(x);
                    return e.min = t, e.max = a, e._unit = i.unit || (r.autoSkip ? Jn(i.minUnit, e.min, e.max, l) : us(e, c.length, i.minUnit, e.min, e.max)), e._majorUnit = !r.major.enabled || e._unit === "year" ? void 0 : ds(e._unit), e._table = ls(e._timestamps.data, t, a, h), e._offsets = fs(e._table, c, t, a, n), r.reverse && c.reverse(), Zn(e, c, e._majorUnit)
                },
                getLabelForIndex: function(e, t) {
                    var a = this,
                        n = a._adapter,
                        r = a.chart.data,
                        i = a.options.time,
                        o = r.labels && e < r.labels.length ? r.labels[e] : "",
                        c = r.datasets[t].data[e];
                    return v.isObject(c) && (o = a.getRightValue(c)), i.tooltipFormat ? n.format(ja(a, o), i.tooltipFormat) : typeof o == "string" ? o : n.format(ja(a, o), i.displayFormats.datetime)
                },
                tickFormatFunction: function(e, t, a, n) {
                    var r = this,
                        i = r._adapter,
                        o = r.options,
                        c = o.time.displayFormats,
                        l = c[r._unit],
                        u = r._majorUnit,
                        h = c[u],
                        f = a[t],
                        p = o.ticks,
                        x = u && h && f && f.major,
                        w = i.format(e, n || (x ? h : l)),
                        _ = x ? p.major : p.minor,
                        M = qn([_.callback, _.userCallback, p.callback, p.userCallback]);
                    return M ? M(w, t, a) : w
                },
                convertTicksToLabels: function(e) {
                    var t = [],
                        a, n;
                    for (a = 0, n = e.length; a < n; ++a) t.push(this.tickFormatFunction(e[a].value, a, e));
                    return t
                },
                getPixelForOffset: function(e) {
                    var t = this,
                        a = t._offsets,
                        n = vt(t._table, "time", e, "pos");
                    return t.getPixelForDecimal((a.start + n) * a.factor)
                },
                getPixelForValue: function(e, t, a) {
                    var n = this,
                        r = null;
                    if (t !== void 0 && a !== void 0 && (r = n._timestamps.datasets[a][t]), r === null && (r = st(n, e)), r !== null) return n.getPixelForOffset(r)
                },
                getPixelForTick: function(e) {
                    var t = this.getTicks();
                    return e >= 0 && e < t.length ? this.getPixelForOffset(t[e].value) : null
                },
                getValueForPixel: function(e) {
                    var t = this,
                        a = t._offsets,
                        n = t.getDecimalForPixel(e) / a.factor - a.end,
                        r = vt(t._table, "pos", n, "time");
                    return t._adapter._create(r)
                },
                _getLabelSize: function(e) {
                    var t = this,
                        a = t.options.ticks,
                        n = t.ctx.measureText(e).width,
                        r = v.toRadians(t.isHorizontal() ? a.maxRotation : a.minRotation),
                        i = Math.cos(r),
                        o = Math.sin(r),
                        c = os(a.fontSize, A.global.defaultFontSize);
                    return {
                        w: n * i + c * o,
                        h: n * o + c * i
                    }
                },
                getLabelWidth: function(e) {
                    return this._getLabelSize(e).w
                },
                getLabelCapacity: function(e) {
                    var t = this,
                        a = t.options.time,
                        n = a.displayFormats,
                        r = n[a.unit] || n.millisecond,
                        i = t.tickFormatFunction(e, 0, Zn(t, [e], t._majorUnit), r),
                        o = t._getLabelSize(i),
                        c = Math.floor(t.isHorizontal() ? t.width / o.w : t.height / o.h);
                    return t.options.offset && c--, c > 0 ? c : 1
                }
            }),
            ms = ps;
        Qn._defaults = ms;
        var gs = {
                category: Wn,
                linear: jn,
                logarithmic: Hn,
                radialLinear: $n,
                time: Qn
            },
            bs = {
                datetime: "MMM D, YYYY, h:mm:ss a",
                millisecond: "h:mm:ss.SSS a",
                second: "h:mm:ss a",
                minute: "h:mm a",
                hour: "hA",
                day: "MMM D",
                week: "ll",
                month: "MMM YYYY",
                quarter: "[Q]Q - YYYY",
                year: "YYYY"
            };
        Na._date.override(typeof s == "function" ? {
            _id: "moment",
            formats: function() {
                return bs
            },
            parse: function(e, t) {
                return typeof e == "string" && typeof t == "string" ? e = s(e, t) : e instanceof s || (e = s(e)), e.isValid() ? e.valueOf() : null
            },
            format: function(e, t) {
                return s(e).format(t)
            },
            add: function(e, t, a) {
                return s(e).add(t, a).valueOf()
            },
            diff: function(e, t, a) {
                return s(e).diff(s(t), a)
            },
            startOf: function(e, t, a) {
                return e = s(e), t === "isoWeek" ? e.isoWeekday(a).valueOf() : e.startOf(t).valueOf()
            },
            endOf: function(e, t) {
                return s(e).endOf(t).valueOf()
            },
            _create: function(e) {
                return s(e)
            }
        } : {}), A._set("global", {
            plugins: {
                filler: {
                    propagate: !0
                }
            }
        });
        var ys = {
            dataset: function(e) {
                var t = e.fill,
                    a = e.chart,
                    n = a.getDatasetMeta(t),
                    r = n && a.isDatasetVisible(t),
                    i = r && n.dataset._children || [],
                    o = i.length || 0;
                return o ? function(c, l) {
                    return l < o && i[l]._view || null
                } : null
            },
            boundary: function(e) {
                var t = e.boundary,
                    a = t ? t.x : null,
                    n = t ? t.y : null;
                return v.isArray(t) ? function(r, i) {
                    return t[i]
                } : function(r) {
                    return {
                        x: a === null ? r.x : a,
                        y: n === null ? r.y : n
                    }
                }
            }
        };

        function xs(e, t, a) {
            var n = e._model || {},
                r = n.fill,
                i;
            if (r === void 0 && (r = !!n.backgroundColor), r === !1 || r === null) return !1;
            if (r === !0) return "origin";
            if (i = parseFloat(r, 10), isFinite(i) && Math.floor(i) === i) return (r[0] === "-" || r[0] === "+") && (i = t + i), i === t || i < 0 || i >= a ? !1 : i;
            switch (r) {
                case "bottom":
                    return "start";
                case "top":
                    return "end";
                case "zero":
                    return "origin";
                case "origin":
                case "start":
                case "end":
                    return r;
                default:
                    return !1
            }
        }

        function ws(e) {
            var t = e.el._model || {},
                a = e.el._scale || {},
                n = e.fill,
                r = null,
                i;
            if (isFinite(n)) return null;
            if (n === "start" ? r = t.scaleBottom === void 0 ? a.bottom : t.scaleBottom : n === "end" ? r = t.scaleTop === void 0 ? a.top : t.scaleTop : t.scaleZero !== void 0 ? r = t.scaleZero : a.getBasePixel && (r = a.getBasePixel()), r != null) {
                if (r.x !== void 0 && r.y !== void 0) return r;
                if (v.isFinite(r)) return i = a.isHorizontal(), {
                    x: i ? r : null,
                    y: i ? null : r
                }
            }
            return null
        }

        function ks(e) {
            var t = e.el._scale,
                a = t.options,
                n = t.chart.data.labels.length,
                r = e.fill,
                i = [],
                o, c, l, u, h;
            if (!n) return null;
            for (o = a.ticks.reverse ? t.max : t.min, c = a.ticks.reverse ? t.min : t.max, l = t.getPointPositionForValue(0, o), u = 0; u < n; ++u) h = r === "start" || r === "end" ? t.getPointPositionForValue(u, r === "start" ? o : c) : t.getBasePosition(u), a.gridLines.circular && (h.cx = l.x, h.cy = l.y, h.angle = t.getIndexAngle(u) - Math.PI / 2), i.push(h);
            return i
        }

        function _s(e) {
            var t = e.el._scale || {};
            return t.getPointPositionForValue ? ks(e) : ws(e)
        }

        function Ms(e, t, a) {
            var n = e[t],
                r = n.fill,
                i = [t],
                o;
            if (!a) return r;
            for (; r !== !1 && i.indexOf(r) === -1;) {
                if (!isFinite(r)) return r;
                if (o = e[r], !o) return !1;
                if (o.visible) return r;
                i.push(r), r = o.fill
            }
            return !1
        }

        function Is(e) {
            var t = e.fill,
                a = "dataset";
            return t === !1 ? null : (isFinite(t) || (a = "boundary"), ys[a](e))
        }

        function er(e) {
            return e && !e.skip
        }

        function tr(e, t, a, n, r) {
            var i, o, c, l;
            if (!(!n || !r)) {
                for (e.moveTo(t[0].x, t[0].y), i = 1; i < n; ++i) v.canvas.lineTo(e, t[i - 1], t[i]);
                if (a[0].angle !== void 0) {
                    for (o = a[0].cx, c = a[0].cy, l = Math.sqrt(Math.pow(a[0].x - o, 2) + Math.pow(a[0].y - c, 2)), i = r - 1; i > 0; --i) e.arc(o, c, l, a[i].angle, a[i - 1].angle, !0);
                    return
                }
                for (e.lineTo(a[r - 1].x, a[r - 1].y), i = r - 1; i > 0; --i) v.canvas.lineTo(e, a[i], a[i - 1], !0)
            }
        }

        function Ss(e, t, a, n, r, i) {
            var o = t.length,
                c = n.spanGaps,
                l = [],
                u = [],
                h = 0,
                f = 0,
                p, x, w, _, M, C, T, N;
            for (e.beginPath(), p = 0, x = o; p < x; ++p) w = p % o, _ = t[w]._view, M = a(_, w, n), C = er(_), T = er(M), i && N === void 0 && C && (N = p + 1, x = o + N), C && T ? (h = l.push(_), f = u.push(M)) : h && f && (c ? (C && l.push(_), T && u.push(M)) : (tr(e, l, u, h, f), h = f = 0, l = [], u = []));
            tr(e, l, u, h, f), e.closePath(), e.fillStyle = r, e.fill()
        }
        var Cs = {
                id: "filler",
                afterDatasetsUpdate: function(e, t) {
                    var a = (e.data.datasets || []).length,
                        n = t.propagate,
                        r = [],
                        i, o, c, l;
                    for (o = 0; o < a; ++o) i = e.getDatasetMeta(o), c = i.dataset, l = null, c && c._model && c instanceof pe.Line && (l = {
                        visible: e.isDatasetVisible(o),
                        fill: xs(c, o, a),
                        chart: e,
                        el: c
                    }), i.$filler = l, r.push(l);
                    for (o = 0; o < a; ++o) l = r[o], l && (l.fill = Ms(r, o, n), l.boundary = _s(l), l.mapper = Is(l))
                },
                beforeDatasetsDraw: function(e) {
                    var t = e._getSortedVisibleDatasetMetas(),
                        a = e.ctx,
                        n, r, i, o, c, l, u;
                    for (r = t.length - 1; r >= 0; --r) n = t[r].$filler, !(!n || !n.visible) && (i = n.el, o = i._view, c = i._children || [], l = n.mapper, u = o.backgroundColor || A.global.defaultColor, l && u && c.length && (v.canvas.clipArea(a, e.chartArea), Ss(a, c, l, o, u, i._loop), v.canvas.unclipArea(a)))
                }
            },
            Ps = v.rtl.getRtlAdapter,
            Xe = v.noop,
            Ke = v.valueOrDefault;
        A._set("global", {
            legend: {
                display: !0,
                position: "top",
                align: "center",
                fullWidth: !0,
                reverse: !1,
                weight: 1e3,
                onClick: function(e, t) {
                    var a = t.datasetIndex,
                        n = this.chart,
                        r = n.getDatasetMeta(a);
                    r.hidden = r.hidden === null ? !n.data.datasets[a].hidden : null, n.update()
                },
                onHover: null,
                onLeave: null,
                labels: {
                    boxWidth: 40,
                    padding: 10,
                    generateLabels: function(e) {
                        var t = e.data.datasets,
                            a = e.options.legend || {},
                            n = a.labels && a.labels.usePointStyle;
                        return e._getSortedDatasetMetas().map(function(r) {
                            var i = r.controller.getStyle(n ? 0 : void 0);
                            return {
                                text: t[r.index].label,
                                fillStyle: i.backgroundColor,
                                hidden: !e.isDatasetVisible(r.index),
                                lineCap: i.borderCapStyle,
                                lineDash: i.borderDash,
                                lineDashOffset: i.borderDashOffset,
                                lineJoin: i.borderJoinStyle,
                                lineWidth: i.borderWidth,
                                strokeStyle: i.borderColor,
                                pointStyle: i.pointStyle,
                                rotation: i.rotation,
                                datasetIndex: r.index
                            }
                        }, this)
                    }
                }
            },
            legendCallback: function(e) {
                var t = document.createElement("ul"),
                    a = e.data.datasets,
                    n, r, i, o;
                for (t.setAttribute("class", e.id + "-legend"), n = 0, r = a.length; n < r; n++) i = t.appendChild(document.createElement("li")), o = i.appendChild(document.createElement("span")), o.style.backgroundColor = a[n].backgroundColor, a[n].label && i.appendChild(document.createTextNode(a[n].label));
                return t.outerHTML
            }
        });

        function Ha(e, t) {
            return e.usePointStyle && e.boxWidth > t ? t : e.boxWidth
        }
        var ar = Le.extend({
            initialize: function(e) {
                var t = this;
                v.extend(t, e), t.legendHitBoxes = [], t._hoveredItem = null, t.doughnutMode = !1
            },
            beforeUpdate: Xe,
            update: function(e, t, a) {
                var n = this;
                return n.beforeUpdate(), n.maxWidth = e, n.maxHeight = t, n.margins = a, n.beforeSetDimensions(), n.setDimensions(), n.afterSetDimensions(), n.beforeBuildLabels(), n.buildLabels(), n.afterBuildLabels(), n.beforeFit(), n.fit(), n.afterFit(), n.afterUpdate(), n.minSize
            },
            afterUpdate: Xe,
            beforeSetDimensions: Xe,
            setDimensions: function() {
                var e = this;
                e.isHorizontal() ? (e.width = e.maxWidth, e.left = 0, e.right = e.width) : (e.height = e.maxHeight, e.top = 0, e.bottom = e.height), e.paddingLeft = 0, e.paddingTop = 0, e.paddingRight = 0, e.paddingBottom = 0, e.minSize = {
                    width: 0,
                    height: 0
                }
            },
            afterSetDimensions: Xe,
            beforeBuildLabels: Xe,
            buildLabels: function() {
                var e = this,
                    t = e.options.labels || {},
                    a = v.callback(t.generateLabels, [e.chart], e) || [];
                t.filter && (a = a.filter(function(n) {
                    return t.filter(n, e.chart.data)
                })), e.options.reverse && a.reverse(), e.legendItems = a
            },
            afterBuildLabels: Xe,
            beforeFit: Xe,
            fit: function() {
                var e = this,
                    t = e.options,
                    a = t.labels,
                    n = t.display,
                    r = e.ctx,
                    i = v.options._parseFont(a),
                    o = i.size,
                    c = e.legendHitBoxes = [],
                    l = e.minSize,
                    u = e.isHorizontal();
                if (u ? (l.width = e.maxWidth, l.height = n ? 10 : 0) : (l.width = n ? 10 : 0, l.height = e.maxHeight), !n) {
                    e.width = l.width = e.height = l.height = 0;
                    return
                }
                if (r.font = i.string, u) {
                    var h = e.lineWidths = [0],
                        f = 0;
                    r.textAlign = "left", r.textBaseline = "middle", v.each(e.legendItems, function(T, N) {
                        var W = Ha(a, o),
                            E = W + o / 2 + r.measureText(T.text).width;
                        (N === 0 || h[h.length - 1] + E + 2 * a.padding > l.width) && (f += o + a.padding, h[h.length - (N > 0 ? 0 : 1)] = 0), c[N] = {
                            left: 0,
                            top: 0,
                            width: E,
                            height: o
                        }, h[h.length - 1] += E + a.padding
                    }), l.height += f
                } else {
                    var p = a.padding,
                        x = e.columnWidths = [],
                        w = e.columnHeights = [],
                        _ = a.padding,
                        M = 0,
                        C = 0;
                    v.each(e.legendItems, function(T, N) {
                        var W = Ha(a, o),
                            E = W + o / 2 + r.measureText(T.text).width;
                        N > 0 && C + o + 2 * p > l.height && (_ += M + a.padding, x.push(M), w.push(C), M = 0, C = 0), M = Math.max(M, E), C += o + p, c[N] = {
                            left: 0,
                            top: 0,
                            width: E,
                            height: o
                        }
                    }), _ += M, x.push(M), w.push(C), l.width += _
                }
                e.width = l.width, e.height = l.height
            },
            afterFit: Xe,
            isHorizontal: function() {
                return this.options.position === "top" || this.options.position === "bottom"
            },
            draw: function() {
                var e = this,
                    t = e.options,
                    a = t.labels,
                    n = A.global,
                    r = n.defaultColor,
                    i = n.elements.line,
                    o = e.height,
                    c = e.columnHeights,
                    l = e.width,
                    u = e.lineWidths;
                if (!!t.display) {
                    var h = Ps(t.rtl, e.left, e.minSize.width),
                        f = e.ctx,
                        p = Ke(a.fontColor, n.defaultFontColor),
                        x = v.options._parseFont(a),
                        w = x.size,
                        _;
                    f.textAlign = h.textAlign("left"), f.textBaseline = "middle", f.lineWidth = .5, f.strokeStyle = p, f.fillStyle = p, f.font = x.string;
                    var M = Ha(a, w),
                        C = e.legendHitBoxes,
                        T = function(G, U, J) {
                            if (!(isNaN(M) || M <= 0)) {
                                f.save();
                                var ie = Ke(J.lineWidth, i.borderWidth);
                                if (f.fillStyle = Ke(J.fillStyle, r), f.lineCap = Ke(J.lineCap, i.borderCapStyle), f.lineDashOffset = Ke(J.lineDashOffset, i.borderDashOffset), f.lineJoin = Ke(J.lineJoin, i.borderJoinStyle), f.lineWidth = ie, f.strokeStyle = Ke(J.strokeStyle, r), f.setLineDash && f.setLineDash(Ke(J.lineDash, i.borderDash)), a && a.usePointStyle) {
                                    var ae = M * Math.SQRT2 / 2,
                                        te = h.xPlus(G, M / 2),
                                        se = U + w / 2;
                                    v.canvas.drawPoint(f, J.pointStyle, ae, te, se, J.rotation)
                                } else f.fillRect(h.leftForLtr(G, M), U, M, w), ie !== 0 && f.strokeRect(h.leftForLtr(G, M), U, M, w);
                                f.restore()
                            }
                        },
                        N = function(G, U, J, ie) {
                            var ae = w / 2,
                                te = h.xPlus(G, M + ae),
                                se = U + ae;
                            f.fillText(J.text, te, se), J.hidden && (f.beginPath(), f.lineWidth = 2, f.moveTo(te, se), f.lineTo(h.xPlus(te, ie), se), f.stroke())
                        },
                        W = function(G, U) {
                            switch (t.align) {
                                case "start":
                                    return a.padding;
                                case "end":
                                    return G - U;
                                default:
                                    return (G - U + a.padding) / 2
                            }
                        },
                        E = e.isHorizontal();
                    E ? _ = {
                        x: e.left + W(l, u[0]),
                        y: e.top + a.padding,
                        line: 0
                    } : _ = {
                        x: e.left + a.padding,
                        y: e.top + W(o, c[0]),
                        line: 0
                    }, v.rtl.overrideTextDirection(e.ctx, t.textDirection);
                    var $ = w + a.padding;
                    v.each(e.legendItems, function(G, U) {
                        var J = f.measureText(G.text).width,
                            ie = M + w / 2 + J,
                            ae = _.x,
                            te = _.y;
                        h.setWidth(e.minSize.width), E ? U > 0 && ae + ie + a.padding > e.left + e.minSize.width && (te = _.y += $, _.line++, ae = _.x = e.left + W(l, u[_.line])) : U > 0 && te + $ > e.top + e.minSize.height && (ae = _.x = ae + e.columnWidths[_.line] + a.padding, _.line++, te = _.y = e.top + W(o, c[_.line]));
                        var se = h.x(ae);
                        T(se, te, G), C[U].left = h.leftForLtr(se, C[U].width), C[U].top = te, N(se, te, G, J), E ? _.x += ie + a.padding : _.y += $
                    }), v.rtl.restoreTextDirection(e.ctx, t.textDirection)
                }
            },
            _getLegendItemAt: function(e, t) {
                var a = this,
                    n, r, i;
                if (e >= a.left && e <= a.right && t >= a.top && t <= a.bottom) {
                    for (i = a.legendHitBoxes, n = 0; n < i.length; ++n)
                        if (r = i[n], e >= r.left && e <= r.left + r.width && t >= r.top && t <= r.top + r.height) return a.legendItems[n]
                }
                return null
            },
            handleEvent: function(e) {
                var t = this,
                    a = t.options,
                    n = e.type === "mouseup" ? "click" : e.type,
                    r;
                if (n === "mousemove") {
                    if (!a.onHover && !a.onLeave) return
                } else if (n === "click") {
                    if (!a.onClick) return
                } else return;
                r = t._getLegendItemAt(e.x, e.y), n === "click" ? r && a.onClick && a.onClick.call(t, e.native, r) : (a.onLeave && r !== t._hoveredItem && (t._hoveredItem && a.onLeave.call(t, e.native, t._hoveredItem), t._hoveredItem = r), a.onHover && r && a.onHover.call(t, e.native, r))
            }
        });

        function nr(e, t) {
            var a = new ar({
                ctx: e.ctx,
                options: t,
                chart: e
            });
            Se.configure(e, a, t), Se.addBox(e, a), e.legend = a
        }
        var Ts = {
                id: "legend",
                _element: ar,
                beforeInit: function(e) {
                    var t = e.options.legend;
                    t && nr(e, t)
                },
                beforeUpdate: function(e) {
                    var t = e.options.legend,
                        a = e.legend;
                    t ? (v.mergeIf(t, A.global.legend), a ? (Se.configure(e, a, t), a.options = t) : nr(e, t)) : a && (Se.removeBox(e, a), delete e.legend)
                },
                afterEvent: function(e, t) {
                    var a = e.legend;
                    a && a.handleEvent(t)
                }
            },
            Ge = v.noop;
        A._set("global", {
            title: {
                display: !1,
                fontStyle: "bold",
                fullWidth: !0,
                padding: 10,
                position: "top",
                text: "",
                weight: 2e3
            }
        });
        var rr = Le.extend({
            initialize: function(e) {
                var t = this;
                v.extend(t, e), t.legendHitBoxes = []
            },
            beforeUpdate: Ge,
            update: function(e, t, a) {
                var n = this;
                return n.beforeUpdate(), n.maxWidth = e, n.maxHeight = t, n.margins = a, n.beforeSetDimensions(), n.setDimensions(), n.afterSetDimensions(), n.beforeBuildLabels(), n.buildLabels(), n.afterBuildLabels(), n.beforeFit(), n.fit(), n.afterFit(), n.afterUpdate(), n.minSize
            },
            afterUpdate: Ge,
            beforeSetDimensions: Ge,
            setDimensions: function() {
                var e = this;
                e.isHorizontal() ? (e.width = e.maxWidth, e.left = 0, e.right = e.width) : (e.height = e.maxHeight, e.top = 0, e.bottom = e.height), e.paddingLeft = 0, e.paddingTop = 0, e.paddingRight = 0, e.paddingBottom = 0, e.minSize = {
                    width: 0,
                    height: 0
                }
            },
            afterSetDimensions: Ge,
            beforeBuildLabels: Ge,
            buildLabels: Ge,
            afterBuildLabels: Ge,
            beforeFit: Ge,
            fit: function() {
                var e = this,
                    t = e.options,
                    a = e.minSize = {},
                    n = e.isHorizontal(),
                    r, i;
                if (!t.display) {
                    e.width = a.width = e.height = a.height = 0;
                    return
                }
                r = v.isArray(t.text) ? t.text.length : 1, i = r * v.options._parseFont(t).lineHeight + t.padding * 2, e.width = a.width = n ? e.maxWidth : i, e.height = a.height = n ? i : e.maxHeight
            },
            afterFit: Ge,
            isHorizontal: function() {
                var e = this.options.position;
                return e === "top" || e === "bottom"
            },
            draw: function() {
                var e = this,
                    t = e.ctx,
                    a = e.options;
                if (!!a.display) {
                    var n = v.options._parseFont(a),
                        r = n.lineHeight,
                        i = r / 2 + a.padding,
                        o = 0,
                        c = e.top,
                        l = e.left,
                        u = e.bottom,
                        h = e.right,
                        f, p, x;
                    t.fillStyle = v.valueOrDefault(a.fontColor, A.global.defaultFontColor), t.font = n.string, e.isHorizontal() ? (p = l + (h - l) / 2, x = c + i, f = h - l) : (p = a.position === "left" ? l + i : h - i, x = c + (u - c) / 2, f = u - c, o = Math.PI * (a.position === "left" ? -.5 : .5)), t.save(), t.translate(p, x), t.rotate(o), t.textAlign = "center", t.textBaseline = "middle";
                    var w = a.text;
                    if (v.isArray(w))
                        for (var _ = 0, M = 0; M < w.length; ++M) t.fillText(w[M], 0, _, f), _ += r;
                    else t.fillText(w, 0, 0, f);
                    t.restore()
                }
            }
        });

        function ir(e, t) {
            var a = new rr({
                ctx: e.ctx,
                options: t,
                chart: e
            });
            Se.configure(e, a, t), Se.addBox(e, a), e.titleBlock = a
        }
        var Ns = {
                id: "title",
                _element: rr,
                beforeInit: function(e) {
                    var t = e.options.title;
                    t && ir(e, t)
                },
                beforeUpdate: function(e) {
                    var t = e.options.title,
                        a = e.titleBlock;
                    t ? (v.mergeIf(t, A.global.title), a ? (Se.configure(e, a, t), a.options = t) : ir(e, t)) : a && (Se.removeBox(e, a), delete e.titleBlock)
                }
            },
            Je = {},
            Ds = Cs,
            Os = Ts,
            As = Ns;
        Je.filler = Ds, Je.legend = Os, Je.title = As, j.helpers = v, Co(), j._adapters = Na, j.Animation = ha, j.animationService = fa, j.controllers = Mn, j.DatasetController = Ie, j.defaults = A, j.Element = Le, j.elements = pe, j.Interaction = dt, j.layouts = Se, j.platform = ht, j.plugins = K, j.Scale = me, j.scaleService = Dt, j.Ticks = Ot, j.Tooltip = Ca, j.helpers.each(gs, function(e, t) {
            j.scaleService.registerScaleType(t, e, e._defaults)
        });
        for (var or in Je) Je.hasOwnProperty(or) && j.plugins.register(Je[or]);
        j.platform.initialize();
        var Bs = j;
        return typeof window < "u" && (window.Chart = j), j.Chart = j, j.Legend = Je.legend._element, j.Title = Je.title._element, j.pluginService = j.plugins, j.PluginBase = j.Element.extend({}), j.canvasHelpers = j.helpers.canvas, j.layoutService = j.layouts, j.LinearScaleBase = Jt, j.helpers.each(["Bar", "Bubble", "Doughnut", "Line", "PolarArea", "Radar", "Scatter"], function(e) {
            j[e] = function(t, a) {
                return new j(t, j.helpers.merge(a || {}, {
                    type: e.charAt(0).toLowerCase() + e.slice(1)
                }))
            }
        }), Bs
    })
})(Ar);
var Cl = Ar.exports;
var Br = (g => (g.normal = "Classic", g.red = "Red", g.green = "Green", g.yellow = "Moon", g))(Br || {}),
    Rr = (g => (g.normal = "-", g.red = "50.51%", g.green = "49.50%", g.yellow = "9.90%", g))(Rr || {});
let Pl = "BC.GAME";

function Fr(g) {
    return Pl === "bc.game"
}
const Tl = Ft.withMultipleDetail(g => {
    const b = Y(),
        {
            gb: s,
            gv: d
        } = g,
        k = (s.extend.maxRate / 100).toFixed(2) + "x",
        y = d[0].bets[0].type;
    return S("div", {
        className: Nl,
        children: [S(Hs, {
            className: "rt_items",
            children: [S("div", {
                className: "item-wrap",
                children: [S("div", {
                    className: "item-num",
                    children: [m(Ae, {
                        className: "result",
                        name: "Result"
                    }), b("common.result")]
                }), m("div", {
                    className: "item-desc",
                    children: k
                })]
            }), S("div", {
                className: "item-wrap",
                children: [S("div", {
                    className: "item-num",
                    children: [m(Ae, {
                        className: "bettype",
                        name: "Bet"
                    }), b("common.bet")]
                }), m("div", {
                    className: "item-desc",
                    children: m("span", {
                        className: "mthan",
                        children: Br[y]
                    })
                })]
            }), S("div", {
                className: "item-wrap",
                children: [S("div", {
                    className: "item-num",
                    children: [m(Ae, {
                        className: "chance",
                        name: "Chance"
                    }), b("common.chance")]
                }), m("div", {
                    className: "item-desc",
                    children: Rr[y]
                })]
            })]
        }), m(ur, {
            label: b("common.game_number"),
            value: s.gameId,
            readOnly: !0
        }), m(ur, {
            label: b("common.hash"),
            value: s.extend.hash,
            readOnly: !0
        }), S("div", {
            className: "flex btns",
            children: [S(le, {
                className: "all",
                type: "gray",
                onClick: () => Ft.openAllPlayers({
                    gameName: s.gameName,
                    gameId: s.gameId
                }),
                children: [m("span", {
                    children: b("common.all_players")
                }), m(Ae, {
                    name: "Arrow"
                })]
            }), m(le, {
                type: "conic",
                onClick: () => {
                    window.open(`${eu.config.validateLink}?hash=${s.extend.hash}${Fr(s.gameId)?"&nosalt":""}`)
                },
                children: b("common.verify")
            })]
        })]
    })
});
var iu = Tl;
const Nl = "c1hfdahv";
var Dl = Q(function() {
    const b = H.exports.useMemo(() => [{
            label: 1,
            value: {
                icon: m(Ae, {
                    name: "Statistics"
                }),
                component: Ol
            }
        }, {
            label: 2,
            value: {
                icon: m(Ae, {
                    name: "Data"
                }),
                component: Al
            }
        }], []),
        [s, d] = H.exports.useState(b[0].value);
    return S("div", {
        className: zl,
        children: [m(Vs, {
            className: "history-tab",
            value: s,
            onChange: d,
            options: b,
            children: ({
                option: k,
                active: y
            }) => m("button", {
                className: y ? "is-active" : "",
                children: k.value.icon
            })
        }), m(s.component, {})]
    })
});

function Lr(g) {
    const b = ee(),
        s = 20,
        d = b.history.length,
        k = Math.min(d, g * s),
        y = k - s;
    return b.history.slice(d - k, d - y).reverse()
}
const Ol = Q(function() {
        const b = ee(),
            s = Y(),
            [d, k] = H.exports.useState(1),
            I = Lr(d).map(P => S("tr", {
                children: [m("td", {
                    children: S("div", {
                        className: "game-link",
                        onClick: () => Ft.openAllPlayers({
                            gameName: b.name,
                            gameId: P.gameId
                        }),
                        children: [m("div", {
                            className: `dot type-${P.odds>=10?3:P.odds>=2?2:1}`
                        }), P.gameId]
                    })
                }), S("td", {
                    children: [P.odds, "x"]
                }), m("td", {
                    children: S("div", {
                        className: "flex-center",
                        children: [m("input", {
                            type: "text",
                            value: P.hash,
                            readOnly: !0
                        }), m("a", {
                            target: "_blank",
                            href: `${b.config.validateLink}?hash=${P.hash}${Fr(P.gameId)?"&nosalt":""}`,
                            children: s("common.verify")
                        })]
                    })
                })]
            }, P.gameId));
        return S("div", {
            className: jl,
            children: [S(yt, {
                children: [m("thead", {
                    children: S("tr", {
                        children: [m("th", {
                            style: {
                                width: "24%"
                            },
                            children: s("common.game_number")
                        }), m("th", {
                            style: {
                                width: "20%"
                            },
                            children: s("common.result")
                        }), m("th", {
                            children: s("common.hash")
                        })]
                    })
                }), m("tbody", {
                    children: I
                })]
            }), m(kr, {
                page: d,
                onChange: k,
                total: b.history.length
            })]
        })
    }),
    Al = Q(function() {
        const b = H.exports.useRef(null),
            s = H.exports.useRef(null),
            d = ee(),
            [k, y] = _r({
                page: 1
            }),
            [I, P] = H.exports.useState(2),
            B = H.exports.useRef(I);
        B.current = I;
        const L = Lr(k.page);
        return H.exports.useEffect(() => {
            if (b.current) {
                const D = b.current.getContext("2d");
                s.current = Ll(D, () => B.current)
            }
        }, []), H.exports.useEffect(() => {
            const D = s.current;
            D && (D.data.labels = ["", `[1, ${I})`, `[${I}, \u221E)`, ""], D.data.datasets = [{
                data: L.map(z => ({
                    x: z.odds >= I ? `[${I}, \u221E)` : `[1, ${I})`,
                    y: z.gameId,
                    value: z.odds
                })),
                borderWidth: 2,
                borderColor: ke.isDarken ? "#5da000" : "#7bc514",
                pointBorderColor: ke.isDarken ? "#5da000" : "#7bc514",
                backgroundColor: "transparent",
                pointRadius: 2
            }], D.update())
        }, [L, I]), S("div", {
            className: Wl,
            children: [m(Bl, {
                onChange: P
            }), m(Rl, {
                rate: I
            }), m("div", {
                className: "chart-wrap",
                children: m("canvas", {
                    ref: b
                })
            }), m(kr, {
                page: k.page,
                onChange: D => y({
                    page: D
                }),
                total: d.history.length
            })]
        })
    }),
    Bl = ({
        onChange: g
    }) => {
        const b = Y(),
            [s, d] = H.exports.useState(2);
        return S("div", {
            className: "fix-layer",
            children: [m("div", {
                children: b("crash.analysis.form_rate_label", "2000")
            }), m(Gs, {
                value: s,
                onChange: d
            }), m(le, {
                onClick: () => g(s),
                type: "conic",
                children: b("common.analysis")
            })]
        })
    },
    Rl = Q(({
        rate: g
    }) => {
        const b = ee(),
            s = Y();
        let d = [{
                label: `[1, ${g})`,
                continuityCounts: 0,
                continuityMax: 0,
                counts: 0
            }, {
                label: `[${g}, \u221E)`,
                continuityCounts: 0,
                continuityMax: 0,
                counts: 0
            }],
            k = -1;
        b.history.forEach(I => {
            const P = I.odds < g ? 0 : 1;
            d.forEach((B, L) => {
                const D = P == L;
                El(B, D, D && L == k)
            }), k = P
        });
        const y = d.map(I => S("tr", {
            children: [m("td", {
                children: I.label
            }), S("td", {
                children: [(I.counts * 100 / b.history.length).toFixed(2), "%"]
            }), m("td", {
                children: I.counts
            }), m("td", {
                children: I.continuityMax
            })]
        }, I.label));
        return m(wt, {
            children: m("table", {
                children: S("tbody", {
                    children: [S("tr", {
                        children: [m("td", {
                            children: s("crash.analysis.rate")
                        }), m("td", {
                            children: s("common.chance")
                        }), m("td", {
                            children: s("crash.analysis.total")
                        }), m("td", {
                            children: s("crash.analysis.continuity")
                        })]
                    }), y]
                })
            })
        })
    });

function Fl(g, b, s, d, k, y) {
    return d < 2 * y && (y = d / 2), k < 2 * y && (y = k / 2), g.beginPath(), g.moveTo(b + y, s), g.arcTo(b + d, s, b + d, s + k, y), g.arcTo(b + d, s + k, b, s + k, y), g.arcTo(b, s + k, b, s, y), g.arcTo(b, s, b + d, s, y), g.closePath(), g
}

function Ll(g, b) {
    const s = g.createLinearGradient(140, 50, 140, 210);
    return s.addColorStop(0, "#40e248"), s.addColorStop(.5, "#c8963c"), s.addColorStop(1, "#ee2b44"), new Cl(g, {
        type: "line",
        data: {
            labels: [0],
            datasets: [{
                data: [0],
                borderColor: s,
                fill: !1,
                borderWidth: 3,
                backgroundColor: s,
                pointBorderColor: s,
                pointBackgroundColor: s,
                pointBorderWidth: 1,
                pointRadius: 1
            }]
        },
        options: {
            maintainAspectRatio: !1,
            legend: {
                display: !1
            },
            elements: {
                line: {
                    tension: 1e-6
                }
            },
            animation: {
                easing: "linear",
                onComplete: d => {
                    var k = d.chart,
                        y = k.ctx,
                        I = k.getDatasetMeta(0).data,
                        P = k.config.data.datasets[0].data;
                    y.font = "12px Arial", y.textAlign = "center", y.textBaseline = "bottom", P.forEach((B, L) => {
                        let D = I[L]._model.x,
                            z = I[L]._model.y;
                        y.fillStyle = B.value >= b() ? `${ke.isDarken?"#5da000":"#7bc514"}` : "#ed6300", Fl(y, D - 30, z - 10, 60, 20, 10), y.fill(), y.fillStyle = "#fff", y.fillText(`${B.value.toFixed(2)}x`, D, z + 7)
                    })
                }
            },
            layout: {
                padding: {
                    top: 20
                }
            },
            tooltips: {
                enabled: !1
            },
            scales: {
                xAxes: [{
                    gridLines: {
                        color: Z(ke.isDarken ? "#31343c" : "#cccfd9", .6)
                    },
                    ticks: {
                        fontColor: Z(ke.isDarken ? "#99a4b0" : "#5f6975", .8)
                    }
                }],
                yAxes: [{
                    gridLines: {
                        color: Z(ke.isDarken ? "#31343c" : "#cccfd9", .6)
                    },
                    ticks: {
                        fontColor: Z(ke.isDarken ? "#99a4b0" : "#5f6975", .8)
                    }
                }]
            }
        }
    })
}

function El(g, b, s) {
    b && g.counts++, s ? (g.continuityCounts++, g.continuityMax = Math.max(g.continuityCounts, g.continuityMax)) : g.continuityCounts = 0
}
kt({
    cl1: [Z("#31343c", .6), Z("#cccfd9", .4)],
    cl2: [Z("#2d3035", .6), Z("#dadde6", .6)],
    cl3: [Z("#2d3035", .4), Z("#dadde6", .3)]
});
const zl = "s1rdzo30";
kt({
    cl1: [Z("#31343c", .6), Z("#cccfd9", .6)],
    cl2: [Z("#31343c", .3), "#f6f7fa"]
});
const Wl = "ac72jev",
    jl = "hcals6g";
const Hl = [2, 1, 2, 0, 0, 0, 2, 0, 3, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    Vl = [2, 1, 2, 0, 0, 0, 3, 1, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0],
    Gl = [5.64, 2.63, 4.15, 1.82, 2.31, 18.78],
    $l = [2.25, 18.12, 4.21, 3.24, 2.14, 3.31, 5.55, 1.32, 1.96, 4.46];
var ql = Ue.memo(function() {
    const b = Y();
    return m(wt, {
        children: S("button", {
            className: Yl,
            onClick: () => $s.push(m(Ul, {})),
            children: [m(Ae, {
                className: "help-ico",
                name: "Help"
            }), m("div", {
                children: b("title.crash_help_trends")
            })]
        })
    })
});

function Ul() {
    const g = Y();
    return m(Et, {
        title: g("title.crash_help_trends"),
        children: S("div", {
            className: Xl,
            children: [S("div", {
                className: "tip",
                children: [S("div", {
                    className: "up",
                    children: [m(Rt, {
                        type: 2
                    }), "\u22652\xD7"]
                }), S("div", {
                    className: "up",
                    children: [m(Rt, {
                        type: 1
                    }), "<2\xD7"]
                }), S("div", {
                    className: "up",
                    children: [m(Rt, {
                        type: 3
                    }), "\u226510\xD7"]
                })]
            }), S("div", {
                className: "wrap",
                children: [m(fr, {
                    target: Hl,
                    source: Gl
                }), m(fr, {
                    target: Vl,
                    source: $l
                })]
            })]
        })
    })
}
const fr = ({
        target: g,
        source: b
    }) => {
        const s = Y();
        return S("div", {
            className: "demo",
            children: [m("div", {
                className: "chart",
                children: g.map((d, k) => m(Rt, {
                    type: d
                }, k))
            }), S("div", {
                className: "summary",
                children: [S("div", {
                    children: [s("crash.help_trends.tips1"), ":"]
                }), m("div", {
                    className: "res-list",
                    children: b.map((d, k) => S("div", {
                        className: "item",
                        children: [m("div", {
                            className: `r-item ${d<2?"red":d<10?"green":"moon"}`,
                            children: d
                        }), k < b.length - 1 && m(Ae, {
                            name: "Direction"
                        })]
                    }, k))
                })]
            })]
        })
    },
    Yl = "b153cftf",
    Xl = "slimr1l";
class Kl {
    constructor() {
        O(this, "row", 0);
        O(this, "col", 0)
    }
    computeSpaceMatrix(b) {
        let s = new Array(this.row * this.col).fill(null);
        for (let d = 0; d < b.length; d++) {
            let k = b[d];
            for (let y = 0; y < k.length; y++) {
                let I = k[y],
                    P = null,
                    B = null;
                if (y === 0) {
                    if (P = s[this.indexOfMatrix(d, y + 1)], P || d === this.col - 1) return this.computeSpaceMatrix(b.slice(1));
                    I.vector = [y, d], I.direction = 0
                } else {
                    let L = k[y - 1],
                        [D, z] = L.vector.slice();
                    if (L.direction == 0 && D + 1 < this.row) {
                        let X = s[this.indexOfMatrix(z, D + 1)];
                        if (D + 2 < this.row && (P = s[this.indexOfMatrix(z, D + 2)]), z > 0 && (B = s[this.indexOfMatrix(z - 1, D + 1)]), P && P.value == I.value) {
                            if (D === 0) return this.computeSpaceMatrix(b.slice(1));
                            z++, I.direction = 1
                        } else B && B.value == I.value || X ? (z++, I.direction = 1) : (D++, I.direction = 0)
                    } else z++, I.direction = 1;
                    if (z === this.col - 1) return d === 0 ? b[0].shift() : b = b.slice(1), this.computeSpaceMatrix(b);
                    I.vector = [D, z]
                }
                s[this.indexOfMatrix(I.vector[1], I.vector[0])] = I
            }
        }
        return s.map(d => d ? d.value : 0)
    }
    indexOfMatrix(b, s) {
        return b + s * this.col
    }
    getDragons(b) {
        let s = [];
        for (let d = 0; d < b.length; d++) {
            let k = {
                vector: [-1, -1],
                value: b[d],
                direction: 0
            };
            this.isEqual(b[d], b[d - 1]) ? s[s.length - 1].push(k) : s.push([k])
        }
        return s
    }
    isEqual(b, s) {
        if (b < 2 && s < 2 || b >= 2 && s >= 2) return !0
    }
    render(b, s = this.row, d = this.col) {
        return this.row = s, this.col = d, this.computeSpaceMatrix(this.getDragons(b))
    }
}
const vr = 6;
var Er = Q(function() {
    const [b, s] = _r({
        visible: !1,
        x: 0,
        y: 0
    }), d = Y();
    return H.exports.useEffect(() => {
        const k = Zl();
        s(k)
    }, []), S(wt, {
        children: [S("button", {
            onClick: () => s({
                visible: !b.visible
            }),
            className: `${Ql} flex-center ${b.visible?"is-active":""}`,
            children: [m(Ae, {
                name: "Trends"
            }), m("div", {
                children: d("common.trends")
            })]
        }), ke.isMobile ? b.visible && m(Mr, {
            id: "crash_trends",
            children: m(pr, {})
        }) : m(qs, {
            x: b.x,
            y: b.y,
            title: d("common.trends"),
            visible: b.visible,
            onClose: () => s({
                visible: !1
            }),
            children: m(pr, {})
        })]
    })
});
const pr = Q(function() {
        const s = ee(),
            [d] = H.exports.useState(() => new Kl),
            k = H.exports.useRef(null),
            y = s.history.slice(-vr * 32).map(({
                odds: P
            }) => P < 2 ? 1 : P < 10 ? 2 : 3),
            I = d.render(y, vr, 32);
        return H.exports.useEffect(() => {
            let P = k.current;
            if (P) {
                let {
                    scrollLeft: B,
                    scrollWidth: L
                } = P;
                (B === 0 || B > 350) && P.scrollTo(L, 0)
            }
        }), S("div", {
            className: ec,
            children: [m("div", {
                className: "dots-wrap",
                ref: k,
                children: m(Jl, {
                    dots: I
                })
            }), m(ql, {})]
        })
    }),
    Jl = ({
        dots: g
    }) => m("div", {
        className: "dots",
        children: g.map((b, s) => m(Rt, {
            type: b
        }, s))
    });

function Rt({
    type: g
}) {
    return m("div", {
        className: `${tc} dot type-${g}`
    })
}

function Zl() {
    const g = document.getElementsByClassName("game-main")[0];
    if (!g) return {
        x: 0,
        y: 0
    };
    const b = g.getBoundingClientRect();
    let s = b.x + b.width + 10;
    s + mr > window.innerWidth && (s = window.innerWidth - mr);
    let d = Math.max(b.y, 70);
    return {
        x: s,
        y: d
    }
}
kt({
    cl1: [Z("#99a4b0", .6), Z("#5f6975", .6)],
    cl2: ["#f5f6f7", "#31373d"]
});
const Ql = "tw2ycly",
    mr = 430,
    ec = "t173ghnx",
    tc = "ddq5w7y";
var gr = Q(({
    path: g
}) => {
    const b = Y(),
        s = Us(),
        [d] = H.exports.useState(() => [{
            label: b("crash.classic"),
            path: "classic",
            value: null
        }, {
            label: b("crash.trenball"),
            path: "trenball",
            value: null
        }]),
        k = d.findIndex(y => y.path === g);
    return S("div", {
        className: ac,
        children: [m(Ys, {
            value: k,
            tabs: d,
            onChange: y => s(y == 0 ? "/crash" : "/crash/trenball", {
                replace: !0
            })
        }), ke.isMobile && m(Er, {})]
    })
});
const ac = "wajpzxb";
var nc = Ue.memo(() => {
    const g = H.exports.useRef(null),
        b = ee(),
        [s, d] = H.exports.useState(!1);
    return H.exports.useEffect(() => Ya(() => b.rate > 100 && b.status === Oe.PROGRESS, k => d(k)), []), H.exports.useEffect(() => {
        if (s) {
            const k = {
                    fram: 0
                },
                y = Ir.to(k, 1, {
                    fram: 5,
                    repeat: -1,
                    yoyo: !0,
                    ease: Xs.easeNone,
                    onUpdate: () => {
                        g.current && (g.current.style.backgroundPositionY = Math.round(-k.fram) * 186 + "px")
                    }
                });
            return () => {
                y.kill()
            }
        }
    }, [s]), s ? m("div", {
        className: rc,
        ref: g
    }) : null
});
const rc = "c1dgr0o5";
var ic = "/assets/cat.a68d2d6b.png",
    oc = "/assets/knife.1e91682e.png",
    sc = "/assets/win.b353e909.png",
    lc = "/assets/trenball_red.0078e052.png",
    cc = "/assets/trenball_green.60f2a952.png",
    uc = "/assets/trenball_red_lose.968eee93.png",
    dc = "/assets/trenball_green_lose.ac2159d5.png",
    gt = {
        cat: ic,
        knife: oc,
        win: sc,
        trenball_red: lc,
        trenball_green: cc,
        trenball_red_lose: uc,
        trenball_green_lose: dc
    };
var hc = Ue.memo(function() {
    const b = ee(),
        s = sa(() => {
            b.graph.resize()
        }, 300),
        d = Y(),
        [k, y] = Ks(({
            profitAmount: I,
            currencyName: P
        }) => S(Js.div, {
            className: vc,
            children: [S("div", {
                className: "msg",
                children: [m("span", {
                    children: d("crash.common.won")
                }), m("span", {
                    className: "amount",
                    children: de.toLocaleCurrency(I, P)
                })]
            }), m("img", {
                src: gt.win
            })]
        }));
    return H.exports.useEffect(() => {
        const I = ({
            amount: P,
            odds: B,
            currencyName: L
        }) => {
            B > 1 && (y({
                profitAmount: new $e(P).mul(B).toNumber(),
                currencyName: L,
                odds: B
            }), setTimeout(() => y(null), 3e3))
        };
        return b.on("escapeSuccess", I), () => {
            b.off("escapeSuccess", I)
        }
    }, []), S("div", {
        className: fc,
        ref: s,
        children: [m(nc, {}), k, m("canvas", {
            className: k.props.children ? "is-win" : "",
            ref: b.graph.mountEffect
        })]
    })
});
const fc = "c1i4f2wq",
    vc = "wqqczo";
const pc = Ue.memo(({
    data: g,
    onClick: b,
    style: s
}) => S("div", {
    className: `game-item ${g.odds>=10?"is-moon":g.odds>=2?"is-doubble":""}`,
    style: s,
    onClick: () => b(g),
    children: [m("div", {
        className: "issus",
        children: g.gameId
    }), S("div", {
        children: [(Math.round(g.odds * 100) / 100).toFixed(2), "x"]
    })]
}));
var br = Q(() => {
    const g = ee(),
        b = g.history.slice(-10).reverse(),
        s = H.exports.useCallback(({
            gameId: d
        }) => {
            Ft.openAllPlayers({
                gameName: g.name,
                gameId: d
            })
        }, [g]);
    return S(wt, {
        children: [m(Zs, {
            list: b,
            className: mc,
            keyof: "gameId",
            onDetail: s,
            item: pc,
            children: !ke.isMobile && m(Er, {})
        }), m(Mr, {
            id: "crash_trends"
        }), S(Qs, {
            className: gc,
            children: [m(el, {
                className: "house-edge"
            }), m(hc, {})]
        })]
    })
});
kt({
    cl1: [Z("#31343c", .4), "#f5f6fa"],
    cl2: [Z("#99a4b0", .5), "#99a4b0"]
});
const mc = "c7ibl2z",
    gc = "gew0h4x";
var bc = Q(function() {
    const b = ee();
    return S("div", {
        className: _c,
        children: [m(xc, {}), S("div", {
            className: "forms",
            children: [m(qe.CoinInput, {}), m(qe.PayoutInput, {
                label: m(yc, {
                    chance: 99 / b.maxRate
                }),
                size: "small",
                value: b.maxRate,
                min: 1.01,
                max: 1e6,
                onChange: s => b.maxRate = s,
                precision: 2
            })]
        })]
    })
});
const yc = Ue.memo(({
        chance: g
    }) => {
        const b = Y();
        return S("div", {
            className: "chance-title",
            children: [m("div", {
                className: "auto-title",
                children: b("title.crash_help_autoRun")
            }), S("div", {
                children: [b("common.chance"), "\xA0\xA0", S("span", {
                    className: "chance-num",
                    children: [g.toFixed(2), "%"]
                })]
            })]
        })
    }),
    xc = Q(() => {
        const g = ee();
        return g.status == Oe.STARTING ? m(kc, {}) : g.status == Oe.PROGRESS ? g.betInfo && g.betInfo.rate == 0 ? m(zr, {
            betInfo: g.betInfo
        }) : m(yr, {}) : m(yr, {})
    }),
    wc = Q(() => {
        const g = Y(),
            b = ee();
        return b.canEscape ? m(zr, {
            betInfo: b.betInfo
        }) : m(le, {
            className: xt,
            type: "conic",
            size: "big",
            disabled: !0,
            children: m("div", {
                children: g("crash.common.escape")
            })
        })
    }),
    kc = Q(() => {
        const g = Y(),
            b = ee();
        return b.betInfo ? m(le, {
            className: xt,
            type: "conic4",
            size: "big",
            disabled: b.script.isRunning,
            children: m("div", {
                children: g("common.loading")
            })
        }) : m(le, {
            className: xt,
            type: "conic",
            size: "big",
            disabled: b.script.isRunning,
            onClick: () => b.handleBetCrash().catch(bt),
            children: m("div", {
                children: g("common.bet")
            })
        })
    }),
    zr = Q(({
        betInfo: g
    }) => {
        const b = Y(),
            s = ee(),
            [d, k] = H.exports.useState(s.graph.currentGamePayout);
        H.exports.useEffect(() => (s.graph.on("payoutChange", k), () => {
            s.graph.off("payoutChange", k)
        }), []);
        const y = H.exports.useCallback(async () => {
            const I = s.gameId;
            try {
                await s.handleEscape()
            } catch (P) {
                bt(new Error(`Escape(${I}): ${P.message}`))
            }
        }, []);
        return S(le, {
            className: xt,
            type: "conic",
            size: "big",
            onClick: y,
            children: [m("div", {
                className: "monospace",
                children: de.toLocaleCurrency(g.bet.mul(d), g.currencyName)
            }), m("div", {
                className: "sub-text",
                children: b("crash.common.escape")
            })]
        })
    }),
    yr = Q(() => {
        const g = Y(),
            b = ee();
        return b.nextBetInfo ? S(le, {
            type: "conic4",
            className: xt,
            size: "big",
            disabled: b.script.isRunning,
            onClick: () => b.handleNext(!0),
            children: [m("div", {
                children: g("common.loading")
            }), m("div", {
                className: "sub-text",
                children: g("crash.common.can_next")
            })]
        }) : S(le, {
            type: "conic",
            size: "big",
            className: xt,
            disabled: b.script.isRunning,
            onClick: () => b.handleNext(),
            children: [m("div", {
                children: g("common.bet")
            }), m("div", {
                className: "sub-text",
                children: g("crash.common.bet_next")
            })]
        })
    }),
    _c = "wnclv85",
    xt = "b1g07ba4";
var Mc = Ue.memo(function() {
    return m(tl, {
        children: m("div", {
            children: m(wc, {})
        })
    })
});
var Wr = Ue.memo(function({
    scroll: b = !1
}) {
    const s = ee(),
        d = al(),
        k = Sr(),
        y = Y(),
        [I, P] = H.exports.useState(10),
        B = sa(({
            height: ce
        }) => {
            let Be = ce / Dr(48);
            P(Be - Math.trunc(Be) > .3 ? Math.ceil(Be) : Math.floor(Be))
        }),
        [L] = H.exports.useState(() => Za(() => k() && d(), 200));
    H.exports.useEffect(() => (s.on("player_change", L), () => {
        s.off("player_change", L)
    }), []);
    let D = s.players.slice(0, s.showPlayersLimit ? b ? I : 10 : 1 / 0);
    const z = s.playersDict[Ce.userId];
    z && s.showPlayersLimit && D.indexOf(z) == -1 && (D.pop(), D.push(z)), D = Xa(D, [ce => ce.rate == 0 ? -1 / 0 : -ce.rate, ce => -ce.usd]);
    const X = s.players.filter(ce => ce.rate > 0).length,
        xe = H.exports.useCallback(() => {
            s.showPlayersLimit = !s.showPlayersLimit, d()
        }, []),
        Pe = b && !s.showPlayersLimit ? "has-scroll" : "",
        oe = D.length == 0 ? m(Cr, {}) : m(yt, {
            children: m("tbody", {
                children: D.map(ce => m(Sc, {
                    player: ce
                }, ce.userId))
            })
        });
    return m(Pr, {
        children: S("div", {
            className: zt(Cc, b && "need-scroll"),
            children: [m(Ic, {}), Pe ? m(Tr, {
                bodyLock: !1,
                ref: B,
                className: "scroll-wrap has-scroll",
                children: oe
            }) : m("div", {
                ref: B,
                className: "scroll-wrap",
                children: oe
            }), S("div", {
                className: "foot",
                children: [S("div", {
                    className: "state",
                    children: [X, "/", s.players.length, " ", y("common.player")]
                }), S("button", {
                    onClick: xe,
                    className: `list-toggle ${s.showPlayersLimit?"show-more":"show-less"}`,
                    children: [m("div", {
                        children: s.showPlayersLimit ? y("common.show_more") : y("common.show_less")
                    }), m(Ae, {
                        name: "Arrow"
                    })]
                })]
            })]
        })
    })
});
const Ic = Ue.memo(() => {
        const g = Y();
        return m("table", {
            className: "head",
            children: m("tbody", {
                children: S("tr", {
                    children: [m("td", {
                        className: "user",
                        children: g("common.player")
                    }), m("td", {
                        className: "escape",
                        children: g("crash.common.escape")
                    }), m("td", {
                        className: "amount",
                        children: g("common.amount")
                    }), m("td", {
                        children: g("common.profit")
                    })]
                })
            })
        })
    }),
    Sc = Q(({
        player: g
    }) => {
        const b = ee(),
            s = Y();
        let d, k;
        return g.rate > 0 ? (d = m(na, {
            icon: !0,
            className: "is-win",
            name: g.currencyName,
            amount: g.bet.mul(g.rate / 100 - 1)
        }), k = (g.rate / 100).toFixed(2) + "x") : b.status == Oe.ENDED ? (d = m(na, {
            className: "is-lose",
            icon: !0,
            name: g.currencyName,
            amount: g.bet.neg()
        }), k = "bang") : (d = m("span", {
            className: "ttl opacity",
            children: s("common.betting")
        }), k = m("span", {
            className: "ttl opacity",
            children: s("common.betting")
        })), S("tr", {
            children: [m("td", {
                className: "user",
                children: m(Nr, {
                    name: g.name,
                    userId: g.userId
                })
            }), m("td", {
                className: "escape",
                children: k
            }), m("td", {
                className: "bet",
                children: m(na, {
                    icon: !0,
                    name: g.currencyName,
                    amount: g.bet
                })
            }), m("td", {
                className: "profit",
                children: d
            })]
        })
    });
kt({
    cl1: [Z("#99a4b0", .6), Z("#5f6975", .8)],
    cl2: ["#f5f6f7", "#31373d"],
    cl3: ["#23272c", "#f6f7fa"]
});
const Cc = "w1pfg8m3",
    q = Lt.Reader,
    fe = Lt.Writer,
    R = Lt.util,
    F = Lt.roots.gameCrash || (Lt.roots.gameCrash = {});
F.CrashInfo = (() => {
    function g(b) {
        if (this.players = [], this.xBets = [], b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.status = 0, g.prototype.prepareTime = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.startTime = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.hash = "", g.prototype.maxRate = 0, g.prototype.players = R.emptyArray, g.prototype.xBets = R.emptyArray, g.encode = function(s, d) {
        if (d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.status != null && Object.hasOwnProperty.call(s, "status") && d.uint32(16).int32(s.status), s.prepareTime != null && Object.hasOwnProperty.call(s, "prepareTime") && d.uint32(24).int64(s.prepareTime), s.startTime != null && Object.hasOwnProperty.call(s, "startTime") && d.uint32(32).int64(s.startTime), s.hash != null && Object.hasOwnProperty.call(s, "hash") && d.uint32(50).string(s.hash), s.maxRate != null && Object.hasOwnProperty.call(s, "maxRate") && d.uint32(56).int32(s.maxRate), s.players != null && s.players.length)
            for (let k = 0; k < s.players.length; ++k) F.CrashInfo.PlayerInfo.encode(s.players[k], d.uint32(66).fork()).ldelim();
        if (s.xBets != null && s.xBets.length)
            for (let k = 0; k < s.xBets.length; ++k) F.XBet.encode(s.xBets[k], d.uint32(122).fork()).ldelim();
        return d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.CrashInfo;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 2:
                    y.status = s.int32();
                    break;
                case 3:
                    y.prepareTime = s.int64();
                    break;
                case 4:
                    y.startTime = s.int64();
                    break;
                case 6:
                    y.hash = s.string();
                    break;
                case 7:
                    y.maxRate = s.int32();
                    break;
                case 8:
                    y.players && y.players.length || (y.players = []), y.players.push(F.CrashInfo.PlayerInfo.decode(s, s.uint32()));
                    break;
                case 15:
                    y.xBets && y.xBets.length || (y.xBets = []), y.xBets.push(F.XBet.decode(s, s.uint32()));
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g.PlayerInfo = function() {
        function b(s) {
            if (s)
                for (let d = Object.keys(s), k = 0; k < d.length; ++k) s[d[k]] != null && (this[d[k]] = s[d[k]])
        }
        return b.prototype.userId = 0, b.prototype.name = "", b.prototype.currencyName = "", b.prototype.bet = R.Long ? R.Long.fromBits(0, 0, !1) : 0, b.prototype.rate = 0, b.encode = function(d, k) {
            return k || (k = fe.create()), d.userId != null && Object.hasOwnProperty.call(d, "userId") && k.uint32(8).int32(d.userId), d.name != null && Object.hasOwnProperty.call(d, "name") && k.uint32(18).string(d.name), d.currencyName != null && Object.hasOwnProperty.call(d, "currencyName") && k.uint32(26).string(d.currencyName), d.bet != null && Object.hasOwnProperty.call(d, "bet") && k.uint32(32).int64(d.bet), d.rate != null && Object.hasOwnProperty.call(d, "rate") && k.uint32(40).int32(d.rate), k
        }, b.decode = function(d, k) {
            d instanceof q || (d = q.create(d));
            let y = k === void 0 ? d.len : d.pos + k,
                I = new F.CrashInfo.PlayerInfo;
            for (; d.pos < y;) {
                let P = d.uint32();
                switch (P >>> 3) {
                    case 1:
                        I.userId = d.int32();
                        break;
                    case 2:
                        I.name = d.string();
                        break;
                    case 3:
                        I.currencyName = d.string();
                        break;
                    case 4:
                        I.bet = d.int64();
                        break;
                    case 5:
                        I.rate = d.int32();
                        break;
                    default:
                        d.skipType(P & 7);
                        break
                }
            }
            return I
        }, b
    }(), g
})();
F.Prepare = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.prepareTime = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.startTime = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.prepareTime != null && Object.hasOwnProperty.call(s, "prepareTime") && d.uint32(24).int64(s.prepareTime), s.startTime != null && Object.hasOwnProperty.call(s, "startTime") && d.uint32(32).int64(s.startTime), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Prepare;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 3:
                    y.prepareTime = s.int64();
                    break;
                case 4:
                    y.startTime = s.int64();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.ThrowBetRequest = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.currencyName = "", g.prototype.bet = "", g.prototype.autoEscapeRate = 0, g.prototype.scriptId = 0, g.prototype.frontgroundId = 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.currencyName != null && Object.hasOwnProperty.call(s, "currencyName") && d.uint32(18).string(s.currencyName), s.bet != null && Object.hasOwnProperty.call(s, "bet") && d.uint32(26).string(s.bet), s.autoEscapeRate != null && Object.hasOwnProperty.call(s, "autoEscapeRate") && d.uint32(32).int32(s.autoEscapeRate), s.scriptId != null && Object.hasOwnProperty.call(s, "scriptId") && d.uint32(40).int32(s.scriptId), s.frontgroundId != null && Object.hasOwnProperty.call(s, "frontgroundId") && d.uint32(120).sint32(s.frontgroundId), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.ThrowBetRequest;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 2:
                    y.currencyName = s.string();
                    break;
                case 3:
                    y.bet = s.string();
                    break;
                case 4:
                    y.autoEscapeRate = s.int32();
                    break;
                case 5:
                    y.scriptId = s.int32();
                    break;
                case 15:
                    y.frontgroundId = s.sint32();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.Bet = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.currencyName = "", g.prototype.bet = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.userId = 0, g.prototype.name = "", g.prototype.betId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.currencyName != null && Object.hasOwnProperty.call(s, "currencyName") && d.uint32(18).string(s.currencyName), s.bet != null && Object.hasOwnProperty.call(s, "bet") && d.uint32(24).int64(s.bet), s.userId != null && Object.hasOwnProperty.call(s, "userId") && d.uint32(32).int32(s.userId), s.name != null && Object.hasOwnProperty.call(s, "name") && d.uint32(42).string(s.name), s.betId != null && Object.hasOwnProperty.call(s, "betId") && d.uint32(48).int64(s.betId), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Bet;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 2:
                    y.currencyName = s.string();
                    break;
                case 3:
                    y.bet = s.int64();
                    break;
                case 4:
                    y.userId = s.int32();
                    break;
                case 5:
                    y.name = s.string();
                    break;
                case 6:
                    y.betId = s.int64();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.Begin = (() => {
    function g(b) {
        if (this.betUserIds = [], b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.startTime = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.betUserIds = R.emptyArray, g.encode = function(s, d) {
        if (d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.startTime != null && Object.hasOwnProperty.call(s, "startTime") && d.uint32(32).int64(s.startTime), s.betUserIds != null && s.betUserIds.length) {
            d.uint32(42).fork();
            for (let k = 0; k < s.betUserIds.length; ++k) d.int32(s.betUserIds[k]);
            d.ldelim()
        }
        return d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Begin;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 4:
                    y.startTime = s.int64();
                    break;
                case 5:
                    if (y.betUserIds && y.betUserIds.length || (y.betUserIds = []), (I & 7) === 2) {
                        let P = s.uint32() + s.pos;
                        for (; s.pos < P;) y.betUserIds.push(s.int32())
                    } else y.betUserIds.push(s.int32());
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.Progress = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.elapsed = 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.elapsed != null && Object.hasOwnProperty.call(s, "elapsed") && d.uint32(8).int32(s.elapsed), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Progress;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.elapsed = s.int32();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.EscapeRequest = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.EscapeRequest;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.Escape = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.userId = 0, g.prototype.betId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.rate = 0, g.prototype.force = !1, g.encode = function(s, d) {
        return d || (d = fe.create()), s.userId != null && Object.hasOwnProperty.call(s, "userId") && d.uint32(8).int32(s.userId), s.betId != null && Object.hasOwnProperty.call(s, "betId") && d.uint32(16).int64(s.betId), s.rate != null && Object.hasOwnProperty.call(s, "rate") && d.uint32(24).int32(s.rate), s.force != null && Object.hasOwnProperty.call(s, "force") && d.uint32(32).bool(s.force), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Escape;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.userId = s.int32();
                    break;
                case 2:
                    y.betId = s.int64();
                    break;
                case 3:
                    y.rate = s.int32();
                    break;
                case 4:
                    y.force = s.bool();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.End = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.maxRate = 0, g.prototype.hash = "", g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.maxRate != null && Object.hasOwnProperty.call(s, "maxRate") && d.uint32(48).int32(s.maxRate), s.hash != null && Object.hasOwnProperty.call(s, "hash") && d.uint32(58).string(s.hash), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.End;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 6:
                    y.maxRate = s.int32();
                    break;
                case 7:
                    y.hash = s.string();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.Settle = (() => {
    function g(b) {
        if (this.escapes = [], b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.escapes = R.emptyArray, g.prototype.maxRate = 0, g.prototype.hash = "", g.encode = function(s, d) {
        if (d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.escapes != null && s.escapes.length)
            for (let k = 0; k < s.escapes.length; ++k) F.Escape.encode(s.escapes[k], d.uint32(18).fork()).ldelim();
        return s.maxRate != null && Object.hasOwnProperty.call(s, "maxRate") && d.uint32(48).int32(s.maxRate), s.hash != null && Object.hasOwnProperty.call(s, "hash") && d.uint32(58).string(s.hash), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Settle;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 2:
                    y.escapes && y.escapes.length || (y.escapes = []), y.escapes.push(F.Escape.decode(s, s.uint32()));
                    break;
                case 6:
                    y.maxRate = s.int32();
                    break;
                case 7:
                    y.hash = s.string();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.Jackpot = (() => {
    function g(b) {
        if (this.jackpot = {}, b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.jackpot = R.emptyObject, g.encode = function(s, d) {
        if (d || (d = fe.create()), s.jackpot != null && Object.hasOwnProperty.call(s, "jackpot"))
            for (let k = Object.keys(s.jackpot), y = 0; y < k.length; ++y) d.uint32(10).fork().uint32(10).string(k[y]).uint32(16).int64(s.jackpot[k[y]]).ldelim();
        return d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.Jackpot,
            I, P;
        for (; s.pos < k;) {
            let B = s.uint32();
            switch (B >>> 3) {
                case 1:
                    y.jackpot === R.emptyObject && (y.jackpot = {});
                    let L = s.uint32() + s.pos;
                    for (I = "", P = 0; s.pos < L;) {
                        let D = s.uint32();
                        switch (D >>> 3) {
                            case 1:
                                I = s.string();
                                break;
                            case 2:
                                P = s.int64();
                                break;
                            default:
                                s.skipType(D & 7);
                                break
                        }
                    }
                    y.jackpot[I] = P;
                    break;
                default:
                    s.skipType(B & 7);
                    break
            }
        }
        return y
    }, g
})();
F.JackpotChangeInfo = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.type = 0, g.prototype.currencyName = "", g.prototype.amount = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.type != null && Object.hasOwnProperty.call(s, "type") && d.uint32(8).int32(s.type), s.currencyName != null && Object.hasOwnProperty.call(s, "currencyName") && d.uint32(18).string(s.currencyName), s.amount != null && Object.hasOwnProperty.call(s, "amount") && d.uint32(24).int64(s.amount), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.JackpotChangeInfo;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.type = s.int32();
                    break;
                case 2:
                    y.currencyName = s.string();
                    break;
                case 3:
                    y.amount = s.int64();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.ThrowXBetRequest = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.currencyName = "", g.prototype.bet = "", g.prototype.x = 0, g.prototype.scriptId = 0, g.prototype.frontgroundId = 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.currencyName != null && Object.hasOwnProperty.call(s, "currencyName") && d.uint32(18).string(s.currencyName), s.bet != null && Object.hasOwnProperty.call(s, "bet") && d.uint32(26).string(s.bet), s.x != null && Object.hasOwnProperty.call(s, "x") && d.uint32(32).int32(s.x), s.scriptId != null && Object.hasOwnProperty.call(s, "scriptId") && d.uint32(40).int32(s.scriptId), s.frontgroundId != null && Object.hasOwnProperty.call(s, "frontgroundId") && d.uint32(120).sint32(s.frontgroundId), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.ThrowXBetRequest;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 2:
                    y.currencyName = s.string();
                    break;
                case 3:
                    y.bet = s.string();
                    break;
                case 4:
                    y.x = s.int32();
                    break;
                case 5:
                    y.scriptId = s.int32();
                    break;
                case 15:
                    y.frontgroundId = s.sint32();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
F.XBet = (() => {
    function g(b) {
        if (b)
            for (let s = Object.keys(b), d = 0; d < s.length; ++d) b[s[d]] != null && (this[s[d]] = b[s[d]])
    }
    return g.prototype.gameId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.currencyName = "", g.prototype.bet = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.userId = 0, g.prototype.name = "", g.prototype.betId = R.Long ? R.Long.fromBits(0, 0, !1) : 0, g.prototype.x = 0, g.encode = function(s, d) {
        return d || (d = fe.create()), s.gameId != null && Object.hasOwnProperty.call(s, "gameId") && d.uint32(8).int64(s.gameId), s.currencyName != null && Object.hasOwnProperty.call(s, "currencyName") && d.uint32(18).string(s.currencyName), s.bet != null && Object.hasOwnProperty.call(s, "bet") && d.uint32(24).int64(s.bet), s.userId != null && Object.hasOwnProperty.call(s, "userId") && d.uint32(32).int32(s.userId), s.name != null && Object.hasOwnProperty.call(s, "name") && d.uint32(42).string(s.name), s.betId != null && Object.hasOwnProperty.call(s, "betId") && d.uint32(48).int64(s.betId), s.x != null && Object.hasOwnProperty.call(s, "x") && d.uint32(56).int32(s.x), d
    }, g.decode = function(s, d) {
        s instanceof q || (s = q.create(s));
        let k = d === void 0 ? s.len : s.pos + d,
            y = new F.XBet;
        for (; s.pos < k;) {
            let I = s.uint32();
            switch (I >>> 3) {
                case 1:
                    y.gameId = s.int64();
                    break;
                case 2:
                    y.currencyName = s.string();
                    break;
                case 3:
                    y.bet = s.int64();
                    break;
                case 4:
                    y.userId = s.int32();
                    break;
                case 5:
                    y.name = s.string();
                    break;
                case 6:
                    y.betId = s.int64();
                    break;
                case 7:
                    y.x = s.int32();
                    break;
                default:
                    s.skipType(I & 7);
                    break
            }
        }
        return y
    }, g
})();
const Pc = ye.encode(F.ThrowXBetRequest);
var he = (g => (g[g.RED = -200] = "RED", g[g.GREEN = 200] = "GREEN", g[g.MOON = 1e3] = "MOON", g))(he || {}),
    jr = (g => (g[g.PENDING = 0] = "PENDING", g[g.WIN = 1] = "WIN", g[g.LOSE = 2] = "LOSE", g))(jr || {});

function Tc(g, b = 0) {
    let s = [];
    const d = Za(() => g(s.splice(0, s.length)), b);
    return y => {
        s.push(...y), d()
    }
}
class Nc extends nl {
    constructor(s) {
        super({
            name: "crash_xbet",
            namespace: "/g/c"
        }, () => null);
        O(this, "throwLimit", {});
        O(this, "game");
        O(this, "myBets", [null, null, null]);
        O(this, "autoBetType", null);
        O(this, "nextBets", [null, null, null]);
        O(this, "redList", []);
        O(this, "greenList", []);
        O(this, "result", 0);
        O(this, "prevRate", 1);
        O(this, "autoBet");
        O(this, "betDict", {});
        O(this, "typeInfo", {
            [-200]: {
                payout: 1.96,
                index: 0,
                label: "Red"
            },
            [200]: {
                payout: 2,
                index: 1,
                label: "Green"
            },
            [1e3]: {
                payout: 10,
                index: 2,
                label: "Moon"
            }
        });
        O(this, "disableAutoConnect", !0);
        Qa(this, {
            myBets: ne,
            autoBetType: ne,
            nextBets: ne,
            redList: ne,
            greenList: ne,
            result: ne,
            init2: De,
            onPrepare: De,
            onEnd: De,
            onEnd2: De,
            onEnd10: De,
            addBets: De
        }), this.game = s, this.onPrepare = this.onPrepare.bind(this), this.onProgress = this.onProgress.bind(this), this.onEnd = this.onEnd.bind(this), this.game.socket.on("xb", ye.decodeBind(d => this.addBets([this.formatBet(d)]), F.XBet)), this.game.on("game_prepare", this.onPrepare), this.game.on("game_end", this.onEnd), this.game.on("game_progress", this.onProgress), this.settings.hotkeyEnable = !1, this.autoBet = new rl(this, void 0, this.game.waitGameStart), this.autoBet.on("start", () => this.setBetStatus(!0)), this.autoBet.on("stop", () => this.setBetStatus(!1)), Ya(() => this.autoBetType, d => {
            d ? this.autoBet.start() : (this.autoBet.stop(), this.setBetStatus(!1))
        }), Ya(() => this.autoBet.isRunning, d => {
            d || (this.autoBetType = null)
        }), this.addBets = Tc(this.addBets.bind(this), 200)
    }
    setBetStatus(s) {
        this.autoBet.isRunning || (this.isBetting = s)
    }
    init2(s) {
        this.betDict = {}, this.redList = [], this.greenList = [];
        const d = s.map(this.formatBet);
        d.filter(k => k.userId == Ce.userId).forEach(({
            bet: k,
            currencyName: y,
            type: I,
            gameId: P
        }) => {
            this.addMyBet({
                gameId: P,
                bet: k,
                currencyName: y,
                type: I,
                status: 0
            })
        }), this.game.rate >= 2 && this.onEnd2(), this.game.rate >= 10 && this.onEnd10(), this.addBets(d)
    }
    onPrepare() {
        this.myBets.fill(null), this.result = 0, this.betDict = {}, this.redList = [], this.greenList = [], this.nextBets.forEach(s => {
            s && (s.gameId = this.game.gameId, this.handleBet(s))
        }), this.nextBets.fill(null)
    }
    onProgress() {
        const s = this.game.rate;
        this.prevRate < 2 ? s >= 2 && this.onEnd2() : this.prevRate < 10 && s >= 10 && this.onEnd10(), this.prevRate = s
    }
    onEnd() {
        this.onEnd2(), this.onEnd10()
    }
    onEnd2() {
        const s = this.game.rate,
            d = this.getMyBetByType(-200),
            k = this.getMyBetByType(200),
            y = s < 2 ? 1 : 2,
            I = s >= 2 ? 1 : 2;
        s < 2 ? this.result = -200 : this.result = 200, d && d.status == 0 && (d.status = y, d.status == 1 && this.emit("win", d)), k && k.status == 0 && (k.status = I, k.status == 1 && this.emit("win", k)), this.redList.forEach(P => P.status = y), this.greenList.filter(P => P.type == 200).forEach(P => P.status = I)
    }
    onEnd10() {
        const s = this.game.rate,
            d = this.getMyBetByType(1e3),
            k = s >= 10 ? 1 : 2;
        d && d.status == 0 && (d.status = k, d.status == 1 && this.emit("win", d)), this.greenList.filter(y => y.type == 1e3).forEach(y => y.status = k)
    }
    addBets(s) {
        let d = !1,
            k = !1;
        s.forEach(y => {
            this.betDict[y.betId] || (this.betDict[y.betId] = y, y.type == -200 ? (this.redList.push(y), d = !0) : (this.greenList.push(y), k = !0))
        }), d && (this.redList = Xa(this.redList, ["type", "usd"], ["desc", "desc"])), k && (this.greenList = Xa(this.greenList, ["type", "usd"], ["desc", "desc"]))
    }
    async handleBet(s, d = 0) {
        if (!s) {
            if (!this.autoBetType) throw new Error("");
            s = {
                gameId: this.game.gameId,
                type: this.autoBetType,
                bet: this.amount,
                currencyName: this.currencyName,
                status: 0
            }
        }
        await this.beforeBetCheck(s.bet, s.currencyName), this.setBetStatus(!0);
        const k = de.createDeduction(s.bet, s.currencyName);
        try {
            await this.game.socketRequest("throw-xbet", Pc({
                gameId: Ka.fromNumber(s.gameId),
                bet: s.bet.toFixed(de.getPrecision(s.currencyName)),
                currencyName: s.currencyName,
                x: s.type,
                scriptId: d,
                frontgroundId: k
            }));
            let y = this.addMyBet(s);
            await this.game.waitGameEnd();
            const I = y.status == 1 ? this.typeInfo[y.type].payout : 0;
            return de.resolveDeduction(k), I
        } catch (y) {
            throw de.resolveDeduction(k, !1), y
        } finally {
            this.setBetStatus(!1), this.syncCurrency()
        }
    }
    handleBetByType(s) {
        return this.handleBet({
            type: s,
            currencyName: this.currencyName,
            bet: this.amount,
            status: 0,
            gameId: this.game.gameId
        })
    }
    async handleBetNext(s) {
        await this.beforeBetCheck(this.amount), this.nextBets[this.typeInfo[s].index] = {
            type: s,
            currencyName: this.currencyName,
            bet: this.amount,
            status: 0,
            gameId: this.game.gameId
        }
    }
    handleCancelNext(s) {
        this.nextBets[this.typeInfo[s.type].index] = null
    }
    getMyBetByType(s) {
        return this.myBets[this.typeInfo[s].index]
    }
    addMyBet(s) {
        return this.myBets[this.typeInfo[s.type].index] = s, this.myBets[this.typeInfo[s.type].index]
    }
    getNextBetByType(s) {
        return this.nextBets[this.typeInfo[s].index]
    }
    formatBet(s) {
        let {
            bet: d,
            currencyName: k,
            userId: y,
            name: I,
            betId: P,
            x: B,
            gameId: L
        } = s;
        const D = de.bn2amount(d, k),
            z = de.amount2locale(D, k);
        return {
            bet: new $e(D),
            usd: z,
            userId: y,
            name: I,
            betId: P.toNumber(),
            currencyName: k,
            type: B,
            gameId: L.toNumber(),
            status: 0
        }
    }
}

function Dc() {
    const g = ee();
    return m(Or.Provider, {
        value: g.xbet,
        children: S("div", {
            className: zt(Ac, "manual-control"),
            children: [m(qe.CoinInput, {}), m(qa, {
                type: he.RED
            }), m(qa, {
                type: he.GREEN
            }), m(qa, {
                type: he.MOON
            })]
        })
    })
}

function Hr({
    type: g,
    children: b
}) {
    const s = Y(),
        k = la().typeInfo[g],
        y = S(wt, {
            children: [m("div", {
                children: s("common.payout")
            }), S("div", {
                className: "bet-payout",
                children: [k.payout, "x"]
            })]
        });
    return m(ol, {
        className: zt(Oc, "bet-item"),
        label: y,
        children: b
    })
}
const qa = Q(function({
        type: g
    }) {
        const b = Y(),
            s = la(),
            [d, k] = H.exports.useState(!1),
            y = s.typeInfo[g],
            I = s.getMyBetByType(g),
            P = y.label;
        H.exports.useEffect(() => {
            if (d) {
                const X = setTimeout(() => k(!1), 3e3);
                return () => clearTimeout(X)
            }
        }, [d]);
        const B = H.exports.useCallback(X => {
            X == I && k(!0)
        }, [I]);
        H.exports.useEffect(() => (s.on("win", B), () => {
            s.off("win", B)
        }), [B]);
        const L = ["bet-button", `type${g}`].join(" ");
        let D;
        const z = () => {
            s.handleBetByType(g).catch(bt)
        };
        if (s.game.status == Oe.STARTING) I ? D = m(le, {
            type: "gray",
            className: `${L} is-active`,
            children: m("div", {
                children: b("common.betting")
            })
        }) : D = m(le, {
            type: "gray",
            className: L,
            onClick: z,
            children: m("div", {
                children: `Bet ${P}`
            })
        });
        else if (I && I.status == jr.PENDING) D = m(le, {
            type: "gray",
            className: `${L} is-active`,
            children: m("div", {
                children: b("common.betting")
            })
        });
        else {
            const X = s.getNextBetByType(g);
            X ? D = S(le, {
                type: "gray",
                className: `${L} is-active`,
                onClick: () => s.handleCancelNext(X),
                children: [m("div", {
                    children: b("common.loading")
                }), m("div", {
                    className: "sub-txt",
                    children: b("crash.common.can_next")
                })]
            }) : D = S(le, {
                type: "gray",
                className: L,
                onClick: () => s.handleBetNext(g),
                children: [m("div", {
                    children: `Bet ${P}`
                }), m("div", {
                    className: "sub-txt",
                    children: b("crash.common.bet_next")
                })]
            })
        }
        return S(Hr, {
            type: g,
            children: [D, d && m(il, {
                className: "winner"
            })]
        })
    }),
    Oc = "b172tqpi",
    Ac = "sdvszi5";

function Bc() {
    const g = ee();
    return m(Or.Provider, {
        value: g.xbet,
        children: S("div", {
            className: zt(Rc, "auto-control"),
            children: [m(qe.CoinInput, {
                checkIncrease: !0
            }), m(qe.TimesInput, {}), m(qe.IncreaseInput, {}), m(qe.IncreaseInput, {
                isLose: !0
            }), m(qe.StopInput, {}), m(qe.StopInput, {
                isLose: !0
            }), S("div", {
                className: "buttons",
                children: [m(Ua, {
                    type: he.RED
                }), m(Ua, {
                    type: he.GREEN
                }), m(Ua, {
                    type: he.MOON
                })]
            })]
        })
    })
}
const Ua = Q(function({
        type: g
    }) {
        const b = Y(),
            s = la(),
            d = s.typeInfo[g],
            k = () => {
                s.autoBetType = s.autoBetType ? null : g
            },
            y = ["bet-button", `type${g}`].join(" ");
        let I;
        return s.autoBetType ? s.autoBetType == g ? I = m(le, {
            type: "gray",
            className: `${y} is-active`,
            onClick: k,
            children: m("div", {
                children: b("common.stop_auto_bet")
            })
        }) : I = m(le, {
            type: "gray",
            className: y,
            onClick: k,
            disabled: !0,
            children: m("div", {
                children: `Bet ${d.label}`
            })
        }) : I = m(le, {
            type: "gray",
            className: y,
            onClick: k,
            children: m("div", {
                children: `Bet ${d.label}`
            })
        }), m(Hr, {
            type: g,
            children: I
        })
    }),
    Rc = "w13a7xf9";
var Vr = Q(function({
    isPC: b = !1
}) {
    const s = Y(),
        d = ee(),
        k = d.xbet.result == 0 || d.xbet.result == he.RED ? gt.trenball_red : gt.trenball_red_lose,
        y = d.xbet.result == 0 || d.xbet.result == he.GREEN ? gt.trenball_green : gt.trenball_green_lose,
        I = d.xbet.redList.length + d.xbet.greenList.length === 0,
        [P, B] = H.exports.useState(10),
        L = Sr(),
        D = H.exports.useCallback(() => {
            d.showXbetLimit = !d.showXbetLimit
        }, []),
        z = b && !d.showXbetLimit,
        X = b ? sa(({
            height: Pe
        }) => {
            const oe = Pe / Dr(48);
            L() && B(oe - Math.trunc(oe) > .2 ? Math.ceil(oe) : Math.floor(oe))
        }, 200) : null,
        xe = d.showXbetLimit ? P : 1 / 0;
    return S("div", {
        className: zt(Ec, b && "need-scroll"),
        children: [S("div", {
            className: "banner",
            children: [S("div", {
                className: "item red",
                children: [m("img", {
                    className: "avatar",
                    src: k
                }), m("div", {
                    className: "title",
                    children: "Red Shiba"
                })]
            }), S("div", {
                className: "item knife",
                children: [m("img", {
                    src: gt.knife
                }), m("div", {
                    className: "title",
                    children: "VS"
                })]
            }), S("div", {
                className: "item green",
                children: [m("img", {
                    className: "avatar reverse",
                    src: y
                }), m("div", {
                    className: "title",
                    children: "Green Doge"
                })]
            })]
        }), m(Fc, {}), S("div", {
            className: "head-wrap",
            children: [m(yt, {
                children: m("thead", {
                    children: S("tr", {
                        children: [m("th", {
                            children: s("common.player")
                        }), m("th", {
                            children: s("common.bet")
                        })]
                    })
                })
            }), m(yt, {
                children: m("thead", {
                    children: S("tr", {
                        children: [m("th", {
                            children: s("common.player")
                        }), m("th", {
                            children: s("common.bet")
                        })]
                    })
                })
            })]
        }), I ? m(Cr, {}) : S(wt, {
            children: [z ? m(Tr, {
                bodyLock: !1,
                children: S("div", {
                    className: "bet-list",
                    children: [m(aa, {
                        type: he.RED,
                        limit: xe
                    }), m(aa, {
                        type: he.GREEN,
                        limit: xe
                    })]
                })
            }) : m("div", {
                className: "list-wrap",
                ref: X,
                children: S("div", {
                    className: "bet-list",
                    children: [m(aa, {
                        type: he.RED,
                        limit: xe
                    }), m(aa, {
                        type: he.GREEN,
                        limit: xe
                    })]
                })
            }), m("div", {
                className: "foot",
                children: S("button", {
                    onClick: D,
                    className: `list-toggle ${d.showXbetLimit?"show-more":"show-less"}`,
                    children: [m("div", {
                        children: d.showXbetLimit ? s("common.show_more") : s("common.show_less")
                    }), m(Ae, {
                        name: "Arrow"
                    })]
                })
            })]
        })]
    })
});
const Fc = Q(function() {
        const b = ee(),
            s = b.history.slice(-100).reduce((d, k) => (k.odds < 2 ? d[0]++ : d[1]++, d), [0, 0]);
        return S("div", {
            className: "info-wrap",
            children: [S("div", {
                className: "info",
                children: [S("div", {
                    className: "players",
                    children: ["Players ", m("span", {
                        className: "nums",
                        children: b.xbet.redList.length
                    })]
                }), S("div", {
                    className: "his",
                    children: ["Battles won ", m("span", {
                        className: "nums",
                        children: s[0]
                    })]
                })]
            }), S("div", {
                className: "info",
                children: [S("div", {
                    className: "players",
                    children: ["Players ", m("span", {
                        className: "nums",
                        children: b.xbet.greenList.length
                    })]
                }), S("div", {
                    className: "his",
                    children: ["Battles won ", m("span", {
                        className: "nums",
                        children: s[1]
                    })]
                })]
            })]
        })
    }),
    aa = Q(function({
        type: b,
        limit: s
    }) {
        const d = ee();
        let k = b == he.RED ? d.xbet.redList : d.xbet.greenList;
        return m(Pr, {
            children: m(yt, {
                children: m("tbody", {
                    children: k.slice(0, s).map(y => m(Lc, {
                        item: y
                    }, y.betId))
                })
            })
        })
    }),
    Lc = Q(({
        item: g
    }) => (ee().xbet, S("tr", {
        children: [S("td", {
            children: [m(Nr, {
                userId: g.userId,
                name: g.name,
                avatar: !ke.isMobile
            }), g.type == he.MOON && m("div", {
                className: "moon"
            })]
        }), m("td", {
            children: m(na, {
                className: `monospace bold status-${g.status}`,
                icon: !0,
                name: g.currencyName,
                amount: g.bet
            })
        })]
    })));
kt({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [Z("#99a4b0", .6), Z("#5f6975", .8)],
    cl3: [Z("#31343c", .6), Z("#cccfd9", .4)],
    cl4: ["#23272c", "#f6f7fa"]
});
const Ec = "w11qw415",
    zc = Ue.memo(({
        game: g
    }) => {
        const b = Y();
        return m(Et, {
            title: b("common.game_intro"),
            children: m(ca, {
                children: S("div", {
                    className: "item",
                    children: [m("h2", {
                        children: "What Is CRASH?"
                    }), m("div", {
                        className: "help-content",
                        children: g.gameInfo.detail.split(`
`).map((s, d) => m("p", {
                            children: `${s}`
                        }, d.toString()))
                    }), m("h2", {
                        children: "How To Play It?"
                    }), S("div", {
                        className: "help-content",
                        children: [m("p", {
                            children: "Before the game starts, you have 6 seconds to place your bet. After the game starts, the multiplier will get higher and higher starting from 1X."
                        }), m("p", {
                            children: 'You can click on "Cash Out" at any time to lock in the current multiplier, and your payoff will be your bets times the current multiplier.'
                        }), m("p", {
                            children: "The longer you stay in the game, the higher payoff you will get. Please be noted, however, that the curve may crash at any moment. If you fail to cash out before the crash, you will lose all your bets."
                        }), m("p", {
                            children: "Are you going to cash out at 1.01x, or are you going to stay until 100x\u30011000x\u300110000x...? It\u2019s all your call \u2013 which has to be made in a split of a second! (This game is not for the weak-hearted)."
                        })]
                    })]
                })
            })
        })
    }),
    Wc = function({
        game: b
    }) {
        return m(sl, {
            game: b,
            children: S("div", {
                className: "item",
                children: [m("h2", {
                    children: "What is the bankroll?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                    }), m("p", {
                        children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                    }), S("ul", {
                        children: [m("li", {
                            children: "Each player can only win 0.75\u2009% of the bankroll per round"
                        }), m("li", {
                            children: "All players can only win 1.125% of the funds per round"
                        })]
                    }), m("p", {
                        children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                    }), m("p", {
                        onClick: () => ll(b, 1),
                        className: "cl-primary",
                        children: "Read more about bankrollers."
                    })]
                }), m("h2", {
                    children: "How does the pool of funds operate? "
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                    }), S("p", {
                        children: [m("b", {
                            className: "cl-primary",
                            children: "The house edge is 1%."
                        }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                    }), m("p", {
                        children: "Payouts made to the winning players will be deducted from the bankroll."
                    })]
                }), m("h2", {
                    children: "How does leverage investment work?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                    }), m("p", {
                        children: "Hint: You can also use this feature as an Off-Site investment."
                    }), m("p", {
                        children: "Let's make an example:"
                    }), m("p", {
                        children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                    })]
                }), m("h2", {
                    children: "What is the bankroller dilution fee?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                    }), m("p", {
                        children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                    }), m("p", {
                        children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                    }), m("p", {
                        children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                    })]
                })]
            })
        })
    };
var jc = Wc;

function Hc() {
    const g = Y();
    return m(Et, {
        title: g("crash.trenball"),
        children: m(ca, {
            children: S("div", {
                className: "item",
                children: [m("h2", {
                    children: "\u2022What Is Trenball?"
                }), m("div", {
                    className: "help-content",
                    children: m("p", {
                        children: "Trenball is a new version of the popular Crash Game. In Trenball you can place bets on RED, GREEN or MOON depending on what you think will be the outcome of the game!"
                    })
                }), m("h2", {
                    children: "\u2022What is Red, Green & Moon?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "It is simply where the crash will bang in a round. You win depending on which of these you place your bets on."
                    }), m("p", {
                        children: "RED \u2014> Crash is less than 2"
                    }), m("p", {
                        children: "GREEN \u2014> Crash is equal to or more than 2"
                    }), m("p", {
                        children: "MOON \u2014> Crash is equal to or more than 10"
                    })]
                }), m("h2", {
                    children: "\u2022The probability in Trenball is simple too!"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "Hitting a Red is 50.5%."
                    }), m("p", {
                        children: "Hitting a Green is 49.5%."
                    }), m("p", {
                        children: "Hitting a Moon is 9.9%."
                    }), m("p", {
                        children: "House Edge is 1%."
                    })]
                }), m("h2", {
                    children: "\u2022The Payout is exciting:"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "Red pays \u2014> x1.96"
                    }), m("p", {
                        children: "Green pays \u2014> x2"
                    }), m("p", {
                        children: "Moon pays \u2014> x10"
                    })]
                }), m("h2", {
                    children: "\u2022How To Play:"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "Before each round in the game starts, you have 6 seconds to place your bet. Here you can choose to bet on Red, Green or Moon.Once the six seconds are up, CRASH will start running until it Bangs i.e reaches the end of that round."
                    }), m("p", {
                        children: "Note:"
                    }), m("p", {
                        children: "You can play both Crash and Trenball individually or at the same time! Happy Playing!"
                    })]
                }), S(yt, {
                    stripe: !0,
                    children: [m("thead", {
                        children: S("tr", {
                            children: [m("th", {}), m("th", {
                                children: "RED"
                            }), m("th", {
                                children: "GREEN"
                            }), m("th", {
                                children: "MOON"
                            })]
                        })
                    }), S("tbody", {
                        children: [S("tr", {
                            children: [m("td", {
                                children: "what is"
                            }), m("td", {
                                children: "< 2"
                            }), m("td", {
                                children: "\u2265 2"
                            }), m("td", {
                                children: "\u2265 10"
                            })]
                        }), S("tr", {
                            children: [m("td", {
                                children: "payout"
                            }), m("td", {
                                children: "1.96"
                            }), m("td", {
                                children: "2"
                            }), m("td", {
                                children: "10"
                            })]
                        }), S("tr", {
                            children: [m("td", {
                                children: "chance"
                            }), m("td", {
                                children: "50.50%"
                            }), m("td", {
                                children: "49.50%"
                            }), m("td", {
                                children: "9.9%"
                            })]
                        })]
                    })]
                })]
            })
        })
    })
}

function Vc() {
    const g = Y();
    return m(Et, {
        title: g("title.crash_help_autoRun"),
        children: m(ca, {
            children: S("div", {
                className: "item",
                children: [m("h2", {
                    children: "Why Is There Internet Lag?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "Since CRASH is a real-time online game (a game in which customers interact with it via the Internet), there is a delay between the time you click on the \u201CCash Out\u201D button and the time when the server receives your cash out instruction."
                    }), m("p", {
                        children: "The farther away you are from the server and the worse your Internet connection is, the longer it will take for your message to reach the game server."
                    }), m("p", {
                        children: "In a perfect environment, your message can travel to the server at the speed of light, but it still takes 134 milliseconds to travel around the world."
                    })]
                }), m("h2", {
                    children: "What's the Use of Automatic Cash Out?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "The best way to avoid damages caused by Internet lag is to use the automatic cash out function. Since your automatic cash out is sent to the server at the same time when you place your bet, the server can execute your cash out instruction precisely and regardless of the lag."
                    }), m("p", {
                        children: "For example, if your connection is bad and you want to cash out at 2x, then we recommend that you set automatic cash out to 2x rather than cash out manually at 2x, because after you click on \u201CCash Out\u201D, the curve may crash before your message reaches the server."
                    })]
                }), m("h2", {
                    children: "What Should You Do If the Game Is Accidentally Disconnected?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "When we notice that you are disconnected from an active game, we will try to cash out for you."
                    }), m("p", {
                        children: "However, we strongly recommend that you use the automatic cash out function to deal with this issue."
                    }), m("p", {
                        children: "Since your automatic cash out multiplier has been sent to the server, you can still cash out normally even if you are completely disconnected. This is the most reliable way to avoid damages caused by accidental disconnection."
                    })]
                })]
            })
        })
    })
}
const Gc = Q(function() {
        const s = cl()["*"] || "classic",
            d = Y(),
            k = ee(),
            y = ul(),
            I = dl(),
            [P, B] = H.exports.useState(() => ke.isMobile),
            L = sa(({
                width: oe
            }) => B(oe < 900)),
            D = H.exports.useMemo(() => {
                const oe = [{
                    title: d("common.game_intro"),
                    node: m(zc, {
                        game: k
                    })
                }, {
                    title: d("common.fairness"),
                    node: "/crash_help/fairness"
                }, {
                    title: d("common.bankroll"),
                    node: m(jc, {
                        game: k
                    })
                }, {
                    title: d("title.crash_help_autoRun"),
                    node: m(Vc, {})
                }, {
                    title: d("crash.trenball"),
                    node: m(Hc, {})
                }];
                return [m(hl, {}), m(fl, {}), m(vl, {
                    list: oe
                })]
            }, []),
            z = [{
                label: d("common.my_bet"),
                value: Ft.Mybet
            }, {
                label: d("common.history"),
                value: Dl
            }],
            X = s === "classic",
            xe = X ? Wr : Vr;
        let Pe = null;
        return P ? z.unshift({
            label: d("common.all_bet"),
            value: xe
        }) : Pe = m($c, {
            isClassic: X
        }), m(pl, {
            isDarken: y,
            isMobile: P,
            isSsr: I,
            children: X ? m(dr, {
                className: xr,
                ref: L,
                type: 1,
                manualControl: m(bc, {}),
                advancedControl: m(Mc, {}),
                controlDisalbe: k.script.isRunning,
                gameView: m(br, {}),
                top: m(gr, {
                    path: s
                }),
                right: Pe,
                actions: D,
                tabs: z
            }) : m(dr, {
                className: xr,
                ref: L,
                type: 1,
                manualControl: m(Dc, {}),
                autoControl: m(Bc, {}),
                controlIdx: k.xbet.controlIdx,
                controlDisalbe: k.xbet.autoBet.isRunning,
                onControlChange: oe => k.xbet.controlIdx = oe,
                gameView: m(br, {}),
                top: m(gr, {
                    path: s
                }),
                right: Pe,
                actions: D,
                tabs: z
            })
        })
    }),
    $c = Q(function({
        isClassic: g
    }) {
        const b = Y(),
            [s, d] = H.exports.useState(!g);
        return H.exports.useEffect(() => {
            d(!g)
        }, [g]), S("div", {
            className: qc,
            children: [S("div", {
                className: "top",
                children: [m("div", {
                    className: "title",
                    children: b("common.all_bet")
                }), S("div", {
                    className: "flex-middle",
                    children: [m("div", {
                        children: b("crash.trenball")
                    }), m(ml, {
                        value: s,
                        onChange: d
                    })]
                })]
            }), s ? m(Vr, {
                isPC: !0
            }) : m(Wr, {
                scroll: !0
            })]
        })
    }),
    xr = "c1a79hnq",
    qc = "a16m6l4j";

function Uc(g) {
    g = g.slice(0, 13);
    let s = parseInt(g, 16) / Math.pow(16, 13);
    s = parseFloat(s.toPrecision(9)), s = 99 / (1 - s);
    const d = Math.floor(s);
    return Math.max(1, d / 100)
}

function Yc(g) {
    return String(bl(g))
}

function Xc(g, b) {
    return String(gl(Sl.parse(g), b))
}

function wr(g) {
    return Math.log(g) / 6e-5
}

function ra(g) {
    return Math.pow(Math.E, 6e-5 * g)
}
const Ne = class extends yl.exports.EventEmitter {
    constructor(s) {
        super();
        O(this, "game");
        O(this, "rendering", !1);
        O(this, "renderTimes", 0);
        O(this, "currentTime", 0);
        O(this, "currentGamePayout", 0);
        O(this, "escapes", []);
        O(this, "canvas");
        O(this, "ctx");
        O(this, "width", 0);
        O(this, "height", 0);
        O(this, "startPoint", [60, 40]);
        O(this, "plotSize", [0, 0]);
        O(this, "plotValue", [0, 0]);
        O(this, "increment", [0, 0]);
        O(this, "devicePixelRatio", 2);
        O(this, "gradient");
        Qa(this, {
            colors: Ja
        }), this.game = s, this.resize = Za(this.resize.bind(this), 200), this.render = this.render.bind(this), this.mountEffect = this.mountEffect.bind(this), this.game.on("escape", this.escape.bind(this))
    }
    get colors() {
        return ke.isDarken ? ["#FFFFFF", "#FFFFFF", "#7322FF", "#3d444b", "#ed6300"] : ["#FFFFFF", "#FFFFFF", "#7322FF", "#DDDDDD", "#ed6300"]
    }
    mountEffect(s) {
        s ? this.startRendering(s) : this.stopRendering()
    }
    startRendering(s) {
        if (!s.getContext) return console.error("No canvas");
        this.rendering = !0, this.canvas = s, this.ctx = s.getContext("2d"), this.resize(), requestAnimationFrame(this.render)
    }
    stopRendering() {
        this.rendering = !1, this.canvas = null, this.ctx = null
    }
    resize() {
        this.width != this.canvas.clientWidth && (this.width = this.canvas.clientWidth * this.devicePixelRatio, this.height = this.canvas.clientHeight * this.devicePixelRatio, this.canvas.width = this.width, this.canvas.height = this.height, this.plotSize = [this.width - this.startPoint[0] * 2, this.height - this.startPoint[1]], this.gradient = this.ctx.createLinearGradient(this.width / 3, 0, this.width * 2 / 3, 0), this.gradient.addColorStop(0, this.colors[1]), this.gradient.addColorStop(1, this.colors[2]))
    }
    render() {
        !this.rendering || (this.renderTimes++, this.renderTimes % Ne.RenderInterval == 0 && (this.calcGameData(), this.calculatePlotValues(), this.clean(), this.drawGraph(), this.drawAxes(), this.drawGameData(), this.drawEscapes()), requestAnimationFrame(this.render.bind(this)))
    }
    clean() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height)
    }
    drawGraph() {
        this.ctx.lineWidth = 7, this.ctx.strokeStyle = this.gradient, this.ctx.beginPath(), this.ctx.font = "Montserrat";
        let s = [0, 0],
            d = Math.max(this.currentTime / 1e3, 100);
        for (var k = 0, y = 0; k <= this.currentTime; k += d, y++) {
            let I = ra(k) - 1,
                P = this.plotSize[1] - I * this.increment[1];
            s = [k * this.increment[0] + this.startPoint[0], P], this.ctx.lineTo(...s)
        }
        this.ctx.stroke()
    }
    drawAxes() {
        const [s, d] = this.startPoint, [k, y] = this.plotSize;

        function I(re) {
            for (var Te = .4, Re = .1, Ze = !0; Ze && !(re < Te || (Te *= 5, Re *= 2, re < Te));) Te *= 2, Re *= 5;
            return Re
        }
        const P = I(this.currentGamePayout ? this.currentGamePayout : 1);
        this.ctx.lineWidth = 1;
        let B = this.colors[3];
        this.ctx.strokeStyle = B, this.ctx.font = "22px Montserrat", this.ctx.fillStyle = B, this.ctx.textAlign = "center";
        for (var L = y / this.plotValue[1], D = P, z = 0; D < this.plotValue[1]; D += P, z++) {
            var X = y - D * L;
            if (this.ctx.fillText(D + 1 + "x", 30, X), this.ctx.beginPath(), this.ctx.moveTo(s, X), this.ctx.lineTo(s + 5, X), this.ctx.stroke(), z > 100) {
                console.log("For 3 too long");
                break
            }
        }
        const xe = I(this.plotValue[0]),
            Pe = k / (this.plotValue[0] / xe);
        for (let re = 0, Te = 0, Re = 0; re < this.plotValue[0]; re += xe, Te++, Re++) {
            var oe = re / 1e3;
            const Ze = oe.toString();
            var ce = this.ctx.measureText(Ze).width,
                Be = Te * Pe + s;
            if (this.ctx.fillText(Ze, Be - ce / 2, y + 20), Re > 100) {
                console.log("For 4 too long");
                break
            }
        }
        this.ctx.lineWidth = 1, this.ctx.beginPath(), this.ctx.moveTo(s, 0), this.ctx.lineTo(s, this.height - d), this.ctx.lineTo(this.width - s, this.height - d), this.ctx.stroke()
    }
    drawGameData() {
        if (this.ctx.textAlign = "center", this.ctx.textBaseline = "middle", this.game.status === Oe.PROGRESS && (this.ctx.fillStyle = this.colors[0], this.ctx.font = "bold " + this.fontSizePx(8) + ` ${Ne.fontFamily}`, this.ctx.fillText(this.currentGamePayout.toFixed(2) + "\xD7", this.width / 2, this.height * 2 / 5)), this.game.status === Oe.ENDED && (this.ctx.font = "bold " + this.fontSizePx(5) + ` ${Ne.fontFamily}`, this.ctx.fillStyle = this.colors[4], this.ctx.fillText($a.t("crash.message.crashed") + " @" + this.game.rate.toFixed(2) + "\xD7", this.width / 2, this.height * 2 / 5)), this.game.status === Oe.STARTING) {
            this.ctx.font = "bold " + this.fontSizePx(4) + ` ${Ne.fontFamily}`, this.ctx.fillStyle = this.colors[0];
            var s = (this.game.startTime - Date.now()) / 1e3;
            if (s < 0) return;
            this.ctx.fillText($a.t("crash.message.nextRoundAt", s.toFixed(1)), this.width / 2, this.height * 2 / 5)
        }
        this.game.status === Oe.CONNECTION && (this.ctx.font = "bold " + this.fontSizePx(3) + ` ${Ne.fontFamily}`, this.ctx.fillStyle = this.colors[0], this.ctx.fillText($a.t("crash.message.reconnection"), this.width / 2, this.height * 2 / 5))
    }
    calcGameData() {
        if (this.game.status === Oe.PROGRESS) {
            let s = Date.now() - this.game.startTime;
            this.game.paused || (this.currentTime = s > 0 ? s : 0)
        } else this.currentTime = 0;
        this.currentGamePayout = ra(this.currentTime), this.emit("payoutChange", this.currentGamePayout)
    }
    calculatePlotValues() {
        this.plotValue[1] = Ne.YAxisSizeMultiplier, this.plotValue[0] = Ne.XAxisPlotMinValue, this.currentTime > Ne.XAxisPlotMinValue && (this.plotValue[0] = this.currentTime), this.currentGamePayout > Ne.YAxisSizeMultiplier && (this.plotValue[1] = this.currentGamePayout), this.plotValue[1] -= 1, this.increment[0] = this.plotSize[0] / this.plotValue[0], this.increment[1] = this.plotSize[1] / this.plotValue[1]
    }
    fontSizePx(s) {
        var d = this.width / (this.width < 1e3 ? 60 : 100),
            k = d * s;
        return k.toFixed(2) + "px"
    }
    drawEscapes() {
        this.ctx.font = this.fontSizePx(1.5) + " Arial", this.escapes.forEach(s => {
            let [d, k, y] = xl(this.colors[0]);
            this.ctx.fillStyle = `rgba(${d}, ${k}, ${y}, .5)`, this.ctx.globalAlpha = s.payoutTween / s.payout;
            let I = this.startPoint[0] + this.increment[0] * s.elapsed,
                P = this.plotSize[1] - s.payoutTween * this.increment[1],
                B = (s.rate * .01).toFixed(2);
            this.ctx.fillText(`${s.name} @${B}`, I, P + 20), this.ctx.beginPath(), this.ctx.arc(I, P, 5, 0, 2 * Math.PI), this.ctx.closePath(), this.ctx.fill(), this.ctx.globalAlpha = 1
        })
    }
    escape(s) {
        if (s.usd < 1 && s.userId !== Ce.userId || !this.rendering || window.document.hidden) return;
        s.name = wl.getName(s.name);
        const d = ra(this.currentTime) - 1;
        let k = Object.assign({
            elapsed: this.currentTime,
            payout: d,
            payoutTween: d
        }, s);
        Ir.to(k, {
            duration: 8,
            payoutTween: 0,
            onComplete: () => {
                let y = this.escapes.indexOf(k);
                y !== -1 && this.escapes.splice(y, 1)
            }
        }), this.escapes.push(k)
    }
};
let lt = Ne;
O(lt, "XAxisPlotMinValue", 1e4), O(lt, "YAxisSizeMultiplier", 2), O(lt, "fontFamily", "Monmono"), O(lt, "RenderInterval", 3);
var Oe = (g => (g[g.CONNECTION = 0] = "CONNECTION", g[g.STARTING = 1] = "STARTING", g[g.PROGRESS = 2] = "PROGRESS", g[g.ENDED = 3] = "ENDED", g))(Oe || {});
const ee = la,
    oa = class extends kl {
        constructor() {
            super({
                name: "crash",
                namespace: "/g/c",
                validateLink: "https://bcgame-project.github.io/verify/crash.html",
                fairLink: "/crash_help/fairness"
            }, Gc);
            O(this, "gameId", 0);
            O(this, "elapsed", 0);
            O(this, "rate", 0);
            O(this, "maxRate", 100);
            O(this, "startTime", Date.now());
            O(this, "hash", "");
            O(this, "players", []);
            O(this, "showPlayers", []);
            O(this, "showPlayersLimit", !0);
            O(this, "throwLimit", {});
            O(this, "history", []);
            O(this, "playersDict", {});
            O(this, "status", 0);
            O(this, "betInfo", null);
            O(this, "nextBetInfo", null);
            O(this, "paused", !1);
            O(this, "checkPauseTimer", 0);
            O(this, "salt", _l.crashSalt);
            O(this, "xbet");
            O(this, "showXbetLimit", !0);
            O(this, "graph", new lt(this));
            O(this, "requesting", !1);
            this.waitGameEnd = this.waitGameEnd.bind(this), this.waitGameStart = this.waitGameStart.bind(this), this.xbet = new Nc(this), this.bindEvent(), Qa(this, {
                gameId: ne,
                elapsed: ne,
                rate: ne,
                maxRate: ne,
                startTime: ne,
                hash: ne,
                history: ne.ref,
                status: ne,
                betInfo: ne,
                nextBetInfo: ne,
                paused: ne,
                showXbetLimit: ne,
                canBet: Ja,
                canEscape: Ja,
                onJackpotChange: De,
                addPlayer: De,
                onPrepare: De,
                onBegin: De,
                onEnd: De
            })
        }
        get canBet() {
            return this.status == 1 && !this.betInfo && !this.script.isRunning
        }
        get canEscape() {
            return this.status == 2 && this.betInfo && this.betInfo.rate == 0
        }
        bindEvent() {
            this.socket.on("connect", this.onConnect.bind(this)), this.socket.on("reconnecting", () => this.status = 0), this.socket.on("pj", ye.decodeBind(this.onJackpotChange.bind(this), F.Jackpot)), this.socket.on("pr", ye.decodeBind(this.onPrepare.bind(this), F.Prepare)), this.socket.on("b", ye.decodeBind(this.onBet.bind(this), F.Bet)), this.socket.on("bg", ye.decodeBind(this.onBegin.bind(this), F.Begin)), this.socket.on("e", ye.decodeBind(this.onEscape.bind(this), F.Escape)), this.socket.on("ed", ye.decodeBind(this.onEnd.bind(this), F.End)), this.socket.on("st", ye.decodeBind(this.onSettle.bind(this), F.Settle)), this.socket.on("pg", ye.decodeBind(this.onProgress.bind(this), F.Progress)), this.script.enableAutoStep(!1), this.on("game_prepare", this.script.step);
            const s = this.hotkeyList.find(d => d.key == "space");
            s && (s.handler = () => (this.requesting || (this.canBet ? this.handleBetCrash().catch(bt) : this.canEscape && this.handleEscape().catch(bt)), !1)), this.on("game_end", () => {
                this.betInfo || this.script.onGameEnd(this.history.slice(-20).reverse())
            })
        }
        async init() {
            const s = super.init(),
                [d] = await Promise.all([hr.get("/crash/currency-v2/", {
                    cache: !0
                }), s]);
            this.throwLimit = d.normalBetLimits.reduce((k, y) => (k[y.currencyName] = {
                maxAmount: parseFloat(y.maxAmount),
                minAmount: parseFloat(y.minAmount)
            }, k), {}), this.xbet.jackpot = d.xbetLimits.reduce((k, y) => (k[y.currencyName] = {
                currencyName: y.currencyName,
                jackpotAmount: 1 / 0,
                maxBetAmount: parseFloat(y.maxAmount),
                minBetAmount: parseFloat(y.minAmount),
                maxProfitAmount: 1 / 0
            }, k), {})
        }
        onPrepare({
            gameId: s,
            startTime: d,
            prepareTime: k
        }) {
            this.gameId = s.toNumber(), this.status = 1, this.hash = "", this.startTime = Date.now() + d.toNumber() - k.toNumber(), this.rate = 0, this.elapsed = 0, this.players = [], this.showPlayers = [], this.playersDict = {}, this.betInfo = null, this.nextBetInfo && (this.handleBetCrash(this.nextBetInfo).catch(bt), this.nextBetInfo = null), this.emit("player_change"), this.emit("game_prepare"), this.emit("game_progress")
        }
        onBegin({
            betUserIds: s
        }) {
            if (this.status = 2, this.startTime = Date.now(), this.betInfo && !this.playersDict[Ce.userId] && s.indexOf(Ce.userId) !== -1) {
                const d = this.betInfo.currencyName;
                this.addPlayer([{
                    userId: Ce.userId,
                    name: Ce.name,
                    currencyName: d,
                    bet: this.betInfo.bet.mul(de.dict[d].unitAmount),
                    rate: 0,
                    usd: 0
                }])
            }
        }
        onProgress({
            elapsed: s
        }) {
            this.status = 2, this.elapsed = s, this.rate = ra(s);
            let d = Date.now() - this.elapsed;
            this.startTime > d && (this.startTime = d), this.emit("game_progress"), this.checkPause()
        }
        onEscape({
            userId: s,
            rate: d,
            force: k
        }) {
            if (this.status !== 2) return;
            const y = this.playersDict[s];
            !y || (y.userId === Ce.userId && this.betInfo && (this.betInfo.rate = d, this.emit("escapeSuccess", {
                amount: this.betInfo.bet,
                odds: this.betInfo.rate / 100,
                currencyName: this.betInfo.currencyName
            })), y.rate = d, this.emit("player_change"), this.emit("escape", Object.assign({}, y)))
        }
        onEnd(s) {
            this.paused = !1, window.clearTimeout(this.checkPauseTimer), this.status = 3, this.rate = new $e(s.maxRate).div(100).toNumber(), this.elapsed = wr(this.rate), this.hash = s.hash
        }
        waitGameEnd() {
            const s = this.gameId;
            return new Promise((d, k) => {
                this.once("game_end", y => {
                    y.gameId !== s ? k(new Error("Network Error! -- Crash script end")) : d(y)
                })
            })
        }
        waitGameStart() {
            return new Promise(s => this.once("game_prepare", s))
        }
        onSettle({
            gameId: s,
            hash: d,
            maxRate: k,
            escapes: y
        }) {
            let I = this.playersDict[Ce.userId];
            const P = {
                gameId: s.toNumber(),
                hash: d,
                odds: k / 100,
                crash: k,
                wager: 0,
                cashedAt: 0
            };
            if (I) {
                let B = y.find(L => L.userId === Ce.userId);
                B && B.rate !== I.rate && this.betInfo && (this.betInfo.rate = B.rate, I.rate = this.betInfo.rate), P.wager = I.bet.toNumber(), P.cashedAt = I.rate
            }
            this.resetHistory(P), this.betInfo, this.emit("game_end", P)
        }
        onBet(s) {
            this.status !== 1 && console.log("onbet msg error");
            const d = {
                currencyName: s.currencyName,
                bet: new $e(de.bn2amount(s.bet, s.currencyName)),
                userId: s.userId,
                name: s.name,
                rate: 0,
                usd: 0
            };
            s.userId === Ce.userId && this.betInfo == null && (this.betInfo = {
                currencyName: d.currencyName,
                bet: new $e(d.bet),
                rate: 0,
                autoRate: 0
            }), this.addPlayer([d])
        }
        async onConnect() {
            const [s, d] = await Promise.all([this.socketRequest("join").then(Kc), this.socketRequest("jackpot").then(Jc), this.initPms]);
            this.loadGameHistory(), Ml(() => {
                s.status === 1 ? this.status = 1 : s.status == 2 ? this.status = 2 : this.status = 3, this.gameId = s.gameId.toNumber(), this.rate = new $e(s.maxRate).div(100).toNumber(), this.elapsed = wr(this.rate), this.startTime = Date.now() + s.startTime.toNumber() - s.prepareTime.toNumber(), this.hash = s.hash, this.players = [], this.showPlayers = [], this.playersDict = {}, this.betInfo = null;
                const k = s.players.map(I => {
                    let {
                        userId: P,
                        name: B,
                        currencyName: L,
                        bet: D,
                        rate: z
                    } = I;
                    return {
                        userId: P,
                        name: B,
                        currencyName: L,
                        rate: z,
                        bet: new $e(de.bn2amount(D, L)),
                        usd: 0
                    }
                });
                this.addPlayer(k);
                let y = this.playersDict[Ce.userId];
                y && (this.betInfo = {
                    bet: y.bet,
                    autoRate: y.rate,
                    rate: y.rate,
                    currencyName: y.currencyName
                }), this.xbet.init2(s.xBets), this.onJackpotChange(d)
            })
        }
        onJackpotChange({
            jackpot: s
        }) {
            Object.keys(s).forEach(d => {
                const k = this.throwLimit[d];
                if (!k) return;
                const y = de.bn2amount(s[d], d),
                    I = Math.min(y * .0048, k.maxAmount),
                    P = this.jackpot[d];
                P ? (P.jackpotAmount = y, P.maxBetAmount = I) : this.jackpot[d] = {
                    currencyName: d,
                    jackpotAmount: y,
                    maxBetAmount: I,
                    minBetAmount: k.minAmount,
                    maxProfitAmount: y * .0075
                }
            })
        }
        addPlayer(s) {
            s.forEach(d => {
                if (!this.playersDict[d.userId]) {
                    const k = de.amount2locale(d.bet.toNumber(), d.currencyName),
                        y = ne(cr(lr({}, d), {
                            usd: k
                        }));
                    this.playersDict[d.userId] = y;
                    const I = Il(this.players, y, P => -P.usd);
                    this.players.splice(I, 0, y)
                }
            }), this.emit("player_change")
        }
        async handleBetCrash(s, d) {
            s || (s = {
                bet: this.amount,
                autoRate: this.maxRate,
                rate: 0,
                currencyName: this.currencyName
            }), await this.beforeBetCheck(s.bet), this.betInfo = s, this.txId = de.createStaticDeduction();
            const k = Zc({
                gameId: Ka.fromNumber(this.gameId),
                currencyName: s.currencyName,
                bet: s.bet.toFixed(de.getPrecision(s.currencyName)),
                autoEscapeRate: new $e(s.autoRate).mul(100).toNumber(),
                scriptId: d || null,
                frontgroundId: this.txId
            });
            try {
                return await this.socketRequest("throw-bet", k)
            } catch (y) {
                throw this.betInfo = null, y
            }
        }
        async handleScriptBet(s, d) {
            var k, y;
            return await this.handleBetCrash({
                bet: new $e(s),
                autoRate: d.payout,
                rate: 0,
                currencyName: this.currencyName
            }, (k = this.script.script) == null ? void 0 : k.id), await this.waitGameEnd(), [(((y = this.betInfo) == null ? void 0 : y.rate) || 0) / 100, this.history.slice(-20).reverse()]
        }
        async handleEscape() {
            this.requesting = !0;
            try {
                await this.socketRequest("throw-escape", Qc({
                    gameId: Ka.fromNumber(this.gameId)
                }))
            } catch (s) {
                throw s
            } finally {
                this.requesting = !1
            }
        }
        async handleNext(s = !1) {
            try {
                await this.beforeBetCheck(this.amount), this.nextBetInfo = s ? null : {
                    bet: this.amount,
                    autoRate: this.maxRate,
                    rate: 0,
                    currencyName: this.currencyName
                }
            } catch (d) {}
        }
        resetHistory({
            gameId: s,
            hash: d,
            cashedAt: k,
            wager: y
        }) {
            const I = this.history[this.history.length - 1],
                P = I ? I.gameId : 0;
            let B = new Array;
            for (let L = 0; L < oa.MAX_HISTORY && !(s <= P); L++) {
                const D = Uc(Xc(d, this.salt)),
                    z = {
                        gameId: s,
                        hash: d,
                        odds: D,
                        crash: D * 100,
                        cashedAt: 0,
                        wager: 0
                    };
                L === 0 && (z.cashedAt = k, z.wager = y), B.push(z), s--, d = Yc(d)
            }
            this.history = this.history.concat(B.reverse()).slice(-oa.MAX_HISTORY)
        }
        async loadGameHistory() {
            const s = await hr.post("/crash/result/recent/");
            this.resetHistory({
                gameId: s[0].gameId,
                hash: s[0].hash,
                odds: 0,
                crash: 0,
                cashedAt: 0,
                wager: 0
            })
        }
        checkPause() {
            window.clearTimeout(this.checkPauseTimer), this.paused = !1, this.checkPauseTimer = window.setTimeout(() => this.paused = !0, 5e3)
        }
        active() {
            this.script.isRunning ? this.enableHotkey() : (this.xbet.active(), super.active())
        }
        deactivate() {
            this.script.isRunning ? this.enableHotkey(!1) : (this.xbet.deactivate(), super.deactivate())
        }
    };
let ia = oa;
O(ia, "MAX_HISTORY", 2e3);
const Kc = ye.decode(F.CrashInfo),
    Jc = ye.decode(F.Jackpot),
    Zc = ye.encode(F.ThrowBetRequest),
    Qc = ye.encode(F.EscapeRequest),
    Gr = new ia;
var eu = Gr;
window.crash = Gr;

function ou({
    bodyLock: g
}) {
    const b = Y();
    return m(Et, {
        title: b("common.fairness"),
        children: m(ca, {
            bodyLock: g,
            children: S("div", {
                id: "crash-help-fair",
                className: "item",
                children: [m("h2", {
                    children: "Is The Game Fair?"
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "We are a fair and impartial prediction and guessing platform. Our goal is to eliminate all unfair factors and make players feel comfortable and have fun."
                    }), m("p", {
                        children: "We have generated a total of 10 million hashes (the generation chain is verifiable), and each hash corresponds to a curve crash multiplier."
                    }), m("p", {
                        children: "We release these 10 million numbers in reverse order, each corresponding to one turn of the game (i.e. we have 10 million turns in total)."
                    }), m("p", {
                        children: "In other words, the crash number of each turn already exists and is not calculated after the game starts. Players can therefore place their bet without concern."
                    })]
                }), S("h2", {
                    children: ["Will The Game Be Manipulated By The Platform?", m("a", {
                        className: "h2-link cl-primary",
                        href: "https://bcgame-project.github.io/verify/crash.html",
                        target: "_blank",
                        children: "GitHub"
                    }), "\xA0\xA0", m("a", {
                        className: "h2-link cl-primary",
                        href: "https://bcgame-project.github.io/verify/crash.html",
                        target: "_blank",
                        children: "Verify"
                    })]
                }), S("div", {
                    className: "help-content",
                    children: [m("p", {
                        children: "The integrity check value is key to verifying whether there is any official manipulation; The test algorithm is provided as follows."
                    }), m("p", {
                        children: "Example: 6b5124897c3c48d0e46cc9249f08c7e560792459f1bad1171224643b5d2be231"
                    }), S("ol", {
                        children: [m("li", {
                            children: "Take a random value in the 2^52 range, namely 16^13, i.e. a 13-bit hexadecimal number (because the hash value is hexadecimal, 2^52 === 16^13)6b5124897c3c4 (0x6b5124897c3c4 equals 1887939992208324 in the decimal system)."
                        }), m("li", {
                            children: "Distribute the random value to 0~1, by dividing it by the maximum value of 13 fs, namely 0x6b5124897c3c4/0x10000000000000. Given the discrete random nature of the hash value, we then can think that any hash value can be transformed into a random number of 0~1, 1887939992208324/4503599627370496 = 0.419206889692064."
                        }), S("li", {
                            children: ["Make the house edge 1%. Further to calculate 99/(1-X), where X is the random value calculated at Step 2. When X is 0, the result is 99; when X is 1, the result is positive infinite; when X is 0.01, the result is 100; when X is less than 0.01, the result is less than 100.", m("p", {
                                children: "Conclusion: The overall random number distribution is 99 to positive infinite; and when the random number distribution is 0~0.01, the result is less than 100."
                            }), m("p", {
                                children: "99/(1-0.419206889692064) = 170.45656748150867"
                            })]
                        }), S("li", {
                            children: ["All values less than 100 will be set to 100. In other words, there is a probability of 1% that 100 will appear. Round off the number and divide it by 100 to get the final result.", m("p", {
                                children: "170/100 = 1.70"
                            })]
                        })]
                    }), m("p", {
                        children: "Conclusion: The hash value used in the game is inverse ordered. Therefore, with the SHA256 algorithm, a previous hash used in the game can be calculated from its subsequent hash. Since there is one-to-one correspondence between the key and the value of hash, we can draw the conclusion that if a hash can be used to calculate the hash that precedes it, then this hash should have been already generated when the preceding prize is announced. Similarly, the entire hash chain is generated at the very beginning and cannot be changed once generated. Otherwise, it cannot pass verification by SHA256, and as far as the payout is concerned, this is nothing more than a probability game in which crash is a given. The official organizer cannot manipulate any game set. Therefore, CRASH is more transparent than other gambling methods. This is the cornerstone on which our game is built."
                    }), m("p", {
                        children: "Simple calculation:"
                    }), m("p", {
                        children: "When the 13-bit hash value is 8000000000000 = 1.98, 0xb000000000 = 3.168, 0xc000000000 = 3.96, that is, the first digit is greater than 8((16-8)/16\u22480.5), the result is approximately 2x; when the first digit is greater than b((16-11)/16\u22480.3), the result is approximately 3x; and when the first digit is greater than c((16-12)/16\u22480.25), the result is approximately 4x, and the same rule applies to the rest."
                    }), m("p", {
                        children: "When the 13-bit hash value is f000000000000 = 15.84, ff00000000000 = 253.44, fff000000"
                    })]
                })]
            })
        })
    })
}
export {
    jc as Bankroll, iu as Detail, ou as Fairness, eu as Game
};
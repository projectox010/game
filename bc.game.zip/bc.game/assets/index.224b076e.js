var sd = {
        modules: {}
    },
    _ = sd._ = {};
typeof JSON != "object" && (JSON = {}),
    function() {
        var rx_one = /^[\],:{}\s]*$/,
            rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,
            rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,
            rx_four = /(?:^|:|,)(?:\s*\[)+/g,
            rx_escapable = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
            rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
            gap, indent, meta, rep;

        function f(e) {
            return e < 10 ? "0" + e : e
        }

        function this_value() {
            return this.valueOf()
        }

        function quote(e) {
            return rx_escapable.lastIndex = 0, rx_escapable.test(e) ? '"' + e.replace(rx_escapable, function(s) {
                var a = meta[s];
                return typeof a == "string" ? a : "\\u" + ("0000" + s.charCodeAt(0).toString(16)).slice(-4)
            }) + '"' : '"' + e + '"'
        }

        function str(e, s) {
            var a, i, d, p, g, y = gap,
                v = s[e];
            switch (v && typeof v == "object" && typeof v.toJSON == "function" && (v = v.toJSON(e)), typeof rep == "function" && (v = rep.call(s, e, v)), typeof v) {
                case "string":
                    return quote(v);
                case "number":
                    return isFinite(v) ? String(v) : "null";
                case "boolean":
                case "null":
                    return String(v);
                case "object":
                    if (!v) return "null";
                    if (gap += indent, g = [], Object.prototype.toString.apply(v) === "[object Array]") {
                        for (p = v.length, a = 0; a < p; a += 1) g[a] = str(a, v) || "null";
                        return d = g.length === 0 ? "[]" : gap ? `[
` + gap + g.join(`,
` + gap) + `
` + y + "]" : "[" + g.join(",") + "]", gap = y, d
                    }
                    if (rep && typeof rep == "object")
                        for (p = rep.length, a = 0; a < p; a += 1) typeof rep[a] == "string" && (d = str(i = rep[a], v)) && g.push(quote(i) + (gap ? ": " : ":") + d);
                    else
                        for (i in v) Object.prototype.hasOwnProperty.call(v, i) && (d = str(i, v)) && g.push(quote(i) + (gap ? ": " : ":") + d);
                    return d = g.length === 0 ? "{}" : gap ? `{
` + gap + g.join(`,
` + gap) + `
` + y + "}" : "{" + g.join(",") + "}", gap = y, d
            }
        }
        typeof Date.prototype.toJSON != "function" && (Date.prototype.toJSON = function() {
            return isFinite(this.valueOf()) ? this.getUTCFullYear() + "-" + f(this.getUTCMonth() + 1) + "-" + f(this.getUTCDate()) + "T" + f(this.getUTCHours()) + ":" + f(this.getUTCMinutes()) + ":" + f(this.getUTCSeconds()) + "Z" : null
        }, Boolean.prototype.toJSON = this_value, Number.prototype.toJSON = this_value, String.prototype.toJSON = this_value), typeof JSON.stringify != "function" && (meta = {
            "\b": "\\b",
            "	": "\\t",
            "\n": "\\n",
            "\f": "\\f",
            "\r": "\\r",
            '"': '\\"',
            "\\": "\\\\"
        }, JSON.stringify = function(e, s, a) {
            var i;
            if (gap = "", indent = "", typeof a == "number")
                for (i = 0; i < a; i += 1) indent += " ";
            else typeof a == "string" && (indent = a);
            if (rep = s, s && typeof s != "function" && (typeof s != "object" || typeof s.length != "number")) throw new Error("JSON.stringify");
            return str("", {
                "": e
            })
        }), typeof JSON.parse != "function" && (JSON.parse = function(text, reviver) {
            var j;

            function walk(e, s) {
                var a, i, d = e[s];
                if (d && typeof d == "object")
                    for (a in d) Object.prototype.hasOwnProperty.call(d, a) && ((i = walk(d, a)) !== void 0 ? d[a] = i : delete d[a]);
                return reviver.call(e, s, d)
            }
            if (text = String(text), rx_dangerous.lastIndex = 0, rx_dangerous.test(text) && (text = text.replace(rx_dangerous, function(e) {
                    return "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4)
                })), rx_one.test(text.replace(rx_two, "@").replace(rx_three, "]").replace(rx_four, ""))) return j = eval("(" + text + ")"), typeof reviver == "function" ? walk({
                "": j
            }, "") : j;
            throw new SyntaxError("JSON.parse")
        })
    }(),
    function() {
        var e, s = Array.prototype,
            a = Object.prototype,
            i = s.slice,
            d = a.toString,
            p = a.hasOwnProperty,
            g = s.forEach,
            y = Array.isArray,
            v = {},
            w = _.each = function(t, r, n) {
                if (t == null) return !1;
                if (g && t.forEach === g) t.forEach(r, n);
                else if (t.length === +t.length) {
                    for (var u = 0, c = t.length; u < c; u++)
                        if (u in t && r.call(n, t[u], u, t) === v) return !1
                } else
                    for (var l in t)
                        if (p.call(t, l) && r.call(n, t[l], l, t) === v) return !1
            };
        _.extend = function(t) {
            return w(i.call(arguments, 1), function(r) {
                for (var n in r) r[n] !== void 0 && (t[n] = r[n])
            }), t
        }, _.extend2Lev = function(t) {
            return w(i.call(arguments, 1), function(r) {
                for (var n in r) r[n] !== void 0 && (_.isObject(r[n]) && _.isObject(t[n]) ? _.extend(t[n], r[n]) : t[n] = r[n])
            }), t
        }, _.coverExtend = function(t) {
            return w(i.call(arguments, 1), function(r) {
                for (var n in r) r[n] !== void 0 && t[n] === void 0 && (t[n] = r[n])
            }), t
        }, _.isArray = y || function(t) {
            return d.call(t) === "[object Array]"
        }, _.isFunction = function(t) {
            if (!t) return !1;
            try {
                return /^\s*\bfunction\b/.test(t)
            } catch (r) {
                return !1
            }
        }, _.isArguments = function(t) {
            return !(!t || !p.call(t, "callee"))
        }, _.toArray = function(t) {
            return t ? t.toArray ? t.toArray() : _.isArray(t) || _.isArguments(t) ? i.call(t) : _.values(t) : []
        }, _.values = function(t) {
            var r = [];
            return t == null || w(t, function(n) {
                r[r.length] = n
            }), r
        }, _.indexOf = function(t, r) {
            var n = t.indexOf;
            if (n) return n.call(t, r);
            for (var u = 0; u < t.length; u++)
                if (r === t[u]) return u;
            return -1
        }, _.hasAttribute = function(t, r) {
            return t.hasAttribute ? t.hasAttribute(r) : !(!t.attributes[r] || !t.attributes[r].specified)
        }, _.filter = function(t, r, n) {
            var u = Object.prototype.hasOwnProperty;
            if (t.filter) return t.filter(r);
            for (var c = [], l = 0; l < t.length; l++)
                if (u.call(t, l)) {
                    var h = t[l];
                    r.call(n, h, l, t) && c.push(h)
                }
            return c
        }, _.inherit = function(t, r) {
            return t.prototype = new r, t.prototype.constructor = t, t.superclass = r.prototype, t
        }, _.trim = function(t) {
            return t.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
        }, _.isObject = function(t) {
            return t != null && d.call(t) == "[object Object]"
        }, _.isEmptyObject = function(t) {
            if (_.isObject(t)) {
                for (var r in t)
                    if (p.call(t, r)) return !1;
                return !0
            }
            return !1
        }, _.isUndefined = function(t) {
            return t === void 0
        }, _.isString = function(t) {
            return d.call(t) == "[object String]"
        }, _.isDate = function(t) {
            return d.call(t) == "[object Date]"
        }, _.isBoolean = function(t) {
            return d.call(t) == "[object Boolean]"
        }, _.isNumber = function(t) {
            return d.call(t) == "[object Number]" && /[\d\.]+/.test(String(t))
        }, _.isElement = function(t) {
            return !(!t || t.nodeType !== 1)
        }, _.isJSONString = function(t) {
            try {
                JSON.parse(t)
            } catch (r) {
                return !1
            }
            return !0
        }, _.safeJSONParse = function(t) {
            var r = null;
            try {
                r = JSON.parse(t)
            } catch (n) {
                return !1
            }
            return r
        }, _.decodeURIComponent = function(t) {
            var r = t;
            try {
                r = decodeURIComponent(t)
            } catch (n) {
                r = t
            }
            return r
        }, _.encodeDates = function(t) {
            return _.each(t, function(r, n) {
                _.isDate(r) ? t[n] = _.formatDate(r) : _.isObject(r) && (t[n] = _.encodeDates(r))
            }), t
        }, _.mediaQueriesSupported = function() {
            return window.matchMedia !== void 0 || window.msMatchMedia !== void 0
        }, _.getScreenOrientation = function() {
            var t = screen.msOrientation || screen.mozOrientation || (screen.orientation || {}).type,
                r = "\u672A\u53D6\u5230\u503C";
            if (t) r = t.indexOf("landscape") > -1 ? "landscape" : "portrait";
            else if (_.mediaQueriesSupported()) {
                var n = window.matchMedia || window.msMatchMedia;
                n("(orientation: landscape)").matches ? r = "landscape" : n("(orientation: portrait)").matches && (r = "portrait")
            }
            return r
        }, _.now = Date.now || function() {
            return new Date().getTime()
        }, _.throttle = function(t, r, n) {
            var u, c, l, h = null,
                b = 0;
            n || (n = {});
            var k = function() {
                b = n.leading === !1 ? 0 : _.now(), h = null, l = t.apply(u, c), h || (u = c = null)
            };
            return function() {
                var S = _.now();
                b || n.leading !== !1 || (b = S);
                var O = r - (S - b);
                return u = this, c = arguments, O <= 0 || O > r ? (h && (clearTimeout(h), h = null), b = S, l = t.apply(u, c), h || (u = c = null)) : h || n.trailing === !1 || (h = setTimeout(k, O)), l
            }
        }, _.hashCode = function(t) {
            if (typeof t != "string") return 0;
            var r = 0;
            if (t.length == 0) return r;
            for (var n = 0; n < t.length; n++) r = (r << 5) - r + t.charCodeAt(n), r &= r;
            return r
        }, _.formatDate = function(t) {
            function r(n) {
                return n < 10 ? "0" + n : n
            }
            return t.getFullYear() + "-" + r(t.getMonth() + 1) + "-" + r(t.getDate()) + " " + r(t.getHours()) + ":" + r(t.getMinutes()) + ":" + r(t.getSeconds()) + "." + r(t.getMilliseconds())
        }, _.searchObjDate = function(t) {
            _.isObject(t) && _.each(t, function(r, n) {
                _.isObject(r) ? _.searchObjDate(t[n]) : _.isDate(r) && (t[n] = _.formatDate(r))
            })
        }, _.searchZZAppStyle = function(t) {
            t.properties.$project !== void 0 && (t.project = t.properties.$project, delete t.properties.$project), t.properties.$token !== void 0 && (t.token = t.properties.$token, delete t.properties.$token)
        }, _.formatJsonString = function(t) {
            try {
                return JSON.stringify(t, null, "  ")
            } catch (r) {
                return JSON.stringify(t)
            }
        }, _.formatString = function(t) {
            return t.length > sd.para.max_string_length ? (sd.log("\u5B57\u7B26\u4E32\u957F\u5EA6\u8D85\u8FC7\u9650\u5236\uFF0C\u5DF2\u7ECF\u505A\u622A\u53D6--" + t), t.slice(0, sd.para.max_string_length)) : t
        }, _.searchObjString = function(t) {
            _.isObject(t) && _.each(t, function(r, n) {
                _.isObject(r) ? _.searchObjString(t[n]) : _.isString(r) && (t[n] = _.formatString(r))
            })
        }, _.parseSuperProperties = function(t) {
            _.isObject(t) && (_.each(t, function(r, n) {
                if (_.isFunction(r)) try {
                    t[n] = r(), _.isFunction(t[n]) && (sd.log("\u60A8\u7684\u5C5E\u6027- " + n + " \u683C\u5F0F\u4E0D\u6EE1\u8DB3\u8981\u6C42\uFF0C\u6211\u4EEC\u5DF2\u7ECF\u5C06\u5176\u5220\u9664"), delete t[n])
                } catch (u) {
                    delete t[n], sd.log("\u60A8\u7684\u5C5E\u6027- " + n + " \u629B\u51FA\u4E86\u5F02\u5E38\uFF0C\u6211\u4EEC\u5DF2\u7ECF\u5C06\u5176\u5220\u9664")
                }
            }), _.strip_sa_properties(t))
        }, _.filterReservedProperties = function(t) {
            _.isObject(t) && _.each(["distinct_id", "user_id", "id", "date", "datetime", "event", "events", "first_id", "original_id", "device_id", "properties", "second_id", "time", "users"], function(r, n) {
                r in t && (n < 3 ? (delete t[r], sd.log("\u60A8\u7684\u5C5E\u6027- " + r + "\u662F\u4FDD\u7559\u5B57\u6BB5\uFF0C\u6211\u4EEC\u5DF2\u7ECF\u5C06\u5176\u5220\u9664")) : sd.log("\u60A8\u7684\u5C5E\u6027- " + r + "\u662F\u4FDD\u7559\u5B57\u6BB5\uFF0C\u8BF7\u907F\u514D\u5176\u4F5C\u4E3A\u5C5E\u6027\u540D"))
            })
        }, _.searchConfigData = function(t) {
            if (typeof t == "object" && t.$option) {
                var r = t.$option;
                return delete t.$option, r
            }
            return {}
        }, _.unique = function(t) {
            for (var r, n = [], u = {}, c = 0; c < t.length; c++)(r = t[c]) in u || (u[r] = !0, n.push(r));
            return n
        }, _.strip_sa_properties = function(t) {
            return _.isObject(t) && _.each(t, function(r, n) {
                if (_.isArray(r)) {
                    var u = [];
                    _.each(r, function(c) {
                        _.isString(c) ? u.push(c) : sd.log("\u60A8\u7684\u6570\u636E-", n, r, "\u7684\u6570\u7EC4\u91CC\u7684\u503C\u5FC5\u987B\u662F\u5B57\u7B26\u4E32,\u5DF2\u7ECF\u5C06\u5176\u5220\u9664")
                    }), u.length !== 0 ? t[n] = u : (delete t[n], sd.log("\u5DF2\u7ECF\u5220\u9664\u7A7A\u7684\u6570\u7EC4"))
                }
                _.isString(r) || _.isNumber(r) || _.isDate(r) || _.isBoolean(r) || _.isArray(r) || _.isFunction(r) || n === "$option" || (sd.log("\u60A8\u7684\u6570\u636E-", n, r, "-\u683C\u5F0F\u4E0D\u6EE1\u8DB3\u8981\u6C42\uFF0C\u6211\u4EEC\u5DF2\u7ECF\u5C06\u5176\u5220\u9664"), delete t[n])
            }), t
        }, _.strip_empty_properties = function(t) {
            var r = {};
            return _.each(t, function(n, u) {
                n != null && (r[u] = n)
            }), r
        }, _.utf8Encode = function(t) {
            var r, n, u, c, l = "";
            for (r = n = 0, u = (t = (t + "").replace(/\r\n/g, `
`).replace(/\r/g, `
`)).length, c = 0; c < u; c++) {
                var h = t.charCodeAt(c),
                    b = null;
                h < 128 ? n++ : b = h > 127 && h < 2048 ? String.fromCharCode(h >> 6 | 192, 63 & h | 128) : String.fromCharCode(h >> 12 | 224, h >> 6 & 63 | 128, 63 & h | 128), b !== null && (n > r && (l += t.substring(r, n)), l += b, r = n = c + 1)
            }
            return n > r && (l += t.substring(r, t.length)), l
        }, _.base64Encode = function(t) {
            if (typeof btoa == "function") return btoa(encodeURIComponent(t).replace(/%([0-9A-F]{2})/g, function(P, $) {
                return String.fromCharCode("0x" + $)
            }));
            var r, n, u, c, l, h = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                b = 0,
                k = 0,
                S = "",
                O = [];
            if (!(t = String(t))) return t;
            t = _.utf8Encode(t);
            do r = (l = t.charCodeAt(b++) << 16 | t.charCodeAt(b++) << 8 | t.charCodeAt(b++)) >> 18 & 63, n = l >> 12 & 63, u = l >> 6 & 63, c = 63 & l, O[k++] = h.charAt(r) + h.charAt(n) + h.charAt(u) + h.charAt(c); while (b < t.length);
            switch (S = O.join(""), t.length % 3) {
                case 1:
                    S = S.slice(0, -2) + "==";
                    break;
                case 2:
                    S = S.slice(0, -1) + "="
            }
            return S
        }, _.UUID = (e = function() {
            for (var t = 1 * new Date, r = 0; t == 1 * new Date;) r++;
            return t.toString(16) + r.toString(16)
        }, function() {
            var t = String(screen.height * screen.width);
            t = t && /\d{5,}/.test(t) ? t.toString(16) : String(31242 * Math.random()).replace(".", "").slice(0, 8);
            var r = e() + "-" + Math.random().toString(16).replace(".", "") + "-" + function(n) {
                var u, c, l = navigator.userAgent,
                    h = [],
                    b = 0;

                function k(S, O) {
                    var P, $ = 0;
                    for (P = 0; P < O.length; P++) $ |= h[P] << 8 * P;
                    return S ^ $
                }
                for (u = 0; u < l.length; u++) c = l.charCodeAt(u), h.unshift(255 & c), h.length >= 4 && (b = k(b, h), h = []);
                return h.length > 0 && (b = k(b, h)), b.toString(16)
            }() + "-" + t + "-" + e();
            return r || (String(Math.random()) + String(Math.random()) + String(Math.random())).slice(2, 15)
        }), _.getQueryParam = function(t, r) {
            r = r.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"), t = _.decodeURIComponent(t);
            var n = new RegExp("[\\?&]" + r + "=([^&#]*)").exec(t);
            return n === null || n && typeof n[1] != "string" && n[1].length ? "" : _.decodeURIComponent(n[1])
        }, _.urlParse = function(t) {
            var r = function(n) {
                this._fields = {
                    Username: 4,
                    Password: 5,
                    Port: 7,
                    Protocol: 2,
                    Host: 6,
                    Path: 8,
                    URL: 0,
                    QueryString: 9,
                    Fragment: 10
                }, this._values = {}, this._regex = null, this._regex = /^((\w+):\/\/)?((\w+):?(\w+)?@)?([^\/\?:]+):?(\d+)?(\/?[^\?#]+)?\??([^#]+)?#?(\w*)/, n !== void 0 && this._parse(n)
            };
            return r.prototype.setUrl = function(n) {
                this._parse(n)
            }, r.prototype._initValues = function() {
                for (var n in this._fields) this._values[n] = ""
            }, r.prototype.addQueryString = function(n) {
                if (typeof n != "object") return !1;
                var u = this._values.QueryString || "";
                for (var c in n) u = new RegExp(c + "[^&]+").test(u) ? u.replace(new RegExp(c + "[^&]+"), c + "=" + n[c]) : u.slice(-1) === "&" ? u + c + "=" + n[c] : u === "" ? c + "=" + n[c] : u + "&" + c + "=" + n[c];
                this._values.QueryString = u
            }, r.prototype.getUrl = function() {
                var n = "";
                return n += this._values.Origin, n += this._values.Port ? ":" + this._values.Port : "", n += this._values.Path, n += this._values.QueryString ? "?" + this._values.QueryString : "", n += this._values.Fragment ? "#" + this._values.Fragment : ""
            }, r.prototype.getUrl = function() {
                var n = "";
                return n += this._values.Origin, n += this._values.Port ? ":" + this._values.Port : "", n += this._values.Path, n += this._values.QueryString ? "?" + this._values.QueryString : ""
            }, r.prototype._parse = function(n) {
                this._initValues();
                var u = this._regex.exec(n);
                if (!u) throw "DPURLParser::_parse -> Invalid URL";
                for (var c in this._fields) u[this._fields[c]] !== void 0 && (this._values[c] = u[this._fields[c]]);
                this._values.Hostname = this._values.Host.replace(/:\d+$/, ""), this._values.Origin = this._values.Protocol + "://" + this._values.Hostname
            }, new r(t)
        }, _.addEvent = function() {
            function t(r) {
                return r && (r.preventDefault = t.preventDefault, r.stopPropagation = t.stopPropagation, r._getPath = t._getPath), r
            }
            t._getPath = function() {
                    var r = this;
                    return this.path || this.composedPath && this.composedPath() || function() {
                        try {
                            var n = r.target,
                                u = [n];
                            if (n === null || n.parentElement === null) return [];
                            for (; n.parentElement !== null;) n = n.parentElement, u.unshift(n);
                            return u
                        } catch (c) {
                            return []
                        }
                    }()
                }, t.preventDefault = function() {
                    this.returnValue = !1
                }, t.stopPropagation = function() {
                    this.cancelBubble = !0
                },
                function(r, n, u) {
                    var c = !(!_.isObject(sd.para.heatmap) || !sd.para.heatmap.useCapture);
                    if (_.isObject(sd.para.heatmap) && sd.para.heatmap.useCapture === void 0 && n === "click" && (c = !0), r && r.addEventListener) r.addEventListener(n, function(b) {
                        b._getPath = t._getPath, u.call(this, b)
                    }, c);
                    else {
                        var l = "on" + n,
                            h = r[l];
                        r[l] = function(b, k, S) {
                            return function(O) {
                                if (O = O || t(window.event)) {
                                    O.target = O.srcElement;
                                    var P, $, D = !0;
                                    return typeof S == "function" && (P = S(O)), $ = k.call(b, O), P !== !1 && $ !== !1 || (D = !1), D
                                }
                            }
                        }(r, u, h)
                    }
                }.apply(null, arguments)
        }, _.addHashEvent = function(t) {
            var r = "pushState" in window.history ? "popstate" : "hashchange";
            _.addEvent(window, r, t)
        }, _.addSinglePageEvent = function(t) {
            var r = location.href,
                n = window.history.pushState,
                u = window.history.replaceState;
            window.history.pushState = function() {
                n.apply(window.history, arguments), t(r), r = location.href
            }, window.history.replaceState = function() {
                u.apply(window.history, arguments), t(r), r = location.href
            };
            var c = n ? "popstate" : "hashchange";
            _.addEvent(window, c, function() {
                t(r), r = location.href
            })
        }, _.cookie = {
            get: function(t) {
                for (var r = t + "=", n = document.cookie.split(";"), u = 0; u < n.length; u++) {
                    for (var c = n[u]; c.charAt(0) == " ";) c = c.substring(1, c.length);
                    if (c.indexOf(r) == 0) return _.decodeURIComponent(c.substring(r.length, c.length))
                }
                return null
            },
            set: function(t, r, n, u, c) {
                var l = "",
                    h = "",
                    b = "";
                if (n = n == null ? 73e3 : n, u = u === void 0 ? sd.para.cross_subdomain : u) {
                    var k = _.getCurrentDomain(location.href);
                    k === "url\u89E3\u6790\u5931\u8D25" && (k = ""), l = k ? "; domain=" + k : ""
                }
                if (n !== 0) {
                    var S = new Date;
                    String(n).slice(-1) === "s" ? S.setTime(S.getTime() + 1e3 * Number(String(n).slice(0, -1))) : S.setTime(S.getTime() + 24 * n * 60 * 60 * 1e3), h = "; expires=" + S.toGMTString()
                }
                c && (b = "; secure"), document.cookie = t + "=" + encodeURIComponent(r) + h + "; path=/" + l + b
            },
            remove: function(t, r) {
                r = r === void 0 ? sd.para.cross_subdomain : r, _.cookie.set(t, "", -1, r)
            },
            getCookieName: function(t, r) {
                var n = "";
                if (r = r || location.href, sd.para.cross_subdomain === !1) {
                    try {
                        n = _.URL(r).hostname
                    } catch (u) {
                        sd.log(u)
                    }
                    n = typeof n == "string" && n !== "" ? "sajssdk_2015_" + t + "_" + n.replace(/\./g, "_") : "sajssdk_2015_root_" + t
                } else n = "sajssdk_2015_cross_" + t;
                return n
            },
            getNewUser: function() {
                return this.get("sensorsdata_is_new_user") !== null || this.get(this.getCookieName("new_user")) !== null
            }
        }, _.getElementContent = function(t, r) {
            var n = "",
                u = "";
            return t.textContent ? n = _.trim(t.textContent) : t.innerText && (n = _.trim(t.innerText)), n && (n = n.replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255)), u = n || "", r !== "input" && r !== "INPUT" || (t.type === "button" || t.type === "submit" || sd.para.heatmap && typeof sd.para.heatmap.collect_input == "function" && sd.para.heatmap.collect_input(t)) && (u = t.value || ""), u
        }, _.getEleInfo = function(t) {
            if (!t.target) return !1;
            var r = t.target,
                n = r.tagName.toLowerCase(),
                u = {};
            return u.$element_type = n, u.$element_name = r.getAttribute("name"), u.$element_id = r.getAttribute("id"), u.$element_class_name = typeof r.className == "string" ? r.className : null, u.$element_target_url = r.getAttribute("href"), u.$element_content = _.getElementContent(r, n), (u = _.strip_empty_properties(u)).$url = location.href, u.$url_path = location.pathname, u.$title = document.title, u.$viewport_width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth || 0, u
        }, _.localStorage = {
            get: function(t) {
                return window.localStorage.getItem(t)
            },
            parse: function(t) {
                var r;
                try {
                    r = JSON.parse(_.localStorage.get(t)) || null
                } catch (n) {
                    sd.log(n)
                }
                return r
            },
            set: function(t, r) {
                window.localStorage.setItem(t, r)
            },
            remove: function(t) {
                window.localStorage.removeItem(t)
            },
            isSupport: function() {
                var t = !0;
                try {
                    var r = "__sensorsdatasupport__",
                        n = "testIsSupportStorage";
                    _.localStorage.set(r, n), _.localStorage.get(r) !== n && (t = !1), _.localStorage.remove(r)
                } catch (u) {
                    t = !1
                }
                return t
            }
        }, _.sessionStorage = {
            isSupport: function() {
                var t = !0,
                    r = "__sensorsdatasupport__",
                    n = "testIsSupportStorage";
                try {
                    sessionStorage && sessionStorage.setItem ? (sessionStorage.setItem(r, n), sessionStorage.removeItem(r, n), t = !0) : t = !1
                } catch (u) {
                    t = !1
                }
                return t
            }
        }, _.isSupportCors = function() {
            return window.XMLHttpRequest !== void 0 && ("withCredentials" in new XMLHttpRequest || typeof XDomainRequest < "u")
        }, _.xhr = function(t) {
            if (t) return window.XMLHttpRequest !== void 0 && "withCredentials" in new XMLHttpRequest ? new XMLHttpRequest : typeof XDomainRequest < "u" ? new XDomainRequest : null;
            if (window.XMLHttpRequest !== void 0) return new XMLHttpRequest;
            if (window.ActiveXObject) try {
                return new ActiveXObject("Msxml2.XMLHTTP")
            } catch (r) {
                try {
                    return new ActiveXObject("Microsoft.XMLHTTP")
                } catch (n) {
                    sd.log(n)
                }
            }
        }, _.ajax = function(t) {
            function r(c) {
                if (!c) return "";
                try {
                    return JSON.parse(c)
                } catch (l) {
                    return {}
                }
            }
            t.timeout = t.timeout || 2e4, t.credentials = t.credentials === void 0 || t.credentials;
            var n = _.xhr(t.cors);
            if (!n) return !1;
            t.type || (t.type = t.data ? "POST" : "GET"), t = _.extend({
                success: function() {},
                error: function() {}
            }, t);
            try {
                typeof n == "object" && "timeout" in n ? n.timeout = t.timeout : setTimeout(function() {
                    n.abort()
                }, t.timeout + 500)
            } catch (c) {
                try {
                    setTimeout(function() {
                        n.abort()
                    }, t.timeout + 500)
                } catch (l) {
                    sd.log(l)
                }
            }
            n.onreadystatechange = function() {
                try {
                    n.readyState == 4 && (n.status >= 200 && n.status < 300 || n.status == 304 ? t.success(r(n.responseText)) : t.error(r(n.responseText), n.status), n.onreadystatechange = null, n.onload = null)
                } catch (c) {
                    n.onreadystatechange = null, n.onload = null
                }
            }, n.open(t.type, t.url, !0);
            try {
                if (t.credentials && (n.withCredentials = !0), _.isObject(t.header))
                    for (var u in t.header) n.setRequestHeader(u, t.header[u]);
                t.data && (t.cors || n.setRequestHeader("X-Requested-With", "XMLHttpRequest"), t.contentType === "application/json" ? n.setRequestHeader("Content-type", "application/json; charset=UTF-8") : n.setRequestHeader("Content-type", "application/x-www-form-urlencoded"))
            } catch (c) {
                sd.log(c)
            }
            n.send(t.data || null)
        }, _.loadScript = function(t) {
            t = _.extend({
                success: function() {},
                error: function() {},
                appendCall: function(n) {
                    document.getElementsByTagName("head")[0].appendChild(n)
                }
            }, t);
            var r = null;
            t.type === "css" && ((r = document.createElement("link")).rel = "stylesheet", r.href = t.url), t.type === "js" && ((r = document.createElement("script")).async = "async", r.setAttribute("charset", "UTF-8"), r.src = t.url, r.type = "text/javascript"), r.onload = r.onreadystatechange = function() {
                this.readyState && this.readyState !== "loaded" && this.readyState !== "complete" || (t.success(), r.onload = r.onreadystatechange = null)
            }, r.onerror = function() {
                t.error(), r.onerror = null
            }, t.appendCall(r)
        }, _.getHostname = function(t, r) {
            r && typeof r == "string" || (r = "hostname\u89E3\u6790\u5F02\u5E38");
            var n = null;
            try {
                n = _.URL(t).hostname
            } catch (u) {
                sd.log(u)
            }
            return n || r
        }, _.getQueryParamsFromUrl = function(t) {
            var r = {},
                n = t.split("?")[1] || "";
            return n && (r = _.getURLSearchParams("?" + n)), r
        }, _.getURLSearchParams = function(t) {
            for (var r = function(k) {
                    return decodeURIComponent(k)
                }, n = {}, u = (t = t || "").substring(1).split("&"), c = 0; c < u.length; c++) {
                var l = u[c].indexOf("=");
                if (l !== -1) {
                    var h = u[c].substring(0, l),
                        b = u[c].substring(l + 1);
                    h = r(h), b = r(b), n[h] = b
                }
            }
            return n
        }, _.URL = function(t) {
            var r, n = {},
                u = ["hash", "host", "hostname", "href", "origin", "password", "pathname", "port", "protocol", "search", "username"];
            if (typeof window.URL == "function" && function() {
                    try {
                        return new URL("http://modernizr.com/").href === "http://modernizr.com/"
                    } catch (b) {
                        return !1
                    }
                }())(n = new URL(t)).searchParams || (n.searchParams = (r = _.getURLSearchParams(n.search), {
                get: function(b) {
                    return r[b]
                }
            }));
            else {
                if (/^https?:\/\/.+/.test(t) === !1) throw "Invalid URL";
                var c = document.createElement("a");
                c.href = t;
                for (var l = u.length - 1; l >= 0; l--) {
                    var h = u[l];
                    n[h] = c[h]
                }
                n.hostname && typeof n.pathname == "string" && n.pathname.indexOf("/") !== 0 && (n.pathname = "/" + n.pathname), n.searchParams = function() {
                    var b = _.getURLSearchParams(n.search);
                    return {
                        get: function(k) {
                            return b[k]
                        }
                    }
                }()
            }
            return n
        }, _.getCurrentDomain = function(t) {
            var r = sd.para.current_domain;
            switch (typeof r) {
                case "function":
                    var n = r();
                    return n === "" || _.trim(n) === "" ? "url\u89E3\u6790\u5931\u8D25" : n.indexOf(".") !== -1 ? n : "url\u89E3\u6790\u5931\u8D25";
                case "string":
                    return r === "" || _.trim(r) === "" ? "url\u89E3\u6790\u5931\u8D25" : r.indexOf(".") !== -1 ? r : "url\u89E3\u6790\u5931\u8D25";
                default:
                    var u = _.getCookieTopLevelDomain();
                    return t === "" || u === "" ? "url\u89E3\u6790\u5931\u8D25" : u
            }
        }, _.getCookieTopLevelDomain = function(t) {
            var r = (t = t || window.location.hostname).split(".");
            if (_.isArray(r) && r.length >= 2 && !/^(\d+\.)+\d+$/.test(t)) {
                for (var n = "." + r.splice(r.length - 1, 1); r.length > 0;)
                    if (n = "." + r.splice(r.length - 1, 1) + n, document.cookie = "sensorsdata_domain_test=true; path=/; domain=" + n, document.cookie.indexOf("sensorsdata_domain_test=true") !== -1) {
                        var u = new Date;
                        return u.setTime(u.getTime() - 1e3), document.cookie = "sensorsdata_domain_test=true; expires=" + u.toGMTString() + "; path=/; domain=" + n, n
                    }
            }
            return ""
        }, _.isReferralTraffic = function(t) {
            return (t = t || document.referrer) === "" || _.getCookieTopLevelDomain(_.getHostname(t)) !== _.getCookieTopLevelDomain()
        }, _.ry = function(t) {
            return new _.ry.init(t)
        }, _.ry.init = function(t) {
            this.ele = t
        }, _.ry.init.prototype = {
            addClass: function(t) {
                return (" " + this.ele.className + " ").indexOf(" " + t + " ") === -1 && (this.ele.className = this.ele.className + (this.ele.className === "" ? "" : " ") + t), this
            },
            removeClass: function(t) {
                var r = " " + this.ele.className + " ";
                return r.indexOf(" " + t + " ") !== -1 && (this.ele.className = r.replace(" " + t + " ", " ").slice(1, -1)), this
            },
            hasClass: function(t) {
                return (" " + this.ele.className + " ").indexOf(" " + t + " ") !== -1
            },
            attr: function(t, r) {
                return typeof t == "string" && _.isUndefined(r) ? this.ele.getAttribute(t) : (typeof t == "string" && (r = String(r), this.ele.setAttribute(t, r)), this)
            },
            offset: function() {
                var t = this.ele.getBoundingClientRect();
                if (t.width || t.height) {
                    var r = this.ele.ownerDocument.documentElement;
                    return {
                        top: t.top + window.pageYOffset - r.clientTop,
                        left: t.left + window.pageXOffset - r.clientLeft
                    }
                }
                return {
                    top: 0,
                    left: 0
                }
            },
            getSize: function() {
                if (!window.getComputedStyle) return {
                    width: this.ele.offsetWidth,
                    height: this.ele.offsetHeight
                };
                try {
                    var t = this.ele.getBoundingClientRect();
                    return {
                        width: t.width,
                        height: t.height
                    }
                } catch (r) {
                    return {
                        width: 0,
                        height: 0
                    }
                }
            },
            getStyle: function(t) {
                return this.ele.currentStyle ? this.ele.currentStyle[t] : this.ele.ownerDocument.defaultView.getComputedStyle(this.ele, null).getPropertyValue(t)
            },
            wrap: function(t) {
                var r = document.createElement(t);
                return this.ele.parentNode.insertBefore(r, this.ele), r.appendChild(this.ele), _.ry(r)
            },
            getCssStyle: function(t) {
                var r = this.ele.style.getPropertyValue(t);
                if (r) return r;
                var n = null;
                if (typeof window.getMatchedCSSRules == "function" && (n = getMatchedCSSRules(this.ele)), !n || !_.isArray(n)) return null;
                for (var u = n.length - 1; u >= 0; u--)
                    if (r = n[u].style.getPropertyValue(t)) return r
            },
            sibling: function(t, r) {
                for (;
                    (t = t[r]) && t.nodeType !== 1;);
                return t
            },
            next: function() {
                return this.sibling(this.ele, "nextSibling")
            },
            prev: function(t) {
                return this.sibling(this.ele, "previousSibling")
            },
            siblings: function(t) {
                return this.siblings((this.ele.parentNode || {}).firstChild, this.ele)
            },
            children: function(t) {
                return this.siblings(this.ele.firstChild)
            },
            parent: function() {
                var t = this.ele.parentNode;
                return t = t && t.nodeType !== 11 ? t : null, _.ry(t)
            }
        }, _.strToUnicode = function(t) {
            if (typeof t != "string") return sd.log("\u8F6C\u6362unicode\u9519\u8BEF", t), t;
            for (var r = "", n = 0; n < t.length; n++) r += "\\" + t.charCodeAt(n).toString(16);
            return r
        }, _.getReferrer = function(t) {
            return typeof(t = t || document.referrer) != "string" ? "\u53D6\u503C\u5F02\u5E38_referrer\u5F02\u5E38_" + String(t) : (t.indexOf("https://www.baidu.com/") === 0 && (t = t.split("?")[0]), typeof(t = t.slice(0, sd.para.max_referrer_string_length)) == "string" ? t : "")
        }, _.getKeywordFromReferrer = function(t) {
            t = t || document.referrer;
            var r = sd.para.source_type.keyword;
            if (document && typeof t == "string") {
                if (t.indexOf("http") === 0) {
                    var n = _.getReferSearchEngine(t),
                        u = _.getQueryParamsFromUrl(t);
                    if (_.isEmptyObject(u)) return "\u672A\u53D6\u5230\u503C";
                    var c = null;
                    for (var l in r)
                        if (n === l && typeof u == "object") {
                            if (c = r[l], _.isArray(c))
                                for (l = 0; l < c.length; l++) {
                                    var h = u[c[l]];
                                    if (h) return h
                                } else if (u[c]) return u[c]
                        }
                    return "\u672A\u53D6\u5230\u503C"
                }
                return t === "" ? "\u672A\u53D6\u5230\u503C_\u76F4\u63A5\u6253\u5F00" : "\u672A\u53D6\u5230\u503C_\u975Ehttp\u7684url"
            }
            return "\u53D6\u503C\u5F02\u5E38_referrer\u5F02\u5E38_" + String(t)
        }, _.getReferSearchEngine = function(t) {
            var r = _.getHostname(t);
            if (!r || r === "hostname\u89E3\u6790\u5F02\u5E38") return "";
            sd.para.source_type.keyword;
            var n = {
                baidu: [/^.*\.baidu\.com$/],
                bing: [/^.*\.bing\.com$/],
                google: [/^www\.google\.com$/, /^www\.google\.com\.[a-z]{2}$/, /^www\.google\.[a-z]{2}$/],
                sm: [/^m\.sm\.cn$/],
                so: [/^.+\.so\.com$/],
                sogou: [/^.*\.sogou\.com$/],
                yahoo: [/^.*\.yahoo\.com$/]
            };
            for (var u in n)
                for (var c = n[u], l = 0, h = c.length; l < h; l++)
                    if (c[l].test(r)) return u;
            return "\u672A\u77E5\u641C\u7D22\u5F15\u64CE"
        }, _.getSourceFromReferrer = function() {
            function t(b, k) {
                for (var S = 0; S < b.length; S++)
                    if (k.split("?")[0].indexOf(b[S]) !== -1) return !0
            }
            var r = "(" + sd.para.source_type.utm.join("|") + ")\\=[^&]+",
                n = sd.para.source_type.search,
                u = sd.para.source_type.social,
                c = document.referrer || "",
                l = _.info.pageProp.url;
            if (l) {
                var h = l.match(new RegExp(r));
                return h && h[0] ? "\u4ED8\u8D39\u5E7F\u544A\u6D41\u91CF" : t(n, c) ? "\u81EA\u7136\u641C\u7D22\u6D41\u91CF" : t(u, c) ? "\u793E\u4EA4\u7F51\u7AD9\u6D41\u91CF" : c === "" ? "\u76F4\u63A5\u6D41\u91CF" : "\u5F15\u8350\u6D41\u91CF"
            }
            return "\u83B7\u53D6url\u5F02\u5E38"
        }, _.info = {
            initPage: function() {
                var t = _.getReferrer(),
                    r = location.href,
                    n = _.getCurrentDomain(r);
                n || sd.debug.jssdkDebug("url_domain\u5F02\u5E38_" + r + "_" + n), this.pageProp = {
                    referrer: t,
                    referrer_host: t ? _.getHostname(t) : "",
                    url: r,
                    url_host: _.getHostname(r, "url_host\u53D6\u503C\u5F02\u5E38"),
                    url_domain: n
                }
            },
            pageProp: {},
            campaignParams: function() {
                var t = sd.source_channel_standard.split(" "),
                    r = "",
                    n = {};
                return _.isArray(sd.para.source_channel) && sd.para.source_channel.length > 0 && (t = t.concat(sd.para.source_channel), t = _.unique(t)), _.each(t, function(u) {
                    (r = _.getQueryParam(location.href, u)).length && (n[u] = r)
                }), n
            },
            campaignParamsStandard: function(t, r) {
                t = t || "", r = r || "";
                var n = _.info.campaignParams(),
                    u = {},
                    c = {};
                for (var l in n)(" " + sd.source_channel_standard + " ").indexOf(" " + l + " ") !== -1 ? u[t + l] = n[l] : c[r + l] = n[l];
                return {
                    $utms: u,
                    otherUtms: c
                }
            },
            properties: function() {
                return {
                    $timezone_offset: new Date().getTimezoneOffset(),
                    $screen_height: Number(screen.height) || 0,
                    $screen_width: Number(screen.width) || 0,
                    $lib: "js",
                    $lib_version: String(sd.lib_version)
                }
            },
            currentProps: {},
            register: function(t) {
                _.extend(_.info.currentProps, t)
            }
        }, _.autoExeQueue = function() {
            return {
                items: [],
                enqueue: function(t) {
                    this.items.push(t), this.start()
                },
                dequeue: function() {
                    return this.items.shift()
                },
                getCurrentItem: function() {
                    return this.items[0]
                },
                isRun: !1,
                start: function() {
                    this.items.length > 0 && !this.isRun && (this.isRun = !0, this.getCurrentItem().start())
                },
                close: function() {
                    this.dequeue(), this.isRun = !1, this.start()
                }
            }
        }, _.trackLink = function(t, r, n) {
            var u = null;
            if ((t = t || {}).ele && (u = t.ele), t.event && (u = t.target ? t.target : t.event.target), n = n || {}, !u || typeof u != "object") return !1;
            if (!u.href || /^javascript/.test(u.href) || u.target || u.download || u.onclick) return sd.track(r, n), !1;

            function c(l) {
                l.stopPropagation(), l.preventDefault();
                var h = !1;

                function b() {
                    h || (h = !0, location.href = u.href)
                }
                setTimeout(b, 1e3), sd.track(r, n, b)
            }
            t.event && c(t.event), t.ele && _.addEvent(t.ele, "click", function(l) {
                c(l)
            })
        }, _.eventEmitter = function() {
            this._events = [], this.pendingEvents = []
        }, _.eventEmitter.prototype = {
            emit: function(t) {
                var r = [].slice.call(arguments, 1);
                _.each(this._events, function(n) {
                    n.type === t && n.callback.apply(n.context, r)
                })
            },
            on: function(t, r, n) {
                typeof r == "function" && this._events.push({
                    type: t,
                    callback: r,
                    context: n || this
                })
            },
            tempAdd: function(t, r) {
                r && t && (this.pendingEvents.push({
                    type: t,
                    data: r
                }), this.pendingEvents.length > 20 && this.pendingEvents.shift())
            },
            isReady: function() {
                var t = this;
                this.tempAdd = this.emit, this.pendingEvents.length !== 0 && (_.each(this.pendingEvents, function(r) {
                    t.emit(r.type, r.data)
                }), this.pendingEvents = [])
            }
        }
    }(), sd.para_default = {
        preset_properties: {
            latest_utm: !0,
            latest_traffic_source_type: !0,
            latest_search_keyword: !0,
            latest_referrer: !0,
            latest_referrer_host: !1,
            latest_landing_page: !1,
            url: !1,
            title: !1
        },
        img_use_crossorigin: !1,
        name: "sa",
        max_referrer_string_length: 200,
        max_string_length: 500,
        cross_subdomain: !0,
        show_log: !0,
        is_debug: !1,
        debug_mode: !1,
        debug_mode_upload: !1,
        session_time: 0,
        use_client_time: !1,
        source_channel: [],
        send_type: "image",
        vtrack_ignore: {},
        auto_init: !0,
        is_track_single_page: !1,
        is_single_page: !1,
        batch_send: !1,
        source_type: {},
        callback_timeout: 200,
        datasend_timeout: 3e3,
        queue_timeout: 300,
        is_track_device_id: !1,
        ignore_oom: !0,
        app_js_bridge: !1
    }, sd.addReferrerHost = function(e) {
        _.isObject(e.properties) && (e.properties.$first_referrer && (e.properties.$first_referrer_host = _.getHostname(e.properties.$first_referrer, "\u53D6\u503C\u5F02\u5E38")), e.type !== "track" && e.type !== "track_signup" || ("$referrer" in e.properties && (e.properties.$referrer_host = e.properties.$referrer === "" ? "" : _.getHostname(e.properties.$referrer, "\u53D6\u503C\u5F02\u5E38")), sd.para.preset_properties.latest_referrer && sd.para.preset_properties.latest_referrer_host && (e.properties.$latest_referrer_host = e.properties.$latest_referrer === "" ? "" : _.getHostname(e.properties.$latest_referrer, "\u53D6\u503C\u5F02\u5E38"))))
    }, sd.addPropsHook = function(e) {
        sd.para.preset_properties && sd.para.preset_properties.url && (e.type === "track" || e.type === "track_signup") && e.properties.$url === void 0 && (e.properties.$url = window.location.href), sd.para.preset_properties && sd.para.preset_properties.title && (e.type === "track" || e.type === "track_signup") && e.properties.$title === void 0 && (e.properties.$title = document.title)
    }, sd.initPara = function(e) {
        sd.para = e || sd.para || {};
        var s, a = {};
        if (_.isObject(sd.para.is_track_latest))
            for (var i in sd.para.is_track_latest) a["latest_" + i] = sd.para.is_track_latest[i];
        for (s in sd.para.preset_properties = _.extend({}, sd.para_default.preset_properties, a, sd.para.preset_properties || {}), sd.para_default) sd.para[s] === void 0 && (sd.para[s] = sd.para_default[s]);
        typeof sd.para.server_url == "string" && sd.para.server_url.slice(0, 3) === "://" && (sd.para.server_url = location.protocol.slice(-1) + sd.para.server_url), typeof sd.para.web_url == "string" && sd.para.web_url.slice(0, 3) === "://" && (sd.para.web_url = location.protocol.slice(-1) + sd.para.web_url), sd.para.send_type !== "image" && sd.para.send_type !== "ajax" && sd.para.send_type !== "beacon" && (sd.para.send_type = "image"), sd.bridge.initPara(), sd.bridge.initState();
        var d = {
            datasend_timeout: 6e3,
            send_interval: 6e3,
            one_send_max_length: 6
        };
        _.localStorage.isSupport() && _.isSupportCors() && typeof localStorage == "object" ? sd.para.batch_send === !0 ? (sd.para.batch_send = _.extend({}, d), sd.para.use_client_time = !0) : typeof sd.para.batch_send == "object" && (sd.para.use_client_time = !0, sd.para.batch_send = _.extend({}, d, sd.para.batch_send)) : sd.para.batch_send = !1;
        var p = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"],
            g = ["www.baidu.", "m.baidu.", "m.sm.cn", "so.com", "sogou.com", "youdao.com", "google.", "yahoo.com/", "bing.com/", "ask.com/"],
            y = ["weibo.com", "renren.com", "kaixin001.com", "douban.com", "qzone.qq.com", "zhihu.com", "tieba.baidu.com", "weixin.qq.com"],
            v = {
                baidu: ["wd", "word", "kw", "keyword"],
                google: "q",
                bing: "q",
                yahoo: "p",
                sogou: ["query", "keyword"],
                so: "q",
                sm: "q"
            };
        if (typeof sd.para.source_type == "object" && (sd.para.source_type.utm = _.isArray(sd.para.source_type.utm) ? sd.para.source_type.utm.concat(p) : p, sd.para.source_type.search = _.isArray(sd.para.source_type.search) ? sd.para.source_type.search.concat(g) : g, sd.para.source_type.social = _.isArray(sd.para.source_type.social) ? sd.para.source_type.social.concat(y) : y, sd.para.source_type.keyword = _.isObject(sd.para.source_type.keyword) ? _.extend(v, sd.para.source_type.keyword) : v), _.isObject(sd.para.heatmap) && (sd.para.heatmap.clickmap = sd.para.heatmap.clickmap || "default", sd.para.heatmap.scroll_notice_map = sd.para.heatmap.scroll_notice_map || "default", sd.para.heatmap.scroll_delay_time = sd.para.heatmap.scroll_delay_time || 4e3, sd.para.heatmap.scroll_event_duration = sd.para.heatmap.scroll_event_duration || 18e3, sd.para.heatmap.renderRefreshTime = sd.para.heatmap.renderRefreshTime || 1e3, sd.para.heatmap.loadTimeout = sd.para.heatmap.loadTimeout || 1e3), typeof sd.para.server_url == "object" && sd.para.server_url.length)
            for (s = 0; s < sd.para.server_url.length; s++) /sa\.gif[^\/]*$/.test(sd.para.server_url[s]) || (sd.para.server_url[s] = sd.para.server_url[s].replace(/\/sa$/, "/sa.gif").replace(/(\/sa)(\?[^\/]+)$/, "/sa.gif$2"));
        else /sa\.gif[^\/]*$/.test(sd.para.server_url) || (sd.para.server_url = sd.para.server_url.replace(/\/sa$/, "/sa.gif").replace(/(\/sa)(\?[^\/]+)$/, "/sa.gif$2"));
        typeof sd.para.server_url == "string" && (sd.para.debug_mode_url = sd.para.debug_mode_url || sd.para.server_url.replace("sa.gif", "debug")), sd.para.noCache === !0 ? sd.para.noCache = "?" + new Date().getTime() : sd.para.noCache = "", sd.para.callback_timeout > sd.para.datasend_timeout && (sd.para.datasend_timeout = sd.para.callback_timeout), sd.para.callback_timeout > sd.para.queue_timeout && (sd.para.queue_timeout = sd.para.callback_timeout), sd.para.queue_timeout > sd.para.datasend_timeout && (sd.para.datasend_timeout = sd.para.queue_timeout)
    }, sd.readyState = {
        state: 0,
        historyState: [],
        stateType: {
            1: "1-init\u672A\u5F00\u59CB",
            2: "2-init\u5F00\u59CB",
            3: "3-store\u5B8C\u6210"
        },
        getState: function() {
            return this.historyState.join(`
`)
        },
        setState: function(e) {
            String(e) in this.stateType && (this.state = e), this.historyState.push(this.stateType[e])
        }
    }, sd.setPreConfig = function(e) {
        sd.para = e.para, sd._q = e._q
    }, sd.setInitVar = function() {
        sd._t = sd._t || 1 * new Date, sd.lib_version = "1.15.10", sd.is_first_visitor = !1, sd.source_channel_standard = "utm_source utm_medium utm_campaign utm_content utm_term"
    }, sd.log = function() {
        if ((_.sessionStorage.isSupport() && sessionStorage.getItem("sensorsdata_jssdk_debug") === "true" || sd.para.show_log) && (sd.para.show_log !== !0 && sd.para.show_log !== "string" && sd.para.show_log !== !1 || (arguments[0] = _.formatJsonString(arguments[0])), typeof console == "object" && console.log)) try {
            return console.log.apply(console, arguments)
        } catch (e) {
            console.log(arguments[0])
        }
    }, sd.enableLocalLog = function() {
        if (_.sessionStorage.isSupport()) try {
            sessionStorage.setItem("sensorsdata_jssdk_debug", "true")
        } catch (e) {
            sd.log("enableLocalLog error: " + e.message)
        }
    }, sd.disableLocalLog = function() {
        _.sessionStorage.isSupport() && sessionStorage.removeItem("sensorsdata_jssdk_debug")
    }, sd.debug = {
        distinct_id: function() {},
        jssdkDebug: function() {},
        _sendDebug: function(e) {
            sd.track("_sensorsdata2019_debug", {
                _jssdk_debug_info: e
            })
        },
        apph5: function(e) {
            var s = "app_h5\u6253\u901A\u5931\u8D25-",
                a = {
                    1: s + "use_app_track\u4E3Afalse",
                    2: s + "Android\u6216\u8005iOS\uFF0C\u6CA1\u6709\u66B4\u9732\u76F8\u5E94\u65B9\u6CD5",
                    3.1: s + "Android\u6821\u9A8Cserver_url\u5931\u8D25",
                    3.2: s + "iOS\u6821\u9A8Cserver_url\u5931\u8D25",
                    4.1: s + "H5 \u6821\u9A8C iOS server_url \u5931\u8D25",
                    4.2: s + "H5 \u6821\u9A8C Android server_url \u5931\u8D25"
                },
                i = e.output,
                d = e.step,
                p = e.data || "";
            i !== "all" && i !== "console" || sd.log(a[d]), (i === "all" || i === "code") && _.isObject(sd.para.is_debug) && sd.para.is_debug.apph5 && (p.type && p.type.slice(0, 7) === "profile" || (p.properties._jssdk_debug_info = "apph5-" + String(d)))
        },
        defineMode: function(e) {
            var s = {
                1: {
                    title: "\u5F53\u524D\u9875\u9762\u65E0\u6CD5\u8FDB\u884C\u53EF\u89C6\u5316\u5168\u57CB\u70B9",
                    message: "App SDK \u4E0E Web JS SDK \u6CA1\u6709\u8FDB\u884C\u6253\u901A\uFF0C\u8BF7\u8054\u7CFB\u8D35\u65B9\u6280\u672F\u4EBA\u5458\u4FEE\u6B63 App SDK \u7684\u914D\u7F6E\uFF0C\u8BE6\u7EC6\u4FE1\u606F\u8BF7\u67E5\u770B\u6587\u6863\u3002",
                    link_text: "\u914D\u7F6E\u6587\u6863",
                    link_url: "https://manual.sensorsdata.cn/sa/latest/tech_sdk_client_link-1573913.html"
                },
                2: {
                    title: "\u5F53\u524D\u9875\u9762\u65E0\u6CD5\u8FDB\u884C\u53EF\u89C6\u5316\u5168\u57CB\u70B9",
                    message: "App SDK \u4E0E Web JS SDK \u6CA1\u6709\u8FDB\u884C\u6253\u901A\uFF0C\u8BF7\u8054\u7CFB\u8D35\u65B9\u6280\u672F\u4EBA\u5458\u4FEE\u6B63 Web JS SDK \u7684\u914D\u7F6E\uFF0C\u8BE6\u7EC6\u4FE1\u606F\u8BF7\u67E5\u770B\u6587\u6863\u3002",
                    link_text: "\u914D\u7F6E\u6587\u6863",
                    link_url: "https://manual.sensorsdata.cn/sa/latest/tech_sdk_client_link-1573913.html"
                },
                3: {
                    title: "\u5F53\u524D\u9875\u9762\u65E0\u6CD5\u8FDB\u884C\u53EF\u89C6\u5316\u5168\u57CB\u70B9",
                    message: "Web JS SDK \u6CA1\u6709\u5F00\u542F\u5168\u57CB\u70B9\u914D\u7F6E\uFF0C\u8BF7\u8054\u7CFB\u8D35\u65B9\u5DE5\u4F5C\u4EBA\u5458\u4FEE\u6B63 SDK \u7684\u914D\u7F6E\uFF0C\u8BE6\u7EC6\u4FE1\u606F\u8BF7\u67E5\u770B\u6587\u6863\u3002",
                    link_text: "\u914D\u7F6E\u6587\u6863",
                    link_url: "https://manual.sensorsdata.cn/sa/latest/tech_sdk_client_web_all-1573964.html"
                },
                4: {
                    title: "\u5F53\u524D\u9875\u9762\u65E0\u6CD5\u8FDB\u884C\u53EF\u89C6\u5316\u5168\u57CB\u70B9",
                    message: "Web JS SDK \u914D\u7F6E\u7684\u6570\u636E\u6821\u9A8C\u5730\u5740\u4E0E App SDK \u914D\u7F6E\u7684\u6570\u636E\u6821\u9A8C\u5730\u5740\u4E0D\u4E00\u81F4\uFF0C\u8BF7\u8054\u7CFB\u8D35\u65B9\u5DE5\u4F5C\u4EBA\u5458\u4FEE\u6B63 SDK \u7684\u914D\u7F6E\uFF0C\u8BE6\u7EC6\u4FE1\u606F\u8BF7\u67E5\u770B\u6587\u6863\u3002",
                    link_text: "\u914D\u7F6E\u6587\u6863",
                    link_url: "https://manual.sensorsdata.cn/sa/latest/tech_sdk_client_link-1573913.html"
                }
            };
            return !(!e || !s[e]) && s[e]
        }
    };
var commonWays = {
    setOnlineState: function(e) {
        if (e === !0 && _.isObject(sd.para.jsapp) && typeof sd.para.jsapp.getData == "function") {
            sd.para.jsapp.isOnline = !0;
            var s = sd.para.jsapp.getData();
            _.isArray(s) && s.length > 0 && _.each(s, function(a) {
                _.isJSONString(a) && sd.sendState.pushSend(JSON.parse(a))
            })
        } else sd.para.jsapp.isOnline = !1
    },
    autoTrackIsUsed: !1,
    isReady: function(e) {
        e()
    },
    getUtm: function() {
        return _.info.campaignParams()
    },
    getStayTime: function() {
        return (new Date - sd._t) / 1e3
    },
    setProfileLocal: function(e) {
        if (!_.localStorage.isSupport()) return sd.setProfile(e), !1;
        if (!_.isObject(e) || _.isEmptyObject(e)) return !1;
        var s = _.localStorage.parse("sensorsdata_2015_jssdk_profile"),
            a = !1;
        if (_.isObject(s) && !_.isEmptyObject(s)) {
            for (var i in e) !(i in s && s[i] !== e[i]) && i in s || (s[i] = e[i], a = !0);
            a && (_.localStorage.set("sensorsdata_2015_jssdk_profile", JSON.stringify(s)), sd.setProfile(e))
        } else _.localStorage.set("sensorsdata_2015_jssdk_profile", JSON.stringify(e)), sd.setProfile(e)
    },
    setInitReferrer: function() {
        var e = _.getReferrer();
        sd.setOnceProfile({
            _init_referrer: e,
            _init_referrer_host: _.info.pageProp.referrer_host
        })
    },
    setSessionReferrer: function() {
        var e = _.getReferrer();
        store.setSessionPropsOnce({
            _session_referrer: e,
            _session_referrer_host: _.info.pageProp.referrer_host
        })
    },
    setDefaultAttr: function() {
        _.info.register({
            _current_url: location.href,
            _referrer: _.getReferrer(),
            _referring_host: _.info.pageProp.referrer_host
        })
    },
    trackHeatMap: function(e, s, a) {
        if (typeof e == "object" && e.tagName) {
            var i = e.tagName.toLowerCase(),
                d = e.parentNode.tagName.toLowerCase();
            i === "button" || i === "a" || d === "a" || d === "button" || i === "input" || i === "textarea" || _.hasAttribute(e, "data-sensors-click") || heatmap.start(null, e, i, s, a)
        }
    },
    trackAllHeatMap: function(e, s, a) {
        if (typeof e == "object" && e.tagName) {
            var i = e.tagName.toLowerCase();
            heatmap.start(null, e, i, s, a)
        }
    },
    autoTrackSinglePage: function(e, s) {
        if (this.autoTrackIsUsed) var a = _.info.pageProp.url;
        else a = _.info.pageProp.referrer;

        function i() {
            var p = _.info.campaignParams(),
                g = {};
            for (var y in p)(" " + sd.source_channel_standard + " ").indexOf(" " + y + " ") !== -1 ? g["$" + y] = p[y] : g[y] = p[y];
            return g
        }

        function d(p, g) {
            sd.track("$pageview", _.extend({
                $referrer: a,
                $url: location.href,
                $url_path: location.pathname,
                $title: document.title
            }, p, i()), g), a = location.href
        }
        e = _.isObject(e) ? e : {}, e = _.isObject(e) ? e : {}, sd.is_first_visitor && !e.not_set_profile && (sd.setOnceProfile(_.extend({
            $first_visit_time: new Date,
            $first_referrer: _.getReferrer(),
            $first_browser_language: navigator.language || "\u53D6\u503C\u5F02\u5E38",
            $first_browser_charset: typeof document.charset == "string" ? document.charset.toUpperCase() : "\u53D6\u503C\u5F02\u5E38",
            $first_traffic_source_type: _.getSourceFromReferrer(),
            $first_search_keyword: _.getKeywordFromReferrer()
        }, i())), sd.is_first_visitor = !1), e.not_set_profile && delete e.not_set_profile, d(e, s), this.autoTrackSinglePage = d
    },
    autoTrackWithoutProfile: function(e, s) {
        e = _.isObject(e) ? e : {}, this.autoTrack(_.extend(e, {
            not_set_profile: !0
        }), s)
    },
    autoTrack: function(e, s) {
        e = _.isObject(e) ? e : {};
        var a = _.info.campaignParams(),
            i = {};
        for (var d in a)(" " + sd.source_channel_standard + " ").indexOf(" " + d + " ") !== -1 ? i["$" + d] = a[d] : i[d] = a[d];
        sd.is_first_visitor && !e.not_set_profile && (sd.setOnceProfile(_.extend({
            $first_visit_time: new Date,
            $first_referrer: _.getReferrer(),
            $first_browser_language: navigator.language || "\u53D6\u503C\u5F02\u5E38",
            $first_browser_charset: typeof document.charset == "string" ? document.charset.toUpperCase() : "\u53D6\u503C\u5F02\u5E38",
            $first_traffic_source_type: _.getSourceFromReferrer(),
            $first_search_keyword: _.getKeywordFromReferrer()
        }, i)), sd.is_first_visitor = !1), e.not_set_profile && delete e.not_set_profile;
        var p = location.href;
        sd.para.is_single_page && _.addHashEvent(function() {
            var g = _.getReferrer(p);
            sd.track("$pageview", _.extend({
                $referrer: g,
                $url: location.href,
                $url_path: location.pathname,
                $title: document.title
            }, i, e), s), p = location.href
        }), sd.track("$pageview", _.extend({
            $referrer: _.getReferrer(),
            $url: location.href,
            $url_path: location.pathname,
            $title: document.title
        }, i, e), s), this.autoTrackIsUsed = !0
    },
    getAnonymousID: function() {
        return _.isEmptyObject(sd.store._state) ? "\u8BF7\u5148\u521D\u59CB\u5316SDK" : sd.store._state._first_id || sd.store._state.first_id || sd.store._state._distinct_id || sd.store._state.distinct_id
    },
    setPlugin: function(e) {
        if (!_.isObject(e)) return !1;
        _.each(e, function(s, a) {
            _.isFunction(s) && (_.isObject(window.SensorsDataWebJSSDKPlugin) && window.SensorsDataWebJSSDKPlugin[a] ? s(window.SensorsDataWebJSSDKPlugin[a]) : sd.log(a + "\u6CA1\u6709\u83B7\u53D6\u5230,\u8BF7\u67E5\u9605\u6587\u6863\uFF0C\u8C03\u6574" + a + "\u7684\u5F15\u5165\u987A\u5E8F\uFF01"))
        })
    },
    useModulePlugin: function() {
        sd.use.apply(sd, arguments)
    },
    useAppPlugin: function() {
        this.setPlugin.apply(this, arguments)
    }
};

function BatchSend() {
    this.sendingData = 0
}
sd.quick = function() {
    var e = Array.prototype.slice.call(arguments),
        s = e[0],
        a = e.slice(1);
    if (typeof s == "string" && commonWays[s]) return commonWays[s].apply(commonWays, a);
    typeof s == "function" ? s.apply(sd, a) : sd.log("quick\u65B9\u6CD5\u4E2D\u6CA1\u6709\u8FD9\u4E2A\u529F\u80FD" + e[0])
}, sd.use = function(e, s) {
    _.isObject(sd.modules) && _.isObject(sd.modules[e]) && _.isFunction(sd.modules[e].init) && (s = s || {}, sd.modules[e].init(sd, s))
}, sd.track = function(e, s, a) {
    saEvent.check({
        event: e,
        properties: s
    }) && saEvent.send({
        type: "track",
        event: e,
        properties: s
    }, a)
}, sd.trackLink = function(e, s, a) {
    typeof e == "object" && e.tagName ? _.trackLink({
        ele: e
    }, s, a) : typeof e == "object" && e.target && e.event && _.trackLink(e, s, a)
}, sd.trackLinks = function(e, s, a) {
    return a = a || {}, !(!e || typeof e != "object") && !(!e.href || /^javascript/.test(e.href) || e.target) && void _.addEvent(e, "click", function(i) {
        i.preventDefault();
        var d = !1;

        function p() {
            d || (d = !0, location.href = e.href)
        }
        setTimeout(p, 1e3), sd.track(s, a, p)
    })
}, sd.setProfile = function(e, s) {
    saEvent.check({
        propertiesMust: e
    }) && saEvent.send({
        type: "profile_set",
        properties: e
    }, s)
}, sd.setOnceProfile = function(e, s) {
    saEvent.check({
        propertiesMust: e
    }) && saEvent.send({
        type: "profile_set_once",
        properties: e
    }, s)
}, sd.appendProfile = function(e, s) {
    saEvent.check({
        propertiesMust: e
    }) && (_.each(e, function(a, i) {
        _.isString(a) ? e[i] = [a] : _.isArray(a) ? e[i] = a : (delete e[i], sd.log("appendProfile\u5C5E\u6027\u7684\u503C\u5FC5\u987B\u662F\u5B57\u7B26\u4E32\u6216\u8005\u6570\u7EC4"))
    }), _.isEmptyObject(e) || saEvent.send({
        type: "profile_append",
        properties: e
    }, s))
}, sd.incrementProfile = function(e, s) {
    var a = e;
    _.isString(e) && ((e = {})[a] = 1), saEvent.check({
        propertiesMust: e
    }) && (function(i) {
        for (var d in i)
            if (!/-*\d+/.test(String(i[d]))) return !1;
        return !0
    }(e) ? saEvent.send({
        type: "profile_increment",
        properties: e
    }, s) : sd.log("profile_increment\u7684\u503C\u53EA\u80FD\u662F\u6570\u5B57"))
}, sd.deleteProfile = function(e) {
    saEvent.send({
        type: "profile_delete"
    }, e), store.set("distinct_id", _.UUID()), store.set("first_id", "")
}, sd.unsetProfile = function(e, s) {
    var a = e,
        i = {};
    _.isString(e) && (e = []).push(a), _.isArray(e) ? (_.each(e, function(d) {
        _.isString(d) ? i[d] = !0 : sd.log("profile_unset\u7ED9\u7684\u6570\u7EC4\u91CC\u9762\u7684\u503C\u5FC5\u987B\u65F6string,\u5DF2\u7ECF\u8FC7\u6EE4\u6389", d)
    }), saEvent.send({
        type: "profile_unset",
        properties: i
    }, s)) : sd.log("profile_unset\u7684\u53C2\u6570\u662F\u6570\u7EC4")
}, sd.identify = function(e, s) {
    typeof e == "number" && (e = String(e));
    var a = store.getFirstId();
    if (e === void 0) {
        var i = _.UUID();
        a ? store.set("first_id", i) : store.set("distinct_id", i)
    } else saEvent.check({
        distinct_id: e
    }) ? s === !0 ? a ? store.set("first_id", e) : store.set("distinct_id", e) : a ? store.change("first_id", e) : store.change("distinct_id", e) : sd.log("identify\u7684\u53C2\u6570\u5FC5\u987B\u662F\u5B57\u7B26\u4E32")
}, sd.trackSignup = function(e, s, a, i) {
    if (saEvent.check({
            distinct_id: e,
            event: s,
            properties: a
        })) {
        var d = store.getFirstId() || store.getDistinctId();
        store.set("distinct_id", e), saEvent.send({
            original_id: d,
            distinct_id: e,
            type: "track_signup",
            event: s,
            properties: a
        }, i)
    }
}, sd.trackAbtest = function(e, s) {}, sd.registerPage = function(e) {
    saEvent.check({
        properties: e
    }) ? _.extend(_.info.currentProps, e) : sd.log("register\u8F93\u5165\u7684\u53C2\u6570\u6709\u8BEF")
}, sd.clearAllRegister = function(e) {
    store.clearAllProps(e)
}, sd.register = function(e) {
    saEvent.check({
        properties: e
    }) ? store.setProps(e) : sd.log("register\u8F93\u5165\u7684\u53C2\u6570\u6709\u8BEF")
}, sd.registerOnce = function(e) {
    saEvent.check({
        properties: e
    }) ? store.setPropsOnce(e) : sd.log("registerOnce\u8F93\u5165\u7684\u53C2\u6570\u6709\u8BEF")
}, sd.registerSession = function(e) {
    saEvent.check({
        properties: e
    }) ? store.setSessionProps(e) : sd.log("registerSession\u8F93\u5165\u7684\u53C2\u6570\u6709\u8BEF")
}, sd.registerSessionOnce = function(e) {
    saEvent.check({
        properties: e
    }) ? store.setSessionPropsOnce(e) : sd.log("registerSessionOnce\u8F93\u5165\u7684\u53C2\u6570\u6709\u8BEF")
}, sd.login = function(e, s) {
    if (typeof e == "number" && (e = String(e)), saEvent.check({
            distinct_id: e
        })) {
        var a = store.getFirstId(),
            i = store.getDistinctId();
        e !== i ? (a || store.set("first_id", i), sd.trackSignup(e, "$SignUp", {}, s)) : s && s()
    } else sd.log("login\u7684\u53C2\u6570\u5FC5\u987B\u662F\u5B57\u7B26\u4E32"), s && s()
}, sd.logout = function(e) {
    var s = store.getFirstId();
    if (s)
        if (store.set("first_id", ""), e === !0) {
            var a = _.UUID();
            store.set("distinct_id", a)
        } else store.set("distinct_id", s);
    else sd.log("\u6CA1\u6709first_id\uFF0Clogout\u5931\u8D25")
}, sd.getPresetProperties = function() {
    var e = {
            $referrer: _.info.pageProp.referrer || "",
            $referrer_host: _.info.pageProp.referrer ? _.getHostname(_.info.pageProp.referrer) : "",
            $url: location.href,
            $url_path: location.pathname,
            $title: document.title || "",
            _distinct_id: store.getDistinctId()
        },
        s = _.extend({}, _.info.properties(), sd.store.getProps(), function() {
            var a = _.info.campaignParams(),
                i = {};
            for (var d in a)(" " + sd.source_channel_standard + " ").indexOf(" " + d + " ") !== -1 ? i["$" + d] = a[d] : i[d] = a[d];
            return i
        }(), e);
    return sd.para.preset_properties.latest_referrer && sd.para.preset_properties.latest_referrer_host && (s.$latest_referrer_host = s.$latest_referrer === "" ? "" : _.getHostname(s.$latest_referrer)), s
}, sd.detectMode = function() {
    var e = {
            searchKeywordMatch: location.search.match(/sa-request-id=([^&#]+)/),
            isSeachHasKeyword: function() {
                var d = this.searchKeywordMatch;
                return d && d[0] && d[1]
            },
            hasKeywordHandle: function() {
                var d = this.searchKeywordMatch,
                    p = location.search.match(/sa-request-type=([^&#]+)/),
                    g = location.search.match(/sa-request-url=([^&#]+)/);
                heatmap.setNotice(g), _.sessionStorage.isSupport() && (g && g[0] && g[1] && sessionStorage.setItem("sensors_heatmap_url", decodeURIComponent(g[1])), sessionStorage.setItem("sensors_heatmap_id", d[1]), p && p[0] && p[1] ? p[1] === "1" || p[1] === "2" || p[1] === "3" ? (p = p[1], sessionStorage.setItem("sensors_heatmap_type", p)) : p = null : p = sessionStorage.getItem("sensors_heatmap_type") !== null ? sessionStorage.getItem("sensors_heatmap_type") : null), this.isReady(d[1], p)
            },
            isReady: function(d, p, g) {
                sd.para.heatmap_url ? _.loadScript({
                    success: function() {
                        setTimeout(function() {
                            typeof sa_jssdk_heatmap_render < "u" && (sa_jssdk_heatmap_render(sd, d, p, g), typeof console == "object" && typeof console.log == "function" && (sd.heatmap_version && sd.heatmap_version === sd.lib_version || console.log("heatmap.js\u4E0Esensorsdata.js\u7248\u672C\u53F7\u4E0D\u4E00\u81F4\uFF0C\u53EF\u80FD\u5B58\u5728\u98CE\u9669!")))
                        }, 0)
                    },
                    error: function() {},
                    type: "js",
                    url: sd.para.heatmap_url
                }) : sd.log("\u6CA1\u6709\u6307\u5B9Aheatmap_url\u7684\u8DEF\u5F84")
            },
            isStoregeHasKeyword: function() {
                return _.sessionStorage.isSupport() && typeof sessionStorage.getItem("sensors_heatmap_id") == "string"
            },
            storageHasKeywordHandle: function() {
                heatmap.setNotice(), e.isReady(sessionStorage.getItem("sensors_heatmap_id"), sessionStorage.getItem("sensors_heatmap_type"), location.href)
            }
        },
        s = {
            isVtrackMode: !1,
            loadVtrack: function() {
                _.loadScript({
                    success: function() {},
                    error: function() {},
                    type: "js",
                    url: location.protocol + "//static.sensorsdata.cn/sdk/" + sd.lib_version + "/vtrack.min.js"
                })
            },
            messageListener: function(d) {
                if (d.data.source !== "sa-fe") return !1;
                d.data.type === "v-track-mode" && (d.data.data && d.data.data.isVtrack && (s.isVtrackMode = !0, s.loadVtrack()), window.removeEventListener("message", s.messageListener, !1))
            },
            removeMessageHandle: function() {
                window.removeEventListener && window.removeEventListener("message", s.messageListener, !1)
            },
            verifyVtrackMode: function() {
                window.addEventListener && window.addEventListener("message", s.messageListener, !1), window.parent && window.parent.postMessage && window.parent.postMessage({
                    source: "sa-web-sdk",
                    type: "v-is-vtrack",
                    data: {}
                }, "*")
            }
        },
        a = function(d) {
            var p = sd.bridge.initDefineBridgeInfo();

            function g() {
                var v = [];
                p.touch_app_bridge || v.push(sd.debug.defineMode("1")), _.isObject(sd.para.app_js_bridge) || (v.push(sd.debug.defineMode("2")), p.verify_success = !1), _.isObject(sd.para.heatmap) && sd.para.heatmap.clickmap == "default" || v.push(sd.debug.defineMode("3")), p.verify_success === "fail" && v.push(sd.debug.defineMode("4"));
                var w = {
                    callType: "app_alert",
                    data: v
                };
                SensorsData_App_Visual_Bridge && SensorsData_App_Visual_Bridge.sensorsdata_visualized_alert_info ? SensorsData_App_Visual_Bridge.sensorsdata_visualized_alert_info(JSON.stringify(w)) : window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.sensorsdataNativeTracker && window.webkit.messageHandlers.sensorsdataNativeTracker.postMessage && window.webkit.messageHandlers.sensorsdataNativeTracker.postMessage(JSON.stringify(w))
            }
            if (_.isObject(window.SensorsData_App_Visual_Bridge) && window.SensorsData_App_Visual_Bridge.sensorsdata_visualized_mode && (window.SensorsData_App_Visual_Bridge.sensorsdata_visualized_mode === !0 || window.SensorsData_App_Visual_Bridge.sensorsdata_visualized_mode()))
                if (_.isObject(sd.para.heatmap) && sd.para.heatmap.clickmap == "default")
                    if (_.isObject(sd.para.app_js_bridge) && p.verify_success === "success")
                        if (d) sa_jssdk_app_define_mode(sd, d);
                        else {
                            var y = location.protocol;
                            y = _.indexOf(["http:", "https:"], y) > -1 ? y : "https:", _.loadScript({
                                success: function() {
                                    setTimeout(function() {
                                        typeof sa_jssdk_app_define_mode < "u" && sa_jssdk_app_define_mode(sd, d)
                                    }, 0)
                                },
                                error: function() {},
                                type: "js",
                                url: y + "//static.sensorsdata.cn/sdk/" + sd.lib_version + "/vapph5define.min.js"
                            })
                        }
            else g();
            else g()
        };

    function i() {
        sd.readyState.setState(3), window.sensorsdata_app_call_js = function(d) {
            d && d == "visualized" && a(typeof sa_jssdk_app_define_mode < "u")
        }, a(!1), sd.bridge.app_js_bridge_v1(), _.info.initPage(), sd.para.is_track_single_page && _.addSinglePageEvent(function(d) {
            var p = function(y) {
                y = y || {}, d !== location.href && (_.info.pageProp.referrer = d, sd.quick("autoTrack", _.extend({
                    $url: location.href,
                    $referrer: d
                }, y)))
            };
            if (typeof sd.para.is_track_single_page == "boolean") p();
            else if (typeof sd.para.is_track_single_page == "function") {
                var g = sd.para.is_track_single_page();
                _.isObject(g) ? p(g) : g === !0 && p()
            }
        }), sd.para.batch_send && sd.batchSend.batchInterval(), sd.store.init(), sd.readyState.setState(4), sd._q && _.isArray(sd._q) && sd._q.length > 0 && _.each(sd._q, function(d) {
            sd[d[0]].apply(sd, Array.prototype.slice.call(d[1]))
        }), _.isObject(sd.para.heatmap) && (heatmap.initHeatmap(), heatmap.initScrollmap())
    }
    e.isSeachHasKeyword() ? e.hasKeywordHandle() : window.parent !== self ? (s.verifyVtrackMode(), setTimeout(function() {
        if (s.isVtrackMode) return !1;
        s.removeMessageHandle(), e.isStoregeHasKeyword() ? e.storageHasKeywordHandle() : i()
    }, 1e3)) : i()
}, BatchSend.prototype = {
    add: function(e) {
        _.isObject(e) && (this.writeStore(e), e.type !== "track_signup" && e.event !== "$pageview" || this.sendStrategy())
    },
    remove: function(e) {
        this.sendingData > 0 && --this.sendingData, _.isArray(e) && e.length > 0 && _.each(e, function(s) {
            _.localStorage.remove(s)
        })
    },
    send: function(e) {
        var s = this,
            a = _.isArray(sd.para.server_url) ? sd.para.server_url[0] : sd.para.server_url;
        _.ajax({
            url: a,
            type: "POST",
            data: "data_list=" + encodeURIComponent(_.base64Encode(JSON.stringify(e.vals))),
            credentials: !1,
            timeout: sd.para.batch_send.datasend_timeout,
            cors: !0,
            success: function() {
                s.remove(e.keys)
            },
            error: function() {
                s.sendingData > 0 && --s.sendingData
            }
        })
    },
    sendPrepare: function(e) {
        var s = e.vals,
            a = sd.para.batch_send.one_send_max_length,
            i = s.length;
        if (i > 0)
            if (i <= a) this.send({
                keys: e.keys,
                vals: s
            });
            else
                for (var d = 0; d * a < i; d++) this.send({
                    keys: e.keys.splice(0, a),
                    vals: s.splice(0, a)
                })
    },
    sendStrategy: function() {
        var e = this.readStore();
        e.keys.length > 0 && this.sendingData === 0 && (this.sendingData = Math.ceil(e.vals.length / sd.para.batch_send.one_send_max_length), this.sendPrepare(e))
    },
    batchInterval: function() {
        var e = this;
        setInterval(function() {
            e.sendStrategy()
        }, sd.para.batch_send.send_interval)
    },
    readStore: function() {
        for (var e = [], s = [], a = null, i = new Date().getTime(), d = localStorage.length, p = 0; p < d; p++) {
            var g = localStorage.key(p);
            g.indexOf("sawebjssdk-") === 0 && /^sawebjssdk\-\d+$/.test(g) && ((a = localStorage.getItem(g)) ? (a = _.safeJSONParse(a)) && _.isObject(a) ? (a._flush_time = i, e.push(g), s.push(a)) : (localStorage.removeItem(g), sd.log("localStorage-\u6570\u636Eparse\u5F02\u5E38" + a)) : (localStorage.removeItem(g), sd.log("localStorage-\u6570\u636E\u53D6\u503C\u5F02\u5E38" + a)))
        }
        return {
            keys: e,
            vals: s
        }
    },
    writeStore: function(e) {
        var s = String(Math.random()).slice(2, 5) + String(Math.random()).slice(2, 5) + String(new Date().getTime()).slice(3);
        localStorage.setItem("sawebjssdk-" + s, JSON.stringify(e))
    }
}, sd.batchSend = new BatchSend;
var dataSend = {
    getSendUrl: function(e, s) {
        var a = _.base64Encode(s),
            i = "crc=" + _.hashCode(a);
        return e.indexOf("?") !== -1 ? e + "&data=" + encodeURIComponent(a) + "&ext=" + encodeURIComponent(i) : e + "?data=" + encodeURIComponent(a) + "&ext=" + encodeURIComponent(i)
    },
    getSendData: function(e) {
        var s = _.base64Encode(e),
            a = "crc=" + _.hashCode(s);
        return "data=" + encodeURIComponent(s) + "&ext=" + encodeURIComponent(a)
    },
    getInstance: function(e) {
        var s = new this[this.getSendType(e)](e),
            a = s.start;
        return s.start = function() {
            _.isObject(sd.para.is_debug) && sd.para.is_debug.storage && sd.store.requests && sd.store.requests.push({
                name: this.server_url,
                initiatorType: this.img ? "img" : "xmlhttprequest",
                entryType: "resource",
                requestData: this.data
            });
            var i = this;
            a.apply(this, arguments), setTimeout(function() {
                i.isEnd(!0)
            }, sd.para.callback_timeout)
        }, s.end = function() {
            this.callback && this.callback();
            var i = this;
            setTimeout(function() {
                i.lastClear && i.lastClear()
            }, sd.para.datasend_timeout - sd.para.callback_timeout)
        }, s.isEnd = function(i) {
            if (!this.received) {
                this.received = !0, this.end();
                var d = this;
                i ? sd.para.queue_timeout - sd.para.callback_timeout <= 0 ? d.close() : setTimeout(function() {
                    d.close()
                }, sd.para.queue_timeout - sd.para.callback_timeout) : d.close()
            }
        }, s
    },
    getSendType: function(e) {
        var s = ["image", "ajax", "beacon"],
            a = s[0];
        return (a = e.config && _.indexOf(s, e.config.send_type) > -1 ? e.config.send_type : sd.para.send_type) === "beacon" && typeof navigator.sendBeacon != "function" && (a = "image"), a === "ajax" && _.isSupportCors() === !1 && (a = "image"), a
    },
    image: function(e) {
        this.callback = e.callback, this.img = document.createElement("img"), this.img.width = 1, this.img.height = 1, sd.para.img_use_crossorigin && (this.img.crossOrigin = "anonymous"), this.data = e.data, this.server_url = dataSend.getSendUrl(e.server_url, e.data)
    }
};
dataSend.image.prototype.start = function() {
    var e = this;
    sd.para.ignore_oom && (this.img.onload = function() {
        this.onload = null, this.onerror = null, this.onabort = null, e.isEnd()
    }, this.img.onerror = function() {
        this.onload = null, this.onerror = null, this.onabort = null, e.isEnd()
    }, this.img.onabort = function() {
        this.onload = null, this.onerror = null, this.onabort = null, e.isEnd()
    }), this.img.src = this.server_url
}, dataSend.image.prototype.lastClear = function() {
    this.img.src = ""
}, dataSend.ajax = function(e) {
    this.callback = e.callback, this.server_url = e.server_url, this.data = dataSend.getSendData(e.data)
}, dataSend.ajax.prototype.start = function() {
    var e = this;
    _.ajax({
        url: this.server_url,
        type: "POST",
        data: this.data,
        credentials: !1,
        timeout: sd.para.datasend_timeout,
        cors: !0,
        success: function() {
            e.isEnd()
        },
        error: function() {
            e.isEnd()
        }
    })
}, dataSend.beacon = function(e) {
    this.callback = e.callback, this.server_url = e.server_url, this.data = dataSend.getSendData(e.data)
}, dataSend.beacon.prototype.start = function() {
    var e = this;
    typeof navigator == "object" && typeof navigator.sendBeacon == "function" && navigator.sendBeacon(this.server_url, this.data), setTimeout(function() {
        e.isEnd()
    }, 40)
};
var sendState = {};
sd.sendState = sendState, sd.events = new _.eventEmitter, sendState.queue = _.autoExeQueue(), sendState.requestData = null, sendState.getSendCall = function(e, s, a) {
    if (sd.is_heatmap_render_mode) return !1;
    if (sd.readyState.state < 3) return sd.log("\u521D\u59CB\u5316\u6CA1\u6709\u5B8C\u6210"), !1;
    e._track_id = Number(String(Math.random()).slice(2, 5) + String(Math.random()).slice(2, 4) + String(new Date().getTime()).slice(-4)), sd.para.use_client_time && (e._flush_time = new Date().getTime());
    var i = e;
    if (e = JSON.stringify(e), this.requestData = {
            data: i,
            config: s,
            callback: a
        }, sd.events.tempAdd("send", i), !sd.para.app_js_bridge && sd.para.batch_send && localStorage.length < 200) return sd.log(i), sd.batchSend.add(this.requestData.data), !1;
    sd.bridge.dataSend(i, this, a), sd.log(i)
}, sendState.prepareServerUrl = function() {
    if (typeof this.requestData.config == "object" && this.requestData.config.server_url) this.sendCall(this.requestData.config.server_url, this.requestData.callback);
    else if (_.isArray(sd.para.server_url))
        for (var e = 0; e < sd.para.server_url.length; e++) this.sendCall(sd.para.server_url[e]);
    else this.sendCall(sd.para.server_url, this.requestData.callback)
}, sendState.sendCall = function(e, s) {
    var a = {
        server_url: e,
        data: JSON.stringify(this.requestData.data),
        callback: s,
        config: this.requestData.config
    };
    _.isObject(sd.para.jsapp) && !sd.para.jsapp.isOnline && typeof sd.para.jsapp.setData == "function" ? (delete a.callback, a = JSON.stringify(a), sd.para.jsapp.setData(a)) : this.pushSend(a)
}, sendState.pushSend = function(e) {
    var s = dataSend.getInstance(e),
        a = this;
    s.close = function() {
        a.queue.close()
    }, this.queue.enqueue(s)
};
var saEvent = {};
sd.saEvent = saEvent, saEvent.checkOption = {
    regChecks: {
        regName: /^((?!^distinct_id$|^original_id$|^time$|^properties$|^id$|^first_id$|^second_id$|^users$|^events$|^event$|^user_id$|^date$|^datetime$)[a-zA-Z_$][a-zA-Z\d_$]{0,99})$/i
    },
    checkPropertiesKey: function(e) {
        var s = this,
            a = !0;
        return _.each(e, function(i, d) {
            s.regChecks.regName.test(d) || (a = !1)
        }), a
    },
    check: function(e, s) {
        return typeof this[e] == "string" ? this[this[e]](s) : this[e](s)
    },
    str: function(e) {
        return !!_.isString(e) || (sd.log("\u8BF7\u68C0\u67E5\u53C2\u6570\u683C\u5F0F,\u5FC5\u987B\u662F\u5B57\u7B26\u4E32"), !0)
    },
    properties: function(e) {
        return _.strip_sa_properties(e), !e || (_.isObject(e) ? !!this.checkPropertiesKey(e) || (sd.log("properties \u91CC\u7684\u81EA\u5B9A\u4E49\u5C5E\u6027\u540D\u9700\u8981\u662F\u5408\u6CD5\u7684\u53D8\u91CF\u540D\uFF0C\u4E0D\u80FD\u4EE5\u6570\u5B57\u5F00\u5934\uFF0C\u4E14\u53EA\u5305\u542B\uFF1A\u5927\u5C0F\u5199\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\uFF0C\u81EA\u5B9A\u4E49\u5C5E\u6027\u4E0D\u80FD\u4EE5 $ \u5F00\u5934"), !0) : (sd.log("properties\u53EF\u4EE5\u6CA1\u6709\uFF0C\u4F46\u6709\u7684\u8BDD\u5FC5\u987B\u662F\u5BF9\u8C61"), !0))
    },
    propertiesMust: function(e) {
        return _.strip_sa_properties(e), e === void 0 || !_.isObject(e) || _.isEmptyObject(e) ? (sd.log("properties\u5FC5\u987B\u662F\u5BF9\u8C61\u4E14\u6709\u503C"), !0) : !!this.checkPropertiesKey(e) || (sd.log("properties \u91CC\u7684\u81EA\u5B9A\u4E49\u5C5E\u6027\u540D\u9700\u8981\u662F\u5408\u6CD5\u7684\u53D8\u91CF\u540D\uFF0C\u4E0D\u80FD\u4EE5\u6570\u5B57\u5F00\u5934\uFF0C\u4E14\u53EA\u5305\u542B\uFF1A\u5927\u5C0F\u5199\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\uFF0C\u81EA\u5B9A\u4E49\u5C5E\u6027\u4E0D\u80FD\u4EE5 $ \u5F00\u5934"), !0)
    },
    event: function(e) {
        return !(!_.isString(e) || !this.regChecks.regName.test(e)) || (sd.log("\u8BF7\u68C0\u67E5\u53C2\u6570\u683C\u5F0F\uFF0CeventName \u5FC5\u987B\u662F\u5B57\u7B26\u4E32\uFF0C\u4E14\u9700\u662F\u5408\u6CD5\u7684\u53D8\u91CF\u540D\uFF0C\u5373\u4E0D\u80FD\u4EE5\u6570\u5B57\u5F00\u5934\uFF0C\u4E14\u53EA\u5305\u542B\uFF1A\u5927\u5C0F\u5199\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u4E0B\u5212\u7EBF\u548C $,\u5176\u4E2D\u4EE5 $ \u5F00\u5934\u7684\u8868\u660E\u662F\u7CFB\u7EDF\u7684\u4FDD\u7559\u5B57\u6BB5\uFF0C\u81EA\u5B9A\u4E49\u4E8B\u4EF6\u540D\u8BF7\u4E0D\u8981\u4EE5 $ \u5F00\u5934"), !0)
    },
    test_id: "str",
    group_id: "str",
    distinct_id: function(e) {
        return !(!_.isString(e) || !/^.{1,255}$/.test(e)) || (sd.log("distinct_id\u5FC5\u987B\u662F\u4E0D\u80FD\u4E3A\u7A7A\uFF0C\u4E14\u5C0F\u4E8E255\u4F4D\u7684\u5B57\u7B26\u4E32"), !1)
    }
}, saEvent.check = function(e) {
    for (var s in e)
        if (!this.checkOption.check(s, e[s])) return !1;
    return !0
}, saEvent.send = function(e, s) {
    var a = {
        distinct_id: store.getDistinctId(),
        lib: {
            $lib: "js",
            $lib_method: "code",
            $lib_version: String(sd.lib_version)
        },
        properties: {}
    };
    _.isObject(e) && _.isObject(e.properties) && !_.isEmptyObject(e.properties) && e.properties.$lib_detail && (a.lib.$lib_detail = e.properties.$lib_detail, delete e.properties.$lib_detail), _.extend(a, sd.store.getUnionId(), e), _.isObject(e.properties) && !_.isEmptyObject(e.properties) && _.extend(a.properties, e.properties), e.type && e.type.slice(0, 7) === "profile" || (a.properties = _.extend({}, _.info.properties(), store.getProps(), store.getSessionProps(), _.info.currentProps, a.properties), sd.para.preset_properties.latest_referrer && !_.isString(a.properties.$latest_referrer) && (a.properties.$latest_referrer = "\u53D6\u503C\u5F02\u5E38"), sd.para.preset_properties.latest_search_keyword && !_.isString(a.properties.$latest_search_keyword) && (a.properties.$latest_search_keyword = "\u53D6\u503C\u5F02\u5E38"), sd.para.preset_properties.latest_traffic_source_type && !_.isString(a.properties.$latest_traffic_source_type) && (a.properties.$latest_traffic_source_type = "\u53D6\u503C\u5F02\u5E38"), sd.para.preset_properties.latest_landing_page && !_.isString(a.properties.$latest_landing_page) && (a.properties.$latest_landing_page = "\u53D6\u503C\u5F02\u5E38")), a.properties.$time && _.isDate(a.properties.$time) ? (a.time = 1 * a.properties.$time, delete a.properties.$time) : sd.para.use_client_time && (a.time = 1 * new Date), _.parseSuperProperties(a.properties), _.filterReservedProperties(a.properties), _.searchObjDate(a), _.searchObjString(a), _.searchZZAppStyle(a);
    var i = _.searchConfigData(a.properties);
    saNewUser.checkIsAddSign(a), saNewUser.checkIsFirstTime(a), sd.addReferrerHost(a), sd.addPropsHook(a), sd.para.debug_mode === !0 ? (sd.log(a), this.debugPath(JSON.stringify(a), s)) : sd.sendState.getSendCall(a, i, s)
}, saEvent.debugPath = function(e, s) {
    var a = e,
        i = "";
    i = sd.para.debug_mode_url.indexOf("?") !== -1 ? sd.para.debug_mode_url + "&data=" + encodeURIComponent(_.base64Encode(e)) : sd.para.debug_mode_url + "?data=" + encodeURIComponent(_.base64Encode(e)), _.ajax({
        url: i,
        type: "GET",
        cors: !0,
        header: {
            "Dry-Run": String(sd.para.debug_mode_upload)
        },
        success: function(d) {
            _.isEmptyObject(d) === !0 ? alert("debug\u6570\u636E\u53D1\u9001\u6210\u529F" + a) : alert("debug\u5931\u8D25 \u9519\u8BEF\u539F\u56E0" + JSON.stringify(d))
        }
    })
};
var store = sd.store = {
        requests: [],
        _sessionState: {},
        _state: {
            distinct_id: "",
            first_id: "",
            props: {}
        },
        getProps: function() {
            return this._state.props || {}
        },
        getSessionProps: function() {
            return this._sessionState
        },
        getDistinctId: function() {
            return this._state._distinct_id || this._state.distinct_id
        },
        getUnionId: function() {
            var e = {},
                s = this._state._first_id || this._state.first_id,
                a = this._state._distinct_id || this._state.distinct_id;
            return s && a ? (e.login_id = a, e.anonymous_id = s) : e.anonymous_id = a, e
        },
        getFirstId: function() {
            return this._state._first_id || this._state.first_id
        },
        toState: function(e) {
            var s = null;
            if (e != null && _.isJSONString(e))
                if (s = JSON.parse(e), this._state = _.extend(s), s.distinct_id) {
                    if (typeof s.props == "object") {
                        for (var a in s.props) typeof s.props[a] == "string" && (s.props[a] = s.props[a].slice(0, sd.para.max_referrer_string_length));
                        this.save()
                    }
                } else this.set("distinct_id", _.UUID()), sd.debug.distinct_id("1", e);
            else this.set("distinct_id", _.UUID()), sd.debug.distinct_id("2", e)
        },
        initSessionState: function() {
            var e = _.cookie.get("sensorsdata2015session"),
                s = null;
            e !== null && typeof(s = JSON.parse(e)) == "object" && (this._sessionState = s || {})
        },
        setOnce: function(e, s) {
            e in this._state || this.set(e, s)
        },
        set: function(e, s) {
            this._state = this._state || {}, e === "distinct_id" && this._state.distinct_id && sd.events.tempAdd("changeDistinctId", s), this._state[e] = s, e === "first_id" ? delete this._state._first_id : e === "distinct_id" && delete this._state._distinct_id, this.save()
        },
        change: function(e, s) {
            this._state["_" + e] = s
        },
        setSessionProps: function(e) {
            var s = this._sessionState;
            _.extend(s, e), this.sessionSave(s)
        },
        setSessionPropsOnce: function(e) {
            var s = this._sessionState;
            _.coverExtend(s, e), this.sessionSave(s)
        },
        setProps: function(e, s) {
            var a = {};
            for (var i in a = s ? e : _.extend(this._state.props || {}, e)) typeof a[i] == "string" && (a[i] = a[i].slice(0, sd.para.max_referrer_string_length));
            this.set("props", a)
        },
        setPropsOnce: function(e) {
            var s = this._state.props || {};
            _.coverExtend(s, e), this.set("props", s)
        },
        clearAllProps: function(e) {
            if (this._sessionState = {}, _.isArray(e) && e.length > 0)
                for (var s = 0; s < e.length; s++) _.isString(e[s]) && e[s].indexOf("latest_") === -1 && e[s] in this._state.props && delete this._state.props[e[s]];
            else
                for (var s in this._state.props) s.indexOf("latest_") !== 1 && delete this._state.props[s];
            this.sessionSave({}), this.save()
        },
        sessionSave: function(e) {
            this._sessionState = e, _.cookie.set("sensorsdata2015session", JSON.stringify(this._sessionState), 0)
        },
        save: function() {
            var e = JSON.parse(JSON.stringify(this._state));
            delete e._first_id, delete e._distinct_id, _.cookie.set(this.getCookieName(), JSON.stringify(e), 73e3, sd.para.cross_subdomain)
        },
        getCookieName: function() {
            var e = "";
            if (sd.para.cross_subdomain === !1) {
                try {
                    e = _.URL(location.href).hostname
                } catch (s) {
                    sd.log(s)
                }
                e = typeof e == "string" && e !== "" ? "sa_jssdk_2015_" + e.replace(/\./g, "_") : "sa_jssdk_2015_root"
            } else e = "sensorsdata2015jssdkcross";
            return e
        },
        init: function() {
            this.initSessionState();
            var e = _.UUID(),
                s = _.cookie.get(this.getCookieName());
            s === null ? (sd.is_first_visitor = !0, this.set("distinct_id", e)) : (_.isJSONString(s) && JSON.parse(s).distinct_id || (sd.is_first_visitor = !0), this.toState(s)), saNewUser.setDeviceId(e), saNewUser.storeInitCheck(), saNewUser.checkIsFirstLatest()
        }
    },
    saNewUser = {
        checkIsAddSign: function(e) {
            e.type === "track" && (_.cookie.getNewUser() ? e.properties.$is_first_day = !0 : e.properties.$is_first_day = !1)
        },
        is_first_visit_time: !1,
        checkIsFirstTime: function(e) {
            e.type === "track" && e.event === "$pageview" && (this.is_first_visit_time ? (e.properties.$is_first_time = !0, this.is_first_visit_time = !1) : e.properties.$is_first_time = !1)
        },
        setDeviceId: function(e) {
            var s = null,
                a = _.cookie.get("sensorsdata2015jssdkcross"),
                i = {};
            a != null && _.isJSONString(a) && (i = JSON.parse(a)).$device_id && (s = i.$device_id), s = s || e, sd.para.cross_subdomain === !0 ? store.set("$device_id", s) : (i.$device_id = s, _.cookie.set("sensorsdata2015jssdkcross", JSON.stringify(i), null, !0)), sd.para.is_track_device_id && (_.info.currentProps.$device_id = s)
        },
        storeInitCheck: function() {
            if (sd.is_first_visitor) {
                var e = new Date,
                    s = {
                        h: 23 - e.getHours(),
                        m: 59 - e.getMinutes(),
                        s: 59 - e.getSeconds()
                    };
                _.cookie.set(_.cookie.getCookieName("new_user"), "1", 3600 * s.h + 60 * s.m + s.s + "s"), this.is_first_visit_time = !0
            } else _.cookie.getNewUser() || (this.checkIsAddSign = function(a) {
                a.type === "track" && (a.properties.$is_first_day = !1)
            }), this.checkIsFirstTime = function(a) {
                a.type === "track" && a.event === "$pageview" && (a.properties.$is_first_time = !1)
            }
        },
        checkIsFirstLatest: function() {
            for (var e = _.info.pageProp.url_domain, s = ["$utm_source", "$utm_medium", "$utm_campaign", "$utm_content", "$utm_term"], a = store.getProps(), i = 0; i < s.length; i++) s[i] in a && delete a[s[i]];
            store.setProps(a, !0);
            var d = {};
            if (e === "" && (e = "url\u89E3\u6790\u5931\u8D25"), _.each(sd.para.preset_properties, function(v, w) {
                    if (w.indexOf("latest_") === -1) return !1;
                    if (w = w.slice(7), v) {
                        if (w !== "utm" && e === "url\u89E3\u6790\u5931\u8D25") d["$latest_" + w] = "url\u7684domain\u89E3\u6790\u5931\u8D25";
                        else if (_.isReferralTraffic(document.referrer)) switch (w) {
                            case "traffic_source_type":
                                d.$latest_traffic_source_type = _.getSourceFromReferrer();
                                break;
                            case "referrer":
                                d.$latest_referrer = _.info.pageProp.referrer;
                                break;
                            case "search_keyword":
                                d.$latest_search_keyword = _.getKeywordFromReferrer();
                                break;
                            case "landing_page":
                                d.$latest_landing_page = location.href
                        }
                    } else if (w === "utm" && sd.store._state.props)
                        for (var t in sd.store._state.props) t.indexOf("$latest_utm") !== 0 && t.indexOf("_latest_") !== 0 || delete sd.store._state.props[t];
                    else sd.store._state.props && "$latest_" + w in sd.store._state.props && delete sd.store._state.props["$latest_" + w]
                }), sd.register(d), sd.para.preset_properties.latest_utm) {
                var p = _.info.campaignParamsStandard("$latest_", "_latest_"),
                    g = p.$utms,
                    y = p.otherUtms;
                _.isEmptyObject(g) || sd.register(g), _.isEmptyObject(y) || sd.register(y)
            }
        }
    };
sd.bridge = {
    is_verify_success: !1,
    initPara: function() {
        var e = {
            is_send: !0,
            white_list: [],
            is_mui: !1
        };
        typeof sd.para.app_js_bridge == "object" ? sd.para.app_js_bridge = _.extend({}, e, sd.para.app_js_bridge) : sd.para.use_app_track === !0 || sd.para.app_js_bridge === !0 || sd.para.use_app_track === "only" ? (sd.para.use_app_track_is_send !== !1 && sd.para.use_app_track !== "only" || (e.is_send = !1), sd.para.app_js_bridge = _.extend({}, e)) : sd.para.use_app_track === "mui" && (e.is_mui = !0, sd.para.app_js_bridge = _.extend({}, e)), sd.para.app_js_bridge.is_send === !1 && sd.log("\u8BBE\u7F6E\u4E86 is_send:false,\u5982\u679C\u6253\u901A\u5931\u8D25\uFF0C\u6570\u636E\u5C06\u88AB\u4E22\u5F03\uFF01")
    },
    initState: function() {
        function e(a) {
            function i(v) {
                var w = {
                    hostname: "",
                    project: ""
                };
                try {
                    w.hostname = _.URL(v).hostname, w.project = _.URL(v).searchParams.get("project") || "default"
                } catch (t) {
                    sd.log(t)
                }
                return w
            }
            var d = i(a),
                p = i(sd.para.server_url);
            if (d.hostname === p.hostname && d.project === p.project) return !0;
            if (sd.para.app_js_bridge.white_list.length > 0)
                for (var g = 0; g < sd.para.app_js_bridge.white_list.length; g++) {
                    var y = i(sd.para.app_js_bridge.white_list[g]);
                    if (y.hostname === d.hostname && y.project === d.project) return !0
                }
            return !1
        }
        if (_.isObject(sd.para.app_js_bridge) && !sd.para.app_js_bridge.is_mui) {
            if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.sensorsdataNativeTracker && _.isObject(window.SensorsData_iOS_JS_Bridge) && window.SensorsData_iOS_JS_Bridge.sensorsdata_app_server_url) e(window.SensorsData_iOS_JS_Bridge.sensorsdata_app_server_url) && (sd.bridge.is_verify_success = !0);
            else if (_.isObject(window.SensorsData_APP_New_H5_Bridge) && window.SensorsData_APP_New_H5_Bridge.sensorsdata_get_server_url && window.SensorsData_APP_New_H5_Bridge.sensorsdata_track) {
                var s = window.SensorsData_APP_New_H5_Bridge.sensorsdata_get_server_url();
                s && e(s) && (sd.bridge.is_verify_success = !0)
            }
        }
    },
    initDefineBridgeInfo: function() {
        var e = {
            touch_app_bridge: !0,
            verify_success: !1
        };
        return window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.sensorsdataNativeTracker && window.webkit.messageHandlers.sensorsdataNativeTracker.postMessage && _.isObject(window.SensorsData_iOS_JS_Bridge) && window.SensorsData_iOS_JS_Bridge.sensorsdata_app_server_url || _.isObject(window.SensorsData_APP_New_H5_Bridge) && window.SensorsData_APP_New_H5_Bridge.sensorsdata_get_server_url && window.SensorsData_APP_New_H5_Bridge.sensorsdata_track ? sd.bridge.is_verify_success ? e.verify_success = "success" : e.verify_success = "fail" : typeof SensorsData_APP_JS_Bridge == "object" && (SensorsData_APP_JS_Bridge.sensorsdata_verify && SensorsData_APP_JS_Bridge.sensorsdata_visual_verify || SensorsData_APP_JS_Bridge.sensorsdata_track) ? SensorsData_APP_JS_Bridge.sensorsdata_verify && SensorsData_APP_JS_Bridge.sensorsdata_visual_verify ? SensorsData_APP_JS_Bridge.sensorsdata_visual_verify(JSON.stringify({
            server_url: sd.para.server_url
        })) ? e.verify_success = "success" : e.verify_success = "fail" : e.verify_success = "success" : !/sensors-verify/.test(navigator.userAgent) && !/sa-sdk-ios/.test(navigator.userAgent) || window.MSStream ? e.touch_app_bridge = !1 : sd.bridge.iOS_UA_bridge() ? e.verify_success = "success" : e.verify_success = "fail", e
    },
    iOS_UA_bridge: function() {
        if (/sensors-verify/.test(navigator.userAgent)) {
            var e = navigator.userAgent.match(/sensors-verify\/([^\s]+)/);
            if (e && e[0] && typeof e[1] == "string" && e[1].split("?").length === 2) {
                e = e[1].split("?");
                var s = null,
                    a = null;
                try {
                    s = _.URL(sd.para.server_url).hostname, a = _.URL(sd.para.server_url).searchParams.get("project") || "default"
                } catch (i) {
                    sd.log(i)
                }
                return !(!s || s !== e[0] || !a || a !== e[1])
            }
            return !1
        }
        return !!/sa-sdk-ios/.test(navigator.userAgent)
    },
    dataSend: function(e, s, a) {
        if (_.isObject(sd.para.app_js_bridge) && !sd.para.app_js_bridge.is_mui)
            if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.sensorsdataNativeTracker && window.webkit.messageHandlers.sensorsdataNativeTracker.postMessage && _.isObject(window.SensorsData_iOS_JS_Bridge) && window.SensorsData_iOS_JS_Bridge.sensorsdata_app_server_url) sd.bridge.is_verify_success ? (window.webkit.messageHandlers.sensorsdataNativeTracker.postMessage(JSON.stringify({
                callType: "app_h5_track",
                data: _.extend({
                    server_url: sd.para.server_url
                }, e)
            })), typeof a == "function" && a()) : sd.para.app_js_bridge.is_send ? (sd.debug.apph5({
                data: e,
                step: "4.1",
                output: "all"
            }), s.prepareServerUrl()) : typeof a == "function" && a();
            else if (_.isObject(window.SensorsData_APP_New_H5_Bridge) && window.SensorsData_APP_New_H5_Bridge.sensorsdata_get_server_url && window.SensorsData_APP_New_H5_Bridge.sensorsdata_track) sd.bridge.is_verify_success ? (SensorsData_APP_New_H5_Bridge.sensorsdata_track(JSON.stringify(_.extend({
            server_url: sd.para.server_url
        }, e))), typeof a == "function" && a()) : sd.para.app_js_bridge.is_send ? (sd.debug.apph5({
            data: e,
            step: "4.2",
            output: "all"
        }), s.prepareServerUrl()) : typeof a == "function" && a();
        else if (typeof SensorsData_APP_JS_Bridge == "object" && (SensorsData_APP_JS_Bridge.sensorsdata_verify || SensorsData_APP_JS_Bridge.sensorsdata_track)) SensorsData_APP_JS_Bridge.sensorsdata_verify ? SensorsData_APP_JS_Bridge.sensorsdata_verify(JSON.stringify(_.extend({
            server_url: sd.para.server_url
        }, e))) ? typeof a == "function" && a() : sd.para.app_js_bridge.is_send ? (sd.debug.apph5({
            data: e,
            step: "3.1",
            output: "all"
        }), s.prepareServerUrl()) : typeof a == "function" && a() : (SensorsData_APP_JS_Bridge.sensorsdata_track(JSON.stringify(_.extend({
            server_url: sd.para.server_url
        }, e))), typeof a == "function" && a());
        else if (!/sensors-verify/.test(navigator.userAgent) && !/sa-sdk-ios/.test(navigator.userAgent) || window.MSStream) _.isObject(sd.para.app_js_bridge) && sd.para.app_js_bridge.is_send === !0 ? (sd.debug.apph5({
            data: e,
            step: "2",
            output: "all"
        }), s.prepareServerUrl()) : typeof a == "function" && a();
        else {
            var i = null;
            sd.bridge.iOS_UA_bridge() ? ((i = document.createElement("iframe")).setAttribute("src", "sensorsanalytics://trackEvent?event=" + encodeURIComponent(JSON.stringify(_.extend({
                server_url: sd.para.server_url
            }, e)))), document.documentElement.appendChild(i), i.parentNode.removeChild(i), i = null, typeof a == "function" && a()) : sd.para.app_js_bridge.is_send ? (sd.debug.apph5({
                data: e,
                step: "3.2",
                output: "all"
            }), s.prepareServerUrl()) : typeof a == "function" && a()
        } else _.isObject(sd.para.app_js_bridge) && sd.para.app_js_bridge.is_mui ? _.isObject(window.plus) && window.plus.SDAnalytics && window.plus.SDAnalytics.trackH5Event ? (window.plus.SDAnalytics.trackH5Event(data), typeof a == "function" && a()) : _.isObject(sd.para.app_js_bridge) && sd.para.app_js_bridge.is_send === !0 ? s.prepareServerUrl() : typeof a == "function" && a() : (sd.debug.apph5({
            data: e,
            step: "1",
            output: "code"
        }), s.prepareServerUrl())
    },
    app_js_bridge_v1: function() {
        var e = null,
            s = null;
        window.sensorsdata_app_js_bridge_call_js = function(a) {
            (function(i) {
                e = i, _.isJSONString(e) && (e = JSON.parse(e)), s && (s(e), s = null, e = null)
            })(a)
        }, sd.getAppStatus = function(a) {
            if (function() {
                    if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
                        var i = document.createElement("iframe");
                        i.setAttribute("src", "sensorsanalytics://getAppInfo"), document.documentElement.appendChild(i), i.parentNode.removeChild(i), i = null
                    }
                }(), typeof window.SensorsData_APP_JS_Bridge == "object" && window.SensorsData_APP_JS_Bridge.sensorsdata_call_app && (e = SensorsData_APP_JS_Bridge.sensorsdata_call_app(), _.isJSONString(e) && (e = JSON.parse(e))), !a) return e;
            e === null ? s = a : (a(e), e = null)
        }
    }
};
var heatmap = sd.heatmap = {
    setNotice: function(e) {
        sd.is_heatmap_render_mode = !0, sd.para.heatmap || (sd.errorMsg = "\u60A8SDK\u6CA1\u6709\u914D\u7F6E\u5F00\u542F\u70B9\u51FB\u56FE\uFF0C\u53EF\u80FD\u6CA1\u6709\u6570\u636E\uFF01"), e && e[0] && e[1] && e[1].slice(0, 5) === "http:" && location.protocol === "https:" && (sd.errorMsg = "\u60A8\u7684\u5F53\u524D\u9875\u9762\u662Fhttps\u7684\u5730\u5740\uFF0C\u795E\u7B56\u5206\u6790\u73AF\u5883\u4E5F\u5FC5\u987B\u662Fhttps\uFF01"), sd.para.heatmap_url || (sd.para.heatmap_url = location.protocol + "//static.sensorsdata.cn/sdk/" + sd.lib_version + "/heatmap.min.js")
    },
    getDomIndex: function(e) {
        if (!e.parentNode) return -1;
        for (var s = 0, a = e.tagName, i = e.parentNode.children, d = 0; d < i.length; d++)
            if (i[d].tagName === a) {
                if (e === i[d]) return s;
                s++
            }
        return -1
    },
    selector: function(e) {
        var s = e.parentNode && e.parentNode.nodeType == 9 ? -1 : this.getDomIndex(e);
        return e.getAttribute && e.getAttribute("id") && (!sd.para.heatmap || sd.para.heatmap && sd.para.heatmap.element_selector !== "not_use_id") ? "#" + e.getAttribute("id") : e.tagName.toLowerCase() + (~s ? ":nth-of-type(" + (s + 1) + ")" : "")
    },
    getDomSelector: function(e, s) {
        if (!e || !e.parentNode || !e.parentNode.children) return !1;
        s = s && s.join ? s : [];
        var a = e.nodeName.toLowerCase();
        return e && a !== "body" && e.nodeType == 1 ? (s.unshift(this.selector(e)), e.getAttribute && e.getAttribute("id") && sd.para.heatmap && sd.para.heatmap.element_selector !== "not_use_id" ? s.join(" > ") : this.getDomSelector(e.parentNode, s)) : (s.unshift("body"), s.join(" > "))
    },
    na: function() {
        var e = document.documentElement.scrollLeft || window.pageXOffset;
        return parseInt(isNaN(e) ? 0 : e, 10)
    },
    i: function() {
        var e = 0;
        try {
            e = o.documentElement && o.documentElement.scrollTop || m.pageYOffset, e = isNaN(e) ? 0 : e
        } catch (s) {
            e = 0
        }
        return parseInt(e, 10)
    },
    getBrowserWidth: function() {
        var e = window.innerWidth || document.body.clientWidth;
        return isNaN(e) ? 0 : parseInt(e, 10)
    },
    getBrowserHeight: function() {
        var e = window.innerHeight || document.body.clientHeight;
        return isNaN(e) ? 0 : parseInt(e, 10)
    },
    getScrollWidth: function() {
        var e = parseInt(document.body.scrollWidth, 10);
        return isNaN(e) ? 0 : e
    },
    W: function(e) {
        var s = parseInt(+e.clientX + +this.na(), 10);
        return e = parseInt(+e.clientY + +this.i(), 10), {
            x: isNaN(s) ? 0 : s,
            y: isNaN(e) ? 0 : e
        }
    },
    start: function(e, s, a, i, d) {
        var p = _.isObject(i) ? i : {},
            g = _.isFunction(d) ? d : _.isFunction(i) ? i : void 0;
        if (sd.para.heatmap && sd.para.heatmap.collect_element && !sd.para.heatmap.collect_element(s)) return !1;
        var y = this.getDomSelector(s),
            v = _.getEleInfo({
                target: s
            });
        if (v.$element_selector = y || "", sd.para.heatmap && sd.para.heatmap.custom_property) {
            var w = sd.para.heatmap.custom_property(s);
            _.isObject(w) && (v = _.extend(v, w))
        }
        v = _.extend(v, p), a === "a" && sd.para.heatmap && sd.para.heatmap.isTrackLink === !0 ? _.trackLink({
            event: e,
            target: s
        }, "$WebClick", v) : sd.track("$WebClick", v, g)
    },
    hasElement: function(e) {
        var s = e._getPath();
        if (_.isArray(s) && s.length > 0) {
            for (var a = 0; a < s.length; a++)
                if (s[a] && s[a].tagName && s[a].tagName.toLowerCase() === "a") return s[a]
        }
        return !1
    },
    initScrollmap: function() {
        if (!_.isObject(sd.para.heatmap) || sd.para.heatmap.scroll_notice_map !== "default") return !1;
        var e = function() {
                return !(sd.para.scrollmap && _.isFunction(sd.para.scrollmap.collect_url) && !sd.para.scrollmap.collect_url())
            },
            s = function(a) {
                var i = {};
                return i.timeout = a.timeout || 1e3, i.func = a.func, i.hasInit = !1, i.inter = null, i.main = function(d, p) {
                    this.func(d, p), this.inter = null
                }, i.go = function(d) {
                    var p = {};
                    this.inter || (p.$viewport_position = document.documentElement && document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop || 0, p.$viewport_position = Math.round(p.$viewport_position) || 0, p.$viewport_height = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight || 0, p.$viewport_width = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth || 0, d ? i.main(p, !0) : this.inter = setTimeout(function() {
                        i.main(p)
                    }, this.timeout))
                }, i
            }({
                timeout: 1e3,
                func: function(a, i) {
                    var d = document.documentElement && document.documentElement.scrollTop || window.pageYOffset || document.body.scrollTop || 0,
                        p = new Date,
                        g = p - this.current_time;
                    (g > sd.para.heatmap.scroll_delay_time && d - a.$viewport_position != 0 || i) && (a.$url = location.href, a.$title = document.title, a.$url_path = location.pathname, a.event_duration = Math.min(sd.para.heatmap.scroll_event_duration, parseInt(g) / 1e3), sd.track("$WebStay", a)), this.current_time = p
                }
            });
        s.current_time = new Date, _.addEvent(window, "scroll", function() {
            if (!e()) return !1;
            s.go()
        }), _.addEvent(window, "unload", function() {
            if (!e()) return !1;
            s.go("notime")
        })
    },
    initHeatmap: function() {
        var e = this;
        return !(!_.isObject(sd.para.heatmap) || sd.para.heatmap.clickmap !== "default") && !(_.isFunction(sd.para.heatmap.collect_url) && !sd.para.heatmap.collect_url()) && (sd.para.heatmap.collect_elements === "all" ? sd.para.heatmap.collect_elements = "all" : sd.para.heatmap.collect_elements = "interact", void(sd.para.heatmap.collect_elements === "all" ? _.addEvent(document, "click", function(s) {
            var a = s || window.event;
            if (!a) return !1;
            var i = a.target || a.srcElement;
            if (typeof i != "object" || typeof i.tagName != "string") return !1;
            var d = i.tagName.toLowerCase();
            if (d === "body" || d === "html" || !i || !i.parentNode || !i.parentNode.children) return !1;
            var p = i.parentNode.tagName.toLowerCase();
            p === "a" || p === "button" ? e.start(a, i.parentNode, p) : e.start(a, i, d)
        }) : _.addEvent(document, "click", function(s) {
            var a = s || window.event;
            if (!a) return !1;
            var i = a.target || a.srcElement;
            if (typeof i != "object" || typeof i.tagName != "string") return !1;
            var d = i.tagName.toLowerCase();
            if (d.toLowerCase() === "body" || d.toLowerCase() === "html" || !i || !i.parentNode || !i.parentNode.children) return !1;
            var p = i.parentNode;
            if (d === "a" || d === "button" || d === "input" || d === "textarea" || _.hasAttribute(i, "data-sensors-click")) e.start(a, i, d);
            else if (p.tagName.toLowerCase() === "button" || p.tagName.toLowerCase() === "a") e.start(a, p, i.parentNode.tagName.toLowerCase());
            else if (d === "area" && p.tagName.toLowerCase() === "map" && _.ry(p).prev().tagName && _.ry(p).prev().tagName.toLowerCase() === "img") e.start(a, _.ry(p).prev(), _.ry(p).prev().tagName.toLowerCase());
            else {
                var g = e.hasElement(s);
                g && e.start(a, g, g.tagName.toLowerCase())
            }
        })))
    }
};
sd.init = function(e) {
    if (sd.readyState && sd.readyState.state && sd.readyState.state >= 2) return !1;
    sd.setInitVar(), sd.readyState.setState(2), sd.initPara(e), sd.detectMode()
};
var methods = ["track", "quick", "register", "registerPage", "registerOnce", "trackSignup", "setProfile", "setOnceProfile", "appendProfile", "incrementProfile", "deleteProfile", "unsetProfile", "identify", "login", "logout", "trackLink", "clearAllRegister"];
_.each(methods, function(e) {
    var s = sd[e];
    sd[e] = function() {
        if (sd.readyState.state < 3) return _.isArray(sd._q) || (sd._q = []), sd._q.push([e, arguments]), !1;
        if (sd.readyState.getState()) return s.apply(sd, arguments);
        try {
            console.error("\u8BF7\u5148\u521D\u59CB\u5316\u795E\u7B56JS SDK")
        } catch (a) {
            sd.log(a)
        }
    }
}), typeof window.sensorsDataAnalytic201505 == "string" ? (sd.setPreConfig(window[sensorsDataAnalytic201505]), window[sensorsDataAnalytic201505] = sd, window.sensorsDataAnalytic201505 = sd, sd.init()) : window.sensorsDataAnalytic201505 === void 0 ? window.sensorsDataAnalytic201505 = sd : sd = window.sensorsDataAnalytic201505;
var sd$1 = sd;
export {
    sd$1 as
    default
};
import {
    aM as Y,
    bz as ca,
    aN as Al,
    cR as ha
} from "./index.28e31dff.js";
import {
    b as Xr
} from "./index.21cf2e94.js";
import {
    d as da
} from "./output.d512c61c.js";
import "./metamaskSupport.1f1c5eb7.js";
import "./Starting.25c670fc.js";
import "./DepositBonus.c3043053.js";
import "./index.65a85ef1.js";
import "./Status.3214655e.js";
var us = {},
    St = {},
    nt = {},
    ur = {},
    it = {},
    lr = {};
const kl = 4,
    Wa = 0,
    Za = 1,
    Tl = 2;

function fr(e) {
    let t = e.length;
    for (; --t >= 0;) e[t] = 0
}
const zl = 0,
    ls = 1,
    Rl = 2,
    Ol = 3,
    Dl = 258,
    pa = 29,
    Qr = 256,
    Wr = Qr + 1 + pa,
    er = 30,
    _a = 19,
    fs = 2 * Wr + 1,
    Ct = 15,
    yi = 16,
    Pl = 7,
    va = 256,
    cs = 16,
    hs = 17,
    ds = 18,
    Gi = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]),
    Tn = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]),
    Cl = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]),
    ps = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]),
    Nl = 512,
    st = new Array((Wr + 2) * 2);
fr(st);
const Ur = new Array(er * 2);
fr(Ur);
const Zr = new Array(Nl);
fr(Zr);
const qr = new Array(Dl - Ol + 1);
fr(qr);
const ya = new Array(pa);
fr(ya);
const Nn = new Array(er);
fr(Nn);

function bi(e, t, r, n, i) {
    this.static_tree = e, this.extra_bits = t, this.extra_base = r, this.elems = n, this.max_length = i, this.has_stree = e && e.length
}
let _s, vs, ys;

function gi(e, t) {
    this.dyn_tree = e, this.max_code = 0, this.stat_desc = t
}
const bs = e => e < 256 ? Zr[e] : Zr[256 + (e >>> 7)],
    jr = (e, t) => {
        e.pending_buf[e.pending++] = t & 255, e.pending_buf[e.pending++] = t >>> 8 & 255
    },
    Te = (e, t, r) => {
        e.bi_valid > yi - r ? (e.bi_buf |= t << e.bi_valid & 65535, jr(e, e.bi_buf), e.bi_buf = t >> yi - e.bi_valid, e.bi_valid += r - yi) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += r)
    },
    Ge = (e, t, r) => {
        Te(e, r[t * 2], r[t * 2 + 1])
    },
    gs = (e, t) => {
        let r = 0;
        do r |= e & 1, e >>>= 1, r <<= 1; while (--t > 0);
        return r >>> 1
    },
    Ll = e => {
        e.bi_valid === 16 ? (jr(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = e.bi_buf & 255, e.bi_buf >>= 8, e.bi_valid -= 8)
    },
    Il = (e, t) => {
        const r = t.dyn_tree,
            n = t.max_code,
            i = t.stat_desc.static_tree,
            a = t.stat_desc.has_stree,
            o = t.stat_desc.extra_bits,
            s = t.stat_desc.extra_base,
            c = t.stat_desc.max_length;
        let u, f, b, _, v, g, k = 0;
        for (_ = 0; _ <= Ct; _++) e.bl_count[_] = 0;
        for (r[e.heap[e.heap_max] * 2 + 1] = 0, u = e.heap_max + 1; u < fs; u++) f = e.heap[u], _ = r[r[f * 2 + 1] * 2 + 1] + 1, _ > c && (_ = c, k++), r[f * 2 + 1] = _, !(f > n) && (e.bl_count[_]++, v = 0, f >= s && (v = o[f - s]), g = r[f * 2], e.opt_len += g * (_ + v), a && (e.static_len += g * (i[f * 2 + 1] + v)));
        if (k !== 0) {
            do {
                for (_ = c - 1; e.bl_count[_] === 0;) _--;
                e.bl_count[_]--, e.bl_count[_ + 1] += 2, e.bl_count[c]--, k -= 2
            } while (k > 0);
            for (_ = c; _ !== 0; _--)
                for (f = e.bl_count[_]; f !== 0;) b = e.heap[--u], !(b > n) && (r[b * 2 + 1] !== _ && (e.opt_len += (_ - r[b * 2 + 1]) * r[b * 2], r[b * 2 + 1] = _), f--)
        }
    },
    ws = (e, t, r) => {
        const n = new Array(Ct + 1);
        let i = 0,
            a, o;
        for (a = 1; a <= Ct; a++) n[a] = i = i + r[a - 1] << 1;
        for (o = 0; o <= t; o++) {
            let s = e[o * 2 + 1];
            s !== 0 && (e[o * 2] = gs(n[s]++, s))
        }
    },
    Bl = () => {
        let e, t, r, n, i;
        const a = new Array(Ct + 1);
        for (r = 0, n = 0; n < pa - 1; n++)
            for (ya[n] = r, e = 0; e < 1 << Gi[n]; e++) qr[r++] = n;
        for (qr[r - 1] = n, i = 0, n = 0; n < 16; n++)
            for (Nn[n] = i, e = 0; e < 1 << Tn[n]; e++) Zr[i++] = n;
        for (i >>= 7; n < er; n++)
            for (Nn[n] = i << 7, e = 0; e < 1 << Tn[n] - 7; e++) Zr[256 + i++] = n;
        for (t = 0; t <= Ct; t++) a[t] = 0;
        for (e = 0; e <= 143;) st[e * 2 + 1] = 8, e++, a[8]++;
        for (; e <= 255;) st[e * 2 + 1] = 9, e++, a[9]++;
        for (; e <= 279;) st[e * 2 + 1] = 7, e++, a[7]++;
        for (; e <= 287;) st[e * 2 + 1] = 8, e++, a[8]++;
        for (ws(st, Wr + 1, a), e = 0; e < er; e++) Ur[e * 2 + 1] = 5, Ur[e * 2] = gs(e, 5);
        _s = new bi(st, Gi, Qr + 1, Wr, Ct), vs = new bi(Ur, Tn, 0, er, Ct), ys = new bi(new Array(0), Cl, 0, _a, Pl)
    },
    xs = e => {
        let t;
        for (t = 0; t < Wr; t++) e.dyn_ltree[t * 2] = 0;
        for (t = 0; t < er; t++) e.dyn_dtree[t * 2] = 0;
        for (t = 0; t < _a; t++) e.bl_tree[t * 2] = 0;
        e.dyn_ltree[va * 2] = 1, e.opt_len = e.static_len = 0, e.last_lit = e.matches = 0
    },
    ms = e => {
        e.bi_valid > 8 ? jr(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf), e.bi_buf = 0, e.bi_valid = 0
    },
    Ml = (e, t, r, n) => {
        ms(e), n && (jr(e, r), jr(e, ~r)), e.pending_buf.set(e.window.subarray(t, t + r), e.pending), e.pending += r
    },
    qa = (e, t, r, n) => {
        const i = t * 2,
            a = r * 2;
        return e[i] < e[a] || e[i] === e[a] && n[t] <= n[r]
    },
    wi = (e, t, r) => {
        const n = e.heap[r];
        let i = r << 1;
        for (; i <= e.heap_len && (i < e.heap_len && qa(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !qa(t, n, e.heap[i], e.depth));) e.heap[r] = e.heap[i], r = i, i <<= 1;
        e.heap[r] = n
    },
    ja = (e, t, r) => {
        let n, i, a = 0,
            o, s;
        if (e.last_lit !== 0)
            do n = e.pending_buf[e.d_buf + a * 2] << 8 | e.pending_buf[e.d_buf + a * 2 + 1], i = e.pending_buf[e.l_buf + a], a++, n === 0 ? Ge(e, i, t) : (o = qr[i], Ge(e, o + Qr + 1, t), s = Gi[o], s !== 0 && (i -= ya[o], Te(e, i, s)), n--, o = bs(n), Ge(e, o, r), s = Tn[o], s !== 0 && (n -= Nn[o], Te(e, n, s))); while (a < e.last_lit);
        Ge(e, va, t)
    },
    Vi = (e, t) => {
        const r = t.dyn_tree,
            n = t.stat_desc.static_tree,
            i = t.stat_desc.has_stree,
            a = t.stat_desc.elems;
        let o, s, c = -1,
            u;
        for (e.heap_len = 0, e.heap_max = fs, o = 0; o < a; o++) r[o * 2] !== 0 ? (e.heap[++e.heap_len] = c = o, e.depth[o] = 0) : r[o * 2 + 1] = 0;
        for (; e.heap_len < 2;) u = e.heap[++e.heap_len] = c < 2 ? ++c : 0, r[u * 2] = 1, e.depth[u] = 0, e.opt_len--, i && (e.static_len -= n[u * 2 + 1]);
        for (t.max_code = c, o = e.heap_len >> 1; o >= 1; o--) wi(e, r, o);
        u = a;
        do o = e.heap[1], e.heap[1] = e.heap[e.heap_len--], wi(e, r, 1), s = e.heap[1], e.heap[--e.heap_max] = o, e.heap[--e.heap_max] = s, r[u * 2] = r[o * 2] + r[s * 2], e.depth[u] = (e.depth[o] >= e.depth[s] ? e.depth[o] : e.depth[s]) + 1, r[o * 2 + 1] = r[s * 2 + 1] = u, e.heap[1] = u++, wi(e, r, 1); while (e.heap_len >= 2);
        e.heap[--e.heap_max] = e.heap[1], Il(e, t), ws(r, c, e.bl_count)
    },
    Ga = (e, t, r) => {
        let n, i = -1,
            a, o = t[0 * 2 + 1],
            s = 0,
            c = 7,
            u = 4;
        for (o === 0 && (c = 138, u = 3), t[(r + 1) * 2 + 1] = 65535, n = 0; n <= r; n++) a = o, o = t[(n + 1) * 2 + 1], !(++s < c && a === o) && (s < u ? e.bl_tree[a * 2] += s : a !== 0 ? (a !== i && e.bl_tree[a * 2]++, e.bl_tree[cs * 2]++) : s <= 10 ? e.bl_tree[hs * 2]++ : e.bl_tree[ds * 2]++, s = 0, i = a, o === 0 ? (c = 138, u = 3) : a === o ? (c = 6, u = 3) : (c = 7, u = 4))
    },
    Va = (e, t, r) => {
        let n, i = -1,
            a, o = t[0 * 2 + 1],
            s = 0,
            c = 7,
            u = 4;
        for (o === 0 && (c = 138, u = 3), n = 0; n <= r; n++)
            if (a = o, o = t[(n + 1) * 2 + 1], !(++s < c && a === o)) {
                if (s < u)
                    do Ge(e, a, e.bl_tree); while (--s !== 0);
                else a !== 0 ? (a !== i && (Ge(e, a, e.bl_tree), s--), Ge(e, cs, e.bl_tree), Te(e, s - 3, 2)) : s <= 10 ? (Ge(e, hs, e.bl_tree), Te(e, s - 3, 3)) : (Ge(e, ds, e.bl_tree), Te(e, s - 11, 7));
                s = 0, i = a, o === 0 ? (c = 138, u = 3) : a === o ? (c = 6, u = 3) : (c = 7, u = 4)
            }
    },
    Ul = e => {
        let t;
        for (Ga(e, e.dyn_ltree, e.l_desc.max_code), Ga(e, e.dyn_dtree, e.d_desc.max_code), Vi(e, e.bl_desc), t = _a - 1; t >= 3 && e.bl_tree[ps[t] * 2 + 1] === 0; t--);
        return e.opt_len += 3 * (t + 1) + 5 + 5 + 4, t
    },
    $l = (e, t, r, n) => {
        let i;
        for (Te(e, t - 257, 5), Te(e, r - 1, 5), Te(e, n - 4, 4), i = 0; i < n; i++) Te(e, e.bl_tree[ps[i] * 2 + 1], 3);
        Va(e, e.dyn_ltree, t - 1), Va(e, e.dyn_dtree, r - 1)
    },
    Fl = e => {
        let t = 4093624447,
            r;
        for (r = 0; r <= 31; r++, t >>>= 1)
            if (t & 1 && e.dyn_ltree[r * 2] !== 0) return Wa;
        if (e.dyn_ltree[9 * 2] !== 0 || e.dyn_ltree[10 * 2] !== 0 || e.dyn_ltree[13 * 2] !== 0) return Za;
        for (r = 32; r < Qr; r++)
            if (e.dyn_ltree[r * 2] !== 0) return Za;
        return Wa
    };
let Ya = !1;
const Hl = e => {
        Ya || (Bl(), Ya = !0), e.l_desc = new gi(e.dyn_ltree, _s), e.d_desc = new gi(e.dyn_dtree, vs), e.bl_desc = new gi(e.bl_tree, ys), e.bi_buf = 0, e.bi_valid = 0, xs(e)
    },
    Es = (e, t, r, n) => {
        Te(e, (zl << 1) + (n ? 1 : 0), 3), Ml(e, t, r, !0)
    },
    Kl = e => {
        Te(e, ls << 1, 3), Ge(e, va, st), Ll(e)
    },
    Wl = (e, t, r, n) => {
        let i, a, o = 0;
        e.level > 0 ? (e.strm.data_type === Tl && (e.strm.data_type = Fl(e)), Vi(e, e.l_desc), Vi(e, e.d_desc), o = Ul(e), i = e.opt_len + 3 + 7 >>> 3, a = e.static_len + 3 + 7 >>> 3, a <= i && (i = a)) : i = a = r + 5, r + 4 <= i && t !== -1 ? Es(e, t, r, n) : e.strategy === kl || a === i ? (Te(e, (ls << 1) + (n ? 1 : 0), 3), ja(e, st, Ur)) : (Te(e, (Rl << 1) + (n ? 1 : 0), 3), $l(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), ja(e, e.dyn_ltree, e.dyn_dtree)), xs(e), n && ms(e)
    },
    Zl = (e, t, r) => (e.pending_buf[e.d_buf + e.last_lit * 2] = t >>> 8 & 255, e.pending_buf[e.d_buf + e.last_lit * 2 + 1] = t & 255, e.pending_buf[e.l_buf + e.last_lit] = r & 255, e.last_lit++, t === 0 ? e.dyn_ltree[r * 2]++ : (e.matches++, t--, e.dyn_ltree[(qr[r] + Qr + 1) * 2]++, e.dyn_dtree[bs(t) * 2]++), e.last_lit === e.lit_bufsize - 1);
lr._tr_init = Hl;
lr._tr_stored_block = Es;
lr._tr_flush_block = Wl;
lr._tr_tally = Zl;
lr._tr_align = Kl;
const ql = (e, t, r, n) => {
    let i = e & 65535 | 0,
        a = e >>> 16 & 65535 | 0,
        o = 0;
    for (; r !== 0;) {
        o = r > 2e3 ? 2e3 : r, r -= o;
        do i = i + t[n++] | 0, a = a + i | 0; while (--o);
        i %= 65521, a %= 65521
    }
    return i | a << 16 | 0
};
var Ss = ql;
const jl = () => {
        let e, t = [];
        for (var r = 0; r < 256; r++) {
            e = r;
            for (var n = 0; n < 8; n++) e = e & 1 ? 3988292384 ^ e >>> 1 : e >>> 1;
            t[r] = e
        }
        return t
    },
    Gl = new Uint32Array(jl()),
    Vl = (e, t, r, n) => {
        const i = Gl,
            a = n + r;
        e ^= -1;
        for (let o = n; o < a; o++) e = e >>> 8 ^ i[(e ^ t[o]) & 255];
        return e ^ -1
    };
var As = Vl,
    ba = {
        2: "need dictionary",
        1: "stream end",
        0: "",
        "-1": "file error",
        "-2": "stream error",
        "-3": "data error",
        "-4": "insufficient memory",
        "-5": "buffer error",
        "-6": "incompatible version"
    },
    Ht = {
        Z_NO_FLUSH: 0,
        Z_PARTIAL_FLUSH: 1,
        Z_SYNC_FLUSH: 2,
        Z_FULL_FLUSH: 3,
        Z_FINISH: 4,
        Z_BLOCK: 5,
        Z_TREES: 6,
        Z_OK: 0,
        Z_STREAM_END: 1,
        Z_NEED_DICT: 2,
        Z_ERRNO: -1,
        Z_STREAM_ERROR: -2,
        Z_DATA_ERROR: -3,
        Z_MEM_ERROR: -4,
        Z_BUF_ERROR: -5,
        Z_NO_COMPRESSION: 0,
        Z_BEST_SPEED: 1,
        Z_BEST_COMPRESSION: 9,
        Z_DEFAULT_COMPRESSION: -1,
        Z_FILTERED: 1,
        Z_HUFFMAN_ONLY: 2,
        Z_RLE: 3,
        Z_FIXED: 4,
        Z_DEFAULT_STRATEGY: 0,
        Z_BINARY: 0,
        Z_TEXT: 1,
        Z_UNKNOWN: 2,
        Z_DEFLATED: 8
    };
const {
    _tr_init: Yl,
    _tr_stored_block: Jl,
    _tr_flush_block: Xl,
    _tr_tally: At,
    _tr_align: Ql
} = lr, ks = Ss, vt = As, ef = ba, {
    Z_NO_FLUSH: Kt,
    Z_PARTIAL_FLUSH: tf,
    Z_FULL_FLUSH: rf,
    Z_FINISH: kt,
    Z_BLOCK: Ja,
    Z_OK: Ve,
    Z_STREAM_END: Xa,
    Z_STREAM_ERROR: Pe,
    Z_DATA_ERROR: nf,
    Z_BUF_ERROR: xi,
    Z_DEFAULT_COMPRESSION: af,
    Z_FILTERED: of ,
    Z_HUFFMAN_ONLY: gn,
    Z_RLE: sf,
    Z_FIXED: uf,
    Z_DEFAULT_STRATEGY: lf,
    Z_UNKNOWN: ff,
    Z_DEFLATED: $n
} = Ht, cf = 9, hf = 15, df = 8, pf = 29, _f = 256, Yi = _f + 1 + pf, vf = 30, yf = 19, bf = 2 * Yi + 1, gf = 15, se = 3, xt = 258, Fe = xt + se + 1, wf = 32, Fn = 42, Ji = 69, zn = 73, Rn = 91, On = 103, Nt = 113, Ir = 666, ge = 1, en = 2, Bt = 3, cr = 4, xf = 3, mt = (e, t) => (e.msg = ef[t], t), Qa = e => (e << 1) - (e > 4 ? 9 : 0), wt = e => {
    let t = e.length;
    for (; --t >= 0;) e[t] = 0
};
let mf = (e, t, r) => (t << e.hash_shift ^ r) & e.hash_mask,
    Tt = mf;
const yt = e => {
        const t = e.state;
        let r = t.pending;
        r > e.avail_out && (r = e.avail_out), r !== 0 && (e.output.set(t.pending_buf.subarray(t.pending_out, t.pending_out + r), e.next_out), e.next_out += r, t.pending_out += r, e.total_out += r, e.avail_out -= r, t.pending -= r, t.pending === 0 && (t.pending_out = 0))
    },
    me = (e, t) => {
        Xl(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t), e.block_start = e.strstart, yt(e.strm)
    },
    le = (e, t) => {
        e.pending_buf[e.pending++] = t
    },
    kr = (e, t) => {
        e.pending_buf[e.pending++] = t >>> 8 & 255, e.pending_buf[e.pending++] = t & 255
    },
    Ef = (e, t, r, n) => {
        let i = e.avail_in;
        return i > n && (i = n), i === 0 ? 0 : (e.avail_in -= i, t.set(e.input.subarray(e.next_in, e.next_in + i), r), e.state.wrap === 1 ? e.adler = ks(e.adler, t, i, r) : e.state.wrap === 2 && (e.adler = vt(e.adler, t, i, r)), e.next_in += i, e.total_in += i, i)
    },
    Ts = (e, t) => {
        let r = e.max_chain_length,
            n = e.strstart,
            i, a, o = e.prev_length,
            s = e.nice_match;
        const c = e.strstart > e.w_size - Fe ? e.strstart - (e.w_size - Fe) : 0,
            u = e.window,
            f = e.w_mask,
            b = e.prev,
            _ = e.strstart + xt;
        let v = u[n + o - 1],
            g = u[n + o];
        e.prev_length >= e.good_match && (r >>= 2), s > e.lookahead && (s = e.lookahead);
        do
            if (i = t, !(u[i + o] !== g || u[i + o - 1] !== v || u[i] !== u[n] || u[++i] !== u[n + 1])) {
                n += 2, i++;
                do; while (u[++n] === u[++i] && u[++n] === u[++i] && u[++n] === u[++i] && u[++n] === u[++i] && u[++n] === u[++i] && u[++n] === u[++i] && u[++n] === u[++i] && u[++n] === u[++i] && n < _);
                if (a = xt - (_ - n), n = _ - xt, a > o) {
                    if (e.match_start = t, o = a, a >= s) break;
                    v = u[n + o - 1], g = u[n + o]
                }
            }
        while ((t = b[t & f]) > c && --r !== 0);
        return o <= e.lookahead ? o : e.lookahead
    },
    Mt = e => {
        const t = e.w_size;
        let r, n, i, a, o;
        do {
            if (a = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - Fe)) {
                e.window.set(e.window.subarray(t, t + t), 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, n = e.hash_size, r = n;
                do i = e.head[--r], e.head[r] = i >= t ? i - t : 0; while (--n);
                n = t, r = n;
                do i = e.prev[--r], e.prev[r] = i >= t ? i - t : 0; while (--n);
                a += t
            }
            if (e.strm.avail_in === 0) break;
            if (n = Ef(e.strm, e.window, e.strstart + e.lookahead, a), e.lookahead += n, e.lookahead + e.insert >= se)
                for (o = e.strstart - e.insert, e.ins_h = e.window[o], e.ins_h = Tt(e, e.ins_h, e.window[o + 1]); e.insert && (e.ins_h = Tt(e, e.ins_h, e.window[o + se - 1]), e.prev[o & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = o, o++, e.insert--, !(e.lookahead + e.insert < se)););
        } while (e.lookahead < Fe && e.strm.avail_in !== 0)
    },
    Sf = (e, t) => {
        let r = 65535;
        for (r > e.pending_buf_size - 5 && (r = e.pending_buf_size - 5);;) {
            if (e.lookahead <= 1) {
                if (Mt(e), e.lookahead === 0 && t === Kt) return ge;
                if (e.lookahead === 0) break
            }
            e.strstart += e.lookahead, e.lookahead = 0;
            const n = e.block_start + r;
            if ((e.strstart === 0 || e.strstart >= n) && (e.lookahead = e.strstart - n, e.strstart = n, me(e, !1), e.strm.avail_out === 0) || e.strstart - e.block_start >= e.w_size - Fe && (me(e, !1), e.strm.avail_out === 0)) return ge
        }
        return e.insert = 0, t === kt ? (me(e, !0), e.strm.avail_out === 0 ? Bt : cr) : (e.strstart > e.block_start && (me(e, !1), e.strm.avail_out === 0), ge)
    },
    mi = (e, t) => {
        let r, n;
        for (;;) {
            if (e.lookahead < Fe) {
                if (Mt(e), e.lookahead < Fe && t === Kt) return ge;
                if (e.lookahead === 0) break
            }
            if (r = 0, e.lookahead >= se && (e.ins_h = Tt(e, e.ins_h, e.window[e.strstart + se - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), r !== 0 && e.strstart - r <= e.w_size - Fe && (e.match_length = Ts(e, r)), e.match_length >= se)
                if (n = At(e, e.strstart - e.match_start, e.match_length - se), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= se) {
                    e.match_length--;
                    do e.strstart++, e.ins_h = Tt(e, e.ins_h, e.window[e.strstart + se - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart; while (--e.match_length !== 0);
                    e.strstart++
                } else e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = Tt(e, e.ins_h, e.window[e.strstart + 1]);
            else n = At(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
            if (n && (me(e, !1), e.strm.avail_out === 0)) return ge
        }
        return e.insert = e.strstart < se - 1 ? e.strstart : se - 1, t === kt ? (me(e, !0), e.strm.avail_out === 0 ? Bt : cr) : e.last_lit && (me(e, !1), e.strm.avail_out === 0) ? ge : en
    },
    Yt = (e, t) => {
        let r, n, i;
        for (;;) {
            if (e.lookahead < Fe) {
                if (Mt(e), e.lookahead < Fe && t === Kt) return ge;
                if (e.lookahead === 0) break
            }
            if (r = 0, e.lookahead >= se && (e.ins_h = Tt(e, e.ins_h, e.window[e.strstart + se - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = se - 1, r !== 0 && e.prev_length < e.max_lazy_match && e.strstart - r <= e.w_size - Fe && (e.match_length = Ts(e, r), e.match_length <= 5 && (e.strategy === of || e.match_length === se && e.strstart - e.match_start > 4096) && (e.match_length = se - 1)), e.prev_length >= se && e.match_length <= e.prev_length) {
                i = e.strstart + e.lookahead - se, n = At(e, e.strstart - 1 - e.prev_match, e.prev_length - se), e.lookahead -= e.prev_length - 1, e.prev_length -= 2;
                do ++e.strstart <= i && (e.ins_h = Tt(e, e.ins_h, e.window[e.strstart + se - 1]), r = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart); while (--e.prev_length !== 0);
                if (e.match_available = 0, e.match_length = se - 1, e.strstart++, n && (me(e, !1), e.strm.avail_out === 0)) return ge
            } else if (e.match_available) {
                if (n = At(e, 0, e.window[e.strstart - 1]), n && me(e, !1), e.strstart++, e.lookahead--, e.strm.avail_out === 0) return ge
            } else e.match_available = 1, e.strstart++, e.lookahead--
        }
        return e.match_available && (n = At(e, 0, e.window[e.strstart - 1]), e.match_available = 0), e.insert = e.strstart < se - 1 ? e.strstart : se - 1, t === kt ? (me(e, !0), e.strm.avail_out === 0 ? Bt : cr) : e.last_lit && (me(e, !1), e.strm.avail_out === 0) ? ge : en
    },
    Af = (e, t) => {
        let r, n, i, a;
        const o = e.window;
        for (;;) {
            if (e.lookahead <= xt) {
                if (Mt(e), e.lookahead <= xt && t === Kt) return ge;
                if (e.lookahead === 0) break
            }
            if (e.match_length = 0, e.lookahead >= se && e.strstart > 0 && (i = e.strstart - 1, n = o[i], n === o[++i] && n === o[++i] && n === o[++i])) {
                a = e.strstart + xt;
                do; while (n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && i < a);
                e.match_length = xt - (a - i), e.match_length > e.lookahead && (e.match_length = e.lookahead)
            }
            if (e.match_length >= se ? (r = At(e, 1, e.match_length - se), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (r = At(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), r && (me(e, !1), e.strm.avail_out === 0)) return ge
        }
        return e.insert = 0, t === kt ? (me(e, !0), e.strm.avail_out === 0 ? Bt : cr) : e.last_lit && (me(e, !1), e.strm.avail_out === 0) ? ge : en
    },
    kf = (e, t) => {
        let r;
        for (;;) {
            if (e.lookahead === 0 && (Mt(e), e.lookahead === 0)) {
                if (t === Kt) return ge;
                break
            }
            if (e.match_length = 0, r = At(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, r && (me(e, !1), e.strm.avail_out === 0)) return ge
        }
        return e.insert = 0, t === kt ? (me(e, !0), e.strm.avail_out === 0 ? Bt : cr) : e.last_lit && (me(e, !1), e.strm.avail_out === 0) ? ge : en
    };

function qe(e, t, r, n, i) {
    this.good_length = e, this.max_lazy = t, this.nice_length = r, this.max_chain = n, this.func = i
}
const Br = [new qe(0, 0, 0, 0, Sf), new qe(4, 4, 8, 4, mi), new qe(4, 5, 16, 8, mi), new qe(4, 6, 32, 32, mi), new qe(4, 4, 16, 16, Yt), new qe(8, 16, 32, 32, Yt), new qe(8, 16, 128, 128, Yt), new qe(8, 32, 128, 256, Yt), new qe(32, 128, 258, 1024, Yt), new qe(32, 258, 258, 4096, Yt)],
    Tf = e => {
        e.window_size = 2 * e.w_size, wt(e.head), e.max_lazy_match = Br[e.level].max_lazy, e.good_match = Br[e.level].good_length, e.nice_match = Br[e.level].nice_length, e.max_chain_length = Br[e.level].max_chain, e.strstart = 0, e.block_start = 0, e.lookahead = 0, e.insert = 0, e.match_length = e.prev_length = se - 1, e.match_available = 0, e.ins_h = 0
    };

function zf() {
    this.strm = null, this.status = 0, this.pending_buf = null, this.pending_buf_size = 0, this.pending_out = 0, this.pending = 0, this.wrap = 0, this.gzhead = null, this.gzindex = 0, this.method = $n, this.last_flush = -1, this.w_size = 0, this.w_bits = 0, this.w_mask = 0, this.window = null, this.window_size = 0, this.prev = null, this.head = null, this.ins_h = 0, this.hash_size = 0, this.hash_bits = 0, this.hash_mask = 0, this.hash_shift = 0, this.block_start = 0, this.match_length = 0, this.prev_match = 0, this.match_available = 0, this.strstart = 0, this.match_start = 0, this.lookahead = 0, this.prev_length = 0, this.max_chain_length = 0, this.max_lazy_match = 0, this.level = 0, this.strategy = 0, this.good_match = 0, this.nice_match = 0, this.dyn_ltree = new Uint16Array(bf * 2), this.dyn_dtree = new Uint16Array((2 * vf + 1) * 2), this.bl_tree = new Uint16Array((2 * yf + 1) * 2), wt(this.dyn_ltree), wt(this.dyn_dtree), wt(this.bl_tree), this.l_desc = null, this.d_desc = null, this.bl_desc = null, this.bl_count = new Uint16Array(gf + 1), this.heap = new Uint16Array(2 * Yi + 1), wt(this.heap), this.heap_len = 0, this.heap_max = 0, this.depth = new Uint16Array(2 * Yi + 1), wt(this.depth), this.l_buf = 0, this.lit_bufsize = 0, this.last_lit = 0, this.d_buf = 0, this.opt_len = 0, this.static_len = 0, this.matches = 0, this.insert = 0, this.bi_buf = 0, this.bi_valid = 0
}
const zs = e => {
        if (!e || !e.state) return mt(e, Pe);
        e.total_in = e.total_out = 0, e.data_type = ff;
        const t = e.state;
        return t.pending = 0, t.pending_out = 0, t.wrap < 0 && (t.wrap = -t.wrap), t.status = t.wrap ? Fn : Nt, e.adler = t.wrap === 2 ? 0 : 1, t.last_flush = Kt, Yl(t), Ve
    },
    Rs = e => {
        const t = zs(e);
        return t === Ve && Tf(e.state), t
    },
    Rf = (e, t) => !e || !e.state || e.state.wrap !== 2 ? Pe : (e.state.gzhead = t, Ve),
    Os = (e, t, r, n, i, a) => {
        if (!e) return Pe;
        let o = 1;
        if (t === af && (t = 6), n < 0 ? (o = 0, n = -n) : n > 15 && (o = 2, n -= 16), i < 1 || i > cf || r !== $n || n < 8 || n > 15 || t < 0 || t > 9 || a < 0 || a > uf) return mt(e, Pe);
        n === 8 && (n = 9);
        const s = new zf;
        return e.state = s, s.strm = e, s.wrap = o, s.gzhead = null, s.w_bits = n, s.w_size = 1 << s.w_bits, s.w_mask = s.w_size - 1, s.hash_bits = i + 7, s.hash_size = 1 << s.hash_bits, s.hash_mask = s.hash_size - 1, s.hash_shift = ~~((s.hash_bits + se - 1) / se), s.window = new Uint8Array(s.w_size * 2), s.head = new Uint16Array(s.hash_size), s.prev = new Uint16Array(s.w_size), s.lit_bufsize = 1 << i + 6, s.pending_buf_size = s.lit_bufsize * 4, s.pending_buf = new Uint8Array(s.pending_buf_size), s.d_buf = 1 * s.lit_bufsize, s.l_buf = (1 + 2) * s.lit_bufsize, s.level = t, s.strategy = a, s.method = r, Rs(e)
    },
    Of = (e, t) => Os(e, t, $n, hf, df, lf),
    Df = (e, t) => {
        let r, n;
        if (!e || !e.state || t > Ja || t < 0) return e ? mt(e, Pe) : Pe;
        const i = e.state;
        if (!e.output || !e.input && e.avail_in !== 0 || i.status === Ir && t !== kt) return mt(e, e.avail_out === 0 ? xi : Pe);
        i.strm = e;
        const a = i.last_flush;
        if (i.last_flush = t, i.status === Fn)
            if (i.wrap === 2) e.adler = 0, le(i, 31), le(i, 139), le(i, 8), i.gzhead ? (le(i, (i.gzhead.text ? 1 : 0) + (i.gzhead.hcrc ? 2 : 0) + (i.gzhead.extra ? 4 : 0) + (i.gzhead.name ? 8 : 0) + (i.gzhead.comment ? 16 : 0)), le(i, i.gzhead.time & 255), le(i, i.gzhead.time >> 8 & 255), le(i, i.gzhead.time >> 16 & 255), le(i, i.gzhead.time >> 24 & 255), le(i, i.level === 9 ? 2 : i.strategy >= gn || i.level < 2 ? 4 : 0), le(i, i.gzhead.os & 255), i.gzhead.extra && i.gzhead.extra.length && (le(i, i.gzhead.extra.length & 255), le(i, i.gzhead.extra.length >> 8 & 255)), i.gzhead.hcrc && (e.adler = vt(e.adler, i.pending_buf, i.pending, 0)), i.gzindex = 0, i.status = Ji) : (le(i, 0), le(i, 0), le(i, 0), le(i, 0), le(i, 0), le(i, i.level === 9 ? 2 : i.strategy >= gn || i.level < 2 ? 4 : 0), le(i, xf), i.status = Nt);
            else {
                let o = $n + (i.w_bits - 8 << 4) << 8,
                    s = -1;
                i.strategy >= gn || i.level < 2 ? s = 0 : i.level < 6 ? s = 1 : i.level === 6 ? s = 2 : s = 3, o |= s << 6, i.strstart !== 0 && (o |= wf), o += 31 - o % 31, i.status = Nt, kr(i, o), i.strstart !== 0 && (kr(i, e.adler >>> 16), kr(i, e.adler & 65535)), e.adler = 1
            }
        if (i.status === Ji)
            if (i.gzhead.extra) {
                for (r = i.pending; i.gzindex < (i.gzhead.extra.length & 65535) && !(i.pending === i.pending_buf_size && (i.gzhead.hcrc && i.pending > r && (e.adler = vt(e.adler, i.pending_buf, i.pending - r, r)), yt(e), r = i.pending, i.pending === i.pending_buf_size));) le(i, i.gzhead.extra[i.gzindex] & 255), i.gzindex++;
                i.gzhead.hcrc && i.pending > r && (e.adler = vt(e.adler, i.pending_buf, i.pending - r, r)), i.gzindex === i.gzhead.extra.length && (i.gzindex = 0, i.status = zn)
            } else i.status = zn;
        if (i.status === zn)
            if (i.gzhead.name) {
                r = i.pending;
                do {
                    if (i.pending === i.pending_buf_size && (i.gzhead.hcrc && i.pending > r && (e.adler = vt(e.adler, i.pending_buf, i.pending - r, r)), yt(e), r = i.pending, i.pending === i.pending_buf_size)) {
                        n = 1;
                        break
                    }
                    i.gzindex < i.gzhead.name.length ? n = i.gzhead.name.charCodeAt(i.gzindex++) & 255 : n = 0, le(i, n)
                } while (n !== 0);
                i.gzhead.hcrc && i.pending > r && (e.adler = vt(e.adler, i.pending_buf, i.pending - r, r)), n === 0 && (i.gzindex = 0, i.status = Rn)
            } else i.status = Rn;
        if (i.status === Rn)
            if (i.gzhead.comment) {
                r = i.pending;
                do {
                    if (i.pending === i.pending_buf_size && (i.gzhead.hcrc && i.pending > r && (e.adler = vt(e.adler, i.pending_buf, i.pending - r, r)), yt(e), r = i.pending, i.pending === i.pending_buf_size)) {
                        n = 1;
                        break
                    }
                    i.gzindex < i.gzhead.comment.length ? n = i.gzhead.comment.charCodeAt(i.gzindex++) & 255 : n = 0, le(i, n)
                } while (n !== 0);
                i.gzhead.hcrc && i.pending > r && (e.adler = vt(e.adler, i.pending_buf, i.pending - r, r)), n === 0 && (i.status = On)
            } else i.status = On;
        if (i.status === On && (i.gzhead.hcrc ? (i.pending + 2 > i.pending_buf_size && yt(e), i.pending + 2 <= i.pending_buf_size && (le(i, e.adler & 255), le(i, e.adler >> 8 & 255), e.adler = 0, i.status = Nt)) : i.status = Nt), i.pending !== 0) {
            if (yt(e), e.avail_out === 0) return i.last_flush = -1, Ve
        } else if (e.avail_in === 0 && Qa(t) <= Qa(a) && t !== kt) return mt(e, xi);
        if (i.status === Ir && e.avail_in !== 0) return mt(e, xi);
        if (e.avail_in !== 0 || i.lookahead !== 0 || t !== Kt && i.status !== Ir) {
            let o = i.strategy === gn ? kf(i, t) : i.strategy === sf ? Af(i, t) : Br[i.level].func(i, t);
            if ((o === Bt || o === cr) && (i.status = Ir), o === ge || o === Bt) return e.avail_out === 0 && (i.last_flush = -1), Ve;
            if (o === en && (t === tf ? Ql(i) : t !== Ja && (Jl(i, 0, 0, !1), t === rf && (wt(i.head), i.lookahead === 0 && (i.strstart = 0, i.block_start = 0, i.insert = 0))), yt(e), e.avail_out === 0)) return i.last_flush = -1, Ve
        }
        return t !== kt ? Ve : i.wrap <= 0 ? Xa : (i.wrap === 2 ? (le(i, e.adler & 255), le(i, e.adler >> 8 & 255), le(i, e.adler >> 16 & 255), le(i, e.adler >> 24 & 255), le(i, e.total_in & 255), le(i, e.total_in >> 8 & 255), le(i, e.total_in >> 16 & 255), le(i, e.total_in >> 24 & 255)) : (kr(i, e.adler >>> 16), kr(i, e.adler & 65535)), yt(e), i.wrap > 0 && (i.wrap = -i.wrap), i.pending !== 0 ? Ve : Xa)
    },
    Pf = e => {
        if (!e || !e.state) return Pe;
        const t = e.state.status;
        return t !== Fn && t !== Ji && t !== zn && t !== Rn && t !== On && t !== Nt && t !== Ir ? mt(e, Pe) : (e.state = null, t === Nt ? mt(e, nf) : Ve)
    },
    Cf = (e, t) => {
        let r = t.length;
        if (!e || !e.state) return Pe;
        const n = e.state,
            i = n.wrap;
        if (i === 2 || i === 1 && n.status !== Fn || n.lookahead) return Pe;
        if (i === 1 && (e.adler = ks(e.adler, t, r, 0)), n.wrap = 0, r >= n.w_size) {
            i === 0 && (wt(n.head), n.strstart = 0, n.block_start = 0, n.insert = 0);
            let c = new Uint8Array(n.w_size);
            c.set(t.subarray(r - n.w_size, r), 0), t = c, r = n.w_size
        }
        const a = e.avail_in,
            o = e.next_in,
            s = e.input;
        for (e.avail_in = r, e.next_in = 0, e.input = t, Mt(n); n.lookahead >= se;) {
            let c = n.strstart,
                u = n.lookahead - (se - 1);
            do n.ins_h = Tt(n, n.ins_h, n.window[c + se - 1]), n.prev[c & n.w_mask] = n.head[n.ins_h], n.head[n.ins_h] = c, c++; while (--u);
            n.strstart = c, n.lookahead = se - 1, Mt(n)
        }
        return n.strstart += n.lookahead, n.block_start = n.strstart, n.insert = n.lookahead, n.lookahead = 0, n.match_length = n.prev_length = se - 1, n.match_available = 0, e.next_in = o, e.input = s, e.avail_in = a, n.wrap = i, Ve
    };
it.deflateInit = Of;
it.deflateInit2 = Os;
it.deflateReset = Rs;
it.deflateResetKeep = zs;
it.deflateSetHeader = Rf;
it.deflate = Df;
it.deflateEnd = Pf;
it.deflateSetDictionary = Cf;
it.deflateInfo = "pako deflate (from Nodeca project)";
var Hn = {};
const Nf = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
Hn.assign = function(e) {
    const t = Array.prototype.slice.call(arguments, 1);
    for (; t.length;) {
        const r = t.shift();
        if (!!r) {
            if (typeof r != "object") throw new TypeError(r + "must be non-object");
            for (const n in r) Nf(r, n) && (e[n] = r[n])
        }
    }
    return e
};
Hn.flattenChunks = e => {
    let t = 0;
    for (let n = 0, i = e.length; n < i; n++) t += e[n].length;
    const r = new Uint8Array(t);
    for (let n = 0, i = 0, a = e.length; n < a; n++) {
        let o = e[n];
        r.set(o, i), i += o.length
    }
    return r
};
var tn = {};
let Ds = !0;
try {
    String.fromCharCode.apply(null, new Uint8Array(1))
} catch (e) {
    Ds = !1
}
const Gr = new Uint8Array(256);
for (let e = 0; e < 256; e++) Gr[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
Gr[254] = Gr[254] = 1;
tn.string2buf = e => {
    let t, r, n, i, a, o = e.length,
        s = 0;
    for (i = 0; i < o; i++) r = e.charCodeAt(i), (r & 64512) === 55296 && i + 1 < o && (n = e.charCodeAt(i + 1), (n & 64512) === 56320 && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++)), s += r < 128 ? 1 : r < 2048 ? 2 : r < 65536 ? 3 : 4;
    for (t = new Uint8Array(s), a = 0, i = 0; a < s; i++) r = e.charCodeAt(i), (r & 64512) === 55296 && i + 1 < o && (n = e.charCodeAt(i + 1), (n & 64512) === 56320 && (r = 65536 + (r - 55296 << 10) + (n - 56320), i++)), r < 128 ? t[a++] = r : r < 2048 ? (t[a++] = 192 | r >>> 6, t[a++] = 128 | r & 63) : r < 65536 ? (t[a++] = 224 | r >>> 12, t[a++] = 128 | r >>> 6 & 63, t[a++] = 128 | r & 63) : (t[a++] = 240 | r >>> 18, t[a++] = 128 | r >>> 12 & 63, t[a++] = 128 | r >>> 6 & 63, t[a++] = 128 | r & 63);
    return t
};
const Lf = (e, t) => {
    if (t < 65534 && e.subarray && Ds) return String.fromCharCode.apply(null, e.length === t ? e : e.subarray(0, t));
    let r = "";
    for (let n = 0; n < t; n++) r += String.fromCharCode(e[n]);
    return r
};
tn.buf2string = (e, t) => {
    let r, n;
    const i = t || e.length,
        a = new Array(i * 2);
    for (n = 0, r = 0; r < i;) {
        let o = e[r++];
        if (o < 128) {
            a[n++] = o;
            continue
        }
        let s = Gr[o];
        if (s > 4) {
            a[n++] = 65533, r += s - 1;
            continue
        }
        for (o &= s === 2 ? 31 : s === 3 ? 15 : 7; s > 1 && r < i;) o = o << 6 | e[r++] & 63, s--;
        if (s > 1) {
            a[n++] = 65533;
            continue
        }
        o < 65536 ? a[n++] = o : (o -= 65536, a[n++] = 55296 | o >> 10 & 1023, a[n++] = 56320 | o & 1023)
    }
    return Lf(a, n)
};
tn.utf8border = (e, t) => {
    t = t || e.length, t > e.length && (t = e.length);
    let r = t - 1;
    for (; r >= 0 && (e[r] & 192) === 128;) r--;
    return r < 0 || r === 0 ? t : r + Gr[e[r]] > t ? r : t
};

function If() {
    this.input = null, this.next_in = 0, this.avail_in = 0, this.total_in = 0, this.output = null, this.next_out = 0, this.avail_out = 0, this.total_out = 0, this.msg = "", this.state = null, this.data_type = 2, this.adler = 0
}
var Ps = If;
const $r = it,
    Cs = Hn,
    Ns = tn,
    Xi = ba,
    Bf = Ps,
    Ls = Object.prototype.toString,
    {
        Z_NO_FLUSH: Mf,
        Z_SYNC_FLUSH: Uf,
        Z_FULL_FLUSH: $f,
        Z_FINISH: Ff,
        Z_OK: Ln,
        Z_STREAM_END: Hf,
        Z_DEFAULT_COMPRESSION: Kf,
        Z_DEFAULT_STRATEGY: Wf,
        Z_DEFLATED: Zf
    } = Ht;

function rn(e) {
    this.options = Cs.assign({
        level: Kf,
        method: Zf,
        chunkSize: 16384,
        windowBits: 15,
        memLevel: 8,
        strategy: Wf
    }, e || {});
    let t = this.options;
    t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new Bf, this.strm.avail_out = 0;
    let r = $r.deflateInit2(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
    if (r !== Ln) throw new Error(Xi[r]);
    if (t.header && $r.deflateSetHeader(this.strm, t.header), t.dictionary) {
        let n;
        if (typeof t.dictionary == "string" ? n = Ns.string2buf(t.dictionary) : Ls.call(t.dictionary) === "[object ArrayBuffer]" ? n = new Uint8Array(t.dictionary) : n = t.dictionary, r = $r.deflateSetDictionary(this.strm, n), r !== Ln) throw new Error(Xi[r]);
        this._dict_set = !0
    }
}
rn.prototype.push = function(e, t) {
    const r = this.strm,
        n = this.options.chunkSize;
    let i, a;
    if (this.ended) return !1;
    for (t === ~~t ? a = t : a = t === !0 ? Ff : Mf, typeof e == "string" ? r.input = Ns.string2buf(e) : Ls.call(e) === "[object ArrayBuffer]" ? r.input = new Uint8Array(e) : r.input = e, r.next_in = 0, r.avail_in = r.input.length;;) {
        if (r.avail_out === 0 && (r.output = new Uint8Array(n), r.next_out = 0, r.avail_out = n), (a === Uf || a === $f) && r.avail_out <= 6) {
            this.onData(r.output.subarray(0, r.next_out)), r.avail_out = 0;
            continue
        }
        if (i = $r.deflate(r, a), i === Hf) return r.next_out > 0 && this.onData(r.output.subarray(0, r.next_out)), i = $r.deflateEnd(this.strm), this.onEnd(i), this.ended = !0, i === Ln;
        if (r.avail_out === 0) {
            this.onData(r.output);
            continue
        }
        if (a > 0 && r.next_out > 0) {
            this.onData(r.output.subarray(0, r.next_out)), r.avail_out = 0;
            continue
        }
        if (r.avail_in === 0) break
    }
    return !0
};
rn.prototype.onData = function(e) {
    this.chunks.push(e)
};
rn.prototype.onEnd = function(e) {
    e === Ln && (this.result = Cs.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg
};

function ga(e, t) {
    const r = new rn(t);
    if (r.push(e, !0), r.err) throw r.msg || Xi[r.err];
    return r.result
}

function qf(e, t) {
    return t = t || {}, t.raw = !0, ga(e, t)
}

function jf(e, t) {
    return t = t || {}, t.gzip = !0, ga(e, t)
}
ur.Deflate = rn;
ur.deflate = ga;
ur.deflateRaw = qf;
ur.gzip = jf;
ur.constants = Ht;
var hr = {},
    Ke = {};
const wn = 30,
    Gf = 12;
var Vf = function(t, r) {
    let n, i, a, o, s, c, u, f, b, _, v, g, k, O, z, P, L, y, D, w, x, A, U, N;
    const F = t.state;
    n = t.next_in, U = t.input, i = n + (t.avail_in - 5), a = t.next_out, N = t.output, o = a - (r - t.avail_out), s = a + (t.avail_out - 257), c = F.dmax, u = F.wsize, f = F.whave, b = F.wnext, _ = F.window, v = F.hold, g = F.bits, k = F.lencode, O = F.distcode, z = (1 << F.lenbits) - 1, P = (1 << F.distbits) - 1;
    e: do {
        g < 15 && (v += U[n++] << g, g += 8, v += U[n++] << g, g += 8), L = k[v & z];
        t: for (;;) {
            if (y = L >>> 24, v >>>= y, g -= y, y = L >>> 16 & 255, y === 0) N[a++] = L & 65535;
            else if (y & 16) {
                D = L & 65535, y &= 15, y && (g < y && (v += U[n++] << g, g += 8), D += v & (1 << y) - 1, v >>>= y, g -= y), g < 15 && (v += U[n++] << g, g += 8, v += U[n++] << g, g += 8), L = O[v & P];
                r: for (;;) {
                    if (y = L >>> 24, v >>>= y, g -= y, y = L >>> 16 & 255, y & 16) {
                        if (w = L & 65535, y &= 15, g < y && (v += U[n++] << g, g += 8, g < y && (v += U[n++] << g, g += 8)), w += v & (1 << y) - 1, w > c) {
                            t.msg = "invalid distance too far back", F.mode = wn;
                            break e
                        }
                        if (v >>>= y, g -= y, y = a - o, w > y) {
                            if (y = w - y, y > f && F.sane) {
                                t.msg = "invalid distance too far back", F.mode = wn;
                                break e
                            }
                            if (x = 0, A = _, b === 0) {
                                if (x += u - y, y < D) {
                                    D -= y;
                                    do N[a++] = _[x++]; while (--y);
                                    x = a - w, A = N
                                }
                            } else if (b < y) {
                                if (x += u + b - y, y -= b, y < D) {
                                    D -= y;
                                    do N[a++] = _[x++]; while (--y);
                                    if (x = 0, b < D) {
                                        y = b, D -= y;
                                        do N[a++] = _[x++]; while (--y);
                                        x = a - w, A = N
                                    }
                                }
                            } else if (x += b - y, y < D) {
                                D -= y;
                                do N[a++] = _[x++]; while (--y);
                                x = a - w, A = N
                            }
                            for (; D > 2;) N[a++] = A[x++], N[a++] = A[x++], N[a++] = A[x++], D -= 3;
                            D && (N[a++] = A[x++], D > 1 && (N[a++] = A[x++]))
                        } else {
                            x = a - w;
                            do N[a++] = N[x++], N[a++] = N[x++], N[a++] = N[x++], D -= 3; while (D > 2);
                            D && (N[a++] = N[x++], D > 1 && (N[a++] = N[x++]))
                        }
                    } else if ((y & 64) === 0) {
                        L = O[(L & 65535) + (v & (1 << y) - 1)];
                        continue r
                    } else {
                        t.msg = "invalid distance code", F.mode = wn;
                        break e
                    }
                    break
                }
            } else if ((y & 64) === 0) {
                L = k[(L & 65535) + (v & (1 << y) - 1)];
                continue t
            } else if (y & 32) {
                F.mode = Gf;
                break e
            } else {
                t.msg = "invalid literal/length code", F.mode = wn;
                break e
            }
            break
        }
    } while (n < i && a < s);
    D = g >> 3, n -= D, g -= D << 3, v &= (1 << g) - 1, t.next_in = n, t.next_out = a, t.avail_in = n < i ? 5 + (i - n) : 5 - (n - i), t.avail_out = a < s ? 257 + (s - a) : 257 - (a - s), F.hold = v, F.bits = g
};
const Jt = 15,
    eo = 852,
    to = 592,
    ro = 0,
    Ei = 1,
    no = 2,
    Yf = new Uint16Array([3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0]),
    Jf = new Uint8Array([16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 18, 18, 18, 18, 19, 19, 19, 19, 20, 20, 20, 20, 21, 21, 21, 21, 16, 72, 78]),
    Xf = new Uint16Array([1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577, 0, 0]),
    Qf = new Uint8Array([16, 16, 16, 16, 17, 17, 18, 18, 19, 19, 20, 20, 21, 21, 22, 22, 23, 23, 24, 24, 25, 25, 26, 26, 27, 27, 28, 28, 29, 29, 64, 64]),
    ec = (e, t, r, n, i, a, o, s) => {
        const c = s.bits;
        let u = 0,
            f = 0,
            b = 0,
            _ = 0,
            v = 0,
            g = 0,
            k = 0,
            O = 0,
            z = 0,
            P = 0,
            L, y, D, w, x, A = null,
            U = 0,
            N;
        const F = new Uint16Array(Jt + 1),
            W = new Uint16Array(Jt + 1);
        let K = null,
            Z = 0,
            V, ie, re;
        for (u = 0; u <= Jt; u++) F[u] = 0;
        for (f = 0; f < n; f++) F[t[r + f]]++;
        for (v = c, _ = Jt; _ >= 1 && F[_] === 0; _--);
        if (v > _ && (v = _), _ === 0) return i[a++] = 1 << 24 | 64 << 16 | 0, i[a++] = 1 << 24 | 64 << 16 | 0, s.bits = 1, 0;
        for (b = 1; b < _ && F[b] === 0; b++);
        for (v < b && (v = b), O = 1, u = 1; u <= Jt; u++)
            if (O <<= 1, O -= F[u], O < 0) return -1;
        if (O > 0 && (e === ro || _ !== 1)) return -1;
        for (W[1] = 0, u = 1; u < Jt; u++) W[u + 1] = W[u] + F[u];
        for (f = 0; f < n; f++) t[r + f] !== 0 && (o[W[t[r + f]]++] = f);
        if (e === ro ? (A = K = o, N = 19) : e === Ei ? (A = Yf, U -= 257, K = Jf, Z -= 257, N = 256) : (A = Xf, K = Qf, N = -1), P = 0, f = 0, u = b, x = a, g = v, k = 0, D = -1, z = 1 << v, w = z - 1, e === Ei && z > eo || e === no && z > to) return 1;
        for (;;) {
            V = u - k, o[f] < N ? (ie = 0, re = o[f]) : o[f] > N ? (ie = K[Z + o[f]], re = A[U + o[f]]) : (ie = 32 + 64, re = 0), L = 1 << u - k, y = 1 << g, b = y;
            do y -= L, i[x + (P >> k) + y] = V << 24 | ie << 16 | re | 0; while (y !== 0);
            for (L = 1 << u - 1; P & L;) L >>= 1;
            if (L !== 0 ? (P &= L - 1, P += L) : P = 0, f++, --F[u] === 0) {
                if (u === _) break;
                u = t[r + o[f]]
            }
            if (u > v && (P & w) !== D) {
                for (k === 0 && (k = v), x += b, g = u - k, O = 1 << g; g + k < _ && (O -= F[g + k], !(O <= 0));) g++, O <<= 1;
                if (z += 1 << g, e === Ei && z > eo || e === no && z > to) return 1;
                D = P & w, i[D] = v << 24 | g << 16 | x - a | 0
            }
        }
        return P !== 0 && (i[x + P] = u - k << 24 | 64 << 16 | 0), s.bits = v, 0
    };
var tc = ec;
const Qi = Ss,
    je = As,
    rc = Vf,
    Fr = tc,
    nc = 0,
    Is = 1,
    Bs = 2,
    {
        Z_FINISH: io,
        Z_BLOCK: ic,
        Z_TREES: xn,
        Z_OK: Ut,
        Z_STREAM_END: ac,
        Z_NEED_DICT: oc,
        Z_STREAM_ERROR: Ce,
        Z_DATA_ERROR: Ms,
        Z_MEM_ERROR: Us,
        Z_BUF_ERROR: sc,
        Z_DEFLATED: ao
    } = Ht,
    $s = 1,
    oo = 2,
    so = 3,
    uo = 4,
    lo = 5,
    fo = 6,
    co = 7,
    ho = 8,
    po = 9,
    _o = 10,
    In = 11,
    ot = 12,
    Si = 13,
    vo = 14,
    Ai = 15,
    yo = 16,
    bo = 17,
    go = 18,
    wo = 19,
    mn = 20,
    En = 21,
    xo = 22,
    mo = 23,
    Eo = 24,
    So = 25,
    Ao = 26,
    ki = 27,
    ko = 28,
    To = 29,
    he = 30,
    Fs = 31,
    uc = 32,
    lc = 852,
    fc = 592,
    cc = 15,
    hc = cc,
    zo = e => (e >>> 24 & 255) + (e >>> 8 & 65280) + ((e & 65280) << 8) + ((e & 255) << 24);

function dc() {
    this.mode = 0, this.last = !1, this.wrap = 0, this.havedict = !1, this.flags = 0, this.dmax = 0, this.check = 0, this.total = 0, this.head = null, this.wbits = 0, this.wsize = 0, this.whave = 0, this.wnext = 0, this.window = null, this.hold = 0, this.bits = 0, this.length = 0, this.offset = 0, this.extra = 0, this.lencode = null, this.distcode = null, this.lenbits = 0, this.distbits = 0, this.ncode = 0, this.nlen = 0, this.ndist = 0, this.have = 0, this.next = null, this.lens = new Uint16Array(320), this.work = new Uint16Array(288), this.lendyn = null, this.distdyn = null, this.sane = 0, this.back = 0, this.was = 0
}
const Hs = e => {
        if (!e || !e.state) return Ce;
        const t = e.state;
        return e.total_in = e.total_out = t.total = 0, e.msg = "", t.wrap && (e.adler = t.wrap & 1), t.mode = $s, t.last = 0, t.havedict = 0, t.dmax = 32768, t.head = null, t.hold = 0, t.bits = 0, t.lencode = t.lendyn = new Int32Array(lc), t.distcode = t.distdyn = new Int32Array(fc), t.sane = 1, t.back = -1, Ut
    },
    Ks = e => {
        if (!e || !e.state) return Ce;
        const t = e.state;
        return t.wsize = 0, t.whave = 0, t.wnext = 0, Hs(e)
    },
    Ws = (e, t) => {
        let r;
        if (!e || !e.state) return Ce;
        const n = e.state;
        return t < 0 ? (r = 0, t = -t) : (r = (t >> 4) + 1, t < 48 && (t &= 15)), t && (t < 8 || t > 15) ? Ce : (n.window !== null && n.wbits !== t && (n.window = null), n.wrap = r, n.wbits = t, Ks(e))
    },
    Zs = (e, t) => {
        if (!e) return Ce;
        const r = new dc;
        e.state = r, r.window = null;
        const n = Ws(e, t);
        return n !== Ut && (e.state = null), n
    },
    pc = e => Zs(e, hc);
let Ro = !0,
    Ti, zi;
const _c = e => {
        if (Ro) {
            Ti = new Int32Array(512), zi = new Int32Array(32);
            let t = 0;
            for (; t < 144;) e.lens[t++] = 8;
            for (; t < 256;) e.lens[t++] = 9;
            for (; t < 280;) e.lens[t++] = 7;
            for (; t < 288;) e.lens[t++] = 8;
            for (Fr(Is, e.lens, 0, 288, Ti, 0, e.work, {
                    bits: 9
                }), t = 0; t < 32;) e.lens[t++] = 5;
            Fr(Bs, e.lens, 0, 32, zi, 0, e.work, {
                bits: 5
            }), Ro = !1
        }
        e.lencode = Ti, e.lenbits = 9, e.distcode = zi, e.distbits = 5
    },
    qs = (e, t, r, n) => {
        let i;
        const a = e.state;
        return a.window === null && (a.wsize = 1 << a.wbits, a.wnext = 0, a.whave = 0, a.window = new Uint8Array(a.wsize)), n >= a.wsize ? (a.window.set(t.subarray(r - a.wsize, r), 0), a.wnext = 0, a.whave = a.wsize) : (i = a.wsize - a.wnext, i > n && (i = n), a.window.set(t.subarray(r - n, r - n + i), a.wnext), n -= i, n ? (a.window.set(t.subarray(r - n, r), 0), a.wnext = n, a.whave = a.wsize) : (a.wnext += i, a.wnext === a.wsize && (a.wnext = 0), a.whave < a.wsize && (a.whave += i))), 0
    },
    vc = (e, t) => {
        let r, n, i, a, o, s, c, u, f, b, _, v, g, k, O = 0,
            z, P, L, y, D, w, x, A;
        const U = new Uint8Array(4);
        let N, F;
        const W = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
        if (!e || !e.state || !e.output || !e.input && e.avail_in !== 0) return Ce;
        r = e.state, r.mode === ot && (r.mode = Si), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, n = e.input, s = e.avail_in, u = r.hold, f = r.bits, b = s, _ = c, A = Ut;
        e: for (;;) switch (r.mode) {
            case $s:
                if (r.wrap === 0) {
                    r.mode = Si;
                    break
                }
                for (; f < 16;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                if (r.wrap & 2 && u === 35615) {
                    r.check = 0, U[0] = u & 255, U[1] = u >>> 8 & 255, r.check = je(r.check, U, 2, 0), u = 0, f = 0, r.mode = oo;
                    break
                }
                if (r.flags = 0, r.head && (r.head.done = !1), !(r.wrap & 1) || (((u & 255) << 8) + (u >> 8)) % 31) {
                    e.msg = "incorrect header check", r.mode = he;
                    break
                }
                if ((u & 15) !== ao) {
                    e.msg = "unknown compression method", r.mode = he;
                    break
                }
                if (u >>>= 4, f -= 4, x = (u & 15) + 8, r.wbits === 0) r.wbits = x;
                else if (x > r.wbits) {
                    e.msg = "invalid window size", r.mode = he;
                    break
                }
                r.dmax = 1 << r.wbits, e.adler = r.check = 1, r.mode = u & 512 ? _o : ot, u = 0, f = 0;
                break;
            case oo:
                for (; f < 16;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                if (r.flags = u, (r.flags & 255) !== ao) {
                    e.msg = "unknown compression method", r.mode = he;
                    break
                }
                if (r.flags & 57344) {
                    e.msg = "unknown header flags set", r.mode = he;
                    break
                }
                r.head && (r.head.text = u >> 8 & 1), r.flags & 512 && (U[0] = u & 255, U[1] = u >>> 8 & 255, r.check = je(r.check, U, 2, 0)), u = 0, f = 0, r.mode = so;
            case so:
                for (; f < 32;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                r.head && (r.head.time = u), r.flags & 512 && (U[0] = u & 255, U[1] = u >>> 8 & 255, U[2] = u >>> 16 & 255, U[3] = u >>> 24 & 255, r.check = je(r.check, U, 4, 0)), u = 0, f = 0, r.mode = uo;
            case uo:
                for (; f < 16;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                r.head && (r.head.xflags = u & 255, r.head.os = u >> 8), r.flags & 512 && (U[0] = u & 255, U[1] = u >>> 8 & 255, r.check = je(r.check, U, 2, 0)), u = 0, f = 0, r.mode = lo;
            case lo:
                if (r.flags & 1024) {
                    for (; f < 16;) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    r.length = u, r.head && (r.head.extra_len = u), r.flags & 512 && (U[0] = u & 255, U[1] = u >>> 8 & 255, r.check = je(r.check, U, 2, 0)), u = 0, f = 0
                } else r.head && (r.head.extra = null);
                r.mode = fo;
            case fo:
                if (r.flags & 1024 && (v = r.length, v > s && (v = s), v && (r.head && (x = r.head.extra_len - r.length, r.head.extra || (r.head.extra = new Uint8Array(r.head.extra_len)), r.head.extra.set(n.subarray(a, a + v), x)), r.flags & 512 && (r.check = je(r.check, n, v, a)), s -= v, a += v, r.length -= v), r.length)) break e;
                r.length = 0, r.mode = co;
            case co:
                if (r.flags & 2048) {
                    if (s === 0) break e;
                    v = 0;
                    do x = n[a + v++], r.head && x && r.length < 65536 && (r.head.name += String.fromCharCode(x)); while (x && v < s);
                    if (r.flags & 512 && (r.check = je(r.check, n, v, a)), s -= v, a += v, x) break e
                } else r.head && (r.head.name = null);
                r.length = 0, r.mode = ho;
            case ho:
                if (r.flags & 4096) {
                    if (s === 0) break e;
                    v = 0;
                    do x = n[a + v++], r.head && x && r.length < 65536 && (r.head.comment += String.fromCharCode(x)); while (x && v < s);
                    if (r.flags & 512 && (r.check = je(r.check, n, v, a)), s -= v, a += v, x) break e
                } else r.head && (r.head.comment = null);
                r.mode = po;
            case po:
                if (r.flags & 512) {
                    for (; f < 16;) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    if (u !== (r.check & 65535)) {
                        e.msg = "header crc mismatch", r.mode = he;
                        break
                    }
                    u = 0, f = 0
                }
                r.head && (r.head.hcrc = r.flags >> 9 & 1, r.head.done = !0), e.adler = r.check = 0, r.mode = ot;
                break;
            case _o:
                for (; f < 32;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                e.adler = r.check = zo(u), u = 0, f = 0, r.mode = In;
            case In:
                if (r.havedict === 0) return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, r.hold = u, r.bits = f, oc;
                e.adler = r.check = 1, r.mode = ot;
            case ot:
                if (t === ic || t === xn) break e;
            case Si:
                if (r.last) {
                    u >>>= f & 7, f -= f & 7, r.mode = ki;
                    break
                }
                for (; f < 3;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                switch (r.last = u & 1, u >>>= 1, f -= 1, u & 3) {
                    case 0:
                        r.mode = vo;
                        break;
                    case 1:
                        if (_c(r), r.mode = mn, t === xn) {
                            u >>>= 2, f -= 2;
                            break e
                        }
                        break;
                    case 2:
                        r.mode = bo;
                        break;
                    case 3:
                        e.msg = "invalid block type", r.mode = he
                }
                u >>>= 2, f -= 2;
                break;
            case vo:
                for (u >>>= f & 7, f -= f & 7; f < 32;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                if ((u & 65535) !== (u >>> 16 ^ 65535)) {
                    e.msg = "invalid stored block lengths", r.mode = he;
                    break
                }
                if (r.length = u & 65535, u = 0, f = 0, r.mode = Ai, t === xn) break e;
            case Ai:
                r.mode = yo;
            case yo:
                if (v = r.length, v) {
                    if (v > s && (v = s), v > c && (v = c), v === 0) break e;
                    i.set(n.subarray(a, a + v), o), s -= v, a += v, c -= v, o += v, r.length -= v;
                    break
                }
                r.mode = ot;
                break;
            case bo:
                for (; f < 14;) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                if (r.nlen = (u & 31) + 257, u >>>= 5, f -= 5, r.ndist = (u & 31) + 1, u >>>= 5, f -= 5, r.ncode = (u & 15) + 4, u >>>= 4, f -= 4, r.nlen > 286 || r.ndist > 30) {
                    e.msg = "too many length or distance symbols", r.mode = he;
                    break
                }
                r.have = 0, r.mode = go;
            case go:
                for (; r.have < r.ncode;) {
                    for (; f < 3;) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    r.lens[W[r.have++]] = u & 7, u >>>= 3, f -= 3
                }
                for (; r.have < 19;) r.lens[W[r.have++]] = 0;
                if (r.lencode = r.lendyn, r.lenbits = 7, N = {
                        bits: r.lenbits
                    }, A = Fr(nc, r.lens, 0, 19, r.lencode, 0, r.work, N), r.lenbits = N.bits, A) {
                    e.msg = "invalid code lengths set", r.mode = he;
                    break
                }
                r.have = 0, r.mode = wo;
            case wo:
                for (; r.have < r.nlen + r.ndist;) {
                    for (; O = r.lencode[u & (1 << r.lenbits) - 1], z = O >>> 24, P = O >>> 16 & 255, L = O & 65535, !(z <= f);) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    if (L < 16) u >>>= z, f -= z, r.lens[r.have++] = L;
                    else {
                        if (L === 16) {
                            for (F = z + 2; f < F;) {
                                if (s === 0) break e;
                                s--, u += n[a++] << f, f += 8
                            }
                            if (u >>>= z, f -= z, r.have === 0) {
                                e.msg = "invalid bit length repeat", r.mode = he;
                                break
                            }
                            x = r.lens[r.have - 1], v = 3 + (u & 3), u >>>= 2, f -= 2
                        } else if (L === 17) {
                            for (F = z + 3; f < F;) {
                                if (s === 0) break e;
                                s--, u += n[a++] << f, f += 8
                            }
                            u >>>= z, f -= z, x = 0, v = 3 + (u & 7), u >>>= 3, f -= 3
                        } else {
                            for (F = z + 7; f < F;) {
                                if (s === 0) break e;
                                s--, u += n[a++] << f, f += 8
                            }
                            u >>>= z, f -= z, x = 0, v = 11 + (u & 127), u >>>= 7, f -= 7
                        }
                        if (r.have + v > r.nlen + r.ndist) {
                            e.msg = "invalid bit length repeat", r.mode = he;
                            break
                        }
                        for (; v--;) r.lens[r.have++] = x
                    }
                }
                if (r.mode === he) break;
                if (r.lens[256] === 0) {
                    e.msg = "invalid code -- missing end-of-block", r.mode = he;
                    break
                }
                if (r.lenbits = 9, N = {
                        bits: r.lenbits
                    }, A = Fr(Is, r.lens, 0, r.nlen, r.lencode, 0, r.work, N), r.lenbits = N.bits, A) {
                    e.msg = "invalid literal/lengths set", r.mode = he;
                    break
                }
                if (r.distbits = 6, r.distcode = r.distdyn, N = {
                        bits: r.distbits
                    }, A = Fr(Bs, r.lens, r.nlen, r.ndist, r.distcode, 0, r.work, N), r.distbits = N.bits, A) {
                    e.msg = "invalid distances set", r.mode = he;
                    break
                }
                if (r.mode = mn, t === xn) break e;
            case mn:
                r.mode = En;
            case En:
                if (s >= 6 && c >= 258) {
                    e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, r.hold = u, r.bits = f, rc(e, _), o = e.next_out, i = e.output, c = e.avail_out, a = e.next_in, n = e.input, s = e.avail_in, u = r.hold, f = r.bits, r.mode === ot && (r.back = -1);
                    break
                }
                for (r.back = 0; O = r.lencode[u & (1 << r.lenbits) - 1], z = O >>> 24, P = O >>> 16 & 255, L = O & 65535, !(z <= f);) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                if (P && (P & 240) === 0) {
                    for (y = z, D = P, w = L; O = r.lencode[w + ((u & (1 << y + D) - 1) >> y)], z = O >>> 24, P = O >>> 16 & 255, L = O & 65535, !(y + z <= f);) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    u >>>= y, f -= y, r.back += y
                }
                if (u >>>= z, f -= z, r.back += z, r.length = L, P === 0) {
                    r.mode = Ao;
                    break
                }
                if (P & 32) {
                    r.back = -1, r.mode = ot;
                    break
                }
                if (P & 64) {
                    e.msg = "invalid literal/length code", r.mode = he;
                    break
                }
                r.extra = P & 15, r.mode = xo;
            case xo:
                if (r.extra) {
                    for (F = r.extra; f < F;) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    r.length += u & (1 << r.extra) - 1, u >>>= r.extra, f -= r.extra, r.back += r.extra
                }
                r.was = r.length, r.mode = mo;
            case mo:
                for (; O = r.distcode[u & (1 << r.distbits) - 1], z = O >>> 24, P = O >>> 16 & 255, L = O & 65535, !(z <= f);) {
                    if (s === 0) break e;
                    s--, u += n[a++] << f, f += 8
                }
                if ((P & 240) === 0) {
                    for (y = z, D = P, w = L; O = r.distcode[w + ((u & (1 << y + D) - 1) >> y)], z = O >>> 24, P = O >>> 16 & 255, L = O & 65535, !(y + z <= f);) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    u >>>= y, f -= y, r.back += y
                }
                if (u >>>= z, f -= z, r.back += z, P & 64) {
                    e.msg = "invalid distance code", r.mode = he;
                    break
                }
                r.offset = L, r.extra = P & 15, r.mode = Eo;
            case Eo:
                if (r.extra) {
                    for (F = r.extra; f < F;) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    r.offset += u & (1 << r.extra) - 1, u >>>= r.extra, f -= r.extra, r.back += r.extra
                }
                if (r.offset > r.dmax) {
                    e.msg = "invalid distance too far back", r.mode = he;
                    break
                }
                r.mode = So;
            case So:
                if (c === 0) break e;
                if (v = _ - c, r.offset > v) {
                    if (v = r.offset - v, v > r.whave && r.sane) {
                        e.msg = "invalid distance too far back", r.mode = he;
                        break
                    }
                    v > r.wnext ? (v -= r.wnext, g = r.wsize - v) : g = r.wnext - v, v > r.length && (v = r.length), k = r.window
                } else k = i, g = o - r.offset, v = r.length;
                v > c && (v = c), c -= v, r.length -= v;
                do i[o++] = k[g++]; while (--v);
                r.length === 0 && (r.mode = En);
                break;
            case Ao:
                if (c === 0) break e;
                i[o++] = r.length, c--, r.mode = En;
                break;
            case ki:
                if (r.wrap) {
                    for (; f < 32;) {
                        if (s === 0) break e;
                        s--, u |= n[a++] << f, f += 8
                    }
                    if (_ -= c, e.total_out += _, r.total += _, _ && (e.adler = r.check = r.flags ? je(r.check, i, _, o - _) : Qi(r.check, i, _, o - _)), _ = c, (r.flags ? u : zo(u)) !== r.check) {
                        e.msg = "incorrect data check", r.mode = he;
                        break
                    }
                    u = 0, f = 0
                }
                r.mode = ko;
            case ko:
                if (r.wrap && r.flags) {
                    for (; f < 32;) {
                        if (s === 0) break e;
                        s--, u += n[a++] << f, f += 8
                    }
                    if (u !== (r.total & 4294967295)) {
                        e.msg = "incorrect length check", r.mode = he;
                        break
                    }
                    u = 0, f = 0
                }
                r.mode = To;
            case To:
                A = ac;
                break e;
            case he:
                A = Ms;
                break e;
            case Fs:
                return Us;
            case uc:
            default:
                return Ce
        }
        return e.next_out = o, e.avail_out = c, e.next_in = a, e.avail_in = s, r.hold = u, r.bits = f, (r.wsize || _ !== e.avail_out && r.mode < he && (r.mode < ki || t !== io)) && qs(e, e.output, e.next_out, _ - e.avail_out), b -= e.avail_in, _ -= e.avail_out, e.total_in += b, e.total_out += _, r.total += _, r.wrap && _ && (e.adler = r.check = r.flags ? je(r.check, i, _, e.next_out - _) : Qi(r.check, i, _, e.next_out - _)), e.data_type = r.bits + (r.last ? 64 : 0) + (r.mode === ot ? 128 : 0) + (r.mode === mn || r.mode === Ai ? 256 : 0), (b === 0 && _ === 0 || t === io) && A === Ut && (A = sc), A
    },
    yc = e => {
        if (!e || !e.state) return Ce;
        let t = e.state;
        return t.window && (t.window = null), e.state = null, Ut
    },
    bc = (e, t) => {
        if (!e || !e.state) return Ce;
        const r = e.state;
        return (r.wrap & 2) === 0 ? Ce : (r.head = t, t.done = !1, Ut)
    },
    gc = (e, t) => {
        const r = t.length;
        let n, i, a;
        return !e || !e.state || (n = e.state, n.wrap !== 0 && n.mode !== In) ? Ce : n.mode === In && (i = 1, i = Qi(i, t, r, 0), i !== n.check) ? Ms : (a = qs(e, t, r, r), a ? (n.mode = Fs, Us) : (n.havedict = 1, Ut))
    };
Ke.inflateReset = Ks;
Ke.inflateReset2 = Ws;
Ke.inflateResetKeep = Hs;
Ke.inflateInit = pc;
Ke.inflateInit2 = Zs;
Ke.inflate = vc;
Ke.inflateEnd = yc;
Ke.inflateGetHeader = bc;
Ke.inflateSetDictionary = gc;
Ke.inflateInfo = "pako inflate (from Nodeca project)";

function wc() {
    this.text = 0, this.time = 0, this.xflags = 0, this.os = 0, this.extra = null, this.extra_len = 0, this.name = "", this.comment = "", this.hcrc = 0, this.done = !1
}
var xc = wc;
const ut = Ke,
    js = Hn,
    ea = tn,
    ta = ba,
    mc = Ps,
    Ec = xc,
    Gs = Object.prototype.toString,
    {
        Z_NO_FLUSH: Sc,
        Z_FINISH: Ac,
        Z_OK: Vr,
        Z_STREAM_END: Ri,
        Z_NEED_DICT: Oi,
        Z_STREAM_ERROR: kc,
        Z_DATA_ERROR: Oo,
        Z_MEM_ERROR: Tc
    } = Ht;

function nn(e) {
    this.options = js.assign({
        chunkSize: 1024 * 64,
        windowBits: 15,
        to: ""
    }, e || {});
    const t = this.options;
    t.raw && t.windowBits >= 0 && t.windowBits < 16 && (t.windowBits = -t.windowBits, t.windowBits === 0 && (t.windowBits = -15)), t.windowBits >= 0 && t.windowBits < 16 && !(e && e.windowBits) && (t.windowBits += 32), t.windowBits > 15 && t.windowBits < 48 && (t.windowBits & 15) === 0 && (t.windowBits |= 15), this.err = 0, this.msg = "", this.ended = !1, this.chunks = [], this.strm = new mc, this.strm.avail_out = 0;
    let r = ut.inflateInit2(this.strm, t.windowBits);
    if (r !== Vr) throw new Error(ta[r]);
    if (this.header = new Ec, ut.inflateGetHeader(this.strm, this.header), t.dictionary && (typeof t.dictionary == "string" ? t.dictionary = ea.string2buf(t.dictionary) : Gs.call(t.dictionary) === "[object ArrayBuffer]" && (t.dictionary = new Uint8Array(t.dictionary)), t.raw && (r = ut.inflateSetDictionary(this.strm, t.dictionary), r !== Vr))) throw new Error(ta[r])
}
nn.prototype.push = function(e, t) {
    const r = this.strm,
        n = this.options.chunkSize,
        i = this.options.dictionary;
    let a, o, s;
    if (this.ended) return !1;
    for (t === ~~t ? o = t : o = t === !0 ? Ac : Sc, Gs.call(e) === "[object ArrayBuffer]" ? r.input = new Uint8Array(e) : r.input = e, r.next_in = 0, r.avail_in = r.input.length;;) {
        for (r.avail_out === 0 && (r.output = new Uint8Array(n), r.next_out = 0, r.avail_out = n), a = ut.inflate(r, o), a === Oi && i && (a = ut.inflateSetDictionary(r, i), a === Vr ? a = ut.inflate(r, o) : a === Oo && (a = Oi)); r.avail_in > 0 && a === Ri && r.state.wrap > 0 && e[r.next_in] !== 0;) ut.inflateReset(r), a = ut.inflate(r, o);
        switch (a) {
            case kc:
            case Oo:
            case Oi:
            case Tc:
                return this.onEnd(a), this.ended = !0, !1
        }
        if (s = r.avail_out, r.next_out && (r.avail_out === 0 || a === Ri))
            if (this.options.to === "string") {
                let c = ea.utf8border(r.output, r.next_out),
                    u = r.next_out - c,
                    f = ea.buf2string(r.output, c);
                r.next_out = u, r.avail_out = n - u, u && r.output.set(r.output.subarray(c, c + u), 0), this.onData(f)
            } else this.onData(r.output.length === r.next_out ? r.output : r.output.subarray(0, r.next_out));
        if (!(a === Vr && s === 0)) {
            if (a === Ri) return a = ut.inflateEnd(this.strm), this.onEnd(a), this.ended = !0, !0;
            if (r.avail_in === 0) break
        }
    }
    return !0
};
nn.prototype.onData = function(e) {
    this.chunks.push(e)
};
nn.prototype.onEnd = function(e) {
    e === Vr && (this.options.to === "string" ? this.result = this.chunks.join("") : this.result = js.flattenChunks(this.chunks)), this.chunks = [], this.err = e, this.msg = this.strm.msg
};

function wa(e, t) {
    const r = new nn(t);
    if (r.push(e), r.err) throw r.msg || ta[r.err];
    return r.result
}

function zc(e, t) {
    return t = t || {}, t.raw = !0, wa(e, t)
}
hr.Inflate = nn;
hr.inflate = wa;
hr.inflateRaw = zc;
hr.ungzip = wa;
hr.constants = Ht;
const {
    Deflate: Rc,
    deflate: Oc,
    deflateRaw: Dc,
    gzip: Pc
} = ur, {
    Inflate: Cc,
    inflate: Nc,
    inflateRaw: Lc,
    ungzip: Ic
} = hr, Bc = Ht;
nt.Deflate = Rc;
nt.deflate = Oc;
nt.deflateRaw = Dc;
nt.gzip = Pc;
nt.Inflate = Cc;
nt.inflate = Nc;
nt.inflateRaw = Lc;
nt.ungzip = Ic;
nt.constants = Bc;
var xa = {},
    Kn = {},
    Vs = {},
    ne = {},
    an = Ys;

function Ys(e, t) {
    if (!e) throw new Error(t || "Assertion failed")
}
Ys.equal = function(t, r, n) {
    if (t != r) throw new Error(n || "Assertion failed: " + t + " != " + r)
};
var ye = {
    exports: {}
};
typeof Object.create == "function" ? ye.exports = function(t, r) {
    r && (t.super_ = r, t.prototype = Object.create(r.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }))
} : ye.exports = function(t, r) {
    if (r) {
        t.super_ = r;
        var n = function() {};
        n.prototype = r.prototype, t.prototype = new n, t.prototype.constructor = t
    }
};
var Mc = an,
    Uc = ye.exports;
ne.inherits = Uc;

function $c(e, t) {
    return (e.charCodeAt(t) & 64512) !== 55296 || t < 0 || t + 1 >= e.length ? !1 : (e.charCodeAt(t + 1) & 64512) === 56320
}

function Fc(e, t) {
    if (Array.isArray(e)) return e.slice();
    if (!e) return [];
    var r = [];
    if (typeof e == "string")
        if (t) {
            if (t === "hex")
                for (e = e.replace(/[^a-z0-9]+/ig, ""), e.length % 2 !== 0 && (e = "0" + e), i = 0; i < e.length; i += 2) r.push(parseInt(e[i] + e[i + 1], 16))
        } else
            for (var n = 0, i = 0; i < e.length; i++) {
                var a = e.charCodeAt(i);
                a < 128 ? r[n++] = a : a < 2048 ? (r[n++] = a >> 6 | 192, r[n++] = a & 63 | 128) : $c(e, i) ? (a = 65536 + ((a & 1023) << 10) + (e.charCodeAt(++i) & 1023), r[n++] = a >> 18 | 240, r[n++] = a >> 12 & 63 | 128, r[n++] = a >> 6 & 63 | 128, r[n++] = a & 63 | 128) : (r[n++] = a >> 12 | 224, r[n++] = a >> 6 & 63 | 128, r[n++] = a & 63 | 128)
            } else
                for (i = 0; i < e.length; i++) r[i] = e[i] | 0;
    return r
}
ne.toArray = Fc;

function Hc(e) {
    for (var t = "", r = 0; r < e.length; r++) t += Xs(e[r].toString(16));
    return t
}
ne.toHex = Hc;

function Js(e) {
    var t = e >>> 24 | e >>> 8 & 65280 | e << 8 & 16711680 | (e & 255) << 24;
    return t >>> 0
}
ne.htonl = Js;

function Kc(e, t) {
    for (var r = "", n = 0; n < e.length; n++) {
        var i = e[n];
        t === "little" && (i = Js(i)), r += Qs(i.toString(16))
    }
    return r
}
ne.toHex32 = Kc;

function Xs(e) {
    return e.length === 1 ? "0" + e : e
}
ne.zero2 = Xs;

function Qs(e) {
    return e.length === 7 ? "0" + e : e.length === 6 ? "00" + e : e.length === 5 ? "000" + e : e.length === 4 ? "0000" + e : e.length === 3 ? "00000" + e : e.length === 2 ? "000000" + e : e.length === 1 ? "0000000" + e : e
}
ne.zero8 = Qs;

function Wc(e, t, r, n) {
    var i = r - t;
    Mc(i % 4 === 0);
    for (var a = new Array(i / 4), o = 0, s = t; o < a.length; o++, s += 4) {
        var c;
        n === "big" ? c = e[s] << 24 | e[s + 1] << 16 | e[s + 2] << 8 | e[s + 3] : c = e[s + 3] << 24 | e[s + 2] << 16 | e[s + 1] << 8 | e[s], a[o] = c >>> 0
    }
    return a
}
ne.join32 = Wc;

function Zc(e, t) {
    for (var r = new Array(e.length * 4), n = 0, i = 0; n < e.length; n++, i += 4) {
        var a = e[n];
        t === "big" ? (r[i] = a >>> 24, r[i + 1] = a >>> 16 & 255, r[i + 2] = a >>> 8 & 255, r[i + 3] = a & 255) : (r[i + 3] = a >>> 24, r[i + 2] = a >>> 16 & 255, r[i + 1] = a >>> 8 & 255, r[i] = a & 255)
    }
    return r
}
ne.split32 = Zc;

function qc(e, t) {
    return e >>> t | e << 32 - t
}
ne.rotr32 = qc;

function jc(e, t) {
    return e << t | e >>> 32 - t
}
ne.rotl32 = jc;

function Gc(e, t) {
    return e + t >>> 0
}
ne.sum32 = Gc;

function Vc(e, t, r) {
    return e + t + r >>> 0
}
ne.sum32_3 = Vc;

function Yc(e, t, r, n) {
    return e + t + r + n >>> 0
}
ne.sum32_4 = Yc;

function Jc(e, t, r, n, i) {
    return e + t + r + n + i >>> 0
}
ne.sum32_5 = Jc;

function Xc(e, t, r, n) {
    var i = e[t],
        a = e[t + 1],
        o = n + a >>> 0,
        s = (o < n ? 1 : 0) + r + i;
    e[t] = s >>> 0, e[t + 1] = o
}
ne.sum64 = Xc;

function Qc(e, t, r, n) {
    var i = t + n >>> 0,
        a = (i < t ? 1 : 0) + e + r;
    return a >>> 0
}
ne.sum64_hi = Qc;

function eh(e, t, r, n) {
    var i = t + n;
    return i >>> 0
}
ne.sum64_lo = eh;

function th(e, t, r, n, i, a, o, s) {
    var c = 0,
        u = t;
    u = u + n >>> 0, c += u < t ? 1 : 0, u = u + a >>> 0, c += u < a ? 1 : 0, u = u + s >>> 0, c += u < s ? 1 : 0;
    var f = e + r + i + o + c;
    return f >>> 0
}
ne.sum64_4_hi = th;

function rh(e, t, r, n, i, a, o, s) {
    var c = t + n + a + s;
    return c >>> 0
}
ne.sum64_4_lo = rh;

function nh(e, t, r, n, i, a, o, s, c, u) {
    var f = 0,
        b = t;
    b = b + n >>> 0, f += b < t ? 1 : 0, b = b + a >>> 0, f += b < a ? 1 : 0, b = b + s >>> 0, f += b < s ? 1 : 0, b = b + u >>> 0, f += b < u ? 1 : 0;
    var _ = e + r + i + o + c + f;
    return _ >>> 0
}
ne.sum64_5_hi = nh;

function ih(e, t, r, n, i, a, o, s, c, u) {
    var f = t + n + a + s + u;
    return f >>> 0
}
ne.sum64_5_lo = ih;

function ah(e, t, r) {
    var n = t << 32 - r | e >>> r;
    return n >>> 0
}
ne.rotr64_hi = ah;

function oh(e, t, r) {
    var n = e << 32 - r | t >>> r;
    return n >>> 0
}
ne.rotr64_lo = oh;

function sh(e, t, r) {
    return e >>> r
}
ne.shr64_hi = sh;

function uh(e, t, r) {
    var n = e << 32 - r | t >>> r;
    return n >>> 0
}
ne.shr64_lo = uh;
var dr = {},
    Do = ne,
    lh = an;

function Wn() {
    this.pending = null, this.pendingTotal = 0, this.blockSize = this.constructor.blockSize, this.outSize = this.constructor.outSize, this.hmacStrength = this.constructor.hmacStrength, this.padLength = this.constructor.padLength / 8, this.endian = "big", this._delta8 = this.blockSize / 8, this._delta32 = this.blockSize / 32
}
dr.BlockHash = Wn;
Wn.prototype.update = function(t, r) {
    if (t = Do.toArray(t, r), this.pending ? this.pending = this.pending.concat(t) : this.pending = t, this.pendingTotal += t.length, this.pending.length >= this._delta8) {
        t = this.pending;
        var n = t.length % this._delta8;
        this.pending = t.slice(t.length - n, t.length), this.pending.length === 0 && (this.pending = null), t = Do.join32(t, 0, t.length - n, this.endian);
        for (var i = 0; i < t.length; i += this._delta32) this._update(t, i, i + this._delta32)
    }
    return this
};
Wn.prototype.digest = function(t) {
    return this.update(this._pad()), lh(this.pending === null), this._digest(t)
};
Wn.prototype._pad = function() {
    var t = this.pendingTotal,
        r = this._delta8,
        n = r - (t + this.padLength) % r,
        i = new Array(n + this.padLength);
    i[0] = 128;
    for (var a = 1; a < n; a++) i[a] = 0;
    if (t <<= 3, this.endian === "big") {
        for (var o = 8; o < this.padLength; o++) i[a++] = 0;
        i[a++] = 0, i[a++] = 0, i[a++] = 0, i[a++] = 0, i[a++] = t >>> 24 & 255, i[a++] = t >>> 16 & 255, i[a++] = t >>> 8 & 255, i[a++] = t & 255
    } else
        for (i[a++] = t & 255, i[a++] = t >>> 8 & 255, i[a++] = t >>> 16 & 255, i[a++] = t >>> 24 & 255, i[a++] = 0, i[a++] = 0, i[a++] = 0, i[a++] = 0, o = 8; o < this.padLength; o++) i[a++] = 0;
    return i
};
var pr = {},
    at = {},
    fh = ne,
    Ye = fh.rotr32;

function ch(e, t, r, n) {
    if (e === 0) return eu(t, r, n);
    if (e === 1 || e === 3) return ru(t, r, n);
    if (e === 2) return tu(t, r, n)
}
at.ft_1 = ch;

function eu(e, t, r) {
    return e & t ^ ~e & r
}
at.ch32 = eu;

function tu(e, t, r) {
    return e & t ^ e & r ^ t & r
}
at.maj32 = tu;

function ru(e, t, r) {
    return e ^ t ^ r
}
at.p32 = ru;

function hh(e) {
    return Ye(e, 2) ^ Ye(e, 13) ^ Ye(e, 22)
}
at.s0_256 = hh;

function dh(e) {
    return Ye(e, 6) ^ Ye(e, 11) ^ Ye(e, 25)
}
at.s1_256 = dh;

function ph(e) {
    return Ye(e, 7) ^ Ye(e, 18) ^ e >>> 3
}
at.g0_256 = ph;

function _h(e) {
    return Ye(e, 17) ^ Ye(e, 19) ^ e >>> 10
}
at.g1_256 = _h;
var ir = ne,
    vh = dr,
    yh = at,
    Di = ir.rotl32,
    Tr = ir.sum32,
    bh = ir.sum32_5,
    gh = yh.ft_1,
    nu = vh.BlockHash,
    wh = [1518500249, 1859775393, 2400959708, 3395469782];

function Qe() {
    if (!(this instanceof Qe)) return new Qe;
    nu.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.W = new Array(80)
}
ir.inherits(Qe, nu);
var xh = Qe;
Qe.blockSize = 512;
Qe.outSize = 160;
Qe.hmacStrength = 80;
Qe.padLength = 64;
Qe.prototype._update = function(t, r) {
    for (var n = this.W, i = 0; i < 16; i++) n[i] = t[r + i];
    for (; i < n.length; i++) n[i] = Di(n[i - 3] ^ n[i - 8] ^ n[i - 14] ^ n[i - 16], 1);
    var a = this.h[0],
        o = this.h[1],
        s = this.h[2],
        c = this.h[3],
        u = this.h[4];
    for (i = 0; i < n.length; i++) {
        var f = ~~(i / 20),
            b = bh(Di(a, 5), gh(f, o, s, c), u, n[i], wh[f]);
        u = c, c = s, s = Di(o, 30), o = a, a = b
    }
    this.h[0] = Tr(this.h[0], a), this.h[1] = Tr(this.h[1], o), this.h[2] = Tr(this.h[2], s), this.h[3] = Tr(this.h[3], c), this.h[4] = Tr(this.h[4], u)
};
Qe.prototype._digest = function(t) {
    return t === "hex" ? ir.toHex32(this.h, "big") : ir.split32(this.h, "big")
};
var ar = ne,
    mh = dr,
    _r = at,
    Eh = an,
    $e = ar.sum32,
    Sh = ar.sum32_4,
    Ah = ar.sum32_5,
    kh = _r.ch32,
    Th = _r.maj32,
    zh = _r.s0_256,
    Rh = _r.s1_256,
    Oh = _r.g0_256,
    Dh = _r.g1_256,
    iu = mh.BlockHash,
    Ph = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];

function et() {
    if (!(this instanceof et)) return new et;
    iu.call(this), this.h = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225], this.k = Ph, this.W = new Array(64)
}
ar.inherits(et, iu);
var au = et;
et.blockSize = 512;
et.outSize = 256;
et.hmacStrength = 192;
et.padLength = 64;
et.prototype._update = function(t, r) {
    for (var n = this.W, i = 0; i < 16; i++) n[i] = t[r + i];
    for (; i < n.length; i++) n[i] = Sh(Dh(n[i - 2]), n[i - 7], Oh(n[i - 15]), n[i - 16]);
    var a = this.h[0],
        o = this.h[1],
        s = this.h[2],
        c = this.h[3],
        u = this.h[4],
        f = this.h[5],
        b = this.h[6],
        _ = this.h[7];
    for (Eh(this.k.length === n.length), i = 0; i < n.length; i++) {
        var v = Ah(_, Rh(u), kh(u, f, b), this.k[i], n[i]),
            g = $e(zh(a), Th(a, o, s));
        _ = b, b = f, f = u, u = $e(c, v), c = s, s = o, o = a, a = $e(v, g)
    }
    this.h[0] = $e(this.h[0], a), this.h[1] = $e(this.h[1], o), this.h[2] = $e(this.h[2], s), this.h[3] = $e(this.h[3], c), this.h[4] = $e(this.h[4], u), this.h[5] = $e(this.h[5], f), this.h[6] = $e(this.h[6], b), this.h[7] = $e(this.h[7], _)
};
et.prototype._digest = function(t) {
    return t === "hex" ? ar.toHex32(this.h, "big") : ar.split32(this.h, "big")
};
var ra = ne,
    ou = au;

function lt() {
    if (!(this instanceof lt)) return new lt;
    ou.call(this), this.h = [3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428]
}
ra.inherits(lt, ou);
var Ch = lt;
lt.blockSize = 512;
lt.outSize = 224;
lt.hmacStrength = 192;
lt.padLength = 64;
lt.prototype._digest = function(t) {
    return t === "hex" ? ra.toHex32(this.h.slice(0, 7), "big") : ra.split32(this.h.slice(0, 7), "big")
};
var ze = ne,
    Nh = dr,
    Lh = an,
    Je = ze.rotr64_hi,
    Xe = ze.rotr64_lo,
    su = ze.shr64_hi,
    uu = ze.shr64_lo,
    pt = ze.sum64,
    Pi = ze.sum64_hi,
    Ci = ze.sum64_lo,
    Ih = ze.sum64_4_hi,
    Bh = ze.sum64_4_lo,
    Mh = ze.sum64_5_hi,
    Uh = ze.sum64_5_lo,
    lu = Nh.BlockHash,
    $h = [1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591];

function He() {
    if (!(this instanceof He)) return new He;
    lu.call(this), this.h = [1779033703, 4089235720, 3144134277, 2227873595, 1013904242, 4271175723, 2773480762, 1595750129, 1359893119, 2917565137, 2600822924, 725511199, 528734635, 4215389547, 1541459225, 327033209], this.k = $h, this.W = new Array(160)
}
ze.inherits(He, lu);
var fu = He;
He.blockSize = 1024;
He.outSize = 512;
He.hmacStrength = 192;
He.padLength = 128;
He.prototype._prepareBlock = function(t, r) {
    for (var n = this.W, i = 0; i < 32; i++) n[i] = t[r + i];
    for (; i < n.length; i += 2) {
        var a = Jh(n[i - 4], n[i - 3]),
            o = Xh(n[i - 4], n[i - 3]),
            s = n[i - 14],
            c = n[i - 13],
            u = Vh(n[i - 30], n[i - 29]),
            f = Yh(n[i - 30], n[i - 29]),
            b = n[i - 32],
            _ = n[i - 31];
        n[i] = Ih(a, o, s, c, u, f, b, _), n[i + 1] = Bh(a, o, s, c, u, f, b, _)
    }
};
He.prototype._update = function(t, r) {
    this._prepareBlock(t, r);
    var n = this.W,
        i = this.h[0],
        a = this.h[1],
        o = this.h[2],
        s = this.h[3],
        c = this.h[4],
        u = this.h[5],
        f = this.h[6],
        b = this.h[7],
        _ = this.h[8],
        v = this.h[9],
        g = this.h[10],
        k = this.h[11],
        O = this.h[12],
        z = this.h[13],
        P = this.h[14],
        L = this.h[15];
    Lh(this.k.length === n.length);
    for (var y = 0; y < n.length; y += 2) {
        var D = P,
            w = L,
            x = jh(_, v),
            A = Gh(_, v),
            U = Fh(_, v, g, k, O),
            N = Hh(_, v, g, k, O, z),
            F = this.k[y],
            W = this.k[y + 1],
            K = n[y],
            Z = n[y + 1],
            V = Mh(D, w, x, A, U, N, F, W, K, Z),
            ie = Uh(D, w, x, A, U, N, F, W, K, Z);
        D = Zh(i, a), w = qh(i, a), x = Kh(i, a, o, s, c), A = Wh(i, a, o, s, c, u);
        var re = Pi(D, w, x, A),
            I = Ci(D, w, x, A);
        P = O, L = z, O = g, z = k, g = _, k = v, _ = Pi(f, b, V, ie), v = Ci(b, b, V, ie), f = c, b = u, c = o, u = s, o = i, s = a, i = Pi(V, ie, re, I), a = Ci(V, ie, re, I)
    }
    pt(this.h, 0, i, a), pt(this.h, 2, o, s), pt(this.h, 4, c, u), pt(this.h, 6, f, b), pt(this.h, 8, _, v), pt(this.h, 10, g, k), pt(this.h, 12, O, z), pt(this.h, 14, P, L)
};
He.prototype._digest = function(t) {
    return t === "hex" ? ze.toHex32(this.h, "big") : ze.split32(this.h, "big")
};

function Fh(e, t, r, n, i) {
    var a = e & r ^ ~e & i;
    return a < 0 && (a += 4294967296), a
}

function Hh(e, t, r, n, i, a) {
    var o = t & n ^ ~t & a;
    return o < 0 && (o += 4294967296), o
}

function Kh(e, t, r, n, i) {
    var a = e & r ^ e & i ^ r & i;
    return a < 0 && (a += 4294967296), a
}

function Wh(e, t, r, n, i, a) {
    var o = t & n ^ t & a ^ n & a;
    return o < 0 && (o += 4294967296), o
}

function Zh(e, t) {
    var r = Je(e, t, 28),
        n = Je(t, e, 2),
        i = Je(t, e, 7),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function qh(e, t) {
    var r = Xe(e, t, 28),
        n = Xe(t, e, 2),
        i = Xe(t, e, 7),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function jh(e, t) {
    var r = Je(e, t, 14),
        n = Je(e, t, 18),
        i = Je(t, e, 9),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function Gh(e, t) {
    var r = Xe(e, t, 14),
        n = Xe(e, t, 18),
        i = Xe(t, e, 9),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function Vh(e, t) {
    var r = Je(e, t, 1),
        n = Je(e, t, 8),
        i = su(e, t, 7),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function Yh(e, t) {
    var r = Xe(e, t, 1),
        n = Xe(e, t, 8),
        i = uu(e, t, 7),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function Jh(e, t) {
    var r = Je(e, t, 19),
        n = Je(t, e, 29),
        i = su(e, t, 6),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}

function Xh(e, t) {
    var r = Xe(e, t, 19),
        n = Xe(t, e, 29),
        i = uu(e, t, 6),
        a = r ^ n ^ i;
    return a < 0 && (a += 4294967296), a
}
var na = ne,
    cu = fu;

function ft() {
    if (!(this instanceof ft)) return new ft;
    cu.call(this), this.h = [3418070365, 3238371032, 1654270250, 914150663, 2438529370, 812702999, 355462360, 4144912697, 1731405415, 4290775857, 2394180231, 1750603025, 3675008525, 1694076839, 1203062813, 3204075428]
}
na.inherits(ft, cu);
var Qh = ft;
ft.blockSize = 1024;
ft.outSize = 384;
ft.hmacStrength = 192;
ft.padLength = 128;
ft.prototype._digest = function(t) {
    return t === "hex" ? na.toHex32(this.h.slice(0, 12), "big") : na.split32(this.h.slice(0, 12), "big")
};
pr.sha1 = xh;
pr.sha224 = Ch;
pr.sha256 = au;
pr.sha384 = Qh;
pr.sha512 = fu;
var hu = {},
    $t = ne,
    ed = dr,
    Sn = $t.rotl32,
    Po = $t.sum32,
    zr = $t.sum32_3,
    Co = $t.sum32_4,
    du = ed.BlockHash;

function tt() {
    if (!(this instanceof tt)) return new tt;
    du.call(this), this.h = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], this.endian = "little"
}
$t.inherits(tt, du);
hu.ripemd160 = tt;
tt.blockSize = 512;
tt.outSize = 160;
tt.hmacStrength = 192;
tt.padLength = 64;
tt.prototype._update = function(t, r) {
    for (var n = this.h[0], i = this.h[1], a = this.h[2], o = this.h[3], s = this.h[4], c = n, u = i, f = a, b = o, _ = s, v = 0; v < 80; v++) {
        var g = Po(Sn(Co(n, No(v, i, a, o), t[nd[v] + r], td(v)), ad[v]), s);
        n = s, s = o, o = Sn(a, 10), a = i, i = g, g = Po(Sn(Co(c, No(79 - v, u, f, b), t[id[v] + r], rd(v)), od[v]), _), c = _, _ = b, b = Sn(f, 10), f = u, u = g
    }
    g = zr(this.h[1], a, b), this.h[1] = zr(this.h[2], o, _), this.h[2] = zr(this.h[3], s, c), this.h[3] = zr(this.h[4], n, u), this.h[4] = zr(this.h[0], i, f), this.h[0] = g
};
tt.prototype._digest = function(t) {
    return t === "hex" ? $t.toHex32(this.h, "little") : $t.split32(this.h, "little")
};

function No(e, t, r, n) {
    return e <= 15 ? t ^ r ^ n : e <= 31 ? t & r | ~t & n : e <= 47 ? (t | ~r) ^ n : e <= 63 ? t & n | r & ~n : t ^ (r | ~n)
}

function td(e) {
    return e <= 15 ? 0 : e <= 31 ? 1518500249 : e <= 47 ? 1859775393 : e <= 63 ? 2400959708 : 2840853838
}

function rd(e) {
    return e <= 15 ? 1352829926 : e <= 31 ? 1548603684 : e <= 47 ? 1836072691 : e <= 63 ? 2053994217 : 0
}
var nd = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13],
    id = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11],
    ad = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6],
    od = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11],
    sd = ne,
    ud = an;

function or(e, t, r) {
    if (!(this instanceof or)) return new or(e, t, r);
    this.Hash = e, this.blockSize = e.blockSize / 8, this.outSize = e.outSize / 8, this.inner = null, this.outer = null, this._init(sd.toArray(t, r))
}
var ld = or;
or.prototype._init = function(t) {
    t.length > this.blockSize && (t = new this.Hash().update(t).digest()), ud(t.length <= this.blockSize);
    for (var r = t.length; r < this.blockSize; r++) t.push(0);
    for (r = 0; r < t.length; r++) t[r] ^= 54;
    for (this.inner = new this.Hash().update(t), r = 0; r < t.length; r++) t[r] ^= 106;
    this.outer = new this.Hash().update(t)
};
or.prototype.update = function(t, r) {
    return this.inner.update(t, r), this
};
or.prototype.digest = function(t) {
    return this.outer.update(this.inner.digest()), this.outer.digest(t)
};
(function(e) {
    var t = e;
    t.utils = ne, t.common = dr, t.sha = pr, t.ripemd = hu, t.hmac = ld, t.sha1 = t.sha.sha1, t.sha256 = t.sha.sha256, t.sha224 = t.sha.sha224, t.sha384 = t.sha.sha384, t.sha512 = t.sha.sha512, t.ripemd160 = t.ripemd.ripemd160
})(Vs);
var fd = function() {
        function e(t, r) {
            var n = [],
                i = !0,
                a = !1,
                o = void 0;
            try {
                for (var s = t[Symbol.iterator](), c; !(i = (c = s.next()).done) && (n.push(c.value), !(r && n.length === r)); i = !0);
            } catch (u) {
                a = !0, o = u
            } finally {
                try {
                    !i && s.return && s.return()
                } finally {
                    if (a) throw o
                }
            }
            return n
        }
        return function(t, r) {
            if (Array.isArray(t)) return t;
            if (Symbol.iterator in Object(t)) return e(t, r);
            throw new TypeError("Invalid attempt to destructure non-iterable instance")
        }
    }(),
    cd = function() {
        function e(t, r) {
            for (var n = 0; n < r.length; n++) {
                var i = r[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
            }
        }
        return function(t, r, n) {
            return r && e(t.prototype, r), n && e(t, n), t
        }
    }();

function hd(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}
var dd = function() {
        function e() {
            hd(this, e)
        }
        return cd(e, null, [{
            key: "get_n_pad_bytes",
            value: function(r) {
                return 64 - (r + 8 & 63)
            }
        }, {
            key: "pad",
            value: function(r) {
                var n = r.byteLength,
                    i = e.get_n_pad_bytes(n),
                    a = function(v, g) {
                        return [Math.floor(v / g), v % g]
                    },
                    o = a(n, 536870912).map(function(_, v) {
                        return v ? _ * 8 : _
                    }),
                    s = fd(o, 2),
                    c = s[0],
                    u = s[1],
                    f = new Uint8Array(n + i + 8);
                f.set(new Uint8Array(r), 0);
                var b = new DataView(f.buffer);
                return b.setUint8(n, 128), b.setUint32(n + i, u, !0), b.setUint32(n + i + 4, c, !0), f.buffer
            }
        }, {
            key: "f",
            value: function(r, n, i, a) {
                if (0 <= r && r <= 15) return n ^ i ^ a;
                if (16 <= r && r <= 31) return n & i | ~n & a;
                if (32 <= r && r <= 47) return (n | ~i) ^ a;
                if (48 <= r && r <= 63) return n & a | i & ~a;
                if (64 <= r && r <= 79) return n ^ (i | ~a)
            }
        }, {
            key: "K",
            value: function(r) {
                if (0 <= r && r <= 15) return 0;
                if (16 <= r && r <= 31) return 1518500249;
                if (32 <= r && r <= 47) return 1859775393;
                if (48 <= r && r <= 63) return 2400959708;
                if (64 <= r && r <= 79) return 2840853838
            }
        }, {
            key: "KP",
            value: function(r) {
                if (0 <= r && r <= 15) return 1352829926;
                if (16 <= r && r <= 31) return 1548603684;
                if (32 <= r && r <= 47) return 1836072691;
                if (48 <= r && r <= 63) return 2053994217;
                if (64 <= r && r <= 79) return 0
            }
        }, {
            key: "add_modulo32",
            value: function() {
                return Array.from(arguments).reduce(function(r, n) {
                    return r + n
                }, 0) | 0
            }
        }, {
            key: "rol32",
            value: function(r, n) {
                return r << n | r >>> 32 - n
            }
        }, {
            key: "hash",
            value: function(r) {
                for (var n = e.pad(r), i = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13], a = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11], o = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6], s = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11], c = 4, u = 64, f = n.byteLength / u, b = new Array(f).fill(void 0).map(function(K, Z) {
                        return function(V) {
                            return new DataView(n, Z * u, u).getUint32(V * c, !0)
                        }
                    }), _ = [1732584193, 4023233417, 2562383102, 271733878, 3285377520], v = 0; v < f; ++v) {
                    for (var g = _[0], k = _[1], O = _[2], z = _[3], P = _[4], L = g, y = k, D = O, w = z, x = P, A = 0; A < 80; ++A) {
                        var U = e.add_modulo32(e.rol32(e.add_modulo32(g, e.f(A, k, O, z), b[v](i[A]), e.K(A)), o[A]), P);
                        g = P, P = z, z = e.rol32(O, 10), O = k, k = U, U = e.add_modulo32(e.rol32(e.add_modulo32(L, e.f(79 - A, y, D, w), b[v](a[A]), e.KP(A)), s[A]), x), L = x, x = w, w = e.rol32(D, 10), D = y, y = U
                    }
                    var N = e.add_modulo32(_[1], O, w);
                    _[1] = e.add_modulo32(_[2], z, x), _[2] = e.add_modulo32(_[3], P, L), _[3] = e.add_modulo32(_[4], g, y), _[4] = e.add_modulo32(_[0], k, D), _[0] = N
                }
                var F = new ArrayBuffer(20),
                    W = new DataView(F);
                return _.forEach(function(K, Z) {
                    return W.setUint32(Z * 4, K, !0)
                }), F
            }
        }]), e
    }(),
    pd = {
        RIPEMD160: dd
    };
(function(e) {
    var t = Y && Y.__read || function(h, m) {
            var S = typeof Symbol == "function" && h[Symbol.iterator];
            if (!S) return h;
            var C = S.call(h),
                $, M = [],
                H;
            try {
                for (;
                    (m === void 0 || m-- > 0) && !($ = C.next()).done;) M.push($.value)
            } catch (j) {
                H = {
                    error: j
                }
            } finally {
                try {
                    $ && !$.done && (S = C.return) && S.call(C)
                } finally {
                    if (H) throw H.error
                }
            }
            return M
        },
        r = Y && Y.__spreadArray || function(h, m) {
            for (var S = 0, C = m.length, $ = h.length; S < C; S++, $++) h[$] = m[S];
            return h
        },
        n = Y && Y.__values || function(h) {
            var m = typeof Symbol == "function" && Symbol.iterator,
                S = m && h[m],
                C = 0;
            if (S) return S.call(h);
            if (h && typeof h.length == "number") return {
                next: function() {
                    return h && C >= h.length && (h = void 0), {
                        value: h && h[C++],
                        done: !h
                    }
                }
            };
            throw new TypeError(m ? "Object is not iterable." : "Symbol.iterator is not defined.")
        };
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.signatureToString = e.stringToSignature = e.privateKeyToString = e.privateKeyToLegacyString = e.stringToPrivateKey = e.convertLegacyPublicKeys = e.convertLegacyPublicKey = e.publicKeyToString = e.publicKeyToLegacyString = e.stringToPublicKey = e.signatureDataSize = e.privateKeyDataSize = e.publicKeyDataSize = e.KeyType = e.base64ToBinary = e.binaryToBase58 = e.base58ToBinary = e.signedBinaryToDecimal = e.binaryToDecimal = e.signedDecimalToBinary = e.decimalToBinary = e.negate = e.isNegative = void 0;
    var i = Vs,
        a = pd.RIPEMD160.hash,
        o = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz",
        s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        c = function() {
            for (var h = Array(256).fill(-1), m = 0; m < o.length; ++m) h[o.charCodeAt(m)] = m;
            return h
        },
        u = c(),
        f = function() {
            for (var h = Array(256).fill(-1), m = 0; m < s.length; ++m) h[s.charCodeAt(m)] = m;
            return h["=".charCodeAt(0)] = 0, h
        },
        b = f(),
        _ = function(h) {
            return (h[h.length - 1] & 128) !== 0
        };
    e.isNegative = _;
    var v = function(h) {
        for (var m = 1, S = 0; S < h.length; ++S) {
            var C = (~h[S] & 255) + m;
            h[S] = C, m = C >> 8
        }
    };
    e.negate = v;
    var g = function(h, m) {
        for (var S = new Uint8Array(h), C = 0; C < m.length; ++C) {
            var $ = m.charCodeAt(C);
            if ($ < "0".charCodeAt(0) || $ > "9".charCodeAt(0)) throw new Error("invalid number");
            for (var M = $ - "0".charCodeAt(0), H = 0; H < h; ++H) {
                var j = S[H] * 10 + M;
                S[H] = j, M = j >> 8
            }
            if (M) throw new Error("number is out of range")
        }
        return S
    };
    e.decimalToBinary = g;
    var k = function(h, m) {
        var S = m[0] === "-";
        S && (m = m.substr(1));
        var C = e.decimalToBinary(h, m);
        if (S) {
            if (e.negate(C), !e.isNegative(C)) throw new Error("number is out of range")
        } else if (e.isNegative(C)) throw new Error("number is out of range");
        return C
    };
    e.signedDecimalToBinary = k;
    var O = function(h, m) {
        m === void 0 && (m = 1);
        for (var S = Array(m).fill("0".charCodeAt(0)), C = h.length - 1; C >= 0; --C) {
            for (var $ = h[C], M = 0; M < S.length; ++M) {
                var H = (S[M] - "0".charCodeAt(0) << 8) + $;
                S[M] = "0".charCodeAt(0) + H % 10, $ = H / 10 | 0
            }
            for (; $;) S.push("0".charCodeAt(0) + $ % 10), $ = $ / 10 | 0
        }
        return S.reverse(), String.fromCharCode.apply(String, r([], t(S)))
    };
    e.binaryToDecimal = O;
    var z = function(h, m) {
        if (m === void 0 && (m = 1), e.isNegative(h)) {
            var S = h.slice();
            return e.negate(S), "-" + e.binaryToDecimal(S, m)
        }
        return e.binaryToDecimal(h, m)
    };
    e.signedBinaryToDecimal = z;
    var P = function(h) {
            for (var m, S, C = [], $ = 0; $ < h.length; ++$) {
                var M = u[h.charCodeAt($)];
                if (M < 0) throw new Error("invalid base-58 value");
                for (var H = 0; H < C.length; ++H) {
                    var j = C[H] * 58 + M;
                    C[H] = j & 255, M = j >> 8
                }
                M && C.push(M)
            }
            try {
                for (var ee = n(h), ce = ee.next(); !ce.done; ce = ee.next()) {
                    var we = ce.value;
                    if (we === "1") C.push(0);
                    else break
                }
            } catch (ht) {
                m = {
                    error: ht
                }
            } finally {
                try {
                    ce && !ce.done && (S = ee.return) && S.call(ee)
                } finally {
                    if (m) throw m.error
                }
            }
            return C.reverse(), new Uint8Array(C)
        },
        L = function(h, m) {
            if (!h) return P(m);
            for (var S = new Uint8Array(h), C = 0; C < m.length; ++C) {
                var $ = u[m.charCodeAt(C)];
                if ($ < 0) throw new Error("invalid base-58 value");
                for (var M = 0; M < h; ++M) {
                    var H = S[M] * 58 + $;
                    S[M] = H, $ = H >> 8
                }
                if ($) throw new Error("base-58 value is out of range")
            }
            return S.reverse(), S
        };
    e.base58ToBinary = L;
    var y = function(h, m) {
        var S, C, $, M, H = [];
        try {
            for (var j = n(h), ee = j.next(); !ee.done; ee = j.next()) {
                for (var ce = ee.value, we = ce, ht = 0; ht < H.length; ++ht) {
                    var pn = (u[H[ht]] << 8) + we;
                    H[ht] = o.charCodeAt(pn % 58), we = pn / 58 | 0
                }
                for (; we;) H.push(o.charCodeAt(we % 58)), we = we / 58 | 0
            }
        } catch (xr) {
            S = {
                error: xr
            }
        } finally {
            try {
                ee && !ee.done && (C = j.return) && C.call(j)
            } finally {
                if (S) throw S.error
            }
        }
        try {
            for (var Gt = n(h), Ot = Gt.next(); !Ot.done; Ot = Gt.next()) {
                var ce = Ot.value;
                if (ce) break;
                H.push("1".charCodeAt(0))
            }
        } catch (xr) {
            $ = {
                error: xr
            }
        } finally {
            try {
                Ot && !Ot.done && (M = Gt.return) && M.call(Gt)
            } finally {
                if ($) throw $.error
            }
        }
        return H.reverse(), String.fromCharCode.apply(String, r([], t(H)))
    };
    e.binaryToBase58 = y;
    var D = function(h) {
        var m = h.length;
        if ((m & 3) === 1 && h[m - 1] === "=" && (m -= 1), (m & 3) !== 0) throw new Error("base-64 value is not padded correctly");
        var S = m >> 2,
            C = S * 3;
        m > 0 && h[m - 1] === "=" && (h[m - 2] === "=" ? C -= 2 : C -= 1);
        for (var $ = new Uint8Array(C), M = 0; M < S; ++M) {
            var H = b[h.charCodeAt(M * 4 + 0)],
                j = b[h.charCodeAt(M * 4 + 1)],
                ee = b[h.charCodeAt(M * 4 + 2)],
                ce = b[h.charCodeAt(M * 4 + 3)];
            $[M * 3 + 0] = H << 2 | j >> 4, M * 3 + 1 < C && ($[M * 3 + 1] = (j & 15) << 4 | ee >> 2), M * 3 + 2 < C && ($[M * 3 + 2] = (ee & 3) << 6 | ce)
        }
        return $
    };
    e.base64ToBinary = D;
    var w;
    (function(h) {
        h[h.k1 = 0] = "k1", h[h.r1 = 1] = "r1", h[h.wa = 2] = "wa"
    })(w = e.KeyType || (e.KeyType = {})), e.publicKeyDataSize = 33, e.privateKeyDataSize = 32, e.signatureDataSize = 65;
    var x = function(h, m) {
            for (var S = new Uint8Array(h.length + m.length), C = 0; C < h.length; ++C) S[C] = h[C];
            for (var C = 0; C < m.length; ++C) S[h.length + C] = m.charCodeAt(C);
            return a(S)
        },
        A = function(h, m, S, C) {
            var $ = e.base58ToBinary(S ? S + 4 : 0, h),
                M = {
                    type: m,
                    data: new Uint8Array($.buffer, 0, $.length - 4)
                },
                H = new Uint8Array(x(M.data, C));
            if (H[0] !== $[$.length - 4] || H[1] !== $[$.length - 3] || H[2] !== $[$.length - 2] || H[3] !== $[$.length - 1]) throw new Error("checksum doesn't match");
            return M
        },
        U = function(h, m, S) {
            for (var C = new Uint8Array(x(h.data, m)), $ = new Uint8Array(h.data.length + 4), M = 0; M < h.data.length; ++M) $[M] = h.data[M];
            for (var M = 0; M < 4; ++M) $[M + h.data.length] = C[M];
            return S + e.binaryToBase58($)
        },
        N = function(h) {
            if (typeof h != "string") throw new Error("expected string containing public key");
            if (h.substr(0, 3) === "EOS") {
                for (var m = e.base58ToBinary(e.publicKeyDataSize + 4, h.substr(3)), S = {
                        type: w.k1,
                        data: new Uint8Array(e.publicKeyDataSize)
                    }, C = 0; C < e.publicKeyDataSize; ++C) S.data[C] = m[C];
                var $ = new Uint8Array(a(S.data));
                if ($[0] !== m[e.publicKeyDataSize] || $[1] !== m[34] || $[2] !== m[35] || $[3] !== m[36]) throw new Error("checksum doesn't match");
                return S
            } else {
                if (h.substr(0, 7) === "PUB_K1_") return A(h.substr(7), w.k1, e.publicKeyDataSize, "K1");
                if (h.substr(0, 7) === "PUB_R1_") return A(h.substr(7), w.r1, e.publicKeyDataSize, "R1");
                if (h.substr(0, 7) === "PUB_WA_") return A(h.substr(7), w.wa, 0, "WA");
                throw new Error("unrecognized public key format")
            }
        };
    e.stringToPublicKey = N;
    var F = function(h) {
        if (h.type === w.k1 && h.data.length === e.publicKeyDataSize) return U(h, "", "EOS");
        throw h.type === w.r1 || h.type === w.wa ? new Error("Key format not supported in legacy conversion") : new Error("unrecognized public key format")
    };
    e.publicKeyToLegacyString = F;
    var W = function(h) {
        if (h.type === w.k1 && h.data.length === e.publicKeyDataSize) return U(h, "K1", "PUB_K1_");
        if (h.type === w.r1 && h.data.length === e.publicKeyDataSize) return U(h, "R1", "PUB_R1_");
        if (h.type === w.wa) return U(h, "WA", "PUB_WA_");
        throw new Error("unrecognized public key format")
    };
    e.publicKeyToString = W;
    var K = function(h) {
        return h.substr(0, 3) === "EOS" ? e.publicKeyToString(e.stringToPublicKey(h)) : h
    };
    e.convertLegacyPublicKey = K;
    var Z = function(h) {
        return h.map(e.convertLegacyPublicKey)
    };
    e.convertLegacyPublicKeys = Z;
    var V = function(h) {
        if (typeof h != "string") throw new Error("expected string containing private key");
        if (h.substr(0, 7) === "PVT_R1_") return A(h.substr(7), w.r1, e.privateKeyDataSize, "R1");
        if (h.substr(0, 7) === "PVT_K1_") return A(h.substr(7), w.k1, e.privateKeyDataSize, "K1");
        var m = e.base58ToBinary(e.privateKeyDataSize + 5, h),
            S = {
                type: w.k1,
                data: new Uint8Array(e.privateKeyDataSize)
            };
        if (m[0] !== 128) throw new Error("unrecognized private key type");
        for (var C = 0; C < e.privateKeyDataSize; ++C) S.data[C] = m[C + 1];
        return S
    };
    e.stringToPrivateKey = V;
    var ie = function(h) {
        if (h.type === w.k1 && h.data.length === e.privateKeyDataSize) {
            var m = [];
            m.push(128), h.data.forEach(function(M) {
                return m.push(M)
            });
            for (var S = new Uint8Array(i.sha256().update(i.sha256().update(m).digest()).digest()), C = new Uint8Array(e.privateKeyDataSize + 5), $ = 0; $ < m.length; $++) C[$] = m[$];
            for (var $ = 0; $ < 4; $++) C[$ + m.length] = S[$];
            return e.binaryToBase58(C)
        } else throw h.type === w.r1 || h.type === w.wa ? new Error("Key format not supported in legacy conversion") : new Error("unrecognized public key format")
    };
    e.privateKeyToLegacyString = ie;
    var re = function(h) {
        if (h.type === w.r1) return U(h, "R1", "PVT_R1_");
        if (h.type === w.k1) return U(h, "K1", "PVT_K1_");
        throw new Error("unrecognized private key format")
    };
    e.privateKeyToString = re;
    var I = function(h) {
        if (typeof h != "string") throw new Error("expected string containing signature");
        if (h.substr(0, 7) === "SIG_K1_") return A(h.substr(7), w.k1, e.signatureDataSize, "K1");
        if (h.substr(0, 7) === "SIG_R1_") return A(h.substr(7), w.r1, e.signatureDataSize, "R1");
        if (h.substr(0, 7) === "SIG_WA_") return A(h.substr(7), w.wa, 0, "WA");
        throw new Error("unrecognized signature format")
    };
    e.stringToSignature = I;
    var T = function(h) {
        if (h.type === w.k1) return U(h, "K1", "SIG_K1_");
        if (h.type === w.r1) return U(h, "R1", "SIG_R1_");
        if (h.type === w.wa) return U(h, "WA", "SIG_WA_");
        throw new Error("unrecognized signature format")
    };
    e.signatureToString = T
})(Kn);
(function(e) {
    var t = Y && Y.__assign || function() {
            return t = Object.assign || function(p) {
                for (var l, d = 1, E = arguments.length; d < E; d++) {
                    l = arguments[d];
                    for (var R in l) Object.prototype.hasOwnProperty.call(l, R) && (p[R] = l[R])
                }
                return p
            }, t.apply(this, arguments)
        },
        r = Y && Y.__read || function(p, l) {
            var d = typeof Symbol == "function" && p[Symbol.iterator];
            if (!d) return p;
            var E = d.call(p),
                R, B = [],
                q;
            try {
                for (;
                    (l === void 0 || l-- > 0) && !(R = E.next()).done;) B.push(R.value)
            } catch (G) {
                q = {
                    error: G
                }
            } finally {
                try {
                    R && !R.done && (d = E.return) && d.call(E)
                } finally {
                    if (q) throw q.error
                }
            }
            return B
        },
        n = Y && Y.__spreadArray || function(p, l) {
            for (var d = 0, E = l.length, R = p.length; d < E; d++, R++) p[R] = l[d];
            return p
        },
        i = Y && Y.__values || function(p) {
            var l = typeof Symbol == "function" && Symbol.iterator,
                d = l && p[l],
                E = 0;
            if (d) return d.call(p);
            if (p && typeof p.length == "number") return {
                next: function() {
                    return p && E >= p.length && (p = void 0), {
                        value: p && p[E++],
                        done: !p
                    }
                }
            };
            throw new TypeError(l ? "Object is not iterable." : "Symbol.iterator is not defined.")
        };
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.serializeQuery = e.deserializeAnyArray = e.serializeAnyArray = e.deserializeAnyObject = e.serializeAnyObject = e.deserializeAnyvarShort = e.deserializeAnyvar = e.serializeAnyvar = e.deserializeAction = e.deserializeActionData = e.serializeAction = e.serializeActionData = e.transactionHeader = e.getTypesFromAbi = e.getType = e.createTransactionTypes = e.createTransactionExtensionTypes = e.createAbiTypes = e.createInitialTypes = e.hexToUint8Array = e.arrayToHex = e.symbolToString = e.stringToSymbol = e.blockTimestampToDate = e.dateToBlockTimestamp = e.timePointSecToDate = e.dateToTimePointSec = e.timePointToDate = e.dateToTimePoint = e.supportedAbiVersion = e.SerialBuffer = e.SerializerState = void 0;
    var a = Kn,
        o = function() {
            function p(l) {
                l === void 0 && (l = {}), this.skippedBinaryExtension = !1, this.options = l
            }
            return p
        }();
    e.SerializerState = o;
    var s = function() {
        function p(l) {
            var d = l === void 0 ? {} : l,
                E = d.textEncoder,
                R = d.textDecoder,
                B = d.array;
            this.readPos = 0, this.array = B || new Uint8Array(1024), this.length = B ? B.length : 0, this.textEncoder = E || new TextEncoder, this.textDecoder = R || new TextDecoder("utf-8", {
                fatal: !0
            })
        }
        return p.prototype.reserve = function(l) {
            if (!(this.length + l <= this.array.length)) {
                for (var d = this.array.length; this.length + l > d;) d = Math.ceil(d * 1.5);
                var E = new Uint8Array(d);
                E.set(this.array), this.array = E
            }
        }, p.prototype.haveReadData = function() {
            return this.readPos < this.length
        }, p.prototype.restartRead = function() {
            this.readPos = 0
        }, p.prototype.asUint8Array = function() {
            return new Uint8Array(this.array.buffer, this.array.byteOffset, this.length)
        }, p.prototype.pushArray = function(l) {
            this.reserve(l.length), this.array.set(l, this.length), this.length += l.length
        }, p.prototype.push = function() {
            for (var l = [], d = 0; d < arguments.length; d++) l[d] = arguments[d];
            this.pushArray(l)
        }, p.prototype.get = function() {
            if (this.readPos < this.length) return this.array[this.readPos++];
            throw new Error("Read past end of buffer")
        }, p.prototype.pushUint8ArrayChecked = function(l, d) {
            if (l.length !== d) throw new Error("Binary data has incorrect size");
            this.pushArray(l)
        }, p.prototype.getUint8Array = function(l) {
            if (this.readPos + l > this.length) throw new Error("Read past end of buffer");
            var d = new Uint8Array(this.array.buffer, this.array.byteOffset + this.readPos, l);
            return this.readPos += l, d
        }, p.prototype.skip = function(l) {
            if (this.readPos + l > this.length) throw new Error("Read past end of buffer");
            this.readPos += l
        }, p.prototype.pushUint16 = function(l) {
            this.push(l >> 0 & 255, l >> 8 & 255)
        }, p.prototype.getUint16 = function() {
            var l = 0;
            return l |= this.get() << 0, l |= this.get() << 8, l
        }, p.prototype.pushUint32 = function(l) {
            this.push(l >> 0 & 255, l >> 8 & 255, l >> 16 & 255, l >> 24 & 255)
        }, p.prototype.getUint32 = function() {
            var l = 0;
            return l |= this.get() << 0, l |= this.get() << 8, l |= this.get() << 16, l |= this.get() << 24, l >>> 0
        }, p.prototype.pushNumberAsUint64 = function(l) {
            this.pushUint32(l >>> 0), this.pushUint32(Math.floor(l / 4294967296) >>> 0)
        }, p.prototype.getUint64AsNumber = function() {
            var l = this.getUint32(),
                d = this.getUint32();
            return (d >>> 0) * 4294967296 + (l >>> 0)
        }, p.prototype.pushVaruint32 = function(l) {
            for (;;)
                if (l >>> 7) this.push(128 | l & 127), l = l >>> 7;
                else {
                    this.push(l);
                    break
                }
        }, p.prototype.getVaruint32 = function() {
            for (var l = 0, d = 0;;) {
                var E = this.get();
                if (l |= (E & 127) << d, d += 7, !(E & 128)) break
            }
            return l >>> 0
        }, p.prototype.pushVarint32 = function(l) {
            this.pushVaruint32(l << 1 ^ l >> 31)
        }, p.prototype.getVarint32 = function() {
            var l = this.getVaruint32();
            return l & 1 ? ~l >> 1 | 2147483648 : l >>> 1
        }, p.prototype.pushFloat32 = function(l) {
            this.pushArray(new Uint8Array(new Float32Array([l]).buffer))
        }, p.prototype.getFloat32 = function() {
            return new Float32Array(this.getUint8Array(4).slice().buffer)[0]
        }, p.prototype.pushFloat64 = function(l) {
            this.pushArray(new Uint8Array(new Float64Array([l]).buffer))
        }, p.prototype.getFloat64 = function() {
            return new Float64Array(this.getUint8Array(8).slice().buffer)[0]
        }, p.prototype.pushName = function(l) {
            if (typeof l != "string") throw new Error("Expected string containing name");
            var d = new RegExp(/^[.1-5a-z]{0,12}[.1-5a-j]?$/);
            if (!d.test(l)) throw new Error("Name should be less than 13 characters, or less than 14 if last character is between 1-5 or a-j, and only contain the following symbols .12345abcdefghijklmnopqrstuvwxyz");
            for (var E = function(te) {
                    return te >= "a".charCodeAt(0) && te <= "z".charCodeAt(0) ? te - "a".charCodeAt(0) + 6 : te >= "1".charCodeAt(0) && te <= "5".charCodeAt(0) ? te - "1".charCodeAt(0) + 1 : 0
                }, R = new Uint8Array(8), B = 63, q = 0; q < l.length; ++q) {
                var G = E(l.charCodeAt(q));
                B < 5 && (G = G << 1);
                for (var J = 4; J >= 0; --J) B >= 0 && (R[Math.floor(B / 8)] |= (G >> J & 1) << B % 8, --B)
            }
            this.pushArray(R)
        }, p.prototype.getName = function() {
            for (var l = this.getUint8Array(8), d = "", E = 63; E >= 0;) {
                for (var R = 0, B = 0; B < 5; ++B) E >= 0 && (R = R << 1 | l[Math.floor(E / 8)] >> E % 8 & 1, --E);
                R >= 6 ? d += String.fromCharCode(R + "a".charCodeAt(0) - 6) : R >= 1 ? d += String.fromCharCode(R + "1".charCodeAt(0) - 1) : d += "."
            }
            for (; d.endsWith(".");) d = d.substr(0, d.length - 1);
            return d
        }, p.prototype.pushBytes = function(l) {
            this.pushVaruint32(l.length), this.pushArray(l)
        }, p.prototype.getBytes = function() {
            return this.getUint8Array(this.getVaruint32())
        }, p.prototype.pushString = function(l) {
            this.pushBytes(this.textEncoder.encode(l))
        }, p.prototype.getString = function() {
            return this.textDecoder.decode(this.getBytes())
        }, p.prototype.pushSymbolCode = function(l) {
            if (typeof l != "string") throw new Error("Expected string containing symbol_code");
            var d = [];
            for (d.push.apply(d, n([], r(this.textEncoder.encode(l)))); d.length < 8;) d.push(0);
            this.pushArray(d.slice(0, 8))
        }, p.prototype.getSymbolCode = function() {
            var l = this.getUint8Array(8),
                d;
            for (d = 0; d < l.length && l[d]; ++d);
            var E = this.textDecoder.decode(new Uint8Array(l.buffer, l.byteOffset, d));
            return E
        }, p.prototype.pushSymbol = function(l) {
            var d = l.name,
                E = l.precision;
            if (!/^[A-Z]{1,7}$/.test(d)) throw new Error("Expected symbol to be A-Z and between one and seven characters");
            var R = [E & 255];
            for (R.push.apply(R, n([], r(this.textEncoder.encode(d)))); R.length < 8;) R.push(0);
            this.pushArray(R.slice(0, 8))
        }, p.prototype.getSymbol = function() {
            var l = this.get(),
                d = this.getUint8Array(7),
                E;
            for (E = 0; E < d.length && d[E]; ++E);
            var R = this.textDecoder.decode(new Uint8Array(d.buffer, d.byteOffset, E));
            return {
                name: R,
                precision: l
            }
        }, p.prototype.pushAsset = function(l) {
            if (typeof l != "string") throw new Error("Expected string containing asset");
            l = l.trim();
            var d = 0,
                E = "",
                R = 0;
            l[d] === "-" && (E += "-", ++d);
            for (var B = !1; d < l.length && l.charCodeAt(d) >= "0".charCodeAt(0) && l.charCodeAt(d) <= "9".charCodeAt(0);) B = !0, E += l[d], ++d;
            if (!B) throw new Error("Asset must begin with a number");
            if (l[d] === ".")
                for (++d; d < l.length && l.charCodeAt(d) >= "0".charCodeAt(0) && l.charCodeAt(d) <= "9".charCodeAt(0);) E += l[d], ++R, ++d;
            var q = l.substr(d).trim();
            this.pushArray(a.signedDecimalToBinary(8, E)), this.pushSymbol({
                name: q,
                precision: R
            })
        }, p.prototype.getAsset = function() {
            var l = this.getUint8Array(8),
                d = this.getSymbol(),
                E = d.name,
                R = d.precision,
                B = a.signedBinaryToDecimal(l, R + 1);
            return R && (B = B.substr(0, B.length - R) + "." + B.substr(B.length - R)), B + " " + E
        }, p.prototype.pushPublicKey = function(l) {
            var d = a.stringToPublicKey(l);
            this.push(d.type), this.pushArray(d.data)
        }, p.prototype.getPublicKey = function() {
            var l = this.get(),
                d;
            if (l === a.KeyType.wa) {
                var E = this.readPos;
                this.skip(34), this.skip(this.getVaruint32()), d = new Uint8Array(this.array.buffer, this.array.byteOffset + E, this.readPos - E)
            } else d = this.getUint8Array(a.publicKeyDataSize);
            return a.publicKeyToString({
                type: l,
                data: d
            })
        }, p.prototype.pushPrivateKey = function(l) {
            var d = a.stringToPrivateKey(l);
            this.push(d.type), this.pushArray(d.data)
        }, p.prototype.getPrivateKey = function() {
            var l = this.get(),
                d = this.getUint8Array(a.privateKeyDataSize);
            return a.privateKeyToString({
                type: l,
                data: d
            })
        }, p.prototype.pushSignature = function(l) {
            var d = a.stringToSignature(l);
            this.push(d.type), this.pushArray(d.data)
        }, p.prototype.getSignature = function() {
            var l = this.get(),
                d;
            if (l === a.KeyType.wa) {
                var E = this.readPos;
                this.skip(65), this.skip(this.getVaruint32()), this.skip(this.getVaruint32()), d = new Uint8Array(this.array.buffer, this.array.byteOffset + E, this.readPos - E)
            } else d = this.getUint8Array(a.signatureDataSize);
            return a.signatureToString({
                type: l,
                data: d
            })
        }, p
    }();
    e.SerialBuffer = s;
    var c = function(p) {
        return p.startsWith("eosio::abi/1.")
    };
    e.supportedAbiVersion = c;
    var u = function(p) {
            var l = Date.parse(p);
            if (Number.isNaN(l)) throw new Error("Invalid time format");
            return l
        },
        f = function(p) {
            return Math.round(u(p + "Z") * 1e3)
        };
    e.dateToTimePoint = f;
    var b = function(p) {
        var l = new Date(p / 1e3).toISOString();
        return l.substr(0, l.length - 1)
    };
    e.timePointToDate = b;
    var _ = function(p) {
        return Math.round(u(p + "Z") / 1e3)
    };
    e.dateToTimePointSec = _;
    var v = function(p) {
        var l = new Date(p * 1e3).toISOString();
        return l.substr(0, l.length - 1)
    };
    e.timePointSecToDate = v;
    var g = function(p) {
        return Math.round((u(p + "Z") - 9466848e5) / 500)
    };
    e.dateToBlockTimestamp = g;
    var k = function(p) {
        var l = new Date(p * 500 + 9466848e5).toISOString();
        return l.substr(0, l.length - 1)
    };
    e.blockTimestampToDate = k;
    var O = function(p) {
        if (typeof p != "string") throw new Error("Expected string containing symbol");
        var l = p.match(/^([0-9]+),([A-Z]+)$/);
        if (!l) throw new Error("Invalid symbol");
        return {
            name: l[2],
            precision: +l[1]
        }
    };
    e.stringToSymbol = O;
    var z = function(p) {
        var l = p.name,
            d = p.precision;
        return d + "," + l
    };
    e.symbolToString = z;
    var P = function(p) {
        var l, d, E = "";
        try {
            for (var R = i(p), B = R.next(); !B.done; B = R.next()) {
                var q = B.value;
                E += ("00" + q.toString(16)).slice(-2)
            }
        } catch (G) {
            l = {
                error: G
            }
        } finally {
            try {
                B && !B.done && (d = R.return) && d.call(R)
            } finally {
                if (l) throw l.error
            }
        }
        return E.toUpperCase()
    };
    e.arrayToHex = P;
    var L = function(p) {
        if (typeof p != "string") throw new Error("Expected string containing hex digits");
        if (p.length % 2) throw new Error("Odd number of hex digits");
        for (var l = p.length / 2, d = new Uint8Array(l), E = 0; E < l; ++E) {
            var R = parseInt(p.substr(E * 2, 2), 16);
            if (Number.isNaN(R)) throw new Error("Expected hex string");
            d[E] = R
        }
        return d
    };
    e.hexToUint8Array = L;

    function y(p, l) {
        throw new Error("Don't know how to serialize " + this.name)
    }

    function D(p) {
        throw new Error("Don't know how to deserialize " + this.name)
    }

    function w(p, l, d, E) {
        var R, B;
        if (d === void 0 && (d = new o), E === void 0 && (E = !0), typeof l != "object") throw new Error("expected object containing data: " + JSON.stringify(l));
        this.base && this.base.serialize(p, l, d, E);
        try {
            for (var q = i(this.fields), G = q.next(); !G.done; G = q.next()) {
                var J = G.value;
                if (J.name in l) {
                    if (d.skippedBinaryExtension) throw new Error("unexpected " + this.name + "." + J.name);
                    J.type.serialize(p, l[J.name], d, E && J === this.fields[this.fields.length - 1])
                } else if (E && J.type.extensionOf) d.skippedBinaryExtension = !0;
                else throw new Error("missing " + this.name + "." + J.name + " (type=" + J.type.name + ")")
            }
        } catch (te) {
            R = {
                error: te
            }
        } finally {
            try {
                G && !G.done && (B = q.return) && B.call(q)
            } finally {
                if (R) throw R.error
            }
        }
    }

    function x(p, l, d) {
        var E, R;
        l === void 0 && (l = new o), d === void 0 && (d = !0);
        var B;
        this.base ? B = this.base.deserialize(p, l, d) : B = {};
        try {
            for (var q = i(this.fields), G = q.next(); !G.done; G = q.next()) {
                var J = G.value;
                d && J.type.extensionOf && !p.haveReadData() ? l.skippedBinaryExtension = !0 : B[J.name] = J.type.deserialize(p, l, d)
            }
        } catch (te) {
            E = {
                error: te
            }
        } finally {
            try {
                G && !G.done && (R = q.return) && R.call(q)
            } finally {
                if (E) throw E.error
            }
        }
        return B
    }

    function A(p, l, d, E) {
        if (!Array.isArray(l) || l.length !== 2 || typeof l[0] != "string") throw new Error('expected variant: ["type", value]');
        var R = this.fields.findIndex(function(B) {
            return B.name === l[0]
        });
        if (R < 0) throw new Error('type "' + l[0] + '" is not valid for variant');
        p.pushVaruint32(R), this.fields[R].type.serialize(p, l[1], d, E)
    }

    function U(p, l, d) {
        var E = p.getVaruint32();
        if (E >= this.fields.length) throw new Error("type index " + E + " is not valid for variant");
        var R = this.fields[E];
        return [R.name, R.type.deserialize(p, l, d)]
    }

    function N(p, l, d, E) {
        var R, B;
        p.pushVaruint32(l.length);
        try {
            for (var q = i(l), G = q.next(); !G.done; G = q.next()) {
                var J = G.value;
                this.arrayOf.serialize(p, J, d, !1)
            }
        } catch (te) {
            R = {
                error: te
            }
        } finally {
            try {
                G && !G.done && (B = q.return) && B.call(q)
            } finally {
                if (R) throw R.error
            }
        }
    }

    function F(p, l, d) {
        for (var E = p.getVaruint32(), R = [], B = 0; B < E; ++B) R.push(this.arrayOf.deserialize(p, l, !1));
        return R
    }

    function W(p, l, d, E) {
        l == null ? p.push(0) : (p.push(1), this.optionalOf.serialize(p, l, d, E))
    }

    function K(p, l, d) {
        return p.get() ? this.optionalOf.deserialize(p, l, d) : null
    }

    function Z(p, l, d, E) {
        this.extensionOf.serialize(p, l, d, E)
    }

    function V(p, l, d) {
        return this.extensionOf.deserialize(p, l, d)
    }

    function ie(p, l, d, E) {
        var R, B, q = Object.entries(l);
        p.pushVaruint32(q.length);
        try {
            for (var G = i(q), J = G.next(); !J.done; J = G.next()) {
                var te = r(J.value, 2),
                    de = te[0],
                    Ze = te[1],
                    Ue = this.fields[0].type,
                    dt = this.fields[1].type;
                Ue.serialize(p, de, d, E), dt.serialize(p, Ze, d, E)
            }
        } catch (Dt) {
            R = {
                error: Dt
            }
        } finally {
            try {
                J && !J.done && (B = G.return) && B.call(G)
            } finally {
                if (R) throw R.error
            }
        }
    }

    function re(p, l, d) {
        for (var E = p.getVaruint32(), R = {}, B = 0; B < E; ++B) {
            var q = this.fields[0].type,
                G = this.fields[1].type,
                J = q.deserialize(p, l, d);
            R[J] = G.deserialize(p, l, d)
        }
        return R
    }

    function I(p, l, d, E) {
        var R = this;
        p.pushVaruint32(l.length), l.forEach(function(B) {
            R.fields[0].type.serialize(p, B[0], d, E), R.fields[1].type.serialize(p, B[1], d, E)
        })
    }

    function T(p, l, d) {
        for (var E = [], R = p.getVaruint32(), B = 0; B < R; ++B) E.push(this.fields[0].type.deserialize(p, l, d)), E.push(this.fields[1].type.deserialize(p, l, d));
        return E
    }
    var h = function(p) {
            return t({
                name: "<missing name>",
                aliasOfName: "",
                arrayOf: null,
                optionalOf: null,
                extensionOf: null,
                baseName: "",
                base: null,
                fields: [],
                serialize: y,
                deserialize: D
            }, p)
        },
        m = function(p, l) {
            if (Number.isNaN(+p) || Number.isNaN(+l) || typeof p != "number" && typeof p != "string") throw new Error("Expected number");
            if (+p != +l) throw new Error("Number is out of range");
            return +p
        },
        S = function() {
            var p = new Map(Object.entries({
                bool: h({
                    name: "bool",
                    serialize: function(l, d) {
                        if (!(typeof d == "boolean" || typeof d == "number" && (d === 1 || d === 0))) throw new Error("Expected boolean or number equal to 1 or 0");
                        l.push(d ? 1 : 0)
                    },
                    deserialize: function(l) {
                        return !!l.get()
                    }
                }),
                uint8: h({
                    name: "uint8",
                    serialize: function(l, d) {
                        l.push(m(d, d & 255))
                    },
                    deserialize: function(l) {
                        return l.get()
                    }
                }),
                int8: h({
                    name: "int8",
                    serialize: function(l, d) {
                        l.push(m(d, d << 24 >> 24))
                    },
                    deserialize: function(l) {
                        return l.get() << 24 >> 24
                    }
                }),
                uint16: h({
                    name: "uint16",
                    serialize: function(l, d) {
                        l.pushUint16(m(d, d & 65535))
                    },
                    deserialize: function(l) {
                        return l.getUint16()
                    }
                }),
                int16: h({
                    name: "int16",
                    serialize: function(l, d) {
                        l.pushUint16(m(d, d << 16 >> 16))
                    },
                    deserialize: function(l) {
                        return l.getUint16() << 16 >> 16
                    }
                }),
                uint32: h({
                    name: "uint32",
                    serialize: function(l, d) {
                        l.pushUint32(m(d, d >>> 0))
                    },
                    deserialize: function(l) {
                        return l.getUint32()
                    }
                }),
                uint64: h({
                    name: "uint64",
                    serialize: function(l, d) {
                        l.pushArray(a.decimalToBinary(8, "" + d))
                    },
                    deserialize: function(l) {
                        return a.binaryToDecimal(l.getUint8Array(8))
                    }
                }),
                int64: h({
                    name: "int64",
                    serialize: function(l, d) {
                        l.pushArray(a.signedDecimalToBinary(8, "" + d))
                    },
                    deserialize: function(l) {
                        return a.signedBinaryToDecimal(l.getUint8Array(8))
                    }
                }),
                int32: h({
                    name: "int32",
                    serialize: function(l, d) {
                        l.pushUint32(m(d, d | 0))
                    },
                    deserialize: function(l) {
                        return l.getUint32() | 0
                    }
                }),
                varuint32: h({
                    name: "varuint32",
                    serialize: function(l, d) {
                        l.pushVaruint32(m(d, d >>> 0))
                    },
                    deserialize: function(l) {
                        return l.getVaruint32()
                    }
                }),
                varint32: h({
                    name: "varint32",
                    serialize: function(l, d) {
                        l.pushVarint32(m(d, d | 0))
                    },
                    deserialize: function(l) {
                        return l.getVarint32()
                    }
                }),
                uint128: h({
                    name: "uint128",
                    serialize: function(l, d) {
                        l.pushArray(a.decimalToBinary(16, "" + d))
                    },
                    deserialize: function(l) {
                        return a.binaryToDecimal(l.getUint8Array(16))
                    }
                }),
                int128: h({
                    name: "int128",
                    serialize: function(l, d) {
                        l.pushArray(a.signedDecimalToBinary(16, "" + d))
                    },
                    deserialize: function(l) {
                        return a.signedBinaryToDecimal(l.getUint8Array(16))
                    }
                }),
                float32: h({
                    name: "float32",
                    serialize: function(l, d) {
                        l.pushFloat32(d)
                    },
                    deserialize: function(l) {
                        return l.getFloat32()
                    }
                }),
                float64: h({
                    name: "float64",
                    serialize: function(l, d) {
                        l.pushFloat64(d)
                    },
                    deserialize: function(l) {
                        return l.getFloat64()
                    }
                }),
                float128: h({
                    name: "float128",
                    serialize: function(l, d) {
                        l.pushUint8ArrayChecked(e.hexToUint8Array(d), 16)
                    },
                    deserialize: function(l) {
                        return e.arrayToHex(l.getUint8Array(16))
                    }
                }),
                bytes: h({
                    name: "bytes",
                    serialize: function(l, d) {
                        d instanceof Uint8Array || Array.isArray(d) ? l.pushBytes(d) : l.pushBytes(e.hexToUint8Array(d))
                    },
                    deserialize: function(l, d) {
                        return d && d.options.bytesAsUint8Array ? l.getBytes() : e.arrayToHex(l.getBytes())
                    }
                }),
                string: h({
                    name: "string",
                    serialize: function(l, d) {
                        l.pushString(d)
                    },
                    deserialize: function(l) {
                        return l.getString()
                    }
                }),
                name: h({
                    name: "name",
                    serialize: function(l, d) {
                        l.pushName(d)
                    },
                    deserialize: function(l) {
                        return l.getName()
                    }
                }),
                time_point: h({
                    name: "time_point",
                    serialize: function(l, d) {
                        l.pushNumberAsUint64(e.dateToTimePoint(d))
                    },
                    deserialize: function(l) {
                        return e.timePointToDate(l.getUint64AsNumber())
                    }
                }),
                time_point_sec: h({
                    name: "time_point_sec",
                    serialize: function(l, d) {
                        l.pushUint32(e.dateToTimePointSec(d))
                    },
                    deserialize: function(l) {
                        return e.timePointSecToDate(l.getUint32())
                    }
                }),
                block_timestamp_type: h({
                    name: "block_timestamp_type",
                    serialize: function(l, d) {
                        l.pushUint32(e.dateToBlockTimestamp(d))
                    },
                    deserialize: function(l) {
                        return e.blockTimestampToDate(l.getUint32())
                    }
                }),
                symbol_code: h({
                    name: "symbol_code",
                    serialize: function(l, d) {
                        l.pushSymbolCode(d)
                    },
                    deserialize: function(l) {
                        return l.getSymbolCode()
                    }
                }),
                symbol: h({
                    name: "symbol",
                    serialize: function(l, d) {
                        l.pushSymbol(e.stringToSymbol(d))
                    },
                    deserialize: function(l) {
                        return e.symbolToString(l.getSymbol())
                    }
                }),
                asset: h({
                    name: "asset",
                    serialize: function(l, d) {
                        l.pushAsset(d)
                    },
                    deserialize: function(l) {
                        return l.getAsset()
                    }
                }),
                checksum160: h({
                    name: "checksum160",
                    serialize: function(l, d) {
                        l.pushUint8ArrayChecked(e.hexToUint8Array(d), 20)
                    },
                    deserialize: function(l) {
                        return e.arrayToHex(l.getUint8Array(20))
                    }
                }),
                checksum256: h({
                    name: "checksum256",
                    serialize: function(l, d) {
                        l.pushUint8ArrayChecked(e.hexToUint8Array(d), 32)
                    },
                    deserialize: function(l) {
                        return e.arrayToHex(l.getUint8Array(32))
                    }
                }),
                checksum512: h({
                    name: "checksum512",
                    serialize: function(l, d) {
                        l.pushUint8ArrayChecked(e.hexToUint8Array(d), 64)
                    },
                    deserialize: function(l) {
                        return e.arrayToHex(l.getUint8Array(64))
                    }
                }),
                public_key: h({
                    name: "public_key",
                    serialize: function(l, d) {
                        l.pushPublicKey(d)
                    },
                    deserialize: function(l) {
                        return l.getPublicKey()
                    }
                }),
                private_key: h({
                    name: "private_key",
                    serialize: function(l, d) {
                        l.pushPrivateKey(d)
                    },
                    deserialize: function(l) {
                        return l.getPrivateKey()
                    }
                }),
                signature: h({
                    name: "signature",
                    serialize: function(l, d) {
                        l.pushSignature(d)
                    },
                    deserialize: function(l) {
                        return l.getSignature()
                    }
                })
            }));
            return p.set("extended_asset", h({
                name: "extended_asset",
                baseName: "",
                fields: [{
                    name: "quantity",
                    typeName: "asset",
                    type: p.get("asset")
                }, {
                    name: "contract",
                    typeName: "name",
                    type: p.get("name")
                }],
                serialize: w,
                deserialize: x
            })), p
        };
    e.createInitialTypes = S;
    var C = function() {
        var p = e.createInitialTypes();
        return p.set("extensions_entry", h({
            name: "extensions_entry",
            baseName: "",
            fields: [{
                name: "tag",
                typeName: "uint16",
                type: null
            }, {
                name: "value",
                typeName: "bytes",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("type_def", h({
            name: "type_def",
            baseName: "",
            fields: [{
                name: "new_type_name",
                typeName: "string",
                type: null
            }, {
                name: "type",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("field_def", h({
            name: "field_def",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "string",
                type: null
            }, {
                name: "type",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("struct_def", h({
            name: "struct_def",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "string",
                type: null
            }, {
                name: "base",
                typeName: "string",
                type: null
            }, {
                name: "fields",
                typeName: "field_def[]",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("action_def", h({
            name: "action_def",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "type",
                typeName: "string",
                type: null
            }, {
                name: "ricardian_contract",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("table_def", h({
            name: "table_def",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "index_type",
                typeName: "string",
                type: null
            }, {
                name: "key_names",
                typeName: "string[]",
                type: null
            }, {
                name: "key_types",
                typeName: "string[]",
                type: null
            }, {
                name: "type",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("clause_pair", h({
            name: "clause_pair",
            baseName: "",
            fields: [{
                name: "id",
                typeName: "string",
                type: null
            }, {
                name: "body",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("error_message", h({
            name: "error_message",
            baseName: "",
            fields: [{
                name: "error_code",
                typeName: "uint64",
                type: null
            }, {
                name: "error_msg",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("variant_def", h({
            name: "variant_def",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "string",
                type: null
            }, {
                name: "types",
                typeName: "string[]",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("action_result", h({
            name: "action_result",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "result_type",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("primary_key_index_def", h({
            name: "primary_key_index_def",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "type",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("secondary_index_def", h({
            name: "secondary_index_def",
            baseName: "",
            fields: [{
                name: "type",
                typeName: "string",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("secondary_indices", h({
            name: "secondary_indices",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "secondary_index_def",
                typeName: "secondary_index_def",
                type: null
            }],
            serialize: ie,
            deserialize: re
        })), p.set("kv_table_entry_def", h({
            name: "kv_table_entry_def",
            baseName: "",
            fields: [{
                name: "type",
                typeName: "string",
                type: null
            }, {
                name: "primary_index",
                typeName: "primary_key_index_def",
                type: null
            }, {
                name: "secondary_indices",
                typeName: "secondary_indices",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("kv_table", h({
            name: "kv_table",
            baseName: "",
            fields: [{
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "kv_table_entry_def",
                typeName: "kv_table_entry_def",
                type: null
            }],
            serialize: ie,
            deserialize: re
        })), p.set("abi_def", h({
            name: "abi_def",
            baseName: "",
            fields: [{
                name: "version",
                typeName: "string",
                type: null
            }, {
                name: "types",
                typeName: "type_def[]",
                type: null
            }, {
                name: "structs",
                typeName: "struct_def[]",
                type: null
            }, {
                name: "actions",
                typeName: "action_def[]",
                type: null
            }, {
                name: "tables",
                typeName: "table_def[]",
                type: null
            }, {
                name: "ricardian_clauses",
                typeName: "clause_pair[]",
                type: null
            }, {
                name: "error_messages",
                typeName: "error_message[]",
                type: null
            }, {
                name: "abi_extensions",
                typeName: "extensions_entry[]",
                type: null
            }, {
                name: "variants",
                typeName: "variant_def[]$",
                type: null
            }, {
                name: "action_results",
                typeName: "action_result[]$",
                type: null
            }, {
                name: "kv_tables",
                typeName: "kv_table$",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p
    };
    e.createAbiTypes = C;
    var $ = function() {
        var p = e.createInitialTypes();
        return p.set("resource_payer", h({
            name: "resource_payer",
            baseName: "",
            fields: [{
                name: "payer",
                typeName: "name",
                type: null
            }, {
                name: "max_net_bytes",
                typeName: "uint64",
                type: null
            }, {
                name: "max_cpu_us",
                typeName: "uint64",
                type: null
            }, {
                name: "max_memory_bytes",
                typeName: "uint64",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p
    };
    e.createTransactionExtensionTypes = $;
    var M = function() {
        var p = e.createInitialTypes();
        return p.set("permission_level", h({
            name: "permission_level",
            baseName: "",
            fields: [{
                name: "actor",
                typeName: "name",
                type: null
            }, {
                name: "permission",
                typeName: "name",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("action", h({
            name: "action",
            baseName: "",
            fields: [{
                name: "account",
                typeName: "name",
                type: null
            }, {
                name: "name",
                typeName: "name",
                type: null
            }, {
                name: "authorization",
                typeName: "permission_level[]",
                type: null
            }, {
                name: "data",
                typeName: "bytes",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("extension", h({
            name: "extension",
            baseName: "",
            fields: [{
                name: "type",
                typeName: "uint16",
                type: null
            }, {
                name: "data",
                typeName: "bytes",
                type: null
            }],
            serialize: I,
            deserialize: T
        })), p.set("transaction_header", h({
            name: "transaction_header",
            baseName: "",
            fields: [{
                name: "expiration",
                typeName: "time_point_sec",
                type: null
            }, {
                name: "ref_block_num",
                typeName: "uint16",
                type: null
            }, {
                name: "ref_block_prefix",
                typeName: "uint32",
                type: null
            }, {
                name: "max_net_usage_words",
                typeName: "varuint32",
                type: null
            }, {
                name: "max_cpu_usage_ms",
                typeName: "uint8",
                type: null
            }, {
                name: "delay_sec",
                typeName: "varuint32",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p.set("transaction", h({
            name: "transaction",
            baseName: "transaction_header",
            fields: [{
                name: "context_free_actions",
                typeName: "action[]",
                type: null
            }, {
                name: "actions",
                typeName: "action[]",
                type: null
            }, {
                name: "transaction_extensions",
                typeName: "extension",
                type: null
            }],
            serialize: w,
            deserialize: x
        })), p
    };
    e.createTransactionTypes = M;
    var H = function(p, l) {
        var d = p.get(l);
        if (d && d.aliasOfName) return e.getType(p, d.aliasOfName);
        if (d) return d;
        if (l.endsWith("[]")) return h({
            name: l,
            arrayOf: e.getType(p, l.substr(0, l.length - 2)),
            serialize: N,
            deserialize: F
        });
        if (l.endsWith("?")) return h({
            name: l,
            optionalOf: e.getType(p, l.substr(0, l.length - 1)),
            serialize: W,
            deserialize: K
        });
        if (l.endsWith("$")) return h({
            name: l,
            extensionOf: e.getType(p, l.substr(0, l.length - 1)),
            serialize: Z,
            deserialize: V
        });
        throw new Error("Unknown type: " + l)
    };
    e.getType = H;
    var j = function(p, l) {
        var d, E, R, B, q, G, J, te, de, Ze, Ue = new Map(p);
        if (l && l.types) try {
            for (var dt = i(l.types), Dt = dt.next(); !Dt.done; Dt = dt.next()) {
                var Ba = Dt.value,
                    Ma = Ba.new_type_name,
                    Vt = Ba.type;
                Ue.set(Ma, h({
                    name: Ma,
                    aliasOfName: Vt
                }))
            }
        } catch (Re) {
            d = {
                error: Re
            }
        } finally {
            try {
                Dt && !Dt.done && (E = dt.return) && E.call(dt)
            } finally {
                if (d) throw d.error
            }
        }
        if (l && l.structs) try {
            for (var _n = i(l.structs), mr = _n.next(); !mr.done; mr = _n.next()) {
                var _i = mr.value,
                    Ua = _i.name,
                    xl = _i.base,
                    ml = _i.fields;
                Ue.set(Ua, h({
                    name: Ua,
                    baseName: xl,
                    fields: ml.map(function(Re) {
                        var vi = Re.name,
                            Sl = Re.type;
                        return {
                            name: vi,
                            typeName: Sl,
                            type: null
                        }
                    }),
                    serialize: w,
                    deserialize: x
                }))
            }
        } catch (Re) {
            R = {
                error: Re
            }
        } finally {
            try {
                mr && !mr.done && (B = _n.return) && B.call(_n)
            } finally {
                if (R) throw R.error
            }
        }
        if (l && l.variants) try {
            for (var vn = i(l.variants), Er = vn.next(); !Er.done; Er = vn.next()) {
                var $a = Er.value,
                    Fa = $a.name,
                    El = $a.types;
                Ue.set(Fa, h({
                    name: Fa,
                    fields: El.map(function(Re) {
                        return {
                            name: Re,
                            typeName: Re,
                            type: null
                        }
                    }),
                    serialize: A,
                    deserialize: U
                }))
            }
        } catch (Re) {
            q = {
                error: Re
            }
        } finally {
            try {
                Er && !Er.done && (G = vn.return) && G.call(vn)
            } finally {
                if (q) throw q.error
            }
        }
        try {
            for (var yn = i(Ue), Sr = yn.next(); !Sr.done; Sr = yn.next()) {
                var Ha = r(Sr.value, 2),
                    Z_ = Ha[0],
                    Vt = Ha[1];
                Vt.baseName && (Vt.base = e.getType(Ue, Vt.baseName));
                try {
                    for (var bn = (de = void 0, i(Vt.fields)), Ar = bn.next(); !Ar.done; Ar = bn.next()) {
                        var Ka = Ar.value;
                        Ka.type = e.getType(Ue, Ka.typeName)
                    }
                } catch (vi) {
                    de = {
                        error: vi
                    }
                } finally {
                    try {
                        Ar && !Ar.done && (Ze = bn.return) && Ze.call(bn)
                    } finally {
                        if (de) throw de.error
                    }
                }
            }
        } catch (Re) {
            J = {
                error: Re
            }
        } finally {
            try {
                Sr && !Sr.done && (te = yn.return) && te.call(yn)
            } finally {
                if (J) throw J.error
            }
        }
        return Ue
    };
    e.getTypesFromAbi = j;
    var ee = function(p) {
            return p.substr(6, 2) + p.substr(4, 2) + p.substr(2, 2) + p.substr(0, 2)
        },
        ce = function(p, l) {
            var d = p.header ? p.header.timestamp : p.timestamp,
                E = parseInt(ee(p.id.substr(16, 8)), 16);
            return {
                expiration: e.timePointSecToDate(e.dateToTimePointSec(d) + l),
                ref_block_num: p.block_num & 65535,
                ref_block_prefix: E
            }
        };
    e.transactionHeader = ce;
    var we = function(p, l, d, E, R, B) {
        var q = p.actions.get(d);
        if (!q) throw new Error("Unknown action " + d + " in contract " + l);
        var G = new s({
            textEncoder: R,
            textDecoder: B
        });
        return q.serialize(G, E), e.arrayToHex(G.asUint8Array())
    };
    e.serializeActionData = we;
    var ht = function(p, l, d, E, R, B, q) {
        return {
            account: l,
            name: d,
            authorization: E,
            data: e.serializeActionData(p, l, d, R, B, q)
        }
    };
    e.serializeAction = ht;
    var pn = function(p, l, d, E, R, B) {
        var q = p.actions.get(d);
        if (typeof E == "string" && (E = e.hexToUint8Array(E)), !q) throw new Error("Unknown action " + d + " in contract " + l);
        var G = new s({
            textDecoder: B,
            textEncoder: R
        });
        return G.pushArray(E), q.deserialize(G)
    };
    e.deserializeActionData = pn;
    var Gt = function(p, l, d, E, R, B, q) {
        return {
            account: l,
            name: d,
            authorization: E,
            data: e.deserializeActionData(p, l, d, R, B, q)
        }
    };
    e.deserializeAction = Gt;
    var Ot = function(p, l) {
        var d, E, R, B, q, G, J, te, de;
        l === null ? (d = r([fe.null_t, l], 2), te = d[0], de = d[1]) : typeof l == "string" ? (E = r([fe.string, l], 2), te = E[0], de = E[1]) : typeof l == "number" ? (R = r([fe.int32, l], 2), te = R[0], de = R[1]) : l instanceof Uint8Array ? (B = r([fe.bytes, l], 2), te = B[0], de = B[1]) : Array.isArray(l) ? (q = r([fe.any_array, l], 2), te = q[0], de = q[1]) : Object.keys(l).length === 2 && l.hasOwnProperty("type") && l.hasOwnProperty("value") ? (G = r([fe[l.type], l.value], 2), te = G[0], de = G[1]) : (J = r([fe.any_object, l], 2), te = J[0], de = J[1]), p.pushVaruint32(te.index), te.type.serialize(p, de)
    };
    e.serializeAnyvar = Ot;
    var xr = function(p, l) {
        var d = p.getVaruint32();
        if (d >= Ia.length) throw new Error("Tried to deserialize unknown anyvar type");
        var E = Ia[d],
            R = E.type.deserialize(p, l);
        return l && l.options.useShortForm || E.useShortForm ? R : {
            type: E.type.name,
            value: R
        }
    };
    e.deserializeAnyvar = xr;
    var pl = function(p) {
        return e.deserializeAnyvar(p, new o({
            useShortForm: !0
        }))
    };
    e.deserializeAnyvarShort = pl;
    var _l = function(p, l) {
        var d, E, R = Object.entries(l);
        p.pushVaruint32(R.length);
        try {
            for (var B = i(R), q = B.next(); !q.done; q = B.next()) {
                var G = r(q.value, 2),
                    J = G[0],
                    te = G[1];
                p.pushString(J), e.serializeAnyvar(p, te)
            }
        } catch (de) {
            d = {
                error: de
            }
        } finally {
            try {
                q && !q.done && (E = B.return) && E.call(B)
            } finally {
                if (d) throw d.error
            }
        }
    };
    e.serializeAnyObject = _l;
    var vl = function(p, l) {
        for (var d = p.getVaruint32(), E = {}, R = 0; R < d; ++R) {
            var B = p.getString();
            if (B in E) {
                for (var q = 1; B + "_" + q in E;) ++q;
                B = B + "_" + q
            }
            E[B] = e.deserializeAnyvar(p, l)
        }
        return E
    };
    e.deserializeAnyObject = vl;
    var yl = function(p, l) {
        var d, E;
        p.pushVaruint32(l.length);
        try {
            for (var R = i(l), B = R.next(); !B.done; B = R.next()) {
                var q = B.value;
                e.serializeAnyvar(p, q)
            }
        } catch (G) {
            d = {
                error: G
            }
        } finally {
            try {
                B && !B.done && (E = R.return) && E.call(R)
            } finally {
                if (d) throw d.error
            }
        }
    };
    e.serializeAnyArray = yl;
    var bl = function(p, l) {
        for (var d = p.getVaruint32(), E = [], R = 0; R < d; ++R) E.push(e.deserializeAnyvar(p, l));
        return E
    };
    e.deserializeAnyArray = bl;
    var gl = function() {
            var p = e.createInitialTypes();
            return p.set("null_t", h({
                name: "null_t",
                serialize: function(l, d) {},
                deserialize: function(l, d) {}
            })), p.set("any_object", h({
                name: "any_object",
                serialize: e.serializeAnyObject,
                deserialize: e.deserializeAnyObject
            })), p.set("any_array", h({
                name: "any_array",
                serialize: e.serializeAnyArray,
                deserialize: e.deserializeAnyArray
            })), p
        },
        be = gl(),
        fe = {
            null_t: {
                index: 0,
                useShortForm: !0,
                type: be.get("null_t")
            },
            int64: {
                index: 1,
                useShortForm: !1,
                type: be.get("int64")
            },
            uint64: {
                index: 2,
                useShortForm: !1,
                type: be.get("uint64")
            },
            int32: {
                index: 3,
                useShortForm: !0,
                type: be.get("int32")
            },
            uint32: {
                index: 4,
                useShortForm: !1,
                type: be.get("uint32")
            },
            int16: {
                index: 5,
                useShortForm: !1,
                type: be.get("int16")
            },
            uint16: {
                index: 6,
                useShortForm: !1,
                type: be.get("uint16")
            },
            int8: {
                index: 7,
                useShortForm: !1,
                type: be.get("int8")
            },
            uint8: {
                index: 8,
                useShortForm: !1,
                type: be.get("uint8")
            },
            time_point: {
                index: 9,
                useShortForm: !1,
                type: be.get("time_point")
            },
            checksum256: {
                index: 10,
                useShortForm: !1,
                type: be.get("checksum256")
            },
            float64: {
                index: 11,
                useShortForm: !1,
                type: be.get("float64")
            },
            string: {
                index: 12,
                useShortForm: !0,
                type: be.get("string")
            },
            any_object: {
                index: 13,
                useShortForm: !0,
                type: be.get("any_object")
            },
            any_array: {
                index: 14,
                useShortForm: !0,
                type: be.get("any_array")
            },
            bytes: {
                index: 15,
                useShortForm: !1,
                type: be.get("bytes")
            },
            symbol: {
                index: 16,
                useShortForm: !1,
                type: be.get("symbol")
            },
            symbol_code: {
                index: 17,
                useShortForm: !1,
                type: be.get("symbol_code")
            },
            asset: {
                index: 18,
                useShortForm: !1,
                type: be.get("asset")
            }
        },
        Ia = [fe.null_t, fe.int64, fe.uint64, fe.int32, fe.uint32, fe.int16, fe.uint16, fe.int8, fe.uint8, fe.time_point, fe.checksum256, fe.float64, fe.string, fe.any_object, fe.any_array, fe.bytes, fe.symbol, fe.symbol_code, fe.asset],
        wl = function(p, l) {
            var d, E, R, B, q, G, J, te;
            if (typeof l == "string" ? G = l : Array.isArray(l) && l.length === 2 ? (d = r(l, 2), G = d[0], te = d[1]) : Array.isArray(l) && l.length === 3 ? (E = r(l, 3), G = E[0], J = E[1], te = E[2]) : (R = r([l.method, l.arg, l.filter], 3), G = R[0], J = R[1], te = R[2]), p.pushString(G), J === void 0 ? p.push(0) : (p.push(1), e.serializeAnyvar(p, J)), te === void 0) p.push(0);
            else {
                p.pushVaruint32(te.length);
                try {
                    for (var de = i(te), Ze = de.next(); !Ze.done; Ze = de.next()) {
                        var Ue = Ze.value;
                        e.serializeQuery(p, Ue)
                    }
                } catch (dt) {
                    B = {
                        error: dt
                    }
                } finally {
                    try {
                        Ze && !Ze.done && (q = de.return) && q.call(de)
                    } finally {
                        if (B) throw B.error
                    }
                }
            }
        };
    e.serializeQuery = wl
})(xa);
var Oe = Y && Y.__assign || function() {
        return Oe = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) {
                t = arguments[r];
                for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i])
            }
            return e
        }, Oe.apply(this, arguments)
    },
    _e = Y && Y.__awaiter || function(e, t, r, n) {
        function i(a) {
            return a instanceof r ? a : new r(function(o) {
                o(a)
            })
        }
        return new(r || (r = Promise))(function(a, o) {
            function s(f) {
                try {
                    u(n.next(f))
                } catch (b) {
                    o(b)
                }
            }

            function c(f) {
                try {
                    u(n.throw(f))
                } catch (b) {
                    o(b)
                }
            }

            function u(f) {
                f.done ? a(f.value) : i(f.value).then(s, c)
            }
            u((n = n.apply(e, t || [])).next())
        })
    },
    ve = Y && Y.__generator || function(e, t) {
        var r = {
                label: 0,
                sent: function() {
                    if (a[0] & 1) throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            },
            n, i, a, o;
        return o = {
            next: s(0),
            throw: s(1),
            return: s(2)
        }, typeof Symbol == "function" && (o[Symbol.iterator] = function() {
            return this
        }), o;

        function s(u) {
            return function(f) {
                return c([u, f])
            }
        }

        function c(u) {
            if (n) throw new TypeError("Generator is already executing.");
            for (; r;) try {
                if (n = 1, i && (a = u[0] & 2 ? i.return : u[0] ? i.throw || ((a = i.return) && a.call(i), 0) : i.next) && !(a = a.call(i, u[1])).done) return a;
                switch (i = 0, a && (u = [u[0] & 2, a.value]), u[0]) {
                    case 0:
                    case 1:
                        a = u;
                        break;
                    case 4:
                        return r.label++, {
                            value: u[1],
                            done: !1
                        };
                    case 5:
                        r.label++, i = u[1], u = [0];
                        continue;
                    case 7:
                        u = r.ops.pop(), r.trys.pop();
                        continue;
                    default:
                        if (a = r.trys, !(a = a.length > 0 && a[a.length - 1]) && (u[0] === 6 || u[0] === 2)) {
                            r = 0;
                            continue
                        }
                        if (u[0] === 3 && (!a || u[1] > a[0] && u[1] < a[3])) {
                            r.label = u[1];
                            break
                        }
                        if (u[0] === 6 && r.label < a[1]) {
                            r.label = a[1], a = u;
                            break
                        }
                        if (a && r.label < a[2]) {
                            r.label = a[2], r.ops.push(u);
                            break
                        }
                        a[2] && r.ops.pop(), r.trys.pop();
                        continue
                }
                u = t.call(e, r)
            } catch (f) {
                u = [6, f], i = 0
            } finally {
                n = a = 0
            }
            if (u[0] & 5) throw u[1];
            return {
                value: u[0] ? u[1] : void 0,
                done: !0
            }
        }
    },
    Lo = Y && Y.__read || function(e, t) {
        var r = typeof Symbol == "function" && e[Symbol.iterator];
        if (!r) return e;
        var n = r.call(e),
            i, a = [],
            o;
        try {
            for (;
                (t === void 0 || t-- > 0) && !(i = n.next()).done;) a.push(i.value)
        } catch (s) {
            o = {
                error: s
            }
        } finally {
            try {
                i && !i.done && (r = n.return) && r.call(n)
            } finally {
                if (o) throw o.error
            }
        }
        return a
    },
    Ni = Y && Y.__spreadArray || function(e, t) {
        for (var r = 0, n = t.length, i = e.length; r < n; r++, i++) e[i] = t[r];
        return e
    },
    ia = Y && Y.__values || function(e) {
        var t = typeof Symbol == "function" && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && typeof e.length == "number") return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
Object.defineProperty(St, "__esModule", {
    value: !0
});
St.ActionBuilder = St.TransactionBuilder = St.Api = void 0;
var Io = nt,
    X = xa,
    _d = function() {
        function e(t) {
            this.contracts = new Map, this.cachedAbis = new Map, this.transactionExtensions = [{
                id: 1,
                type: "resource_payer",
                keys: ["payer", "max_net_bytes", "max_cpu_us", "max_memory_bytes"]
            }], this.rpc = t.rpc, this.authorityProvider = t.authorityProvider || t.rpc, this.abiProvider = t.abiProvider || t.rpc, this.signatureProvider = t.signatureProvider, this.chainId = t.chainId, this.textEncoder = t.textEncoder, this.textDecoder = t.textDecoder, this.abiTypes = X.getTypesFromAbi(X.createAbiTypes()), this.transactionTypes = X.getTypesFromAbi(X.createTransactionTypes())
        }
        return e.prototype.rawAbiToJson = function(t) {
            var r = new X.SerialBuffer({
                textEncoder: this.textEncoder,
                textDecoder: this.textDecoder,
                array: t
            });
            if (!X.supportedAbiVersion(r.getString())) throw new Error("Unsupported abi version");
            return r.restartRead(), this.abiTypes.get("abi_def").deserialize(r)
        }, e.prototype.jsonToRawAbi = function(t) {
            var r = new X.SerialBuffer({
                textEncoder: this.textEncoder,
                textDecoder: this.textDecoder
            });
            if (this.abiTypes.get("abi_def").serialize(r, t), !X.supportedAbiVersion(r.getString())) throw new Error("Unsupported abi version");
            return r.asUint8Array()
        }, e.prototype.getCachedAbi = function(t, r) {
            return r === void 0 && (r = !1), _e(this, void 0, void 0, function() {
                var n, i, a, o;
                return ve(this, function(s) {
                    switch (s.label) {
                        case 0:
                            if (!r && this.cachedAbis.get(t)) return [2, this.cachedAbis.get(t)];
                            s.label = 1;
                        case 1:
                            return s.trys.push([1, 3, , 4]), [4, this.abiProvider.getRawAbi(t)];
                        case 2:
                            return i = s.sent().abi, a = this.rawAbiToJson(i), n = {
                                rawAbi: i,
                                abi: a
                            }, [3, 4];
                        case 3:
                            throw o = s.sent(), o.message = "fetching abi for " + t + ": " + o.message, o;
                        case 4:
                            if (!n) throw new Error("Missing abi for " + t);
                            return this.cachedAbis.set(t, n), [2, n]
                    }
                })
            })
        }, e.prototype.getAbi = function(t, r) {
            return r === void 0 && (r = !1), _e(this, void 0, void 0, function() {
                return ve(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, this.getCachedAbi(t, r)];
                        case 1:
                            return [2, n.sent().abi]
                    }
                })
            })
        }, e.prototype.getTransactionAbis = function(t, r) {
            return r === void 0 && (r = !1), _e(this, void 0, void 0, function() {
                var n, i, a, o, s = this;
                return ve(this, function(c) {
                    return n = (t.context_free_actions || []).concat(t.actions), i = n.map(function(u) {
                        return u.account
                    }), a = new Set(i), o = Ni([], Lo(a)).map(function(u) {
                        return _e(s, void 0, void 0, function() {
                            var f;
                            return ve(this, function(b) {
                                switch (b.label) {
                                    case 0:
                                        return f = {
                                            accountName: u
                                        }, [4, this.getCachedAbi(u, r)];
                                    case 1:
                                        return [2, (f.abi = b.sent().rawAbi, f)]
                                }
                            })
                        })
                    }), [2, Promise.all(o)]
                })
            })
        }, e.prototype.getContract = function(t, r) {
            return r === void 0 && (r = !1), _e(this, void 0, void 0, function() {
                var n, i, a, o, s, c, u, f, b, _, v;
                return ve(this, function(g) {
                    switch (g.label) {
                        case 0:
                            return !r && this.contracts.get(t) ? [2, this.contracts.get(t)] : [4, this.getAbi(t, r)];
                        case 1:
                            n = g.sent(), i = X.getTypesFromAbi(X.createInitialTypes(), n), a = new Map;
                            try {
                                for (o = ia(n.actions), s = o.next(); !s.done; s = o.next()) c = s.value, u = c.name, f = c.type, a.set(u, X.getType(i, f))
                            } catch (k) {
                                _ = {
                                    error: k
                                }
                            } finally {
                                try {
                                    s && !s.done && (v = o.return) && v.call(o)
                                } finally {
                                    if (_) throw _.error
                                }
                            }
                            return b = {
                                types: i,
                                actions: a
                            }, this.contracts.set(t, b), [2, b]
                    }
                })
            })
        }, e.prototype.serialize = function(t, r, n) {
            this.transactionTypes.get(r).serialize(t, n)
        }, e.prototype.deserialize = function(t, r) {
            return this.transactionTypes.get(r).deserialize(t)
        }, e.prototype.serializeTransaction = function(t) {
            var r = new X.SerialBuffer({
                textEncoder: this.textEncoder,
                textDecoder: this.textDecoder
            });
            return this.serialize(r, "transaction", Oe({
                max_net_usage_words: 0,
                max_cpu_usage_ms: 0,
                delay_sec: 0,
                context_free_actions: [],
                actions: [],
                transaction_extensions: []
            }, t)), r.asUint8Array()
        }, e.prototype.serializeContextFreeData = function(t) {
            var r, n;
            if (!t || !t.length) return null;
            var i = new X.SerialBuffer({
                textEncoder: this.textEncoder,
                textDecoder: this.textDecoder
            });
            i.pushVaruint32(t.length);
            try {
                for (var a = ia(t), o = a.next(); !o.done; o = a.next()) {
                    var s = o.value;
                    i.pushBytes(s)
                }
            } catch (c) {
                r = {
                    error: c
                }
            } finally {
                try {
                    o && !o.done && (n = a.return) && n.call(a)
                } finally {
                    if (r) throw r.error
                }
            }
            return i.asUint8Array()
        }, e.prototype.deserializeTransaction = function(t) {
            var r = new X.SerialBuffer({
                textEncoder: this.textEncoder,
                textDecoder: this.textDecoder
            });
            return r.pushArray(t), this.deserialize(r, "transaction")
        }, e.prototype.serializeTransactionExtensions = function(t) {
            var r = [];
            if (t.resource_payer) {
                var n = new X.SerialBuffer({
                        textEncoder: this.textEncoder,
                        textDecoder: this.textDecoder
                    }),
                    i = X.getTypesFromAbi(X.createTransactionExtensionTypes());
                i.get("resource_payer").serialize(n, t.resource_payer), r = Ni(Ni([], Lo(r)), [
                    [1, X.arrayToHex(n.asUint8Array())]
                ])
            }
            return r
        }, e.prototype.deserializeTransactionExtensions = function(t) {
            var r = this,
                n = {};
            return t.forEach(function(i) {
                var a = r.transactionExtensions.find(function(u) {
                    return u.id === i[0]
                });
                if (a === void 0) throw new Error("Transaction Extension could not be determined: " + i);
                var o = X.getTypesFromAbi(X.createTransactionExtensionTypes()),
                    s = new X.SerialBuffer({
                        textEncoder: r.textEncoder,
                        textDecoder: r.textDecoder
                    });
                s.pushArray(X.hexToUint8Array(i[1]));
                var c = o.get(a.type).deserialize(s);
                i[0] === 1 && (c.max_net_bytes = Number(c.max_net_bytes), c.max_cpu_us = Number(c.max_cpu_us), c.max_memory_bytes = Number(c.max_memory_bytes), n.resource_payer = c)
            }), n
        }, e.prototype.deleteTransactionExtensionObjects = function(t) {
            return delete t.resource_payer, t
        }, e.prototype.serializeActions = function(t) {
            return _e(this, void 0, void 0, function() {
                var r = this;
                return ve(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, Promise.all(t.map(function(i) {
                                return _e(r, void 0, void 0, function() {
                                    var a, o, s, c, u;
                                    return ve(this, function(f) {
                                        switch (f.label) {
                                            case 0:
                                                return a = i.account, o = i.name, s = i.authorization, c = i.data, [4, this.getContract(a)];
                                            case 1:
                                                return u = f.sent(), typeof c != "object" ? [2, i] : [2, X.serializeAction(u, a, o, s, c, this.textEncoder, this.textDecoder)]
                                        }
                                    })
                                })
                            }))];
                        case 1:
                            return [2, n.sent()]
                    }
                })
            })
        }, e.prototype.deserializeActions = function(t) {
            return _e(this, void 0, void 0, function() {
                var r = this;
                return ve(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, Promise.all(t.map(function(i) {
                                var a = i.account,
                                    o = i.name,
                                    s = i.authorization,
                                    c = i.data;
                                return _e(r, void 0, void 0, function() {
                                    var u;
                                    return ve(this, function(f) {
                                        switch (f.label) {
                                            case 0:
                                                return [4, this.getContract(a)];
                                            case 1:
                                                return u = f.sent(), [2, X.deserializeAction(u, a, o, s, c, this.textEncoder, this.textDecoder)]
                                        }
                                    })
                                })
                            }))];
                        case 1:
                            return [2, n.sent()]
                    }
                })
            })
        }, e.prototype.deserializeTransactionWithActions = function(t) {
            return _e(this, void 0, void 0, function() {
                var r, n, i;
                return ve(this, function(a) {
                    switch (a.label) {
                        case 0:
                            return typeof t == "string" && (t = X.hexToUint8Array(t)), r = this.deserializeTransaction(t), [4, this.deserializeActions(r.context_free_actions)];
                        case 1:
                            return n = a.sent(), [4, this.deserializeActions(r.actions)];
                        case 2:
                            return i = a.sent(), [2, Oe(Oe({}, r), {
                                context_free_actions: n,
                                actions: i
                            })]
                    }
                })
            })
        }, e.prototype.deflateSerializedArray = function(t) {
            return Io.deflate(t, {
                level: 9
            })
        }, e.prototype.inflateSerializedArray = function(t) {
            return Io.inflate(t)
        }, e.prototype.transact = function(t, r) {
            var n = r === void 0 ? {} : r,
                i = n.broadcast,
                a = i === void 0 ? !0 : i,
                o = n.sign,
                s = o === void 0 ? !0 : o,
                c = n.readOnlyTrx,
                u = n.returnFailureTraces,
                f = n.requiredKeys,
                b = n.compression,
                _ = n.blocksBehind,
                v = n.useLastIrreversible,
                g = n.expireSeconds;
            return _e(this, void 0, void 0, function() {
                var k, O, z, P, L, y, D, w;
                return ve(this, function(x) {
                    switch (x.label) {
                        case 0:
                            if (typeof _ == "number" && v) throw new Error("Use either blocksBehind or useLastIrreversible");
                            return this.chainId ? [3, 2] : [4, this.rpc.get_info()];
                        case 1:
                            k = x.sent(), this.chainId = k.chain_id, x.label = 2;
                        case 2:
                            return (typeof _ == "number" || v) && g ? [4, this.generateTapos(k, t, _, v, g)] : [3, 4];
                        case 3:
                            t = x.sent(), x.label = 4;
                        case 4:
                            if (!this.hasRequiredTaposFields(t)) throw new Error("Required configuration or TAPOS fields are not present");
                            return [4, this.getTransactionAbis(t)];
                        case 5:
                            return O = x.sent(), z = [Oe({}, t)], w = {}, [4, this.serializeTransactionExtensions(t)];
                        case 6:
                            return w.transaction_extensions = x.sent(), [4, this.serializeActions(t.context_free_actions || [])];
                        case 7:
                            return w.context_free_actions = x.sent(), [4, this.serializeActions(t.actions)];
                        case 8:
                            return t = Oe.apply(void 0, z.concat([(w.actions = x.sent(), w)])), t = this.deleteTransactionExtensionObjects(t), P = this.serializeTransaction(t), L = this.serializeContextFreeData(t.context_free_data), y = {
                                serializedTransaction: P,
                                serializedContextFreeData: L,
                                signatures: []
                            }, s ? f ? [3, 11] : [4, this.signatureProvider.getAvailableKeys()] : [3, 13];
                        case 9:
                            return D = x.sent(), [4, this.authorityProvider.getRequiredKeys({
                                transaction: t,
                                availableKeys: D
                            })];
                        case 10:
                            f = x.sent(), x.label = 11;
                        case 11:
                            return [4, this.signatureProvider.sign({
                                chainId: this.chainId,
                                requiredKeys: f,
                                serializedTransaction: P,
                                serializedContextFreeData: L,
                                abis: O
                            })];
                        case 12:
                            y = x.sent(), x.label = 13;
                        case 13:
                            return a ? b ? [2, this.pushCompressedSignedTransaction(y, c, u)] : [2, this.pushSignedTransaction(y, c, u)] : [2, y]
                    }
                })
            })
        }, e.prototype.query = function(t, r, n, i) {
            var a = i.sign,
                o = i.requiredKeys,
                s = i.authorization,
                c = s === void 0 ? [] : s;
            return _e(this, void 0, void 0, function() {
                var u, f, b, _, v, g, k, O, z, P, L;
                return ve(this, function(y) {
                    switch (y.label) {
                        case 0:
                            return [4, this.rpc.get_info()];
                        case 1:
                            return u = y.sent(), [4, this.tryRefBlockFromGetInfo(u)];
                        case 2:
                            return f = y.sent(), b = new X.SerialBuffer({
                                textEncoder: this.textEncoder,
                                textDecoder: this.textDecoder
                            }), X.serializeQuery(b, n), _ = Oe(Oe({}, X.transactionHeader(f, 60 * 30)), {
                                context_free_actions: [],
                                actions: [{
                                    account: t,
                                    name: "queryit",
                                    authorization: c,
                                    data: X.arrayToHex(b.asUint8Array())
                                }]
                            }), v = this.serializeTransaction(_), g = [], a ? [4, this.getTransactionAbis(_)] : [3, 8];
                        case 3:
                            return k = y.sent(), o ? [3, 6] : [4, this.signatureProvider.getAvailableKeys()];
                        case 4:
                            return O = y.sent(), [4, this.authorityProvider.getRequiredKeys({
                                transaction: _,
                                availableKeys: O
                            })];
                        case 5:
                            o = y.sent(), y.label = 6;
                        case 6:
                            return [4, this.signatureProvider.sign({
                                chainId: this.chainId,
                                requiredKeys: o,
                                serializedTransaction: v,
                                serializedContextFreeData: null,
                                abis: k
                            })];
                        case 7:
                            z = y.sent(), g = z.signatures, y.label = 8;
                        case 8:
                            return [4, this.rpc.send_transaction({
                                signatures: g,
                                compression: 0,
                                serializedTransaction: v
                            })];
                        case 9:
                            return P = y.sent(), L = new X.SerialBuffer({
                                textEncoder: this.textEncoder,
                                textDecoder: this.textDecoder,
                                array: X.hexToUint8Array(P.processed.action_traces[0][1].return_value)
                            }), r ? [2, X.deserializeAnyvarShort(L)] : [2, X.deserializeAnyvar(L)]
                    }
                })
            })
        }, e.prototype.pushSignedTransaction = function(t, r, n) {
            var i = t.signatures,
                a = t.serializedTransaction,
                o = t.serializedContextFreeData;
            return r === void 0 && (r = !1), n === void 0 && (n = !1), _e(this, void 0, void 0, function() {
                return ve(this, function(s) {
                    return r ? [2, this.rpc.push_ro_transaction({
                        signatures: i,
                        serializedTransaction: a,
                        serializedContextFreeData: o
                    }, n)] : [2, this.rpc.push_transaction({
                        signatures: i,
                        serializedTransaction: a,
                        serializedContextFreeData: o
                    })]
                })
            })
        }, e.prototype.pushCompressedSignedTransaction = function(t, r, n) {
            var i = t.signatures,
                a = t.serializedTransaction,
                o = t.serializedContextFreeData;
            return r === void 0 && (r = !1), n === void 0 && (n = !1), _e(this, void 0, void 0, function() {
                var s, c;
                return ve(this, function(u) {
                    return s = this.deflateSerializedArray(a), c = this.deflateSerializedArray(o || new Uint8Array(0)), r ? [2, this.rpc.push_ro_transaction({
                        signatures: i,
                        compression: 1,
                        serializedTransaction: s,
                        serializedContextFreeData: c
                    }, n)] : [2, this.rpc.push_transaction({
                        signatures: i,
                        compression: 1,
                        serializedTransaction: s,
                        serializedContextFreeData: c
                    })]
                })
            })
        }, e.prototype.generateTapos = function(t, r, n, i, a) {
            return _e(this, void 0, void 0, function() {
                var o, s, c, u;
                return ve(this, function(f) {
                    switch (f.label) {
                        case 0:
                            return t ? [3, 2] : [4, this.rpc.get_info()];
                        case 1:
                            t = f.sent(), f.label = 2;
                        case 2:
                            return i ? [4, this.tryRefBlockFromGetInfo(t)] : [3, 4];
                        case 3:
                            return o = f.sent(), [2, Oe(Oe({}, X.transactionHeader(o, a)), r)];
                        case 4:
                            return s = t.head_block_num - n, s <= t.last_irreversible_block_num ? [4, this.tryGetBlockInfo(s)] : [3, 6];
                        case 5:
                            return u = f.sent(), [3, 8];
                        case 6:
                            return [4, this.tryGetBlockHeaderState(s)];
                        case 7:
                            u = f.sent(), f.label = 8;
                        case 8:
                            return c = u, [2, Oe(Oe({}, X.transactionHeader(c, a)), r)]
                    }
                })
            })
        }, e.prototype.hasRequiredTaposFields = function(t) {
            var r = t.expiration,
                n = t.ref_block_num,
                i = t.ref_block_prefix;
            return !!(r && typeof n == "number" && typeof i == "number")
        }, e.prototype.tryGetBlockHeaderState = function(t) {
            return _e(this, void 0, void 0, function() {
                return ve(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return r.trys.push([0, 2, , 4]), [4, this.rpc.get_block_header_state(t)];
                        case 1:
                            return [2, r.sent()];
                        case 2:
                            return r.sent(), [4, this.tryGetBlockInfo(t)];
                        case 3:
                            return [2, r.sent()];
                        case 4:
                            return [2]
                    }
                })
            })
        }, e.prototype.tryGetBlockInfo = function(t) {
            return _e(this, void 0, void 0, function() {
                return ve(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return r.trys.push([0, 2, , 4]), [4, this.rpc.get_block_info(t)];
                        case 1:
                            return [2, r.sent()];
                        case 2:
                            return r.sent(), [4, this.rpc.get_block(t)];
                        case 3:
                            return [2, r.sent()];
                        case 4:
                            return [2]
                    }
                })
            })
        }, e.prototype.tryRefBlockFromGetInfo = function(t) {
            return _e(this, void 0, void 0, function() {
                var r;
                return ve(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return t.hasOwnProperty("last_irreversible_block_id") && t.hasOwnProperty("last_irreversible_block_num") && t.hasOwnProperty("last_irreversible_block_time") ? [2, {
                                block_num: t.last_irreversible_block_num,
                                id: t.last_irreversible_block_id,
                                timestamp: t.last_irreversible_block_time
                            }] : [3, 1];
                        case 1:
                            return [4, this.tryGetBlockInfo(t.last_irreversible_block_num)];
                        case 2:
                            return r = n.sent(), [2, {
                                block_num: r.block_num,
                                id: r.id,
                                timestamp: r.timestamp
                            }]
                    }
                })
            })
        }, e.prototype.with = function(t) {
            return new ma(this, t)
        }, e.prototype.buildTransaction = function(t) {
            var r = new pu(this);
            return t ? t(r) : r
        }, e
    }();
St.Api = _d;
var pu = function() {
    function e(t) {
        this.actions = [], this.contextFreeGroups = [], this.api = t
    }
    return e.prototype.with = function(t) {
        var r = new ma(this.api, t);
        return this.actions.push(r), r
    }, e.prototype.associateContextFree = function(t) {
        return this.contextFreeGroups.push(t), this
    }, e.prototype.send = function(t) {
        return _e(this, void 0, void 0, function() {
            var r, n, i, a = this;
            return ve(this, function(o) {
                switch (o.label) {
                    case 0:
                        return r = [], n = [], i = this.actions.map(function(s) {
                            return s.serializedData
                        }), [4, Promise.all(this.contextFreeGroups.map(function(s) {
                            return _e(a, void 0, void 0, function() {
                                var c, u, f, b;
                                return ve(this, function(_) {
                                    return c = s({
                                        cfd: r.length,
                                        cfa: n.length
                                    }), u = c.action, f = c.contextFreeAction, b = c.contextFreeData, u && i.push(u), f && n.push(f), b && r.push(b), [2]
                                })
                            })
                        }))];
                    case 1:
                        return o.sent(), this.contextFreeGroups = [], this.actions = [], [4, this.api.transact({
                            context_free_data: r,
                            context_free_actions: n,
                            actions: i
                        }, t)];
                    case 2:
                        return [2, o.sent()]
                }
            })
        })
    }, e
}();
St.TransactionBuilder = pu;
var ma = function() {
    function e(t, r) {
        this.api = t, this.accountName = r
    }
    return e.prototype.as = function(t) {
        t === void 0 && (t = []);
        var r = [];
        return t && typeof t == "string" ? r = [{
            actor: t,
            permission: "active"
        }] : r = t, new vd(this, this.api, this.accountName, r)
    }, e
}();
St.ActionBuilder = ma;
var vd = function() {
        function e(t, r, n, i) {
            var a, o, s = this,
                c = r.cachedAbis.get(n);
            if (!c) throw new Error("ABI must be cached before using ActionBuilder, run api.getAbi()");
            var u = X.getTypesFromAbi(X.createInitialTypes(), c.abi),
                f = new Map;
            try {
                for (var b = ia(c.abi.actions), _ = b.next(); !_.done; _ = b.next()) {
                    var v = _.value,
                        g = v.name,
                        k = v.type;
                    f.set(g, X.getType(u, k))
                }
            } catch (O) {
                a = {
                    error: O
                }
            } finally {
                try {
                    _ && !_.done && (o = b.return) && o.call(b)
                } finally {
                    if (a) throw a.error
                }
            }
            f.forEach(function(O, z) {
                var P;
                Object.assign(s, (P = {}, P[z] = function() {
                    for (var L = [], y = 0; y < arguments.length; y++) L[y] = arguments[y];
                    var D = {};
                    L.forEach(function(x, A) {
                        var U = O.fields[A];
                        D[U.name] = x
                    });
                    var w = X.serializeAction({
                        types: u,
                        actions: f
                    }, n, z, i, D, r.textEncoder, r.textDecoder);
                    return t.serializedData = w, w
                }, P))
            })
        }
        return e
    }(),
    _u = {};
Object.defineProperty(_u, "__esModule", {
    value: !0
});
var Zn = {},
    on = {},
    yd = Y && Y.__extends || function() {
        var e = function(t, r) {
            return e = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(n, i) {
                n.__proto__ = i
            } || function(n, i) {
                for (var a in i) Object.prototype.hasOwnProperty.call(i, a) && (n[a] = i[a])
            }, e(t, r)
        };
        return function(t, r) {
            if (typeof r != "function" && r !== null) throw new TypeError("Class extends value " + String(r) + " is not a constructor or null");
            e(t, r);

            function n() {
                this.constructor = t
            }
            t.prototype = r === null ? Object.create(r) : (n.prototype = r.prototype, new n)
        }
    }();
Object.defineProperty(on, "__esModule", {
    value: !0
});
on.RpcError = void 0;
var bd = function(e) {
    yd(t, e);

    function t(r) {
        var n = this;
        return r.error && r.error.details && r.error.details.length && r.error.details[0].message ? (n = e.call(this, r.error.details[0].message) || this, n.details = r.error.details) : r.processed && r.processed.except && r.processed.except.message ? (n = e.call(this, r.processed.except.message) || this, n.details = r.processed.except) : r.result && r.result.except && r.result.except.message ? (n = e.call(this, r.result.except.message) || this, n.details = r.result.except) : n = e.call(this, r.message) || this, Object.setPrototypeOf(n, t.prototype), n.json = r, n
    }
    return t
}(Error);
on.RpcError = bd;
var ae = Y && Y.__awaiter || function(e, t, r, n) {
        function i(a) {
            return a instanceof r ? a : new r(function(o) {
                o(a)
            })
        }
        return new(r || (r = Promise))(function(a, o) {
            function s(f) {
                try {
                    u(n.next(f))
                } catch (b) {
                    o(b)
                }
            }

            function c(f) {
                try {
                    u(n.throw(f))
                } catch (b) {
                    o(b)
                }
            }

            function u(f) {
                f.done ? a(f.value) : i(f.value).then(s, c)
            }
            u((n = n.apply(e, t || [])).next())
        })
    },
    oe = Y && Y.__generator || function(e, t) {
        var r = {
                label: 0,
                sent: function() {
                    if (a[0] & 1) throw a[1];
                    return a[1]
                },
                trys: [],
                ops: []
            },
            n, i, a, o;
        return o = {
            next: s(0),
            throw: s(1),
            return: s(2)
        }, typeof Symbol == "function" && (o[Symbol.iterator] = function() {
            return this
        }), o;

        function s(u) {
            return function(f) {
                return c([u, f])
            }
        }

        function c(u) {
            if (n) throw new TypeError("Generator is already executing.");
            for (; r;) try {
                if (n = 1, i && (a = u[0] & 2 ? i.return : u[0] ? i.throw || ((a = i.return) && a.call(i), 0) : i.next) && !(a = a.call(i, u[1])).done) return a;
                switch (i = 0, a && (u = [u[0] & 2, a.value]), u[0]) {
                    case 0:
                    case 1:
                        a = u;
                        break;
                    case 4:
                        return r.label++, {
                            value: u[1],
                            done: !1
                        };
                    case 5:
                        r.label++, i = u[1], u = [0];
                        continue;
                    case 7:
                        u = r.ops.pop(), r.trys.pop();
                        continue;
                    default:
                        if (a = r.trys, !(a = a.length > 0 && a[a.length - 1]) && (u[0] === 6 || u[0] === 2)) {
                            r = 0;
                            continue
                        }
                        if (u[0] === 3 && (!a || u[1] > a[0] && u[1] < a[3])) {
                            r.label = u[1];
                            break
                        }
                        if (u[0] === 6 && r.label < a[1]) {
                            r.label = a[1], a = u;
                            break
                        }
                        if (a && r.label < a[2]) {
                            r.label = a[2], r.ops.push(u);
                            break
                        }
                        a[2] && r.ops.pop(), r.trys.pop();
                        continue
                }
                u = t.call(e, r)
            } catch (f) {
                u = [6, f], i = 0
            } finally {
                n = a = 0
            }
            if (u[0] & 5) throw u[1];
            return {
                value: u[0] ? u[1] : void 0,
                done: !0
            }
        }
    },
    gd = Y && Y.__values || function(e) {
        var t = typeof Symbol == "function" && Symbol.iterator,
            r = t && e[t],
            n = 0;
        if (r) return r.call(e);
        if (e && typeof e.length == "number") return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                }
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
    };
Object.defineProperty(Zn, "__esModule", {
    value: !0
});
Zn.JsonRpc = void 0;
var Bo = Kn,
    Li = on,
    _t = function(e) {
        var t, r, n = "";
        try {
            for (var i = gd(e), a = i.next(); !a.done; a = i.next()) {
                var o = a.value;
                n += ("00" + o.toString(16)).slice(-2)
            }
        } catch (s) {
            t = {
                error: s
            }
        } finally {
            try {
                a && !a.done && (r = i.return) && r.call(i)
            } finally {
                if (t) throw t.error
            }
        }
        return n
    },
    wd = function() {
        function e(t, r) {
            r === void 0 && (r = {}), this.endpoint = t.replace(/\/$/, ""), r.fetch ? this.fetchBuiltin = r.fetch : this.fetchBuiltin = Y.fetch
        }
        return e.prototype.fetch = function(t, r) {
            return ae(this, void 0, void 0, function() {
                var n, i, a, o;
                return oe(this, function(s) {
                    switch (s.label) {
                        case 0:
                            return s.trys.push([0, 3, , 4]), a = this.fetchBuiltin, [4, a(this.endpoint + t, {
                                body: JSON.stringify(r),
                                method: "POST"
                            })];
                        case 1:
                            return n = s.sent(), [4, n.json()];
                        case 2:
                            if (i = s.sent(), i.processed && i.processed.except) throw new Li.RpcError(i);
                            if (i.result && i.result.except) throw new Li.RpcError(i);
                            return [3, 4];
                        case 3:
                            throw o = s.sent(), o.isFetchError = !0, o;
                        case 4:
                            if (!n.ok) throw new Li.RpcError(i);
                            return [2, i]
                    }
                })
            })
        }, e.prototype.abi_bin_to_json = function(t, r, n) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/abi_bin_to_json", {
                                code: t,
                                action: r,
                                binargs: n
                            })];
                        case 1:
                            return [2, i.sent()]
                    }
                })
            })
        }, e.prototype.abi_json_to_bin = function(t, r, n) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/abi_json_to_bin", {
                                code: t,
                                action: r,
                                args: n
                            })];
                        case 1:
                            return [2, i.sent()]
                    }
                })
            })
        }, e.prototype.get_abi = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_abi", {
                                account_name: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_account = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_account", {
                                account_name: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_accounts_by_authorizers = function(t, r) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_accounts_by_authorizers", {
                                accounts: t,
                                keys: r
                            })];
                        case 1:
                            return [2, n.sent()]
                    }
                })
            })
        }, e.prototype.get_activated_protocol_features = function(t) {
            var r = t.limit,
                n = r === void 0 ? 10 : r,
                i = t.search_by_block_num,
                a = i === void 0 ? !1 : i,
                o = t.reverse,
                s = o === void 0 ? !1 : o,
                c = t.lower_bound,
                u = c === void 0 ? null : c,
                f = t.upper_bound,
                b = f === void 0 ? null : f;
            return ae(this, void 0, void 0, function() {
                return oe(this, function(_) {
                    switch (_.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_activated_protocol_features", {
                                lower_bound: u,
                                upper_bound: b,
                                limit: n,
                                search_by_block_num: a,
                                reverse: s
                            })];
                        case 1:
                            return [2, _.sent()]
                    }
                })
            })
        }, e.prototype.get_block_header_state = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_block_header_state", {
                                block_num_or_id: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_block_info = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_block_info", {
                                block_num: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_block = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_block", {
                                block_num_or_id: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_code = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_code", {
                                account_name: t,
                                code_as_wasm: !0
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_code_hash = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_code_hash", {
                                account_name: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_currency_balance = function(t, r, n) {
            return n === void 0 && (n = null), ae(this, void 0, void 0, function() {
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_currency_balance", {
                                code: t,
                                account: r,
                                symbol: n
                            })];
                        case 1:
                            return [2, i.sent()]
                    }
                })
            })
        }, e.prototype.get_currency_stats = function(t, r) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_currency_stats", {
                                code: t,
                                symbol: r
                            })];
                        case 1:
                            return [2, n.sent()]
                    }
                })
            })
        }, e.prototype.get_info = function() {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(t) {
                    switch (t.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_info", {})];
                        case 1:
                            return [2, t.sent()]
                    }
                })
            })
        }, e.prototype.get_producer_schedule = function() {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(t) {
                    switch (t.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_producer_schedule", {})];
                        case 1:
                            return [2, t.sent()]
                    }
                })
            })
        }, e.prototype.get_producers = function(t, r, n) {
            return t === void 0 && (t = !0), r === void 0 && (r = ""), n === void 0 && (n = 50), ae(this, void 0, void 0, function() {
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_producers", {
                                json: t,
                                lower_bound: r,
                                limit: n
                            })];
                        case 1:
                            return [2, i.sent()]
                    }
                })
            })
        }, e.prototype.get_raw_code_and_abi = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_raw_code_and_abi", {
                                account_name: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.getRawAbi = function(t) {
            return ae(this, void 0, void 0, function() {
                var r, n;
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.get_raw_abi(t)];
                        case 1:
                            return r = i.sent(), n = Bo.base64ToBinary(r.abi), [2, {
                                accountName: r.account_name,
                                abi: n
                            }]
                    }
                })
            })
        }, e.prototype.get_raw_abi = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_raw_abi", {
                                account_name: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.get_scheduled_transactions = function(t, r, n) {
            return t === void 0 && (t = !0), r === void 0 && (r = ""), n === void 0 && (n = 50), ae(this, void 0, void 0, function() {
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_scheduled_transactions", {
                                json: t,
                                lower_bound: r,
                                limit: n
                            })];
                        case 1:
                            return [2, i.sent()]
                    }
                })
            })
        }, e.prototype.get_table_rows = function(t) {
            var r = t.json,
                n = r === void 0 ? !0 : r,
                i = t.code,
                a = t.scope,
                o = t.table,
                s = t.lower_bound,
                c = s === void 0 ? "" : s,
                u = t.upper_bound,
                f = u === void 0 ? "" : u,
                b = t.index_position,
                _ = b === void 0 ? 1 : b,
                v = t.key_type,
                g = v === void 0 ? "" : v,
                k = t.limit,
                O = k === void 0 ? 10 : k,
                z = t.reverse,
                P = z === void 0 ? !1 : z,
                L = t.show_payer,
                y = L === void 0 ? !1 : L;
            return ae(this, void 0, void 0, function() {
                return oe(this, function(D) {
                    switch (D.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_table_rows", {
                                json: n,
                                code: i,
                                scope: a,
                                table: o,
                                lower_bound: c,
                                upper_bound: f,
                                index_position: _,
                                key_type: g,
                                limit: O,
                                reverse: P,
                                show_payer: y
                            })];
                        case 1:
                            return [2, D.sent()]
                    }
                })
            })
        }, e.prototype.get_kv_table_rows = function(t) {
            var r = t.json,
                n = r === void 0 ? !0 : r,
                i = t.code,
                a = t.table,
                o = t.index_name,
                s = t.encode_type,
                c = s === void 0 ? "bytes" : s,
                u = t.index_value,
                f = t.lower_bound,
                b = t.upper_bound,
                _ = t.limit,
                v = _ === void 0 ? 10 : _,
                g = t.reverse,
                k = g === void 0 ? !1 : g,
                O = t.show_payer,
                z = O === void 0 ? !1 : O;
            return ae(this, void 0, void 0, function() {
                return oe(this, function(P) {
                    switch (P.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_kv_table_rows", {
                                json: n,
                                code: i,
                                table: a,
                                index_name: o,
                                encode_type: c,
                                index_value: u,
                                lower_bound: f,
                                upper_bound: b,
                                limit: v,
                                reverse: k,
                                show_payer: z
                            })];
                        case 1:
                            return [2, P.sent()]
                    }
                })
            })
        }, e.prototype.get_table_by_scope = function(t) {
            var r = t.code,
                n = t.table,
                i = t.lower_bound,
                a = i === void 0 ? "" : i,
                o = t.upper_bound,
                s = o === void 0 ? "" : o,
                c = t.limit,
                u = c === void 0 ? 10 : c;
            return ae(this, void 0, void 0, function() {
                return oe(this, function(f) {
                    switch (f.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/get_table_by_scope", {
                                code: r,
                                table: n,
                                lower_bound: a,
                                upper_bound: s,
                                limit: u
                            })];
                        case 1:
                            return [2, f.sent()]
                    }
                })
            })
        }, e.prototype.getRequiredKeys = function(t) {
            return ae(this, void 0, void 0, function() {
                var r;
                return oe(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return r = Bo.convertLegacyPublicKeys, [4, this.fetch("/v1/chain/get_required_keys", {
                                transaction: t.transaction,
                                available_keys: t.availableKeys
                            })];
                        case 1:
                            return [2, r.apply(void 0, [n.sent().required_keys])]
                    }
                })
            })
        }, e.prototype.push_transaction = function(t) {
            var r = t.signatures,
                n = t.compression,
                i = n === void 0 ? 0 : n,
                a = t.serializedTransaction,
                o = t.serializedContextFreeData;
            return ae(this, void 0, void 0, function() {
                return oe(this, function(s) {
                    switch (s.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/push_transaction", {
                                signatures: r,
                                compression: i,
                                packed_context_free_data: _t(o || new Uint8Array(0)),
                                packed_trx: _t(a)
                            })];
                        case 1:
                            return [2, s.sent()]
                    }
                })
            })
        }, e.prototype.push_ro_transaction = function(t, r) {
            var n = t.signatures,
                i = t.compression,
                a = i === void 0 ? 0 : i,
                o = t.serializedTransaction;
            return r === void 0 && (r = !1), ae(this, void 0, void 0, function() {
                return oe(this, function(s) {
                    switch (s.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/push_ro_transaction", {
                                transaction: {
                                    signatures: n,
                                    compression: a,
                                    packed_context_free_data: _t(new Uint8Array(0)),
                                    packed_trx: _t(o)
                                },
                                return_failure_traces: r
                            })];
                        case 1:
                            return [2, s.sent()]
                    }
                })
            })
        }, e.prototype.push_transactions = function(t) {
            return ae(this, void 0, void 0, function() {
                var r;
                return oe(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return r = t.map(function(i) {
                                var a = i.signatures,
                                    o = i.compression,
                                    s = o === void 0 ? 0 : o,
                                    c = i.serializedTransaction,
                                    u = i.serializedContextFreeData;
                                return {
                                    signatures: a,
                                    compression: s,
                                    packed_context_free_data: _t(u || new Uint8Array(0)),
                                    packed_trx: _t(c)
                                }
                            }), [4, this.fetch("/v1/chain/push_transactions", r)];
                        case 1:
                            return [2, n.sent()]
                    }
                })
            })
        }, e.prototype.send_transaction = function(t) {
            var r = t.signatures,
                n = t.compression,
                i = n === void 0 ? 0 : n,
                a = t.serializedTransaction,
                o = t.serializedContextFreeData;
            return ae(this, void 0, void 0, function() {
                return oe(this, function(s) {
                    switch (s.label) {
                        case 0:
                            return [4, this.fetch("/v1/chain/send_transaction", {
                                signatures: r,
                                compression: i,
                                packed_context_free_data: _t(o || new Uint8Array(0)),
                                packed_trx: _t(a)
                            })];
                        case 1:
                            return [2, s.sent()]
                    }
                })
            })
        }, e.prototype.db_size_get = function() {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(t) {
                    switch (t.label) {
                        case 0:
                            return [4, this.fetch("/v1/db_size/get", {})];
                        case 1:
                            return [2, t.sent()]
                    }
                })
            })
        }, e.prototype.trace_get_block = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/trace_api/get_block", {
                                block_num: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.history_get_actions = function(t, r, n) {
            return r === void 0 && (r = null), n === void 0 && (n = null), ae(this, void 0, void 0, function() {
                return oe(this, function(i) {
                    switch (i.label) {
                        case 0:
                            return [4, this.fetch("/v1/history/get_actions", {
                                account_name: t,
                                pos: r,
                                offset: n
                            })];
                        case 1:
                            return [2, i.sent()]
                    }
                })
            })
        }, e.prototype.history_get_transaction = function(t, r) {
            return r === void 0 && (r = null), ae(this, void 0, void 0, function() {
                return oe(this, function(n) {
                    switch (n.label) {
                        case 0:
                            return [4, this.fetch("/v1/history/get_transaction", {
                                id: t,
                                block_num_hint: r
                            })];
                        case 1:
                            return [2, n.sent()]
                    }
                })
            })
        }, e.prototype.history_get_key_accounts = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/history/get_key_accounts", {
                                public_key: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e.prototype.history_get_controlled_accounts = function(t) {
            return ae(this, void 0, void 0, function() {
                return oe(this, function(r) {
                    switch (r.label) {
                        case 0:
                            return [4, this.fetch("/v1/history/get_controlled_accounts", {
                                controlling_account: t
                            })];
                        case 1:
                            return [2, r.sent()]
                    }
                })
            })
        }, e
    }();
Zn.JsonRpc = wd;
var vu = {};
Object.defineProperty(vu, "__esModule", {
    value: !0
});
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.Serialize = e.RpcError = e.RpcInterfaces = e.Numeric = e.JsonRpc = e.ApiInterfaces = e.Api = void 0;
    var t = St;
    Object.defineProperty(e, "Api", {
        enumerable: !0,
        get: function() {
            return t.Api
        }
    });
    var r = _u;
    e.ApiInterfaces = r;
    var n = Zn;
    Object.defineProperty(e, "JsonRpc", {
        enumerable: !0,
        get: function() {
            return n.JsonRpc
        }
    });
    var i = Kn;
    e.Numeric = i;
    var a = vu;
    e.RpcInterfaces = a;
    var o = on;
    Object.defineProperty(e, "RpcError", {
        enumerable: !0,
        get: function() {
            return o.RpcError
        }
    });
    var s = xa;
    e.Serialize = s
})(us);
var xd = ca(us),
    qn = {},
    vr = {
        exports: {}
    },
    jn = {
        exports: {}
    };
(function(e) {
    function t(r) {
        return e.exports = t = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(n) {
            return typeof n
        } : function(n) {
            return n && typeof Symbol == "function" && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n
        }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r)
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(jn);
(function(e) {
    var t = jn.exports.default;

    function r(i) {
        if (typeof WeakMap != "function") return null;
        var a = new WeakMap,
            o = new WeakMap;
        return (r = function(c) {
            return c ? o : a
        })(i)
    }

    function n(i, a) {
        if (!a && i && i.__esModule) return i;
        if (i === null || t(i) !== "object" && typeof i != "function") return {
            default: i
        };
        var o = r(a);
        if (o && o.has(i)) return o.get(i);
        var s = {},
            c = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var u in i)
            if (u !== "default" && Object.prototype.hasOwnProperty.call(i, u)) {
                var f = c ? Object.getOwnPropertyDescriptor(i, u) : null;
                f && (f.get || f.set) ? Object.defineProperty(s, u, f) : s[u] = i[u]
            }
        return s.default = i, o && o.set(i, s), s
    }
    e.exports = n, e.exports.__esModule = !0, e.exports.default = e.exports
})(vr);
var Le = {
    exports: {}
};
(function(e) {
    function t(r) {
        return r && r.__esModule ? r : {
            default: r
        }
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(Le);
var yu = {
    exports: {}
};
(function(e) {
    var t = function(r) {
        var n = Object.prototype,
            i = n.hasOwnProperty,
            a, o = typeof Symbol == "function" ? Symbol : {},
            s = o.iterator || "@@iterator",
            c = o.asyncIterator || "@@asyncIterator",
            u = o.toStringTag || "@@toStringTag";

        function f(I, T, h) {
            return Object.defineProperty(I, T, {
                value: h,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }), I[T]
        }
        try {
            f({}, "")
        } catch (I) {
            f = function(T, h, m) {
                return T[h] = m
            }
        }

        function b(I, T, h, m) {
            var S = T && T.prototype instanceof P ? T : P,
                C = Object.create(S.prototype),
                $ = new V(m || []);
            return C._invoke = F(I, h, $), C
        }
        r.wrap = b;

        function _(I, T, h) {
            try {
                return {
                    type: "normal",
                    arg: I.call(T, h)
                }
            } catch (m) {
                return {
                    type: "throw",
                    arg: m
                }
            }
        }
        var v = "suspendedStart",
            g = "suspendedYield",
            k = "executing",
            O = "completed",
            z = {};

        function P() {}

        function L() {}

        function y() {}
        var D = {};
        f(D, s, function() {
            return this
        });
        var w = Object.getPrototypeOf,
            x = w && w(w(ie([])));
        x && x !== n && i.call(x, s) && (D = x);
        var A = y.prototype = P.prototype = Object.create(D);
        L.prototype = y, f(A, "constructor", y), f(y, "constructor", L), L.displayName = f(y, u, "GeneratorFunction");

        function U(I) {
            ["next", "throw", "return"].forEach(function(T) {
                f(I, T, function(h) {
                    return this._invoke(T, h)
                })
            })
        }
        r.isGeneratorFunction = function(I) {
            var T = typeof I == "function" && I.constructor;
            return T ? T === L || (T.displayName || T.name) === "GeneratorFunction" : !1
        }, r.mark = function(I) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(I, y) : (I.__proto__ = y, f(I, u, "GeneratorFunction")), I.prototype = Object.create(A), I
        }, r.awrap = function(I) {
            return {
                __await: I
            }
        };

        function N(I, T) {
            function h(C, $, M, H) {
                var j = _(I[C], I, $);
                if (j.type === "throw") H(j.arg);
                else {
                    var ee = j.arg,
                        ce = ee.value;
                    return ce && typeof ce == "object" && i.call(ce, "__await") ? T.resolve(ce.__await).then(function(we) {
                        h("next", we, M, H)
                    }, function(we) {
                        h("throw", we, M, H)
                    }) : T.resolve(ce).then(function(we) {
                        ee.value = we, M(ee)
                    }, function(we) {
                        return h("throw", we, M, H)
                    })
                }
            }
            var m;

            function S(C, $) {
                function M() {
                    return new T(function(H, j) {
                        h(C, $, H, j)
                    })
                }
                return m = m ? m.then(M, M) : M()
            }
            this._invoke = S
        }
        U(N.prototype), f(N.prototype, c, function() {
            return this
        }), r.AsyncIterator = N, r.async = function(I, T, h, m, S) {
            S === void 0 && (S = Promise);
            var C = new N(b(I, T, h, m), S);
            return r.isGeneratorFunction(T) ? C : C.next().then(function($) {
                return $.done ? $.value : C.next()
            })
        };

        function F(I, T, h) {
            var m = v;
            return function(C, $) {
                if (m === k) throw new Error("Generator is already running");
                if (m === O) {
                    if (C === "throw") throw $;
                    return re()
                }
                for (h.method = C, h.arg = $;;) {
                    var M = h.delegate;
                    if (M) {
                        var H = W(M, h);
                        if (H) {
                            if (H === z) continue;
                            return H
                        }
                    }
                    if (h.method === "next") h.sent = h._sent = h.arg;
                    else if (h.method === "throw") {
                        if (m === v) throw m = O, h.arg;
                        h.dispatchException(h.arg)
                    } else h.method === "return" && h.abrupt("return", h.arg);
                    m = k;
                    var j = _(I, T, h);
                    if (j.type === "normal") {
                        if (m = h.done ? O : g, j.arg === z) continue;
                        return {
                            value: j.arg,
                            done: h.done
                        }
                    } else j.type === "throw" && (m = O, h.method = "throw", h.arg = j.arg)
                }
            }
        }

        function W(I, T) {
            var h = I.iterator[T.method];
            if (h === a) {
                if (T.delegate = null, T.method === "throw") {
                    if (I.iterator.return && (T.method = "return", T.arg = a, W(I, T), T.method === "throw")) return z;
                    T.method = "throw", T.arg = new TypeError("The iterator does not provide a 'throw' method")
                }
                return z
            }
            var m = _(h, I.iterator, T.arg);
            if (m.type === "throw") return T.method = "throw", T.arg = m.arg, T.delegate = null, z;
            var S = m.arg;
            if (!S) return T.method = "throw", T.arg = new TypeError("iterator result is not an object"), T.delegate = null, z;
            if (S.done) T[I.resultName] = S.value, T.next = I.nextLoc, T.method !== "return" && (T.method = "next", T.arg = a);
            else return S;
            return T.delegate = null, z
        }
        U(A), f(A, u, "Generator"), f(A, s, function() {
            return this
        }), f(A, "toString", function() {
            return "[object Generator]"
        });

        function K(I) {
            var T = {
                tryLoc: I[0]
            };
            1 in I && (T.catchLoc = I[1]), 2 in I && (T.finallyLoc = I[2], T.afterLoc = I[3]), this.tryEntries.push(T)
        }

        function Z(I) {
            var T = I.completion || {};
            T.type = "normal", delete T.arg, I.completion = T
        }

        function V(I) {
            this.tryEntries = [{
                tryLoc: "root"
            }], I.forEach(K, this), this.reset(!0)
        }
        r.keys = function(I) {
            var T = [];
            for (var h in I) T.push(h);
            return T.reverse(),
                function m() {
                    for (; T.length;) {
                        var S = T.pop();
                        if (S in I) return m.value = S, m.done = !1, m
                    }
                    return m.done = !0, m
                }
        };

        function ie(I) {
            if (I) {
                var T = I[s];
                if (T) return T.call(I);
                if (typeof I.next == "function") return I;
                if (!isNaN(I.length)) {
                    var h = -1,
                        m = function S() {
                            for (; ++h < I.length;)
                                if (i.call(I, h)) return S.value = I[h], S.done = !1, S;
                            return S.value = a, S.done = !0, S
                        };
                    return m.next = m
                }
            }
            return {
                next: re
            }
        }
        r.values = ie;

        function re() {
            return {
                value: a,
                done: !0
            }
        }
        return V.prototype = {
            constructor: V,
            reset: function(I) {
                if (this.prev = 0, this.next = 0, this.sent = this._sent = a, this.done = !1, this.delegate = null, this.method = "next", this.arg = a, this.tryEntries.forEach(Z), !I)
                    for (var T in this) T.charAt(0) === "t" && i.call(this, T) && !isNaN(+T.slice(1)) && (this[T] = a)
            },
            stop: function() {
                this.done = !0;
                var I = this.tryEntries[0],
                    T = I.completion;
                if (T.type === "throw") throw T.arg;
                return this.rval
            },
            dispatchException: function(I) {
                if (this.done) throw I;
                var T = this;

                function h(H, j) {
                    return C.type = "throw", C.arg = I, T.next = H, j && (T.method = "next", T.arg = a), !!j
                }
                for (var m = this.tryEntries.length - 1; m >= 0; --m) {
                    var S = this.tryEntries[m],
                        C = S.completion;
                    if (S.tryLoc === "root") return h("end");
                    if (S.tryLoc <= this.prev) {
                        var $ = i.call(S, "catchLoc"),
                            M = i.call(S, "finallyLoc");
                        if ($ && M) {
                            if (this.prev < S.catchLoc) return h(S.catchLoc, !0);
                            if (this.prev < S.finallyLoc) return h(S.finallyLoc)
                        } else if ($) {
                            if (this.prev < S.catchLoc) return h(S.catchLoc, !0)
                        } else if (M) {
                            if (this.prev < S.finallyLoc) return h(S.finallyLoc)
                        } else throw new Error("try statement without catch or finally")
                    }
                }
            },
            abrupt: function(I, T) {
                for (var h = this.tryEntries.length - 1; h >= 0; --h) {
                    var m = this.tryEntries[h];
                    if (m.tryLoc <= this.prev && i.call(m, "finallyLoc") && this.prev < m.finallyLoc) {
                        var S = m;
                        break
                    }
                }
                S && (I === "break" || I === "continue") && S.tryLoc <= T && T <= S.finallyLoc && (S = null);
                var C = S ? S.completion : {};
                return C.type = I, C.arg = T, S ? (this.method = "next", this.next = S.finallyLoc, z) : this.complete(C)
            },
            complete: function(I, T) {
                if (I.type === "throw") throw I.arg;
                return I.type === "break" || I.type === "continue" ? this.next = I.arg : I.type === "return" ? (this.rval = this.arg = I.arg, this.method = "return", this.next = "end") : I.type === "normal" && T && (this.next = T), z
            },
            finish: function(I) {
                for (var T = this.tryEntries.length - 1; T >= 0; --T) {
                    var h = this.tryEntries[T];
                    if (h.finallyLoc === I) return this.complete(h.completion, h.afterLoc), Z(h), z
                }
            },
            catch: function(I) {
                for (var T = this.tryEntries.length - 1; T >= 0; --T) {
                    var h = this.tryEntries[T];
                    if (h.tryLoc === I) {
                        var m = h.completion;
                        if (m.type === "throw") {
                            var S = m.arg;
                            Z(h)
                        }
                        return S
                    }
                }
                throw new Error("illegal catch attempt")
            },
            delegateYield: function(I, T, h) {
                return this.delegate = {
                    iterator: ie(I),
                    resultName: T,
                    nextLoc: h
                }, this.method === "next" && (this.arg = a), z
            }
        }, r
    }(e.exports);
    try {
        regeneratorRuntime = t
    } catch (r) {
        typeof globalThis == "object" ? globalThis.regeneratorRuntime = t : Function("r", "regeneratorRuntime = r")(t)
    }
})(yu);
var yr = yu.exports,
    Wt = {
        exports: {}
    };
(function(e) {
    function t(n, i, a, o, s, c, u) {
        try {
            var f = n[c](u),
                b = f.value
        } catch (_) {
            a(_);
            return
        }
        f.done ? i(b) : Promise.resolve(b).then(o, s)
    }

    function r(n) {
        return function() {
            var i = this,
                a = arguments;
            return new Promise(function(o, s) {
                var c = n.apply(i, a);

                function u(b) {
                    t(c, o, s, u, f, "next", b)
                }

                function f(b) {
                    t(c, o, s, u, f, "throw", b)
                }
                u(void 0)
            })
        }
    }
    e.exports = r, e.exports.__esModule = !0, e.exports.default = e.exports
})(Wt);
var Ie = {
    exports: {}
};
(function(e) {
    function t(r, n) {
        if (!(r instanceof n)) throw new TypeError("Cannot call a class as a function")
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(Ie);
var Be = {
    exports: {}
};
(function(e) {
    function t(n, i) {
        for (var a = 0; a < i.length; a++) {
            var o = i[a];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(n, o.key, o)
        }
    }

    function r(n, i, a) {
        return i && t(n.prototype, i), a && t(n, a), Object.defineProperty(n, "prototype", {
            writable: !1
        }), n
    }
    e.exports = r, e.exports.__esModule = !0, e.exports.default = e.exports
})(Be);
var bu = {},
    br = {};
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.WALLET_SUPPORT = e.BLOCKCHAIN_SUPPORT = void 0, e.BLOCKCHAIN_SUPPORT = "blockchain_support", e.WALLET_SUPPORT = "wallet_support"
})(br);
(function(e) {
    var t = vr.exports,
        r = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var n = r(yr),
        i = r(Wt.exports),
        a = r(Ie.exports),
        o = r(Be.exports),
        s = t(br),
        c = function() {
            function b() {
                (0, a.default)(this, b), this.plugins = []
            }
            return (0, o.default)(b, [{
                key: "loadPlugin",
                value: function(v) {
                    this.plugin(v.name) || this.plugins.push(v)
                }
            }, {
                key: "wallets",
                value: function() {
                    return this.plugins.filter(function(v) {
                        return v.type === s.WALLET_SUPPORT
                    })
                }
            }, {
                key: "signatureProviders",
                value: function() {
                    return this.plugins.filter(function(v) {
                        return v.type === s.BLOCKCHAIN_SUPPORT
                    })
                }
            }, {
                key: "supportedBlockchains",
                value: function() {
                    return this.signatureProviders().map(function() {
                        return name
                    })
                }
            }, {
                key: "plugin",
                value: function(v) {
                    return this.plugins.find(function(g) {
                        return g.name === v
                    })
                }
            }, {
                key: "endorsedNetworks",
                value: function() {
                    var _ = (0, i.default)(n.default.mark(function v() {
                        return n.default.wrap(function(g) {
                            for (;;) switch (g.prev = g.next) {
                                case 0:
                                    return g.next = 2, Promise.all(this.signatureProviders().map(function() {
                                        var k = (0, i.default)(n.default.mark(function O(z) {
                                            return n.default.wrap(function(P) {
                                                for (;;) switch (P.prev = P.next) {
                                                    case 0:
                                                        return P.next = 2, z.getEndorsedNetwork();
                                                    case 2:
                                                        return P.abrupt("return", P.sent);
                                                    case 3:
                                                    case "end":
                                                        return P.stop()
                                                }
                                            }, O, this)
                                        }));
                                        return function() {
                                            return k.apply(this, arguments)
                                        }
                                    }()));
                                case 2:
                                    return g.abrupt("return", g.sent);
                                case 3:
                                case "end":
                                    return g.stop()
                            }
                        }, v, this)
                    }));
                    return function() {
                        return _.apply(this, arguments)
                    }
                }()
            }]), b
        }(),
        u = new c,
        f = u;
    e.default = f
})(bu);
var Gn = {},
    gu = {
        exports: {}
    },
    wu = {
        exports: {}
    };
(function(e) {
    function t(r) {
        if (Array.isArray(r)) return r
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(wu);
var xu = {
    exports: {}
};
(function(e) {
    function t(r, n) {
        var i = r == null ? null : typeof Symbol < "u" && r[Symbol.iterator] || r["@@iterator"];
        if (i != null) {
            var a = [],
                o = !0,
                s = !1,
                c, u;
            try {
                for (i = i.call(r); !(o = (c = i.next()).done) && (a.push(c.value), !(n && a.length === n)); o = !0);
            } catch (f) {
                s = !0, u = f
            } finally {
                try {
                    !o && i.return != null && i.return()
                } finally {
                    if (s) throw u
                }
            }
            return a
        }
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(xu);
var mu = {
        exports: {}
    },
    Eu = {
        exports: {}
    };
(function(e) {
    function t(r, n) {
        (n == null || n > r.length) && (n = r.length);
        for (var i = 0, a = new Array(n); i < n; i++) a[i] = r[i];
        return a
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(Eu);
(function(e) {
    var t = Eu.exports;

    function r(n, i) {
        if (!!n) {
            if (typeof n == "string") return t(n, i);
            var a = Object.prototype.toString.call(n).slice(8, -1);
            if (a === "Object" && n.constructor && (a = n.constructor.name), a === "Map" || a === "Set") return Array.from(n);
            if (a === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a)) return t(n, i)
        }
    }
    e.exports = r, e.exports.__esModule = !0, e.exports.default = e.exports
})(mu);
var Su = {
    exports: {}
};
(function(e) {
    function t() {
        throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`)
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(Su);
(function(e) {
    var t = wu.exports,
        r = xu.exports,
        n = mu.exports,
        i = Su.exports;

    function a(o, s) {
        return t(o) || r(o, s) || n(o, s) || i()
    }
    e.exports = a, e.exports.__esModule = !0, e.exports.default = e.exports
})(gu);
var Au = {};
(function(e) {
    var t = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = t(Ie.exports),
        n = t(Be.exports),
        i = {},
        a = function() {
            return typeof window > "u" ? {
                localStorage: {
                    setItem: function(c, u) {
                        return i[c] = u
                    },
                    getItem: function(c) {
                        return i[c] || null
                    },
                    removeItem: function(c) {
                        return delete i[c]
                    }
                }
            } : window
        },
        o = function() {
            function s() {
                (0, r.default)(this, s)
            }
            return (0, n.default)(s, null, [{
                key: "setAppKey",
                value: function(u) {
                    a().localStorage.setItem("appkey", u)
                }
            }, {
                key: "getAppKey",
                value: function() {
                    return a().localStorage.getItem("appkey")
                }
            }, {
                key: "removeAppKey",
                value: function() {
                    return a().localStorage.removeItem("appkey")
                }
            }, {
                key: "setNonce",
                value: function(u) {
                    a().localStorage.setItem("nonce", u)
                }
            }, {
                key: "getNonce",
                value: function() {
                    return a().localStorage.getItem("nonce")
                }
            }, {
                key: "removeNonce",
                value: function() {
                    return a().localStorage.removeItem("nonce")
                }
            }]), s
        }();
    e.default = o
})(Au);
var Mr;
typeof window < "u" ? Mr = window : typeof Y < "u" ? Mr = Y : typeof self < "u" ? Mr = self : Mr = {};
var md = Mr,
    Ed = {},
    Sd = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Ed
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    Ea = Al(Sd),
    Xt = md,
    Mo = Ea;

function Ad(e) {
    if (Xt.crypto && Xt.crypto.getRandomValues) return Xt.crypto.getRandomValues(e);
    if (typeof Xt.msCrypto == "object" && typeof Xt.msCrypto.getRandomValues == "function") return Xt.msCrypto.getRandomValues(e);
    if (Mo.randomBytes) {
        if (!(e instanceof Uint8Array)) throw new TypeError("expected Uint8Array");
        if (e.length > 65536) {
            var t = new Error;
            throw t.code = 22, t.message = "Failed to execute 'getRandomValues' on 'Crypto': The ArrayBufferView's byte length (" + e.length + ") exceeds the number of bytes of entropy available via this API (65536).", t.name = "QuotaExceededError", t
        }
        var r = Mo.randomBytes(e.length);
        return e.set(r), e
    } else throw new Error("No secure random number generator available.")
}
var kd = Ad,
    De = {
        exports: {}
    }; /*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
(function(e, t) {
    var r = Xr,
        n = r.Buffer;

    function i(o, s) {
        for (var c in o) s[c] = o[c]
    }
    n.from && n.alloc && n.allocUnsafe && n.allocUnsafeSlow ? e.exports = r : (i(r, t), t.Buffer = a);

    function a(o, s, c) {
        return n(o, s, c)
    }
    a.prototype = Object.create(n.prototype), i(n, a), a.from = function(o, s, c) {
        if (typeof o == "number") throw new TypeError("Argument must not be a number");
        return n(o, s, c)
    }, a.alloc = function(o, s, c) {
        if (typeof o != "number") throw new TypeError("Argument must be a number");
        var u = n(o);
        return s !== void 0 ? typeof c == "string" ? u.fill(s, c) : u.fill(s) : u.fill(0), u
    }, a.allocUnsafe = function(o) {
        if (typeof o != "number") throw new TypeError("Argument must be a number");
        return n(o)
    }, a.allocUnsafeSlow = function(o) {
        if (typeof o != "number") throw new TypeError("Argument must be a number");
        return r.SlowBuffer(o)
    }
})(De, De.exports);
var aa = {
        exports: {}
    },
    ku = ha.exports.EventEmitter;

function Uo(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter(function(i) {
            return Object.getOwnPropertyDescriptor(e, i).enumerable
        })), r.push.apply(r, n)
    }
    return r
}

function Td(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t] != null ? arguments[t] : {};
        t % 2 ? Uo(Object(r), !0).forEach(function(n) {
            zd(e, n, r[n])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Uo(Object(r)).forEach(function(n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n))
        })
    }
    return e
}

function zd(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e
}

function Rd(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function $o(e, t) {
    for (var r = 0; r < t.length; r++) {
        var n = t[r];
        n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
    }
}

function Od(e, t, r) {
    return t && $o(e.prototype, t), r && $o(e, r), e
}
var Dd = Xr,
    Dn = Dd.Buffer,
    Pd = Ea,
    oa = Pd.inspect,
    Cd = oa && oa.custom || "inspect";

function Nd(e, t, r) {
    Dn.prototype.copy.call(e, t, r)
}
var Ld = function() {
    function e() {
        Rd(this, e), this.head = null, this.tail = null, this.length = 0
    }
    return Od(e, [{
        key: "push",
        value: function(r) {
            var n = {
                data: r,
                next: null
            };
            this.length > 0 ? this.tail.next = n : this.head = n, this.tail = n, ++this.length
        }
    }, {
        key: "unshift",
        value: function(r) {
            var n = {
                data: r,
                next: this.head
            };
            this.length === 0 && (this.tail = n), this.head = n, ++this.length
        }
    }, {
        key: "shift",
        value: function() {
            if (this.length !== 0) {
                var r = this.head.data;
                return this.length === 1 ? this.head = this.tail = null : this.head = this.head.next, --this.length, r
            }
        }
    }, {
        key: "clear",
        value: function() {
            this.head = this.tail = null, this.length = 0
        }
    }, {
        key: "join",
        value: function(r) {
            if (this.length === 0) return "";
            for (var n = this.head, i = "" + n.data; n = n.next;) i += r + n.data;
            return i
        }
    }, {
        key: "concat",
        value: function(r) {
            if (this.length === 0) return Dn.alloc(0);
            for (var n = Dn.allocUnsafe(r >>> 0), i = this.head, a = 0; i;) Nd(i.data, n, a), a += i.data.length, i = i.next;
            return n
        }
    }, {
        key: "consume",
        value: function(r, n) {
            var i;
            return r < this.head.data.length ? (i = this.head.data.slice(0, r), this.head.data = this.head.data.slice(r)) : r === this.head.data.length ? i = this.shift() : i = n ? this._getString(r) : this._getBuffer(r), i
        }
    }, {
        key: "first",
        value: function() {
            return this.head.data
        }
    }, {
        key: "_getString",
        value: function(r) {
            var n = this.head,
                i = 1,
                a = n.data;
            for (r -= a.length; n = n.next;) {
                var o = n.data,
                    s = r > o.length ? o.length : r;
                if (s === o.length ? a += o : a += o.slice(0, r), r -= s, r === 0) {
                    s === o.length ? (++i, n.next ? this.head = n.next : this.head = this.tail = null) : (this.head = n, n.data = o.slice(s));
                    break
                }++i
            }
            return this.length -= i, a
        }
    }, {
        key: "_getBuffer",
        value: function(r) {
            var n = Dn.allocUnsafe(r),
                i = this.head,
                a = 1;
            for (i.data.copy(n), r -= i.data.length; i = i.next;) {
                var o = i.data,
                    s = r > o.length ? o.length : r;
                if (o.copy(n, n.length - r, 0, s), r -= s, r === 0) {
                    s === o.length ? (++a, i.next ? this.head = i.next : this.head = this.tail = null) : (this.head = i, i.data = o.slice(s));
                    break
                }++a
            }
            return this.length -= a, n
        }
    }, {
        key: Cd,
        value: function(r, n) {
            return oa(this, Td({}, n, {
                depth: 0,
                customInspect: !1
            }))
        }
    }]), e
}();

function Id(e, t) {
    var r = this,
        n = this._readableState && this._readableState.destroyed,
        i = this._writableState && this._writableState.destroyed;
    return n || i ? (t ? t(e) : e && (this._writableState ? this._writableState.errorEmitted || (this._writableState.errorEmitted = !0, process.nextTick(sa, this, e)) : process.nextTick(sa, this, e)), this) : (this._readableState && (this._readableState.destroyed = !0), this._writableState && (this._writableState.destroyed = !0), this._destroy(e || null, function(a) {
        !t && a ? r._writableState ? r._writableState.errorEmitted ? process.nextTick(Pn, r) : (r._writableState.errorEmitted = !0, process.nextTick(Fo, r, a)) : process.nextTick(Fo, r, a) : t ? (process.nextTick(Pn, r), t(a)) : process.nextTick(Pn, r)
    }), this)
}

function Fo(e, t) {
    sa(e, t), Pn(e)
}

function Pn(e) {
    e._writableState && !e._writableState.emitClose || e._readableState && !e._readableState.emitClose || e.emit("close")
}

function Bd() {
    this._readableState && (this._readableState.destroyed = !1, this._readableState.reading = !1, this._readableState.ended = !1, this._readableState.endEmitted = !1), this._writableState && (this._writableState.destroyed = !1, this._writableState.ended = !1, this._writableState.ending = !1, this._writableState.finalCalled = !1, this._writableState.prefinished = !1, this._writableState.finished = !1, this._writableState.errorEmitted = !1)
}

function sa(e, t) {
    e.emit("error", t)
}

function Md(e, t) {
    var r = e._readableState,
        n = e._writableState;
    r && r.autoDestroy || n && n.autoDestroy ? e.destroy(t) : e.emit("error", t)
}
var Tu = {
        destroy: Id,
        undestroy: Bd,
        errorOrDestroy: Md
    },
    Zt = {};

function Ud(e, t) {
    e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
}
var zu = {};

function Me(e, t, r) {
    r || (r = Error);

    function n(a, o, s) {
        return typeof t == "string" ? t : t(a, o, s)
    }
    var i = function(a) {
        Ud(o, a);

        function o(s, c, u) {
            return a.call(this, n(s, c, u)) || this
        }
        return o
    }(r);
    i.prototype.name = r.name, i.prototype.code = e, zu[e] = i
}

function Ho(e, t) {
    if (Array.isArray(e)) {
        var r = e.length;
        return e = e.map(function(n) {
            return String(n)
        }), r > 2 ? "one of ".concat(t, " ").concat(e.slice(0, r - 1).join(", "), ", or ") + e[r - 1] : r === 2 ? "one of ".concat(t, " ").concat(e[0], " or ").concat(e[1]) : "of ".concat(t, " ").concat(e[0])
    } else return "of ".concat(t, " ").concat(String(e))
}

function $d(e, t, r) {
    return e.substr(!r || r < 0 ? 0 : +r, t.length) === t
}

function Fd(e, t, r) {
    return (r === void 0 || r > e.length) && (r = e.length), e.substring(r - t.length, r) === t
}

function Hd(e, t, r) {
    return typeof r != "number" && (r = 0), r + t.length > e.length ? !1 : e.indexOf(t, r) !== -1
}
Me("ERR_INVALID_OPT_VALUE", function(e, t) {
    return 'The value "' + t + '" is invalid for option "' + e + '"'
}, TypeError);
Me("ERR_INVALID_ARG_TYPE", function(e, t, r) {
    var n;
    typeof t == "string" && $d(t, "not ") ? (n = "must not be", t = t.replace(/^not /, "")) : n = "must be";
    var i;
    if (Fd(e, " argument")) i = "The ".concat(e, " ").concat(n, " ").concat(Ho(t, "type"));
    else {
        var a = Hd(e, ".") ? "property" : "argument";
        i = 'The "'.concat(e, '" ').concat(a, " ").concat(n, " ").concat(Ho(t, "type"))
    }
    return i += ". Received type ".concat(typeof r), i
}, TypeError);
Me("ERR_STREAM_PUSH_AFTER_EOF", "stream.push() after EOF");
Me("ERR_METHOD_NOT_IMPLEMENTED", function(e) {
    return "The " + e + " method is not implemented"
});
Me("ERR_STREAM_PREMATURE_CLOSE", "Premature close");
Me("ERR_STREAM_DESTROYED", function(e) {
    return "Cannot call " + e + " after a stream was destroyed"
});
Me("ERR_MULTIPLE_CALLBACK", "Callback called multiple times");
Me("ERR_STREAM_CANNOT_PIPE", "Cannot pipe, not readable");
Me("ERR_STREAM_WRITE_AFTER_END", "write after end");
Me("ERR_STREAM_NULL_VALUES", "May not write null values to stream", TypeError);
Me("ERR_UNKNOWN_ENCODING", function(e) {
    return "Unknown encoding: " + e
}, TypeError);
Me("ERR_STREAM_UNSHIFT_AFTER_END_EVENT", "stream.unshift() after end event");
Zt.codes = zu;
var Kd = Zt.codes.ERR_INVALID_OPT_VALUE;

function Wd(e, t, r) {
    return e.highWaterMark != null ? e.highWaterMark : t ? e[r] : null
}

function Zd(e, t, r, n) {
    var i = Wd(t, n, r);
    if (i != null) {
        if (!(isFinite(i) && Math.floor(i) === i) || i < 0) {
            var a = n ? r : "highWaterMark";
            throw new Kd(a, i)
        }
        return Math.floor(i)
    }
    return e.objectMode ? 16 : 16 * 1024
}
var Ru = {
        getHighWaterMark: Zd
    },
    qd = jd;

function jd(e, t) {
    if (Ii("noDeprecation")) return e;
    var r = !1;

    function n() {
        if (!r) {
            if (Ii("throwDeprecation")) throw new Error(t);
            Ii("traceDeprecation") ? console.trace(t) : console.warn(t), r = !0
        }
        return e.apply(this, arguments)
    }
    return n
}

function Ii(e) {
    try {
        if (!Y.localStorage) return !1
    } catch (r) {
        return !1
    }
    var t = Y.localStorage[e];
    return t == null ? !1 : String(t).toLowerCase() === "true"
}
var Sa = pe;

function Ou(e) {
    var t = this;
    this.next = null, this.entry = null, this.finish = function() {
        w0(t, e)
    }
}
var tr;
pe.WritableState = sn;
var Gd = {
        deprecate: qd
    },
    Du = ku,
    Vn = Xr.Buffer,
    Vd = Y.Uint8Array || function() {};

function Yd(e) {
    return Vn.from(e)
}

function Jd(e) {
    return Vn.isBuffer(e) || e instanceof Vd
}
var Aa = Tu,
    Xd = Ru,
    Qd = Xd.getHighWaterMark,
    zt = Zt.codes,
    e0 = zt.ERR_INVALID_ARG_TYPE,
    t0 = zt.ERR_METHOD_NOT_IMPLEMENTED,
    r0 = zt.ERR_MULTIPLE_CALLBACK,
    n0 = zt.ERR_STREAM_CANNOT_PIPE,
    i0 = zt.ERR_STREAM_DESTROYED,
    a0 = zt.ERR_STREAM_NULL_VALUES,
    o0 = zt.ERR_STREAM_WRITE_AFTER_END,
    s0 = zt.ERR_UNKNOWN_ENCODING,
    sr = Aa.errorOrDestroy;
ye.exports(pe, Du);

function u0() {}

function sn(e, t, r) {
    tr = tr || qt, e = e || {}, typeof r != "boolean" && (r = t instanceof tr), this.objectMode = !!e.objectMode, r && (this.objectMode = this.objectMode || !!e.writableObjectMode), this.highWaterMark = Qd(this, e, "writableHighWaterMark", r), this.finalCalled = !1, this.needDrain = !1, this.ending = !1, this.ended = !1, this.finished = !1, this.destroyed = !1;
    var n = e.decodeStrings === !1;
    this.decodeStrings = !n, this.defaultEncoding = e.defaultEncoding || "utf8", this.length = 0, this.writing = !1, this.corked = 0, this.sync = !0, this.bufferProcessing = !1, this.onwrite = function(i) {
        _0(t, i)
    }, this.writecb = null, this.writelen = 0, this.bufferedRequest = null, this.lastBufferedRequest = null, this.pendingcb = 0, this.prefinished = !1, this.errorEmitted = !1, this.emitClose = e.emitClose !== !1, this.autoDestroy = !!e.autoDestroy, this.bufferedRequestCount = 0, this.corkedRequestsFree = new Ou(this)
}
sn.prototype.getBuffer = function() {
    for (var t = this.bufferedRequest, r = []; t;) r.push(t), t = t.next;
    return r
};
(function() {
    try {
        Object.defineProperty(sn.prototype, "buffer", {
            get: Gd.deprecate(function() {
                return this.getBuffer()
            }, "_writableState.buffer is deprecated. Use _writableState.getBuffer instead.", "DEP0003")
        })
    } catch (e) {}
})();
var Cn;
typeof Symbol == "function" && Symbol.hasInstance && typeof Function.prototype[Symbol.hasInstance] == "function" ? (Cn = Function.prototype[Symbol.hasInstance], Object.defineProperty(pe, Symbol.hasInstance, {
    value: function(t) {
        return Cn.call(this, t) ? !0 : this !== pe ? !1 : t && t._writableState instanceof sn
    }
})) : Cn = function(t) {
    return t instanceof this
};

function pe(e) {
    tr = tr || qt;
    var t = this instanceof tr;
    if (!t && !Cn.call(pe, this)) return new pe(e);
    this._writableState = new sn(e, this, t), this.writable = !0, e && (typeof e.write == "function" && (this._write = e.write), typeof e.writev == "function" && (this._writev = e.writev), typeof e.destroy == "function" && (this._destroy = e.destroy), typeof e.final == "function" && (this._final = e.final)), Du.call(this)
}
pe.prototype.pipe = function() {
    sr(this, new n0)
};

function l0(e, t) {
    var r = new o0;
    sr(e, r), process.nextTick(t, r)
}

function f0(e, t, r, n) {
    var i;
    return r === null ? i = new a0 : typeof r != "string" && !t.objectMode && (i = new e0("chunk", ["string", "Buffer"], r)), i ? (sr(e, i), process.nextTick(n, i), !1) : !0
}
pe.prototype.write = function(e, t, r) {
    var n = this._writableState,
        i = !1,
        a = !n.objectMode && Jd(e);
    return a && !Vn.isBuffer(e) && (e = Yd(e)), typeof t == "function" && (r = t, t = null), a ? t = "buffer" : t || (t = n.defaultEncoding), typeof r != "function" && (r = u0), n.ending ? l0(this, r) : (a || f0(this, n, e, r)) && (n.pendingcb++, i = h0(this, n, a, e, t, r)), i
};
pe.prototype.cork = function() {
    this._writableState.corked++
};
pe.prototype.uncork = function() {
    var e = this._writableState;
    e.corked && (e.corked--, !e.writing && !e.corked && !e.bufferProcessing && e.bufferedRequest && Pu(this, e))
};
pe.prototype.setDefaultEncoding = function(t) {
    if (typeof t == "string" && (t = t.toLowerCase()), !(["hex", "utf8", "utf-8", "ascii", "binary", "base64", "ucs2", "ucs-2", "utf16le", "utf-16le", "raw"].indexOf((t + "").toLowerCase()) > -1)) throw new s0(t);
    return this._writableState.defaultEncoding = t, this
};
Object.defineProperty(pe.prototype, "writableBuffer", {
    enumerable: !1,
    get: function() {
        return this._writableState && this._writableState.getBuffer()
    }
});

function c0(e, t, r) {
    return !e.objectMode && e.decodeStrings !== !1 && typeof t == "string" && (t = Vn.from(t, r)), t
}
Object.defineProperty(pe.prototype, "writableHighWaterMark", {
    enumerable: !1,
    get: function() {
        return this._writableState.highWaterMark
    }
});

function h0(e, t, r, n, i, a) {
    if (!r) {
        var o = c0(t, n, i);
        n !== o && (r = !0, i = "buffer", n = o)
    }
    var s = t.objectMode ? 1 : n.length;
    t.length += s;
    var c = t.length < t.highWaterMark;
    if (c || (t.needDrain = !0), t.writing || t.corked) {
        var u = t.lastBufferedRequest;
        t.lastBufferedRequest = {
            chunk: n,
            encoding: i,
            isBuf: r,
            callback: a,
            next: null
        }, u ? u.next = t.lastBufferedRequest : t.bufferedRequest = t.lastBufferedRequest, t.bufferedRequestCount += 1
    } else ua(e, t, !1, s, n, i, a);
    return c
}

function ua(e, t, r, n, i, a, o) {
    t.writelen = n, t.writecb = o, t.writing = !0, t.sync = !0, t.destroyed ? t.onwrite(new i0("write")) : r ? e._writev(i, t.onwrite) : e._write(i, a, t.onwrite), t.sync = !1
}

function d0(e, t, r, n, i) {
    --t.pendingcb, r ? (process.nextTick(i, n), process.nextTick(Yr, e, t), e._writableState.errorEmitted = !0, sr(e, n)) : (i(n), e._writableState.errorEmitted = !0, sr(e, n), Yr(e, t))
}

function p0(e) {
    e.writing = !1, e.writecb = null, e.length -= e.writelen, e.writelen = 0
}

function _0(e, t) {
    var r = e._writableState,
        n = r.sync,
        i = r.writecb;
    if (typeof i != "function") throw new r0;
    if (p0(r), t) d0(e, r, n, t, i);
    else {
        var a = Cu(r) || e.destroyed;
        !a && !r.corked && !r.bufferProcessing && r.bufferedRequest && Pu(e, r), n ? process.nextTick(Ko, e, r, a, i) : Ko(e, r, a, i)
    }
}

function Ko(e, t, r, n) {
    r || v0(e, t), t.pendingcb--, n(), Yr(e, t)
}

function v0(e, t) {
    t.length === 0 && t.needDrain && (t.needDrain = !1, e.emit("drain"))
}

function Pu(e, t) {
    t.bufferProcessing = !0;
    var r = t.bufferedRequest;
    if (e._writev && r && r.next) {
        var n = t.bufferedRequestCount,
            i = new Array(n),
            a = t.corkedRequestsFree;
        a.entry = r;
        for (var o = 0, s = !0; r;) i[o] = r, r.isBuf || (s = !1), r = r.next, o += 1;
        i.allBuffers = s, ua(e, t, !0, t.length, i, "", a.finish), t.pendingcb++, t.lastBufferedRequest = null, a.next ? (t.corkedRequestsFree = a.next, a.next = null) : t.corkedRequestsFree = new Ou(t), t.bufferedRequestCount = 0
    } else {
        for (; r;) {
            var c = r.chunk,
                u = r.encoding,
                f = r.callback,
                b = t.objectMode ? 1 : c.length;
            if (ua(e, t, !1, b, c, u, f), r = r.next, t.bufferedRequestCount--, t.writing) break
        }
        r === null && (t.lastBufferedRequest = null)
    }
    t.bufferedRequest = r, t.bufferProcessing = !1
}
pe.prototype._write = function(e, t, r) {
    r(new t0("_write()"))
};
pe.prototype._writev = null;
pe.prototype.end = function(e, t, r) {
    var n = this._writableState;
    return typeof e == "function" ? (r = e, e = null, t = null) : typeof t == "function" && (r = t, t = null), e != null && this.write(e, t), n.corked && (n.corked = 1, this.uncork()), n.ending || g0(this, n, r), this
};
Object.defineProperty(pe.prototype, "writableLength", {
    enumerable: !1,
    get: function() {
        return this._writableState.length
    }
});

function Cu(e) {
    return e.ending && e.length === 0 && e.bufferedRequest === null && !e.finished && !e.writing
}

function y0(e, t) {
    e._final(function(r) {
        t.pendingcb--, r && sr(e, r), t.prefinished = !0, e.emit("prefinish"), Yr(e, t)
    })
}

function b0(e, t) {
    !t.prefinished && !t.finalCalled && (typeof e._final == "function" && !t.destroyed ? (t.pendingcb++, t.finalCalled = !0, process.nextTick(y0, e, t)) : (t.prefinished = !0, e.emit("prefinish")))
}

function Yr(e, t) {
    var r = Cu(t);
    if (r && (b0(e, t), t.pendingcb === 0 && (t.finished = !0, e.emit("finish"), t.autoDestroy))) {
        var n = e._readableState;
        (!n || n.autoDestroy && n.endEmitted) && e.destroy()
    }
    return r
}

function g0(e, t, r) {
    t.ending = !0, Yr(e, t), r && (t.finished ? process.nextTick(r) : e.once("finish", r)), t.ended = !0, e.writable = !1
}

function w0(e, t, r) {
    var n = e.entry;
    for (e.entry = null; n;) {
        var i = n.callback;
        t.pendingcb--, i(r), n = n.next
    }
    t.corkedRequestsFree.next = e
}
Object.defineProperty(pe.prototype, "destroyed", {
    enumerable: !1,
    get: function() {
        return this._writableState === void 0 ? !1 : this._writableState.destroyed
    },
    set: function(t) {
        !this._writableState || (this._writableState.destroyed = t)
    }
});
pe.prototype.destroy = Aa.destroy;
pe.prototype._undestroy = Aa.undestroy;
pe.prototype._destroy = function(e, t) {
    t(e)
};
var x0 = Object.keys || function(e) {
        var t = [];
        for (var r in e) t.push(r);
        return t
    },
    qt = rt,
    Nu = za,
    la = Sa;
ye.exports(rt, Nu);
for (var Wo = x0(la.prototype), Bi = 0; Bi < Wo.length; Bi++) {
    var Mi = Wo[Bi];
    rt.prototype[Mi] || (rt.prototype[Mi] = la.prototype[Mi])
}

function rt(e) {
    if (!(this instanceof rt)) return new rt(e);
    Nu.call(this, e), la.call(this, e), this.allowHalfOpen = !0, e && (e.readable === !1 && (this.readable = !1), e.writable === !1 && (this.writable = !1), e.allowHalfOpen === !1 && (this.allowHalfOpen = !1, this.once("end", m0)))
}
Object.defineProperty(rt.prototype, "writableHighWaterMark", {
    enumerable: !1,
    get: function() {
        return this._writableState.highWaterMark
    }
});
Object.defineProperty(rt.prototype, "writableBuffer", {
    enumerable: !1,
    get: function() {
        return this._writableState && this._writableState.getBuffer()
    }
});
Object.defineProperty(rt.prototype, "writableLength", {
    enumerable: !1,
    get: function() {
        return this._writableState.length
    }
});

function m0() {
    this._writableState.ended || process.nextTick(E0, this)
}

function E0(e) {
    e.end()
}
Object.defineProperty(rt.prototype, "destroyed", {
    enumerable: !1,
    get: function() {
        return this._readableState === void 0 || this._writableState === void 0 ? !1 : this._readableState.destroyed && this._writableState.destroyed
    },
    set: function(t) {
        this._readableState === void 0 || this._writableState === void 0 || (this._readableState.destroyed = t, this._writableState.destroyed = t)
    }
});
var Yn = {},
    ka = De.exports.Buffer,
    Zo = ka.isEncoding || function(e) {
        switch (e = "" + e, e && e.toLowerCase()) {
            case "hex":
            case "utf8":
            case "utf-8":
            case "ascii":
            case "binary":
            case "base64":
            case "ucs2":
            case "ucs-2":
            case "utf16le":
            case "utf-16le":
            case "raw":
                return !0;
            default:
                return !1
        }
    };

function S0(e) {
    if (!e) return "utf8";
    for (var t;;) switch (e) {
        case "utf8":
        case "utf-8":
            return "utf8";
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
            return "utf16le";
        case "latin1":
        case "binary":
            return "latin1";
        case "base64":
        case "ascii":
        case "hex":
            return e;
        default:
            if (t) return;
            e = ("" + e).toLowerCase(), t = !0
    }
}

function A0(e) {
    var t = S0(e);
    if (typeof t != "string" && (ka.isEncoding === Zo || !Zo(e))) throw new Error("Unknown encoding: " + e);
    return t || e
}
Yn.StringDecoder = un;

function un(e) {
    this.encoding = A0(e);
    var t;
    switch (this.encoding) {
        case "utf16le":
            this.text = D0, this.end = P0, t = 4;
            break;
        case "utf8":
            this.fillLast = z0, t = 4;
            break;
        case "base64":
            this.text = C0, this.end = N0, t = 3;
            break;
        default:
            this.write = L0, this.end = I0;
            return
    }
    this.lastNeed = 0, this.lastTotal = 0, this.lastChar = ka.allocUnsafe(t)
}
un.prototype.write = function(e) {
    if (e.length === 0) return "";
    var t, r;
    if (this.lastNeed) {
        if (t = this.fillLast(e), t === void 0) return "";
        r = this.lastNeed, this.lastNeed = 0
    } else r = 0;
    return r < e.length ? t ? t + this.text(e, r) : this.text(e, r) : t || ""
};
un.prototype.end = O0;
un.prototype.text = R0;
un.prototype.fillLast = function(e) {
    if (this.lastNeed <= e.length) return e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
    e.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, e.length), this.lastNeed -= e.length
};

function Ui(e) {
    return e <= 127 ? 0 : e >> 5 === 6 ? 2 : e >> 4 === 14 ? 3 : e >> 3 === 30 ? 4 : e >> 6 === 2 ? -1 : -2
}

function k0(e, t, r) {
    var n = t.length - 1;
    if (n < r) return 0;
    var i = Ui(t[n]);
    return i >= 0 ? (i > 0 && (e.lastNeed = i - 1), i) : --n < r || i === -2 ? 0 : (i = Ui(t[n]), i >= 0 ? (i > 0 && (e.lastNeed = i - 2), i) : --n < r || i === -2 ? 0 : (i = Ui(t[n]), i >= 0 ? (i > 0 && (i === 2 ? i = 0 : e.lastNeed = i - 3), i) : 0))
}

function T0(e, t, r) {
    if ((t[0] & 192) !== 128) return e.lastNeed = 0, "\uFFFD";
    if (e.lastNeed > 1 && t.length > 1) {
        if ((t[1] & 192) !== 128) return e.lastNeed = 1, "\uFFFD";
        if (e.lastNeed > 2 && t.length > 2 && (t[2] & 192) !== 128) return e.lastNeed = 2, "\uFFFD"
    }
}

function z0(e) {
    var t = this.lastTotal - this.lastNeed,
        r = T0(this, e);
    if (r !== void 0) return r;
    if (this.lastNeed <= e.length) return e.copy(this.lastChar, t, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
    e.copy(this.lastChar, t, 0, e.length), this.lastNeed -= e.length
}

function R0(e, t) {
    var r = k0(this, e, t);
    if (!this.lastNeed) return e.toString("utf8", t);
    this.lastTotal = r;
    var n = e.length - (r - this.lastNeed);
    return e.copy(this.lastChar, 0, n), e.toString("utf8", t, n)
}

function O0(e) {
    var t = e && e.length ? this.write(e) : "";
    return this.lastNeed ? t + "\uFFFD" : t
}

function D0(e, t) {
    if ((e.length - t) % 2 === 0) {
        var r = e.toString("utf16le", t);
        if (r) {
            var n = r.charCodeAt(r.length - 1);
            if (n >= 55296 && n <= 56319) return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = e[e.length - 2], this.lastChar[1] = e[e.length - 1], r.slice(0, -1)
        }
        return r
    }
    return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = e[e.length - 1], e.toString("utf16le", t, e.length - 1)
}

function P0(e) {
    var t = e && e.length ? this.write(e) : "";
    if (this.lastNeed) {
        var r = this.lastTotal - this.lastNeed;
        return t + this.lastChar.toString("utf16le", 0, r)
    }
    return t
}

function C0(e, t) {
    var r = (e.length - t) % 3;
    return r === 0 ? e.toString("base64", t) : (this.lastNeed = 3 - r, this.lastTotal = 3, r === 1 ? this.lastChar[0] = e[e.length - 1] : (this.lastChar[0] = e[e.length - 2], this.lastChar[1] = e[e.length - 1]), e.toString("base64", t, e.length - r))
}

function N0(e) {
    var t = e && e.length ? this.write(e) : "";
    return this.lastNeed ? t + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : t
}

function L0(e) {
    return e.toString(this.encoding)
}

function I0(e) {
    return e && e.length ? this.write(e) : ""
}
var qo = Zt.codes.ERR_STREAM_PREMATURE_CLOSE;

function B0(e) {
    var t = !1;
    return function() {
        if (!t) {
            t = !0;
            for (var r = arguments.length, n = new Array(r), i = 0; i < r; i++) n[i] = arguments[i];
            e.apply(this, n)
        }
    }
}

function M0() {}

function U0(e) {
    return e.setHeader && typeof e.abort == "function"
}

function Lu(e, t, r) {
    if (typeof t == "function") return Lu(e, null, t);
    t || (t = {}), r = B0(r || M0);
    var n = t.readable || t.readable !== !1 && e.readable,
        i = t.writable || t.writable !== !1 && e.writable,
        a = function() {
            e.writable || s()
        },
        o = e._writableState && e._writableState.finished,
        s = function() {
            i = !1, o = !0, n || r.call(e)
        },
        c = e._readableState && e._readableState.endEmitted,
        u = function() {
            n = !1, c = !0, i || r.call(e)
        },
        f = function(g) {
            r.call(e, g)
        },
        b = function() {
            var g;
            if (n && !c) return (!e._readableState || !e._readableState.ended) && (g = new qo), r.call(e, g);
            if (i && !o) return (!e._writableState || !e._writableState.ended) && (g = new qo), r.call(e, g)
        },
        _ = function() {
            e.req.on("finish", s)
        };
    return U0(e) ? (e.on("complete", s), e.on("abort", b), e.req ? _() : e.on("request", _)) : i && !e._writableState && (e.on("end", a), e.on("close", a)), e.on("end", u), e.on("finish", s), t.error !== !1 && e.on("error", f), e.on("close", b),
        function() {
            e.removeListener("complete", s), e.removeListener("abort", b), e.removeListener("request", _), e.req && e.req.removeListener("finish", s), e.removeListener("end", a), e.removeListener("close", a), e.removeListener("finish", s), e.removeListener("end", u), e.removeListener("error", f), e.removeListener("close", b)
        }
}
var Jn = Lu,
    An;

function bt(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e
}
var $0 = Jn,
    gt = Symbol("lastResolve"),
    Pt = Symbol("lastReject"),
    Hr = Symbol("error"),
    Bn = Symbol("ended"),
    Lt = Symbol("lastPromise"),
    Ta = Symbol("handlePromise"),
    It = Symbol("stream");

function Et(e, t) {
    return {
        value: e,
        done: t
    }
}

function F0(e) {
    var t = e[gt];
    if (t !== null) {
        var r = e[It].read();
        r !== null && (e[Lt] = null, e[gt] = null, e[Pt] = null, t(Et(r, !1)))
    }
}

function H0(e) {
    process.nextTick(F0, e)
}

function K0(e, t) {
    return function(r, n) {
        e.then(function() {
            if (t[Bn]) {
                r(Et(void 0, !0));
                return
            }
            t[Ta](r, n)
        }, n)
    }
}
var W0 = Object.getPrototypeOf(function() {}),
    Z0 = Object.setPrototypeOf((An = {
        get stream() {
            return this[It]
        },
        next: function() {
            var t = this,
                r = this[Hr];
            if (r !== null) return Promise.reject(r);
            if (this[Bn]) return Promise.resolve(Et(void 0, !0));
            if (this[It].destroyed) return new Promise(function(o, s) {
                process.nextTick(function() {
                    t[Hr] ? s(t[Hr]) : o(Et(void 0, !0))
                })
            });
            var n = this[Lt],
                i;
            if (n) i = new Promise(K0(n, this));
            else {
                var a = this[It].read();
                if (a !== null) return Promise.resolve(Et(a, !1));
                i = new Promise(this[Ta])
            }
            return this[Lt] = i, i
        }
    }, bt(An, Symbol.asyncIterator, function() {
        return this
    }), bt(An, "return", function() {
        var t = this;
        return new Promise(function(r, n) {
            t[It].destroy(null, function(i) {
                if (i) {
                    n(i);
                    return
                }
                r(Et(void 0, !0))
            })
        })
    }), An), W0),
    q0 = function(t) {
        var r, n = Object.create(Z0, (r = {}, bt(r, It, {
            value: t,
            writable: !0
        }), bt(r, gt, {
            value: null,
            writable: !0
        }), bt(r, Pt, {
            value: null,
            writable: !0
        }), bt(r, Hr, {
            value: null,
            writable: !0
        }), bt(r, Bn, {
            value: t._readableState.endEmitted,
            writable: !0
        }), bt(r, Ta, {
            value: function(a, o) {
                var s = n[It].read();
                s ? (n[Lt] = null, n[gt] = null, n[Pt] = null, a(Et(s, !1))) : (n[gt] = a, n[Pt] = o)
            },
            writable: !0
        }), r));
        return n[Lt] = null, $0(t, function(i) {
            if (i && i.code !== "ERR_STREAM_PREMATURE_CLOSE") {
                var a = n[Pt];
                a !== null && (n[Lt] = null, n[gt] = null, n[Pt] = null, a(i)), n[Hr] = i;
                return
            }
            var o = n[gt];
            o !== null && (n[Lt] = null, n[gt] = null, n[Pt] = null, o(Et(void 0, !0))), n[Bn] = !0
        }), t.on("readable", H0.bind(null, n)), n
    },
    j0 = q0,
    G0 = function() {
        throw new Error("Readable.from is not available in the browser")
    },
    za = ue,
    rr;
ue.ReadableState = Bu;
ha.exports.EventEmitter;
var Iu = function(t, r) {
        return t.listeners(r).length
    },
    ln = ku,
    Xn = Xr.Buffer,
    V0 = Y.Uint8Array || function() {};

function Y0(e) {
    return Xn.from(e)
}

function J0(e) {
    return Xn.isBuffer(e) || e instanceof V0
}
var $i = Ea,
    Q;
$i && $i.debuglog ? Q = $i.debuglog("stream") : Q = function() {};
var X0 = Ld,
    Ra = Tu,
    Q0 = Ru,
    ep = Q0.getHighWaterMark,
    Qn = Zt.codes,
    tp = Qn.ERR_INVALID_ARG_TYPE,
    rp = Qn.ERR_STREAM_PUSH_AFTER_EOF,
    np = Qn.ERR_METHOD_NOT_IMPLEMENTED,
    ip = Qn.ERR_STREAM_UNSHIFT_AFTER_END_EVENT,
    nr, Fi, Hi;
ye.exports(ue, ln);
var Kr = Ra.errorOrDestroy,
    Ki = ["error", "close", "destroy", "pause", "resume"];

function ap(e, t, r) {
    if (typeof e.prependListener == "function") return e.prependListener(t, r);
    !e._events || !e._events[t] ? e.on(t, r) : Array.isArray(e._events[t]) ? e._events[t].unshift(r) : e._events[t] = [r, e._events[t]]
}

function Bu(e, t, r) {
    rr = rr || qt, e = e || {}, typeof r != "boolean" && (r = t instanceof rr), this.objectMode = !!e.objectMode, r && (this.objectMode = this.objectMode || !!e.readableObjectMode), this.highWaterMark = ep(this, e, "readableHighWaterMark", r), this.buffer = new X0, this.length = 0, this.pipes = null, this.pipesCount = 0, this.flowing = null, this.ended = !1, this.endEmitted = !1, this.reading = !1, this.sync = !0, this.needReadable = !1, this.emittedReadable = !1, this.readableListening = !1, this.resumeScheduled = !1, this.paused = !0, this.emitClose = e.emitClose !== !1, this.autoDestroy = !!e.autoDestroy, this.destroyed = !1, this.defaultEncoding = e.defaultEncoding || "utf8", this.awaitDrain = 0, this.readingMore = !1, this.decoder = null, this.encoding = null, e.encoding && (nr || (nr = Yn.StringDecoder), this.decoder = new nr(e.encoding), this.encoding = e.encoding)
}

function ue(e) {
    if (rr = rr || qt, !(this instanceof ue)) return new ue(e);
    var t = this instanceof rr;
    this._readableState = new Bu(e, this, t), this.readable = !0, e && (typeof e.read == "function" && (this._read = e.read), typeof e.destroy == "function" && (this._destroy = e.destroy)), ln.call(this)
}
Object.defineProperty(ue.prototype, "destroyed", {
    enumerable: !1,
    get: function() {
        return this._readableState === void 0 ? !1 : this._readableState.destroyed
    },
    set: function(t) {
        !this._readableState || (this._readableState.destroyed = t)
    }
});
ue.prototype.destroy = Ra.destroy;
ue.prototype._undestroy = Ra.undestroy;
ue.prototype._destroy = function(e, t) {
    t(e)
};
ue.prototype.push = function(e, t) {
    var r = this._readableState,
        n;
    return r.objectMode ? n = !0 : typeof e == "string" && (t = t || r.defaultEncoding, t !== r.encoding && (e = Xn.from(e, t), t = ""), n = !0), Mu(this, e, t, !1, n)
};
ue.prototype.unshift = function(e) {
    return Mu(this, e, null, !0, !1)
};

function Mu(e, t, r, n, i) {
    Q("readableAddChunk", t);
    var a = e._readableState;
    if (t === null) a.reading = !1, up(e, a);
    else {
        var o;
        if (i || (o = op(a, t)), o) Kr(e, o);
        else if (a.objectMode || t && t.length > 0)
            if (typeof t != "string" && !a.objectMode && Object.getPrototypeOf(t) !== Xn.prototype && (t = Y0(t)), n) a.endEmitted ? Kr(e, new ip) : Wi(e, a, t, !0);
            else if (a.ended) Kr(e, new rp);
        else {
            if (a.destroyed) return !1;
            a.reading = !1, a.decoder && !r ? (t = a.decoder.write(t), a.objectMode || t.length !== 0 ? Wi(e, a, t, !1) : fa(e, a)) : Wi(e, a, t, !1)
        } else n || (a.reading = !1, fa(e, a))
    }
    return !a.ended && (a.length < a.highWaterMark || a.length === 0)
}

function Wi(e, t, r, n) {
    t.flowing && t.length === 0 && !t.sync ? (t.awaitDrain = 0, e.emit("data", r)) : (t.length += t.objectMode ? 1 : r.length, n ? t.buffer.unshift(r) : t.buffer.push(r), t.needReadable && ei(e)), fa(e, t)
}

function op(e, t) {
    var r;
    return !J0(t) && typeof t != "string" && t !== void 0 && !e.objectMode && (r = new tp("chunk", ["string", "Buffer", "Uint8Array"], t)), r
}
ue.prototype.isPaused = function() {
    return this._readableState.flowing === !1
};
ue.prototype.setEncoding = function(e) {
    nr || (nr = Yn.StringDecoder);
    var t = new nr(e);
    this._readableState.decoder = t, this._readableState.encoding = this._readableState.decoder.encoding;
    for (var r = this._readableState.buffer.head, n = ""; r !== null;) n += t.write(r.data), r = r.next;
    return this._readableState.buffer.clear(), n !== "" && this._readableState.buffer.push(n), this._readableState.length = n.length, this
};
var jo = 1073741824;

function sp(e) {
    return e >= jo ? e = jo : (e--, e |= e >>> 1, e |= e >>> 2, e |= e >>> 4, e |= e >>> 8, e |= e >>> 16, e++), e
}

function Go(e, t) {
    return e <= 0 || t.length === 0 && t.ended ? 0 : t.objectMode ? 1 : e !== e ? t.flowing && t.length ? t.buffer.head.data.length : t.length : (e > t.highWaterMark && (t.highWaterMark = sp(e)), e <= t.length ? e : t.ended ? t.length : (t.needReadable = !0, 0))
}
ue.prototype.read = function(e) {
    Q("read", e), e = parseInt(e, 10);
    var t = this._readableState,
        r = e;
    if (e !== 0 && (t.emittedReadable = !1), e === 0 && t.needReadable && ((t.highWaterMark !== 0 ? t.length >= t.highWaterMark : t.length > 0) || t.ended)) return Q("read: emitReadable", t.length, t.ended), t.length === 0 && t.ended ? Zi(this) : ei(this), null;
    if (e = Go(e, t), e === 0 && t.ended) return t.length === 0 && Zi(this), null;
    var n = t.needReadable;
    Q("need readable", n), (t.length === 0 || t.length - e < t.highWaterMark) && (n = !0, Q("length less than watermark", n)), t.ended || t.reading ? (n = !1, Q("reading or ended", n)) : n && (Q("do read"), t.reading = !0, t.sync = !0, t.length === 0 && (t.needReadable = !0), this._read(t.highWaterMark), t.sync = !1, t.reading || (e = Go(r, t)));
    var i;
    return e > 0 ? i = Fu(e, t) : i = null, i === null ? (t.needReadable = t.length <= t.highWaterMark, e = 0) : (t.length -= e, t.awaitDrain = 0), t.length === 0 && (t.ended || (t.needReadable = !0), r !== e && t.ended && Zi(this)), i !== null && this.emit("data", i), i
};

function up(e, t) {
    if (Q("onEofChunk"), !t.ended) {
        if (t.decoder) {
            var r = t.decoder.end();
            r && r.length && (t.buffer.push(r), t.length += t.objectMode ? 1 : r.length)
        }
        t.ended = !0, t.sync ? ei(e) : (t.needReadable = !1, t.emittedReadable || (t.emittedReadable = !0, Uu(e)))
    }
}

function ei(e) {
    var t = e._readableState;
    Q("emitReadable", t.needReadable, t.emittedReadable), t.needReadable = !1, t.emittedReadable || (Q("emitReadable", t.flowing), t.emittedReadable = !0, process.nextTick(Uu, e))
}

function Uu(e) {
    var t = e._readableState;
    Q("emitReadable_", t.destroyed, t.length, t.ended), !t.destroyed && (t.length || t.ended) && (e.emit("readable"), t.emittedReadable = !1), t.needReadable = !t.flowing && !t.ended && t.length <= t.highWaterMark, Oa(e)
}

function fa(e, t) {
    t.readingMore || (t.readingMore = !0, process.nextTick(lp, e, t))
}

function lp(e, t) {
    for (; !t.reading && !t.ended && (t.length < t.highWaterMark || t.flowing && t.length === 0);) {
        var r = t.length;
        if (Q("maybeReadMore read 0"), e.read(0), r === t.length) break
    }
    t.readingMore = !1
}
ue.prototype._read = function(e) {
    Kr(this, new np("_read()"))
};
ue.prototype.pipe = function(e, t) {
    var r = this,
        n = this._readableState;
    switch (n.pipesCount) {
        case 0:
            n.pipes = e;
            break;
        case 1:
            n.pipes = [n.pipes, e];
            break;
        default:
            n.pipes.push(e);
            break
    }
    n.pipesCount += 1, Q("pipe count=%d opts=%j", n.pipesCount, t);
    var i = (!t || t.end !== !1) && e !== process.stdout && e !== process.stderr,
        a = i ? s : k;
    n.endEmitted ? process.nextTick(a) : r.once("end", a), e.on("unpipe", o);

    function o(O, z) {
        Q("onunpipe"), O === r && z && z.hasUnpiped === !1 && (z.hasUnpiped = !0, f())
    }

    function s() {
        Q("onend"), e.end()
    }
    var c = fp(r);
    e.on("drain", c);
    var u = !1;

    function f() {
        Q("cleanup"), e.removeListener("close", v), e.removeListener("finish", g), e.removeListener("drain", c), e.removeListener("error", _), e.removeListener("unpipe", o), r.removeListener("end", s), r.removeListener("end", k), r.removeListener("data", b), u = !0, n.awaitDrain && (!e._writableState || e._writableState.needDrain) && c()
    }
    r.on("data", b);

    function b(O) {
        Q("ondata");
        var z = e.write(O);
        Q("dest.write", z), z === !1 && ((n.pipesCount === 1 && n.pipes === e || n.pipesCount > 1 && Hu(n.pipes, e) !== -1) && !u && (Q("false write response, pause", n.awaitDrain), n.awaitDrain++), r.pause())
    }

    function _(O) {
        Q("onerror", O), k(), e.removeListener("error", _), Iu(e, "error") === 0 && Kr(e, O)
    }
    ap(e, "error", _);

    function v() {
        e.removeListener("finish", g), k()
    }
    e.once("close", v);

    function g() {
        Q("onfinish"), e.removeListener("close", v), k()
    }
    e.once("finish", g);

    function k() {
        Q("unpipe"), r.unpipe(e)
    }
    return e.emit("pipe", r), n.flowing || (Q("pipe resume"), r.resume()), e
};

function fp(e) {
    return function() {
        var r = e._readableState;
        Q("pipeOnDrain", r.awaitDrain), r.awaitDrain && r.awaitDrain--, r.awaitDrain === 0 && Iu(e, "data") && (r.flowing = !0, Oa(e))
    }
}
ue.prototype.unpipe = function(e) {
    var t = this._readableState,
        r = {
            hasUnpiped: !1
        };
    if (t.pipesCount === 0) return this;
    if (t.pipesCount === 1) return e && e !== t.pipes ? this : (e || (e = t.pipes), t.pipes = null, t.pipesCount = 0, t.flowing = !1, e && e.emit("unpipe", this, r), this);
    if (!e) {
        var n = t.pipes,
            i = t.pipesCount;
        t.pipes = null, t.pipesCount = 0, t.flowing = !1;
        for (var a = 0; a < i; a++) n[a].emit("unpipe", this, {
            hasUnpiped: !1
        });
        return this
    }
    var o = Hu(t.pipes, e);
    return o === -1 ? this : (t.pipes.splice(o, 1), t.pipesCount -= 1, t.pipesCount === 1 && (t.pipes = t.pipes[0]), e.emit("unpipe", this, r), this)
};
ue.prototype.on = function(e, t) {
    var r = ln.prototype.on.call(this, e, t),
        n = this._readableState;
    return e === "data" ? (n.readableListening = this.listenerCount("readable") > 0, n.flowing !== !1 && this.resume()) : e === "readable" && !n.endEmitted && !n.readableListening && (n.readableListening = n.needReadable = !0, n.flowing = !1, n.emittedReadable = !1, Q("on readable", n.length, n.reading), n.length ? ei(this) : n.reading || process.nextTick(cp, this)), r
};
ue.prototype.addListener = ue.prototype.on;
ue.prototype.removeListener = function(e, t) {
    var r = ln.prototype.removeListener.call(this, e, t);
    return e === "readable" && process.nextTick($u, this), r
};
ue.prototype.removeAllListeners = function(e) {
    var t = ln.prototype.removeAllListeners.apply(this, arguments);
    return (e === "readable" || e === void 0) && process.nextTick($u, this), t
};

function $u(e) {
    var t = e._readableState;
    t.readableListening = e.listenerCount("readable") > 0, t.resumeScheduled && !t.paused ? t.flowing = !0 : e.listenerCount("data") > 0 && e.resume()
}

function cp(e) {
    Q("readable nexttick read 0"), e.read(0)
}
ue.prototype.resume = function() {
    var e = this._readableState;
    return e.flowing || (Q("resume"), e.flowing = !e.readableListening, hp(this, e)), e.paused = !1, this
};

function hp(e, t) {
    t.resumeScheduled || (t.resumeScheduled = !0, process.nextTick(dp, e, t))
}

function dp(e, t) {
    Q("resume", t.reading), t.reading || e.read(0), t.resumeScheduled = !1, e.emit("resume"), Oa(e), t.flowing && !t.reading && e.read(0)
}
ue.prototype.pause = function() {
    return Q("call pause flowing=%j", this._readableState.flowing), this._readableState.flowing !== !1 && (Q("pause"), this._readableState.flowing = !1, this.emit("pause")), this._readableState.paused = !0, this
};

function Oa(e) {
    var t = e._readableState;
    for (Q("flow", t.flowing); t.flowing && e.read() !== null;);
}
ue.prototype.wrap = function(e) {
    var t = this,
        r = this._readableState,
        n = !1;
    e.on("end", function() {
        if (Q("wrapped end"), r.decoder && !r.ended) {
            var o = r.decoder.end();
            o && o.length && t.push(o)
        }
        t.push(null)
    }), e.on("data", function(o) {
        if (Q("wrapped data"), r.decoder && (o = r.decoder.write(o)), !(r.objectMode && o == null) && !(!r.objectMode && (!o || !o.length))) {
            var s = t.push(o);
            s || (n = !0, e.pause())
        }
    });
    for (var i in e) this[i] === void 0 && typeof e[i] == "function" && (this[i] = function(s) {
        return function() {
            return e[s].apply(e, arguments)
        }
    }(i));
    for (var a = 0; a < Ki.length; a++) e.on(Ki[a], this.emit.bind(this, Ki[a]));
    return this._read = function(o) {
        Q("wrapped _read", o), n && (n = !1, e.resume())
    }, this
};
typeof Symbol == "function" && (ue.prototype[Symbol.asyncIterator] = function() {
    return Fi === void 0 && (Fi = j0), Fi(this)
});
Object.defineProperty(ue.prototype, "readableHighWaterMark", {
    enumerable: !1,
    get: function() {
        return this._readableState.highWaterMark
    }
});
Object.defineProperty(ue.prototype, "readableBuffer", {
    enumerable: !1,
    get: function() {
        return this._readableState && this._readableState.buffer
    }
});
Object.defineProperty(ue.prototype, "readableFlowing", {
    enumerable: !1,
    get: function() {
        return this._readableState.flowing
    },
    set: function(t) {
        this._readableState && (this._readableState.flowing = t)
    }
});
ue._fromList = Fu;
Object.defineProperty(ue.prototype, "readableLength", {
    enumerable: !1,
    get: function() {
        return this._readableState.length
    }
});

function Fu(e, t) {
    if (t.length === 0) return null;
    var r;
    return t.objectMode ? r = t.buffer.shift() : !e || e >= t.length ? (t.decoder ? r = t.buffer.join("") : t.buffer.length === 1 ? r = t.buffer.first() : r = t.buffer.concat(t.length), t.buffer.clear()) : r = t.buffer.consume(e, t.decoder), r
}

function Zi(e) {
    var t = e._readableState;
    Q("endReadable", t.endEmitted), t.endEmitted || (t.ended = !0, process.nextTick(pp, t, e))
}

function pp(e, t) {
    if (Q("endReadableNT", e.endEmitted, e.length), !e.endEmitted && e.length === 0 && (e.endEmitted = !0, t.readable = !1, t.emit("end"), e.autoDestroy)) {
        var r = t._writableState;
        (!r || r.autoDestroy && r.finished) && t.destroy()
    }
}
typeof Symbol == "function" && (ue.from = function(e, t) {
    return Hi === void 0 && (Hi = G0), Hi(ue, e, t)
});

function Hu(e, t) {
    for (var r = 0, n = e.length; r < n; r++)
        if (e[r] === t) return r;
    return -1
}
var Da = ct,
    ti = Zt.codes,
    _p = ti.ERR_METHOD_NOT_IMPLEMENTED,
    vp = ti.ERR_MULTIPLE_CALLBACK,
    yp = ti.ERR_TRANSFORM_ALREADY_TRANSFORMING,
    bp = ti.ERR_TRANSFORM_WITH_LENGTH_0,
    ri = qt;
ye.exports(ct, ri);

function gp(e, t) {
    var r = this._transformState;
    r.transforming = !1;
    var n = r.writecb;
    if (n === null) return this.emit("error", new vp);
    r.writechunk = null, r.writecb = null, t != null && this.push(t), n(e);
    var i = this._readableState;
    i.reading = !1, (i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
}

function ct(e) {
    if (!(this instanceof ct)) return new ct(e);
    ri.call(this, e), this._transformState = {
        afterTransform: gp.bind(this),
        needTransform: !1,
        transforming: !1,
        writecb: null,
        writechunk: null,
        writeencoding: null
    }, this._readableState.needReadable = !0, this._readableState.sync = !1, e && (typeof e.transform == "function" && (this._transform = e.transform), typeof e.flush == "function" && (this._flush = e.flush)), this.on("prefinish", wp)
}

function wp() {
    var e = this;
    typeof this._flush == "function" && !this._readableState.destroyed ? this._flush(function(t, r) {
        Vo(e, t, r)
    }) : Vo(this, null, null)
}
ct.prototype.push = function(e, t) {
    return this._transformState.needTransform = !1, ri.prototype.push.call(this, e, t)
};
ct.prototype._transform = function(e, t, r) {
    r(new _p("_transform()"))
};
ct.prototype._write = function(e, t, r) {
    var n = this._transformState;
    if (n.writecb = r, n.writechunk = e, n.writeencoding = t, !n.transforming) {
        var i = this._readableState;
        (n.needTransform || i.needReadable || i.length < i.highWaterMark) && this._read(i.highWaterMark)
    }
};
ct.prototype._read = function(e) {
    var t = this._transformState;
    t.writechunk !== null && !t.transforming ? (t.transforming = !0, this._transform(t.writechunk, t.writeencoding, t.afterTransform)) : t.needTransform = !0
};
ct.prototype._destroy = function(e, t) {
    ri.prototype._destroy.call(this, e, function(r) {
        t(r)
    })
};

function Vo(e, t, r) {
    if (t) return e.emit("error", t);
    if (r != null && e.push(r), e._writableState.length) throw new bp;
    if (e._transformState.transforming) throw new yp;
    return e.push(null)
}
var Ku = Jr,
    Wu = Da;
ye.exports(Jr, Wu);

function Jr(e) {
    if (!(this instanceof Jr)) return new Jr(e);
    Wu.call(this, e)
}
Jr.prototype._transform = function(e, t, r) {
    r(null, e)
};
var qi;

function xp(e) {
    var t = !1;
    return function() {
        t || (t = !0, e.apply(void 0, arguments))
    }
}
var Zu = Zt.codes,
    mp = Zu.ERR_MISSING_ARGS,
    Ep = Zu.ERR_STREAM_DESTROYED;

function Yo(e) {
    if (e) throw e
}

function Sp(e) {
    return e.setHeader && typeof e.abort == "function"
}

function Ap(e, t, r, n) {
    n = xp(n);
    var i = !1;
    e.on("close", function() {
        i = !0
    }), qi === void 0 && (qi = Jn), qi(e, {
        readable: t,
        writable: r
    }, function(o) {
        if (o) return n(o);
        i = !0, n()
    });
    var a = !1;
    return function(o) {
        if (!i && !a) {
            if (a = !0, Sp(e)) return e.abort();
            if (typeof e.destroy == "function") return e.destroy();
            n(o || new Ep("pipe"))
        }
    }
}

function Jo(e) {
    e()
}

function kp(e, t) {
    return e.pipe(t)
}

function Tp(e) {
    return !e.length || typeof e[e.length - 1] != "function" ? Yo : e.pop()
}

function zp() {
    for (var e = arguments.length, t = new Array(e), r = 0; r < e; r++) t[r] = arguments[r];
    var n = Tp(t);
    if (Array.isArray(t[0]) && (t = t[0]), t.length < 2) throw new mp("streams");
    var i, a = t.map(function(o, s) {
        var c = s < t.length - 1,
            u = s > 0;
        return Ap(o, c, u, function(f) {
            i || (i = f), f && a.forEach(Jo), !c && (a.forEach(Jo), n(i))
        })
    });
    return t.reduce(kp)
}
var qu = zp;
(function(e, t) {
    t = e.exports = za, t.Stream = t, t.Readable = t, t.Writable = Sa, t.Duplex = qt, t.Transform = Da, t.PassThrough = Ku, t.finished = Jn, t.pipeline = qu
})(aa, aa.exports);
var Mn = De.exports.Buffer,
    ju = aa.exports.Transform,
    Rp = ye.exports;

function Op(e, t) {
    if (!Mn.isBuffer(e) && typeof e != "string") throw new TypeError(t + " must be a string or a buffer")
}

function Rt(e) {
    ju.call(this), this._block = Mn.allocUnsafe(e), this._blockSize = e, this._blockOffset = 0, this._length = [0, 0, 0, 0], this._finalized = !1
}
Rp(Rt, ju);
Rt.prototype._transform = function(e, t, r) {
    var n = null;
    try {
        this.update(e, t)
    } catch (i) {
        n = i
    }
    r(n)
};
Rt.prototype._flush = function(e) {
    var t = null;
    try {
        this.push(this.digest())
    } catch (r) {
        t = r
    }
    e(t)
};
Rt.prototype.update = function(e, t) {
    if (Op(e, "Data"), this._finalized) throw new Error("Digest already called");
    Mn.isBuffer(e) || (e = Mn.from(e, t));
    for (var r = this._block, n = 0; this._blockOffset + e.length - n >= this._blockSize;) {
        for (var i = this._blockOffset; i < this._blockSize;) r[i++] = e[n++];
        this._update(), this._blockOffset = 0
    }
    for (; n < e.length;) r[this._blockOffset++] = e[n++];
    for (var a = 0, o = e.length * 8; o > 0; ++a) this._length[a] += o, o = this._length[a] / 4294967296 | 0, o > 0 && (this._length[a] -= 4294967296 * o);
    return this
};
Rt.prototype._update = function() {
    throw new Error("_update is not implemented")
};
Rt.prototype.digest = function(e) {
    if (this._finalized) throw new Error("Digest already called");
    this._finalized = !0;
    var t = this._digest();
    e !== void 0 && (t = t.toString(e)), this._block.fill(0), this._blockOffset = 0;
    for (var r = 0; r < 4; ++r) this._length[r] = 0;
    return t
};
Rt.prototype._digest = function() {
    throw new Error("_digest is not implemented")
};
var Gu = Rt,
    Dp = ye.exports,
    Vu = Gu,
    Pp = De.exports.Buffer,
    Cp = new Array(16);

function ni() {
    Vu.call(this, 64), this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878
}
Dp(ni, Vu);
ni.prototype._update = function() {
    for (var e = Cp, t = 0; t < 16; ++t) e[t] = this._block.readInt32LE(t * 4);
    var r = this._a,
        n = this._b,
        i = this._c,
        a = this._d;
    r = Ee(r, n, i, a, e[0], 3614090360, 7), a = Ee(a, r, n, i, e[1], 3905402710, 12), i = Ee(i, a, r, n, e[2], 606105819, 17), n = Ee(n, i, a, r, e[3], 3250441966, 22), r = Ee(r, n, i, a, e[4], 4118548399, 7), a = Ee(a, r, n, i, e[5], 1200080426, 12), i = Ee(i, a, r, n, e[6], 2821735955, 17), n = Ee(n, i, a, r, e[7], 4249261313, 22), r = Ee(r, n, i, a, e[8], 1770035416, 7), a = Ee(a, r, n, i, e[9], 2336552879, 12), i = Ee(i, a, r, n, e[10], 4294925233, 17), n = Ee(n, i, a, r, e[11], 2304563134, 22), r = Ee(r, n, i, a, e[12], 1804603682, 7), a = Ee(a, r, n, i, e[13], 4254626195, 12), i = Ee(i, a, r, n, e[14], 2792965006, 17), n = Ee(n, i, a, r, e[15], 1236535329, 22), r = Se(r, n, i, a, e[1], 4129170786, 5), a = Se(a, r, n, i, e[6], 3225465664, 9), i = Se(i, a, r, n, e[11], 643717713, 14), n = Se(n, i, a, r, e[0], 3921069994, 20), r = Se(r, n, i, a, e[5], 3593408605, 5), a = Se(a, r, n, i, e[10], 38016083, 9), i = Se(i, a, r, n, e[15], 3634488961, 14), n = Se(n, i, a, r, e[4], 3889429448, 20), r = Se(r, n, i, a, e[9], 568446438, 5), a = Se(a, r, n, i, e[14], 3275163606, 9), i = Se(i, a, r, n, e[3], 4107603335, 14), n = Se(n, i, a, r, e[8], 1163531501, 20), r = Se(r, n, i, a, e[13], 2850285829, 5), a = Se(a, r, n, i, e[2], 4243563512, 9), i = Se(i, a, r, n, e[7], 1735328473, 14), n = Se(n, i, a, r, e[12], 2368359562, 20), r = Ae(r, n, i, a, e[5], 4294588738, 4), a = Ae(a, r, n, i, e[8], 2272392833, 11), i = Ae(i, a, r, n, e[11], 1839030562, 16), n = Ae(n, i, a, r, e[14], 4259657740, 23), r = Ae(r, n, i, a, e[1], 2763975236, 4), a = Ae(a, r, n, i, e[4], 1272893353, 11), i = Ae(i, a, r, n, e[7], 4139469664, 16), n = Ae(n, i, a, r, e[10], 3200236656, 23), r = Ae(r, n, i, a, e[13], 681279174, 4), a = Ae(a, r, n, i, e[0], 3936430074, 11), i = Ae(i, a, r, n, e[3], 3572445317, 16), n = Ae(n, i, a, r, e[6], 76029189, 23), r = Ae(r, n, i, a, e[9], 3654602809, 4), a = Ae(a, r, n, i, e[12], 3873151461, 11), i = Ae(i, a, r, n, e[15], 530742520, 16), n = Ae(n, i, a, r, e[2], 3299628645, 23), r = ke(r, n, i, a, e[0], 4096336452, 6), a = ke(a, r, n, i, e[7], 1126891415, 10), i = ke(i, a, r, n, e[14], 2878612391, 15), n = ke(n, i, a, r, e[5], 4237533241, 21), r = ke(r, n, i, a, e[12], 1700485571, 6), a = ke(a, r, n, i, e[3], 2399980690, 10), i = ke(i, a, r, n, e[10], 4293915773, 15), n = ke(n, i, a, r, e[1], 2240044497, 21), r = ke(r, n, i, a, e[8], 1873313359, 6), a = ke(a, r, n, i, e[15], 4264355552, 10), i = ke(i, a, r, n, e[6], 2734768916, 15), n = ke(n, i, a, r, e[13], 1309151649, 21), r = ke(r, n, i, a, e[4], 4149444226, 6), a = ke(a, r, n, i, e[11], 3174756917, 10), i = ke(i, a, r, n, e[2], 718787259, 15), n = ke(n, i, a, r, e[9], 3951481745, 21), this._a = this._a + r | 0, this._b = this._b + n | 0, this._c = this._c + i | 0, this._d = this._d + a | 0
};
ni.prototype._digest = function() {
    this._block[this._blockOffset++] = 128, this._blockOffset > 56 && (this._block.fill(0, this._blockOffset, 64), this._update(), this._blockOffset = 0), this._block.fill(0, this._blockOffset, 56), this._block.writeUInt32LE(this._length[0], 56), this._block.writeUInt32LE(this._length[1], 60), this._update();
    var e = Pp.allocUnsafe(16);
    return e.writeInt32LE(this._a, 0), e.writeInt32LE(this._b, 4), e.writeInt32LE(this._c, 8), e.writeInt32LE(this._d, 12), e
};

function ii(e, t) {
    return e << t | e >>> 32 - t
}

function Ee(e, t, r, n, i, a, o) {
    return ii(e + (t & r | ~t & n) + i + a | 0, o) + t | 0
}

function Se(e, t, r, n, i, a, o) {
    return ii(e + (t & n | r & ~n) + i + a | 0, o) + t | 0
}

function Ae(e, t, r, n, i, a, o) {
    return ii(e + (t ^ r ^ n) + i + a | 0, o) + t | 0
}

function ke(e, t, r, n, i, a, o) {
    return ii(e + (r ^ (t | ~n)) + i + a | 0, o) + t | 0
}
var Np = ni,
    ji = Xr.Buffer,
    Lp = ye.exports,
    Yu = Gu,
    Ip = new Array(16),
    Rr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13],
    Or = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11],
    Dr = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6],
    Pr = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11],
    Cr = [0, 1518500249, 1859775393, 2400959708, 2840853838],
    Nr = [1352829926, 1548603684, 1836072691, 2053994217, 0];

function ai() {
    Yu.call(this, 64), this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520
}
Lp(ai, Yu);
ai.prototype._update = function() {
    for (var e = Ip, t = 0; t < 16; ++t) e[t] = this._block.readInt32LE(t * 4);
    for (var r = this._a | 0, n = this._b | 0, i = this._c | 0, a = this._d | 0, o = this._e | 0, s = this._a | 0, c = this._b | 0, u = this._c | 0, f = this._d | 0, b = this._e | 0, _ = 0; _ < 80; _ += 1) {
        var v, g;
        _ < 16 ? (v = Xo(r, n, i, a, o, e[Rr[_]], Cr[0], Dr[_]), g = rs(s, c, u, f, b, e[Or[_]], Nr[0], Pr[_])) : _ < 32 ? (v = Qo(r, n, i, a, o, e[Rr[_]], Cr[1], Dr[_]), g = ts(s, c, u, f, b, e[Or[_]], Nr[1], Pr[_])) : _ < 48 ? (v = es(r, n, i, a, o, e[Rr[_]], Cr[2], Dr[_]), g = es(s, c, u, f, b, e[Or[_]], Nr[2], Pr[_])) : _ < 64 ? (v = ts(r, n, i, a, o, e[Rr[_]], Cr[3], Dr[_]), g = Qo(s, c, u, f, b, e[Or[_]], Nr[3], Pr[_])) : (v = rs(r, n, i, a, o, e[Rr[_]], Cr[4], Dr[_]), g = Xo(s, c, u, f, b, e[Or[_]], Nr[4], Pr[_])), r = o, o = a, a = Ft(i, 10), i = n, n = v, s = b, b = f, f = Ft(u, 10), u = c, c = g
    }
    var k = this._b + i + f | 0;
    this._b = this._c + a + b | 0, this._c = this._d + o + s | 0, this._d = this._e + r + c | 0, this._e = this._a + n + u | 0, this._a = k
};
ai.prototype._digest = function() {
    this._block[this._blockOffset++] = 128, this._blockOffset > 56 && (this._block.fill(0, this._blockOffset, 64), this._update(), this._blockOffset = 0), this._block.fill(0, this._blockOffset, 56), this._block.writeUInt32LE(this._length[0], 56), this._block.writeUInt32LE(this._length[1], 60), this._update();
    var e = ji.alloc ? ji.alloc(20) : new ji(20);
    return e.writeInt32LE(this._a, 0), e.writeInt32LE(this._b, 4), e.writeInt32LE(this._c, 8), e.writeInt32LE(this._d, 12), e.writeInt32LE(this._e, 16), e
};

function Ft(e, t) {
    return e << t | e >>> 32 - t
}

function Xo(e, t, r, n, i, a, o, s) {
    return Ft(e + (t ^ r ^ n) + a + o | 0, s) + i | 0
}

function Qo(e, t, r, n, i, a, o, s) {
    return Ft(e + (t & r | ~t & n) + a + o | 0, s) + i | 0
}

function es(e, t, r, n, i, a, o, s) {
    return Ft(e + ((t | ~r) ^ n) + a + o | 0, s) + i | 0
}

function ts(e, t, r, n, i, a, o, s) {
    return Ft(e + (t & n | r & ~n) + a + o | 0, s) + i | 0
}

function rs(e, t, r, n, i, a, o, s) {
    return Ft(e + (t ^ (r | ~n)) + a + o | 0, s) + i | 0
}
var Bp = ai,
    Ju = {
        exports: {}
    },
    Xu = De.exports.Buffer;

function oi(e, t) {
    this._block = Xu.alloc(e), this._finalSize = t, this._blockSize = e, this._len = 0
}
oi.prototype.update = function(e, t) {
    typeof e == "string" && (t = t || "utf8", e = Xu.from(e, t));
    for (var r = this._block, n = this._blockSize, i = e.length, a = this._len, o = 0; o < i;) {
        for (var s = a % n, c = Math.min(i - o, n - s), u = 0; u < c; u++) r[s + u] = e[o + u];
        a += c, o += c, a % n === 0 && this._update(r)
    }
    return this._len += i, this
};
oi.prototype.digest = function(e) {
    var t = this._len % this._blockSize;
    this._block[t] = 128, this._block.fill(0, t + 1), t >= this._finalSize && (this._update(this._block), this._block.fill(0));
    var r = this._len * 8;
    if (r <= 4294967295) this._block.writeUInt32BE(r, this._blockSize - 4);
    else {
        var n = (r & 4294967295) >>> 0,
            i = (r - n) / 4294967296;
        this._block.writeUInt32BE(i, this._blockSize - 8), this._block.writeUInt32BE(n, this._blockSize - 4)
    }
    this._update(this._block);
    var a = this._hash();
    return e ? a.toString(e) : a
};
oi.prototype._update = function() {
    throw new Error("_update must be implemented by subclass")
};
var gr = oi,
    Mp = ye.exports,
    Qu = gr,
    Up = De.exports.Buffer,
    $p = [1518500249, 1859775393, -1894007588, -899497514],
    Fp = new Array(80);

function fn() {
    this.init(), this._w = Fp, Qu.call(this, 64, 56)
}
Mp(fn, Qu);
fn.prototype.init = function() {
    return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this
};

function Hp(e) {
    return e << 5 | e >>> 27
}

function Kp(e) {
    return e << 30 | e >>> 2
}

function Wp(e, t, r, n) {
    return e === 0 ? t & r | ~t & n : e === 2 ? t & r | t & n | r & n : t ^ r ^ n
}
fn.prototype._update = function(e) {
    for (var t = this._w, r = this._a | 0, n = this._b | 0, i = this._c | 0, a = this._d | 0, o = this._e | 0, s = 0; s < 16; ++s) t[s] = e.readInt32BE(s * 4);
    for (; s < 80; ++s) t[s] = t[s - 3] ^ t[s - 8] ^ t[s - 14] ^ t[s - 16];
    for (var c = 0; c < 80; ++c) {
        var u = ~~(c / 20),
            f = Hp(r) + Wp(u, n, i, a) + o + t[c] + $p[u] | 0;
        o = a, a = i, i = Kp(n), n = r, r = f
    }
    this._a = r + this._a | 0, this._b = n + this._b | 0, this._c = i + this._c | 0, this._d = a + this._d | 0, this._e = o + this._e | 0
};
fn.prototype._hash = function() {
    var e = Up.allocUnsafe(20);
    return e.writeInt32BE(this._a | 0, 0), e.writeInt32BE(this._b | 0, 4), e.writeInt32BE(this._c | 0, 8), e.writeInt32BE(this._d | 0, 12), e.writeInt32BE(this._e | 0, 16), e
};
var Zp = fn,
    qp = ye.exports,
    el = gr,
    jp = De.exports.Buffer,
    Gp = [1518500249, 1859775393, -1894007588, -899497514],
    Vp = new Array(80);

function cn() {
    this.init(), this._w = Vp, el.call(this, 64, 56)
}
qp(cn, el);
cn.prototype.init = function() {
    return this._a = 1732584193, this._b = 4023233417, this._c = 2562383102, this._d = 271733878, this._e = 3285377520, this
};

function Yp(e) {
    return e << 1 | e >>> 31
}

function Jp(e) {
    return e << 5 | e >>> 27
}

function Xp(e) {
    return e << 30 | e >>> 2
}

function Qp(e, t, r, n) {
    return e === 0 ? t & r | ~t & n : e === 2 ? t & r | t & n | r & n : t ^ r ^ n
}
cn.prototype._update = function(e) {
    for (var t = this._w, r = this._a | 0, n = this._b | 0, i = this._c | 0, a = this._d | 0, o = this._e | 0, s = 0; s < 16; ++s) t[s] = e.readInt32BE(s * 4);
    for (; s < 80; ++s) t[s] = Yp(t[s - 3] ^ t[s - 8] ^ t[s - 14] ^ t[s - 16]);
    for (var c = 0; c < 80; ++c) {
        var u = ~~(c / 20),
            f = Jp(r) + Qp(u, n, i, a) + o + t[c] + Gp[u] | 0;
        o = a, a = i, i = Xp(n), n = r, r = f
    }
    this._a = r + this._a | 0, this._b = n + this._b | 0, this._c = i + this._c | 0, this._d = a + this._d | 0, this._e = o + this._e | 0
};
cn.prototype._hash = function() {
    var e = jp.allocUnsafe(20);
    return e.writeInt32BE(this._a | 0, 0), e.writeInt32BE(this._b | 0, 4), e.writeInt32BE(this._c | 0, 8), e.writeInt32BE(this._d | 0, 12), e.writeInt32BE(this._e | 0, 16), e
};
var e_ = cn,
    t_ = ye.exports,
    tl = gr,
    r_ = De.exports.Buffer,
    n_ = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298],
    i_ = new Array(64);

function hn() {
    this.init(), this._w = i_, tl.call(this, 64, 56)
}
t_(hn, tl);
hn.prototype.init = function() {
    return this._a = 1779033703, this._b = 3144134277, this._c = 1013904242, this._d = 2773480762, this._e = 1359893119, this._f = 2600822924, this._g = 528734635, this._h = 1541459225, this
};

function a_(e, t, r) {
    return r ^ e & (t ^ r)
}

function o_(e, t, r) {
    return e & t | r & (e | t)
}

function s_(e) {
    return (e >>> 2 | e << 30) ^ (e >>> 13 | e << 19) ^ (e >>> 22 | e << 10)
}

function u_(e) {
    return (e >>> 6 | e << 26) ^ (e >>> 11 | e << 21) ^ (e >>> 25 | e << 7)
}

function l_(e) {
    return (e >>> 7 | e << 25) ^ (e >>> 18 | e << 14) ^ e >>> 3
}

function f_(e) {
    return (e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10
}
hn.prototype._update = function(e) {
    for (var t = this._w, r = this._a | 0, n = this._b | 0, i = this._c | 0, a = this._d | 0, o = this._e | 0, s = this._f | 0, c = this._g | 0, u = this._h | 0, f = 0; f < 16; ++f) t[f] = e.readInt32BE(f * 4);
    for (; f < 64; ++f) t[f] = f_(t[f - 2]) + t[f - 7] + l_(t[f - 15]) + t[f - 16] | 0;
    for (var b = 0; b < 64; ++b) {
        var _ = u + u_(o) + a_(o, s, c) + n_[b] + t[b] | 0,
            v = s_(r) + o_(r, n, i) | 0;
        u = c, c = s, s = o, o = a + _ | 0, a = i, i = n, n = r, r = _ + v | 0
    }
    this._a = r + this._a | 0, this._b = n + this._b | 0, this._c = i + this._c | 0, this._d = a + this._d | 0, this._e = o + this._e | 0, this._f = s + this._f | 0, this._g = c + this._g | 0, this._h = u + this._h | 0
};
hn.prototype._hash = function() {
    var e = r_.allocUnsafe(32);
    return e.writeInt32BE(this._a, 0), e.writeInt32BE(this._b, 4), e.writeInt32BE(this._c, 8), e.writeInt32BE(this._d, 12), e.writeInt32BE(this._e, 16), e.writeInt32BE(this._f, 20), e.writeInt32BE(this._g, 24), e.writeInt32BE(this._h, 28), e
};
var rl = hn,
    c_ = ye.exports,
    h_ = rl,
    d_ = gr,
    p_ = De.exports.Buffer,
    __ = new Array(64);

function si() {
    this.init(), this._w = __, d_.call(this, 64, 56)
}
c_(si, h_);
si.prototype.init = function() {
    return this._a = 3238371032, this._b = 914150663, this._c = 812702999, this._d = 4144912697, this._e = 4290775857, this._f = 1750603025, this._g = 1694076839, this._h = 3204075428, this
};
si.prototype._hash = function() {
    var e = p_.allocUnsafe(28);
    return e.writeInt32BE(this._a, 0), e.writeInt32BE(this._b, 4), e.writeInt32BE(this._c, 8), e.writeInt32BE(this._d, 12), e.writeInt32BE(this._e, 16), e.writeInt32BE(this._f, 20), e.writeInt32BE(this._g, 24), e
};
var v_ = si,
    y_ = ye.exports,
    nl = gr,
    b_ = De.exports.Buffer,
    ns = [1116352408, 3609767458, 1899447441, 602891725, 3049323471, 3964484399, 3921009573, 2173295548, 961987163, 4081628472, 1508970993, 3053834265, 2453635748, 2937671579, 2870763221, 3664609560, 3624381080, 2734883394, 310598401, 1164996542, 607225278, 1323610764, 1426881987, 3590304994, 1925078388, 4068182383, 2162078206, 991336113, 2614888103, 633803317, 3248222580, 3479774868, 3835390401, 2666613458, 4022224774, 944711139, 264347078, 2341262773, 604807628, 2007800933, 770255983, 1495990901, 1249150122, 1856431235, 1555081692, 3175218132, 1996064986, 2198950837, 2554220882, 3999719339, 2821834349, 766784016, 2952996808, 2566594879, 3210313671, 3203337956, 3336571891, 1034457026, 3584528711, 2466948901, 113926993, 3758326383, 338241895, 168717936, 666307205, 1188179964, 773529912, 1546045734, 1294757372, 1522805485, 1396182291, 2643833823, 1695183700, 2343527390, 1986661051, 1014477480, 2177026350, 1206759142, 2456956037, 344077627, 2730485921, 1290863460, 2820302411, 3158454273, 3259730800, 3505952657, 3345764771, 106217008, 3516065817, 3606008344, 3600352804, 1432725776, 4094571909, 1467031594, 275423344, 851169720, 430227734, 3100823752, 506948616, 1363258195, 659060556, 3750685593, 883997877, 3785050280, 958139571, 3318307427, 1322822218, 3812723403, 1537002063, 2003034995, 1747873779, 3602036899, 1955562222, 1575990012, 2024104815, 1125592928, 2227730452, 2716904306, 2361852424, 442776044, 2428436474, 593698344, 2756734187, 3733110249, 3204031479, 2999351573, 3329325298, 3815920427, 3391569614, 3928383900, 3515267271, 566280711, 3940187606, 3454069534, 4118630271, 4000239992, 116418474, 1914138554, 174292421, 2731055270, 289380356, 3203993006, 460393269, 320620315, 685471733, 587496836, 852142971, 1086792851, 1017036298, 365543100, 1126000580, 2618297676, 1288033470, 3409855158, 1501505948, 4234509866, 1607167915, 987167468, 1816402316, 1246189591],
    g_ = new Array(160);

function dn() {
    this.init(), this._w = g_, nl.call(this, 128, 112)
}
y_(dn, nl);
dn.prototype.init = function() {
    return this._ah = 1779033703, this._bh = 3144134277, this._ch = 1013904242, this._dh = 2773480762, this._eh = 1359893119, this._fh = 2600822924, this._gh = 528734635, this._hh = 1541459225, this._al = 4089235720, this._bl = 2227873595, this._cl = 4271175723, this._dl = 1595750129, this._el = 2917565137, this._fl = 725511199, this._gl = 4215389547, this._hl = 327033209, this
};

function is(e, t, r) {
    return r ^ e & (t ^ r)
}

function as(e, t, r) {
    return e & t | r & (e | t)
}

function os(e, t) {
    return (e >>> 28 | t << 4) ^ (t >>> 2 | e << 30) ^ (t >>> 7 | e << 25)
}

function ss(e, t) {
    return (e >>> 14 | t << 18) ^ (e >>> 18 | t << 14) ^ (t >>> 9 | e << 23)
}

function w_(e, t) {
    return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ e >>> 7
}

function x_(e, t) {
    return (e >>> 1 | t << 31) ^ (e >>> 8 | t << 24) ^ (e >>> 7 | t << 25)
}

function m_(e, t) {
    return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ e >>> 6
}

function E_(e, t) {
    return (e >>> 19 | t << 13) ^ (t >>> 29 | e << 3) ^ (e >>> 6 | t << 26)
}

function xe(e, t) {
    return e >>> 0 < t >>> 0 ? 1 : 0
}
dn.prototype._update = function(e) {
    for (var t = this._w, r = this._ah | 0, n = this._bh | 0, i = this._ch | 0, a = this._dh | 0, o = this._eh | 0, s = this._fh | 0, c = this._gh | 0, u = this._hh | 0, f = this._al | 0, b = this._bl | 0, _ = this._cl | 0, v = this._dl | 0, g = this._el | 0, k = this._fl | 0, O = this._gl | 0, z = this._hl | 0, P = 0; P < 32; P += 2) t[P] = e.readInt32BE(P * 4), t[P + 1] = e.readInt32BE(P * 4 + 4);
    for (; P < 160; P += 2) {
        var L = t[P - 30],
            y = t[P - 15 * 2 + 1],
            D = w_(L, y),
            w = x_(y, L);
        L = t[P - 2 * 2], y = t[P - 2 * 2 + 1];
        var x = m_(L, y),
            A = E_(y, L),
            U = t[P - 7 * 2],
            N = t[P - 7 * 2 + 1],
            F = t[P - 16 * 2],
            W = t[P - 16 * 2 + 1],
            K = w + N | 0,
            Z = D + U + xe(K, w) | 0;
        K = K + A | 0, Z = Z + x + xe(K, A) | 0, K = K + W | 0, Z = Z + F + xe(K, W) | 0, t[P] = Z, t[P + 1] = K
    }
    for (var V = 0; V < 160; V += 2) {
        Z = t[V], K = t[V + 1];
        var ie = as(r, n, i),
            re = as(f, b, _),
            I = os(r, f),
            T = os(f, r),
            h = ss(o, g),
            m = ss(g, o),
            S = ns[V],
            C = ns[V + 1],
            $ = is(o, s, c),
            M = is(g, k, O),
            H = z + m | 0,
            j = u + h + xe(H, z) | 0;
        H = H + M | 0, j = j + $ + xe(H, M) | 0, H = H + C | 0, j = j + S + xe(H, C) | 0, H = H + K | 0, j = j + Z + xe(H, K) | 0;
        var ee = T + re | 0,
            ce = I + ie + xe(ee, T) | 0;
        u = c, z = O, c = s, O = k, s = o, k = g, g = v + H | 0, o = a + j + xe(g, v) | 0, a = i, v = _, i = n, _ = b, n = r, b = f, f = H + ee | 0, r = j + ce + xe(f, H) | 0
    }
    this._al = this._al + f | 0, this._bl = this._bl + b | 0, this._cl = this._cl + _ | 0, this._dl = this._dl + v | 0, this._el = this._el + g | 0, this._fl = this._fl + k | 0, this._gl = this._gl + O | 0, this._hl = this._hl + z | 0, this._ah = this._ah + r + xe(this._al, f) | 0, this._bh = this._bh + n + xe(this._bl, b) | 0, this._ch = this._ch + i + xe(this._cl, _) | 0, this._dh = this._dh + a + xe(this._dl, v) | 0, this._eh = this._eh + o + xe(this._el, g) | 0, this._fh = this._fh + s + xe(this._fl, k) | 0, this._gh = this._gh + c + xe(this._gl, O) | 0, this._hh = this._hh + u + xe(this._hl, z) | 0
};
dn.prototype._hash = function() {
    var e = b_.allocUnsafe(64);

    function t(r, n, i) {
        e.writeInt32BE(r, i), e.writeInt32BE(n, i + 4)
    }
    return t(this._ah, this._al, 0), t(this._bh, this._bl, 8), t(this._ch, this._cl, 16), t(this._dh, this._dl, 24), t(this._eh, this._el, 32), t(this._fh, this._fl, 40), t(this._gh, this._gl, 48), t(this._hh, this._hl, 56), e
};
var il = dn,
    S_ = ye.exports,
    A_ = il,
    k_ = gr,
    T_ = De.exports.Buffer,
    z_ = new Array(160);

function ui() {
    this.init(), this._w = z_, k_.call(this, 128, 112)
}
S_(ui, A_);
ui.prototype.init = function() {
    return this._ah = 3418070365, this._bh = 1654270250, this._ch = 2438529370, this._dh = 355462360, this._eh = 1731405415, this._fh = 2394180231, this._gh = 3675008525, this._hh = 1203062813, this._al = 3238371032, this._bl = 914150663, this._cl = 812702999, this._dl = 4144912697, this._el = 4290775857, this._fl = 1750603025, this._gl = 1694076839, this._hl = 3204075428, this
};
ui.prototype._hash = function() {
    var e = T_.allocUnsafe(48);

    function t(r, n, i) {
        e.writeInt32BE(r, i), e.writeInt32BE(n, i + 4)
    }
    return t(this._ah, this._al, 0), t(this._bh, this._bl, 8), t(this._ch, this._cl, 16), t(this._dh, this._dl, 24), t(this._eh, this._el, 32), t(this._fh, this._fl, 40), e
};
var R_ = ui,
    jt = Ju.exports = function(t) {
        t = t.toLowerCase();
        var r = jt[t];
        if (!r) throw new Error(t + " is not supported (we accept pull requests)");
        return new r
    };
jt.sha = Zp;
jt.sha1 = e_;
jt.sha224 = v_;
jt.sha256 = rl;
jt.sha384 = R_;
jt.sha512 = il;
var O_ = Ne,
    Pa = ha.exports.EventEmitter,
    D_ = ye.exports;
D_(Ne, Pa);
Ne.Readable = za;
Ne.Writable = Sa;
Ne.Duplex = qt;
Ne.Transform = Da;
Ne.PassThrough = Ku;
Ne.finished = Jn;
Ne.pipeline = qu;
Ne.Stream = Ne;

function Ne() {
    Pa.call(this)
}
Ne.prototype.pipe = function(e, t) {
    var r = this;

    function n(f) {
        e.writable && e.write(f) === !1 && r.pause && r.pause()
    }
    r.on("data", n);

    function i() {
        r.readable && r.resume && r.resume()
    }
    e.on("drain", i), !e._isStdio && (!t || t.end !== !1) && (r.on("end", o), r.on("close", s));
    var a = !1;

    function o() {
        a || (a = !0, e.end())
    }

    function s() {
        a || (a = !0, typeof e.destroy == "function" && e.destroy())
    }

    function c(f) {
        if (u(), Pa.listenerCount(this, "error") === 0) throw f
    }
    r.on("error", c), e.on("error", c);

    function u() {
        r.removeListener("data", n), e.removeListener("drain", i), r.removeListener("end", o), r.removeListener("close", s), r.removeListener("error", c), e.removeListener("error", c), r.removeListener("end", u), r.removeListener("close", u), e.removeListener("close", u)
    }
    return r.on("end", u), r.on("close", u), e.on("close", u), e.emit("pipe", r), e
};
var al = De.exports.Buffer,
    ol = O_.Transform,
    P_ = Yn.StringDecoder,
    C_ = ye.exports;

function We(e) {
    ol.call(this), this.hashMode = typeof e == "string", this.hashMode ? this[e] = this._finalOrDigest : this.final = this._finalOrDigest, this._final && (this.__final = this._final, this._final = null), this._decoder = null, this._encoding = null
}
C_(We, ol);
We.prototype.update = function(e, t, r) {
    typeof e == "string" && (e = al.from(e, t));
    var n = this._update(e);
    return this.hashMode ? this : (r && (n = this._toString(n, r)), n)
};
We.prototype.setAutoPadding = function() {};
We.prototype.getAuthTag = function() {
    throw new Error("trying to get auth tag in unsupported state")
};
We.prototype.setAuthTag = function() {
    throw new Error("trying to set auth tag in unsupported state")
};
We.prototype.setAAD = function() {
    throw new Error("trying to set aad in unsupported state")
};
We.prototype._transform = function(e, t, r) {
    var n;
    try {
        this.hashMode ? this._update(e) : this.push(this._update(e))
    } catch (i) {
        n = i
    } finally {
        r(n)
    }
};
We.prototype._flush = function(e) {
    var t;
    try {
        this.push(this.__final())
    } catch (r) {
        t = r
    }
    e(t)
};
We.prototype._finalOrDigest = function(e) {
    var t = this.__final() || al.alloc(0);
    return e && (t = this._toString(t, e, !0)), t
};
We.prototype._toString = function(e, t, r) {
    if (this._decoder || (this._decoder = new P_(t), this._encoding = t), this._encoding !== t) throw new Error("can't switch encodings");
    var n = this._decoder.write(e);
    return r && (n += this._decoder.end()), n
};
var N_ = We,
    L_ = ye.exports,
    I_ = Np,
    B_ = Bp,
    M_ = Ju.exports,
    sl = N_;

function li(e) {
    sl.call(this, "digest"), this._hash = e
}
L_(li, sl);
li.prototype._update = function(e) {
    this._hash.update(e)
};
li.prototype._final = function() {
    return this._hash.digest()
};
var U_ = function(t) {
        return t = t.toLowerCase(), t === "md5" ? new I_ : t === "rmd160" || t === "ripemd160" ? new B_ : new li(M_(t))
    },
    Qt = null;
typeof WebSocket < "u" ? Qt = WebSocket : typeof MozWebSocket < "u" ? Qt = MozWebSocket : typeof Y < "u" ? Qt = Y.WebSocket || Y.MozWebSocket : typeof window < "u" ? Qt = window.WebSocket || window.MozWebSocket : typeof self < "u" && (Qt = self.WebSocket || self.MozWebSocket);
var $_ = Qt;
(function(e) {
    var t = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r, n = t(yr),
        i = t(jn.exports),
        a = t(gu.exports),
        o = t(Wt.exports),
        s = t(Ie.exports),
        c = t(Be.exports),
        u = t(Au),
        f = t(kd),
        b = t(U_),
        _ = t($_),
        v = "/socket.io/?EIO=3&transport=websocket",
        g = null,
        k = !1,
        O = !1,
        z = [],
        P = null,
        L = function(W) {
            return (0, b.default)("sha256").update(W).digest("hex")
        },
        y = function() {
            var W = new Uint8Array(24);
            return (0, f.default)(W), W.join("")
        },
        D = function() {
            var K;
            return K = typeof location > "u" ? r : location.hasOwnProperty("hostname") && location.hostname.length && location.hostname !== "localhost" ? location.hostname : r, K.substr(0, 4) === "www." && (K = K.replace("www.", "")), K
        },
        w = u.default.getAppKey();
    w || (w = "appkey:" + y());
    var x = function() {
            var W = 0 < arguments.length && arguments[0] !== void 0 ? arguments[0] : null,
                K = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : null;
            W === null && K === null ? g.send("40/scatter") : g.send("42/scatter," + JSON.stringify([W, K]))
        },
        A = null,
        U = function() {
            var W = 0 < arguments.length && arguments[0] !== void 0 && arguments[0];
            return new Promise(function(K, Z) {
                A = {
                    resolve: K,
                    reject: Z
                }, x("pair", {
                    data: {
                        appkey: w,
                        origin: D(),
                        passthrough: W
                    },
                    plugin: r
                })
            })
        },
        N = {},
        F = function() {
            function W() {
                (0, s.default)(this, W)
            }
            return (0, c.default)(W, null, [{
                key: "init",
                value: function(Z) {
                    var V = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : 6e4;
                    r = Z, this.timeout = V
                }
            }, {
                key: "getOrigin",
                value: function() {
                    return D()
                }
            }, {
                key: "addEventHandler",
                value: function(Z, V) {
                    V || (V = "app"), N[V] = Z
                }
            }, {
                key: "removeEventHandler",
                value: function(Z) {
                    Z || (Z = "app"), delete N[Z]
                }
            }, {
                key: "link",
                value: function() {
                    var Z = this;
                    return Promise.race([new Promise(function(V) {
                        return setTimeout(function() {
                            k || (V(!1), g && (g.disconnect(), g = null))
                        }, Z.timeout)
                    }), new Promise(function() {
                        var V = (0, o.default)(n.default.mark(function ie(re) {
                            var I, T;
                            return n.default.wrap(function(h) {
                                for (;;) switch (h.prev = h.next) {
                                    case 0:
                                        return I = function() {
                                            g.onmessage = function(M) {
                                                if (M.data.indexOf("42/scatter") === -1) return !1;
                                                var H = JSON.parse(M.data.replace("42/scatter,", "")),
                                                    j = (0, a.default)(H, 2),
                                                    ee = j[0],
                                                    ce = j[1];
                                                return ee === "paired" ? m(ce) : ee === "rekey" ? S() : ee === "api" ? C(ce) : ee === "event" ? $(ce) : void 0
                                            };
                                            var m = function(M) {
                                                    if (O = M, O) {
                                                        var H = u.default.getAppKey(),
                                                            j = -1 < w.indexOf("appkey:") ? L(w) : w;
                                                        H && H === j || (u.default.setAppKey(j), w = u.default.getAppKey())
                                                    }
                                                    A.resolve(M)
                                                },
                                                S = function() {
                                                    w = "appkey:" + y(), x("rekeyed", {
                                                        data: {
                                                            appkey: w,
                                                            origin: D()
                                                        },
                                                        plugin: r
                                                    })
                                                },
                                                C = function(M) {
                                                    var H = z.find(function(ee) {
                                                        return ee.id === M.id
                                                    });
                                                    if (H) {
                                                        z = z.filter(function(ee) {
                                                            return ee.id !== M.id
                                                        });
                                                        var j = (0, i.default)(M.result) === "object" && M.result !== null && M.result.hasOwnProperty("isError");
                                                        j ? H.reject(M.result) : H.resolve(M.result)
                                                    }
                                                },
                                                $ = function(M) {
                                                    var H = M.event,
                                                        j = M.payload;
                                                    Object.keys(N).length && Object.keys(N).map(function(ee) {
                                                        N[ee](H, j)
                                                    })
                                                }
                                        }, T = function() {
                                            var m, S = !(0 < arguments.length && arguments[0] !== void 0) || arguments[0],
                                                C = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : null;
                                            C || (m = new Promise(function(ee) {
                                                return C = ee
                                            }));
                                            var $ = S ? "local.get-scatter.com:50006" : "127.0.0.1:50005",
                                                M = S ? "wss://" : "ws://",
                                                H = "".concat(M).concat($).concat(v),
                                                j = new _.default(H);
                                            return j.onerror = function() {
                                                S ? T(!1, C) : (re(!1), C(!1))
                                            }, j.onopen = function() {
                                                g = j, x(), clearTimeout(P), k = !0, U(!0).then(function() {
                                                    re(!0), C(!0)
                                                }), I()
                                            }, m
                                        }, h.next = 4, T();
                                    case 4:
                                    case "end":
                                        return h.stop()
                                }
                            }, ie, this)
                        }));
                        return function() {
                            return V.apply(this, arguments)
                        }
                    }())])
                }
            }, {
                key: "isConnected",
                value: function() {
                    return k
                }
            }, {
                key: "isPaired",
                value: function() {
                    return O
                }
            }, {
                key: "disconnect",
                value: function() {
                    return g && g.close(), !0
                }
            }, {
                key: "removeAppKeys",
                value: function() {
                    u.default.removeAppKey(), u.default.removeNonce()
                }
            }, {
                key: "sendApiRequest",
                value: function(Z) {
                    return new Promise(function(V, ie) {
                        return Z.type !== "identityFromPermissions" || O ? void U().then(function() {
                            if (!O) return ie({
                                code: "not_paired",
                                message: "The user did not allow this app to connect to their Scatter"
                            });
                            Z.id = y(), Z.appkey = w, Z.nonce = u.default.getNonce() || 0;
                            var re = y();
                            Z.nextNonce = L(re), u.default.setNonce(re), Z.hasOwnProperty("payload") && !Z.payload.hasOwnProperty("origin") && (Z.payload.origin = D()), z.push(Object.assign(Z, {
                                resolve: V,
                                reject: ie
                            })), x("api", {
                                data: Z,
                                plugin: r
                            })
                        }) : V(!1)
                    })
                }
            }]), W
        }();
    e.default = F
})(Gn);
var fi = {};
(function(e) {
    var t = vr.exports,
        r = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var n = r(Ie.exports),
        i = r(Be.exports),
        a = t(br),
        o = function() {
            function s() {
                var c = 0 < arguments.length && arguments[0] !== void 0 ? arguments[0] : "",
                    u = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : "";
                (0, n.default)(this, s), this.name = c, this.type = u
            }
            return (0, i.default)(s, [{
                key: "isSignatureProvider",
                value: function() {
                    return this.type === a.BLOCKCHAIN_SUPPORT
                }
            }, {
                key: "isValid",
                value: function() {
                    return Object.keys(a).map(function(u) {
                        return a[u]
                    }).includes(this.type)
                }
            }], [{
                key: "placeholder",
                value: function() {
                    return new s
                }
            }, {
                key: "fromJson",
                value: function(u) {
                    return Object.assign(s.placeholder(), u)
                }
            }]), s
        }();
    e.default = o
})(fi);
var wr = {};
(function(e) {
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.BlockchainsArray = e.Blockchains = void 0;
    var t = {
        EOS: "eos",
        ETH: "eth",
        TRX: "trx"
    };
    e.Blockchains = t;
    var r = Object.keys(t).map(function(n) {
        return {
            key: n,
            value: t[n]
        }
    });
    e.BlockchainsArray = r
})(wr);
var ul = {},
    Ca = {};
(function(e) {
    var t = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = t(Ie.exports),
        n = t(Be.exports),
        i = wr,
        a = function() {
            function o() {
                var s = 0 < arguments.length && arguments[0] !== void 0 ? arguments[0] : i.Blockchains.EOS,
                    c = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : "",
                    u = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : "",
                    f = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null,
                    b = 4 < arguments.length && arguments[4] !== void 0 ? arguments[4] : null;
                (0, r.default)(this, o), this.blockchain = s, this.contract = c, this.symbol = u, this.name = f || u, this.decimals = b
            }
            return (0, n.default)(o, null, [{
                key: "placeholder",
                value: function() {
                    return new o
                }
            }, {
                key: "fromJson",
                value: function(c) {
                    return Object.assign(this.placeholder(), c)
                }
            }]), o
        }();
    e.default = a
})(Ca);
(function(e) {
    var t = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = t(Ie.exports),
        n = t(Be.exports),
        i = wr,
        a = t(Ca),
        o = function() {
            function s() {
                var c = 0 < arguments.length && arguments[0] !== void 0 ? arguments[0] : "",
                    u = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : "https",
                    f = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : "",
                    b = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : 0,
                    _ = 4 < arguments.length && arguments[4] !== void 0 ? arguments[4] : i.Blockchains.EOS,
                    v = 5 < arguments.length && arguments[5] !== void 0 ? arguments[5] : "";
                (0, r.default)(this, s), this.name = c, this.protocol = u, this.host = f, this.port = b, this.blockchain = _, this.chainId = v.toString(), this.token = null
            }
            return (0, n.default)(s, [{
                key: "fullhost",
                value: function() {
                    return "".concat(this.protocol, "://").concat(this.host).concat(this.port ? ":" : "").concat(this.port)
                }
            }, {
                key: "unique",
                value: function() {
                    return ("".concat(this.blockchain, ":") + (this.chainId.length ? "chain:".concat(this.chainId) : "".concat(this.host, ":").concat(this.port))).toLowerCase()
                }
            }], [{
                key: "placeholder",
                value: function() {
                    return new s
                }
            }, {
                key: "fromJson",
                value: function(u) {
                    var f = Object.assign(s.placeholder(), u);
                    return f.chainId = f.chainId ? f.chainId.toString() : "", f.token = u.hasOwnProperty("token") && u.token ? a.default.fromJson(u.token) : null, f
                }
            }]), s
        }();
    e.default = o
})(ul);
var Na = {};
(function(e) {
    var t = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = e.WALLET_METHODS = void 0;
    var r, n = t(Ie.exports),
        i = t(Be.exports),
        a = t(da.exports),
        o = {
            disconnect: "disconnect",
            isConnected: "isConnected",
            isPaired: "isPaired",
            addEventHandler: "addEventHandler",
            removeEventHandler: "removeEventHandler",
            listen: "listen",
            getVersion: "getVersion",
            getIdentity: "getIdentity",
            getIdentityFromPermissions: "getIdentityFromPermissions",
            forgetIdentity: "forgetIdentity",
            updateIdentity: "updateIdentity",
            authenticate: "authenticate",
            getArbitrarySignature: "getArbitrarySignature",
            getPublicKey: "getPublicKey",
            linkAccount: "linkAccount",
            hasAccountFor: "hasAccountFor",
            suggestNetwork: "suggestNetwork",
            requestTransfer: "requestTransfer",
            requestSignature: "requestSignature",
            createTransaction: "createTransaction",
            addToken: "addToken"
        };
    e.WALLET_METHODS = o;
    var s = (r = {}, (0, a.default)(r, o.getIdentity, "login"), (0, a.default)(r, o.forgetIdentity, "logout"), (0, a.default)(r, o.getIdentityFromPermissions, "checkLogin"), r),
        c = function() {
            function u(f, b, _) {
                (0, n.default)(this, u);
                var v = function(k) {
                        return function() {
                            throw console.error("".concat(f, " does not support the ").concat(k, " method.")), new Error("".concat(f, " does not support the ").concat(k, " method."))
                        }
                    },
                    g = function(k, O) {
                        typeof _[O] > "u" && (_[O] = k || v(O)), s[O] && typeof _[s[O]] > "u" && (_[s[O]] = _[O] ? _[O] : v(O))
                    };
                Object.keys(o).map(function(k) {
                    return g(b[k], k)
                })
            }
            return (0, i.default)(u, null, [{
                key: "bindBasics",
                value: function(b) {
                    b.account = function(_) {
                        return b.identity && b.identity.accounts ? b.identity.accounts.find(function(v) {
                            return v.blockchain === _
                        }) : void 0
                    }
                }
            }]), u
        }();
    e.default = c
})(Na);
var ll = {},
    ci = {
        exports: {}
    },
    fl = {
        exports: {}
    };
(function(e) {
    function t(r) {
        if (r === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return r
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(fl);
(function(e) {
    var t = jn.exports.default,
        r = fl.exports;

    function n(i, a) {
        if (a && (t(a) === "object" || typeof a == "function")) return a;
        if (a !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
        return r(i)
    }
    e.exports = n, e.exports.__esModule = !0, e.exports.default = e.exports
})(ci);
var hi = {
    exports: {}
};
(function(e) {
    function t(r) {
        return e.exports = t = Object.setPrototypeOf ? Object.getPrototypeOf : function(i) {
            return i.__proto__ || Object.getPrototypeOf(i)
        }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r)
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(hi);
var di = {
        exports: {}
    },
    cl = {
        exports: {}
    };
(function(e) {
    function t(r, n) {
        return e.exports = t = Object.setPrototypeOf || function(a, o) {
            return a.__proto__ = o, a
        }, e.exports.__esModule = !0, e.exports.default = e.exports, t(r, n)
    }
    e.exports = t, e.exports.__esModule = !0, e.exports.default = e.exports
})(cl);
(function(e) {
    var t = cl.exports;

    function r(n, i) {
        if (typeof i != "function" && i !== null) throw new TypeError("Super expression must either be null or a function");
        n.prototype = Object.create(i && i.prototype, {
            constructor: {
                value: n,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(n, "prototype", {
            writable: !1
        }), i && t(n, i)
    }
    e.exports = r, e.exports.__esModule = !0, e.exports.default = e.exports
})(di);
(function(e) {
    var t = vr.exports,
        r = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var n = r(da.exports),
        i = r(yr),
        a = r(Wt.exports),
        o = r(Ie.exports),
        s = r(Be.exports),
        c = r(ci.exports),
        u = r(hi.exports),
        f = r(di.exports),
        b = r(fi),
        _ = wr,
        v = t(br),
        g = r(Gn),
        k = qn,
        O = function(z) {
            function P(L, y) {
                var D;
                return (0, o.default)(this, P), D = (0, c.default)(this, (0, u.default)(P).call(this, _.Blockchains.EOS, v.WALLET_SUPPORT)), D.name = "ScatterSockets", D.context = L, D.holderFns = y, D
            }
            return (0, f.default)(P, z), (0, s.default)(P, [{
                key: "connect",
                value: function(y) {
                    var D = this,
                        w = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : {};
                    return new Promise(function(x) {
                        if (!y || !y.length) throw new Error("You must specify a name for this connection");
                        w = Object.assign({
                            initTimeout: 1e4,
                            linkTimeout: 3e4
                        }, w), g.default.init(y, w.linkTimeout), g.default.link().then(function() {
                            var A = (0, a.default)(i.default.mark(function U(N) {
                                return i.default.wrap(function(F) {
                                    for (;;) switch (F.prev = F.next) {
                                        case 0:
                                            if (N) {
                                                F.next = 2;
                                                break
                                            }
                                            return F.abrupt("return", !1);
                                        case 2:
                                            return D.holderFns.get().isExtension = !1, D.holderFns.get().wallet || (D.holderFns.get().wallet = D.name), F.abrupt("return", x(!0));
                                        case 5:
                                        case "end":
                                            return F.stop()
                                    }
                                }, U, this)
                            }));
                            return function() {
                                return A.apply(this, arguments)
                            }
                        }())
                    })
                }
            }, {
                key: "runAfterInterfacing",
                value: function() {
                    var L = (0, a.default)(i.default.mark(function y() {
                        var D = this;
                        return i.default.wrap(function(w) {
                            for (;;) switch (w.prev = w.next) {
                                case 0:
                                    return this.holderFns.get().addEventHandler(function(x, A) {
                                        return D.eventHandler(x, A)
                                    }, "internal"), w.next = 3, this.holderFns.get().getIdentityFromPermissions();
                                case 3:
                                    return this.holderFns.get().identity = w.sent, w.abrupt("return", !0);
                                case 5:
                                case "end":
                                    return w.stop()
                            }
                        }, y, this)
                    }));
                    return function() {
                        return L.apply(this, arguments)
                    }
                }()
            }, {
                key: "methods",
                value: function() {
                    var y, D = this,
                        w = function(x, A) {
                            return (x || A) && (D.holderFns.get().identity = x), A || x
                        };
                    return y = {}, (0, n.default)(y, k.WALLET_METHODS.disconnect, function() {
                        return g.default.disconnect()
                    }), (0, n.default)(y, k.WALLET_METHODS.isConnected, function() {
                        return g.default.isConnected()
                    }), (0, n.default)(y, k.WALLET_METHODS.isPaired, function() {
                        return g.default.isPaired()
                    }), (0, n.default)(y, k.WALLET_METHODS.addEventHandler, function(x) {
                        var A = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : null;
                        return g.default.addEventHandler(x, A)
                    }), (0, n.default)(y, k.WALLET_METHODS.removeEventHandler, function() {
                        var x = 0 < arguments.length && arguments[0] !== void 0 ? arguments[0] : null;
                        return g.default.removeEventHandler(x)
                    }), (0, n.default)(y, k.WALLET_METHODS.listen, function(x) {
                        return g.default.addEventHandler(x)
                    }), (0, n.default)(y, k.WALLET_METHODS.getVersion, function() {
                        return g.default.sendApiRequest({
                            type: "getVersion",
                            payload: {}
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.getIdentity, function(x) {
                        return g.default.sendApiRequest({
                            type: "getOrRequestIdentity",
                            payload: {
                                fields: x || {
                                    accounts: [D.holderFns.get().network]
                                }
                            }
                        }).then(w)
                    }), (0, n.default)(y, k.WALLET_METHODS.getIdentityFromPermissions, function() {
                        return g.default.sendApiRequest({
                            type: "identityFromPermissions",
                            payload: {}
                        }).then(w)
                    }), (0, n.default)(y, k.WALLET_METHODS.forgetIdentity, function() {
                        return g.default.sendApiRequest({
                            type: "forgetIdentity",
                            payload: {}
                        }).then(function(x) {
                            return w(null, x)
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.updateIdentity, function(x) {
                        var A = x.name,
                            U = x.kyc;
                        return g.default.sendApiRequest({
                            type: "updateIdentity",
                            payload: {
                                name: A,
                                kyc: U
                            }
                        }).then(function(N) {
                            return N ? w(N) : null
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.authenticate, function(x) {
                        var A = 1 < arguments.length && arguments[1] !== void 0 ? arguments[1] : null,
                            U = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
                        return g.default.sendApiRequest({
                            type: "authenticate",
                            payload: {
                                nonce: x,
                                data: A,
                                publicKey: U
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.getArbitrarySignature, function(x, A) {
                        return g.default.sendApiRequest({
                            type: "requestArbitrarySignature",
                            payload: {
                                publicKey: x,
                                data: A
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.getPublicKey, function(x) {
                        return g.default.sendApiRequest({
                            type: "getPublicKey",
                            payload: {
                                blockchain: x
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.linkAccount, function(x, A) {
                        return g.default.sendApiRequest({
                            type: "linkAccount",
                            payload: {
                                account: x,
                                network: A || D.holderFns.get().network
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.hasAccountFor, function(x) {
                        return g.default.sendApiRequest({
                            type: "hasAccountFor",
                            payload: {
                                network: x || D.holderFns.get().network
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.suggestNetwork, function(x) {
                        return g.default.sendApiRequest({
                            type: "requestAddNetwork",
                            payload: {
                                network: x || D.holderFns.get().network
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.requestTransfer, function(x, A, U) {
                        var N = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : {};
                        return g.default.sendApiRequest({
                            type: "requestTransfer",
                            payload: {
                                network: x || D.holderFns.get().network,
                                to: A,
                                amount: U,
                                options: N
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.requestSignature, function(x) {
                        return g.default.sendApiRequest({
                            type: "requestSignature",
                            payload: x
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.createTransaction, function(x, A, U, N) {
                        return g.default.sendApiRequest({
                            type: "createTransaction",
                            payload: {
                                blockchain: x,
                                actions: A,
                                account: U,
                                network: N || D.holderFns.get().network
                            }
                        })
                    }), (0, n.default)(y, k.WALLET_METHODS.addToken, function(x, A) {
                        return g.default.sendApiRequest({
                            type: "addToken",
                            payload: {
                                token: x,
                                network: A || D.holderFns.get().network
                            }
                        })
                    }), y
                }
            }, {
                key: "eventHandler",
                value: function() {
                    var L = (0, a.default)(i.default.mark(function y(D) {
                        return i.default.wrap(function(w) {
                            for (;;) switch (w.prev = w.next) {
                                case 0:
                                    w.t0 = D, w.next = w.t0 === k.EVENTS.Disconnected ? 3 : w.t0 === k.EVENTS.LoggedOut ? 5 : 9;
                                    break;
                                case 3:
                                    return this.holderFns.get().identity = null, w.abrupt("break", 9);
                                case 5:
                                    return w.next = 7, this.holderFns.get().getIdentityFromPermissions();
                                case 7:
                                    return this.holderFns.get().identity = w.sent, w.abrupt("break", 9);
                                case 9:
                                case "end":
                                    return w.stop()
                            }
                        }, y, this)
                    }));
                    return function() {
                        return L.apply(this, arguments)
                    }
                }()
            }]), P
        }(b.default);
    e.default = O
})(ll);
var hl = {};
(function(e) {
    var t = vr.exports,
        r = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var n = r(da.exports),
        i = r(Ie.exports),
        a = r(Be.exports),
        o = r(ci.exports),
        s = r(hi.exports),
        c = r(di.exports),
        u = r(yr),
        f = r(Wt.exports),
        b = t(br),
        _ = r(fi),
        v = wr,
        g = t(Na);
    r(Gn);
    var k = !1;
    typeof window < "u" && typeof document < "u" && (typeof window.scatter > "u" ? document.addEventListener("scatterLoaded", function() {
        return k = !0
    }) : k = !0);
    var O = function() {
            var P = (0, f.default)(u.default.mark(function L() {
                var y, D, w = arguments;
                return u.default.wrap(function(x) {
                    for (;;) switch (x.prev = x.next) {
                        case 0:
                            return y = 0 < w.length && w[0] !== void 0 ? w[0] : null, D = 1 < w.length && w[1] !== void 0 ? w[1] : 0, x.abrupt("return", new Promise(function(A) {
                                return y || (y = A), k ? y(!0) : 5 < D ? y(!1) : void setTimeout(function() {
                                    return O(y, D + 1)
                                }, 100)
                            }));
                        case 3:
                        case "end":
                            return x.stop()
                    }
                }, L, this)
            }));
            return function() {
                return P.apply(this, arguments)
            }
        }(),
        z = function(P) {
            function L(y, D) {
                var w;
                return (0, i.default)(this, L), w = (0, o.default)(this, (0, s.default)(L).call(this, v.Blockchains.EOS, b.WALLET_SUPPORT)), w.name = "ScatterExtension", w.context = y, w.holderFns = D, w
            }
            return (0, c.default)(L, P), (0, a.default)(L, [{
                key: "connect",
                value: function() {
                    var y = (0, f.default)(u.default.mark(function D() {
                        var w = this;
                        return u.default.wrap(function(x) {
                            for (;;) switch (x.prev = x.next) {
                                case 0:
                                    return x.abrupt("return", new Promise(function() {
                                        var A = (0, f.default)(u.default.mark(function U(N) {
                                            var F;
                                            return u.default.wrap(function(W) {
                                                for (;;) switch (W.prev = W.next) {
                                                    case 0:
                                                        return W.next = 2, O();
                                                    case 2:
                                                        F = W.sent, F && (!w.holderFns.get().wallet && (w.holderFns.get().wallet = w.name), N(!0));
                                                    case 4:
                                                    case "end":
                                                        return W.stop()
                                                }
                                            }, U, this)
                                        }));
                                        return function() {
                                            return A.apply(this, arguments)
                                        }
                                    }()));
                                case 1:
                                case "end":
                                    return x.stop()
                            }
                        }, D, this)
                    }));
                    return function() {
                        return y.apply(this, arguments)
                    }
                }()
            }, {
                key: "runBeforeInterfacing",
                value: function() {
                    var y = (0, f.default)(u.default.mark(function D() {
                        var w, x, A, U, N = this;
                        return u.default.wrap(function(F) {
                            for (;;) switch (F.prev = F.next) {
                                case 0:
                                    return w = this.context.network, w && (x = window.scatter.getIdentity.bind(window.scatter), A = window.scatter.useIdentity.bind(window.scatter), window.scatter.getIdentity = function(W) {
                                        return x(W || {
                                            accounts: [w]
                                        }).then(function(K) {
                                            return N.holderFns.get().identity = K, A(K), K
                                        })
                                    }, U = window.scatter.suggestNetwork.bind(window.scatter), window.scatter.suggestNetwork = function(W) {
                                        return U(W || w)
                                    }), this.holderFns.get().wallet === this.name && (window.scatter.wallet = this.name), this.holderFns.set(window.scatter), this.context = this.holderFns.get(), F.abrupt("return", !0);
                                case 6:
                                case "end":
                                    return F.stop()
                            }
                        }, D, this)
                    }));
                    return function() {
                        return y.apply(this, arguments)
                    }
                }()
            }, {
                key: "runAfterInterfacing",
                value: function() {
                    var y = (0, f.default)(u.default.mark(function D() {
                        return u.default.wrap(function(w) {
                            for (;;) switch (w.prev = w.next) {
                                case 0:
                                    return this.context.isExtension = !0, this.context.connect = this.connect, w.abrupt("return", !0);
                                case 3:
                                case "end":
                                    return w.stop()
                            }
                        }, D, this)
                    }));
                    return function() {
                        return y.apply(this, arguments)
                    }
                }()
            }, {
                key: "methods",
                value: function() {
                    return (0, n.default)({}, g.WALLET_METHODS.getIdentity, function() {
                        console.log("getid")
                    })
                }
            }]), L
        }(_.default);
    e.default = z
})(hl);
(function(e) {
    var t = vr.exports,
        r = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), Object.defineProperty(e, "SocketService", {
        enumerable: !0,
        get: function() {
            return c.default
        }
    }), Object.defineProperty(e, "Plugin", {
        enumerable: !0,
        get: function() {
            return u.default
        }
    }), Object.defineProperty(e, "Blockchains", {
        enumerable: !0,
        get: function() {
            return b.Blockchains
        }
    }), Object.defineProperty(e, "Network", {
        enumerable: !0,
        get: function() {
            return _.default
        }
    }), Object.defineProperty(e, "WalletInterface", {
        enumerable: !0,
        get: function() {
            return v.default
        }
    }), Object.defineProperty(e, "WALLET_METHODS", {
        enumerable: !0,
        get: function() {
            return v.WALLET_METHODS
        }
    }), e.PluginTypes = e.default = e.EVENTS = void 0;
    var n = r(yr),
        i = r(Wt.exports),
        a = r(Ie.exports),
        o = r(Be.exports),
        s = r(bu),
        c = r(Gn),
        u = r(fi),
        f = t(br);
    e.PluginTypes = f;
    var b = wr,
        _ = r(ul),
        v = t(Na),
        g = r(ll),
        k = r(hl),
        O = r(Ca),
        z = {
            Disconnected: "dced",
            LoggedOut: "logout"
        };
    e.EVENTS = z, c.default;
    var P = [],
        L = {},
        y = function() {
            function A() {
                (0, a.default)(this, A), this.identity = null, this.network = null, s.default.loadPlugin(new g.default(this, L)), s.default.loadPlugin(new k.default(this, L))
            }
            return (0, o.default)(A, [{
                key: "loadPlugin",
                value: function(N) {
                    if (!N.isValid()) throw new Error("".concat(N.name, " doesn't seem to be a valid ScatterJS plugin."));
                    s.default.loadPlugin(N), N.type === f.BLOCKCHAIN_SUPPORT && (this[N.name] = N.signatureProvider(function() {
                        if (!L.get().identity) throw new Error("No Identity")
                    }, function() {
                        return L.get().identity
                    }), this[N.name + "Hook"] = N.hookProvider, P.push(N.setSocketService)), N.type === f.WALLET_SUPPORT && N.init(this, L, P)
                }
            }, {
                key: "connect",
                value: function() {
                    var U = (0, i.default)(n.default.mark(function N(F, W) {
                        var K;
                        return n.default.wrap(function(Z) {
                            for (;;) switch (Z.prev = Z.next) {
                                case 0:
                                    return W || (W = {}), this.network = W.hasOwnProperty("network") ? W.network : null, K = s.default.wallets(), Z.next = 5, Promise.race(K.map(function(V) {
                                        return V.connect(F, W).then((0, i.default)(n.default.mark(function ie() {
                                            return n.default.wrap(function(re) {
                                                for (;;) switch (re.prev = re.next) {
                                                    case 0:
                                                        if (typeof V.runBeforeInterfacing != "function") {
                                                            re.next = 3;
                                                            break
                                                        }
                                                        return re.next = 3, V.runBeforeInterfacing();
                                                    case 3:
                                                        if (new v.default(V.name, V.methods(), L.get()), typeof V.runAfterInterfacing != "function") {
                                                            re.next = 7;
                                                            break
                                                        }
                                                        return re.next = 7, V.runAfterInterfacing();
                                                    case 7:
                                                        return v.default.bindBasics(L.get()), re.abrupt("return", !0);
                                                    case 9:
                                                    case "end":
                                                        return re.stop()
                                                }
                                            }, ie, this)
                                        })))
                                    }).concat(new Promise(function(V) {
                                        return setTimeout(function() {
                                            return V(!1)
                                        }, W.initTimeout || 5e3)
                                    })));
                                case 5:
                                    return Z.abrupt("return", Z.sent);
                                case 6:
                                case "end":
                                    return Z.stop()
                            }
                        }, N, this)
                    }));
                    return function() {
                        return U.apply(this, arguments)
                    }
                }()
            }]), A
        }(),
        D = function() {
            function A(U) {
                (0, a.default)(this, A), this.scatter = U
            }
            return (0, o.default)(A, [{
                key: "plugins",
                value: function() {
                    var N = this;
                    if (!this.scatter.isExtension) {
                        for (var F = arguments.length, W = Array(F), K = 0; K < F; K++) W[K] = arguments[K];
                        W.map(function(Z) {
                            return N.scatter.loadPlugin(Z)
                        })
                    }
                }
            }, {
                key: "connect",
                value: function() {
                    var N;
                    return (N = this.scatter).connect.apply(N, arguments)
                }
            }, {
                key: "catchAll",
                value: function() {}
            }]), A
        }(),
        w = new Proxy(new D(new y), {
            get: function(U, N) {
                return typeof U[N] > "u" ? U.scatter[N] : U[N]
            }
        });
    L.set = function(A) {
        return w.scatter = A
    }, L.get = function() {
        return w.scatter
    }, typeof window < "u" && (window.ScatterJS = w), w.Plugin = u.default, w.PluginTypes = f, w.Blockchains = b.Blockchains, w.Network = _.default, w.Token = O.default, w.SocketService = c.default, w.EVENTS = z, w.WalletInterface = v.default, w.WALLET_METHODS = v.WALLET_METHODS;
    var x = w;
    e.default = x
})(qn);
var Un = ca(qn),
    dl = {};
(function(e) {
    var t = Le.exports;
    Object.defineProperty(e, "__esModule", {
        value: !0
    }), e.default = void 0;
    var r = t(yr),
        n = t(Wt.exports),
        i = t(Ie.exports),
        a = t(Be.exports),
        o = t(ci.exports),
        s = t(hi.exports),
        c = t(di.exports),
        u = qn,
        f = u.SocketService,
        b = function(v, g) {
            return new Proxy(v, g)
        },
        _ = function(v) {
            function g() {
                return (0, i.default)(this, g), (0, o.default)(this, (0, s.default)(g).call(this, u.Blockchains.EOS, u.PluginTypes.BLOCKCHAIN_SUPPORT))
            }
            return (0, c.default)(g, v), (0, a.default)(g, [{
                key: "setSocketService",
                value: function(O) {
                    f = O
                }
            }, {
                key: "hookProvider",
                value: function(O) {
                    return function(z) {
                        return new Promise(function(P, L) {
                            var y = Object.assign(z, {
                                blockchain: u.Blockchains.EOS,
                                network: O,
                                requiredFields: {}
                            });
                            f.sendApiRequest({
                                type: "requestSignature",
                                payload: y
                            }).then(function(D) {
                                return P(D.signatures)
                            }).catch(function(D) {
                                return L(D)
                            })
                        })
                    }
                }
            }, {
                key: "signatureProvider",
                value: function() {
                    var O = 0 >= arguments.length ? void 0 : arguments[0];
                    return function(z, P) {
                        var L = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : {};
                        z = u.Network.fromJson(z);
                        var y, D = z.hasOwnProperty("chainId") && z.chainId.length ? z.chainId : L.chainId,
                            w = function() {
                                var x = (0, n.default)(r.default.mark(function A(U) {
                                    return r.default.wrap(function(N) {
                                        for (;;) switch (N.prev = N.next) {
                                            case 0:
                                                return N.abrupt("return", y(U));
                                            case 1:
                                            case "end":
                                                return N.stop()
                                        }
                                    }, A, this)
                                }));
                                return function() {
                                    return x.apply(this, arguments)
                                }
                            }();
                        return b(P({
                            httpEndpoint: z.fullhost(),
                            chainId: D,
                            signProvider: w
                        }), {
                            get: function(A, U) {
                                if (typeof A[U] != "function") return A[U];
                                var N = null;
                                return function() {
                                    for (var F = arguments.length, W = Array(F), K = 0; K < F; K++) W[K] = arguments[K];
                                    if (W.find(function(Z) {
                                            return Z.hasOwnProperty("keyProvider")
                                        })) throw Error.usedKeyProvider();
                                    return y = function() {
                                        var Z = (0, n.default)(r.default.mark(function V(ie) {
                                            var re, I, T, h;
                                            return r.default.wrap(function(m) {
                                                for (;;) switch (m.prev = m.next) {
                                                    case 0:
                                                        return O(), re = W.find(function(S) {
                                                            return S.hasOwnProperty("requiredFields")
                                                        }) || {
                                                            requiredFields: {}
                                                        }, I = Object.assign(ie, {
                                                            blockchain: u.Blockchains.EOS,
                                                            network: z,
                                                            requiredFields: re.requiredFields
                                                        }), m.next = 5, f.sendApiRequest({
                                                            type: "requestSignature",
                                                            payload: I
                                                        });
                                                    case 5:
                                                        if (T = m.sent, T) {
                                                            m.next = 8;
                                                            break
                                                        }
                                                        return m.abrupt("return", null);
                                                    case 8:
                                                        if (!T.hasOwnProperty("signatures")) {
                                                            m.next = 13;
                                                            break
                                                        }
                                                        return N = T.returnedFields, h = W.find(function(S) {
                                                            return S.hasOwnProperty("signProvider")
                                                        }), h && T.signatures.push(h.signProvider(ie.buf, ie.sign)), m.abrupt("return", T.signatures);
                                                    case 13:
                                                        return m.abrupt("return", T);
                                                    case 14:
                                                    case "end":
                                                        return m.stop()
                                                }
                                            }, V, this)
                                        }));
                                        return function() {
                                            return Z.apply(this, arguments)
                                        }
                                    }(), new Promise(function(Z, V) {
                                        A[U].apply(A, W).then(function(ie) {
                                            return ie.hasOwnProperty("fc") ? void Z(b(ie, {
                                                get: function(I, T) {
                                                    return T === "then" ? I[T] : function() {
                                                        for (var h = arguments.length, m = Array(h), S = 0; S < h; S++) m[S] = arguments[S];
                                                        return new Promise(function() {
                                                            var C = (0, n.default)(r.default.mark(function $(M, H) {
                                                                return r.default.wrap(function(j) {
                                                                    for (;;) switch (j.prev = j.next) {
                                                                        case 0:
                                                                            I[T].apply(I, m).then(function(ee) {
                                                                                M(Object.assign(ee, {
                                                                                    returnedFields: N
                                                                                }))
                                                                            }).catch(H);
                                                                        case 1:
                                                                        case "end":
                                                                            return j.stop()
                                                                    }
                                                                }, $, this)
                                                            }));
                                                            return function() {
                                                                return C.apply(this, arguments)
                                                            }
                                                        }())
                                                    }
                                                }
                                            })) : Z(Object.assign(ie, {
                                                returnedFields: N
                                            }))
                                        }).catch(V)
                                    })
                                }
                            }
                        })
                    }
                }
            }]), g
        }(u.Plugin);
    e.default = _, typeof window < "u" && (window.ScatterEOS = _)
})(dl);
var F_ = ca(dl);
Un.plugins(new F_);
let Lr, kn;
const pi = {
        blockchain: "eos",
        chainId: "aca376f206b8fc25a6ed44dbdc66547c36c6c33e3a119ffbeaef943642f0e906",
        host: "nodes.get-scatter.com",
        port: 443,
        protocol: "https"
    },
    H_ = async () => {
        if (Lr) return Lr;
        if (Lr = await Un.connect(location.host, {
                network: pi
            }), !Lr) throw new Error("Scatter connect error!");
        return Lr
    },
    La = async () => kn || (await H_(), kn = Un.scatter, await Un.login({
        accounts: [pi]
    }), kn),
    K_ = async (e = "eos") => (await W_()).find(r => r.blockchain === e),
    W_ = async () => {
        let e = await La();
        return e.identity.accounts || await e.getIdentity({
            accounts: [pi]
        }), e.identity.accounts
    },
    ev = async (e, t, r, n = "EOS") => {
        let i = await La(),
            a = await K_(),
            o = i.eos(pi, xd, {
                expireInSeconds: 60
            }),
            s = {
                authorization: [`${a.name}@${a.authority}`]
            };
        return await o.transfer(a.name, e, `${t.toFixed(4)} ${n}`, r, s)
    },
    tv = async (e, t = "") => {
        let r = await La(),
            n = r.identity.publicKey;
        return {
            signature: await r.getArbitrarySignature(n, e, t, !1),
            publicAddress: n
        }
    };
export {
    H_ as connect, K_ as getAccount, W_ as getAccounts, La as getScatter, tv as sign, ev as transaction
};
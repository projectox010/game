var pe = Object.defineProperty,
    ge = Object.defineProperties;
var be = Object.getOwnPropertyDescriptors;
var Q = Object.getOwnPropertySymbols;
var ye = Object.prototype.hasOwnProperty,
    ve = Object.prototype.propertyIsEnumerable;
var z = (s, o, e) => o in s ? pe(s, o, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : s[o] = e,
    Z = (s, o) => {
        for (var e in o || (o = {})) ye.call(o, e) && z(s, e, o[e]);
        if (Q)
            for (var e of Q(o)) ve.call(o, e) && z(s, e, o[e]);
        return s
    },
    ee = (s, o) => ge(s, be(o));
var S = (s, o, e) => (z(s, typeof o != "symbol" ? o + "" : o, e), e);
import {
    a5 as Y,
    a as n,
    dx as de,
    j as l,
    dy as we,
    dz as ke,
    o as k,
    du as R,
    r as p,
    aO as C,
    ee as B,
    ef as v,
    t as ue,
    q as _,
    l as $,
    dV as Ne,
    s as K,
    M as xe,
    eg as Se,
    aB as te,
    dj as Ce,
    F as he,
    dk as Be,
    dl as Re,
    an as P,
    y as G,
    z as W,
    b as T,
    u as X,
    G as Ie,
    dG as _e,
    ed as Ge,
    dY as Ae,
    dC as He,
    dZ as Me,
    dD as Te,
    dE as Oe,
    dp as O,
    bN as E,
    d_ as je,
    ba as $e,
    bb as D,
    bc as Le,
    d as ne,
    aH as se,
    J as Ve,
    a2 as Ee,
    bo as ze,
    D as Pe,
    n as We
} from "./index.28e31dff.js";
import {
    s as j
} from "./index.dd8128e8.js";
import {
    G as De
} from "./index.06a59a68.js";
import {
    i as oe
} from "./isNumber.3847f240.js";
const Fe = Y.memo(() => n(de, {
        children: l("div", {
            className: "item",
            children: [n("h2", {
                children: "What Is Hi-lo?"
            }), n("div", {
                className: "content",
                children: n("p", {
                    children: "Hi-lo is an online single player guessing game in which you guess the card point is higher (hi) or lower (lo) compared to the previous one."
                })
            }), n("h2", {
                children: "How To Play It?"
            }), l("div", {
                className: "content",
                children: [n("p", {
                    children: "The game is not timed."
                }), n("p", {
                    children: 'Click "Bet" to start betting and get the first card.'
                }), n("p", {
                    children: 'At this point you can guess the next card is "higher or same" or "lower or same" or \u201Cskip\u201D.'
                }), n("p", {
                    children: "If you guess right, you will get the corresponding payout. You can choose to claim the win and stop this round or continue guessing the next card."
                }), n("p", {
                    children: "The more cards you guess, the bigger payout you get."
                }), n("p", {
                    children: "There is no max payout, only bet and profit limits."
                }), n("p", {
                    children: "Ace is the lowest card, king is the highest card. The value order is K,Q,J,10,9,8,7,6,5,4,3,2,A."
                })]
            }), n("h2", {
                children: "What Is the Return Rate of Hi-lo?"
            }), n("div", {
                className: "content",
                children: n("p", {
                    children: "1% House Edge."
                })
            })]
        })
    })),
    qe = Y.memo(() => n(we, {
        game: le,
        children: l("div", {
            className: "item",
            children: [n("h2", {
                children: "What is the bankroll?"
            }), l("div", {
                className: "help-content",
                children: [n("p", {
                    children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                }), n("p", {
                    children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                }), n("p", {
                    children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                }), n("p", {
                    onClick: () => ke(le),
                    className: "cl-primary",
                    children: "Read more about bankrollers."
                })]
            }), n("h2", {
                children: "How does the pool of funds operate?"
            }), l("div", {
                className: "help-content",
                children: [n("p", {
                    children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                }), l("p", {
                    children: [n("b", {
                        className: "cl-primary",
                        children: "The house edge is 1%."
                    }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                }), n("p", {
                    children: "Payouts made to the winning players will be deducted from the bankroll."
                })]
            }), n("h2", {
                children: "How does leverage investment work?"
            }), l("div", {
                className: "help-content",
                children: [n("p", {
                    children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                }), n("p", {
                    children: "Hint: You can also use this feature as an Off-Site investment."
                }), n("p", {
                    children: "Let's make an example:"
                }), n("p", {
                    children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                })]
            }), n("h2", {
                children: "What is the bankroller dilution fee?"
            }), l("div", {
                className: "help-content",
                children: [n("p", {
                    children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                }), n("p", {
                    children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                }), n("p", {
                    children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                }), n("p", {
                    children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                })]
            })]
        })
    }));
var Ye = qe,
    Ke = "/assets/dice.8796ef26.png",
    Xe = "/assets/win.ae4b0d6d.mp3",
    Je = "/assets/deal.fa1626d6.mp3",
    Ue = "/assets/cashout.41167174.mp3",
    Qe = "/assets/bet.9fe42261.mp3",
    Ze = "/assets/skip.2122e51f.mp3",
    et = "/assets/giraffe.f1576e60.mp3",
    tt = "/assets/ape.42f4390a.mp3",
    nt = "/assets/hilo.4aa95fcb.mp3",
    st = "/assets/win.00419b3e.png",
    ot = "/assets/win_w.9daebc9a.png",
    it = "/assets/monkey.ca9b3010.json",
    at = "/assets/giraffe.592355d2.json",
    rt = "/assets/icon.388267af.png",
    lt = "/assets/banner1.f25bcb86.png",
    ct = "/assets/banner2.7f064425.png",
    dt = "/assets/hilo_bg.662c3c58.png",
    ut = "/assets/hilo_bg_w.fc21d75f.png";
const y = {
    icon: rt,
    banner1: lt,
    banner2: ct,
    bingo_sound: Xe,
    bet_sound: Qe,
    deal_sound: Je,
    cashout_sound: Ue,
    skip_sound: Ze,
    giraffe_sound: et,
    ape_sound: tt,
    hilo_sound: nt,
    dice: Ke,
    win: st,
    win_w: ot,
    monkey: it,
    giraffe: at,
    hilo_bg: dt,
    hilo_bg_w: ut
};
const b = {
    "icon-upsame": n("path", {
        d: "M29 22.929v5.571h-26v-5.571h26zM15.874 2.5l13.010 13.039-3.102 3.275-9.909-9.237-9.464 9.237-3.41-3.275 12.874-13.039z"
    }),
    "icon-downsame": n("path", {
        d: "M30 8.5v-6h-28v6h28zM15.864 30.5l14.011-14.042-3.34-3.527-10.671 9.948-10.192-9.948-3.672 3.527 13.864 14.042z"
    }),
    "icon-down": n("path", {
        d: "M15.923 6.883l14.541 14.573-3.467 3.66-11.075-10.324-10.577 10.324-3.811-3.66z"
    }),
    "icon-up": n("path", {
        d: "M15.843 24.405l13.744-13.774-3.277-3.459-10.467 9.758-9.997-9.758-3.602 3.459z"
    }),
    "icon-skip": n("path", {
        d: "M18.356 4.39l11.505 11.548-11.505 11.671-2.89-2.782 8.15-8.889-8.15-8.49 2.89-3.059zM5.029 4.39l11.505 11.548-11.505 11.671-2.89-2.782 8.15-8.889-8.15-8.49 2.89-3.059z"
    }),
    "icon-same": n("path", {
        d: "M29.222 18.833v5.667h-26.444v-5.667h26.444zM29.222 7.5v5.667h-26.444v-5.667h26.444z"
    }),
    "icon-hight_arrow": n("path", {
        d: "M16 3l10.833 12.588-4.815-0 0.001 13.413h-12.037l-0-13.413-4.814 0 10.833-12.588z"
    }),
    "icon-lower_arrow": n("path", {
        d: "M16 29.153l10.756-13.018-4.781 0 0.001-13.289h-11.951l-0 13.289-4.78-0 10.756 13.018z"
    })
};

function ht(s) {
    switch (s) {
        case 6:
            return b["icon-upsame"];
        case 5:
            return b["icon-downsame"];
        case 3:
            return b["icon-down"];
        case 2:
            return b["icon-up"];
        case 1:
            return b["icon-skip"];
        default:
            return b["icon-same"]
    }
}

function me(s) {
    const {
        guess: o,
        isLose: e = !1
    } = s;
    return n("svg", {
        viewBox: "0 0 32 32",
        className: `${mt} guess-ico guess-ico${o} ${e?"is-lose":""}`,
        children: ht(o)
    })
}
const mt = "gp8v90z";

function ft(s) {
    const o = R(),
        {
            odds: e,
            guess: t,
            cardId: i
        } = s,
        a = e === 0,
        r = t === 0,
        [h, d] = p.exports.useState(!1),
        c = p.exports.useRef(null),
        u = p.exports.useRef(null),
        f = p.exports.useRef(null);
    return p.exports.useEffect(() => {
        let I = () => {
            d(!1);
            let N = c.current;
            N && (C.to(N, .4, {
                x: -N.offsetLeft
            }), C.to(N, .2, {
                y: 50,
                opacity: 0,
                delay: .4
            })), r || (u.current && (u.current.style.display = "none"), f.current && (f.current.style.display = "none"))
        };
        return C.from(c.current, .5, {
            x: "100%"
        }), setTimeout(() => {
            d(!0)
        }, 200), r || (C.from(u.current, .3, {
            y: "100%",
            opacity: 0,
            delay: .3
        }), C.from(f.current, .3, {
            scale: 0,
            opacity: 0,
            delay: .3
        })), o.on("close", I), () => {
            o.off("close", I)
        }
    }, []), l("div", {
        className: `${gt} hilo-round ${s.className||""}`,
        ref: c,
        children: [n(B, {
            card: new v(i),
            active: h
        }), n("div", {
            className: `odds ${a?"is-lose":""}`,
            ref: u,
            children: n("div", {
                className: "val",
                children: r ? "Start Card" : (Math.round(e * 100) / 100).toFixed(2) + "\xD7"
            })
        }), !r && n("div", {
            className: "guess flex-center",
            ref: f,
            children: n(me, {
                guess: t,
                isLose: a
            })
        })]
    })
}
var pt = k(ft);
const gt = "rzbfcg3";

function bt(s) {
    const {
        rounds: o
    } = s, e = p.exports.useRef(null);
    return p.exports.useEffect(() => {
        let t = e.current;
        if (!t) return;
        const i = t.children.length;
        if (i < 4) return;
        const a = i * t.children[1].offsetLeft - t.offsetWidth;
        a <= 0 || C.to(t, .6, {
            scrollLeft: a
        })
    }), l("div", {
        className: $(vt, "hilo-rounds-wrap"),
        children: [o.length > 9 && n("div", {
            className: "round-len",
            children: o.length
        }), n("div", {
            className: "hilo-rounds",
            ref: e,
            children: o.map((t, i) => n(pt, {
                className: `round-item ${t.guess===1?"round-skip":""}`,
                odds: t.odds,
                guess: t.guess,
                cardId: t.card.cardId
            }, i))
        })]
    })
}
var yt = k(bt);
ue({
    cl1: [_("#31343c", .4), _("#dadde6", .6)]
});
const vt = "rijcc6u";

function wt() {
    const s = R(),
        o = p.exports.useRef(null),
        [e, t] = p.exports.useState({
            odds: 0,
            winAmount: 0,
            currencyName: "BTC"
        });
    return p.exports.useEffect(() => {
        let i;
        const a = r();

        function r() {
            C.set(o.current, {
                visibility: "hidden"
            });
            const d = C.timeline({
                paused: !0
            });
            return d.set(o.current, {
                visibility: "hidden"
            }, 0), d.set(o.current, {
                visibility: "visible"
            }, .01), d.from(o.current, .5, {
                scale: .5,
                opacity: 0,
                ease: Ne.easeOut
            }), d
        }

        function h(d) {
            const {
                odds: c,
                winAmount: u
            } = d;
            c !== 0 && (t({
                odds: c,
                currencyName: s.currencyName,
                winAmount: u - s.amount.toNumber()
            }), a.play(), i = setTimeout(() => a.reverse(), 2e3))
        }
        return s.on("end", h), () => {
            clearTimeout(i), s.off("end", h)
        }
    }, []), l("div", {
        className: $(Nt, "hilo-win"),
        ref: o,
        children: [n("img", {
            src: K.isDarken ? y.win : y.win_w,
            className: "bg"
        }), n("div", {
            className: "wrap",
            children: l("div", {
                className: "profit",
                children: [n(xe, {
                    icon: !0,
                    name: e.currencyName,
                    amount: e.winAmount,
                    showName: !1
                }), l("div", {
                    className: "payout",
                    children: [Math.floor(e.odds * 100) / 100, "\xD7"]
                })]
            })
        })]
    })
}
var kt = k(wt);
const Nt = "w11gsxxd";

function xt() {
    const s = R(),
        o = s.rounds[s.rounds.length - 1],
        [e, t] = p.exports.useState(!1),
        [i, a] = p.exports.useState({
            cardId: 179,
            active: !1
        }),
        r = p.exports.useRef(null),
        h = p.exports.useRef(null);
    return p.exports.useEffect(() => {
        o && o.odds === 0 ? e || t(!0) : e && t(!1)
    }, [o]), p.exports.useEffect(() => {
        function d() {
            let m = document.querySelector(".card1-ref");
            m && (m = m.parentElement);
            let x = C.timeline({
                paused: !0
            });
            return x.to(m, .5, {
                y: "-200%",
                x: "200%",
                rotate: -30
            }), x.call(() => {
                m && (m.style.display = "none", setTimeout(() => {
                    m.style.display = "block"
                }, 0))
            }), x.set(m, {
                y: 0,
                x: 0,
                rotate: 0
            }), x
        }

        function c(m) {
            var x, U;
            a(ee(Z({}, i), {
                cardId: m.card.cardId
            })), f(!0, m.card.cardId), m.odds > 0 && ([2, 5].includes(m.guess) ? (x = h.current) == null || x.play(0) : [3, 6].includes(m.guess) && ((U = r.current) == null || U.play(0)))
        }

        function u() {
            N.restart()
        }

        function f(m = !0, x) {
            setTimeout(() => {
                a({
                    cardId: x,
                    active: m
                })
            }, 30)
        }

        function I() {
            f(!1, i.cardId)
        }
        let N = d();
        s.on("next", u), s.on("betInit", c), s.on("nextOver", c), s.on("close", I);
        let H = s.rounds[s.rounds.length - 1];
        return H && c(H), () => {
            s.off("next", u), s.off("betInit", c), s.off("nextOver", c), s.off("close", I)
        }
    }, []), l("div", {
        className: $(Ct, "hilo-graph"),
        children: [l("div", {
            className: "hilo-graph-wrap",
            children: [l("div", {
                className: "top-box",
                children: [l("div", {
                    className: "higher lh-box",
                    children: [n(te, {
                        className: "lottie",
                        path: y.giraffe,
                        ref: r
                    }), n("div", {
                        className: "title",
                        children: "HIGHER OR SAME"
                    })]
                }), l("div", {
                    className: "cards-box",
                    children: [l("div", {
                        className: "cards",
                        children: [n(B, {
                            card: new v(i.cardId),
                            active: i.active,
                            className: `card1-ref ${e?"bust":""}`
                        }), n(B, {
                            card: new v(161)
                        }), n(B, {
                            card: new v(161)
                        }), n(B, {
                            card: new v(161)
                        }), n(B, {
                            card: new v(161)
                        }), n(B, {
                            card: new v(161)
                        })]
                    }), n("button", {
                        className: "skip-btn",
                        disabled: !s.isBetting || s.guessing || s.skipNums >= A.MAX_SKIPS,
                        onClick: s.doSkip,
                        children: n("svg", {
                            viewBox: "0 0 32 32",
                            children: b["icon-skip"]
                        })
                    }), n("div", {
                        className: "tips",
                        children: "KING IS HIGHEST, ACE IS LOWEST"
                    })]
                }), l("div", {
                    className: "lower lh-box",
                    children: [n(te, {
                        className: "lottie",
                        path: y.monkey,
                        ref: h
                    }), n("div", {
                        className: "title",
                        children: "LOWER OR SAME"
                    })]
                })]
            }), n(yt, {
                rounds: s.rounds
            })]
        }), n(kt, {})]
    })
}
var St = k(xt);
ue({
    cl1: [`solid ${Se(2)} #474b57`, "none"],
    cl2: ["#17181b", "#f5f6fa"],
    cl3: [_("#31343c", .4), "#dadde6"],
    cl4: ["#f5f6f7", "#31373d"],
    cl5: ["#99a4b0", "#dadde6"],
    cl6: [`0 1px 1px 0 ${_("#415185",.33)}`, `0 1px 1px 0 ${_("#c1c4ca",.33)}`],
    cl7: ["#474b57", "#9196a8"],
    cl8: ["#31343c", "#9196a8"],
    cl9: ["#b8c2cc", "#f5f6f7"],
    cl10: [_("#31343c", .3), _("#cccfd9", .4)],
    cl11: ["#17181b", "#f5f6fa"]
});
const Ct = "g1szjelh",
    Bt = k(() => {
        const s = R(),
            o = j.useSingleDetail();
        return n(Ce, {
            list: s.myBets,
            keyof: "betId",
            onDetail: o
        })
    }),
    Rt = () => l(he, {
        children: [n(Bt, {}), l(Be, {
            children: [n(St, {}), n(Re, {})]
        })]
    });
var It = k(Rt);

function F(s) {
    return s === 0 ? "" : `(${s.toFixed(4)}x)`
}

function q(s) {
    let o = Math.abs(s),
        e = "",
        t = "";
    if (o > 1e7 || o <= -1e7) e = o.toFixed();
    else {
        e = o.toFixed(9).substring(0, o >= 0 ? 10 : 11);
        const i = e.match(/(.*?)(0+)$/);
        i && (e = i[1], t = i[2])
    }
    return e + t
}

function _t() {
    const s = R(),
        o = s.rounds[s.rounds.length - 1],
        e = o ? o.odds : .99,
        t = s.jackpot[s.currencyName],
        i = t ? t.maxProfitAmount : 0;

    function a() {
        let c = 0;
        if (!s.isBetting) return 0;
        if (o) {
            let u = o.card.point;
            return c = s.getChance(u, !1), .99 / c
        } else return 0
    }

    function r() {
        let c = 0;
        if (!s.isBetting) return 0;
        if (o) {
            let u = o.card.point;
            return c = s.getChance(u, !0), .99 / c
        } else return 0
    }

    function h(c) {
        return G.min(G.max(s.amount.mul(c), 0), i)
    }

    function d(c) {
        let u = s.amount.mul(c).mul(e);
        return u.gt(i) ? new G(i).div(h(e - 1)) : G.max(u.sub(s.amount.mul(e)), 0)
    }
    return l("div", {
        className: $(Gt, s.isBetting && "betting"),
        children: [n(De.CoinInput, {
            checkIncrease: !0
        }), n(P, {
            label: `Total Profit ${F(e)}`,
            size: "small",
            children: l("div", {
                className: "input-control",
                children: [n("input", {
                    value: q(h(e - 1).toNumber()),
                    readOnly: !0
                }), n(W, {
                    name: s.currencyName,
                    className: "amount-ico"
                })]
            })
        }), n(P, {
            label: `Profit Higher ${F(a())}`,
            size: "small",
            children: l("div", {
                className: "input-control",
                children: [n("svg", {
                    className: "hi_lo hi",
                    viewBox: "0 0 32 32",
                    children: b["icon-hight_arrow"]
                }), n("input", {
                    value: q(d(a()).toNumber()),
                    readOnly: !0
                }), n(W, {
                    name: s.currencyName,
                    className: "amount-ico"
                })]
            })
        }), n(P, {
            label: `Profit Lower ${F(r())}`,
            size: "small",
            children: l("div", {
                className: "input-control",
                children: [n("svg", {
                    className: "hi_lo lo",
                    viewBox: "0 0 32 32",
                    children: b["icon-lower_arrow"]
                }), n("input", {
                    value: q(d(r()).toNumber()),
                    readOnly: !0
                }), n(W, {
                    name: s.currencyName,
                    className: "amount-ico"
                })]
            })
        })]
    })
}
var ie = k(_t);
const Gt = "hwv27xb";

function At(s) {
    switch (s) {
        case 5:
            return "Lower or Same";
        case 6:
            return "Higher or Same";
        case 3:
            return "Higher";
        case 2:
            return "Lower";
        default:
            return "Same"
    }
}

function Ht(s) {
    switch (s) {
        case 2:
        case 5:
            return b["icon-lower_arrow"];
        case 3:
        case 6:
            return b["icon-hight_arrow"];
        default:
            return b["icon-same"]
    }
}

function Mt(s) {
    const o = R(),
        {
            point: e,
            disabled: t,
            isLower: i = !1
        } = s,
        a = At(h()),
        r = Ht(h());

    function h() {
        return o.getGuess(e, i)
    }

    function d() {
        return `${(o.getChance(e,i)*100).toFixed(2)}%`
    }

    function c() {
        i ? o.doLower() : o.doHigher()
    }
    return l(T, {
        type: "gray",
        className: $(Tt, "hilo-guess-btn"),
        disabled: t,
        onClick: c,
        children: [n("svg", {
            className: i ? "lo" : "hi",
            viewBox: "0 0 32 32",
            children: r
        }), l("div", {
            className: "flex-1",
            children: [n("div", {
                className: `text ${i?"lo":"hi"}`,
                children: a
            }), e > 0 && n("div", {
                className: "chance",
                children: d()
            })]
        })]
    })
}
var V = k(Mt);
const Tt = "g1awqeuq";

function Ot() {
    const s = R(),
        o = s.rounds[s.rounds.length - 1],
        e = o ? o.card.point : 1,
        t = !o || !s.isBetting || s.guessing,
        i = K.isMobile,
        a = l("div", {
            className: re,
            children: [n(ae, {}), l("div", {
                className: "inline-btns",
                children: [n(V, {
                    point: e,
                    disabled: t
                }), n(V, {
                    point: e,
                    disabled: t,
                    isLower: !0
                })]
            }), l(T, {
                type: "gray",
                className: "skip-btn flex-btn",
                disabled: !s.isBetting || s.guessing || s.skipNums >= A.MAX_SKIPS,
                onClick: s.doSkip,
                children: [n("span", {
                    children: "Skip"
                }), n("svg", {
                    viewBox: "0 0 32 32",
                    className: "skip-ico",
                    children: b["icon-skip"]
                })]
            }), n(ie, {})]
        }),
        r = l("div", {
            className: re,
            children: [n(ie, {}), l("div", {
                className: "inline-btns",
                children: [n(V, {
                    point: e,
                    disabled: t
                }), n(V, {
                    point: e,
                    disabled: t,
                    isLower: !0
                })]
            }), l(T, {
                type: "gray",
                className: "skip-btn flex-btn",
                disabled: !s.isBetting || s.guessing || s.skipNums >= A.MAX_SKIPS,
                onClick: s.doSkip,
                children: [n("span", {
                    children: "Skip"
                }), n("svg", {
                    viewBox: "0 0 32 32",
                    className: "skip-ico",
                    children: b["icon-skip"]
                })]
            }), n(ae, {})]
        });
    return i ? a : r
}
const ae = k(function() {
    const o = X(),
        e = R(),
        t = e.rounds[e.rounds.length - 1],
        i = t ? t.odds : 0;
    let a = !1;
    async function r() {
        a || (a = !0, t && await e.closeCards(), e.handleBet().then(() => {
            a = !1
        }).catch(h => {
            Ie(h), e.join()
        }))
    }
    return e.isBetting ? n(T, {
        className: "bet-button cashout-btn",
        type: "conic",
        size: "big",
        disabled: i <= 1 || e.guessing,
        onClick: e.cashout,
        children: "Cashout"
    }) : n(T, {
        className: "bet-button",
        size: "big",
        type: "conic",
        onClick: r,
        children: o("common.bet")
    })
});
var jt = k(Ot);
const re = "ml7v9jm";
const $t = Y.memo(() => {
        const s = X(),
            o = [{
                title: s("common.game_intro"),
                node: n(Fe, {})
            }, {
                title: s("common.fairness"),
                node: "/hilo_help/fairness"
            }, {
                title: s("common.bankroll"),
                node: n(Ye, {})
            }];
        return n(_e, {
            manualControl: n(jt, {}),
            className: Lt,
            gameView: n(It, {}),
            tabs: [{
                label: s("common.all_bet"),
                value: j.AllBet
            }, {
                label: s("common.my_bet"),
                value: j.MyBet
            }],
            actions: [n(Ge, {}), n(Ae, {}), n(He, {}), n(Me, {}), n(Te, {}), n(Oe, {
                list: o
            })]
        })
    }),
    Lt = "m1noradu",
    w = O.Reader,
    L = O.Writer,
    Vt = O.util,
    g = O.roots.gameHilo || (O.roots.gameHilo = {});
g.BetValue = (() => {
    function s(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return s.encode = function(e, t) {
        return t || (t = L.create()), t
    }, s.decode = function(e, t) {
        e instanceof w || (e = w.create(e));
        let i = t === void 0 ? e.len : e.pos + t,
            a = new g.BetValue;
        for (; e.pos < i;) {
            let r = e.uint32();
            switch (r >>> 3) {
                default: e.skipType(r & 7);
                break
            }
        }
        return a
    }, s
})();
g.GameValue = (() => {
    function s(o) {
        if (this.rounds = [], o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return s.prototype.rounds = Vt.emptyArray, s.encode = function(e, t) {
        if (t || (t = L.create()), e.rounds != null && e.rounds.length)
            for (let i = 0; i < e.rounds.length; ++i) g.Round.encode(e.rounds[i], t.uint32(18).fork()).ldelim();
        return t
    }, s.decode = function(e, t) {
        e instanceof w || (e = w.create(e));
        let i = t === void 0 ? e.len : e.pos + t,
            a = new g.GameValue;
        for (; e.pos < i;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 2:
                    a.rounds && a.rounds.length || (a.rounds = []), a.rounds.push(g.Round.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return a
    }, s
})();
g.Round = (() => {
    function s(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return s.prototype.round = 0, s.prototype.card = 0, s.prototype.guess = 0, s.prototype.odds = 0, s.encode = function(e, t) {
        return t || (t = L.create()), e.round != null && Object.hasOwnProperty.call(e, "round") && t.uint32(8).sint32(e.round), e.card != null && Object.hasOwnProperty.call(e, "card") && t.uint32(16).sint32(e.card), e.guess != null && Object.hasOwnProperty.call(e, "guess") && t.uint32(24).sint32(e.guess), e.odds != null && Object.hasOwnProperty.call(e, "odds") && t.uint32(33).double(e.odds), t
    }, s.decode = function(e, t) {
        e instanceof w || (e = w.create(e));
        let i = t === void 0 ? e.len : e.pos + t,
            a = new g.Round;
        for (; e.pos < i;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    a.round = e.sint32();
                    break;
                case 2:
                    a.card = e.sint32();
                    break;
                case 3:
                    a.guess = e.sint32();
                    break;
                case 4:
                    a.odds = e.double();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return a
    }, s
})();
g.Next = (() => {
    function s(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return s.prototype.guess = 0, s.encode = function(e, t) {
        return t || (t = L.create()), e.guess != null && Object.hasOwnProperty.call(e, "guess") && t.uint32(8).sint32(e.guess), t
    }, s.decode = function(e, t) {
        e instanceof w || (e = w.create(e));
        let i = t === void 0 ? e.len : e.pos + t,
            a = new g.Next;
        for (; e.pos < i;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    a.guess = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return a
    }, s
})();
g.CashoutValue = (() => {
    function s(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return s.prototype.frontgroundId = 0, s.encode = function(e, t) {
        return t || (t = L.create()), e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && t.uint32(120).sint32(e.frontgroundId), t
    }, s.decode = function(e, t) {
        e instanceof w || (e = w.create(e));
        let i = t === void 0 ? e.len : e.pos + t,
            a = new g.CashoutValue;
        for (; e.pos < i;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 15:
                    a.frontgroundId = e.sint32();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return a
    }, s
})();
const Et = E.decode(g.Round),
    zt = E.encode(g.CashoutValue),
    J = class extends je {
        constructor() {
            super({
                name: "Hilo",
                namespace: "/g/hilo",
                sounds: {
                    bet: y.bet_sound,
                    bingo: y.bingo_sound,
                    cashout: y.cashout_sound,
                    deal: y.deal_sound,
                    skip: y.skip_sound,
                    giraffe: y.giraffe_sound,
                    ape: y.ape_sound,
                    hilo: {
                        src: y.hilo_sound,
                        loop: !0,
                        isBackground: !0
                    }
                },
                fairLink: "/hilo_help/fairness",
                validateLink: "/hilo_help/validate"
            }, $t);
            S(this, "theme", {
                text: "#02a4a5",
                main: "#067778",
                light: "#2a9192",
                dark: "#0b636a",
                dark2: "#0b636a"
            });
            S(this, "rounds", []);
            S(this, "odds", 0);
            S(this, "guessing", !1);
            S(this, "nextTime", 500);
            S(this, "closeTime", 500);
            S(this, "gameValueDecoder", E.decode(g.GameValue));
            $e(this, {
                rounds: D,
                odds: D,
                guessing: D,
                skipNums: Le
            }), this.setMaxListeners(100), this.doHigher = this.doHigher.bind(this), this.doLower = this.doLower.bind(this), this.doSkip = this.doSkip.bind(this), this.cashout = this.cashout.bind(this), this.socket.on("connect", () => this.join()), ne.waitLogin().then(() => this.join()), this.addHotkey("q", this.doHigher, "Higher or Same"), this.addHotkey("w", this.doLower, "Lower or Same"), this.addHotkey("e", this.doSkip, "Skip Current Card"), this.addHotkey("r", this.cashout, "Cashout"), K.isMobile && (this.settings.hotkeyEnable = !1)
        }
        get skipNums() {
            return this.rounds.filter(e => e.guess === 1).length
        }
        betValue() {
            return new Uint8Array
        }
        canGuess() {
            return this.isBetting && !this.guessing
        }
        getLastRound() {
            return this.rounds[this.rounds.length - 1]
        }
        getGuess(e, t) {
            return e == 13 ? t ? 2 : 4 : e == 1 ? t ? 4 : 3 : t ? 5 : 6
        }
        addRound(e) {
            let {
                round: t,
                card: i,
                guess: a,
                odds: r
            } = e, h = {
                round: t,
                card: new v(i),
                guess: a,
                odds: r
            };
            return this.rounds.push(h), h
        }
        async join() {
            if (!this.isActived || !ne.login) return;
            let e = await this.socketRequest("join").then(this.betResultDecoder),
                {
                    rounds: t
                } = this.gameValueDecoder(e.gameValue);
            if (this.isBetting = !1, t.length > 0) {
                let i = this.getBetlog(e);
                this.currencyName = i.currencyName, setTimeout(() => this.amount = new G(i.betAmount), 100);
                try {
                    this.setBetStatus(!0);
                    const a = new G(i.betAmount),
                        {
                            odds: r
                        } = await this.bet(a, i);
                    this.emit("betEnd", {
                        amount: a,
                        odds: r,
                        currencyName: i.currencyName
                    })
                } catch (a) {} finally {
                    this.setBetStatus(!1)
                }
            } else this.rounds = [], this.closeCards()
        }
        async next(e) {
            this.guessing = !0, e == 1 && this.sounds.playSound("skip");
            try {
                let t = Date.now(),
                    i = await this.socketRequest("next", E.encode(g.Next)({
                        guess: e
                    })).then(Et),
                    a = Math.max(this.nextTime - (Date.now() - t), 0);
                if (await se(a), i.round !== this.rounds.length) throw new Error("Round Error!");
                this.emit("next");
                let r = this.addRound(i);
                this.sounds.playSound("deal"), this.emit("nextOver", r), i.odds == 0 ? this.emit("end", {
                    odds: 0,
                    winAmount: 0
                }) : e !== 1 && (setTimeout(() => this.sounds.playSound("bingo"), 300), e == 3 || e == 6 ? setTimeout(() => this.sounds.playSound("giraffe"), 600) : setTimeout(() => this.sounds.playSound("ape"), 600)), this.guessing = !1
            } catch (t) {
                this.guessing = !1, this.join()
            }
        }
        doHigher() {
            if (!this.canGuess()) return;
            let e = this.getLastRound();
            if (!!e) return this.next(this.getGuess(e.card.point, !1))
        }
        doLower() {
            if (!this.canGuess()) return;
            let e = this.getLastRound();
            if (!!e) return this.next(this.getGuess(e.card.point, !0))
        }
        async doSkip() {
            if (!!this.canGuess() && !(this.skipNums >= J.MAX_SKIPS)) return this.next(1)
        }
        async cashout() {
            if (!this.canGuess()) return;
            let e = this.getLastRound();
            if (!(!e || e.odds < 1)) {
                this.rounds[this.rounds.length - 1], this.guessing = !0;
                try {
                    let {
                        odds: t,
                        winAmount: i,
                        currencyName: a
                    } = await this.socketRequest("cashout", zt({
                        frontgroundId: this.txId
                    })).then(this.betResultDecoder);
                    t /= this.oddsScale;
                    const r = Ve.bn2amount(i, a);
                    r > 0 ? (this.amount.mul(e.odds).eq(r) || this.join(), this.sounds.playSound("cashout")) : this.closeCards(), this.emit("end", {
                        odds: t,
                        winAmount: r
                    })
                } finally {
                    this.guessing = !1
                }
            }
        }
        getChance(e, t) {
            switch (this.getGuess(e, t)) {
                case 3:
                case 2:
                    return .9231;
                case 6:
                    return Math.round(1e4 * (14 - e) / 13) / 1e4;
                case 5:
                    return Math.round(1e4 * e / 13) / 1e4;
                default:
                    return .0769
            }
        }
        async closeCards() {
            this.emit("close"), await se(this.closeTime)
        }
        async bet(e = this.amount, t = 0) {
            if (this.rounds = [], oe(t)) {
                this.sounds.playSound("bet"), this.guessing = !0;
                try {
                    let f = this.betRequest(e, this.betValue());
                    this.onBetRequest && (f = this.onBetRequest(f)), t = await f
                } finally {
                    oe(t) && this.join(), this.guessing = !1
                }
            }
            let {
                rounds: i
            } = t.gameValue, a = i.map(f => this.addRound(f)), r = a[a.length - 1];
            r && this.emit("betInit", r);
            let {
                odds: h,
                winAmount: d
            } = await new Promise((f, I) => {
                const N = m => {
                        this.removeListener("deactivate", H), f(m)
                    },
                    H = () => {
                        this.removeListener("end", N), I()
                    };
                this.once("end", N), this.once("deactivate", H)
            });
            t.odds = h, t.winAmount = d, t.profitAmount = d - t.betAmount, delete t.gameValue;
            let c = t.betId;
            return this.myBets.find(f => f.betId === c) || (this.addMyBet(t), this.emit("betEnd", {
                amount: new G(t.betAmount),
                odds: t.odds,
                currencyName: t.currencyName
            })), t
        }
    };
let A = J;
S(A, "MAX_SKIPS", 50);
const fe = new A;
var le = fe;
window.hog = fe;

function Zt({
    bodyLock: s
}) {
    return n(de, {
        bodyLock: s,
        children: l("div", {
            className: "item",
            children: [n("h2", {
                children: "How Are the Results Calculated? "
            }), n("div", {
                className: "content",
                children: n("p", {
                    children: "We calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce:round, serverSeed)."
                })
            })]
        })
    })
}
const M = [161, 180, 199, 218, 162, 205, 181, 200, 219, 163, 182, 220, 201, 177, 196, 215, 170, 178, 221, 197, 216, 171, 179, 198, 172, 217, 193, 212, 167, 186, 194, 173, 213, 168, 187, 195, 214, 188, 169, 209, 164, 183, 202, 210, 189, 165, 184, 203, 211, 166, 204, 185];

function Pt(s, o = 2) {
    let e = [];
    for (let t = 0; t < s.length; t += o) {
        let i = s[t] + s[t + 1],
            a = parseInt(i, 16);
        e.push(a)
    }
    return e
}

function Wt(s, o, e = 4) {
    let t = Pt(s);
    return o.map((i, a) => {
        let h = t.slice(a * e, (a + 1) * e).map((d, c) => d / Math.pow(256, c + 1)).reduce((d, c) => d + c, 0);
        return Math.floor(h * i)
    })
}

function ce(s) {
    const o = new v(s);
    return o.suitStr + o.pointStr
}

function en() {
    const s = X(),
        o = Ee(),
        e = ze(o),
        t = e[0] || "",
        i = e[1] || "",
        a = e[2] || "",
        r = [52];
    return n(Pe, {
        title: s("common.fairness"),
        children: n(j.GameValidate, {
            serverSeed: t,
            clientSeed: i,
            nonce: parseInt(a),
            hasRound: !0,
            modulusList: r,
            children: h => {
                const d = Wt(h, r)[0];
                return l(he, {
                    children: [n("h2", {
                        children: "Final Result"
                    }), l("div", {
                        className: Dt,
                        children: [l("div", {
                            children: [n("span", {
                                className: "card",
                                children: ce(M[d])
                            }), ",", d, ",", M[d]]
                        }), n("hr", {}), n("div", {
                            className: "table-wrap",
                            children: n("table", {
                                children: l("tbody", {
                                    children: [n("tr", {
                                        children: M.map((c, u) => n("td", {
                                            children: u
                                        }, u))
                                    }), n("tr", {
                                        children: M.map((c, u) => n("td", {
                                            children: n("span", {
                                                className: "card",
                                                children: ce(c)
                                            })
                                        }, u))
                                    }), n("tr", {
                                        children: M.map((c, u) => n("td", {
                                            children: c
                                        }, u))
                                    })]
                                })
                            })
                        })]
                    })]
                })
            }
        })
    })
}
const Dt = "hwyq9ab";
const Ft = (s, o, e) => {
        We(`/hilo_help/validate/${s}/${o}/${e}`)
    },
    qt = j.withSingleDetail({
        onValidate: Ft,
        result: ({
            betLog: s
        }) => {
            const {
                rounds: o
            } = s.gv;
            return n("div", {
                className: Yt,
                children: n("div", {
                    className: "list-wrap",
                    children: o.map((e, t) => l("div", {
                        className: "hilo-round",
                        children: [n(B, {
                            card: new v(e.card),
                            active: !0
                        }), n("div", {
                            className: e.odds === 0 ? "odds is-lose" : "odds",
                            children: n("div", {
                                className: "val",
                                children: e.guess === 0 ? "Start Card" : (Math.round(e.odds * 100) / 100).toFixed(2) + "\xD7"
                            })
                        }), e.guess !== 0 && n("div", {
                            className: "guess flex-center",
                            children: n(me, {
                                guess: e.guess,
                                isLose: e.odds === 0
                            })
                        })]
                    }, t))
                })
            })
        }
    });
var tn = qt;
const Yt = "rhchxrz";
export {
    Ye as Bankroll, tn as Detail, Zt as Fairness, le as Game, en as Validate
};
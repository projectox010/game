! function() {
    var e = document.createElement("style");
    e.innerHTML = ".lok4cf0{--12vcisu:linear-gradient(to bottom,#e56237 -20%,#bc4f2e 20%,#e9eaf2);position:fixed;left:1rem;z-index:110;bottom:.875rem;-webkit-transition:width .5s,height .5s;transition:width .5s,height .5s;touch-action:pan-x,pan-y}.darken .lok4cf0{--12vcisu:linear-gradient(to bottom,#e56237 -20%,#31343c)}.lok4cf0 .dragpop-area{width:100%;height:100%}.lok4cf0.small{width:13.625rem;height:12.5rem}.lok4cf0.common{width:25.875rem;height:23.375rem}.lok4cf0 .deposit-main{width:100%;height:100%;border-radius:1.25rem;box-shadow:0 6px 16px rgba(0,0,0,.2);background-image:var(--12vcisu);position:relative}.lok4cf0 .deposit-main .close-icon svg{fill:#f5f6f7}.lok4cf0 .deposit-main .main{padding-top:1rem;width:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;color:#f5f6f7;height:100%}.lok4cf0 .deposit-main .main p{margin:0}.lok4cf0 .deposit-main .main .title{font-size:1.125rem;line-height:1.5rem;font-weight:700}.lok4cf0 .deposit-main .main .big-title{margin-top:.875rem;font-size:2.25rem;line-height:2.75rem;font-weight:700}.lok4cf0 .deposit-main .main .big-title span{color:#fbcf12}.lok4cf0 .deposit-main .main .end-time{margin-top:.875rem;line-height:1.125rem}.lok4cf0 .deposit-main .main>button{width:8.875rem;height:2.75rem;margin-top:1.625rem;color:#222329;background-image:conic-gradient(from 1turn,#e2b40b,#f6c722)}.lok4cf0.small .deposit-main .close-icon{display:none}.lok4cf0.small .deposit-main .main{padding-top:0;cursor:pointer}.lok4cf0.small .deposit-main .main .title{font-size:.75rem;line-height:1rem;padding:0 1.5rem;text-align:center}.lok4cf0.small .deposit-main .main .big-title{font-size:1.5rem;line-height:1.25rem;margin-top:.5rem}@media screen and (max-width:621px){.lok4cf0.small{width:6.25rem;height:5rem}.lok4cf0.small .deposit-main .main .title{display:none}.lok4cf0.small .deposit-main .main .big-title{font-size:.875rem;line-height:1.125rem}}.bjhs3pt{--1mbyr44:rgba(0,0,0,.4);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.darken .bjhs3pt{--1mbyr44:rgba(35,22,16,.45)}.bjhs3pt .time-area{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;background:var(--1mbyr44);color:#fff}.bjhs3pt.big{margin-top:.5rem}.bjhs3pt.big .time-area{width:5.1875rem;height:6.0625rem;border-radius:.675rem}.bjhs3pt.big .time-area span{font-size:.75rem;opacity:.6;line-height:1.125rem;margin-top:.625rem}.bjhs3pt.big .time-area p{font-weight:700;font-size:2.25rem;line-height:1.15;margin-top:.25rem}.bjhs3pt.big .time-split{font-size:1.5rem;margin:0 .625rem}.bjhs3pt.small{margin-top:1.25rem}.bjhs3pt.small .time-area{width:3.875rem;height:4.5rem;border-radius:.5rem}.bjhs3pt.small .time-area span{font-size:.75rem;-webkit-transform:scale(.95);-ms-transform:scale(.95);transform:scale(.95);opacity:.6}.bjhs3pt.small .time-area p{font-size:1.625rem;font-weight:700}.bjhs3pt.small .time-split{font-size:1.125rem;margin:0 .375rem}@media screen and (max-width:621px){.bjhs3pt.small{margin-top:.5rem}.bjhs3pt.small .time-area{width:1.875rem;height:1.875rem;border-radius:.5rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.bjhs3pt.small .time-area span{display:none}.bjhs3pt.small .time-area p{font-size:.875rem}.bjhs3pt.small .time-split{font-size:.875rem;margin:0 .1875rem}}.sz8k9o{--12o3opf:#e7e7e4;width:26.25rem;height:23.75rem;border-radius:20px;background:url(/assets/limit-bg.ed24b18a.png) no-repeat center;background-size:110% auto;position:relative;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;color:var(--12o3opf)}.darken .sz8k9o{--12o3opf:#f5f6f7}.sz8k9o .close-icon svg{fill:#f5f6f7}.sz8k9o p{margin:0}.sz8k9o .title{line-height:1.5rem;font-weight:700;font-size:1.25rem}.sz8k9o .title-second{color:#fbcf12;font-size:2rem;margin-top:.5rem;font-weight:700}.sz8k9o .big{margin-top:2.25rem}.sz8k9o .more{color:#fbcf12;-webkit-text-decoration:underline;text-decoration:underline;font-size:1rem;margin-top:2.8125rem;cursor:pointer}\n", document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js", "./DepositBonus-legacy.b5f6d3ee.js"], (function(e) {
        "use strict";
        var i, t, n, r, a, o, s, l, m, c, d, p, f, b, g, h, k, x, u, w, y, j, v;
        return {
            setters: [function(e) {
                i = e.o, t = e.u, n = e.e, r = e.f, a = e.r, o = e.c, s = e.g, l = e.h, m = e.i, c = e.a, d = e.k, p = e.l, f = e.T, b = e.j, g = e.C, h = e.I, k = e.b, x = e.m, u = e.t, w = e.q, y = e.p, j = e.v
            }, function(e) {
                v = e.D
            }],
            execute: function() {
                e("s", (function() {
                    y.push(c(E, {}))
                }));
                const z = i((function() {
                        const e = t(),
                            i = n(),
                            x = r(3e4),
                            u = window.localStorage.getItem("CLOSE_LIMIT") || "NO",
                            [w, y] = a.exports.useState("YES" === u),
                            [j, v] = a.exports.useState(!1),
                            z = a.exports.useRef(0),
                            I = o.registerTime + 12e5;
                        const [E, S] = s((() => ({
                            config: l.gentle,
                            transform: "translate3d(0px, 0px, 0px)"
                        })));
                        a.exports.useEffect((() => {
                            S.start({
                                transform: "translate3d(0px, 0px, 0px)"
                            })
                        }), [0, 0]);
                        const C = m((({
                            lastOffset: [e, i],
                            movement: [t, n]
                        }) => {
                            S.start({
                                transform: `translate3d(${e+t+0}px, ${i+n+0}px, 0px)`,
                                immediate: !0
                            })
                        }));
                        if (!o.isInited || 4 === o.rechargeValidNum) return null;
                        if (!(o.firstExpiredTime > 0) || j || !x) return null;
                        const O = o.bonusItems ? o.bonusItems[0].bonusRatio : 1;
                        return c(d.div, {
                            className: p(N, w ? "small" : "common"),
                            style: E,
                            children: c("div", { ...C(),
                                className: "dragpop-area",
                                children: c(f, {
                                    from: {
                                        y: "100%",
                                        opacity: 0
                                    },
                                    enter: {
                                        y: "0%",
                                        opacity: 1
                                    },
                                    children: b(d.div, {
                                        className: "deposit-main",
                                        children: [c(g, {
                                            onClick: () => {
                                                y(!w), window.localStorage.setItem("CLOSE_LIMIT", "YES")
                                            }
                                        }), b("div", {
                                            className: "main",
                                            onMouseDown: () => {
                                                z.current = (new Date).getTime()
                                            },
                                            onMouseUp: () => {
                                                (new Date).getTime() - z.current < 200 && i("/wallet")
                                            },
                                            children: [c("p", {
                                                className: "title",
                                                children: e(w ? "page.bcd.title.long" : "page.bcd.title.short")
                                            }), c("p", {
                                                className: "big-title",
                                                children: c(h, {
                                                    k: "page.bcd.title.big",
                                                    children: b("span", {
                                                        children: [Math.floor(100 * O), "%"]
                                                    })
                                                })
                                            }), !w && c("p", {
                                                className: "end-time",
                                                children: e("page.bcd.end_time")
                                            }), c(T, {
                                                endTime: I,
                                                close: w,
                                                changeOver: v
                                            }), !w && c(k, {
                                                type: "conic",
                                                onClick: () => i("/wallet"),
                                                children: e("page.bcd.deposit_now")
                                            })]
                                        })]
                                    })
                                })
                            })
                        })
                    })),
                    N = "lok4cf0",
                    T = function({
                        close: e,
                        endTime: i,
                        changeOver: n
                    }) {
                        const r = t();
                        return c(x, {
                            endTime: i,
                            onEnd: () => {
                                n(!0), o.init(!0)
                            },
                            children: ({
                                minutes: i,
                                seconds: t
                            }) => b("div", {
                                className: p(I, e ? "small" : "big"),
                                children: [b("div", {
                                    className: "time-area",
                                    children: [c("span", {
                                        children: r("page.bcd.minute")
                                    }), c("p", {
                                        children: i > 9 ? i : "0" + i
                                    })]
                                }), c("div", {
                                    className: "time-split",
                                    children: ":"
                                }), b("div", {
                                    className: "time-area",
                                    children: [c("span", {
                                        children: r("page.bcd.second")
                                    }), c("p", {
                                        children: t > 9 ? t : "0" + t
                                    })]
                                })]
                            })
                        })
                    };
                u({
                    cl1: [w("#231610", .45), w("#000000", .4)]
                });
                const I = "bjhs3pt";
                e("L", z);
                const E = i((function() {
                        const e = t(),
                            i = n(),
                            r = o.firstExpiredTime,
                            a = o.bonusItems,
                            s = a ? a[0].bonusRatio : 1;
                        return r > 0 ? b("div", {
                            className: S,
                            children: [c(g, {
                                onClick: () => y.close()
                            }), c("p", {
                                className: "title",
                                children: c(h, {
                                    k: "wallet.bcd.morepop.title",
                                    children: c("span", {
                                        children: a.length > 0 ? a[0].rechargeUsd : "60"
                                    })
                                })
                            }), b("p", {
                                className: "title-second",
                                children: [b("span", {
                                    children: [Number(100 * s), "%"]
                                }), c("span", {
                                    children: e("page.vip.dialog.table.head5")
                                })]
                            }), c(T, {
                                close: !1,
                                endTime: o.registerTime + 12e5,
                                changeOver: () => y.close()
                            }), c("p", {
                                className: "more",
                                onClick: () => {
                                    y.close(), j.close(), setTimeout((() => {
                                        i("/promotion")
                                    }), 200)
                                },
                                children: e("wallet.bcd.more")
                            })]
                        }) : c(v, {})
                    })),
                    S = "sz8k9o"
            }
        }
    }))
}();
var zt = Object.defineProperty;
var _t = (i, o, e) => o in i ? zt(i, o, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : i[o] = e;
var r = (i, o, e) => (_t(i, typeof o != "symbol" ? o + "" : o, e), e);
import {
    aI as vt,
    a5 as Ze,
    a as h,
    dx as Xe,
    j as A,
    aO as w,
    dR as K,
    d as Be,
    dS as kt,
    y as H,
    dT as At,
    dU as We,
    dV as ye,
    J as ue,
    dW as Ct,
    dp as de,
    bN as Re,
    o as qe,
    r as he,
    a$ as Bt,
    dX as It,
    u as Ke,
    du as Ye,
    dk as Tt,
    l as Qe,
    s as Ie,
    b as Pt,
    dG as Lt,
    dY as Et,
    dC as Ot,
    dD as Rt,
    dZ as Mt,
    dE as Dt,
    d_ as Gt,
    d$ as Nt,
    ba as $t,
    bb as Z,
    dr as He,
    G as Wt,
    e0 as Fe
} from "./index.28e31dff.js";
import {
    s as Te
} from "./index.dd8128e8.js";
import {
    G as Ve
} from "./index.06a59a68.js";
import {
    B as Ht,
    b as et,
    C as v,
    c as m,
    G as oe,
    f as Ft,
    A as ne,
    T as tt,
    N as rt,
    d as je,
    e as Vt,
    E as jt,
    g as Ue,
    h as it,
    i as st,
    j as Ut,
    s as Jt
} from "./usePixiGsap.bf451f35.js";
import {
    b as Zt,
    v as Xt
} from "./_baseRandom.b8a5c2ab.js";

function at(i) {
    var o = i.length;
    return o ? i[Zt(0, o - 1)] : void 0
}

function qt(i) {
    return at(Xt(i))
}

function Kt(i) {
    var o = vt(i) ? at : qt;
    return o(i)
}
const Yt = Ze.memo(({
    game: i
}) => h(Xe, {
    children: A("div", {
        className: "item",
        children: [h("h2", {
            children: "What Game Is This?"
        }), h("div", {
            className: "help-content",
            children: i.gameInfo.detail.split(`
`).map((o, e) => h("p", {
                children: `${o}`
            }, e.toString()))
        }), h("h2", {
            children: "How To Play It?"
        }), A("div", {
            className: "help-content",
            children: [h("p", {
                children: "<BET>"
            }), h("p", {
                children: "Choose the amount and the coin you wish to wager with. That amount will be deducted from your balance and the game will begin. Good luck!"
            }), h("p", {
                children: "<MAX/MIN>"
            }), h("p", {
                children: "When you click or tap on maximum/minimum bet, the amount filled in will be the amount deducted from your balance when you push the BET button. Be careful! No refunds will be given for Max bet accidents. NO EXCEPTIONS. Sorry."
            }), h("p", {
                children: "<AUTO START>"
            }), h("p", {
                children: "By setting the <NUMBER OF BETS>, the selected number is displayed. When you click the 'BET' button the reel starts to spin and the amount selected will be deducted from your balance. Autostart can be stopped by pressing the Bet button again. Be careful! Do not leave your game unattended. No refunds will be issued for Autostart mishaps. Please be responsible. Double check your amounts before you click 'BET'."
            }), h("p", {
                children: "<PAYTABLE ON TOWER>"
            }), h("p", {
                children: "Winnings are paid out according to the paytable shown on the towers. All win lines are individually calculated. Only the highest win per line counts. Wins on different lines are added together to give the final result."
            }), h("p", {
                children: "<SOUND>"
            }), h("p", {
                children: "By clicking the volume button the sound is turned off or on."
            }), h("p", {
                children: "<ACORN>"
            }), h("p", {
                children: "By clicking the acorn button the hash id is shown."
            })]
        })]
    })
}));
var ot = {
    exports: {}
};
(function(i) {
    (function() {
        function o(d, g) {
            document.addEventListener ? d.addEventListener("scroll", g, !1) : d.attachEvent("scroll", g)
        }

        function e(d) {
            document.body ? d() : document.addEventListener ? document.addEventListener("DOMContentLoaded", function g() {
                document.removeEventListener("DOMContentLoaded", g), d()
            }) : document.attachEvent("onreadystatechange", function g() {
                (document.readyState == "interactive" || document.readyState == "complete") && (document.detachEvent("onreadystatechange", g), d())
            })
        }

        function t(d) {
            this.a = document.createElement("div"), this.a.setAttribute("aria-hidden", "true"), this.a.appendChild(document.createTextNode(d)), this.b = document.createElement("span"), this.c = document.createElement("span"), this.h = document.createElement("span"), this.f = document.createElement("span"), this.g = -1, this.b.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.c.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.f.style.cssText = "max-width:none;display:inline-block;position:absolute;height:100%;width:100%;overflow:scroll;font-size:16px;", this.h.style.cssText = "display:inline-block;width:200%;height:200%;font-size:16px;max-width:none;", this.b.appendChild(this.h), this.c.appendChild(this.f), this.a.appendChild(this.b), this.a.appendChild(this.c)
        }

        function s(d, g) {
            d.a.style.cssText = "max-width:none;min-width:20px;min-height:20px;display:inline-block;overflow:hidden;position:absolute;width:auto;margin:0;padding:0;top:-999px;white-space:nowrap;font-synthesis:none;font:" + g + ";"
        }

        function a(d) {
            var g = d.a.offsetWidth,
                S = g + 100;
            return d.f.style.width = S + "px", d.c.scrollLeft = S, d.b.scrollLeft = d.b.scrollWidth + 100, d.g !== g ? (d.g = g, !0) : !1
        }

        function n(d, g) {
            function S() {
                var G = Q;
                a(G) && G.a.parentNode && g(G.g)
            }
            var Q = d;
            o(d.b, S), o(d.c, S), a(d)
        }

        function p(d, g) {
            var S = g || {};
            this.family = d, this.style = S.style || "normal", this.weight = S.weight || "normal", this.stretch = S.stretch || "normal"
        }
        var y = null,
            k = null,
            C = null,
            V = null;

        function Y() {
            if (k === null)
                if (me() && /Apple/.test(window.navigator.vendor)) {
                    var d = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))(?:\.([0-9]+))/.exec(window.navigator.userAgent);
                    k = !!d && 603 > parseInt(d[1], 10)
                } else k = !1;
            return k
        }

        function me() {
            return V === null && (V = !!document.fonts), V
        }

        function ft() {
            if (C === null) {
                var d = document.createElement("div");
                try {
                    d.style.font = "condensed 100px sans-serif"
                } catch (g) {}
                C = d.style.font !== ""
            }
            return C
        }

        function j(d, g) {
            return [d.style, d.weight, ft() ? d.stretch : "", "100px", g].join(" ")
        }
        p.prototype.load = function(d, g) {
            var S = this,
                Q = d || "BESbswy",
                G = 0,
                ee = g || 3e3,
                Ge = new Date().getTime();
            return new Promise(function(Ne, $e) {
                if (me() && !Y()) {
                    var xt = new Promise(function(U, J) {
                            function E() {
                                new Date().getTime() - Ge >= ee ? J(Error("" + ee + "ms timeout exceeded")) : document.fonts.load(j(S, '"' + S.family + '"'), Q).then(function(N) {
                                    1 <= N.length ? U() : setTimeout(E, 25)
                                }, J)
                            }
                            E()
                        }),
                        bt = new Promise(function(U, J) {
                            G = setTimeout(function() {
                                J(Error("" + ee + "ms timeout exceeded"))
                            }, ee)
                        });
                    Promise.race([bt, xt]).then(function() {
                        clearTimeout(G), Ne(S)
                    }, $e)
                } else e(function() {
                    function U() {
                        var f;
                        (f = O != -1 && R != -1 || O != -1 && M != -1 || R != -1 && M != -1) && ((f = O != R && O != M && R != M) || (y === null && (f = /AppleWebKit\/([0-9]+)(?:\.([0-9]+))/.exec(window.navigator.userAgent), y = !!f && (536 > parseInt(f[1], 10) || parseInt(f[1], 10) === 536 && 11 >= parseInt(f[2], 10))), f = y && (O == le && R == le && M == le || O == we && R == we && M == we || O == Se && R == Se && M == Se)), f = !f), f && (B.parentNode && B.parentNode.removeChild(B), clearTimeout(G), Ne(S))
                    }

                    function J() {
                        if (new Date().getTime() - Ge >= ee) B.parentNode && B.parentNode.removeChild(B), $e(Error("" + ee + "ms timeout exceeded"));
                        else {
                            var f = document.hidden;
                            (f === !0 || f === void 0) && (O = E.a.offsetWidth, R = N.a.offsetWidth, M = te.a.offsetWidth, U()), G = setTimeout(J, 50)
                        }
                    }
                    var E = new t(Q),
                        N = new t(Q),
                        te = new t(Q),
                        O = -1,
                        R = -1,
                        M = -1,
                        le = -1,
                        we = -1,
                        Se = -1,
                        B = document.createElement("div");
                    B.dir = "ltr", s(E, j(S, "sans-serif")), s(N, j(S, "serif")), s(te, j(S, "monospace")), B.appendChild(E.a), B.appendChild(N.a), B.appendChild(te.a), document.body.appendChild(B), le = E.a.offsetWidth, we = N.a.offsetWidth, Se = te.a.offsetWidth, J(), n(E, function(f) {
                        O = f, U()
                    }), s(E, j(S, '"' + S.family + '",sans-serif')), n(N, function(f) {
                        R = f, U()
                    }), s(N, j(S, '"' + S.family + '",serif')), n(te, function(f) {
                        M = f, U()
                    }), s(te, j(S, '"' + S.family + '",monospace'))
                })
            })
        }, i.exports = p
    })()
})(ot);
var Qt = ot.exports,
    er = "/assets/bg@2x.52a3769d.jpg",
    tr = "/assets/bg2@2x.d0afd4f5.jpg";
const rr = {
        "b_minus.png": {
            frame: {
                x: 513,
                y: 959,
                w: 50,
                h: 48
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 50,
                h: 48
            },
            sourceSize: {
                w: 50,
                h: 48
            }
        },
        "b_plus.png": {
            frame: {
                x: 565,
                y: 959,
                w: 50,
                h: 48
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 50,
                h: 48
            },
            sourceSize: {
                w: 50,
                h: 48
            }
        },
        "bag.png": {
            frame: {
                x: 1589,
                y: 525,
                w: 264,
                h: 305
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 5,
                y: 2,
                w: 264,
                h: 305
            },
            sourceSize: {
                w: 272,
                h: 310
            }
        },
        "bible.png": {
            frame: {
                x: 724,
                y: 1121,
                w: 422,
                h: 296
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 114,
                y: 38,
                w: 422,
                h: 296
            },
            sourceSize: {
                w: 636,
                h: 362
            }
        },
        "bible_2.png": {
            frame: {
                x: 1524,
                y: 1736,
                w: 136,
                h: 97
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 4,
                y: 3,
                w: 136,
                h: 97
            },
            sourceSize: {
                w: 143,
                h: 103
            }
        },
        "bigwin.png": {
            frame: {
                x: 1673,
                y: 1453,
                w: 256,
                h: 70
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 256,
                h: 70
            },
            sourceSize: {
                w: 256,
                h: 70
            }
        },
        "button1.png": {
            frame: {
                x: 1087,
                y: 1929,
                w: 196,
                h: 61
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 1,
                y: 0,
                w: 196,
                h: 61
            },
            sourceSize: {
                w: 197,
                h: 61
            }
        },
        "button1_2.png": {
            frame: {
                x: 1276,
                y: 463,
                w: 197,
                h: 61
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 197,
                h: 61
            },
            sourceSize: {
                w: 197,
                h: 61
            }
        },
        "cross.png": {
            frame: {
                x: 513,
                y: 501,
                w: 456,
                h: 327
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 83,
                y: 23,
                w: 456,
                h: 327
            },
            sourceSize: {
                w: 636,
                h: 362
            }
        },
        "cross_2.png": {
            frame: {
                x: 1613,
                y: 1885,
                w: 132,
                h: 95
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 5,
                y: 5,
                w: 132,
                h: 95
            },
            sourceSize: {
                w: 143,
                h: 103
            }
        },
        "gem.png": {
            frame: {
                x: 475,
                y: 1517,
                w: 447,
                h: 320
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 28,
                w: 447,
                h: 320
            },
            sourceSize: {
                w: 636,
                h: 362
            }
        },
        "gem_2.png": {
            frame: {
                x: 1747,
                y: 1885,
                w: 114,
                h: 90
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 14,
                y: 10,
                w: 114,
                h: 90
            },
            sourceSize: {
                w: 143,
                h: 103
            }
        },
        "house_edge.png": {
            frame: {
                x: 1148,
                y: 1121,
                w: 144,
                h: 20
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 144,
                h: 20
            },
            sourceSize: {
                w: 144,
                h: 20
            }
        },
        "l_box1.png": {
            frame: {
                x: 1,
                y: 1,
                w: 812,
                h: 498
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 812,
                h: 498
            },
            sourceSize: {
                w: 812,
                h: 498
            }
        },
        "l_box1_1.png": {
            frame: {
                x: 1148,
                y: 1146,
                w: 358,
                h: 359
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 359
            },
            sourceSize: {
                w: 358,
                h: 360
            }
        },
        "l_box2.png": {
            frame: {
                x: 815,
                y: 1,
                w: 772,
                h: 184
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 772,
                h: 184
            },
            sourceSize: {
                w: 772,
                h: 184
            }
        },
        "l_box2_2.png": {
            frame: {
                x: 1543,
                y: 832,
                w: 307,
                h: 285
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 2,
                y: 0,
                w: 307,
                h: 285
            },
            sourceSize: {
                w: 310,
                h: 286
            }
        },
        "l_box3.png": {
            frame: {
                x: 1087,
                y: 1852,
                w: 224,
                h: 75
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 224,
                h: 75
            },
            sourceSize: {
                w: 225,
                h: 75
            }
        },
        "l_box3_2.png": {
            frame: {
                x: 1745,
                y: 1453,
                w: 225,
                h: 75
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 225,
                h: 75
            },
            sourceSize: {
                w: 225,
                h: 75
            }
        },
        "l_box4.png": {
            frame: {
                x: 1509,
                y: 1146,
                w: 340,
                h: 74
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 74
            },
            sourceSize: {
                w: 340,
                h: 74
            }
        },
        "line.png": {
            frame: {
                x: 1276,
                y: 662,
                w: 140,
                h: 4
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 140,
                h: 4
            },
            sourceSize: {
                w: 140,
                h: 4
            }
        },
        "logo.png": {
            frame: {
                x: 1118,
                y: 1736,
                w: 404,
                h: 114
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 8,
                y: 3,
                w: 404,
                h: 114
            },
            sourceSize: {
                w: 419,
                h: 118
            }
        },
        "particle.png": {
            frame: {
                x: 617,
                y: 959,
                w: 44,
                h: 44
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 44,
                h: 44
            },
            sourceSize: {
                w: 44,
                h: 44
            }
        },
        "plant.png": {
            frame: {
                x: 724,
                y: 959,
                w: 108,
                h: 128
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 108,
                h: 128
            },
            sourceSize: {
                w: 108,
                h: 128
            }
        },
        "ring.png": {
            frame: {
                x: 1,
                y: 1012,
                w: 472,
                h: 472
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 472,
                h: 472
            },
            sourceSize: {
                w: 472,
                h: 472
            }
        },
        "ring_1.png": {
            frame: {
                x: 1623,
                y: 1723,
                w: 160,
                h: 160
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 137,
                y: 137,
                w: 160,
                h: 160
            },
            sourceSize: {
                w: 434,
                h: 434
            }
        },
        "ring_2.png": {
            frame: {
                x: 1,
                y: 1486,
                w: 472,
                h: 472
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 472,
                h: 472
            },
            sourceSize: {
                w: 472,
                h: 472
            }
        },
        "ring_arc.png": {
            frame: {
                x: 995,
                y: 1811,
                w: 177,
                h: 90
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 1,
                y: 0,
                w: 177,
                h: 90
            },
            sourceSize: {
                w: 178,
                h: 90
            }
        },
        "ring_border.png": {
            frame: {
                x: 797,
                y: 1811,
                w: 196,
                h: 196
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 2,
                y: 2,
                w: 196,
                h: 196
            },
            sourceSize: {
                w: 200,
                h: 200
            }
        },
        "s_ac1.png": {
            frame: {
                x: 1313,
                y: 1922,
                w: 192,
                h: 68
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 192,
                h: 68
            },
            sourceSize: {
                w: 192,
                h: 68
            }
        },
        "s_ac2.png": {
            frame: {
                x: 1313,
                y: 1852,
                w: 194,
                h: 68
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 194,
                h: 68
            },
            sourceSize: {
                w: 194,
                h: 68
            }
        },
        "s_ac3.png": {
            frame: {
                x: 1785,
                y: 1680,
                w: 170,
                h: 72
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 170,
                h: 72
            },
            sourceSize: {
                w: 170,
                h: 72
            }
        },
        "s_bg0.png": {
            frame: {
                x: 1118,
                y: 1506,
                w: 228,
                h: 391
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 228,
                h: 391
            },
            sourceSize: {
                w: 228,
                h: 391
            }
        },
        "s_bg2.png": {
            frame: {
                x: 842,
                y: 873,
                w: 246,
                h: 452
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 2,
                w: 246,
                h: 452
            },
            sourceSize: {
                w: 246,
                h: 454
            }
        },
        "s_bg2_2.png": {
            frame: {
                x: 1296,
                y: 691,
                w: 245,
                h: 453
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 245,
                h: 453
            },
            sourceSize: {
                w: 245,
                h: 453
            }
        },
        "s_bg3.png": {
            frame: {
                x: 1589,
                y: 1,
                w: 274,
                h: 522
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 274,
                h: 522
            },
            sourceSize: {
                w: 274,
                h: 522
            }
        },
        "s_bg3_2.png": {
            frame: {
                x: 815,
                y: 187,
                w: 274,
                h: 522
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 274,
                h: 522
            },
            sourceSize: {
                w: 274,
                h: 522
            }
        },
        "s_bg4.png": {
            frame: {
                x: 1339,
                y: 187,
                w: 248,
                h: 502
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 2,
                w: 248,
                h: 502
            },
            sourceSize: {
                w: 248,
                h: 504
            }
        },
        "s_bg4_2.png": {
            frame: {
                x: 475,
                y: 1012,
                w: 247,
                h: 503
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 247,
                h: 503
            },
            sourceSize: {
                w: 247,
                h: 503
            }
        },
        "s_bg5.png": {
            frame: {
                x: 1585,
                y: 1359,
                w: 246,
                h: 92
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 246,
                h: 92
            },
            sourceSize: {
                w: 246,
                h: 92
            }
        },
        "s_bg5_2.png": {
            frame: {
                x: 1511,
                y: 1488,
                w: 246,
                h: 90
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 246,
                h: 90
            },
            sourceSize: {
                w: 246,
                h: 90
            }
        },
        "seed.png": {
            frame: {
                x: 1827,
                y: 1119,
                w: 36,
                h: 42
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 36,
                h: 42
            },
            sourceSize: {
                w: 36,
                h: 42
            }
        },
        "skull.png": {
            frame: {
                x: 797,
                y: 1419,
                w: 390,
                h: 319
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 38,
                y: 7,
                w: 390,
                h: 319
            },
            sourceSize: {
                w: 454,
                h: 326
            }
        },
        "skull_2.png": {
            frame: {
                x: 1509,
                y: 1874,
                w: 86,
                h: 102
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 86,
                h: 102
            },
            sourceSize: {
                w: 86,
                h: 102
            }
        },
        "sound_off.png": {
            frame: {
                x: 1,
                y: 1968,
                w: 48,
                h: 40
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 48,
                h: 40
            },
            sourceSize: {
                w: 48,
                h: 40
            }
        },
        "sound_on.png": {
            frame: {
                x: 1827,
                y: 1163,
                w: 36,
                h: 40
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 36,
                h: 40
            },
            sourceSize: {
                w: 48,
                h: 40
            }
        },
        "text_cashpot.png": {
            frame: {
                x: 1543,
                y: 691,
                w: 114,
                h: 32
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 114,
                h: 32
            },
            sourceSize: {
                w: 114,
                h: 32
            }
        },
        "win_circle.png": {
            frame: {
                x: 842,
                y: 463,
                w: 432,
                h: 408
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 432,
                h: 408
            },
            sourceSize: {
                w: 432,
                h: 408
            }
        },
        "win_coin.png": {
            frame: {
                x: 724,
                y: 1419,
                w: 86,
                h: 70
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 86,
                h: 70
            },
            sourceSize: {
                w: 86,
                h: 70
            }
        },
        "win_light.png": {
            frame: {
                x: 1,
                y: 501,
                w: 510,
                h: 509
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 510,
                h: 509
            },
            sourceSize: {
                w: 510,
                h: 509
            }
        },
        "win_light2.png": {
            frame: {
                x: 1585,
                y: 1119,
                w: 240,
                h: 238
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 240,
                h: 238
            },
            sourceSize: {
                w: 240,
                h: 238
            }
        },
        "win_line.png": {
            frame: {
                x: 1,
                y: 1960,
                w: 466,
                h: 6
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 466,
                h: 6
            },
            sourceSize: {
                w: 466,
                h: 6
            }
        },
        "youwin.png": {
            frame: {
                x: 1603,
                y: 1453,
                w: 268,
                h: 68
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 268,
                h: 68
            },
            sourceSize: {
                w: 268,
                h: 68
            }
        }
    },
    ir = {
        l_box: ["l_box1.png", "l_box2.png", "l_box3.png", "l_box4.png"],
        ring: ["ring_1.png", "ring_2.png"],
        s_ac: ["s_ac1.png", "s_ac2.png", "s_ac3.png"],
        s_bg: ["s_bg0.png", "s_bg2.png", "s_bg3.png", "s_bg4.png", "s_bg5.png"]
    },
    sr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "sheets@2x.png",
        format: "RGBA8888",
        size: {
            w: 1864,
            h: 2009
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:58f1ea485095c8c2f2dcd5c9a31f8dd2:5de0616d4097e16c99330f33c06873ae:caf4c70207e487b5dc0fb4598e3a6a41$"
    };
var ar = {
        frames: rr,
        animations: ir,
        meta: sr
    },
    Me = "/assets/sheets@2x.a61bfc69.png";
const or = {
        "rou00.png": {
            frame: {
                x: 272,
                y: 271,
                w: 3,
                h: 3
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 3,
                h: 3
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou01.png": {
            frame: {
                x: 289,
                y: 1321,
                w: 73,
                h: 150
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 24,
                w: 73,
                h: 150
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou02.png": {
            frame: {
                x: 153,
                y: 1332,
                w: 134,
                h: 150
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 40,
                y: 24,
                w: 134,
                h: 150
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou03.png": {
            frame: {
                x: 1,
                y: 1332,
                w: 150,
                h: 150
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 24,
                y: 24,
                w: 150,
                h: 150
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou04.png": {
            frame: {
                x: 1098,
                y: 407,
                w: 150,
                h: 205
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 24,
                y: 24,
                w: 150,
                h: 205
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou05.png": {
            frame: {
                x: 1100,
                y: 178,
                w: 150,
                h: 227
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 24,
                y: 24,
                w: 150,
                h: 227
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou06.png": {
            frame: {
                x: 943,
                y: 1546,
                w: 199,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 24,
                y: 23,
                w: 199,
                h: 228
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou07.png": {
            frame: {
                x: 943,
                y: 1317,
                w: 227,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 24,
                y: 23,
                w: 227,
                h: 228
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou08.png": {
            frame: {
                x: 713,
                y: 1496,
                w: 228,
                h: 232
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 23,
                y: 20,
                w: 228,
                h: 232
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou09.png": {
            frame: {
                x: 479,
                y: 1496,
                w: 232,
                h: 237
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 19,
                y: 17,
                w: 232,
                h: 237
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou10.png": {
            frame: {
                x: 242,
                y: 1496,
                w: 235,
                h: 242
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 16,
                y: 14,
                w: 235,
                h: 242
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou11.png": {
            frame: {
                x: 1,
                y: 1496,
                w: 239,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 14,
                y: 10,
                w: 239,
                h: 249
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou12.png": {
            frame: {
                x: 538,
                y: 1057,
                w: 247,
                h: 262
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 8,
                y: 2,
                w: 247,
                h: 262
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou13.png": {
            frame: {
                x: 1,
                y: 808,
                w: 256,
                h: 267
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 3,
                y: 0,
                w: 256,
                h: 267
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou14.png": {
            frame: {
                x: 542,
                y: 791,
                w: 264,
                h: 267
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 264,
                h: 267
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou15.png": {
            frame: {
                x: 272,
                y: 529,
                w: 264,
                h: 268
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 2,
                y: 0,
                w: 264,
                h: 268
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou16.png": {
            frame: {
                x: 820,
                y: 529,
                w: 265,
                h: 267
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 1,
                y: 2,
                w: 265,
                h: 267
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou17.png": {
            frame: {
                x: 1,
                y: 539,
                w: 267,
                h: 267
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 2,
                w: 267,
                h: 267
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou18.png": {
            frame: {
                x: 811,
                y: 796,
                w: 265,
                h: 263
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 265,
                h: 263
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou19.png": {
            frame: {
                x: 1,
                y: 1066,
                w: 264,
                h: 265
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 264,
                h: 265
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou20.png": {
            frame: {
                x: 1,
                y: 271,
                w: 266,
                h: 269
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 266,
                h: 269
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou21.png": {
            frame: {
                x: 1,
                y: 1,
                w: 268,
                h: 274
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 268,
                h: 274
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou22.png": {
            frame: {
                x: 277,
                y: 1,
                w: 263,
                h: 273
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 7,
                y: 0,
                w: 263,
                h: 273
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou23.png": {
            frame: {
                x: 552,
                y: 263,
                w: 262,
                h: 270
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 7,
                y: 0,
                w: 262,
                h: 270
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou24.png": {
            frame: {
                x: 270,
                y: 1054,
                w: 266,
                h: 265
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 6,
                y: 0,
                w: 266,
                h: 265
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou25.png": {
            frame: {
                x: 826,
                y: 262,
                w: 270,
                h: 265
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 3,
                y: 0,
                w: 270,
                h: 265
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou26.png": {
            frame: {
                x: 549,
                y: 527,
                w: 269,
                h: 262
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 269,
                h: 262
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou27.png": {
            frame: {
                x: 277,
                y: 266,
                w: 270,
                h: 261
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 270,
                h: 261
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou28.png": {
            frame: {
                x: 552,
                y: 1,
                w: 272,
                h: 260
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 272,
                h: 260
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou29.png": {
            frame: {
                x: 826,
                y: 1,
                w: 272,
                h: 259
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 272,
                h: 259
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou30.png": {
            frame: {
                x: 270,
                y: 795,
                w: 267,
                h: 257
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 4,
                y: 0,
                w: 267,
                h: 257
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou31.png": {
            frame: {
                x: 802,
                y: 1061,
                w: 259,
                h: 254
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 10,
                y: 0,
                w: 259,
                h: 254
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou32.png": {
            frame: {
                x: 538,
                y: 1306,
                w: 188,
                h: 256
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 82,
                y: 0,
                w: 188,
                h: 256
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou33.png": {
            frame: {
                x: 1089,
                y: 614,
                w: 172,
                h: 235
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 100,
                y: 0,
                w: 172,
                h: 235
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou34.png": {
            frame: {
                x: 1078,
                y: 1060,
                w: 173,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 0,
                w: 173,
                h: 198
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou35.png": {
            frame: {
                x: 1100,
                y: 1,
                w: 161,
                h: 175
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 99,
                y: 0,
                w: 161,
                h: 175
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou36.png": {
            frame: {
                x: 1078,
                y: 851,
                w: 124,
                h: 174
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 94,
                y: 0,
                w: 124,
                h: 174
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou37.png": {
            frame: {
                x: 1078,
                y: 977,
                w: 81,
                h: 174
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 93,
                y: 0,
                w: 81,
                h: 174
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou38.png": {
            frame: {
                x: 1173,
                y: 1260,
                w: 74,
                h: 74
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 100,
                y: 101,
                w: 74,
                h: 74
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou39.png": {
            frame: {
                x: 1173,
                y: 1563,
                w: 73,
                h: 74
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 101,
                w: 73,
                h: 74
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou40.png": {
            frame: {
                x: 1173,
                y: 1336,
                w: 74,
                h: 74
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 100,
                y: 101,
                w: 74,
                h: 74
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou41.png": {
            frame: {
                x: 1173,
                y: 1638,
                w: 73,
                h: 74
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 101,
                w: 73,
                h: 74
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou42.png": {
            frame: {
                x: 796,
                y: 1317,
                w: 73,
                h: 74
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 101,
                w: 73,
                h: 74
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou43.png": {
            frame: {
                x: 1173,
                y: 1488,
                w: 74,
                h: 73
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 100,
                y: 101,
                w: 74,
                h: 73
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou44.png": {
            frame: {
                x: 1173,
                y: 1412,
                w: 74,
                h: 74
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 100,
                y: 101,
                w: 74,
                h: 74
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou45.png": {
            frame: {
                x: 796,
                y: 1392,
                w: 73,
                h: 73
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 101,
                w: 73,
                h: 73
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou46.png": {
            frame: {
                x: 364,
                y: 1321,
                w: 73,
                h: 73
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 101,
                w: 73,
                h: 73
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        },
        "rou47.png": {
            frame: {
                x: 272,
                y: 271,
                w: 3,
                h: 3
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 3,
                h: 3
            },
            sourceSize: {
                w: 275,
                h: 275
            }
        }
    },
    nr = {
        rou: ["rou00.png", "rou01.png", "rou02.png", "rou03.png", "rou04.png", "rou05.png", "rou06.png", "rou07.png", "rou08.png", "rou09.png", "rou10.png", "rou11.png", "rou12.png", "rou13.png", "rou14.png", "rou15.png", "rou16.png", "rou17.png", "rou18.png", "rou19.png", "rou20.png", "rou21.png", "rou22.png", "rou23.png", "rou24.png", "rou25.png", "rou26.png", "rou27.png", "rou28.png", "rou29.png", "rou30.png", "rou31.png", "rou32.png", "rou33.png", "rou34.png", "rou35.png", "rou36.png", "rou37.png", "rou38.png", "rou39.png", "rou40.png", "rou41.png", "rou42.png", "rou43.png", "rou44.png", "rou45.png", "rou46.png", "rou47.png"]
    },
    hr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "rou@2x.png",
        format: "RGBA8888",
        size: {
            w: 1262,
            h: 1746
        },
        scale: "0.5",
        smartupdate: "$TexturePacker:SmartUpdate:b027e1e85d5deda7328dbc6d89aeaa94:6abcdf4b15bebe2c9f6085856de36591:95a33116cf5564d509f0e14d6ddc0562$"
    };
var ur = {
        frames: or,
        animations: nr,
        meta: hr
    },
    nt = "/assets/rou@2x.a16525ce.png";
const cr = {
        "gem00.png": {
            frame: {
                x: 1332,
                y: 503,
                w: 228,
                h: 163
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 89,
                y: 49,
                w: 228,
                h: 163
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem01.png": {
            frame: {
                x: 1692,
                y: 753,
                w: 265,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 69,
                y: 15,
                w: 265,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem02.png": {
            frame: {
                x: 1521,
                y: 1494,
                w: 277,
                h: 222
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 63,
                y: 10,
                w: 277,
                h: 222
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem03.png": {
            frame: {
                x: 1214,
                y: 1494,
                w: 305,
                h: 232
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 39,
                y: 2,
                w: 305,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem04.png": {
            frame: {
                x: 1515,
                y: 1728,
                w: 335,
                h: 238
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 14,
                y: 0,
                w: 335,
                h: 238
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem05.png": {
            frame: {
                x: 863,
                y: 1491,
                w: 349,
                h: 238
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 349,
                h: 238
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem06.png": {
            frame: {
                x: 503,
                y: 1495,
                w: 349,
                h: 238
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 349,
                h: 238
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem07.png": {
            frame: {
                x: 252,
                y: 503,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem08.png": {
            frame: {
                x: 972,
                y: 503,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem09.png": {
            frame: {
                x: 972,
                y: 750,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem10.png": {
            frame: {
                x: 503,
                y: 754,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem11.png": {
            frame: {
                x: 1332,
                y: 753,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem12.png": {
            frame: {
                x: 863,
                y: 997,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem13.png": {
            frame: {
                x: 503,
                y: 1001,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem14.png": {
            frame: {
                x: 1223,
                y: 1e3,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem15.png": {
            frame: {
                x: 863,
                y: 1244,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem16.png": {
            frame: {
                x: 503,
                y: 1248,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem17.png": {
            frame: {
                x: 1223,
                y: 1247,
                w: 358,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem18.png": {
            frame: {
                x: 1,
                y: 252,
                w: 358,
                h: 247
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 247
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem19.png": {
            frame: {
                x: 252,
                y: 1123,
                w: 358,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem20.png": {
            frame: {
                x: 252,
                y: 1483,
                w: 358,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem21.png": {
            frame: {
                x: 612,
                y: 503,
                w: 358,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 358,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem22.png": {
            frame: {
                x: 252,
                y: 753,
                w: 368,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 368,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem23.png": {
            frame: {
                x: 1505,
                y: 502,
                w: 374,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 374,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem24.png": {
            frame: {
                x: 361,
                y: 252,
                w: 383,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 383,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem25.png": {
            frame: {
                x: 1,
                y: 1283,
                w: 386,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 386,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem26.png": {
            frame: {
                x: 1,
                y: 502,
                w: 389,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 389,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem27.png": {
            frame: {
                x: 1182,
                y: 1,
                w: 390,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 390,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem28.png": {
            frame: {
                x: 396,
                y: 1,
                w: 391,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 391,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem29.png": {
            frame: {
                x: 1,
                y: 1,
                w: 393,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 393,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem30.png": {
            frame: {
                x: 1,
                y: 893,
                w: 388,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 388,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem31.png": {
            frame: {
                x: 789,
                y: 1,
                w: 391,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 391,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem32.png": {
            frame: {
                x: 746,
                y: 252,
                w: 380,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 2,
                y: 0,
                w: 380,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem33.png": {
            frame: {
                x: 1128,
                y: 252,
                w: 375,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 5,
                y: 0,
                w: 375,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem34.png": {
            frame: {
                x: 843,
                y: 1735,
                w: 336,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 46,
                y: 0,
                w: 336,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem35.png": {
            frame: {
                x: 1181,
                y: 1731,
                w: 332,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 46,
                y: 0,
                w: 332,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem36.png": {
            frame: {
                x: 1,
                y: 1671,
                w: 322,
                h: 249
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 46,
                y: 0,
                w: 322,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem37.png": {
            frame: {
                x: 1574,
                y: 251,
                w: 323,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 49,
                y: 0,
                w: 323,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem38.png": {
            frame: {
                x: 503,
                y: 1735,
                w: 338,
                h: 249
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 44,
                y: 0,
                w: 338,
                h: 249
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem39.png": {
            frame: {
                x: 1574,
                y: 1,
                w: 326,
                h: 248
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 45,
                y: 1,
                w: 326,
                h: 248
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "gem40.png": {
            frame: {
                x: 1583,
                y: 1020,
                w: 306,
                h: 245
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 46,
                y: 4,
                w: 306,
                h: 245
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        }
    },
    pr = {
        gem: ["gem00.png", "gem01.png", "gem02.png", "gem03.png", "gem04.png", "gem05.png", "gem06.png", "gem07.png", "gem08.png", "gem09.png", "gem10.png", "gem11.png", "gem12.png", "gem13.png", "gem14.png", "gem15.png", "gem16.png", "gem17.png", "gem18.png", "gem19.png", "gem20.png", "gem21.png", "gem22.png", "gem23.png", "gem24.png", "gem25.png", "gem26.png", "gem27.png", "gem28.png", "gem29.png", "gem30.png", "gem31.png", "gem32.png", "gem33.png", "gem34.png", "gem35.png", "gem36.png", "gem37.png", "gem38.png", "gem39.png", "gem40.png"]
    },
    dr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "gem@2x.png",
        format: "RGBA8888",
        size: {
            w: 1905,
            h: 1994
        },
        scale: "0.5",
        smartupdate: "$TexturePacker:SmartUpdate:aa3661f73bf035a8b2647c724c548602:31bc627221a9844ee7a80483c51ab2b1:527b436c9415ce59a678f0596cdab17a$"
    };
var mr = {
        frames: cr,
        animations: pr,
        meta: dr
    },
    ht = "/assets/gem@2x.104000d9.png";
const lr = {
        "cross_00.png": {
            frame: {
                x: 1819,
                y: 1029,
                w: 230,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 79,
                y: 0,
                w: 230,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_01.png": {
            frame: {
                x: 1802,
                y: 1,
                w: 247,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 71,
                y: 0,
                w: 247,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_02.png": {
            frame: {
                x: 1793,
                y: 515,
                w: 251,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 69,
                y: 0,
                w: 251,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_03.png": {
            frame: {
                x: 1799,
                y: 258,
                w: 251,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 69,
                y: 0,
                w: 251,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_04.png": {
            frame: {
                x: 749,
                y: 1032,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_05.png": {
            frame: {
                x: 926,
                y: 775,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_06.png": {
            frame: {
                x: 937,
                y: 515,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_07.png": {
            frame: {
                x: 963,
                y: 1032,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_08.png": {
            frame: {
                x: 1140,
                y: 772,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_09.png": {
            frame: {
                x: 1151,
                y: 515,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_10.png": {
            frame: {
                x: 1157,
                y: 258,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_11.png": {
            frame: {
                x: 1160,
                y: 1,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_12.png": {
            frame: {
                x: 1177,
                y: 1029,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_13.png": {
            frame: {
                x: 1354,
                y: 772,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_14.png": {
            frame: {
                x: 1365,
                y: 515,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_15.png": {
            frame: {
                x: 1371,
                y: 258,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_16.png": {
            frame: {
                x: 1374,
                y: 1,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_17.png": {
            frame: {
                x: 1391,
                y: 1029,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_18.png": {
            frame: {
                x: 1568,
                y: 772,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_19.png": {
            frame: {
                x: 1579,
                y: 515,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_20.png": {
            frame: {
                x: 1585,
                y: 258,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_21.png": {
            frame: {
                x: 1588,
                y: 1,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_22.png": {
            frame: {
                x: 1605,
                y: 1029,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_23.png": {
            frame: {
                x: 1782,
                y: 772,
                w: 255,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_24.png": {
            frame: {
                x: 935,
                y: 258,
                w: 255,
                h: 220
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 220
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_25.png": {
            frame: {
                x: 704,
                y: 775,
                w: 255,
                h: 220
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 220
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_26.png": {
            frame: {
                x: 934,
                y: 1,
                w: 255,
                h: 224
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 224
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_27.png": {
            frame: {
                x: 705,
                y: 1,
                w: 255,
                h: 227
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 227
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_28.png": {
            frame: {
                x: 704,
                y: 259,
                w: 255,
                h: 229
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 229
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_29.png": {
            frame: {
                x: 471,
                y: 259,
                w: 257,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 257,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_30.png": {
            frame: {
                x: 515,
                y: 1082,
                w: 256,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 256,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_31.png": {
            frame: {
                x: 703,
                y: 518,
                w: 255,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 255,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_32.png": {
            frame: {
                x: 471,
                y: 1,
                w: 256,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 256,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_33.png": {
            frame: {
                x: 470,
                y: 821,
                w: 259,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 259,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_34.png": {
            frame: {
                x: 470,
                y: 558,
                w: 261,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 261,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_35.png": {
            frame: {
                x: 282,
                y: 1102,
                w: 264,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 264,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_36.png": {
            frame: {
                x: 238,
                y: 832,
                w: 268,
                h: 230
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 268,
                h: 230
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_37.png": {
            frame: {
                x: 238,
                y: 558,
                w: 272,
                h: 230
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 272,
                h: 230
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_38.png": {
            frame: {
                x: 238,
                y: 281,
                w: 275,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 275,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_39.png": {
            frame: {
                x: 1,
                y: 1130,
                w: 279,
                h: 234
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 279,
                h: 234
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_40.png": {
            frame: {
                x: 1,
                y: 284,
                w: 280,
                h: 235
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 280,
                h: 235
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_41.png": {
            frame: {
                x: 1,
                y: 566,
                w: 280,
                h: 235
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 67,
                y: 0,
                w: 280,
                h: 235
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_42.png": {
            frame: {
                x: 1,
                y: 848,
                w: 280,
                h: 235
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 69,
                y: 0,
                w: 280,
                h: 235
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_43.png": {
            frame: {
                x: 1,
                y: 1,
                w: 281,
                h: 235
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 69,
                y: 0,
                w: 281,
                h: 235
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "cross_44.png": {
            frame: {
                x: 238,
                y: 1,
                w: 278,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 73,
                y: 0,
                w: 278,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        }
    },
    wr = {
        cross: ["cross_00.png", "cross_01.png", "cross_02.png", "cross_03.png", "cross_04.png", "cross_05.png", "cross_06.png", "cross_07.png", "cross_08.png", "cross_09.png", "cross_10.png", "cross_11.png", "cross_12.png", "cross_13.png", "cross_14.png", "cross_15.png", "cross_16.png", "cross_17.png", "cross_18.png", "cross_19.png", "cross_20.png", "cross_21.png", "cross_22.png", "cross_23.png", "cross_24.png", "cross_25.png", "cross_26.png", "cross_27.png", "cross_28.png", "cross_29.png", "cross_30.png", "cross_31.png", "cross_32.png", "cross_33.png", "cross_34.png", "cross_35.png", "cross_36.png", "cross_37.png", "cross_38.png", "cross_39.png", "cross_40.png", "cross_41.png", "cross_42.png", "cross_43.png", "cross_44.png"]
    },
    Sr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "cross@2x.png",
        format: "RGBA8888",
        size: {
            w: 2032,
            h: 1367
        },
        scale: "0.5",
        smartupdate: "$TexturePacker:SmartUpdate:82365b6e6b2beeb49017091a50621074:d5e1a7671ca89a7b70acd1d6a63f0d80:a72445f59b8eda8e9ce43b0683d81619$"
    };
var gr = {
        frames: lr,
        animations: wr,
        meta: Sr
    },
    ut = "/assets/cross@2x.224b9f3a.png";
const yr = {
        "book_00.png": {
            frame: {
                x: 1362,
                y: 692,
                w: 212,
                h: 151
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 96,
                y: 50,
                w: 212,
                h: 151
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_01.png": {
            frame: {
                x: 1141,
                y: 1098,
                w: 216,
                h: 154
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 94,
                y: 47,
                w: 216,
                h: 154
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_02.png": {
            frame: {
                x: 1795,
                y: 1596,
                w: 230,
                h: 163
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 87,
                y: 41,
                w: 230,
                h: 163
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_03.png": {
            frame: {
                x: 1617,
                y: 1596,
                w: 248,
                h: 176
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 78,
                y: 31,
                w: 248,
                h: 176
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_04.png": {
            frame: {
                x: 1157,
                y: 1254,
                w: 284,
                h: 197
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 59,
                y: 14,
                w: 284,
                h: 197
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_05.png": {
            frame: {
                x: 926,
                y: 1107,
                w: 312,
                h: 211
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 44,
                y: 0,
                w: 312,
                h: 211
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_06.png": {
            frame: {
                x: 1359,
                y: 1188,
                w: 339,
                h: 210
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 30,
                y: 0,
                w: 339,
                h: 210
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_07.png": {
            frame: {
                x: 464,
                y: 383,
                w: 370,
                h: 209
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 18,
                y: 0,
                w: 370,
                h: 209
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_08.png": {
            frame: {
                x: 466,
                y: 1,
                w: 370,
                h: 208
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 21,
                y: 0,
                w: 370,
                h: 208
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_09.png": {
            frame: {
                x: 688,
                y: 744,
                w: 369,
                h: 223
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 25,
                y: 0,
                w: 369,
                h: 223
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_10.png": {
            frame: {
                x: 675,
                y: 373,
                w: 369,
                h: 225
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 29,
                y: 0,
                w: 369,
                h: 225
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_11.png": {
            frame: {
                x: 676,
                y: 1,
                w: 369,
                h: 225
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 32,
                y: 0,
                w: 369,
                h: 225
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_12.png": {
            frame: {
                x: 462,
                y: 755,
                w: 370,
                h: 224
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 35,
                y: 0,
                w: 370,
                h: 224
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_13.png": {
            frame: {
                x: 903,
                y: 1,
                w: 367,
                h: 224
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 39,
                y: 0,
                w: 367,
                h: 224
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_14.png": {
            frame: {
                x: 913,
                y: 741,
                w: 364,
                h: 226
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 42,
                y: 0,
                w: 364,
                h: 226
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_15.png": {
            frame: {
                x: 1576,
                y: 904,
                w: 361,
                h: 228
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 45,
                y: 0,
                w: 361,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_16.png": {
            frame: {
                x: 696,
                y: 1529,
                w: 357,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 49,
                y: 0,
                w: 357,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_17.png": {
            frame: {
                x: 1157,
                y: 1540,
                w: 354,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 52,
                y: 0,
                w: 354,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_18.png": {
            frame: {
                x: 1387,
                y: 1529,
                w: 351,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 55,
                y: 0,
                w: 351,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_19.png": {
            frame: {
                x: 1617,
                y: 1366,
                w: 350,
                h: 228
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 56,
                y: 0,
                w: 350,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_20.png": {
            frame: {
                x: 926,
                y: 1529,
                w: 354,
                h: 229
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 52,
                y: 0,
                w: 354,
                h: 229
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_21.png": {
            frame: {
                x: 1576,
                y: 1134,
                w: 358,
                h: 230
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 48,
                y: 0,
                w: 358,
                h: 230
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_22.png": {
            frame: {
                x: 1576,
                y: 440,
                w: 361,
                h: 231
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 45,
                y: 0,
                w: 361,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_23.png": {
            frame: {
                x: 692,
                y: 1115,
                w: 364,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 42,
                y: 0,
                w: 364,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_24.png": {
            frame: {
                x: 228,
                y: 1531,
                w: 370,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 36,
                y: 0,
                w: 370,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_25.png": {
            frame: {
                x: 462,
                y: 1530,
                w: 373,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 33,
                y: 0,
                w: 373,
                h: 232
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_26.png": {
            frame: {
                x: 233,
                y: 1153,
                w: 375,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 31,
                y: 0,
                w: 375,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_27.png": {
            frame: {
                x: 1,
                y: 774,
                w: 377,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 29,
                y: 0,
                w: 377,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_28.png": {
            frame: {
                x: 233,
                y: 1,
                w: 380,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 26,
                y: 0,
                w: 380,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_29.png": {
            frame: {
                x: 1,
                y: 389,
                w: 383,
                h: 231
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 23,
                y: 0,
                w: 383,
                h: 231
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_30.png": {
            frame: {
                x: 1,
                y: 1,
                w: 386,
                h: 230
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 20,
                y: 0,
                w: 386,
                h: 230
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_31.png": {
            frame: {
                x: 1,
                y: 1153,
                w: 376,
                h: 230
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 18,
                y: 0,
                w: 376,
                h: 230
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_32.png": {
            frame: {
                x: 1576,
                y: 673,
                w: 361,
                h: 229
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 16,
                y: 0,
                w: 361,
                h: 229
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_33.png": {
            frame: {
                x: 1132,
                y: 370,
                w: 363,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 15,
                y: 0,
                w: 363,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_34.png": {
            frame: {
                x: 902,
                y: 372,
                w: 367,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 10,
                y: 0,
                w: 367,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_35.png": {
            frame: {
                x: 234,
                y: 383,
                w: 370,
                h: 228
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 7,
                y: 0,
                w: 370,
                h: 228
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_36.png": {
            frame: {
                x: 234,
                y: 755,
                w: 370,
                h: 226
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 6,
                y: 0,
                w: 370,
                h: 226
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_37.png": {
            frame: {
                x: 1,
                y: 1531,
                w: 371,
                h: 225
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 6,
                y: 0,
                w: 371,
                h: 225
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_38.png": {
            frame: {
                x: 466,
                y: 1127,
                w: 369,
                h: 224
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 8,
                y: 0,
                w: 369,
                h: 224
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_39.png": {
            frame: {
                x: 1129,
                y: 1,
                w: 367,
                h: 223
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 9,
                y: 0,
                w: 367,
                h: 223
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_40.png": {
            frame: {
                x: 1354,
                y: 1,
                w: 363,
                h: 220
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 11,
                y: 0,
                w: 363,
                h: 220
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_41.png": {
            frame: {
                x: 1576,
                y: 1,
                w: 362,
                h: 218
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 12,
                y: 0,
                w: 362,
                h: 218
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_42.png": {
            frame: {
                x: 1576,
                y: 221,
                w: 362,
                h: 217
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 13,
                y: 0,
                w: 362,
                h: 217
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_43.png": {
            frame: {
                x: 1141,
                y: 735,
                w: 361,
                h: 217
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 14,
                y: 0,
                w: 361,
                h: 217
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_44.png": {
            frame: {
                x: 1360,
                y: 845,
                w: 341,
                h: 214
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 33,
                y: 0,
                w: 341,
                h: 214
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        },
        "book_45.png": {
            frame: {
                x: 1362,
                y: 366,
                w: 324,
                h: 212
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 50,
                y: 0,
                w: 324,
                h: 212
            },
            sourceSize: {
                w: 406,
                h: 249
            }
        }
    },
    fr = {
        book: ["book_00.png", "book_01.png", "book_02.png", "book_03.png", "book_04.png", "book_05.png", "book_06.png", "book_07.png", "book_08.png", "book_09.png", "book_10.png", "book_11.png", "book_12.png", "book_13.png", "book_14.png", "book_15.png", "book_16.png", "book_17.png", "book_18.png", "book_19.png", "book_20.png", "book_21.png", "book_22.png", "book_23.png", "book_24.png", "book_25.png", "book_26.png", "book_27.png", "book_28.png", "book_29.png", "book_30.png", "book_31.png", "book_32.png", "book_33.png", "book_34.png", "book_35.png", "book_36.png", "book_37.png", "book_38.png", "book_39.png", "book_40.png", "book_41.png", "book_42.png", "book_43.png", "book_44.png", "book_45.png"]
    },
    xr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "book@2x.png",
        format: "RGBA8888",
        size: {
            w: 1968,
            h: 1904
        },
        scale: "0.5",
        smartupdate: "$TexturePacker:SmartUpdate:162d0670eb945371524ed683b1b99456:3530e3425214facdc5403381d1888206:87d22a894ebf958e18f00793549d7de7$"
    };
var br = {
        frames: yr,
        animations: fr,
        meta: xr
    },
    ct = "/assets/book@2x.3f17f202.png";
const zr = {
        "a1_00.png": {
            frame: {
                x: 1,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_01.png": {
            frame: {
                x: 343,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_02.png": {
            frame: {
                x: 685,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_03.png": {
            frame: {
                x: 1027,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_04.png": {
            frame: {
                x: 1369,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_05.png": {
            frame: {
                x: 1711,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_06.png": {
            frame: {
                x: 1,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_07.png": {
            frame: {
                x: 343,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_08.png": {
            frame: {
                x: 685,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_09.png": {
            frame: {
                x: 1027,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_10.png": {
            frame: {
                x: 1369,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_11.png": {
            frame: {
                x: 1711,
                y: 343,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_12.png": {
            frame: {
                x: 1,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_13.png": {
            frame: {
                x: 343,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_14.png": {
            frame: {
                x: 685,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_15.png": {
            frame: {
                x: 1027,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_16.png": {
            frame: {
                x: 1369,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_17.png": {
            frame: {
                x: 1,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_18.png": {
            frame: {
                x: 343,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_19.png": {
            frame: {
                x: 685,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_20.png": {
            frame: {
                x: 1027,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_21.png": {
            frame: {
                x: 1369,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_22.png": {
            frame: {
                x: 1711,
                y: 685,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_23.png": {
            frame: {
                x: 1,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_24.png": {
            frame: {
                x: 343,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_25.png": {
            frame: {
                x: 685,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_26.png": {
            frame: {
                x: 1027,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_27.png": {
            frame: {
                x: 1369,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_28.png": {
            frame: {
                x: 1711,
                y: 1027,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a1_29.png": {
            frame: {
                x: 1,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        }
    },
    _r = {
        a1: ["a1_00.png", "a1_01.png", "a1_02.png", "a1_03.png", "a1_04.png", "a1_05.png", "a1_06.png", "a1_07.png", "a1_08.png", "a1_09.png", "a1_10.png", "a1_11.png", "a1_12.png", "a1_13.png", "a1_14.png", "a1_15.png", "a1_16.png", "a1_17.png", "a1_18.png", "a1_19.png", "a1_20.png", "a1_21.png", "a1_22.png", "a1_23.png", "a1_24.png", "a1_25.png", "a1_26.png", "a1_27.png", "a1_28.png", "a1_29.png"]
    },
    vr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "a1@2x.png",
        format: "RGBA8888",
        size: {
            w: 1962,
            h: 1368
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:38e5a92c3cd08f2be412c88285e11ddc:62a3eb41c1aaa600b85542e96393af5f:75279b72b5e6a45e93d22af6253630dc$"
    };
var kr = {
        frames: zr,
        animations: _r,
        meta: vr
    },
    pt = "/assets/a1@2x.c236d531.png";
const Ar = {
        "a2_00.png": {
            frame: {
                x: 1761,
                y: 1,
                w: 350,
                h: 191
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 27,
                w: 350,
                h: 191
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_01.png": {
            frame: {
                x: 1409,
                y: 601,
                w: 350,
                h: 194
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 24,
                w: 350,
                h: 194
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_02.png": {
            frame: {
                x: 1,
                y: 1,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_03.png": {
            frame: {
                x: 1,
                y: 201,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_04.png": {
            frame: {
                x: 353,
                y: 1,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_05.png": {
            frame: {
                x: 1,
                y: 401,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_06.png": {
            frame: {
                x: 353,
                y: 201,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_07.png": {
            frame: {
                x: 705,
                y: 1,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_08.png": {
            frame: {
                x: 1,
                y: 601,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_09.png": {
            frame: {
                x: 1,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_10.png": {
            frame: {
                x: 201,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_11.png": {
            frame: {
                x: 705,
                y: 201,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_12.png": {
            frame: {
                x: 1057,
                y: 1,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_13.png": {
            frame: {
                x: 353,
                y: 401,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_14.png": {
            frame: {
                x: 353,
                y: 601,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_15.png": {
            frame: {
                x: 401,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_16.png": {
            frame: {
                x: 601,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_17.png": {
            frame: {
                x: 1057,
                y: 201,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_18.png": {
            frame: {
                x: 1409,
                y: 1,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_19.png": {
            frame: {
                x: 705,
                y: 401,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_20.png": {
            frame: {
                x: 705,
                y: 601,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_21.png": {
            frame: {
                x: 801,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_22.png": {
            frame: {
                x: 1001,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_23.png": {
            frame: {
                x: 1409,
                y: 201,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_24.png": {
            frame: {
                x: 1057,
                y: 401,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_25.png": {
            frame: {
                x: 1057,
                y: 601,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_26.png": {
            frame: {
                x: 1201,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_27.png": {
            frame: {
                x: 1401,
                y: 801,
                w: 350,
                h: 198
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_28.png": {
            frame: {
                x: 1409,
                y: 401,
                w: 350,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 20,
                w: 350,
                h: 198
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_29.png": {
            frame: {
                x: 1601,
                y: 797,
                w: 350,
                h: 194
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 24,
                w: 350,
                h: 194
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        },
        "a2_30.png": {
            frame: {
                x: 1761,
                y: 1,
                w: 350,
                h: 191
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 27,
                w: 350,
                h: 191
            },
            sourceSize: {
                w: 350,
                h: 218
            }
        }
    },
    Cr = {
        a2: ["a2_00.png", "a2_01.png", "a2_02.png", "a2_03.png", "a2_04.png", "a2_05.png", "a2_06.png", "a2_07.png", "a2_08.png", "a2_09.png", "a2_10.png", "a2_11.png", "a2_12.png", "a2_13.png", "a2_14.png", "a2_15.png", "a2_16.png", "a2_17.png", "a2_18.png", "a2_19.png", "a2_20.png", "a2_21.png", "a2_22.png", "a2_23.png", "a2_24.png", "a2_25.png", "a2_26.png", "a2_27.png", "a2_28.png", "a2_29.png", "a2_30.png"]
    },
    Br = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "a2@2x.png",
        format: "RGBA8888",
        size: {
            w: 1953,
            h: 1152
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:81cfe80c17ee2e58254db665fe18aaa8:6c3b6185042b196e9916ef1bf6f4e4d6:4b2f55f77eb13fc073ca9a18abcf8449$"
    };
var Ir = {
        frames: Ar,
        animations: Cr,
        meta: Br
    },
    dt = "/assets/a2@2x.2ea586e9.png";
const Tr = {
        "a3_00.png": {
            frame: {
                x: 1,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_01.png": {
            frame: {
                x: 343,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_02.png": {
            frame: {
                x: 685,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_03.png": {
            frame: {
                x: 1027,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_04.png": {
            frame: {
                x: 1369,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_05.png": {
            frame: {
                x: 1711,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_06.png": {
            frame: {
                x: 1,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_07.png": {
            frame: {
                x: 343,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_08.png": {
            frame: {
                x: 685,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_09.png": {
            frame: {
                x: 1027,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_10.png": {
            frame: {
                x: 1369,
                y: 253,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_11.png": {
            frame: {
                x: 1711,
                y: 343,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_12.png": {
            frame: {
                x: 1,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_13.png": {
            frame: {
                x: 343,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_14.png": {
            frame: {
                x: 685,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_15.png": {
            frame: {
                x: 1027,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_16.png": {
            frame: {
                x: 1369,
                y: 505,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_17.png": {
            frame: {
                x: 1,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_18.png": {
            frame: {
                x: 343,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_19.png": {
            frame: {
                x: 685,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_20.png": {
            frame: {
                x: 1027,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_21.png": {
            frame: {
                x: 1369,
                y: 757,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_22.png": {
            frame: {
                x: 1711,
                y: 685,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_23.png": {
            frame: {
                x: 1,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_24.png": {
            frame: {
                x: 343,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_25.png": {
            frame: {
                x: 685,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_26.png": {
            frame: {
                x: 1027,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_27.png": {
            frame: {
                x: 1369,
                y: 1009,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_28.png": {
            frame: {
                x: 1711,
                y: 1027,
                w: 340,
                h: 250
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        },
        "a3_29.png": {
            frame: {
                x: 1,
                y: 1,
                w: 340,
                h: 250
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 340,
                h: 250
            },
            sourceSize: {
                w: 340,
                h: 250
            }
        }
    },
    Pr = {
        a3: ["a3_00.png", "a3_01.png", "a3_02.png", "a3_03.png", "a3_04.png", "a3_05.png", "a3_06.png", "a3_07.png", "a3_08.png", "a3_09.png", "a3_10.png", "a3_11.png", "a3_12.png", "a3_13.png", "a3_14.png", "a3_15.png", "a3_16.png", "a3_17.png", "a3_18.png", "a3_19.png", "a3_20.png", "a3_21.png", "a3_22.png", "a3_23.png", "a3_24.png", "a3_25.png", "a3_26.png", "a3_27.png", "a3_28.png", "a3_29.png"]
    },
    Lr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "a3@2x.png",
        format: "RGBA8888",
        size: {
            w: 1962,
            h: 1368
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:e9ee7e070a29d328607d9ef28d396809:752886bef6643bdcdd4b0a04159745b3:0aeabb21a92c1ebf80b119df9e70999a$"
    };
var Er = {
        frames: Tr,
        animations: Pr,
        meta: Lr
    },
    mt = "/assets/a3@2x.3eb6ee8a.png";
const Or = {
        "bat083.png": {
            frame: {
                x: 1783,
                y: 620,
                w: 22,
                h: 34
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 786,
                y: 27,
                w: 22,
                h: 34
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat085.png": {
            frame: {
                x: 1793,
                y: 224,
                w: 98,
                h: 157
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 710,
                y: 7,
                w: 98,
                h: 157
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat087.png": {
            frame: {
                x: 1605,
                y: 518,
                w: 221,
                h: 176
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 587,
                y: 20,
                w: 221,
                h: 176
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat089.png": {
            frame: {
                x: 1495,
                y: 990,
                w: 269,
                h: 170
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 505,
                y: 26,
                w: 269,
                h: 170
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat091.png": {
            frame: {
                x: 1282,
                y: 518,
                w: 321,
                h: 178
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 487,
                y: 1,
                w: 321,
                h: 178
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat093.png": {
            frame: {
                x: 1403,
                y: 360,
                w: 357,
                h: 156
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 451,
                y: 34,
                w: 357,
                h: 156
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat095.png": {
            frame: {
                x: 1179,
                y: 1017,
                w: 314,
                h: 112
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 427,
                y: 84,
                w: 314,
                h: 112
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat097.png": {
            frame: {
                x: 1281,
                y: 227,
                w: 202,
                h: 120
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 425,
                y: 99,
                w: 202,
                h: 120
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat099.png": {
            frame: {
                x: 1,
                y: 1637,
                w: 398,
                h: 186
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 403,
                y: 35,
                w: 398,
                h: 186
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat101.png": {
            frame: {
                x: 1494,
                y: 1162,
                w: 262,
                h: 130
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 407,
                y: 89,
                w: 262,
                h: 130
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat103.png": {
            frame: {
                x: 1629,
                y: 1607,
                w: 213,
                h: 97
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 395,
                y: 107,
                w: 213,
                h: 97
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat105.png": {
            frame: {
                x: 1605,
                y: 741,
                w: 247,
                h: 200
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 390,
                y: 7,
                w: 247,
                h: 200
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat107.png": {
            frame: {
                x: 569,
                y: 1139,
                w: 413,
                h: 173
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 395,
                y: 43,
                w: 413,
                h: 173
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat109.png": {
            frame: {
                x: 857,
                y: 461,
                w: 423,
                h: 219
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 385,
                y: 0,
                w: 423,
                h: 219
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat111.png": {
            frame: {
                x: 744,
                y: 1343,
                w: 388,
                h: 186
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 389,
                y: 31,
                w: 388,
                h: 186
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat113.png": {
            frame: {
                x: 744,
                y: 1129,
                w: 400,
                h: 212
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 381,
                y: 4,
                w: 400,
                h: 212
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat115.png": {
            frame: {
                x: 1188,
                y: 698,
                w: 309,
                h: 188
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 376,
                y: 35,
                w: 309,
                h: 188
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat117.png": {
            frame: {
                x: 1133,
                y: 1572,
                w: 276,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 369,
                y: 27,
                w: 276,
                h: 198
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat119.png": {
            frame: {
                x: 1411,
                y: 1607,
                w: 216,
                h: 181
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 369,
                y: 43,
                w: 216,
                h: 181
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat121.png": {
            frame: {
                x: 397,
                y: 1139,
                w: 447,
                h: 170
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 361,
                y: 47,
                w: 447,
                h: 170
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat123.png": {
            frame: {
                x: 1420,
                y: 224,
                w: 371,
                h: 134
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 361,
                y: 93,
                w: 371,
                h: 134
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat125.png": {
            frame: {
                x: 1188,
                y: 888,
                w: 294,
                h: 127
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 355,
                y: 101,
                w: 294,
                h: 127
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat127.png": {
            frame: {
                x: 219,
                y: 1174,
                w: 453,
                h: 176
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 355,
                y: 43,
                w: 453,
                h: 176
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat129.png": {
            frame: {
                x: 367,
                y: 700,
                w: 437,
                h: 206
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 350,
                y: 13,
                w: 437,
                h: 206
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat131.png": {
            frame: {
                x: 773,
                y: 1531,
                w: 358,
                h: 171
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 351,
                y: 49,
                w: 358,
                h: 171
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat133.png": {
            frame: {
                x: 1134,
                y: 1439,
                w: 292,
                h: 131
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 346,
                y: 96,
                w: 292,
                h: 131
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat135.png": {
            frame: {
                x: 1383,
                y: 1790,
                w: 242,
                h: 122
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 343,
                y: 106,
                w: 242,
                h: 122
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat137.png": {
            frame: {
                x: 217,
                y: 711,
                w: 461,
                h: 148
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 347,
                y: 72,
                w: 461,
                h: 148
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat139.png": {
            frame: {
                x: 446,
                y: 231,
                w: 467,
                h: 191
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 341,
                y: 30,
                w: 467,
                h: 191
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat141.png": {
            frame: {
                x: 220,
                y: 231,
                w: 465,
                h: 224
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 343,
                y: 0,
                w: 465,
                h: 224
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat143.png": {
            frame: {
                x: 772,
                y: 682,
                w: 414,
                h: 219
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 339,
                y: 12,
                w: 414,
                h: 219
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat145.png": {
            frame: {
                x: 1,
                y: 1,
                w: 471,
                h: 228
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 337,
                y: 4,
                w: 471,
                h: 228
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat147.png": {
            frame: {
                x: 423,
                y: 1588,
                w: 414,
                h: 186
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 339,
                y: 39,
                w: 414,
                h: 186
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat149.png": {
            frame: {
                x: 1,
                y: 711,
                w: 473,
                h: 214
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 335,
                y: 12,
                w: 473,
                h: 214
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat151.png": {
            frame: {
                x: 955,
                y: 1,
                w: 463,
                h: 224
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 335,
                y: 3,
                w: 463,
                h: 224
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat153.png": {
            frame: {
                x: 857,
                y: 227,
                w: 422,
                h: 232
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 0,
                w: 422,
                h: 232
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat155.png": {
            frame: {
                x: 189,
                y: 1637,
                w: 394,
                h: 232
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 0,
                w: 394,
                h: 232
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat157.png": {
            frame: {
                x: 772,
                y: 903,
                w: 405,
                h: 224
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 333,
                y: 0,
                w: 405,
                h: 224
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat159.png": {
            frame: {
                x: 773,
                y: 1704,
                w: 331,
                h: 197
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 27,
                w: 331,
                h: 197
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat161.png": {
            frame: {
                x: 1146,
                y: 1263,
                w: 294,
                h: 174
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 47,
                w: 294,
                h: 174
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat163.png": {
            frame: {
                x: 1106,
                y: 1772,
                w: 275,
                h: 188
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 36,
                w: 275,
                h: 188
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat165.png": {
            frame: {
                x: 1766,
                y: 990,
                w: 261,
                h: 169
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 54,
                w: 261,
                h: 169
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat167.png": {
            frame: {
                x: 1728,
                y: 1503,
                w: 235,
                h: 129
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 332,
                y: 90,
                w: 235,
                h: 129
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat169.png": {
            frame: {
                x: 1,
                y: 231,
                w: 478,
                h: 217
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 330,
                y: 0,
                w: 478,
                h: 217
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat171.png": {
            frame: {
                x: 639,
                y: 217,
                w: 442,
                h: 216
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 0,
                w: 442,
                h: 216
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat173.png": {
            frame: {
                x: 1,
                y: 1186,
                w: 449,
                h: 216
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 0,
                w: 449,
                h: 216
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat175.png": {
            frame: {
                x: 474,
                y: 1,
                w: 479,
                h: 214
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 3,
                w: 479,
                h: 214
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat177.png": {
            frame: {
                x: 1420,
                y: 1,
                w: 445,
                h: 221
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 332,
                y: 0,
                w: 445,
                h: 221
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat179.png": {
            frame: {
                x: 575,
                y: 700,
                w: 420,
                h: 195
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 330,
                y: 28,
                w: 420,
                h: 195
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat181.png": {
            frame: {
                x: 611,
                y: 1554,
                w: 373,
                h: 160
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 63,
                w: 373,
                h: 160
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat183.png": {
            frame: {
                x: 1146,
                y: 1131,
                w: 346,
                h: 130
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 92,
                w: 346,
                h: 130
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat185.png": {
            frame: {
                x: 611,
                y: 1929,
                w: 304,
                h: 106
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 114,
                w: 304,
                h: 106
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat187.png": {
            frame: {
                x: 1442,
                y: 1407,
                w: 283,
                h: 100
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 331,
                y: 122,
                w: 283,
                h: 100
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat189.png": {
            frame: {
                x: 1442,
                y: 1294,
                w: 284,
                h: 111
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 111,
                w: 284,
                h: 111
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat191.png": {
            frame: {
                x: 1499,
                y: 698,
                w: 264,
                h: 104
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 330,
                y: 115,
                w: 264,
                h: 104
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat193.png": {
            frame: {
                x: 1428,
                y: 1509,
                w: 261,
                h: 96
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 328,
                y: 130,
                w: 261,
                h: 96
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat195.png": {
            frame: {
                x: 1383,
                y: 1914,
                w: 242,
                h: 94
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 327,
                y: 137,
                w: 242,
                h: 94
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat197.png": {
            frame: {
                x: 1807,
                y: 620,
                w: 230,
                h: 83
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 328,
                y: 141,
                w: 230,
                h: 83
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat199.png": {
            frame: {
                x: 1783,
                y: 383,
                w: 235,
                h: 96
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 130,
                w: 235,
                h: 96
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat201.png": {
            frame: {
                x: 1830,
                y: 1808,
                w: 222,
                h: 99
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 130,
                w: 222,
                h: 99
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat203.png": {
            frame: {
                x: 1728,
                y: 1808,
                w: 220,
                h: 100
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 139,
                w: 220,
                h: 100
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat205.png": {
            frame: {
                x: 1627,
                y: 1822,
                w: 203,
                h: 91
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 324,
                y: 146,
                w: 203,
                h: 91
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat207.png": {
            frame: {
                x: 917,
                y: 1903,
                w: 187,
                h: 80
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 148,
                w: 187,
                h: 80
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat209.png": {
            frame: {
                x: 1728,
                y: 1336,
                w: 189,
                h: 86
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 324,
                y: 140,
                w: 189,
                h: 86
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat211.png": {
            frame: {
                x: 1758,
                y: 1253,
                w: 172,
                h: 81
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 142,
                w: 172,
                h: 81
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat213.png": {
            frame: {
                x: 1727,
                y: 1424,
                w: 171,
                h: 77
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 149,
                w: 171,
                h: 77
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat215.png": {
            frame: {
                x: 1867,
                y: 1,
                w: 156,
                h: 62
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 158,
                w: 156,
                h: 62
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat217.png": {
            frame: {
                x: 1859,
                y: 1503,
                w: 144,
                h: 61
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 160,
                w: 144,
                h: 61
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat219.png": {
            frame: {
                x: 1728,
                y: 1740,
                w: 143,
                h: 66
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 154,
                w: 143,
                h: 66
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat221.png": {
            frame: {
                x: 1807,
                y: 852,
                w: 132,
                h: 65
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 156,
                w: 132,
                h: 65
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat223.png": {
            frame: {
                x: 1136,
                y: 1962,
                w: 133,
                h: 58
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 163,
                w: 133,
                h: 58
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat225.png": {
            frame: {
                x: 1874,
                y: 852,
                w: 123,
                h: 53
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 170,
                w: 123,
                h: 53
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat227.png": {
            frame: {
                x: 1881,
                y: 383,
                w: 116,
                h: 54
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 168,
                w: 116,
                h: 54
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat229.png": {
            frame: {
                x: 1881,
                y: 501,
                w: 116,
                h: 54
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 166,
                w: 116,
                h: 54
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat231.png": {
            frame: {
                x: 1271,
                y: 1962,
                w: 108,
                h: 54
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 326,
                y: 166,
                w: 108,
                h: 54
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat233.png": {
            frame: {
                x: 917,
                y: 1985,
                w: 113,
                h: 50
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 324,
                y: 171,
                w: 113,
                h: 50
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat235.png": {
            frame: {
                x: 1282,
                y: 431,
                w: 106,
                h: 45
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 324,
                y: 176,
                w: 106,
                h: 45
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat237.png": {
            frame: {
                x: 1873,
                y: 1649,
                w: 99,
                h: 46
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 325,
                y: 176,
                w: 99,
                h: 46
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat239.png": {
            frame: {
                x: 1032,
                y: 1985,
                w: 102,
                h: 50
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 323,
                y: 170,
                w: 102,
                h: 50
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat241.png": {
            frame: {
                x: 639,
                y: 661,
                w: 58,
                h: 30
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 323,
                y: 189,
                w: 58,
                h: 30
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat243.png": {
            frame: {
                x: 773,
                y: 1903,
                w: 49,
                h: 24
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 329,
                y: 192,
                w: 49,
                h: 24
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat245.png": {
            frame: {
                x: 220,
                y: 698,
                w: 11,
                h: 14
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 363,
                y: 202,
                w: 11,
                h: 14
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        },
        "bat247.png": {
            frame: {
                x: 1932,
                y: 1253,
                w: 3,
                h: 3
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 3,
                h: 3
            },
            sourceSize: {
                w: 808,
                h: 454
            }
        }
    },
    Rr = {
        bat: ["bat083.png", "bat085.png", "bat087.png", "bat089.png", "bat091.png", "bat093.png", "bat095.png", "bat097.png", "bat099.png", "bat101.png", "bat103.png", "bat105.png", "bat107.png", "bat109.png", "bat111.png", "bat113.png", "bat115.png", "bat117.png", "bat119.png", "bat121.png", "bat123.png", "bat125.png", "bat127.png", "bat129.png", "bat131.png", "bat133.png", "bat135.png", "bat137.png", "bat139.png", "bat141.png", "bat143.png", "bat145.png", "bat147.png", "bat149.png", "bat151.png", "bat153.png", "bat155.png", "bat157.png", "bat159.png", "bat161.png", "bat163.png", "bat165.png", "bat167.png", "bat169.png", "bat171.png", "bat173.png", "bat175.png", "bat177.png", "bat179.png", "bat181.png", "bat183.png", "bat185.png", "bat187.png", "bat189.png", "bat191.png", "bat193.png", "bat195.png", "bat197.png", "bat199.png", "bat201.png", "bat203.png", "bat205.png", "bat207.png", "bat209.png", "bat211.png", "bat213.png", "bat215.png", "bat217.png", "bat219.png", "bat221.png", "bat223.png", "bat225.png", "bat227.png", "bat229.png", "bat231.png", "bat233.png", "bat235.png", "bat237.png", "bat239.png", "bat241.png", "bat243.png", "bat245.png", "bat247.png"]
    },
    Mr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "bat-1.png",
        format: "RGBA8888",
        size: {
            w: 1936,
            h: 2036
        },
        scale: "0.8",
        smartupdate: "$TexturePacker:SmartUpdate:8ce08bcf4c55abeb6b7fff85c20a1ac5:455049b627e848c4992c8ebc12a3649f:a5e6a6eb03371b15206352b24395ecf3$"
    };
var Dr = {
        frames: Or,
        animations: Rr,
        meta: Mr
    },
    lt = "/assets/bat-1.bda85806.png";
const Gr = {
        "bat2001.png": {
            frame: {
                x: 1490,
                y: 866,
                w: 18,
                h: 20
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 532,
                y: 269,
                w: 18,
                h: 20
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2003.png": {
            frame: {
                x: 1210,
                y: 981,
                w: 39,
                h: 24
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 512,
                y: 267,
                w: 39,
                h: 24
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2005.png": {
            frame: {
                x: 1674,
                y: 826,
                w: 47,
                h: 30
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 506,
                y: 265,
                w: 47,
                h: 30
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2007.png": {
            frame: {
                x: 673,
                y: 1449,
                w: 49,
                h: 33
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 506,
                y: 260,
                w: 49,
                h: 33
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2009.png": {
            frame: {
                x: 489,
                y: 397,
                w: 52,
                h: 34
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 507,
                y: 259,
                w: 52,
                h: 34
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2011.png": {
            frame: {
                x: 673,
                y: 1390,
                w: 57,
                h: 35
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 504,
                y: 258,
                w: 57,
                h: 35
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2013.png": {
            frame: {
                x: 1805,
                y: 969,
                w: 55,
                h: 36
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 503,
                y: 258,
                w: 55,
                h: 36
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2015.png": {
            frame: {
                x: 1144,
                y: 981,
                w: 64,
                h: 39
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 497,
                y: 255,
                w: 64,
                h: 39
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2017.png": {
            frame: {
                x: 1441,
                y: 1426,
                w: 59,
                h: 45
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 497,
                y: 249,
                w: 59,
                h: 45
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2019.png": {
            frame: {
                x: 187,
                y: 1437,
                w: 61,
                h: 47
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 498,
                y: 247,
                w: 61,
                h: 47
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2021.png": {
            frame: {
                x: 1780,
                y: 1391,
                w: 64,
                h: 48
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 495,
                y: 247,
                w: 64,
                h: 48
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2023.png": {
            frame: {
                x: 489,
                y: 336,
                w: 59,
                h: 51
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 495,
                y: 243,
                w: 59,
                h: 51
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2025.png": {
            frame: {
                x: 489,
                y: 268,
                w: 66,
                h: 54
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 491,
                y: 239,
                w: 66,
                h: 54
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2027.png": {
            frame: {
                x: 1378,
                y: 1426,
                w: 61,
                h: 65
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 491,
                y: 229,
                w: 61,
                h: 65
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2029.png": {
            frame: {
                x: 1805,
                y: 899,
                w: 61,
                h: 68
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 493,
                y: 225,
                w: 61,
                h: 68
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2031.png": {
            frame: {
                x: 1805,
                y: 826,
                w: 68,
                h: 71
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 486,
                y: 223,
                w: 68,
                h: 71
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2033.png": {
            frame: {
                x: 1627,
                y: 337,
                w: 77,
                h: 80
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 478,
                y: 216,
                w: 77,
                h: 80
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2035.png": {
            frame: {
                x: 1627,
                y: 261,
                w: 74,
                h: 85
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 479,
                y: 210,
                w: 74,
                h: 85
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2037.png": {
            frame: {
                x: 1780,
                y: 1301,
                w: 88,
                h: 98
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 468,
                y: 197,
                w: 88,
                h: 98
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2039.png": {
            frame: {
                x: 1546,
                y: 1334,
                w: 95,
                h: 104
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 463,
                y: 190,
                w: 95,
                h: 104
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2041.png": {
            frame: {
                x: 1682,
                y: 1014,
                w: 115,
                h: 110
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 438,
                y: 184,
                w: 115,
                h: 110
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2043.png": {
            frame: {
                x: 1652,
                y: 1327,
                w: 126,
                h: 121
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 429,
                y: 173,
                w: 126,
                h: 121
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2045.png": {
            frame: {
                x: 1524,
                y: 995,
                w: 156,
                h: 133
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 395,
                y: 159,
                w: 156,
                h: 133
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2047.png": {
            frame: {
                x: 1712,
                y: 530,
                w: 163,
                h: 154
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 393,
                y: 136,
                w: 163,
                h: 154
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2049.png": {
            frame: {
                x: 790,
                y: 571,
                w: 193,
                h: 173
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 358,
                y: 115,
                w: 193,
                h: 173
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2051.png": {
            frame: {
                x: 545,
                y: 575,
                w: 243,
                h: 194
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 310,
                y: 92,
                w: 243,
                h: 194
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2053.png": {
            frame: {
                x: 876,
                y: 790,
                w: 266,
                h: 230
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 287,
                y: 56,
                w: 266,
                h: 230
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2055.png": {
            frame: {
                x: 434,
                y: 1062,
                w: 326,
                h: 283
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 218,
                y: 1,
                w: 326,
                h: 283
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2057.png": {
            frame: {
                x: 1510,
                y: 699,
                w: 162,
                h: 188
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 382,
                y: 93,
                w: 162,
                h: 188
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2059.png": {
            frame: {
                x: 1165,
                y: 1190,
                w: 182,
                h: 220
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 362,
                y: 60,
                w: 182,
                h: 220
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2061.png": {
            frame: {
                x: 366,
                y: 783,
                w: 258,
                h: 277
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 282,
                y: 4,
                w: 258,
                h: 277
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2063.png": {
            frame: {
                x: 1165,
                y: 1412,
                w: 175,
                h: 80
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 370,
                y: 204,
                w: 175,
                h: 80
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2065.png": {
            frame: {
                x: 1740,
                y: 1126,
                w: 173,
                h: 83
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 368,
                y: 199,
                w: 173,
                h: 83
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2067.png": {
            frame: {
                x: 1649,
                y: 1130,
                w: 195,
                h: 89
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 350,
                y: 193,
                w: 195,
                h: 89
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2069.png": {
            frame: {
                x: 1144,
                y: 790,
                w: 189,
                h: 97
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 357,
                y: 185,
                w: 189,
                h: 97
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2071.png": {
            frame: {
                x: 1546,
                y: 1130,
                w: 202,
                h: 101
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 339,
                y: 183,
                w: 202,
                h: 101
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2073.png": {
            frame: {
                x: 719,
                y: 459,
                w: 233,
                h: 110
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 312,
                y: 174,
                w: 233,
                h: 110
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2075.png": {
            frame: {
                x: 1349,
                y: 1190,
                w: 234,
                h: 123
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 306,
                y: 158,
                w: 234,
                h: 123
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2077.png": {
            frame: {
                x: 403,
                y: 508,
                w: 267,
                h: 140
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 276,
                y: 140,
                w: 267,
                h: 140
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2079.png": {
            frame: {
                x: 1243,
                y: 699,
                w: 265,
                h: 165
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 281,
                y: 113,
                w: 265,
                h: 165
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2081.png": {
            frame: {
                x: 719,
                y: 1056,
                w: 294,
                h: 214
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 246,
                y: 65,
                w: 294,
                h: 214
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2083.png": {
            frame: {
                x: 1,
                y: 783,
                w: 363,
                h: 277
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 184,
                y: 0,
                w: 363,
                h: 277
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2085.png": {
            frame: {
                x: 1,
                y: 508,
                w: 400,
                h: 273
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 143,
                y: 0,
                w: 400,
                h: 273
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2087.png": {
            frame: {
                x: 1,
                y: 268,
                w: 486,
                h: 238
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 63,
                y: 31,
                w: 486,
                h: 238
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2089.png": {
            frame: {
                x: 1,
                y: 1,
                w: 522,
                h: 265
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 29,
                y: 0,
                w: 522,
                h: 265
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2091.png": {
            frame: {
                x: 1271,
                y: 432,
                w: 305,
                h: 265
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 237,
                y: 0,
                w: 305,
                h: 265
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2093.png": {
            frame: {
                x: 1358,
                y: 1,
                w: 360,
                h: 258
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 187,
                y: 1,
                w: 360,
                h: 258
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2095.png": {
            frame: {
                x: 525,
                y: 1,
                w: 436,
                h: 256
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 101,
                y: 0,
                w: 436,
                h: 256
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2097.png": {
            frame: {
                x: 1,
                y: 1062,
                w: 373,
                h: 247
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 167,
                y: 4,
                w: 373,
                h: 247
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2099.png": {
            frame: {
                x: 1163,
                y: 1022,
                w: 237,
                h: 166
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 301,
                y: 83,
                w: 237,
                h: 166
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2101.png": {
            frame: {
                x: 965,
                y: 570,
                w: 276,
                h: 218
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 249,
                y: 28,
                w: 276,
                h: 218
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2103.png": {
            frame: {
                x: 935,
                y: 1022,
                w: 227,
                h: 226
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 302,
                y: 24,
                w: 227,
                h: 226
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2105.png": {
            frame: {
                x: 626,
                y: 771,
                w: 283,
                h: 248
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 235,
                y: 0,
                w: 283,
                h: 248
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2107.png": {
            frame: {
                x: 545,
                y: 259,
                w: 314,
                h: 172
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 209,
                y: 73,
                w: 314,
                h: 172
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2109.png": {
            frame: {
                x: 963,
                y: 1,
                w: 393,
                h: 237
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 133,
                y: 5,
                w: 393,
                h: 237
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2111.png": {
            frame: {
                x: 1402,
                y: 1022,
                w: 165,
                h: 120
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 349,
                y: 117,
                w: 165,
                h: 120
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2113.png": {
            frame: {
                x: 1674,
                y: 686,
                w: 193,
                h: 138
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 330,
                y: 99,
                w: 193,
                h: 138
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2115.png": {
            frame: {
                x: 1712,
                y: 338,
                w: 190,
                h: 162
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 319,
                y: 64,
                w: 190,
                h: 162
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2117.png": {
            frame: {
                x: 719,
                y: 259,
                w: 242,
                h: 198
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 272,
                y: 19,
                w: 242,
                h: 198
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2119.png": {
            frame: {
                x: 954,
                y: 1251,
                w: 225,
                h: 209
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 286,
                y: 0,
                w: 225,
                h: 209
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2121.png": {
            frame: {
                x: 1578,
                y: 432,
                w: 241,
                h: 132
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 249,
                y: 69,
                w: 241,
                h: 132
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2123.png": {
            frame: {
                x: 719,
                y: 1352,
                w: 233,
                h: 146
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 263,
                y: 55,
                w: 233,
                h: 146
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2125.png": {
            frame: {
                x: 1243,
                y: 866,
                w: 245,
                h: 154
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 230,
                y: 35,
                w: 245,
                h: 154
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2127.png": {
            frame: {
                x: 963,
                y: 386,
                w: 306,
                h: 182
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 173,
                y: 5,
                w: 306,
                h: 182
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2129.png": {
            frame: {
                x: 250,
                y: 1062,
                w: 378,
                h: 182
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 96,
                y: 0,
                w: 378,
                h: 182
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2131.png": {
            frame: {
                x: 963,
                y: 240,
                w: 330,
                h: 144
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 114,
                y: 24,
                w: 330,
                h: 144
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2133.png": {
            frame: {
                x: 1295,
                y: 261,
                w: 330,
                h: 169
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 128,
                y: 0,
                w: 330,
                h: 169
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2135.png": {
            frame: {
                x: 1720,
                y: 1,
                w: 335,
                h: 155
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 100,
                y: 0,
                w: 335,
                h: 155
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2137.png": {
            frame: {
                x: 1706,
                y: 826,
                w: 186,
                h: 97
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 254,
                y: 45,
                w: 186,
                h: 97
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2139.png": {
            frame: {
                x: 1490,
                y: 889,
                w: 214,
                h: 104
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 210,
                y: 22,
                w: 214,
                h: 104
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2141.png": {
            frame: {
                x: 434,
                y: 1390,
                w: 237,
                h: 105
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 125,
                y: 0,
                w: 237,
                h: 105
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2143.png": {
            frame: {
                x: 1,
                y: 1437,
                w: 184,
                h: 59
            },
            rotated: !1,
            trimmed: !0,
            spriteSourceSize: {
                x: 69,
                y: 29,
                w: 184,
                h: 59
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2145.png": {
            frame: {
                x: 1474,
                y: 1189,
                w: 235,
                h: 70
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 235,
                h: 70
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        },
        "bat2147.png": {
            frame: {
                x: 1342,
                y: 1426,
                w: 72,
                h: 34
            },
            rotated: !0,
            trimmed: !0,
            spriteSourceSize: {
                x: 88,
                y: 18,
                w: 72,
                h: 34
            },
            sourceSize: {
                w: 1010,
                h: 568
            }
        }
    },
    Nr = {
        bat: ["bat2001.png", "bat2003.png", "bat2005.png", "bat2007.png", "bat2009.png", "bat2011.png", "bat2013.png", "bat2015.png", "bat2017.png", "bat2019.png", "bat2021.png", "bat2023.png", "bat2025.png", "bat2027.png", "bat2029.png", "bat2031.png", "bat2033.png", "bat2035.png", "bat2037.png", "bat2039.png", "bat2041.png", "bat2043.png", "bat2045.png", "bat2047.png", "bat2049.png", "bat2051.png", "bat2053.png", "bat2055.png", "bat2057.png", "bat2059.png", "bat2061.png", "bat2063.png", "bat2065.png", "bat2067.png", "bat2069.png", "bat2071.png", "bat2073.png", "bat2075.png", "bat2077.png", "bat2079.png", "bat2081.png", "bat2083.png", "bat2085.png", "bat2087.png", "bat2089.png", "bat2091.png", "bat2093.png", "bat2095.png", "bat2097.png", "bat2099.png", "bat2101.png", "bat2103.png", "bat2105.png", "bat2107.png", "bat2109.png", "bat2111.png", "bat2113.png", "bat2115.png", "bat2117.png", "bat2119.png", "bat2121.png", "bat2123.png", "bat2125.png", "bat2127.png", "bat2129.png", "bat2131.png", "bat2133.png", "bat2135.png", "bat2137.png", "bat2139.png", "bat2141.png", "bat2143.png", "bat2145.png", "bat2147.png"]
    },
    $r = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "bat-2.png",
        format: "RGBA8888",
        size: {
            w: 1879,
            h: 1499
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:c7953bd65ff4d4218d0b321a2ef55fa9:887d3b05ed88430ca29aab5ccc01840b:9423740c85c33609f7022e8d1dfdbb47$"
    };
var Wr = {
        frames: Gr,
        animations: Nr,
        meta: $r
    },
    wt = "/assets/bat-2.f4c3e0a9.png",
    Pe = "/assets/font.4de92b02.xml",
    Le = "/assets/font@2x.6cc58b25.png",
    St = "/assets/VampireBrideBold.d7c27cfa.woff";
const Hr = i => {
        let o = i.split("/").pop();
        if (!o) throw new Error("not ext");
        let e = o.split(".")[0],
            t = document.createElement("style"),
            s = "@font-face {font-family: '" + e + "'; src: url('" + i + "');}";
        return t.appendChild(document.createTextNode(s)), document.head.appendChild(t), new Qt(e).load("test", 1e4).catch(console.log)
    },
    _ = {
        bg: er,
        bg2: tr,
        sheets: Me,
        bats1: lt,
        bats2: wt,
        books: ct,
        gems: ht,
        cross: ut,
        a1s: pt,
        a2s: dt,
        a3s: mt,
        font_xml: Pe,
        font_png: Le,
        font: St,
        rous: nt
    },
    z = {},
    u = i => {
        var o;
        return (o = z[Me].spritesheet) == null ? void 0 : o.textures[`${i}.png`]
    };

function Fr(i) {
    return new Promise(o => {
        i.add(Object.values(_)).load((e, t) => {
            Object.assign(z, t), o(t)
        })
    }).then(() => {
        const o = z[Pe].data,
            e = o.createElement("page");
        e.setAttribute("file", Le), e.setAttribute("id", "0"), o.children[0].appendChild(e), Ht.install(z[Pe].data, z[Le].texture, !0)
    }).then(() => Promise.all([Hr(St), P(Me, ar), P(lt, Dr), P(wt, Wr), P(nt, ur), P(ht, mr), P(ct, br), P(ut, gr), P(pt, kr), P(dt, Ir), P(mt, Er)]))
}

function P(i, o) {
    return new Promise(e => {
        const t = new et(z[i].texture.baseTexture, o);
        t.parse(() => {
            z[i].spritesheet = t, e(t)
        })
    })
}
var D = (i => (i[i.BIBLE = 0] = "BIBLE", i[i.CROSS = 1] = "CROSS", i[i.GEM = 2] = "GEM", i[i.SKULL = 3] = "SKULL", i))(D || {});
const Ee = {
        [0]: "bible",
        [1]: "cross",
        [2]: "gem",
        [3]: "skull"
    },
    $ = class extends v {
        constructor(e) {
            super();
            r(this, "type");
            r(this, "bg");
            r(this, "suitSprite");
            r(this, "suitAne");
            this.type = e, this.onAneComplete = this.onAneComplete.bind(this), this.drawSprite()
        }
        drawSprite() {
            this.bg = new m(u("l_box1_1")), this.bg.anchor.set(.5), this.bg.x = $.width / 2, this.bg.y = $.height / 2, this.addChild(this.bg);
            let e = new m(u(Ee[this.type]));
            e.anchor.set(.5), e.x = $.width / 2, e.y = $.height / 2, this.suitSprite = e, this.addChild(e)
        }
        drawAne() {}
        playAne() {
            this.suitAne.visible = !0, this.suitAne.gotoAndPlay(0), this.suitAne.onComplete = this.onAneComplete
        }
        onAneComplete() {
            this.suitAne.visible = !1
        }
        drawArea(e = 16777215) {
            let t = new oe;
            t.beginFill(e), t.drawRect(0, 0, $.width, $.height), t.endFill(), t.alpha = .2, this.addChild(t)
        }
    };
let b = $;
r(b, "width", 346), r(b, "height", 200);

function Vr(i) {
    return i < 10 ? 1 : i < 50 ? 2 : i < 100 ? 3 : 4
}

function jr(i = .5) {
    return o => --o * o * ((i + 1) * o + i) + 1
}
const gt = (i = 0) => new Promise(o => w.delayedCall(i / 1e3, o)),
    se = class extends v {
        constructor() {
            super();
            r(this, "suits", []);
            r(this, "scrollContainer");
            r(this, "scrollWrap");
            r(this, "scrollMask");
            r(this, "bg");
            r(this, "box");
            r(this, "scrollTop", 0);
            r(this, "anes", []);
            r(this, "aneContainer");
            r(this, "blur");
            this.scrollTo = this.scrollTo.bind(this), this.renderGraph(), this.renderScrollContainer(), this.renderSuits(), this.renderBg(), this.renderAne2(), this.layout(), this.jumpTo(2), this.on("removed", () => {
                w.killTweensOf(this)
            })
        }
        renderGraph() {
            this.bg = new oe, this.bg.beginFill(1250868), this.bg.drawRect(0, 0, 100, 100), this.bg.endFill(), this.addChild(this.bg)
        }
        renderBg() {
            this.box = new m(u("l_box1")), this.addChild(this.box)
        }
        scrollTo(e) {
            let t = e;
            e == l.NONE && (t = Math.round(Math.random() * 1e4) % 4 + .5), c.playSound("SkeletonSound");
            let s;
            return s = `ReelRotatelevel${Vr(c.payout)}`, c.playSound(s), new Promise(n => {
                let p = t * (b.height + se.space),
                    y = (this.suits.length - 1) * (b.height + se.space);
                this.scrollTop = this.scrollTop % y, this.scrollTop < p && (this.scrollTop += y), this.scrollTop += y * 2;
                let k = w.to(this, {
                    pixi: {
                        scrollTop: p
                    },
                    ease: jr(.3),
                    duration: 1,
                    onComplete: n,
                    onUpdate: () => {
                        let C = k.progress();
                        C > .8 ? this.blur.enabled = !1 : (this.blur.enabled = !0, this.blur.blurY = (.8 - C) * 40), this.scrollWrap.y = -this.scrollTop % y
                    }
                })
            }).then(() => {
                e == l.TOP && (e = l.MIDDLE), !(e > l.RIGHT) && c.layers[e] == c.payouts[e].length - 2 && this.playAne(e)
            })
        }
        jumpTo(e) {
            let t = e;
            e == l.NONE && (t = Math.round(Math.random() * 1e4) % 4 + .5), this.scrollTop = t * (b.height + se.space), this.scrollWrap.y = -this.scrollTop
        }
        renderSuits() {
            this.blur.blurX = 0, this.blur.blurY = 0, this.blur.enabled = !1, this.suits = [new b(D.BIBLE), new b(D.CROSS), new b(D.GEM), new b(D.SKULL), new b(D.BIBLE)], this.suits.forEach((e, t) => {
                e.y = t * (b.height + se.space), this.scrollWrap.addChild(e)
            })
        }
        renderScrollContainer() {
            let e = new oe;
            e.beginFill(0), e.drawRect(0, 0, b.width, b.height), e.endFill(), this.scrollContainer = new v, this.scrollWrap = new v, this.scrollContainer.mask = e, this.blur = new Ft.BlurFilter, this.scrollWrap.filters = [this.blur], this.addChild(this.scrollContainer, e), this.scrollContainer.addChild(this.scrollWrap), this.scrollMask = e
        }
        renderAne2() {
            this.aneContainer = new v, this.addChild(this.aneContainer);
            let t = [_.books, _.cross, _.gems].map(s => {
                var p;
                let a = Object.values((p = z[s].spritesheet) == null ? void 0 : p.textures),
                    n = new ne(a);
                return n.anchor.set(.5), n.animationSpeed = .3, n.width *= 2, n.height *= 2, n.loop = !1, n.visible = !1, this.aneContainer.addChild(n), n
            });
            this.anes.push(...t), this.stopAllAne()
        }
        playAne(e) {
            if (e == l.TOP && (e = l.MIDDLE), e > 2) return;
            let t = this.anes[e];
            t.visible = !0, t.gotoAndPlay(0), t.onComplete = () => {
                this.stopAne(e)
            }
        }
        stopAne(e) {
            this.anes[e].visible = !1, this.anes[e].gotoAndStop(0)
        }
        stopAllAne() {
            this.anes.forEach((e, t) => {
                this.stopAne(t)
            })
        }
        layout() {
            this.scrollContainer.position.set(30, 26), this.scrollMask.position.set(30, 26), this.aneContainer.position.set(this.box.width / 2, this.box.height / 2), this.aneContainer.children[0].position.set(4, 2), this.aneContainer.children[1].position.set(5.2, -1.5), this.aneContainer.children[2].position.set(3.8, -1), this.bg.position.set(30, 26), this.bg.width = b.width, this.bg.height = b.height
        }
    };
let fe = se;
r(fe, "space", 40);
class ge extends m {
    constructor(e, t = e) {
        super(e);
        r(this, "_disabled", !1);
        r(this, "isPointerDown", !1);
        r(this, "baseTexture");
        r(this, "disabledTexture");
        r(this, "tween");
        this.interactive = !0, this.buttonMode = !0, this.anchor.set(.5), this.baseTexture = e, this.disabledTexture = t, this.onPointerDown = this.onPointerDown.bind(this), this.onPointerUp = this.onPointerUp.bind(this), this.on("pointerdown", this.onPointerDown), this.on("pointerup", this.onPointerUp), this.on("pointerupoutside", this.onPointerUp), this.tween = w.to(this, .2, {
            pixi: {
                scale: .9
            }
        }).pause(), this.on("removed", () => {
            this.tween.kill()
        })
    }
    onPointerDown() {
        this.isPointerDown = !0, !this.disabled && this.tween.play()
    }
    onPointerUp() {
        this.isPointerDown = !1, !this.disabled && this.tween.reverse()
    }
    onPointerCancel() {}
    get disabled() {
        return this._disabled
    }
    set disabled(e) {
        this._disabled != e && (this._disabled = e, this.texture = e ? this.disabledTexture : this.baseTexture)
    }
}
const X = class extends v {
    constructor() {
        super();
        r(this, "title1");
        r(this, "title2");
        r(this, "colletButton");
        r(this, "partialButton");
        r(this, "upButton");
        r(this, "downButton");
        r(this, "cashpot");
        r(this, "auto");
        r(this, "_profit");
        r(this, "updateDisposer");
        this.updateView = this.updateView.bind(this), this.y = 300, this.drawTitle(), this.drawCashpot(), this.drawCollectButton(), this.drawPartialButton(), this.renderAuto(), this.layout(), this.dataBind(), this.updateDisposer = K(this.updateView), this.on("removed", () => {
            Be.lockSyncAmount(!1), this.updateDisposer()
        })
    }
    drawCollectButton() {
        let e = new ge(u("button1_2"), u("button1")),
            t = this.createButtonText("COLLECT");
        e.addChild(t), this.addChild(e), this.colletButton = e
    }
    drawPartialButton() {
        let e = new ge(u("button1_2"), u("button1")),
            t = this.createButtonText("PARTIAL COLLECT");
        e.addChild(t), this.addChild(e), this.partialButton = e
    }
    drawTitle() {
        let e = new m(u("text_cashpot"));
        e.anchor.set(.5);
        let t = this.createTitleText("AUTO TOP TO");
        this.addChild(e), this.addChild(t), this.title1 = e, this.title2 = t
    }
    drawCashpot() {
        let e = new m(u("l_box3")),
            t = this.createInputText("");
        t.y = e.height / 2, t.x = e.width / 2, e.pivot.x = e.width / 2, e.pivot.y = e.height / 2, e.addChild(t), this.addChild(e), this.cashpot = e
    }
    updateView() {
        let e = c.cashpot == 0;
        this.cashpot.children[0].text = kt(c.cashpot), this.cashpot.texture = u(e ? "l_box3" : "l_box3_2");
        let t = c.betLoading || c.cashpot == 0;
        this.colletButton.disabled = t, this.partialButton.disabled = t, this.auto.children[0].text = `${c.autoStop}x`
    }
    renderAuto() {
        let t = new m(u("l_box4"));
        t.pivot.x = t.width / 2, t.pivot.y = t.height / 2;
        let s = this.createInputText("");
        s.y = t.height / 2, s.x = t.width / 2, t.addChild(s);
        let a = new ge(u("b_plus"));
        a.anchor.set(.5), a.position.set(a.width / 2 + 6, t.height / 2 - .5), a.rotation = Math.PI, t.addChild(a), this.upButton = a;
        let n = new ge(u("b_minus"));
        n.anchor.set(.5), n.position.set(t.width - a.width / 2 - 6, t.height / 2 - .5), t.addChild(n), this.downButton = n, this.addChild(t), this.auto = t
    }
    createButtonText(e) {
        return this.createText(e, 11.2, 16634200)
    }
    createTitleText(e) {
        return this.createText(e, 13, 8029872)
    }
    createInputText(e) {
        return this.createText(e, 16, 14924174)
    }
    createText(e, t, s = 8029872) {
        let a = new tt(e, {
            fontSize: t,
            fontFamily: "VampireBrideBold",
            fill: s
        });
        return a.anchor.set(.5), a
    }
    layout() {
        let e = -this.title1.height / 2;
        this.title1.x = X.width / 2, e += this.title1.height, e += 6, e += this.cashpot.height / 2, this.colletButton.x = this.partialButton.width / 2, this.colletButton.y = e, this.partialButton.x = X.width - this.partialButton.width / 2, this.partialButton.y = e, this.cashpot.x = X.width / 2, this.cashpot.y = e, e += this.cashpot.height / 2, e += 12, e += this.title2.height / 2, this.title2.x = X.width / 2, this.title2.y = e, e += this.title2.height / 2, e += 6, e += this.auto.height / 2, this.auto.x = X.width / 2, this.auto.y = e
    }
    dataBind() {
        let e = !1;
        this.colletButton.on("pointertap", async () => {
            e || this.colletButton.disabled || (e = !0, c.playSound("PressCollectCashPotSound"), await c.collectAll(t => (e = !1, L.instance.showProfit(new H(c.amount).mul(t).toNumber()))), e = !1)
        }), this.partialButton.on("pointertap", async () => {
            this.partialButton.disabled || (c.playSound("PressCollectCashPotSound"), await c.partialCollect(t => L.instance.showProfit(new H(c.amount).mul(t).toNumber())))
        }), this.upButton.on("pointertap", c.addAutoStop), this.downButton.on("pointertap", c.subAutoStop)
    }
};
let xe = X;
r(xe, "width", 350);
const De = class extends v {
    constructor() {
        super();
        r(this, "bg");
        r(this, "plate");
        r(this, "border");
        r(this, "borderAne");
        r(this, "btn");
        r(this, "ringArc", 0);
        r(this, "ringAne");
        r(this, "activeSprite");
        r(this, "activeAne");
        r(this, "watchList", []);
        this.renderBg(), this.renderPlate(), this.renderButton(), this.renderAnes(), this.layout(), this.on("removed", () => {
            this.borderAne.kill(), this.activeAne.kill(), w.killTweensOf(this)
        })
    }
    renderPlate() {
        let e = new m(u("ring_2"));
        e.anchor.set(.5), e.y = e.height / 2, this.plate = e, this.border = new m(u("ring_border")), this.border.anchor.set(.5), this.border.scale.set(2.85), this.border.alpha = 0, this.borderAne = w.to(this.border, {
            duration: .15,
            pixi: {
                alpha: 1
            },
            ease: "none",
            repeat: 9,
            yoyo: !0,
            paused: !0
        }), this.activeSprite = new m(u("ring_arc")), this.activeSprite.anchor.set(.5), this.activeSprite.pivot.y = -69, this.activeSprite.alpha = 0, this.activeAne = w.to(this.activeSprite, {
            duration: .15,
            pixi: {
                alpha: 1
            },
            ease: "none",
            repeat: 5,
            yoyo: !0,
            paused: !0
        }), this.plate.addChild(this.activeSprite), this.addChild(this.plate, this.border)
    }
    renderBg() {
        let e = new m(u("s_bg5"));
        e.pivot.x = e.width / 2, this.addChild(e), this.bg = e
    }
    renderButton() {
        let e = new m(u("ring_1"));
        e.anchor.set(.5), this.addChild(e), this.btn = e
    }
    renderAnes() {
        var t;
        let e = Object.values((t = z[_.rous].spritesheet) == null ? void 0 : t.textures);
        this.ringAne = new ne(e), this.ringAne.visible = !1, this.ringAne.loop = !1, this.ringAne.scale.set(1.85), this.ringAne.anchor.set(.5), this.ringAne.animationSpeed = .2, this.ringAne.y = this.plate.y, this.addChild(this.ringAne)
    }
    playAne() {
        this.ringAne.visible = !0, this.ringAne.gotoAndPlay(0), this.ringAne.onComplete = () => this.ringAne.visible = !1
    }
    rotaTo(e) {
        return e = De.valueIndexDict[e], new Promise(t => {
            let s = (e + .5) * Math.PI * 2 / 5 + Math.PI * 25;
            s += (Math.random() - .5) * Math.PI * 2 / 5 * .6, this.ringArc = this.ringArc % (Math.PI * 2), this.playAne(), w.delayedCall(4.5, () => {
                this.activeSprite.rotation = -(e + .5) * Math.PI * 2 / 5 - Math.PI, this.activeAne.restart()
            });
            let a = w.to(this, 5, {
                ringArc: s,
                ease: At.easeOut,
                onComplete: () => {
                    w.delayedCall(.5, t)
                },
                onUpdate: () => {
                    a.progress(), this.plate.rotation = this.ringArc
                }
            })
        })
    }
    layout() {
        this.bg.position.set(0, 206), this.border.position.set(0, this.plate.height / 2), this.btn.position.set(0, this.plate.height * .5)
    }
};
let ce = De;
r(ce, "size", 300), r(ce, "valueIndexDict", [2, 3, 4, 0, 1]);
var be = (i => (i[i.NORMAL = 0] = "NORMAL", i[i.SELECTED = 1] = "SELECTED", i[i.ACTIVED = 2] = "ACTIVED", i))(be || {});
const _e = class extends tt {
    constructor(e) {
        super(`${e.toFixed(1)}X`, {
            fontSize: 12,
            fontFamily: "VampireBrideBold",
            fill: _e.colors[0]
        });
        r(this, "opt");
        r(this, "_state", 0);
        this.anchor.set(.5)
    }
    get state() {
        return this._state
    }
    set state(e) {
        this._state != e && (this._state = e, this.updateColor())
    }
    reset() {
        this.state = 0
    }
    updateColor() {
        this.style.fill = _e.colors[this.state]
    }
};
let ze = _e;
r(ze, "colors", [10198983, 16642438, 16642438]);
class Ae {
    constructor(o, e, t) {
        r(this, "width");
        r(this, "width2");
        r(this, "height");
        r(this, "w2h");
        r(this, "h2w");
        this.width = o, this.width2 = e, this.height = t, this.w2h = We([o, e], [0, t]), this.h2w = We([0, t], [o, e])
    }
    getHeightByWidth(o) {
        return this.w2h(o)
    }
    getWidthByHeight(o) {
        return this.h2w(o)
    }
}
const I = class extends v {
    constructor(e, t, s, a, n) {
        super();
        r(this, "type");
        r(this, "stepIndex", -1);
        r(this, "stepNums");
        r(this, "steps", []);
        r(this, "bg");
        r(this, "bgActive");
        r(this, "box");
        r(this, "area");
        r(this, "stepHeight");
        r(this, "pointer");
        r(this, "textContainer");
        this.stepNums = e, this.area = n, this.stepHeight = this.area.height / e.length, this.renderBg(), this.renderBgActive(), this.renderBox(t, a), this.renderTextLayer(e, s), this.on("removed", () => {
            w.killTweensOf(this.pointer), w.killTweensOf(this.bgActive.mask)
        })
    }
    renderTextLayer(e, t) {
        this.textContainer = new v, this.textContainer.zIndex = 10, this.textContainer.pivot.x = I.maskTrap.width2 / 2, this.addChild(this.textContainer);
        const s = new rt(t, 8, 0, 8, 0);
        s.height = 40, s.pivot.y = s.height * .5, s.visible = !1, this.pointer = s, this.textContainer.addChild(s), e.forEach((a, n) => {
            const p = new ze(a);
            p.x = I.maskTrap.width2 / 2, p.y = (e.length - n - .5) * this.stepHeight, p.zIndex = 20, this.steps.push(p), this.textContainer.addChild(p)
        })
    }
    renderBg() {
        const e = new m(u("s_bg0"));
        e.pivot.x = e.width / 2, e.tint = 4284048;
        const t = this.area.height + 2,
            s = new oe;
        s.beginFill(16777215), s.drawRect(0, I.maskTrap.height - t, I.maskTrap.width2, t), s.endFill(), e.addChild(s), e.mask = s, this.bg = e, this.addChild(e)
    }
    renderBgActive() {
        const e = new m(u("s_bg0"));
        e.pivot.x = e.width / 2, e.visible = !1;
        const t = this.area.height + 2,
            s = new oe;
        s.beginFill(16777215), s.drawRect(0, I.maskTrap.height - t, I.maskTrap.width2, t), s.endFill(), e.mask = s, e.addChild(s);
        const a = this.stepNums.length - 1;
        for (let n = 0; n < a; n++) {
            const p = new m(u("line"));
            p.alpha = .5, p.anchor.set(.5), p.x = I.maskTrap.width2 / 2, p.y = I.maskTrap.height - t + (n + 1) * this.stepHeight, p.width = this.area.getWidthByHeight((a - n) / (a + 2) * this.area.height), e.addChild(p)
        }
        this.bgActive = e, this.addChild(e)
    }
    renderBox(e, t) {
        const s = new m(e),
            a = new m(t);
        a.anchor.set(.5), a.position.set(0, s.height - 20), a.zIndex = 11, s.anchor.x = .5, this.addChild(s), this.addChild(a), this.box = s
    }
    async onBigWin(e) {}
    async movePointer(e, t = !0) {
        const s = Math.max(0, e - 1),
            a = (this.steps.length - s - .5) * this.stepHeight,
            n = this.area.getWidthByHeight((s + 1) * this.stepHeight) + 8,
            p = (I.maskTrap.width2 - n) / 2;
        e > 0 && (this.pointer.visible = !0, this.bgActive.visible = !0), await new Promise(y => {
            if (!t || s == 0 && this.stepIndex == 1) this.pointer.x = p, this.pointer.y = a, this.pointer.width = n, this.bgActive.mask.y = a, y();
            else {
                if (this._destroyed) return;
                w.to(this.pointer, .2, {
                    pixi: {
                        x: p,
                        y: a,
                        width: n
                    },
                    onComplete: y
                }), w.to(this.bgActive.mask, .2, {
                    pixi: {
                        y: a
                    }
                })
            }
        }), e == 0 && (this.pointer.visible = !1, this.bgActive.visible = !1)
    }
    layout() {
        this.box.width;
        const e = this.box.height;
        this.bg.y = e - this.bg.height - 40, this.bgActive.y = e - this.bgActive.height - 40, this.textContainer.y = e - this.area.height - 40 - 3
    }
    setStep(e) {
        if (e != this.stepIndex) {
            if (this.stepIndex != -1 && this.stepIndex < e) switch (this.type) {
                case l.LEFT:
                    c.playSound(`RosaryBonusLevel${e}`);
                    break;
                case l.MIDDLE:
                    c.playSound(`CrossBonusLevel${e}`);
                    break;
                case l.RIGHT:
                    c.playSound(`RedGemsBonusLevel${e}`);
                    break
            }
            this.steps.forEach((t, s) => {
                s == e - 1 ? t.state = be.ACTIVED : s < e - 1 ? t.state = be.SELECTED : t.state = be.NORMAL
            }), this.movePointer(e), this.stepIndex = e
        }
    }
};
let ae = I;
r(ae, "maskTrap", new Ae(69.5, 114, 195.5));
class Ur extends ae {
    constructor() {
        super(c.payouts[l.LEFT].slice(1, -1), u("s_bg2"), u("s_ac2"), u("bible_2"), new Ae(69.5, 99, 124));
        r(this, "ane");
        r(this, "bigWinPayout", 0);
        r(this, "updateDisposer");
        let e = c.payouts[l.LEFT];
        this.bigWinPayout = e[e.length - 1] - e[e.length - 2], this.updateView = this.updateView.bind(this), this.type = l.LEFT, this.bgActive.tint = 2526332, this.bgActive.children.forEach(t => {
            t instanceof m && (t.tint = 1742968)
        }), this.renderBigWin(), this.layout(), this.updateDisposer = K(this.updateView), this.sortChildren(), this.on("removed", () => {
            this.updateDisposer()
        })
    }
    renderBigWin() {
        var s;
        let e = Object.values((s = z[_.a1s].spritesheet) == null ? void 0 : s.textures),
            t = new ne(e);
        t.anchor.set(.5), t.loop = !1, t.visible = !1, t.animationSpeed = .2, this.addChild(t), this.ane = t
    }
    async playAne() {
        return new Promise(e => {
            this.ane.gotoAndPlay(0), this.ane.onComplete = () => {
                this.ane.gotoAndStop(0), e()
            }
        })
    }
    async onBigWin() {
        var e;
        await this.playAne(), await ((e = L.instance) == null ? void 0 : e.showProfit(new H(c.amount).mul(this.bigWinPayout).toNumber(), D.BIBLE))
    }
    updateView() {
        let e = c.layers[l.LEFT] == 0;
        this.box.texture = u(e ? "s_bg2" : "s_bg2_2");
        let t = c.layers[l.LEFT] == c.payouts[l.LEFT].length - 2;
        this.ane.visible = t
    }
    layout() {
        super.layout(), this.ane.position.set(.5, 31.6)
    }
}
class Jr extends ae {
    constructor(e) {
        super(c.payouts[l.MIDDLE].slice(1, -1), u("s_bg3"), u("s_ac1"), u("cross_2"), new Ae(69.5, 108, 165));
        r(this, "ring");
        r(this, "ane");
        r(this, "watchList", []);
        r(this, "updateDisposer");
        this.updateView = this.updateView.bind(this), this.type = l.MIDDLE, this.bgActive.tint = 5596107, this.bgActive.children.forEach(t => {
            t instanceof m && (t.tint = 9216255)
        }), this.ring = e, this.renderBigWin(), this.layout(), this.updateDisposer = K(this.updateView), this.sortChildren(), this.on("removed", () => {
            this.updateDisposer()
        })
    }
    renderBigWin() {
        var s;
        let e = Object.values((s = z[_.a2s].spritesheet) == null ? void 0 : s.textures),
            t = new ne(e);
        t.anchor.set(.5), t.loop = !1, t.visible = !1, t.animationSpeed = .2, this.addChild(t), this.ane = t
    }
    async playAne() {
        return new Promise(e => {
            this.ane.gotoAndPlay(0), this.ane.onComplete = () => {
                this.ane.gotoAndStop(0), e()
            }
        })
    }
    async onBigWin(e) {
        var s;
        await gt(2e3), c.playSound("ActionSpin"), this.ring.borderAne.restart(), await this.playAne(), await this.ring.rotaTo(e);
        let t = c.payouts[3][e];
        await ((s = L.instance) == null ? void 0 : s.showProfit(new H(c.amount).mul(t).toNumber(), D.CROSS))
    }
    updateView() {
        let e = c.layers[l.MIDDLE] == 0;
        this.ring.plate.texture = u(e ? "ring" : "ring_2"), this.ring.bg.texture = u(e ? "s_bg5" : "s_bg5_2"), this.box.texture = u(e ? "s_bg3" : "s_bg3_2");
        let t = c.layers[l.MIDDLE] == c.payouts[l.MIDDLE].length - 2;
        this.ane.visible = t
    }
    layout() {
        super.layout(), this.ane.position.set(0, 21.3)
    }
}
class Zr extends ae {
    constructor() {
        super(c.payouts[l.RIGHT].slice(1, -1), u("s_bg4"), u("s_ac3"), u("gem_2"), new Ae(69.5, 99, 146));
        r(this, "ane");
        r(this, "bigWinPayout", 0);
        r(this, "updateDisposer");
        let e = c.payouts[l.RIGHT];
        this.bigWinPayout = e[e.length - 1] - e[e.length - 2], this.updateView = this.updateView.bind(this), this.type = l.RIGHT, this.bgActive.tint = 9918315, this.bgActive.children.forEach(t => {
            t instanceof m && (t.tint = 13332358)
        }), this.renderBigWin(), this.layout(), this.updateDisposer = K(this.updateView), this.sortChildren(), this.on("removed", () => {
            this.updateDisposer()
        })
    }
    renderBigWin() {
        var s;
        let e = Object.values((s = z[_.a3s].spritesheet) == null ? void 0 : s.textures),
            t = new ne(e);
        t.anchor.set(.5), t.loop = !1, t.visible = !1, t.animationSpeed = .2, this.addChild(t), this.ane = t
    }
    async playAne() {
        return new Promise(e => {
            this.ane.gotoAndPlay(0), this.ane.onComplete = () => {
                this.ane.gotoAndStop(0), e()
            }
        })
    }
    async onBigWin() {
        var e;
        await this.playAne(), await ((e = L.instance) == null ? void 0 : e.showProfit(new H(c.amount).mul(this.bigWinPayout).toNumber(), D.GEM))
    }
    updateView() {
        let e = c.layers[l.RIGHT] == 0;
        this.box.texture = u(e ? "s_bg4" : "s_bg4_2");
        let t = c.layers[l.RIGHT] == c.payouts[l.RIGHT].length - 2;
        this.ane.visible = t
    }
    layout() {
        super.layout(), this.ane.position.set(0, 31)
    }
}
const pe = class extends v {
    constructor() {
        super();
        r(this, "ring");
        r(this, "smallStairs");
        r(this, "middleStairs");
        r(this, "bigStairs");
        r(this, "stairsList", []);
        r(this, "anesList", []);
        r(this, "updateDisposer");
        this.onResult = this.onResult.bind(this), this.updateView = this.updateView.bind(this), this.renderRing(), this.renderSmall(), this.renderMiddle(), this.renderBig(), this.layout(), this.updateDisposer = K(this.updateView), this.on("removed", () => {
            this.updateDisposer()
        })
    }
    renderSmall() {
        let e = new Ur;
        this.stairsList.push(e), this.addChild(e), this.smallStairs = e
    }
    renderMiddle() {
        let e = new Jr(this.ring);
        this.stairsList.push(e), this.addChild(e), this.middleStairs = e
    }
    renderBig() {
        let e = new Zr;
        this.stairsList.push(e), this.addChild(e), this.bigStairs = e
    }
    renderRing() {
        let e = new ce;
        this.ring = e, this.addChild(this.ring)
    }
    playAne(e) {}
    async onResult(e, t) {
        e == l.SKULL && c.playSound("SkeletonSound"), e == l.TOP ? (c.playSound("CrossBonusJackpotSound"), await this.middleStairs.onBigWin(t)) : (e == l.LEFT || e == l.RIGHT) && c.layers[e] == c.payouts[e].length - 2 && (e == l.LEFT ? c.playSound("RosaryBonusJackpotSound") : c.playSound("RedGemsJackpotSound"), await this.stairsList[e].onBigWin())
    }
    layout() {
        let e = this.stairsList.reduce((a, n) => (a += n.box.width, a), 0),
            t = (pe.width - e) / (this.stairsList.length - 1),
            s = 0;
        this.stairsList.forEach(a => {
            a.x = s + a.box.width / 2, a.y = pe.height - a.box.height, s += a.box.width + t
        }), this.ring.x = pe.width / 2
    }
    updateView() {
        this.stairsList.forEach((e, t) => {
            e.setStep(c.layers[t])
        })
    }
};
let W = pe;
r(W, "width", 410), r(W, "height", 480);
const Xr = {
        "bar.png": {
            frame: {
                x: 1,
                y: 1,
                w: 2,
                h: 34
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 2,
                h: 34
            },
            sourceSize: {
                w: 2,
                h: 34
            }
        },
        "bg.png": {
            frame: {
                x: 1,
                y: 29,
                w: 706,
                h: 180
            },
            rotated: !0,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 706,
                h: 180
            },
            sourceSize: {
                w: 706,
                h: 180
            }
        },
        "garden.png": {
            frame: {
                x: 37,
                y: 1,
                w: 40,
                h: 26
            },
            rotated: !1,
            trimmed: !1,
            spriteSourceSize: {
                x: 0,
                y: 0,
                w: 40,
                h: 26
            },
            sourceSize: {
                w: 40,
                h: 26
            }
        }
    },
    qr = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "loading@2x.png",
        format: "RGBA8888",
        size: {
            w: 182,
            h: 736
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:e974e7a356edaee7a998bc3e819d0d8c:bedb84636249ae466653db645a0a2f4c:7e8965a7ca512fd2a287de6c4998cee3$"
    };
var Kr = {
    frames: Xr,
    meta: qr
};
let Yr = new Image;

function Qr() {
    return new Promise(i => {
        window.bt = je;
        let o = new et(new je(Yr, {
            resolution: 2
        }), Kr, "loading@2x.png");
        o.parse(() => {
            i(o)
        })
    })
}
class Oe extends v {
    constructor() {
        super();
        r(this, "_progress", 0);
        r(this, "activeBar");
        r(this, "bg");
        this.renderBg(), this.on("removed", () => {
            w.killTweensOf(this.activeBar)
        })
    }
    async renderBg() {
        let e = await Qr(),
            t = e.textures["bg.png"],
            s = e.textures["garden.png"],
            a = e.textures["bar.png"];
        this.bg = new m(t);
        let n = new rt(s, 6, 0, 6, 0);
        n.width = this.bg.width - 10, n.position.set(5, 74), this.activeBar = new Vt(a, this.bg.width - 10, 15), this.activeBar.position.set(6, 72), this.addChild(n, this.activeBar, this.bg), this.pivot.set(this.bg.width / 2, this.bg.height / 2), this.animateTo()
    }
    renderText() {}
    animateTo() {
        !this.activeBar || (w.killTweensOf(this.activeBar), w.to(this.activeBar, {
            duration: .2,
            pixi: {
                scaleX: this.progress
            }
        }))
    }
    set progress(e) {
        this._progress != e && (this._progress = e, this.animateTo())
    }
    get progress() {
        return this._progress
    }
}
r(Oe, "width", 100), r(Oe, "height", 6);
const ei = {
        start: 1,
        end: 0
    },
    ti = {
        start: .22,
        end: .02,
        minimumScaleMultiplier: 1
    },
    ri = {
        start: "#f7a73e",
        end: "#992b0f"
    },
    ii = {
        start: 50,
        end: 0,
        minimumSpeedMultiplier: 3
    },
    si = {
        x: 15,
        y: 35
    },
    ai = 0,
    oi = {
        min: 250,
        max: 290
    },
    ni = !1,
    hi = {
        min: 0,
        max: 0
    },
    ui = {
        min: 3,
        max: 6
    },
    ci = "normal",
    pi = .15,
    di = -1,
    mi = 300,
    li = {
        x: 0,
        y: 0
    },
    wi = !1,
    Si = "polygonalChain",
    gi = [
        [{
            x: 774,
            y: 466
        }, {
            x: 783,
            y: 501
        }, {
            x: 816,
            y: 503
        }, {
            x: 774,
            y: 466
        }],
        [{
            x: 821,
            y: 508
        }, {
            x: 858,
            y: 518
        }, {
            x: 855,
            y: 499
        }, {
            x: 821,
            y: 508
        }],
        [{
            x: 917,
            y: 449
        }, {
            x: 953,
            y: 468
        }, {
            x: 972,
            y: 462
        }, {
            x: 917,
            y: 449
        }],
        [{
            x: 866,
            y: 518
        }, {
            x: 985,
            y: 536
        }, {
            x: 1125,
            y: 519
        }, {
            x: 986,
            y: 525
        }, {
            x: 866,
            y: 518
        }]
    ];
var yi = {
    alpha: ei,
    scale: ti,
    color: ri,
    speed: ii,
    acceleration: si,
    maxSpeed: ai,
    startRotation: oi,
    noRotation: ni,
    rotationSpeed: hi,
    lifetime: ui,
    blendMode: ci,
    frequency: pi,
    emitterLifetime: di,
    maxParticles: mi,
    pos: li,
    addAtBack: wi,
    spawnType: Si,
    spawnPolygon: gi
};
class fi extends m {
    constructor() {
        super(z[_.bg].texture);
        r(this, "particles");
        r(this, "bats");
        r(this, "bats2");
        r(this, "houseEdge");
        r(this, "watchList", []);
        this.houseEdge = new m(u("house_edge")), this.updateSound = this.updateSound.bind(this), this.renderParticles(), this.renderButtons(), this.renderBats(), this.addChild(this.houseEdge), this.bindEvent(), this.layout(), this.on("removed", () => {
            this.particles.destroy(), this.watchList.map(e => e())
        })
    }
    renderParticles() {
        this.particles = new jt(this, u("particle"), yi), this.particles.autoUpdate = !0
    }
    renderButtons() {
        this.updateSound()
    }
    async renderBats() {
        var s, a;
        let e = Object.values((s = z[_.bats1].spritesheet) == null ? void 0 : s.textures);
        this.bats = this.createBats(e);
        let t = Object.values((a = z[_.bats2].spritesheet) == null ? void 0 : a.textures);
        for (this.bats2 = this.createBats(t), this.addChild(this.bats, this.bats2); !this._destroyed;) await this.emitBats()
    }
    createBats(e) {
        let t = new ne(e);
        return t.visible = !1, t.anchor.set(.5), t.animationSpeed = .25, t.loop = !1, t
    }
    playBats(e) {
        this._destroyed || (e.visible = !0, e.gotoAndPlay(0), e.onComplete = () => {
            e.visible = !1, e.gotoAndStop(0)
        })
    }
    emitBats() {
        return new Promise(e => {
            this.playBats(this.bats), w.delayedCall(10, () => {
                this.playBats(this.bats2)
            }), w.delayedCall(20, e)
        })
    }
    updateSound() {}
    stopParticles() {
        this.particles.emit = !1
    }
    startParticles() {
        this.particles.emit = !0
    }
    bindEvent() {}
    layout() {
        L.instance.screen.width > 640 ? (this.texture = z[_.bg].texture, this.startParticles(), this.bats.position.set(720, 280), this.bats2.position.set(640, 280), this.houseEdge.scale.set(1.2), this.houseEdge.position.set(385, 528)) : (this.texture = z[_.bg2].texture, this.stopParticles(), this.bats.position.set(100, 180), this.bats2.position.set(300, 280), this.houseEdge.scale.set(1), this.houseEdge.position.set(305, 52)), this.pivot.x = this.width / 2
    }
}
const ve = class extends v {
    constructor() {
        super();
        r(this, "precision", 0);
        r(this, "amount", 0);
        r(this, "amountTime", 0);
        r(this, "currency", "");
        r(this, "amountText");
        r(this, "icon");
        r(this, "skull");
        r(this, "plant1");
        r(this, "plant2");
        r(this, "circle");
        r(this, "title");
        r(this, "coins", []);
        r(this, "line");
        r(this, "light");
        r(this, "summary");
        r(this, "tl");
        r(this, "bgAne");
        this.init(), this.createAne(), this.on("removed", () => {
            this.killAnes()
        })
    }
    init() {
        this.amountText = new Ue("0.00596 ETH", {
            fontName: "font",
            fontSize: 45
        }), this.amountText.anchor.set(.5), this.amountText.position.set(0, 86), this.summary = new Ue(ve.texts[0], {
            fontName: "font",
            fontSize: 12
        }), this.summary.anchor.set(.5), this.summary.position.set(0, 40);
        let e = new m(u("win_light2"));
        e.anchor.set(.5), e.scale.set(4), e.position.set(0, -40), this.light = new m(u("win_light")), this.light.anchor.set(.5), this.light.scale.set(2), this.light.position.set(0, -55), this.circle = new m(u("win_circle")), this.circle.anchor.set(.5), this.circle.position.set(-18, -102), this.plant1 = new m(u("plant")), this.plant1.anchor.set(.5), this.plant1.position.set(100, 10), this.plant2 = new m(u("plant")), this.plant2.anchor.set(.5), this.plant2.position.set(-100, 10), this.plant2.scale.x = -1, this.title = new m(u("bigwin")), this.title.anchor.set(.5), this.title.position.set(0, 10), this.icon = new m(u(Ee[1])), this.icon.anchor.set(.5), this.icon.scale.set(.9), this.icon.position.set(0, -92), this.line = new m(u("win_line")), this.line.anchor.set(.5), this.line.position.set(0, 120), this.skull = new m(u("skull_2")), this.skull.anchor.set(.5), this.skull.position.set(0, 160), this.addChild(e, this.light);
        let t = 130,
            s = Math.PI;
        for (let a = 0; a < 5; a++) {
            let n = new m(u("win_coin"));
            n.anchor.set(.5), n.scale.set(Math.random() * .3 + .7), n.rotation = Math.PI * Math.random();
            let p = s * a / 4 - (Math.PI + s) / 2 + (Math.random() - .5) * Math.PI / 15,
                y = t * (1 + Math.random() * .1);
            n.position.x = Math.cos(p) * y, n.position.y = Math.sin(p) * y - 80, this.coins.push(n), this.addChild(n)
        }
        this.addChild(this.circle, this.plant1, this.plant2, this.summary, this.title, this.icon, this.amountText, this.line, this.skull)
    }
    createAne() {
        let e = w.timeline({
            paused: !0
        });
        e.from(this.light, {
            duration: .2,
            pixi: {
                alpha: 0
            }
        }), e.from(this.circle, {
            duration: .2,
            pixi: {
                alpha: 0
            }
        }, "-=.2"), e.from(this.icon, {
            duration: .3,
            pixi: {
                scale: .3,
                alpha: 0,
                rotation: -90
            },
            ease: ye.easeOut
        }, "-=.15"), e.from(this.line, {
            duration: .2,
            pixi: {
                width: 0
            }
        }, "-=.1"), e.from(this.plant1, {
            duration: .2,
            pixi: {
                x: 0,
                alpha: 0
            }
        }, "-=.1"), e.from(this.plant2, {
            duration: .2,
            pixi: {
                x: 0,
                alpha: 0
            }
        }, "-=.1"), e.from(this.title, {
            duration: .2,
            pixi: {
                scale: .5,
                alpha: 0
            },
            ease: ye.easeOut
        }), e.from(this.summary, {
            duration: .2,
            pixi: {
                y: -10,
                alpha: 0,
                scale: .5
            }
        }, "-=.2"), e.from(this.skull, {
            duration: .2,
            pixi: {
                y: this.skull.y - 30,
                alpha: 0
            }
        }), e.call(() => {
            this.amountText.text = `${Number(0).toFixed(this.precision)} ${this.currency}`
        }, [], "-=.2"), e.from(this.amountText, {
            duration: .2,
            pixi: {
                y: this.amountText.y + 30,
                alpha: 0
            }
        }, "-=.2"), e.from(this.coins, {
            duration: .2,
            pixi: {
                x: 0,
                y: 0,
                scale: 0,
                alpha: 0,
                rotation: -360
            },
            ease: ye.easeOut,
            stagger: .07
        }, "-=.5"), e.to(this, {
            duration: 1,
            amountTime: 1e4,
            onUpdate: () => {
                this.amountText.text = `${(this.amount*this.amountTime/1e4).toFixed(this.precision)} ${ue.getAlias(this.currency)}`
            }
        }, "-=.2"), this.tl = e, this.bgAne = w.to(this.light, {
            duration: 10,
            pixi: {
                rotation: 260
            },
            ease: "none",
            repeat: 60
        })
    }
    show(e, t, s) {
        return gt(200).then(() => c.playSound("ReceiveMoneySound")), new Promise(a => {
            this.precision = Math.min(8, Ct(e)), e < 100 && this.precision == 0 && (this.precision = 2), this.amount = e, this.currency = t, this.summary.text = Kt(ve.texts), s != null ? (this.icon.texture = u(Ee[s]), this.title.texture = u("bigwin"), this.circle.visible = !0) : (this.icon.texture = u("bag"), this.title.texture = u("youwin"), this.circle.visible = !1);
            let n = setTimeout(a, 5e3);
            this.tl.eventCallback("onComplete", () => {
                w.delayedCall(2, () => {
                    clearTimeout(n), a()
                })
            }), this.tl.restart(), this.bgAne.restart()
        }).then(() => {
            this.hide()
        })
    }
    hide() {
        this.killAnes()
    }
    killAnes() {
        this.bgAne.kill(), this.tl.kill()
    }
};
let ie = ve;
r(ie, "width", 278), r(ie, "height", 434), r(ie, "texts", ["Huge Win!! Now Coco is worried.", "Great Win! Coco's Shivering :)", "BIGWIN!! Can You Hit It Again?", "BIGWIN! You Caught Coco Again"]);
class xi extends v {
    constructor() {
        super();
        r(this, "component", null);
        r(this, "stacks", []);
        r(this, "overlayer");
        this.visible = !1, this.renderOverlayer(), this.on("removed", () => {
            this.component && (w.killTweensOf(this.component), w.killTweensOf(this.overlayer))
        })
    }
    get isOpen() {
        return this.component !== null
    }
    async setComponent(e) {
        let t, s;
        this.component != null ? t = this.removeComponent(this.component) : t = this.show(), e != null ? (e.x = this.overlayer.width / 2, e.y = this.overlayer.height / 2, s = this.addComponent(e)) : s = this.hide(), this.component = e, await Promise.all([t, s])
    }
    addComponent(e) {
        return new Promise(t => {
            this.addChild(e), e.scale.set(.5), w.to(e, .5, {
                pixi: {
                    scale: 1,
                    alpha: 1
                },
                ease: ye.easeOut,
                onComplete: t
            })
        })
    }
    removeComponent(e) {
        return new Promise(t => {
            w.to(e, .3, {
                pixi: {
                    scale: .5,
                    alpha: 0
                },
                onComplete: t
            })
        }).then(() => this.removeChild(e))
    }
    renderOverlayer() {
        this.overlayer = new oe, this.overlayer.interactive = !0, this.overlayer.beginFill(0), this.overlayer.drawRect(0, 0, 100, 100), this.overlayer.alpha = .5, this.addChild(this.overlayer)
    }
    async push(e) {
        if (this.component != e) return this.stacks.push(e), await this.setComponent(e), this.stacks
    }
    async pop() {
        let e = this.stacks.pop();
        return await this.setComponent(this.stacks[this.stacks.length - 1] || null), e
    }
    async close() {
        this.stacks = [], await this.setComponent(null)
    }
    show() {
        return new Promise(e => {
            this.visible = !0, w.to(this.overlayer, .5, {
                pixi: {
                    alpha: .7
                },
                onComplete: e
            })
        })
    }
    hide() {
        return new Promise(e => {
            w.to(this.overlayer, .5, {
                pixi: {
                    alpha: 0
                },
                onComplete: e
            })
        }).then(() => this.visible = !1)
    }
    resize(e, t) {
        this.overlayer.width = e, this.overlayer.height = t, this.pivot.set(e / 2, t / 2)
    }
}
window.PIXI = it;
st.registerPIXI(it);
w.registerPlugin(st);
const x = {
        SAFE_SIZE: 860,
        MOBILE_SIZE: 640,
        WIDTH: 1110,
        MOBILE_WIDTH: 412,
        HEIGHT: 555
    },
    ke = class extends Ut {
        constructor(e) {
            super();
            r(this, "inited");
            r(this, "width");
            r(this, "scale", 1);
            r(this, "rank");
            r(this, "roll");
            r(this, "control");
            r(this, "loading");
            r(this, "bg");
            r(this, "logo");
            r(this, "des");
            r(this, "bigWin");
            r(this, "dialog");
            r(this, "store", c);
            ke.instance = this, Jt.FILTER_RESOLUTION = window.devicePixelRatio, this.onProgress = this.onProgress.bind(this), this.width = e, this.init(), this.resetSize(e)
        }
        init() {
            this.inited = new Promise(async e => {
                this.loading = new Oe, this.stage.addChild(this.loading), this.onProgress(), this.loader.onProgress.add(this.onProgress), await Promise.all([Fr(this.loader)]), this.stage.removeChild(this.loading), this.loading = null, this.renderBg(), this.roll = new fe, this.roll.pivot.x = this.roll.box.width / 2, this.stage.addChild(this.roll), this.control = new xe, this.control.pivot.x = this.control.width / 2, this.stage.addChild(this.control), this.rank = new W, this.rank.pivot.x = W.width / 2, this.rank.pivot.y = W.height / 2, this.stage.addChild(this.rank), this.bigWin = new ie, this.dialog = new xi, this.dialog.zIndex = 100, this.stage.addChild(this.dialog), this.stage.sortChildren(), this.reLayout(), e()
            })
        }
        async resetSize(e) {
            let t;
            this.width = e, e < x.MOBILE_SIZE ? (this.scale = e / x.MOBILE_WIDTH, t = e * 1.64, this.renderer.resize(e, t)) : (this.scale = e / x.WIDTH, this.renderer.resize(e, e / 2)), this.loading ? (this.loading.x = this.screen.width / 2, this.loading.y = this.screen.height / 2, this.screen.width < x.MOBILE_SIZE && this.loading.scale.set(.5)) : this.reLayout()
        }
        async reLayout() {
            await this.inited, this.screen.width < x.MOBILE_SIZE ? this.reLayoutMobile(this.screen.width, this.screen.height) : this.reLayoutPc(this.screen.width, this.screen.height)
        }
        renderBg() {
            this.bg = new fi, this.stage.addChild(this.bg), this.logo = new m(u("logo")), this.logo.pivot.x = this.logo.width / 2, this.logo.zIndex = 3, this.stage.addChild(this.logo), this.des = new m(u("l_box2")), this.des.anchor.set(.5), this.des.zIndex = 3, this.stage.addChild(this.des)
        }
        reLayoutPc(e, t) {
            let s = 12;
            this.logo.scale.set(1), this.logo.x = x.SAFE_SIZE / 4, this.logo.y = s, s += this.logo.height, s += -5, this.roll.scale.set(1), this.roll.x = x.SAFE_SIZE / 4, this.roll.y = s, s += this.roll.box.height, s -= 20, this.des.visible = !0, this.des.texture = u("l_box2"), this.des.scale.set(1), this.des.x = x.SAFE_SIZE / 4, this.des.y = s + this.des.height / 2, s += this.des.height, s += 5, this.control.x = x.SAFE_SIZE / 4, this.control.y = s, s += this.control.y, this.rank.scale.set(1), this.rank.x = x.SAFE_SIZE * 3 / 4, this.rank.y = x.HEIGHT / 2, this.dialog.resize(this.screen.width / this.scale, this.screen.height / this.scale), this.dialog.position.set(x.SAFE_SIZE / 2, x.HEIGHT / 2), this.stage.scale.set(this.scale), this.stage.pivot.x = x.SAFE_SIZE / 2, this.stage.x = this.screen.width / 2, this.bg.position.x = x.SAFE_SIZE / 2, this.bg.layout()
        }
        reLayoutMobile(e, t) {
            let s = 0;
            this.logo.scale.set(.6), this.logo.x = x.MOBILE_WIDTH - this.logo.width / 2 - 10, this.logo.y = 10, this.rank.scale.set(330 / W.width), this.rank.y = this.rank.height / 2 + s, this.rank.x = x.MOBILE_WIDTH / 2, s += this.rank.height;
            const a = 143 / 252;
            this.roll.scale.set(a * .9), this.roll.y = s, this.roll.x = this.roll.width / 2 + 30, this.des.texture = u("l_box2_2"), this.des.scale.set(.9), this.des.y = s + this.des.height / 2, this.des.x = x.MOBILE_WIDTH - 30 - this.des.width / 2, s += this.roll.box.height * a, s += 0, this.control.scale.set(.9), this.control.x = x.MOBILE_WIDTH / 2, this.control.y = s, this.bg.x = x.MOBILE_WIDTH / 2, this.bg.layout(), this.dialog.resize(this.screen.width / this.scale, this.screen.height / this.scale), this.dialog.position.set(this.screen.width / this.scale / 2, this.screen.height / this.scale / 2), this.stage.scale.set(this.scale), this.stage.pivot.x = 0, this.stage.x = 0
        }
        onProgress() {
            this.loading.progress = this.loader.progress * .01
        }
        async run(e, t) {
            await this.roll.scrollTo(e), await this.rank.onResult(e, t)
        }
        async showProfit(e, t) {
            !this.stage || (this.dialog.push(this.bigWin), await this.bigWin.show(e, c.currencyName, t), !!this.stage && this.dialog.component === this.bigWin && this.dialog.pop())
        }
        destroy() {
            ke.instance = null, super.destroy()
        }
    };
let L = ke;
r(L, "instance", null);
const F = de.Reader,
    Ce = de.Writer,
    re = de.util,
    T = de.roots.gameSlots || (de.roots.gameSlots = {});
T.BetValue = (() => {
    function i(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return i.encode = function(e, t) {
        return t || (t = Ce.create()), t
    }, i.decode = function(e, t) {
        e instanceof F || (e = F.create(e));
        let s = t === void 0 ? e.len : e.pos + t,
            a = new T.BetValue;
        for (; e.pos < s;) {
            let n = e.uint32();
            switch (n >>> 3) {
                default: e.skipType(n & 7);
                break
            }
        }
        return a
    }, i
})();
T.GameValue = (() => {
    function i(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return i.prototype.leftIndex = 0, i.prototype.centerIndex = 0, i.prototype.rightIndex = 0, i.prototype.position = 0, i.prototype.index = 0, i.encode = function(e, t) {
        return t || (t = Ce.create()), e.leftIndex != null && Object.hasOwnProperty.call(e, "leftIndex") && t.uint32(8).sint32(e.leftIndex), e.centerIndex != null && Object.hasOwnProperty.call(e, "centerIndex") && t.uint32(16).sint32(e.centerIndex), e.rightIndex != null && Object.hasOwnProperty.call(e, "rightIndex") && t.uint32(24).sint32(e.rightIndex), e.position != null && Object.hasOwnProperty.call(e, "position") && t.uint32(32).sint32(e.position), e.index != null && Object.hasOwnProperty.call(e, "index") && t.uint32(40).sint32(e.index), t
    }, i.decode = function(e, t) {
        e instanceof F || (e = F.create(e));
        let s = t === void 0 ? e.len : e.pos + t,
            a = new T.GameValue;
        for (; e.pos < s;) {
            let n = e.uint32();
            switch (n >>> 3) {
                case 1:
                    a.leftIndex = e.sint32();
                    break;
                case 2:
                    a.centerIndex = e.sint32();
                    break;
                case 3:
                    a.rightIndex = e.sint32();
                    break;
                case 4:
                    a.position = e.sint32();
                    break;
                case 5:
                    a.index = e.sint32();
                    break;
                default:
                    e.skipType(n & 7);
                    break
            }
        }
        return a
    }, i
})();
T.GameInfo = (() => {
    function i(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return i.prototype.userId = 0, i.prototype.status = 0, i.prototype.currencyName = "", i.prototype.betAmount = re.Long ? re.Long.fromBits(0, 0, !1) : 0, i.prototype.settleAmount = re.Long ? re.Long.fromBits(0, 0, !1) : 0, i.prototype.cashpotPayout = 0, i.prototype.cashpotAmount = re.Long ? re.Long.fromBits(0, 0, !1) : 0, i.prototype.leftIndex = 0, i.prototype.centerIndex = 0, i.prototype.rightIndex = 0, i.encode = function(e, t) {
        return t || (t = Ce.create()), e.userId != null && Object.hasOwnProperty.call(e, "userId") && t.uint32(8).sint32(e.userId), e.status != null && Object.hasOwnProperty.call(e, "status") && t.uint32(16).sint32(e.status), e.currencyName != null && Object.hasOwnProperty.call(e, "currencyName") && t.uint32(26).string(e.currencyName), e.betAmount != null && Object.hasOwnProperty.call(e, "betAmount") && t.uint32(32).sint64(e.betAmount), e.settleAmount != null && Object.hasOwnProperty.call(e, "settleAmount") && t.uint32(40).sint64(e.settleAmount), e.cashpotPayout != null && Object.hasOwnProperty.call(e, "cashpotPayout") && t.uint32(49).double(e.cashpotPayout), e.cashpotAmount != null && Object.hasOwnProperty.call(e, "cashpotAmount") && t.uint32(56).sint64(e.cashpotAmount), e.leftIndex != null && Object.hasOwnProperty.call(e, "leftIndex") && t.uint32(64).sint32(e.leftIndex), e.centerIndex != null && Object.hasOwnProperty.call(e, "centerIndex") && t.uint32(72).sint32(e.centerIndex), e.rightIndex != null && Object.hasOwnProperty.call(e, "rightIndex") && t.uint32(80).sint32(e.rightIndex), t
    }, i.decode = function(e, t) {
        e instanceof F || (e = F.create(e));
        let s = t === void 0 ? e.len : e.pos + t,
            a = new T.GameInfo;
        for (; e.pos < s;) {
            let n = e.uint32();
            switch (n >>> 3) {
                case 1:
                    a.userId = e.sint32();
                    break;
                case 2:
                    a.status = e.sint32();
                    break;
                case 3:
                    a.currencyName = e.string();
                    break;
                case 4:
                    a.betAmount = e.sint64();
                    break;
                case 5:
                    a.settleAmount = e.sint64();
                    break;
                case 6:
                    a.cashpotPayout = e.double();
                    break;
                case 7:
                    a.cashpotAmount = e.sint64();
                    break;
                case 8:
                    a.leftIndex = e.sint32();
                    break;
                case 9:
                    a.centerIndex = e.sint32();
                    break;
                case 10:
                    a.rightIndex = e.sint32();
                    break;
                default:
                    e.skipType(n & 7);
                    break
            }
        }
        return a
    }, i
})();
T.CollectRequest = (() => {
    function i(o) {
        if (o)
            for (let e = Object.keys(o), t = 0; t < e.length; ++t) o[e[t]] != null && (this[e[t]] = o[e[t]])
    }
    return i.prototype.type = 0, i.prototype.frontgroundId = 0, i.encode = function(e, t) {
        return t || (t = Ce.create()), e.type != null && Object.hasOwnProperty.call(e, "type") && t.uint32(8).int32(e.type), e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && t.uint32(120).sint32(e.frontgroundId), t
    }, i.decode = function(e, t) {
        e instanceof F || (e = F.create(e));
        let s = t === void 0 ? e.len : e.pos + t,
            a = new T.CollectRequest;
        for (; e.pos < s;) {
            let n = e.uint32();
            switch (n >>> 3) {
                case 1:
                    a.type = e.int32();
                    break;
                case 15:
                    a.frontgroundId = e.sint32();
                    break;
                default:
                    e.skipType(n & 7);
                    break
            }
        }
        return a
    }, i
})();
const bi = Re.decode(T.GameValue),
    zi = qe(() => {
        const [i, o] = he.exports.useState(0), e = he.exports.useRef(null), t = Bt(({
            width: n
        }) => {
            o(n)
        }, 3e3), s = It([e, t]), [a] = he.exports.useState(() => new L(_i()));
        return window.slotsRef = a, he.exports.useEffect(() => {
            i > 0 && (a.view.style.display = "none", a.resetSize(i), a.view.style.display = "block")
        }, [i]), he.exports.useEffect(() => {
            if (e.current) return e.current.appendChild(a.view), c.onBetRequest = async n => {
                c.betLoading = !0;
                try {
                    let p = await n;
                    const {
                        leftIndex: y,
                        centerIndex: k,
                        rightIndex: C,
                        position: V,
                        index: Y
                    } = bi(p.gameValue);
                    try {
                        await a.run(V - 1, Y), c.setLayers([y, k, C])
                    } catch (me) {
                        console.log(me)
                    }
                    return c.autoBet.isRunning && c.payout >= c.autoStop && c.autoBet.stop(), p
                } catch (p) {
                    throw p
                } finally {
                    c.betLoading = !1
                }
            }, () => {
                a.destroy()
            }
        }, []), h("div", {
            className: "graph",
            ref: s
        })
    });

function _i() {
    const i = window.innerWidth;
    return i < 612 ? (console.log(i), i * .8) : 900
}
const vi = qe(function() {
        const o = Ke(),
            e = Ye(),
            t = e.autoBet;
        let s = e.betLoading,
            a = o("common.bet");
        t.times > 0 && t.isRunning && (a = o("common.actions.stop"), s = !1);
        const n = () => h(Pt, {
            type: "conic",
            disabled: s,
            onClick: e.toggleAutoBet,
            children: a
        });
        return A(Tt, {
            className: Qe(ki, "cave"),
            children: [h(zi, {}), A("div", {
                className: "game-form",
                children: [Ie.isMobile && n(), h(Ve.CoinInput, {}), h(Ve.TimesInput, {
                    disabled: t.isRunning,
                    hideButtons: !0
                }), !Ie.isMobile && n()]
            })]
        })
    }),
    ki = "w1ne54d2";
const Ai = Ze.memo(() => {
        const i = Ke(),
            o = Ye(),
            e = [{
                title: i("common.game_intro"),
                node: h(Yt, {
                    game: o
                })
            }, {
                title: i("common.fairness"),
                node: "/cave_help/fairness"
            }];
        return h(Lt, {
            gameView: h(vi, {}),
            className: Ci,
            type: 1,
            tabs: [{
                label: i("common.all_bet"),
                value: Te.AllBet
            }, {
                label: i("common.my_bet"),
                value: Te.MyBet
            }],
            actions: [h(Et, {}), h(Ot, {}), h(Rt, {}), h(Mt, {}), h(Dt, {
                list: e
            })]
        })
    }),
    Ci = "s11vk3dr";
var Bi = {
        RedGemsJackpotMusic: [0, 3631],
        RedGemsJackpotSound: [3631, 2500],
        ReelRotatelevel1: [6131, 833],
        ReelRotatelevel2: [6964, 559],
        ReelRotatelevel3: [7523, 617],
        ReelRotatelevel4: [8140, 680],
        ReelRotateStopLevel1: [8820, 360],
        ReelRotateStopLevel2: [9180, 364],
        ReelRotateStopLevel3: [9544, 326],
        ReelRotateStopLevel4: [9870, 326],
        RosaryBonusJackpotMusic: [10196, 3871],
        RosaryBonusJackpotSound: [14067, 2743],
        RosaryBonusLevel1: [16810, 913],
        RosaryBonusLevel2: [17723, 879],
        RosaryBonusLevel3: [18602, 958],
        RosaryBonusLevel4: [19560, 2744],
        SkeletonSound: [22304, 1665],
        SystemAutoStopBetSound: [23969, 479],
        ActionSpin: [24448, 10098],
        CrossBonusJackpotMusic: [34556, 3423],
        CrossBonusJackpotSound: [37969, 2060],
        CrossBonusLevel1: [40029, 1111],
        CrossBonusLevel2: [41140, 1228],
        CrossBonusLevel3: [42368, 930],
        CrossBonusLevel4: [43298, 821],
        CrossBonusLevel5: [44119, 1132],
        CrossBonusLevel6: [45251, 1046],
        CrossBonusLevel7: [46297, 1016],
        PressAutoupToSound: [47313, 56],
        PressCollectCashPotSound: [47369, 464],
        ReceiveMoneySound: [47833, 3609],
        RedGemsBonusLevel1: [51442, 1028],
        RedGemsBonusLevel2: [52470, 806],
        RedGemsBonusLevel3: [53276, 750],
        RedGemsBonusLevel4: [54026, 950],
        RedGemsBonusLevel5: [54976, 1189]
    },
    Ii = "/assets/sounds.51bd2999.mp3";
const Ti = new Uint8Array,
    Je = Re.decode(T.GameInfo),
    Pi = Re.encode(T.CollectRequest);
class Li extends Gt {
    constructor() {
        super({
            name: "SlotsCave",
            namespace: "/g/sc",
            fairLink: "/cave_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/slots.html"
        }, Ai);
        r(this, "payout", 0);
        r(this, "cashpot", 0);
        r(this, "autoStop", 500);
        r(this, "autoStopIndex", 5);
        r(this, "autoStopNums", [10, 20, 50, 100, 200, 500]);
        r(this, "layers", [0, 0, 0]);
        r(this, "payouts", [
            [0, 1.6, 5, 10.5, 18],
            [0, 4, 13, 28.5, 53, 88, 137.5, 205, 0],
            [0, 2.5, 8, 16.5, 28.5, 45, 66],
            [100, 200, 300, 400, 500]
        ]);
        r(this, "betLoading", !1);
        r(this, "isJoining", !1);
        r(this, "caveSound", new Nt.Howl({
            src: Ii,
            sprite: Bi
        }));
        r(this, "theme", {
            main: "#5899be",
            text: "#fff",
            dark: "#397da2",
            dark2: "#397da2",
            light: "#a8d3ea"
        });
        $t(this, {
            payout: Z,
            cashpot: Z,
            autoStop: Z,
            autoStopIndex: Z,
            layers: Z,
            betLoading: Z,
            payouts: Z.ref,
            addAutoStop: He,
            subAutoStop: He
        }), this.join = this.join.bind(this), this.addAutoStop = this.addAutoStop.bind(this), this.subAutoStop = this.subAutoStop.bind(this), this.toggleAutoBet = this.toggleAutoBet.bind(this), this.socket.on("connect", this.join), this.autoBet.isLog = !1, K(() => {
            Be.login && this.join()
        }), K(() => {
            this.setBetStatus(this.payout > 0)
        }), this.autoBet.stopWithZero = !0;
        const e = this.hotkeyList.find(t => t.key == "space");
        e && (e.handler = this.toggleAutoBet)
    }
    setBetStatus(e) {
        this.isBetting = this.autoBet.isRunning || this.payout > 0
    }
    toggleAutoBet() {
        return this.autoBet.isRunning && this.autoBet.times > 0 ? this.autoBet.stop() : this.betLoading || this.autoBet.start().catch(Wt), !1
    }
    async join() {
        if (!!Be.login && !this.isJoining) {
            this.isJoining = !0;
            try {
                await this.initialize();
                const e = await this.socketRequest("join").then(Je);
                let {
                    status: t,
                    leftIndex: s,
                    centerIndex: a,
                    rightIndex: n,
                    currencyName: p,
                    betAmount: y,
                    cashpotPayout: k
                } = e;
                k > 0 && (this.currencyName = p, this.amount = new H(ue.bn2amount(y, p))), this.setLayers([s, a, n])
            } catch (e) {} finally {
                this.isJoining = !1
            }
        }
    }
    addLayer(e, t) {
        let s = this.layers[e],
            a = Math.max(Math.min(s + t, this.payouts[e].length - 2), 0);
        return this.layers.splice(e, 1, a), this.payouts[e][a] - this.payouts[e][s]
    }
    setLayers(e) {
        let t = this.getPayout(e);
        this.layers = e, this.payout = t, this.cashpot = new H(this.amount).mul(t).toNumber()
    }
    getPayout(e) {
        return e.reduce((t, s, a) => t += this.payouts[a][s], 0)
    }
    async collect(e, t) {
        const s = ue.createDeduction(new H(0), this.currencyName, this.name);
        this.betLoading = !0;
        try {
            const a = await this.socketRequest("collect", Pi({
                    frontgroundId: s,
                    type: e ? 1 : 2
                })).then(Je),
                {
                    leftIndex: n,
                    centerIndex: p,
                    rightIndex: y
                } = a,
                k = this.payout,
                C = [n, p, y];
            let V = this.getPayout(C),
                Y = k - V;
            return await t(Y), this.setLayers(C), ue.resolveDeduction(s), Y
        } catch (a) {
            throw a
        } finally {
            this.betLoading = !1, ue.resolveDeduction(s, !1), this.syncCurrency()
        }
    }
    collectAll(e) {
        return this.collect(!0, e)
    }
    partialCollect(e) {
        return this.collect(!1, e)
    }
    addAutoStop() {
        this.autoStopIndex = Math.min(this.autoStopIndex + 1, this.autoStopNums.length - 1), this.autoStop = this.autoStopNums[this.autoStopIndex]
    }
    subAutoStop() {
        this.autoStopIndex = Math.max(this.autoStopIndex - 1, 0), this.autoStop = this.autoStopNums[this.autoStopIndex]
    }
    playSound(e) {
        if (!!this.settings.soundEnable) try {
            return this.caveSound.play(e)
        } catch (t) {}
    }
    betValue() {
        return Ti
    }
}
const yt = new Li;
var c = yt,
    l = (i => (i[i.LEFT = 0] = "LEFT", i[i.MIDDLE = 1] = "MIDDLE", i[i.RIGHT = 2] = "RIGHT", i[i.SKULL = 3] = "SKULL", i[i.NONE = 4] = "NONE", i[i.TOP = 5] = "TOP", i))(l || {});
window.dg = yt;

function Yi({
    bodyLock: i
}) {
    return h(Xe, {
        bodyLock: i,
        children: A("div", {
            className: "item",
            children: [h("h2", {
                children: "Fairness Verification"
            }), A("div", {
                className: "help-content",
                children: [h("h4", {
                    children: "Q: How is the game result generated?"
                }), h("p", {
                    children: "A random number between 0 and 99,999 is generated using a provably fair algorithm. That process is described below."
                }), A("p", {
                    children: ["The random number (between 0 and 99,999) is then matched to the", h("a", {
                        className: "cl-primary",
                        style: {
                            padding: "0 0.2rem"
                        },
                        href: "https://bcgame-project.github.io/verify/slots.html#probability",
                        target: "_blank",
                        children: "probability table"
                    }), "and the corresponding symbol from the table is the game result."]
                }), h("h4", {
                    children: "Q: How is the random number generated?"
                }), h("p", {
                    children: "First, combine the server seed, client seed and the nonce to get the SHA512 hash."
                }), A("ol", {
                    children: [h("li", {
                        children: h("p", {
                            children: "We use the combination to compute the HMAC_SHA512 hash. This gives us a 128-character hex string: hash = HMAC_SHA512 (clientSeed:nonce, serverSeed)"
                        })
                    }), h("li", {
                        children: "Then we take the first 5 characters of the 128 character hex string and convert them to a decimal number from 0 to 1,048,575 (16 ^ 5-1). If it is less than 1 million, it is used as the random number. If it is more than 1 million, we use the next five characters from the same 128 character hex string. We are able to repeat the process up to 25 times."
                    }), h("li", {
                        children: "In very rare cases ((48,576 / 1,000,000) ^ 25) When converting to decimal, none of the 25 trials are below 1 million, we use the remaining 3 characters and convert them to your random number"
                    })]
                }), h("p", {
                    children: "Code example:"
                }), h("p", {
                    children: "The following code example can be used to verify bets:"
                }), h(Fe, {
                    children: `function get (serverSeed, clientSeed, nonce) {
  var hash = hmac_sha512(this.client_seed + ":" +this.nonce, this.server_seed);
  var index = 0;
  do {
    var lucky = parseInt (hash.substr (index, 5), 16);
    index + = 5;
  } while (lucky> = 1000000);
    return lucky;
  }
}`
                }), h("br", {}), A("h4", {
                    children: ["How to use the", h("a", {
                        className: "cl-primary",
                        style: {
                            paddingLeft: "0.2rem"
                        },
                        href: "https://bcgame-project.github.io/verify/slots.html#probability",
                        target: "_blank",
                        children: "probability table"
                    }), "?"]
                }), A("ul", {
                    children: [h("li", {
                        children: "Layer = How high you climbed each of the three columns and the effect it has on the probability range of each symbol."
                    }), h("li", {
                        children: "Left = Book symbol"
                    }), h("li", {
                        children: "Middle = Cross symbol"
                    }), h("li", {
                        children: "Right = Gem symbol"
                    }), h("li", {
                        children: "Ghost = Skull symbol"
                    }), h("li", {
                        children: "Blank = No symbol"
                    })]
                }), h("p", {
                    children: "Example: You currently have 2 layers of books, 1 layer of crosses, and 3 layers of potions. This means that the layer for reference on the next spin is layer 213. The random number you obtained from the SHA512 hash, converted to decimal, as described above, is 503140. The corresponding layer in your table is Layer 213. The range is Ghost [200800 + 122711 + 92033, 200800 + 122711 + 92033 +146113)"
                }), h("br", {}), h("h4", {
                    children: "Action Spin:"
                }), h("p", {
                    children: "If the middle tower reaches the top level, the first 10 characters of the HMAC_SHA512 hash value are converted into decimal numbers and modulo 5 to get a random number of [0,4], which corresponds to 100-500 times the prize in turn."
                }), h("p", {
                    children: "Code example:"
                }), h(Fe, {
                    children: `function get (serverSeed, clientSeed, nonce) {
  var hash = hmac_sha512(this.client_seed + ":" +this.nonce, this.server_seed);
  var lucky = parseInt (hash.substr (0, 10), 16);
  return lucky%5;
}`
                })]
            })]
        })
    })
}
var Ei = "/assets/bgline.bd5db471.png",
    Oi = "/assets/bgline_w.52e4fe37.png",
    Ri = "/assets/border.7def02f7.png",
    Mi = "/assets/border_w.f01f4d4d.png",
    Di = "/assets/bible.e5561b8c.png",
    Gi = "/assets/cross.2c4ce392.png",
    Ni = "/assets/gem.b56bb4bb.png",
    $i = "/assets/skull.03d7bdc5.png",
    Wi = "/assets/space.4d0e573d.png";
const q = {
    bgline: Ei,
    bgline_w: Oi,
    border: Ri,
    border_w: Mi,
    bible: Di,
    cross: Gi,
    gem: Ni,
    skull: $i,
    space: Wi
};
const Hi = (i, o, e, t, s) => {
        const a = parseInt(s.betLog.gv.decimalIndex);
        window.open(`${c.config.validateLink}?s=${i}&c=${o}&h=${t}&n=${e}&l=${a}`)
    },
    Fi = {
        1: q.bible,
        2: q.cross,
        3: q.gem,
        4: q.skull
    },
    Vi = Te.withSingleDetail({
        onValidate: Hi,
        result: ({
            betLog: i
        }) => {
            const {
                position: o
            } = i.gv, e = i.odds / 1e4, t = e < 1, s = Ie.isDarken;
            return A("div", {
                className: Qe(ji, "slots-box"),
                children: [A("div", {
                    className: "l-box",
                    children: [!t && h("img", {
                        src: s ? q.bgline : q.bgline_w,
                        className: "lin-img"
                    }), h("img", {
                        src: Fi[o] || q.space,
                        className: "res-img"
                    })]
                }), h("div", {
                    className: "c-result",
                    children: t ? "LOSE" : "WIN"
                }), h("div", {
                    className: `r-r ${t?"lose":""}`,
                    children: e + "X"
                })]
            })
        }
    }),
    ji = "r15e6g48";
var Qi = Vi;
export {
    Qi as Detail, Yi as Fairness, c as Game
};
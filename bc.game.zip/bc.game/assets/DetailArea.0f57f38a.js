var B = Object.defineProperty,
    H = Object.defineProperties;
var J = Object.getOwnPropertyDescriptors;
var m = Object.getOwnPropertySymbols;
var b = Object.prototype.hasOwnProperty,
    w = Object.prototype.propertyIsEnumerable;
var y = (t, n, s) => n in t ? B(t, n, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : t[n] = s,
    h = (t, n) => {
        for (var s in n || (n = {})) b.call(n, s) && y(t, s, n[s]);
        if (m)
            for (var s of m(n)) w.call(n, s) && y(t, s, n[s]);
        return t
    },
    C = (t, n) => H(t, J(n));
var I = (t, n) => {
    var s = {};
    for (var o in t) b.call(t, o) && n.indexOf(o) < 0 && (s[o] = t[o]);
    if (t != null && m)
        for (var o of m(t)) n.indexOf(o) < 0 && w.call(t, o) && (s[o] = t[o]);
    return s
};
import {
    a5 as S,
    J as j,
    j as q,
    a as u,
    cS as A,
    y as v
} from "./index.28e31dff.js";
import {
    g as L,
    s as T,
    a as k,
    C as z
} from "./index.77c81a32.js";
import "./lodash.f3c7da90.js";
import "./index.dd8128e8.js";
import "./index.06a59a68.js";
const M = S.memo(function({
    bets: n,
    currencyName: s,
    result: o
}) {
    const r = L(),
        c = j.dict[s];
    let i = c ? c.precision : -999;
    return s === "JB" && (i = 0), q("div", {
        className: G,
        children: [T.map((a, e) => a.map((l, p) => {
            const d = l.type === "green" ? "0" : l.pos[0] + "-" + l.pos[1],
                g = o === l.num,
                {
                    chips: N,
                    amountInfo: R
                } = x(n, s, i, {
                    type: "0",
                    column: String(l.num)
                });
            return u(D, {
                className: A("slot", "slot-" + l.type, "slot-" + d, g && "result"),
                row: l.pos[0],
                column: l.pos[1],
                chips: N,
                amountInfo: R,
                children: l.num
            }, "slots-" + p.toString())
        })), r.map((a, e) => {
            const l = a.label === "red" || a.label === "black",
                p = a.isHidden,
                f = l || p,
                {
                    chips: d,
                    amountInfo: g
                } = x(n, s, i, {
                    type: a.type,
                    column: a.column
                });
            return p && d.eq(0) ? null : u(D, {
                className: A("action", f && "action-" + a.label, p && "hidden"),
                row: a.pos[0],
                column: a.pos[1],
                chips: d,
                amountInfo: g,
                children: f ? "" : a.label
            }, "action-" + e.toString())
        })]
    })
});

function x(t, n, s, o) {
    let r = new v(0),
        c = "",
        i = !1,
        a = "0";
    if (i = t.some(e => {
            if (e.type === o.type && e.column === o.column) return a = e.betAmount, !0
        }), i) {
        if (s != -999) {
            const e = k(s);
            r = new v(a).div(e).round()
        }
        r.eq(0) && (c = a + " " + j.getAlias(n))
    }
    return {
        chips: r,
        amountInfo: c
    }
}
const D = S.memo(function(e) {
        var l = e,
            {
                row: t,
                column: n,
                children: s,
                chips: o,
                amountInfo: r,
                className: c,
                style: i
            } = l,
            a = I(l, ["row", "column", "children", "chips", "amountInfo", "className", "style"]);
        return q("div", C(h({
            className: A(c, "result-item"),
            style: h({
                gridRow: t,
                gridColumn: n
            }, i)
        }, a), {
            children: [u("span", {
                children: s
            }), o.gt(0) && u(z, {
                chip: o
            }), r && u("div", {
                className: "amount-info",
                children: r
            })]
        }))
    }),
    G = "d1itz9wr";
export {
    M as
    default
};
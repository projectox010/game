import {
    bj as $,
    ca as _e,
    t as O,
    q as V,
    u as R,
    r as f,
    j as n,
    a as e,
    C as Se,
    p as H,
    I as U,
    d as C,
    s as p,
    a5 as k,
    A as Y,
    o as Q,
    cb as z,
    l as W,
    aO as _,
    cc as N,
    a$ as le,
    K as Ce,
    aa as ne,
    L as ce,
    F as K,
    b as Ae,
    e as ge,
    T as Le,
    k as Ie,
    bW as Me,
    P as X,
    cd as Pe,
    bh as de,
    D as ye,
    S as Be,
    a3 as Re,
    v as Ue,
    a2 as ke,
    $ as Ve,
    G as je,
    aB as xe,
    J as Ee
} from "./index.28e31dff.js";
import {
    s as ee
} from "./sortedIndex.6b9ffc19.js";
import {
    g as Qe
} from "./groupBy.00ce7dc6.js";
import "./_baseAssignValue.0532e777.js";
var Te = "/assets/bg.7ad42530.png",
    Oe = "/assets/bg_m.876e8177.png",
    ze = "/assets/bg_w.0c723150.png",
    Ke = "/assets/bg_m_w.87deeaa1.png",
    Ge = "/assets/element.0de17056.png",
    Je = "/assets/element_w.dc8c5f4d.png",
    De = "/assets/jb.781d8c60.png",
    Ye = "/assets/jb_w.1892d510.png",
    qe = "/assets/box_r.146d6072.png",
    He = "/assets/box_r_w.0b153017.png",
    We = "/assets/jb_r.b43f1e03.png",
    Xe = "/assets/jb_r_w.992469b8.png",
    Ze = "/assets/jbc.5c2f4bbb.png",
    Fe = "/assets/jbc_w.4be2f1e2.png",
    $e = "/assets/jbnc.9d80a2fa.png",
    ea = "/assets/ribbon.f9e96837.png",
    aa = "/assets/ribbon_w.4941a7ea.png",
    sa = "/assets/tr.c44e4679.png",
    ra = "/assets/tr_w.253e4938.png",
    ta = "/assets/tr_r.5ad8acac.png",
    ia = "/assets/tr_r_w.ac4592f1.png",
    la = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKYAAAAiCAMAAADid1KLAAAAllBMVEUAAAAuNDQeICQfISUfICQeICQeISQwMDAeICQfISUfISUgIiYeICQeICQeICQgISYiKC0eICQeICQeICQeICQeICUfIiYgISUiIikfJiciIismJikfICUeISUeICQfISUfICQeICUfISUlJSUgJyoeISQeICQfISUgIyUiJCQeICUhISUgIiYfICUfISQjIykeISQeICRp4GtKAAAAMXRSTlMABfb62NSaCvx1Vj3k3qFPDvHIwq5tSkUlIB0U0Lu1k41+WxsY6s1jLyKHNiemaCypQU1KZQAAAp1JREFUWMPVl9t6qjAQhcNJVERARUQpiuKhamvX+7/c3jW7tiY0YcjV/q/nWy4Xk8mEiVyHzJBtbqpQ6UvGHjPDCnuGCov+UF8CwziPcJZmCmN4+hJ4ZmG6wNpI4dUBhvoSszi3AOydiUIPgKcvQcEMcAGzOHPnUyHSlyAyCxOwa7MwgUJfggPrjMcVNp0Flg5XiPQlmLOODMGxV10V1uAc9CWYGIRpFufOgSaq5dzGF+nC6jCLroOHgJ11Oe3+6e2hcLgIX6QOjueZZ+MJxy3XaZZbrfy9ztN1GfafFWxvdj4GdTt/t2jQm47wTDIZV9tL/FkwKAR/otuepfE4dh2VQnJIdafmZQQV+2nA4gmUjK5Mw22vVpj62inWhwLe6PEUCsJXpuWqDOPF1ysMld/jzPviReEyb7XSKHyWfhuFSOGzYkzj01223BbC3xRmLSfG/NcTMvg+BeUvLuvWd0dIcymT2SqXHGuGBryaMJbdJoU3wvQNGn2mz1PlAxIF6cKrPVlhTLojgkRWeBdq5DzdmJFYhVKWjMalL7sU2UCAfK8X8iChEUMkk2qk055Qb3Spt0qiQqA8Pxz5KiE+vK7y0GU03uXmljoLEnPqqinhU1dNbeMFTROLRCUrXGgK8q1tiyUpvuh/J05iJgngSFPYywp58ysI02DxgU4vIvffT4zzbNJpha/BSarVcQRO1Bh4ce/HUyklrsfiEcxu903C48sRSSHjv7pZfaql+8bGSwC4w0en3l0vGIHT3dejG7chgBFF4N53Tm/3NUSrRL4hdn81j9bPjeUARMQH+iT7me77CIiJD/SPn8msNjYKIfD9wBcHjFsxAmdP/Ff+IAkoCpPyJO4zPdt6Xhjjhm67kT560+2XmyosfPY/8QcORQi28vufLwAAAABJRU5ErkJggg==",
    na = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQYAAAA0BAMAAACa3osdAAAAD1BMVEUAAAAuOkY3Q0w+RlU1QErYRghYAAAABXRSTlMAFgwGEPXuQHQAAAJGSURBVFjDtZnRccMgEESRcAEcogCkpACSNCAs9V9TJoqtM8NwvsVjfm/ezt6yxh8yxUkGOG9irh16HkfsJMwI1xsDzlyCMKMV1hsowswXJWHmYL25w3emKMzwyyWa4DoUTDUjuA5EAa4DkRdmFOE6ECW4DkTSzOF6cCFmYddMBBeCCC6E/WOcMCO4DkIhAIbrABdiOJjUwTSvFi7EfDBrBxNbdYALkQkvBLV3tURYIZgJcB2IvDCjiL02cCGGG9OoA1gIZlakDq1d7bLT/ewfurXsNzNXJfOz5ILhwWem8oTl54nYd81ccWZf0v+AysM2m2LLjjNnaJX1eF5pfSbxSusjFyM3mWhsYyKVfWwhweCM5243YsCCWCGGfx9WiAFcKhiA4RiaQTj5YRBiwIKI/OACK0kMHIQXlto0L2QdAxxE5KWAlSQGDsKfwwFZiYOoGTiIyMNcrwQH4Z8zo8Rc6pXgIKKCmQXG5ioGNAivYUaJuaAxcBC8EhxEqjygekOlhzJGzAHXix3ZJUHPdeitHXcRBT0H6L3LwwToYb5z6VvQ84Ae5psE37nDA73VQwD0IN9W8k3l6dALr76T9gUPucNDbnuY7t1Mer3NZL3vy42xufY9nrZm9qDS284yaZjhztxMVHqef6VRq+f5Xzdpn9aNmVKPL2fWPHrMnIJR6WFjpvA9HHI8dBq9gtH5ng+G7z8WeiGZB0Gn0vMGZfIjM5a+58MCC04aD2WrdR58wRQePstC2atCby+ZccK/t4zuTd+D8PMLuPiXS5hsB90AAAAASUVORK5CYII=",
    ca = "/assets/star.34db71a0.png",
    Aa = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAmCAMAAACBKikvAAAAeFBMVEUAAAD29/j4+Pj29/j1+Pj4+Pj2+vr6+vr19vj19vf19/j29vf29/j19/j29vj29vj39/j39/r2+fn39/v39/v39/n////////29/j19vf29/j29/j19/j19/j29vj2+Pj19/f39/n29vn2+Pj39/v////////19vfUZqdzAAAAJ3RSTlMA+UPyaUo2MO7s1cm/ubKvl1pQPjofCAT0597atZyQi4V4d3A/GBB+O7w/AAABAUlEQVQ4y43TWRKCMBAE0CQERESQTdx3nfvf0IhR0Gkq6S+YetX5mESA3G7CL2nq52qi2gvOieY+LiKTyK+QV+JCv8rsDTOXm5DNxAHzD8ydhV6Vbd7DvIWkUfqw20oaRG53B62aL6n0MUusQJFJdtSVgQVDABfCpJROV4ouoXS40CAusbNRq3G3UmKQKhhzQfV3rYMRV7PrFSMXR2DNU+6mcOELDhf4lXKYQoiORu5OIHcAFYIKwCuCVwD3CO4BnJHNTKn+G0C7w6Ts7mhiN8hdQ69sis9/sekGDYOhma51O3iRem1GIYMXis/L39HyHNOFb/r0ECyPE9/2tw2P/fMEKVJWNRcLtgoAAAAASUVORK5CYII=",
    ga = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkAgMAAAANjH3HAAAACVBMVEUiMDsZJC0eKzV0dvt0AAAArUlEQVRIx3XNMREAMAzDwF62ADGkQDPfInitP+ipoSwllHJz3FBC6XEjWUoolcxJlhJKJXOSpYRSyZxkKaFUMidZSiiVzEmWEkolc5KlhFLJnGQpoVQyJ1lKKJXMSZYSSiVzkqWEUsmcZCmhVDInWUoolcxJlhJKJXOSpYRSyZxkKaFUMidZSiiVzEmWEkolc5KlhFLJnGQpoVQyJ1lKKJXMSZYSSiVzkqWEUskH4tGhvQsYag0AAAAASUVORK5CYII=",
    da = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkAgMAAAANjH3HAAAACVBMVEX////z9vn7/P0T2YIbAAAArUlEQVRIx3XNMREAMAzDwF62ADGkQDPfInitP+ipoSwllHJz3FBC6XEjWUoolcxJlhJKJXOSpYRSyZxkKaFUMidZSiiVzEmWEkolc5KlhFLJnGQpoVQyJ1lKKJXMSZYSSiVzkqWEUsmcZCmhVDInWUoolcxJlhJKJXOSpYRSyZxkKaFUMidZSiiVzEmWEkolc5KlhFLJnGQpoVQyJ1lKKJXMSZYSSiVzkqWEUskH4tGhvQsYag0AAAAASUVORK5CYII=",
    va = "/assets/Bronze.eae10e4e.png",
    oa = "/assets/Silver.15def0cd.png",
    pa = "/assets/Gold.2687cbeb.png",
    ma = "/assets/Bronze_w.030c9499.png",
    fa = "/assets/Silver_w.32acd21d.png",
    ha = "/assets/Gold_w.ebd4d479.png",
    ua = "/assets/Platinum.b77f6517.png",
    ba = "/assets/Diamond.b71311f8.png",
    Na = "/assets/tr_b.5d83e201.png",
    wa = "/assets/tr_s.2f50b427.png",
    _a = "/assets/tr_g.0770a403.png",
    Sa = "/assets/tr_p.aed56327.png",
    Ca = "/assets/tr_d.67e15949.png",
    La = "/assets/b_bar.ffc79e7e.png",
    Ia = "/assets/s_bar.cb84156b.png",
    Ma = "/assets/g_bar.ef1228e2.png",
    Pa = "/assets/p_bar.32c1a8ef.png",
    ya = "/assets/d_bar.dd325f97.png",
    Ba = "/assets/badge1.624c0289.png",
    Ra = "/assets/badge2.60fc7795.png",
    Ua = "/assets/badge3.7889993b.png",
    ka = "/assets/badge4.1e7d1b21.png",
    Va = "/assets/badge5.9df776c8.png",
    ja = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABGCAMAAAC0TEcTAAABAlBMVEUAAACRlqmSl6iSlqiSl6mNlqOTk6aSqqq/v7+Sl6iRlqiSl6l3fY2Rl6mSl6mTmKqSl6mTmKuTmaqVmayJjp94fox4fo2Slql3fo2Rl6l4fY2Rlql4foySl6l3fo2Slqh4f42SlqiSmKl5f4ySlqmTl6p4fo55fo14fo16foySmqp3go719vza3eaRlqh3fYy3u8nEyNTy8/rw8fjY2+XJzNeZnq+UmauSl6mPlKbz9Pvs7vXh5Ozc3+jq6/Pn6fHf4erU1uDQ092/w8+qrr2kqLidorOIjZ57gJDl5+7Dx9O1uMahpbWMkqOFi5uBh5d8g5OwtcOvs8HLz9m6v8u6vsuO9w8iAAAALHRSTlMA/N3tMxMNBwT51r6unpduYFEtIxz59fPt5OLPyse6qpGNg4F6eHFnV0c/LQ8iQfIAAAJgSURBVEjHvZbpcqJAFEaJG5poYqLZ933rFkbFIBoXQJJRs2iS93+VkS8MUypI35qqnF/a3Uc9lHiVwijkcgWJRuo0UyplTlMEJZ2Pl0A8nxZ17vZhgP07IaVwjNND0xziwXEhOuYs456saQZjhlZzH2fOItLyu3h1tcFAQ8XT3fwCJXGIM3aT+TRtLB0mQpRiTnf3nS6bouu4q3quGKDIl9vu5kO/zGYo9x/cne1LedZZj5VcBi0WQGuAzdj6lLKxgtVeh4XQ6eHAyoavJFeXcJlNtgATl39pNQklvRZHjFVhC6lYSIuvpSeXeRlvPGqzSNojHF1OSDHEcCYER1pMmuTomsEEMTR9EuZKKhOnMvKkX8JK+TdXqVKbc6rUeORUqdLknCQhBlCk1iOnSo0OBwQJMTTJQAxFQgxRQgxRKiOGJBltDggSYohSBTEUCTE0CTE0CTcAUUIMTcINQJUQQ5EQQ5RwA9AkxBAlFd8ZQcaepH9WRZXqJ36WMQAcTczRHAyAv6PGNqMV0/ZGjT/U9EE14pMNdG+oTY1Pa5Fj+eNzZlAPtdCYoTeog/4S2N0gpWvP/yUA8kUd81qtzsWomND1C1ma5/mphLT+tNOvYfnpWQpCUd5fsN/7+Kd89LD08q4owdKEtzrOjLtezBhP62+KEiaB1++0r+ok5us75hUbYRLw0hzLcrwYJVry0/wYIQlpfoyghDTXQYywhDTEkCTwQ9LWFlk6uE6lrg8o0s7JvQTuT3YEpaMbWfKRb46ipb3z4ux68XxvkbSZvZUCuc1uhkjZq6QUSvIqK/0ffwATstoHLsI5LgAAAABJRU5ErkJggg==",
    xa = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABGCAMAAAC0TEcTAAABBVBMVEUAAAC/v+a/v+a/v+bExOvKyvHX1/Wqqu++vua/v+W/v+a/v+a/v+a/v+Z5ebrBwebBwejExOl4eLl4eLi/v+W/v+Z3d7m/v+Z4eLl4eLi/v+W/v+a+vuV3d7l3d7m/v+a/v+Z4eLm/v+Z5ebq+vua/v+bAwOa/v+Z4eLl4eLt6eru+vufAwOd3d7t7e72AgL+AgMjj4//T0/u+vuV3d7jJyfDS0vPg4P7f3/3GxuvY2Pzi4v7c3P3V1fvR0fnMzO7CwunS0vvDw+ja2vjOzvbLy/PGxu27u+O2tuCwsNyentGSksmHh8N/f717e7vc3PrX1/bV1fXPz/Gnp9ajo9ScnM+Cgr9z50jhAAAAMXRSTlMA++DNJxEIBf3u1peObmlRLRz69ffz7eriyse+vbqrqqCRg4F6eGVbV05HPzUtHxQOLDsmnQAAAjRJREFUSMe9lmdTwjAYgFNBcCAy3HvvlSZtqVVw4UBxy///Kdq8yHtAmnHe+XwqJc+RJ/TuLUkinculiR2DOYcxJzdo42xNM8H0lrGyn2IdUvtGSnFZrL7y/StxsVzUKpm1CbHUjyiNfHE5sZZRO9sDYl2tQgWVmvg4sK1QDubEmvCFdngJxa25g6SYFYh5pV28QtpKURazOQkxAe0hgLTJzb60cYzpBdPGu5TCAsRc0wSuIW2hgM/M6JCIeaMK3kTa0Cg8WdmxYRbzjjFSgnexbHgsS0h6RBqjSBtJk5QsRp2WIk58zNSY+PidWKpRc4KwLfnmyqnrWUrRmevaSpVz11jCnbmWUgSKmYQxxhLGmEsYYyyhYiud4c70EsZoJM3O9BIcs62Eil7CGK2kjdFLuDO9hDuzlQJU9BLGGEv4z1hJEGMnwc4spQgUG6mGMXrCtsQ81+aHmAMD4OLGTLm5gAHQHjVhVa9Uw/aowaHmXaqVSw+HGo5PVlc5dYbjEyjMM0hTx7D5guyV4LYqjbnteyUAMht3mCaLuduQvVc1P2GP9Z4Y2Nlnk8jg/OkBj7/7mB+eOJdLPzzeYxrG3D9yrpD489dvGsZ8PfNkCWh+QJrnQcxHk3Ot1EnrxBhImAYxRhKkNWKnATE6CWk1Gi3OjSXkn6Ry2VqazZ+c5GdtpKnVQ7h1uDplKC3uZPFmdmdRL82sH/XeP1qfSZbKvLS0R6TsLZV4SfrNbv6YJHKc3yV/4xv1MQg021JKJgAAAABJRU5ErkJggg==",
    Ea = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABGCAMAAAC0TEcTAAAA/FBMVEUAAADomTLNdgrnmTHrnTTllinmky30qj3omjLomjHomjHnmjLnmTLnmjLomjLomjLomjPpmzLomTPbiSD/v0DNdwzMdQvomTHMdQromjHNdQromjLomTLomjLMdgvMdgrnmTLnmTHMdgvomjPOdwzomjLpmjLNdQzPdg3NdwvrmjXsmjXMdwvvnDHMdgz/uVz6qT3nmTHMdQryoTfzqUf+uFromjL9tlb9sk32pTrunzXrnDL8r0j7rEP6qz/5slLzqkfvpD/4qDzqnTXklCvciiDQexDOdwz9tFL3r03soTrrnzjgjybXgxj0q0n0q0jwpUL6qDzaiB7TfhQOVPg2AAAAL3RSTlMA+/jtJxMNB/z13tbMl455blEtHARo7eTiz8rHvr26q6qgkYOBZVtXTkc/NS0fbhGfZo0AAAJISURBVEjHvZZpU+owFIbLrqgoIO77vt42KaUXuFeLWHFf//9/MZ7WRjmhJxlnfD8w0PaB98mEObFGJV+p5C2zFCsZxjKVogmzm2OQ3K42crTIkiweaSGnG/D03ePjHbzZOKVltseZSOvJs23vqcVExrcJtb15+PZnz4Z4z/Bxfi8FOV6GZ27P7STnt3Bp+XgEUt+ENv0b+1tu+tB3s65AStORTODZQ/GCSG26NMxUy1Cj59uK+D24Wa5+Q2qrUgZHqq3WEqQwNaaSUamNTRUAmZ3JgUxzSAapNUEtNzMrdvOEUiZFbSJvTcKewTJqNdhZk1ZGvMplpuIF4vHMB9Sz9eN3YijQRrx/jhtDTV3kr+OYQtdnjink/xcEgigZB0GUDDQzgq6hGYJoGQwRMiSEZWgIyxhCPjQjILxnTCEkgyBimWkILzMNYRkagj+APoRlaAjL0BCWoSEsQ0NYhoYCLENDPbln6HRiiLmOyQ8JCAZAt62HtLswAD5HTeeCRi468ahJhhpz6WbJUJPjs+WmIi05PqPUVhhWwzJspYaOBKCWIlOu4sMHizq+DCMvUTMmDh84g1B2xM3CgaUK51f3cL/f/oL04dL9FedqSOThUqpJmcsHzlMgPnhlcvljmdcBT4eSjl3X7SbNKEjkLeoYNXvjXAeSaiCjB4FaGC0z14dALQxBhoJQfgnKZo2hpUax2Fgygea2TizIydacJrS2X5IXS/trNLSwg0769Z2F0VCWZ9cPLWUO18VN5Z2DPwVrZAqNA+tneQfsvPSvf+pybwAAAABJRU5ErkJggg==",
    Qa = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABGCAMAAAC0TEcTAAAA5FBMVEUAAACLVOmITeFsNseLVOmET+OGTeaGYfS/gP+LVemMVemMVOmLVeiMVeiMVOmMVOmMVemMVemNVulvOMiOVeiUXvKLVeiMVeltN8dsNseLVeltNsZsN8dtN8aMVOmMVOltN8eMVuptN8hsN8htNsaNVuiMVOlsOMeOVeuMV+xzQMypdv+ZYPqLVOhsNsaTWvKbZvOncv6MVemlcP2faPyaYfqYXvmQWO+OV+tuOMmibP2ibvqWXfaWYfCQWuyNVut9RtlzO86bY/qdZfufavecZ/SUW/OTXu6IUeWFTeKASdx4QdOH0d1DAAAAK3RSTlMA+yj4yh0NBwTu597WvpeOeW5RSy0T9/Pt4s7KuquqoJGDgWxnZVtXPzUUNmsKxAAAAi5JREFUSMe9l9lWwjAQQEtZFRXFfd/XNCltlUVAcAG3//8fw6R2jiRtOi/eJ07DhdyccqY4abiNhuvQqDQKnBcaFYJSu1zkwOJlLa9zs8cT9m5yKeUjePfTZPIEL47K9pjTLS4JJ0wyCblk69SSdqVihgEDgqFKu8pQbkvwnvc+S+i/w6XSbVrMMeym+8b+8NaF/R6b0qqr27DYYhot+LDt1eq806yrmIgZiFRavflH2VhWxwwxJvrq+Jc3EmVzpWCKMaUVVjZBqa0tqJiAZRKotIW1mrybl9QxR8xKpI5/yXVKppjstJIzy2mx3LRmYTNpyPITdUCifFFw7/lU6fHBo0rRi+cRpeBVGhQJYjyaBDFECWJoEsTQJIihShijS/YYu4Q7o0qo2CWMoUoYY5f0GLuEO6NKESgkKcJ7xi5hDE2CGKIEx0yT4AdAkyCGKA0xxk4nlrjvUb5ISjAARoN8ymCkBkA8ajptu9LuxKMmGWrcb1sUnydDDcdnOM1ypmE8PucHdXeQGtPFQY0065iWFlNv6g8fsBD6uuOHsCQfPnR6X7A2ms7FjODyV88xIcTzZ5ymxXw+C2GWJN8fmIYxH99CZEiiN/5Nw5hxT2RIwG+a78cxoFikJC2JySNhGsTklCANY+wS7nE8xp3ZJeSfpGKRLO1fVCoX+xRp58RVl9yTnZzSwXUVL1avD+zS7llZ+2dwtpsuFUXxcN0xsn4oF80r53dOKnfn2ucR+QEO88rujJWX0gAAAABJRU5ErkJggg==",
    Ta = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAABGCAMAAAC0TEcTAAAA5FBMVEUAAADKOFzdPmrLN13LO2K/MlvHOVjAOlnKN1zLOFzLOFzLOF3LN1zLOF3LOF3LOFzMN16iIEPMOF2iIETKOV7MOWCiIUKhIEPLN1yhIEOhIUOiIUPLN13KN12iIUOhIUPLOF3KOFyiIUPKOF2iIkPKN17MOF3NOF3NOFyhIEOkIkT5XITsTXbKN1yhIELcQmriSXD3WYLvUHnQO2DMOF31V3/zVX7xVHzlSnGkIUTXP2brTHXpSnPfRWzaQmjSPWLOOV6pJUfVPmTxUnvpT3XHNVnCMle8LlO4LVGwKUzINlu2LE876TEPAAAAK3RSTlMA/AX6Jx0TDcr17ufe1peOeWlRSzot+vXO7eLKvr26q6qgkYOBb25lW1ct1CytHQAAAkdJREFUSMe9lmdv6jAYRk2YnUCZ3XsmdhJSIGGkwO2g7f//Pzd5QsNtbbCtK/V8QCj2kTiRxWuyily5nCN6FMtZSrPloo5zu0XB1q2yUm/TlHZdScmfYfeT7z/hy1leHnO5QSMmvhnhT2jExqUk7S6JGbsmcMdJ2t26mBL2DPpmSn+AR6X6qphzrHvP5jeePTw+F6UZFcQ8Oq75A9d5RFrF+OnsbdMYu2sK6NpY3N77pjSO8XSGGBH9GTYcN1KlsJsRxYjSMruFJOZmUxwjTtu8idJyOzQm7JlSeiG27uRIG2emYyrRwckqkWz06ZjKONH2LMlQGprquANKM7HkqCt/LFtX6lmWrtTtWLqSC0VP6sPgJFkML8ljeEkew0uSGKnEx0glPkYq8WfGkkp8jK7UtSyJJI2RS4iRS5LXLJMQoyfhzGhKiNGTEKMn4TVrSojRk3BmNKUQMYrMYikbjzJ1x8bfMmaz56gpjocB8DVqZiO5Mpp9jRpiXCdDLRyuV4ZhMtSujX/H52S8zhlPluMzoXFEkeavUnzE0KOG6EowGAljBqIrAS4fH0izh1yMjZiPikF4gjeapnEx9C0gIhibvi6uektlcel7nTImliLeX5Zpy5iXd8bWSCz4pGkaYiI+A7ZGAos0z7a9JAaKRErT0hglCWlpjLLEgnnszAOmLIHpfI5fJpM4fklqtbSlw2qxWD3UkfYvHgh4uNhXlE7uDZJi3J/IpYMr7qafvzpYLbVY87RGhNROm6wpXqkWyEoK1Rr5P/4CrVTKsjnzxjcAAAAASUVORK5CYII=",
    Oa = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAcCAMAAAAKjix2AAAAQlBMVEUAAACRl6mSl6mSl6mSl6mUmaySm62iorqRlqiRlqmSl6iRl6iRl6mSmKmUl6qTl6uVnrCZmbOSlqiSlqiTmKqRlqgutlzcAAAAFXRSTlMA5vfupi0cBdHDvrOVg1FAHRTUcG8w9x3IAAAAbUlEQVQ4y73VNw4AMQhE0e913Bx9/6tuST+WoH+SZWCAkkKXaoESu1gPJNVOGYKKP0C1KzoO9wA+0fGOjueq43ih4wMdb+i4VR1PGXdsz/b/MGuV/5DYePovhq2kfxhYDAVVvwxGrx76jaFz8wPmT3yQuvIhVwAAAABJRU5ErkJggg==",
    za = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAcCAMAAAAKjix2AAAAP1BMVEUAAADlLXXgKHHgKHHgJ3HgJ3LgKHLgKnXgKHLgKHLgKHLgKHLgJ3PgKHLgKHLgKXHfKHTmM3PfQID/VarfJ3H7XQIuAAAAFHRSTlMAHPfm0sGmLe7t5bOVg29RQBQIAygTo0MAAABrSURBVDjLvdU3DgAxCETR73XaHH3/s25JP0jQP8kyMEBqeUhVIS1DrAJNtVOHrOITUO2GjtfHgW90fKDj+ul4Tuj4Qsc7Oi6vjqdOOLZnx3+YtSp8SGw8wxfDVjI+DCyGXAHoil5f6LvOzQ9Ptna/Nqi4JgAAAABJRU5ErkJggg==",
    Ka = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAcCAMAAAAKjix2AAAAQlBMVEUAAAD2yCL8ySP3yCL2xyL3yCP/6Eb2yCL3yCL3yCP2xyL2yCL3yCP5ySP3xyT6zCT5xyX/zCb3yCP4yCL4yCL2xyLHt9P4AAAAFXRSTlMA5hz37qYF0cO+s5WDUUAxKRTUcG+mdP/DAAAAbElEQVQ4y73VNw4AMQhE0e+8Ofv+V92SfixB/yTLwACxhC7VDDF3sR4oqk0nBBV/gGoXdBzuAXyg4w0dT1XHOaLjHR2v6LhVHacLd2zP9v8wa5X/kNh4+i+GraR/GFgMBVW/DEavHvqNoXPzA8N3fIX8NYkoAAAAAElFTkSuQmCC",
    Ga = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAcCAMAAAAKjix2AAAARVBMVEUAAAB4PP53PP54Pf16Pf+AQP+MRv94Pf54PP54PP53PP53PP54Pf54Pv14PP14P/94QP97Pv+AQP93PP55Pf93Pv93PP2cgJ0HAAAAFnRSTlMA5u6mLRwF0fn1w76zlYNRQB0U1HBvsjt2LAAAAG1JREFUOMu91TkOwDAIRNHveMu+x/c/akr6sQT9kywDA+QYmlQL5KGJ9UBU7ZggqPgDVLui43B34BMd7+h4LjoeLnR8oOMNHdei4ynhju3Z/h9mrfIfEhtP/8WwlfQPA4uhoOqXzujVQ7/SdW5+za2CgnTqU6wAAAAASUVORK5CYII=",
    Ja = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAAcCAMAAAAKjix2AAAARVBMVEUAAADp2v/p2//p2v/s3v/t2///6P/p2v/o2v/o2//p2v/p2//o2//p2//q2//p3P/r2//t3P/y5v/o2//o2//o2v/o2v/TCpFOAAAAFnRSTlMA5u6mLRwF0fn1w76zlYNRQB0U1HBvsjt2LAAAAG1JREFUOMu91TkOwDAIRNHveMu+x/c/akr6sQT9kywDA+QYmlQL5KGJ9UBU7ZggqPgDVLui43B34BMd7+h4LjoeLnR8oOMNHdei4ynhju3Z/h9mrfIfEhtP/8WwlfQPA4uhoOqXzujVQ7/SdW5+za2CgnTqU6wAAAAASUVORK5CYII=",
    Da = "/assets/white.7e3788f0.svg",
    Ya = "/assets/white_hover.6d143b05.svg",
    qa = "/assets/black.23aef3cd.svg",
    Ha = "/assets/black_hover.5b276789.svg",
    Wa = "/assets/chat.f51f666d.png",
    Xa = "/assets/recharge.0f6e68e9.png",
    Za = "/assets/coindrop.2d362bea.png",
    Fa = "/assets/dice.cb7509e5.png",
    $a = "/assets/gift.4da40e98.png",
    es = "/assets/jpg.dd00bef5.png",
    as = "/assets/money.9316ba83.png",
    ss = "/assets/ooo.1ed7df6a.png",
    rs = "/assets/people.5087dee8.png",
    ts = "/assets/pig.2870c414.png",
    is = "/assets/rain.81aa4c59.png",
    ls = "/assets/rakeback.459272ac.png",
    ns = "/assets/secret.5ee36c98.png",
    cs = "/assets/trophy.8501b925.png",
    As = "/assets/water.c5137b76.png",
    gs = "/assets/air.5e85a4f2.png",
    ds = "/assets/air_m.f1789377.png",
    vs = "/assets/air_w.8b70a3e8.png",
    os = "/assets/air_m_w.9f82f40e.png",
    ps = "/assets/card.666a69ae.png",
    ms = "/assets/card_m.739fb4c2.png",
    fs = "/assets/card_w.e0dfb740.png",
    hs = "/assets/card_m_w.54d5da66.png",
    us = "/assets/diamond.7c4f7f9e.png",
    bs = "/assets/diamond_m.6fd4401f.png",
    Ns = "/assets/diamond_w.f5de56fe.png",
    ws = "/assets/diamond_m_w.5221bf7e.png",
    _s = "/assets/emoji.058c08b0.png",
    Ss = "/assets/emoji_m.ae3b136b.png",
    Cs = "/assets/emoji_w.4f73ee09.png",
    Ls = "/assets/emoji_m_w.135991f1.png",
    Is = "/assets/gift.d2cad534.png",
    Ms = "/assets/gift_m.70fbc611.png",
    Ps = "/assets/gift_w.6b5072a2.png",
    ys = "/assets/gift_m_w.6ad92457.png",
    Bs = "/assets/sail.4040c7c5.png",
    Rs = "/assets/sail_m.bcb3baae.png",
    Us = "/assets/sail_w.9df63b4b.png",
    ks = "/assets/sail_m_w.34aeeaa6.png",
    Vs = "/assets/ship.9998da4f.png",
    js = "/assets/ship_m.73308b08.png",
    xs = "/assets/ship_w.b5fc330d.png",
    Es = "/assets/ship_m_w.c62fdcbc.png",
    Qs = "/assets/start.578d2808.png",
    Ts = "/assets/start_m.7bbee082.png",
    Os = "/assets/start_w.10098ce7.png",
    zs = "/assets/start_m_w.3fa95e69.png",
    Ks = "/assets/wallet.ff988bfc.png",
    Gs = "/assets/wallet_m.747f1dcc.png",
    Js = "/assets/wallet_w.37d464d6.png",
    Ds = "/assets/wallet_m_w.6ca64c45.png",
    Ys = "/assets/flag_bg.fcc40855.png",
    qs = "/assets/flag_bg_w.6eb38051.png",
    Hs = "/assets/rights.2058e9f5.svg",
    Ws = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAADBUlEQVR4Ae3b6WoTURgG4O87E+9G64YbKqK4oM1SFCRL/zVpLmMml5Gl/9IkIEq2Ki5YRMUNd+/GzDmeRMFQ07zNZK39BgLTeefMnPP0zXT+lPPluiHZdhVQuyYS9AQECBRBgAQICIBYGiRAQADE0iABAgIglgYJEBAAsTRIgIAAiKVBAgQEQCwNEiAgAGJpkAABARBLgwQICIBYGiRAQADE0iABAgIglgYJEBAAsTRIgIAAiKVBAgQEQCwNEiAgAGJpkAABARBLgwQICIBYGiRAQADE0iABAgIglgYJEBAAsTRIgIAAiKVBAgQEQCwNEiAgAGJpkAABARBLgwQICIB40Rqk7Xy7n4XZFgKImQ0x32Ollrqf3n732AJsoXnOoQdj6L5ynFw6Hv7RN5e7pVr7sO74LjHdMcZwXzbTXZ7H/833YMg8MOZQLru6/H3YivPlrSPMP10ivj0PqJkC/WlMnRV5mWTs2zCYnVmx0lgymjzbqJVZQs0EqAtjyDRCjuOtxSNfdy5+lJ83aq2jHd/3mDg2C6ipA1mcBlHIW08tfxkFAp1b2Nw6RtTxLFIMnTtOPjUg+xtuKoe8dCL2eZwJorGlauO49smzDY2ic4PkEweyjWkbR7nZeORTkAkFHZOvtU6wr3O2UeGg1xg0boJAvKXYcTOp8MdBN5rVseJm+6Q2fo7ILE/inmMDMdNDcpS3Ho9+mMSEJnWNQq15inxtn1F0a5xrBgayX6VHipSXTkXejzOBaY8tbbZOa+pCmZtB7jUykG3MY6PIzSZW3gW54bzG5Kv1M6zJPqPoxihzGAXoiQopNxOPvh3lBot2brHWPKs72j6j6Ppe5gaB7FfpqcPKXUtG3uzlgvvlnI1K65xven/1rg2b865AFuaZMvY9ZjX2etgF9ntWKjfOa7bvUcZcHbSWf4AszHNjG5NNRl4NGvC/HstXWhf4d6Ou9K/xLxDztlL2PSYRftl/wkHbL1bbF7W271HGXO6unQvl+jYp+x6TjL44aBjD1luoNC+R1t4vV6P3BL5hyhAAAAAASUVORK5CYII=",
    Xs = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAAC5klEQVR4Ae3b224SURgF4P8f8AVMpb0thTutp3iKGqPxEA+xRh8IeB6jscZDrMZeqPEUz17JobdAiS8gw/afkURSgQUDDNSuJpPQWTN79v6yOjNpglZ/OCf86Sng9UwYhAIEAkUgEIGAAIjZIAIBARCzQQQCAiBmgwgEBEDMBhEICICYDSIQEAAxG0QgIABiNohAQADEbBCBgACI2SACAQEQs0EEAgIgZoMIBARAzAYRCAiAmA0iEBAAMRtEICAAYjaIQEAAxGwQgYAAiNkgAgEBELNBBAICIGaDCAQEQMwGEQgIgJgNIhAQADEbRCAgAGI2iEBAAMRsEIGAAIhnqkGq0go2MOdY45kAMhRn2+2kyHKwBZ+DfbFK9LiYTvNr4W2EO7tUCrsz+r1zjj9Lbu8vJznbd8u+uK6dWZyfpwLUhrnrPCksLOm3fguult0+bYVQN6cBFStQCOPkniQlP5/Wr/1gtma1iluWpuStSzfihIoFqN2YVUmEMF+2Ln6Y3w1qv/gGJbISB9TEgQxnVa0xqUX9PAwEOra+4Q44a5QhraBjR8knBmQw9+3Omk9l9dMoE0Tn1ovuoD3uAqjr6Ngo+fiBVB4kRHJ7svoxyoSinrNZdId8kYK9HFyLOka388YJ9DDhGUxGP3S7UFz7NkvusN8yKJGr47jmOIAeJe3mO7ek78cxoXGN0Si7I80/N/Mro4wZGcjuMY8TAUxa340ygUmf26i4o75B2T3qcpRrDQ1kME8SScnNLerbKBec1jmNDXfMb0rBoC4NM4eBgQxmzZ4WuYWsvhnmArN2bLXojtvTNYC6OMjcIJDBPLWBcvNZfT3IgNvlmFrRnbC5BlAX+s25J5ApPxPP3nwz+qrfANs9q5XcSfsHS97+Os53W8u/QCrPPXtcp5b0ZbcT/td99bI71QpeD5yc61zjXyCVdS9hMGl90XnATvtcr7jTLT+EOhuu3W5a6/YWemanQaD1BiaBzW/ZHegI/MzGtQAAAABJRU5ErkJggg==",
    Zs = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAAAAXNSR0IArs4c6QAAAERlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAA6ABAAMAAAABAAEAAKACAAQAAAABAAAASKADAAQAAAABAAAASAAAAACQMUbvAAADAUlEQVR4Ae3b224SQRwG8PnvrjTtYxSKN1pPpdCoMRoP8RBrNPF1WJ7HaNR4iIfYCzXlUM/eSKGPAem6wziLxjSV8pUFltZ+JKR0v5md2V++TsJFpbU6axRfOwo4OyYMugIEAkUgEIGAAIjZIAIBARCzQQQCAiBmgwgEBEDMBhEICICYDSIQEAAxG0QgIABiNohAQADEbBCBgACI2SACAQEQs0EEAgIgZoMIBARAzAYRCAiAmA0iEBAAMRtEICAAYjaIQEAAxGwQgYAAiNkgAgEBELNBBAICIGaDCAQEQMwGEQgIgJgNIhAQADEbRCAgAGI2iEBAAMRsEIGAAIj3VINEVCd6gz0nGu8JIItilMg9x3Hmo3f0uXstUYrei3m9LydzNUKw/5N+33GlNJVrft+y6t3NWvqI1qYoSt2xg+yPybxkEv83/wfmgeup0tTCxrd+j765NntUhyqCuj0JqESBujBGHrri+VOFH1/7wWzPNsuH57UJfRFzK0moRIB+N0YeeeL6qXz9y/aHH+T3oJI9Fhrt27/O5SSgxg8kFsZx/NTi+udBINDYoDp3POx0fHuKLaOxw+TjAxJ57Lnip3KNT8NsEM0NapkToTYR1E00Nk4+DqAn3iGnmFpofIyzobhzgrXMyfBnp2Tn34h7j17zRgZkz5mnrpJiqtD80GuhpK4F5fQprUzJnk/XR7Hm0EAi8sx17OG7WK+NYkOjukdQzeZ0R/vGmGvD3DM2kIV57roWJlevDrOBcc8NatlFrbtQV+OsNTCQhXnhGnvGLK1X4iw4qTnB6lxeS8f+6Zkrg+xh10D2jHnpKgtTaJQHWWCvjQ3KmYJWEZS6vJu9QSAL88qIU5zJN1Z3c8P9MqZVySyJ6UJd6rfnHYHsd5/XxhN/Jtd83+8G+z1r1dKnJTS+/dJ8sdez/ANkz5g3SpnidGHjXa8J/+u1dnn2jFISnVEXtj7jXyALs6LELU7n62+3Djhon9uV7FlldAR1vvvs7XJ6pV3NnDtoEOh5I5PI5hfiqfUEgS41LgAAAABJRU5ErkJggg==";
const Fs = a => {
        let s = "";
        switch (a) {
            case "Bronze":
                s = Na;
                break;
            case "Silver":
                s = wa;
                break;
            case "Gold":
                s = _a;
                break;
            case "Platinum":
                s = Sa;
                break;
            case "Diamond":
                s = Ca;
                break
        }
        return s
    },
    t = {
        bronzeCard_w: ma,
        bronzeCard: va,
        silverCard_w: fa,
        silverCard: oa,
        goldCard_w: ha,
        goldCard: pa,
        platinumCard: ua,
        diamondCard: ba,
        bronzeMedal: ja,
        silverMedal: xa,
        goldMedal: Ea,
        platinumMedal: Qa,
        diamondMedal: Ta,
        BronzeMedal: Oa,
        SilverMedal: Ja,
        GoldMedal: Ka,
        PlatinumMedal: Ga,
        DiamondMedal: za,
        jbnc: $e,
        star: ca,
        star_w: Aa,
        element: Ge,
        element_w: Je,
        vipillu: $.illustration,
        vipbg_m: Oe,
        vipbg: Te,
        vipbg_m_w: Ke,
        vipbg_w: ze,
        jb_w: Ye,
        jb: De,
        jbr_w: Xe,
        jbr: We,
        box_r_w: He,
        boxr: qe,
        jbc_w: Fe,
        jbc: Ze,
        ribbon_w: aa,
        ribbon: ea,
        tr_w: ra,
        tr: sa,
        tr_r_w: ia,
        tr_r: ta,
        tstar_w: na,
        tstar: la,
        prompt_w: da,
        prompt: ga,
        right_w: Da,
        right_b: qa,
        right_w_h: Ya,
        right_b_h: Ha,
        badge1: Ba,
        badge2: Ra,
        badge3: Ua,
        badge4: ka,
        badge5: Va,
        b_bar: La,
        s_bar: Ia,
        g_bar: Ma,
        p_bar: Pa,
        d_bar: ya,
        chat: Wa,
        coindrop: Za,
        dice: Fa,
        gift: $a,
        jbfree: $.jbfree,
        jpg: es,
        money: as,
        ooo: ss,
        people: rs,
        pig: ts,
        recharge: Xa,
        rain: is,
        rakeback: ls,
        secret: ns,
        spider: _e.spider,
        trophy: cs,
        water: As,
        flag_bg: Ys,
        flag_bg_w: qs,
        fn_air: gs,
        fn_air_m: ds,
        fn_air_w: vs,
        fn_air_m_w: os,
        fn_card: ps,
        fn_card_m: ms,
        fn_card_w: fs,
        fn_card_m_w: hs,
        fn_diamond: us,
        fn_diamond_m: bs,
        fn_diamond_w: Ns,
        fn_diamond_m_w: ws,
        fn_emoji: _s,
        fn_emoji_m: Ss,
        fn_emoji_w: Cs,
        fn_emoji_m_w: Ls,
        fn_gift: Is,
        fn_gift_m: Ms,
        fn_gift_w: Ps,
        fn_gift_m_w: ys,
        fn_sail: Bs,
        fn_sail_m: Rs,
        fn_sail_w: Us,
        fn_sail_m_w: ks,
        fn_ship: Vs,
        fn_ship_m: js,
        fn_ship_w: xs,
        fn_ship_m_w: Es,
        fn_start: Qs,
        fn_start_m: Ts,
        fn_start_w: Os,
        fn_start_m_w: zs,
        fn_wallet: Ks,
        fn_wallet_m: Gs,
        fn_wallet_w: Js,
        fn_wallet_m_w: Ds,
        getColorTr: Fs,
        rights: Hs,
        level_1: Ws,
        level_2: Xs,
        level_3: Zs
    };
var $s = "/assets/1.0755d9fe.png",
    er = "/assets/2.0c56901e.png",
    ar = "/assets/3.6df0fd1c.png",
    sr = "/assets/4.1c882976.png",
    rr = "/assets/5.2859dbcc.png",
    tr = "/assets/1_w.e4b1c857.png",
    ir = "/assets/2_w.8f78b84c.png",
    lr = "/assets/3_w.fce78436.png",
    nr = "/assets/4_w.7e7cab2a.png",
    cr = "/assets/5_w.9719873e.png";
const Ar = {
    level_1: $s,
    level_2: er,
    level_3: ar,
    level_4: sr,
    level_5: rr,
    level_w_1: tr,
    level_w_2: ir,
    level_w_3: lr,
    level_w_4: nr,
    level_w_5: cr
};

function gr({
    type: a,
    level: s
}) {
    const r = R(),
        [i, l] = f.exports.useState(a - 1),
        g = [r("page.vip.cards.bronze"), r("page.vip.cards.silver"), r("page.vip.cards.golden"), r("page.vip.cards.platinum"), r("page.vip.cards.diamond")],
        o = [e(U, {
            k: "page.vip.cards.bronze.word",
            children: e("br", {})
        }), e(U, {
            k: "page.vip.cards.silver.word",
            children: e("br", {})
        }), e(U, {
            k: "page.vip.cards.golden.word",
            children: e("br", {})
        }), e(U, {
            k: "page.vip.cards.platinum.word",
            children: e("br", {})
        }), e(U, {
            k: "page.vip.cards.diamond.word",
            children: e("br", {})
        })];
    return n("div", {
        className: dr,
        children: [e("div", {
            className: "title",
            children: r("page.vip.cards.title")
        }), e(Se, {
            onClick: () => H.close()
        }), e("div", {
            className: "cards",
            children: e(vr, {
                type: a - 1,
                level: s,
                set: l,
                cardsLevel: g
            })
        }), e("p", {
            className: "word-one",
            children: i === a - 1 ? e(U, {
                k: "page.vip.cards.vipnow",
                children: g[i]
            }) : g[i]
        }), e("p", {
            className: "word-two",
            children: o[i]
        })]
    })
}
O({
    cl1: ["#1e2024", "#fff"],
    cl2: ["#f1f2f3", "#31373d"],
    cl3: ["#1b1c20", V("#F6F7FA", .2)]
});
const dr = "vosqyro",
    vr = ({
        type: a,
        level: s,
        set: r,
        cardsLevel: i
    }) => {
        const [l, g] = f.exports.useState(a), o = C.getLevelInfo();
        let c = 0;
        const A = [];
        for (let d = 0; d < o.length; d++) o[d] !== c && (c = o[d], A.push(d > 68 ? d - 69 : d));
        return n("div", {
            className: or,
            children: [e("div", {
                className: "mask"
            }), e(pr, {
                value: l,
                onChange: d => {
                    g(d), r(d)
                },
                children: i.map((d, m) => {
                    const v = (p.isDarken ? "level_" : "level_w_") + (m + 1);
                    return e("div", {
                        className: "item",
                        children: n("div", {
                            className: "wrap",
                            children: [e("img", {
                                alt: "vip-card",
                                src: Ar[v]
                            }), e("div", {
                                className: "bor",
                                style: {
                                    borderColor: m === l ? C.levelColor[m] : "transparent"
                                }
                            }), e("p", {
                                className: m === 4 ? "last" : "",
                                children: a === m ? s : A[m] + 1
                            })]
                        })
                    }, m)
                })
            })]
        })
    };
O({
    cl1: [V("#000000", .25), V("#D0D0D0", .2)]
});
const or = "v542rx2",
    pr = ({
        value: a,
        onChange: s,
        children: r
    }) => {
        const i = p.isMobile ? 1 : 1.5,
            l = k.Children.toArray(r),
            g = l.length,
            o = c => {
                if (c === a) return {
                    pos: 0,
                    className: "select",
                    scale: 1
                };
                const A = Math.floor(g / 2);
                let d = c - a,
                    m = !1;
                return d > A ? (d = -(A - d + A + 1), m = !0) : d < -A ? d = g - (a - c) : d < 0 && (m = !0), d == 2 || d == -2 ? {
                    pos: 34 * d,
                    className: "two " + (m ? "left" : "right"),
                    scale: .78
                } : {
                    pos: 34 * d,
                    className: "one " + (m ? "left" : "right"),
                    scale: .89
                }
            };
        return n("div", {
            className: `${mr} carousel-card`,
            children: [l.map((c, A) => {
                const d = o(A);
                return e("div", {
                    className: "item-wrap " + d.className,
                    style: {
                        transform: `translate3d(${d.pos*i}px, 0 , 0) scale3d(${d.scale}, ${d.scale}, 1)`
                    },
                    onClick: () => s(A),
                    children: c
                }, "item-" + A)
            }), e("div", {
                className: "left next",
                onClick: () => {
                    s(a === 0 ? g - 1 : a - 1)
                },
                children: e(Y, {
                    name: "Arrow"
                })
            }), e("div", {
                className: "right next",
                onClick: () => {
                    a === g - 1 ? s(0) : s(a + 1)
                },
                children: e(Y, {
                    name: "Arrow"
                })
            })]
        })
    };
O({
    cl1: ["#2d3035", V("#C2C8D0", .65)],
    cl2: ["#565b66", "#C2C8D0"],
    cl3: ["#565b66", V("#ffffff", .8)],
    cl4: ["#f5f6f7", "#fff"]
});
const mr = "c1i7a0z5";
const fr = Q(function({
        level: s
    }) {
        const [r, i] = f.exports.useState(1), {
            vipLevel: l,
            vipTypeNum: g
        } = C.getUserLevelInfo(s);
        f.exports.useEffect(() => {
            let m = z[s - 1];
            const v = m ? m[4] : 0;
            i(v)
        }, []);
        const o = () => l === 0 ? "0" : l > 9 ? String(l) : `0${l}`,
            c = () => "bage-" + r,
            A = () => {
                switch (r) {
                    case 2:
                        return e("img", {
                            className: "card-img",
                            src: p.isDarken ? t.silverCard : t.silverCard_w,
                            alt: "Silver.jpg"
                        });
                    case 3:
                        return e("img", {
                            className: "card-img",
                            src: p.isDarken ? t.goldCard : t.goldCard_w,
                            alt: "Gold.jpg"
                        });
                    case 4:
                        return e("img", {
                            className: "card-img",
                            src: t.platinumCard,
                            alt: "Platinum.jpg"
                        });
                    case 5:
                        return e("img", {
                            className: "card-img",
                            src: t.diamondCard,
                            alt: "Diamond.jpg"
                        });
                    default:
                        return e("img", {
                            className: "card-img",
                            src: p.isDarken ? t.bronzeCard : t.bronzeCard_w,
                            alt: "bronze.jpg"
                        })
                }
            },
            d = () => {
                switch (r) {
                    case 2:
                        return e("img", {
                            className: "badge-img",
                            src: t.badge2,
                            alt: "badge2.png"
                        });
                    case 3:
                        return e("img", {
                            className: "badge-img",
                            src: t.badge3,
                            alt: "badge3.png"
                        });
                    case 4:
                        return e("img", {
                            className: "badge-img",
                            src: t.badge4,
                            alt: "badge4.png"
                        });
                    case 5:
                        return e("img", {
                            className: "badge-img",
                            src: t.badge5,
                            alt: "badge5.png"
                        });
                    default:
                        return e("img", {
                            className: "badge-img",
                            src: t.badge1,
                            alt: "badge1.png"
                        })
                }
            };
        return n("div", {
            className: W(hr, "class", c()),
            onClick: () => H.push(e(gr, {
                type: g,
                level: l
            })),
            children: [e("div", {
                className: "card-img-wrap",
                children: A()
            }), n("div", {
                className: "card-badge",
                children: [e("div", {
                    className: "card-badge-num " + (r === 5 ? "diamond-dadge" : ""),
                    children: o()
                }), d()]
            })]
        })
    }),
    hr = "v1whgnos";
var ae = "/assets/b_light.ca24c72d.png",
    ur = "/assets/d_light.b4fb91f4.png",
    br = "/assets/g_light.c612be56.png",
    Nr = "/assets/s_light.5d77359c.png",
    wr = "/assets/p_light.bfed8834.png",
    _r = "/assets/bot.233a43f2.png",
    Sr = "/assets/bot_w.3c274288.png",
    se = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAcCAMAAABMOI/cAAAAdVBMVEUAAAD////19v35+v/////29/32+f/39//29/z19/z2+P329v329/329/329/z29vz29/329/339/339/z29vz3+P/4+P/2+P/2///////////29/319v329/329/329/329v319/339/z4+P/39//39//19v1SziwVAAAAJnRSTlMAA88wB/hTPr22i+Xh3cSzmYZ2X1hNRTcbFA3z7dipppOAYichIAfBAI8AAACjSURBVCjPdY9XEoQgEAUHxKxrTpvju/8RV7QsFcb+7C6meLSh74nH8w5CVBwEeeL9FxjYUAIV50UKsLcqjDi2H2IdQvtQiIna8OcMM26735wASynFYtX7hi2yVlo39wtM4shXpLwAFjLyaaTbJzdf1zTX1Qcf2vCTi38KY0g6+5xMHGikIouHDj4R+yQkDgm0bHghEWxwUBCLcDviycRB2P31D/8gGNba/leDAAAAAElFTkSuQmCC",
    q = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAaCAMAAACaYWzBAAAAZlBMVEUAAACRl6mSl6mTl6qSmKurq9WfpbWSl6iRlqmRl6iSl6iRl6mSlqmSl6mXma2ZmaqSl6mSl6mSl6mSmKmTmKqSmKuUmq2ZmaqUna+SlqiRlqmSl6mSl6iSmKmSlqmTlqqTmaqRlqgE5yEmAAAAIXRSTlMA651HPQQI+/basZCDdSUP48C5b1dQKB4c4s+mlpR6Wi1TK/z/AAAAmElEQVQoz3XRWRLCIBBF0WbMPBlj4uzb/yYVSoUKzfm8ryg+miLrRrznMTPcmsxwrviugRc7SKDlel8AwjJDjY8u7R2csuc7UK0UOx3wM6p/NcrloNY+KymwV7XakFlqJKbWv+plEVfx2MLnl9CbgSL2/s3lQjtXeOlJ7Og6d5HZ/TswgxHAnLlHObCDgiSWLRTxJpMZNEXemoYT9pszGGQAAAAASUVORK5CYII=",
    ve = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABYAAAAaCAMAAACEqFxyAAAAZlBMVEUAAAD/YKD/WofsTnbsTnbtT3n/YZLsTnfsTXfsTnftT3jyT3vsTXfrTXfsTXfsTnfrTXbsTnbsTnbsTnftTXbsTnbsT3jtTXbtT3jsUHnuUnnrTnbrTnftTnfuT3nuTnryUXnrTXaZtaX8AAAAIXRSTlMAAgr7l0EF5shbTRPx6eDX0L6pn4x4alQ4NB3etG9KLibiZPwwAAAAkUlEQVQoz4XRSQ6DMBBE0TLGZoYwQ+a6/yWDEhQcu6W85VerNg2HgmgWq0rFvOhCygMzaaNmJ+SM1OegRg3JIcgxN/rh3fZ8q39mTMNdMn8vs5SONldbVFNJT9UbAMVY0XW6PfeZUR/R4LBe9hpbuIrkU+Ex3KQWvpbkgsCdvCJkS+YQdIn44ymGZM3FbCP88wJMABBM3sxT6AAAAABJRU5ErkJggg==",
    oe = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAcCAMAAABMOI/cAAAAb1BMVEUAAAD3yCL3yCL4yCP3yCL3ySP4yST5yiT//2f3yCL2yCL3yCL/zSj/0C//7Dv3yCL3yCP3xyP3xyL4ySP3yCP4ySL6yib6yyT/0CP3yCL3yCL3xyP3xyP4xyL3yCT2ySL2yCP4yST3xyj3zin2xyLIRsPSAAAAJHRSTlMA+u5vtHo4KQL05tMRCgTg2sSMZmRLNTAV2cGgl2ldWVhHIB+n/99CAAAAoElEQVQoz42Q2RKDIAwAgwieeFWrva/8/zeWYmsBw4z7uBvITMBiDwFOoZAntE9wRweBMR0KzBTlH4j0X60ORbr2HD9cVn5gJkSjq1Oh/Vykpau+wT9d+R2WXY4O2dkcbRI1+rA4MW/ujaMPvFyWcLboiFdgIX97av/Cz2ief4HPzYSBPC7Sd7/qMFJBZdgCSYw9HTgr6SCPQKMEBJhgC28NPxRi1y/4cwAAAABJRU5ErkJggg==",
    pe = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAaCAMAAACaYWzBAAAAY1BMVEUAAACFhe2Ghu6Ghu6Ghu6Hh++Vlf+Ghu6Ghu6Hh/CLi/CIiPSKivWxsf+Ghu2Ghu6Ghu6Ghu6Ghu2Hh+6Hh+2Ghu6Ghu6Ghu+IiPGIiPKGhu2Ghu6Ghu2Ghu+FhfCIiO6Fhe3LaRw2AAAAIHRSTlMA9fradU0JppYsIBcQBOfV0b+7oY95WTYkHINnZWFDPKHAfpEAAACVSURBVCjPdZJZFoMgDEUjIqB1rGPn7H+VxXKqYpL7eV8IkBM4cgGBu+CLRggeKPTq8Mn6G+KVDRwi5ozPlQ8s9WWKKxmpDx6TT1w+Jl6GZKw2PQ9e76S6DAOyeEZ1r9+xxanIN3rZ/tYfOsUPm/7XWAMxc2jXA0GvvjU0MLUP3sCgpekWYVIMbV3xweCAZ8qkLTHUUb7JrxCnnQ81pgAAAABJRU5ErkJggg==",
    me = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAaCAMAAACaYWzBAAAAb1BMVEUAAACeaf+aYPuaYfykbf+ZYPuZYfuZYfubY/ubZP+ZYPuZYfqZYfqaYPuaYPqaYPqaYfyZYfuaYPuaYfubYfybZP+eZf+dYv+kgP+ZYfuaYPqaYfuZYfqaYvuaYfuZY/ybZPucY/+/gP////+ZYPtWWQQ1AAAAJHRSTlMAD/dRCufMjjkj8djSr6SglHtwZ1sqHxoH8964qIiDS0AxBAEDfka9AAAAkklEQVQoz42RVw6EMAwFHXrvC2xv7/5nXLGJRAi2xHzOJP6w6RAfwc++EJJYCG0khAIT609Az4YaKIQPwHPvg3wJl8D1aYQ/122Z+wyG6L3qsQ1hUSVaqwYueZzq+Y1na6/0FRmmevW3kWyGs3k+kMNLB2bzj8XfaY/KgDAghhjo+APCU2z4hhXxlL4QOiWEjf8BwJsRyGA+UaUAAAAASUVORK5CYII=",
    Cr = "/assets/sf.975597ba.png",
    Lr = "/assets/sf_w.ab90573d.png",
    Ir = "/assets/sf_svip.9f5e5bfb.png",
    Mr = "/assets/sf_svip_w.faae5d4e.png",
    Pr = "/assets/sf_svip_h.6054fdef.png",
    yr = "/assets/sf_svip_hw.2b3ed94b.png",
    Br = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAMAAAC7IEhfAAAAjVBMVEUAAAD5yyb3yCP3yCP/zyz//0f3xyP3yCP2yCP4yCL2xyL3yCL5ySP5yiX/2Dv2yCP2yCL3yCL3yCL2xyP3ySP4yCP4yiP/zCn3yCL3yCP2yCP2yCL3yCP3ySL3yCP2ySP5yCX3ySP6yCT6yST4yif/zCv3xyP2yCP3xyP3yCL3yCL4ySP4ySP3yCT2xyISu/UtAAAALnRSTlMAH/qZEQPbt5CJ7sJPKAbs6Lyjk3RIQxbz48ysqJZkVlM9NzEmC9OtoH54bWddMDsW9AAAAaRJREFUOMuNktdygzAQRZciEKIaG+zENS7puf//eZGtaLRYhPF5WY04s2gLjbDb0UMcw/D4iLd8Ap6WE8K2E6QROTS5OXdb34uBOuoFzXFjTqKPaiD2xBJXmjX+WDe3UHpij1F6T/wZF3888XNc/PTE+bg4vyu5kM242MjCFn7psmc4Mhscz1l30WIQgvOyhWb7Ak4YkCYCZ1/lQF7twYmIvJQLPWw96sV9Qi9lRnQ6EWVeQpeylps8WbV0o10l+UbWLiFPObs2oiKNCfHMJrRIGJKSGGUCgyQDe7jqnNcpVuCNHRxqab2lgmNHmgMcSTn8syU8EPWmZFsNI54xsyfJNkVQFZyNdQ4qEmyjJNHRrkSdvirg3YjvgHpNa7sWR9KIbzWcTFEMJ1N/C/saNsQvKlerkr7YANnLA3d9iBMgiVkvAnIUbB9TaFK2jwUTP9z1hgXDBxPfMMEbE5MpMXHeBZNcyHLO03UbyfbeaGXUrtP8THdUzdBrKvqHbChm5MP7rvZ7Ney0T3rdNf09mF2bTv9TIPxb+0WIYkIU6ckeT6kgzi9NoI4GmV+a8wAAAABJRU5ErkJggg==",
    fe = "/assets/dtr.1f911215.png",
    he = "/assets/dtr_w.ac9e3c2a.png",
    Rr = "/assets/dtr_h.af82116b.png",
    Ur = "/assets/dtr_h_w.8df16fc2.png",
    re = "/assets/b_tr.479e7048.png",
    kr = "/assets/s_tr.3d163d1e.png",
    Vr = "/assets/g_tr.0da7a354.png",
    jr = "/assets/p_tr.836e3e07.png",
    xr = "/assets/d_tr.58dc8454.png",
    Er = "/assets/botr.d40189c7.png",
    Qr = "/assets/botr_w.a434ff48.png";
const Tr = (a, s) => {
    const r = p.isDarken;
    let i = r ? fe : he;
    return s && (i = r ? Rr : Ur), a === 1 && (i = r ? Er : Qr), i
};
let Or = a => {
        let s = re;
        switch (a) {
            case 1:
                s = re;
                break;
            case 2:
                s = kr;
                break;
            case 3:
                s = Vr;
                break;
            case 4:
                s = jr;
                break;
            case 5:
                s = xr;
                break
        }
        return s
    },
    zr = a => {
        let s = ae;
        switch (a) {
            case 1:
                s = ae;
                break;
            case 2:
                s = Nr;
                break;
            case 3:
                s = br;
                break;
            case 4:
                s = wr;
                break;
            case 5:
                s = ur;
                break
        }
        return s
    },
    Kr = a => {
        let s = q;
        switch (a) {
            case 1:
                s = q;
                break;
            case 2:
                s = pe;
                break;
            case 3:
                s = oe;
                break;
            case 4:
                s = me;
                break;
            case 5:
                s = ve;
                break
        }
        return s
    };
const w = {
    get getdtr() {
        return p.isDarken ? fe : he
    },
    get botlight() {
        return p.isDarken ? _r : Sr
    },
    get slight() {
        return p.isDarken ? Cr : Lr
    },
    get sviplight() {
        return p.isDarken ? Ir : Mr
    },
    get sviplighthover() {
        return p.isDarken ? Pr : yr
    },
    get star() {
        return p.isDarken ? q : se
    },
    svip: Br,
    gettr: Tr,
    getCltr: Or,
    getlight: zr,
    getstar: Kr,
    b_star: q,
    w_star: se,
    s_star: pe,
    p_star: me,
    d_star: ve,
    g_star: oe
};
const D = [.029, .102, .177, .25, .325, .395, .47, .545, .617, .69, .763, .838, .91, .985];

function Gr(a) {
    const {
        isSvip: s,
        vipLevel: r
    } = C.getUserLevelInfo(a);
    let i = "V" + (a > 9 || a === 0 ? a : "0" + a);
    if (s) {
        let l = r > 9 ? r : "0" + r;
        i = "SV" + l
    }
    return i
}
const ue = Q(({
    level: a,
    list: s,
    percent: r,
    dialog: i
}) => {
    const {
        isSvip: l
    } = C.getUserLevelInfo(a), [g, o] = f.exports.useState("pr-bronze"), c = s.map(h => h[0]), A = c.map(h => a >= h), d = k.createRef(), m = k.createRef(), v = A.map(h => k.createRef());
    return f.exports.useEffect(() => {
        const h = ee(c, a),
            L = ee(c, a + 1);
        let I = 0;
        if (r) I = r;
        else {
            let b = 0;
            if (h === 0) b = a * D[0] / c[0];
            else if (a === c[c.length - 1]) b = 1;
            else {
                let u = D[h - 1],
                    y = a - c[h - 1],
                    E = D[h] - D[h - 1],
                    Ne = c[h] - c[h - 1],
                    we = E / Ne;
                b = u + y * we
            }
            I = b * 100
        }
        let P = 3,
            M = I * P / 100,
            j = r ? P / 5 : P / 10,
            B = "pr-bronze";
        _.set(d.current, {
            left: I + "%"
        }), _.to(m.current, {
            width: I + "%",
            duration: M
        }), _.from(d.current, {
            y: -20,
            opacity: 0,
            duration: P / 10,
            delay: M
        }), _.from(v.map(b => b.current), {
            y: i ? 3.2 : 5,
            duration: j,
            stagger: j
        });
        let T = s.map(b => b[4]),
            x = 0,
            S = setInterval(() => {
                if (x >= L) return l && (B = "pr-diamond"), clearInterval(S), !1;
                switch (T[x]) {
                    case 2:
                        B = "pr-silver";
                        break;
                    case 3:
                        B = "pr-gold";
                        break;
                    case 4:
                        B = "pr-platinum";
                        break;
                    case 5:
                        B = "pr-diamond";
                        break;
                    default:
                        B = "pr-bronze";
                        break
                }
                o(B), x < L && x++
            }, j * 1e3);
        return () => clearInterval(S)
    }, []), n("div", {
        className: W(Jr, "vip-bonus-progress", g),
        children: [e("div", {
            className: "tri-wrap",
            children: A.map((h, L) => e("li", {
                className: "tri-top " + (h && L != A.length - 1 ? "tri-active" : ""),
                ref: v[L]
            }, L))
        }), n("div", {
            className: "pr-bar",
            children: [n("div", {
                className: "pr-tip",
                ref: d,
                children: [e("div", {
                    className: "prompt-wrap",
                    children: e("div", {
                        className: "pr-num",
                        children: Gr(a)
                    })
                }), e("div", {
                    className: "tri-bot"
                })]
            }), e("div", {
                className: "pr-progress",
                ref: m,
                children: e("div", {
                    className: "dot-wrap",
                    children: e("div", {
                        className: "dot-near",
                        children: e("div", {
                            className: "dot-icon"
                        })
                    })
                })
            })]
        })]
    })
});
O({
    cl1: ["#3c404a", V("#dadde6", .8)],
    cl2: ["#1a1b1e", "#f5f6f7"],
    cl3: ["#f5f6f7", "#31373d"]
});
const Jr = "pldblhg";

function Dr(a, s) {
    return s === 1 / 0 ? "..." : `${a}${s>9?s:"0"+s}`
}
const Yr = Q(function({
        level: s,
        list: r,
        position: i
    }) {
        const l = o => {
                const {
                    isSvip: c,
                    vipLevel: A
                } = C.getUserLevelInfo(o);
                return Dr(c ? "SV" : "V", c ? A : o)
            },
            g = w.gettr(3, s >= N.svip);
        return n("div", {
            className: `${qr} sort-pr-bar`,
            children: [n("div", {
                className: "pr-mark-wrap",
                children: [r.map((o, c) => e("div", {
                    className: "pr-mark " + (o[0] > s ? "lock-num" : ""),
                    children: e("div", {
                        children: p.isMobile && c === r.length - 1 ? "SV..." : l(o[0])
                    })
                }, c)), n("div", {
                    className: "pr-tr m-omit",
                    children: [n("div", {
                        className: "tr-img-wrap",
                        children: [e("img", {
                            className: "bg-light",
                            src: w.slight,
                            alt: ""
                        }), e("img", {
                            className: "tr-img",
                            src: g,
                            alt: "tr.png"
                        })]
                    }), e("span", {
                        className: "omit",
                        children: "..."
                    })]
                })]
            }), e(ue, {
                level: s,
                list: r,
                percent: i
            })]
        })
    }),
    qr = "s11sw1h0";
const be = k.memo(function({
        children: s
    }) {
        return n("div", {
            className: `${Hr} flower-wrap`,
            children: [e("img", {
                alt: "",
                className: "bg-flower",
                src: w.sviplight
            }), s]
        })
    }),
    Hr = "f1jkrva4";

function J(a) {
    const s = z;
    if (!s) return [0, 0, 0, 0, 0];
    const r = s.length - (a ? 2 : 1);
    return z[r]
}

function G(a, s) {
    const i = [...J()];
    return a && (i[0] = a), i[5] = s ? 1 : 0, i
}

function Z(a) {
    return a.level <= 14 ? a.list.findIndex(i => i[5] && a.level < i[0]) : 8 - (a.level - 14) % 8 + a.level - 1
}

function F(a) {
    const r = a.list.filter(i => i[5]).find(i => a.level < i[0]);
    return r || G(Z(a))
}

function Wr(a) {
    const s = a.list;
    return [s[0], s[1], F(a), J(!0), J()]
}

function Xr(a) {
    const s = Z(a),
        r = a.level === s;
    return [a.list[a.level - 2], a.list[r ? a.level - 1 : a.level], F(a), J(!0), J()]
}

function Zr(a) {
    const s = Z(a),
        r = s + 8,
        i = a.level === s;
    return [G(a.level - 1), G(i ? a.level : a.level + 1), F(a), G(r - 1), G(r)]
}

function Fr(a) {
    return a.level <= 1 ? Wr(a) : a.level > 93 ? Zr(a) : Xr(a)
}
const $r = (a, s) => {
        const r = [6.5, 29.2, 50.5, 72.3, 96.5];
        let i = p.isMobile ? 18.7 : 18;
        if (a === 0) i = 1;
        else if (a === 1) i = 7.5;
        else if (s.find(l => l[0] === a)) return r[s.findIndex(l => l[0] === a)];
        return i
    },
    et = Q(function({
        onAlertVipLevel: s
    }) {
        const r = p.isMobile ? 300 : 640,
            i = R(),
            [l, g] = f.exports.useState(r),
            o = le(m => {
                const v = m.width || r;
                g(v > r ? r : v)
            }),
            c = N.state.level,
            A = Fr({
                list: z,
                level: c
            }),
            d = $r(c, A);
        return n("div", {
            className: `${at} vip-user`,
            children: [n("div", {
                className: "user-info-wrap",
                children: [n("div", {
                    className: "user-info",
                    children: [e(Ce, {
                        userId: C.userId,
                        name: C.name
                    }), n("div", {
                        className: "user-info-detail",
                        children: [e("div", {
                            className: "user-name",
                            children: C.name
                        }), e("div", {
                            className: "user-star",
                            children: e(ne, {
                                level: N.state.level
                            })
                        })]
                    })]
                }), n("div", {
                    onClick: s,
                    className: "about-level-btn",
                    children: [i("title.user_vip_about"), e(Y, {
                        name: "Arrow"
                    })]
                })]
            }), e("div", {
                className: "level-big-wrap",
                ref: o,
                children: n("div", {
                    className: "tran-wrap",
                    style: {
                        transform: `scale(${l/r})`
                    },
                    children: [e("div", {
                        className: "level-cl-wrap",
                        onClick: s,
                        children: n("div", {
                            className: "level-cont",
                            children: [e(Yr, {
                                level: c,
                                list: A,
                                position: d
                            }), n("div", {
                                className: "level-bot-wrap",
                                children: [n("div", {
                                    className: "level-xp",
                                    children: [i("page.level.current_xp"), " :", n("span", {
                                        className: "xw-txt",
                                        children: [N.state.totalXp, " XP"]
                                    }), " /", " ", i("page.level.total_wager"), " :", e("span", {
                                        className: "xw-txt",
                                        children: e(ce, {
                                            amount: Number(N.state.betXpToUsd)
                                        })
                                    })]
                                }), e("div", {
                                    className: "level-next",
                                    children: n(U, {
                                        k: "page.vip.level.next",
                                        children: [n("span", {
                                            className: "xw-txt",
                                            children: [N.state.nextLevelTotalXp - N.state.totalXp, " ", "xp"]
                                        }), n("span", {
                                            className: "xw-txt",
                                            children: [N.state.level + 1 > 69 ? "SVIP " : "VIP ", N.state.level + 1 > 69 ? N.state.level - 68 : N.state.level + 1]
                                        })]
                                    })
                                })]
                            })]
                        })
                    }), e("div", {
                        className: "level-right-super",
                        children: n("div", {
                            className: "super-inner",
                            children: [n("div", {
                                className: "svip-super",
                                children: [e("img", {
                                    src: w.svip,
                                    alt: "f"
                                }), e("p", {
                                    children: "SVIP..."
                                })]
                            }), e(be, {
                                children: e("img", {
                                    className: "tr-img",
                                    src: w.gettr(3, !0),
                                    alt: "tr.png"
                                })
                            })]
                        })
                    })]
                })
            })]
        })
    });
O({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [V("#2d3035", .6), "#f5f6fa"],
    cl3: ["#424752", "rgba(66,71,82,.05)"]
});
const at = "v13qf59s";
const st = Q(function({
        onAlertVipLevel: s
    }) {
        const r = R(),
            i = p.isDarken ? p.isMobile ? t.vipbg_m : t.vipbg : p.isMobile ? t.vipbg_m_w : t.vipbg_w;
        return n("div", {
            className: `${rt} vip-top-banner`,
            children: [n("div", {
                className: "banner-head",
                children: [e("img", {
                    className: "vip-bc-img",
                    alt: "banner.png",
                    src: i
                }), n("div", {
                    className: "vip-desc",
                    children: [n("div", {
                        className: "vip-club-tit",
                        children: [r("title.user_level"), " - ", e("br", {}), r("page.vip.title")]
                    }), e("div", {
                        className: "vip-club-desc",
                        children: p.isMobile ? r("page.vip.title_des_mob") : r("page.vip.title_des")
                    })]
                })]
            }), C.login ? n(K, {
                children: [n("div", {
                    className: "vip-user-panel",
                    children: [e(fr, {
                        level: N.state.level
                    }), e(et, {
                        onAlertVipLevel: s
                    })]
                }), n("div", {
                    className: "banner-cont-w",
                    children: [n("div", {
                        className: "level-cont cont-l cont-margin",
                        children: [e("div", {
                            className: "level-sub-tit",
                            children: r("page.vip.upgrade_title")
                        }), e("div", {
                            className: "level-sub-desc",
                            children: r("page.vip.upgrade_des")
                        })]
                    }), n("div", {
                        className: "level-cont cont-r cont-margin",
                        children: [e("div", {
                            className: "level-sub-tit",
                            children: r("page.vip.upLevel_title")
                        }), e("div", {
                            className: "level-sub-desc",
                            children: r("page.vip.upLevel_des")
                        }), e(Ae, {
                            type: "conic",
                            className: "level-btn-detail",
                            onClick: s,
                            children: r("common.actions.details")
                        })]
                    })]
                })]
            }) : null]
        })
    }),
    rt = "v12inhoj";
const tt = Q(function({
        level: s
    }) {
        const r = R(),
            i = [{
                img: t.dice,
                url: "/bonus/roll",
                lv: "03",
                title: r("page.vip.rights.title3"),
                desc: r("page.vip.rights.des3"),
                vipLevel: t.level_1
            }, {
                img: t.money,
                url: "",
                lv: "04",
                title: r("page.vip.rights.title4"),
                desc: r("page.vip.rights.des4"),
                vipLevel: t.level_1
            }, {
                img: t.secret,
                url: "",
                lv: "04",
                title: r("page.vip.rights.title5"),
                desc: r("page.vip.rights.des5"),
                vipLevel: t.level_1
            }, {
                img: t.chat,
                url: "/chat",
                lv: "04",
                title: r("page.vip.rights.title6"),
                desc: r("page.vip.rights.des6"),
                vipLevel: t.level_1
            }, {
                img: t.rain,
                url: "/bonus/rain",
                lv: "04",
                title: r("page.vip.rights.title7"),
                desc: r("page.vip.rights.des7"),
                vipLevel: t.level_1
            }, {
                img: t.coindrop,
                url: "/user/coindrop_send",
                lv: "07",
                title: r("page.vip.rights.title8"),
                desc: r("page.vip.rights.des8"),
                vipLevel: t.level_1
            }, {
                img: t.jpg,
                url: "",
                lv: "08",
                title: r("page.vip.rights.title10"),
                desc: r("page.vip.rights.des10"),
                vipLevel: t.level_1
            }, {
                img: t.spider,
                url: "/bonus/crocodile",
                lv: "14",
                title: r("page.vip.rights.title11"),
                desc: r("page.vip.rights.des11"),
                vipLevel: t.level_2
            }, {
                img: t.rakeback,
                url: "/rakeback",
                lv: "14",
                title: r("page.vip.rights.title12"),
                desc: r("page.vip.rights.des12"),
                vipLevel: t.level_2
            }, {
                img: t.pig,
                url: "",
                lv: "14",
                title: r("page.vip.rights.title13"),
                desc: r("page.vip.rights.des13"),
                vipLevel: t.level_2
            }, {
                img: t.jbfree,
                url: "",
                lv: "22",
                title: r("page.vip.rights.title14"),
                desc: r("page.vip.rights.des14"),
                vipLevel: t.level_3
            }, {
                img: t.recharge,
                url: "/recharge",
                lv: "22",
                title: r("page.vip.rights.title15"),
                desc: r("page.vip.rights.des15"),
                vipLevel: t.level_3
            }];
        return e("div", {
            className: `${gt} l-box-wrap`,
            children: p.isMobile ? e(At, {
                boxList: i,
                level: s
            }) : e(lt, {
                boxList: i,
                level: s
            })
        })
    }),
    it = a => {
        const s = [...a[a.length - 1]],
            r = a[0].length - s.length;
        if (r > 0) {
            let i = [];
            i = [...a[a.length - 2]].splice(a[0].length - r).concat(s);
            const o = [...a];
            return o[o.length - 1] = i, o
        } else return a
    },
    lt = Q(function({
        boxList: s,
        level: r
    }) {
        const i = ge(),
            l = 210,
            g = s.length,
            o = R(),
            [c, A] = f.exports.useState(6),
            [d, m] = f.exports.useState(0),
            [v, h] = f.exports.useState(3),
            [L, I] = f.exports.useState(!0),
            P = f.exports.useRef(null),
            M = f.exports.useRef(!0),
            j = le(({
                width: b
            }) => {
                const u = Math.floor(b / l);
                c !== u && (A(u), m(0), h(Math.ceil(g / u)))
            }),
            B = b => {
                b !== d && (M.current = !1, m(b))
            },
            T = b => {
                const u = Me(s, b);
                return it(u)
            },
            x = b => b.map((u, y) => {
                const E = r >= Number(u.lv);
                return n("div", {
                    onClick: () => {
                        u.url && u.url !== "" && E && i(u.url)
                    },
                    className: "flag-wrap " + (u.url && u.url !== "" ? "hove-cus " : "") + (E || !C.login ? "open" : ""),
                    children: [n("div", {
                        className: "top",
                        children: [e("div", {
                            className: "top-lock",
                            children: o(E ? "page.vip.rights.unlocked" : "page.vip.rights.locked")
                        }), e("div", {
                            className: "tag-img",
                            style: {
                                backgroundImage: `url(${u.vipLevel})`,
                                color: u.lv === "14" ? "#31373d" : "#f5f6f7"
                            },
                            children: n("span", {
                                className: "rights",
                                children: ["V", u.lv]
                            })
                        })]
                    }), e("div", {
                        className: "flag-img-wrap",
                        children: e("img", {
                            className: "flag-img",
                            src: u.img,
                            alt: ""
                        })
                    }), n("div", {
                        className: "flag-box",
                        children: [e("div", {
                            className: "flag-tit",
                            children: u.title
                        }), e("div", {
                            className: "flag-desc",
                            dangerouslySetInnerHTML: {
                                __html: u.desc
                            }
                        })]
                    })]
                }, "item-" + y)
            }),
            S = T(c)[d];
        return n(K, {
            children: [e("div", {
                ref: j,
                className: `${dt} swiper-slide`,
                children: e(Le, {
                    from: {
                        transform: `translate3d(${L?"100%":"-100%"}, 0, 0)`,
                        opacity: 0
                    },
                    enter: {
                        transform: "translate3d(0%, 0, 0)",
                        opacity: 1
                    },
                    leave: {
                        transform: `translate3d(${L?"-50%":"50%"}, 0, 0)`,
                        opacity: 0
                    },
                    immediate: M.current,
                    children: S && e(nt, {
                        children: e(K, {
                            children: x(S)
                        })
                    }, d)
                })
            }), e("div", {
                className: "swiper-page-wrap",
                ref: P,
                children: Array(v).fill(0).map((b, u) => e(ct, {
                    active: d === u,
                    setPage: () => {
                        B(u), I(u > d)
                    }
                }, u))
            })]
        })
    }),
    nt = k.memo(({
        style: a,
        children: s
    }) => e(Ie.div, {
        style: a,
        children: s
    })),
    ct = function({
        setPage: a,
        active: s
    }) {
        return e("div", {
            className: "swiper-page " + (s ? "active" : ""),
            onClick: a
        })
    },
    At = function({
        boxList: s,
        level: r
    }) {
        const i = ge();
        return e("div", {
            className: `${vt} mobile-swiper-wrap`,
            children: s.map((l, g) => {
                const o = r >= Number(l.lv) || !C.login,
                    c = r >= Number(l.lv);
                return n("div", {
                    className: "flag-wrap " + (o ? "open" : ""),
                    onClick: () => {
                        l.url && l.url !== "" && c && i(l.url)
                    },
                    children: [n("div", {
                        className: "top",
                        children: [e("div", {
                            className: "top-lock",
                            children: o ? "Unlocked" : "locked"
                        }), e("div", {
                            className: "tag-img",
                            style: {
                                backgroundImage: `url(${l.vipLevel})`,
                                color: l.lv === "14" ? "#31373d" : "#f5f6f7"
                            },
                            children: n("span", {
                                children: ["V", l.lv]
                            })
                        })]
                    }), e("div", {
                        className: "flag-img-wrap",
                        children: e("img", {
                            className: "flag-img",
                            src: l.img,
                            alt: ""
                        })
                    }), n("div", {
                        className: "flag-box",
                        children: [e("div", {
                            className: "flag-tit",
                            children: l.title
                        }), e("div", {
                            className: "flag-desc",
                            dangerouslySetInnerHTML: {
                                __html: l.desc
                            }
                        })]
                    })]
                }, g)
            })
        })
    },
    gt = "l1vfoeq7",
    dt = "le2lgp6",
    vt = "lsseuag";
window.vipStore = N;

function ot(a, s) {
    let r = !1;
    return s.map((i, l) => {
        let g = 3;
        g = a >= i[0] ? 1 : g, g = a < i[0] ? 3 : g, !r && a < i[0] && (g = 2, r = !0), l === s.length - 1 && a >= 102 && (g = 3);
        const {
            isSvip: o,
            vipLevel: c
        } = C.getUserLevelInfo(i[0]);
        let A = i[0] < 10 ? "V0" + i[0] : "V" + i[0];
        o && (i[0] === 70 ? A = "SVIP" : c > 33 ? A = "SV..." : A = "SV" + (i[0] - 69));
        let d = "tr_" + i[4];
        switch (g) {
            case 1:
                d += " tr_disabled";
                break;
            case 2:
                d += " tr_near";
                break;
            case 3:
                d += " tr_lock";
                break
        }
        return {
            lvtext: A,
            lvnum: i[0],
            lvcolor: i[4],
            className: d,
            status: g,
            svip: o
        }
    })
}
let pt = (a, s, r, i) => {
        let l;
        return !a && s != r ? l = e("img", {
            className: "botl-img",
            src: w.botlight
        }) : s === r && (l = e("img", {
            className: "botl-img cl-botl-img",
            src: w.getlight(i)
        })), l
    },
    mt = (a, s, r, i, l) => {
        let g;
        return s === r ? g = e("img", {
            className: "tr-img",
            src: w.getCltr(i),
            alt: "tr.png"
        }) : g = e("img", {
            className: "tr-img",
            src: w.gettr(l, a),
            alt: "tr.png"
        }), g
    },
    ft = (a, s, r, i) => {
        let l;
        return a && s === r ? l = e("div", {
            className: "light-img light-svip ani-svip",
            children: e("img", {
                src: w.sviplighthover,
                alt: ""
            })
        }) : a ? l = e("div", {
            className: "light-img light-svip",
            children: e("img", {
                src: w.sviplight,
                alt: ""
            })
        }) : i === 2 && s != r && (l = e("div", {
            className: "light-img",
            children: e("img", {
                src: w.slight,
                alt: ""
            })
        })), l
    },
    ht = (a, s) => {
        let r;
        return a ? r = n("div", {
            className: "svip-bs-title vip-bs-title",
            children: [e("img", {
                className: "svip-img",
                src: w.svip,
                alt: ""
            }), s]
        }) : r = e("div", {
            className: "vip-bs-title",
            children: s
        }), r
    };
const ut = k.memo(({
        list: a,
        level: s
    }) => {
        const [r, i] = f.exports.useState(-1);
        let l = f.exports.useCallback((c, A) => {
                i(A === 1 ? -1 : c)
            }, []),
            g = f.exports.useCallback(() => {
                i(-1)
            }, []),
            o = f.exports.useCallback((c, A) => ot(c, A), [s, a]);
        return e("div", {
            className: `${bt} vip-bonus-list`,
            children: e("div", {
                className: "vip-bonus-wrap",
                children: o(s, a).map((c, A) => e("div", {
                    onMouseEnter: () => l(A, c.status),
                    onMouseLeave: () => g(),
                    className: `vip-bonus-item ${c.className} ${r===A?"tr_active":""}`,
                    children: n("div", {
                        className: "hover-ani-tr",
                        children: [ht(c.svip, c.lvtext), e("div", {
                            className: "vip-bonus-bar"
                        }), ft(c.svip, A, r, c.status), pt(c.svip, A, r, c.lvcolor), mt(c.svip, A, r, c.lvcolor, c.status), A === r && n("div", {
                            className: "star-wrap",
                            children: [e("img", {
                                className: "star-img star-b",
                                src: w.w_star,
                                alt: ""
                            }), e("img", {
                                className: "star-img star-g",
                                src: w.g_star,
                                alt: ""
                            }), e("img", {
                                className: "star-img star-gm",
                                src: w.g_star,
                                alt: ""
                            }), e("img", {
                                className: "star-img star-o",
                                src: w.getstar(c.lvcolor),
                                alt: ""
                            })]
                        })]
                    })
                }, A))
            })
        })
    }),
    bt = "ve37dr7";
const Nt = z.filter(a => a[5]),
    te = Nt.concat([
        [103, 1 / 0, 10, 1 / 0, 5, 1, 1 / 0]
    ]),
    wt = () => {
        const a = R(),
            [s, r] = f.exports.useState(!0);
        let i = N.state.level,
            l = k.createRef(),
            g = 0;
        const o = X();
        f.exports.useEffect(() => {
            var d, m;
            if (g = ((d = l.current) == null ? void 0 : d.scrollWidth) - ((m = l.current) == null ? void 0 : m.offsetWidth), p.isMobile) {
                let v = i * g / N.totalLevel;
                _.to(l.current, {
                    duration: 1,
                    scrollLeft: v,
                    delay: .2
                })
            } else i > 65 ? setTimeout(() => {
                var v, h;
                o() && (g = ((v = l.current) == null ? void 0 : v.scrollWidth) - ((h = l.current) == null ? void 0 : h.offsetWidth), _.to(l.current, {
                    duration: 1,
                    scrollLeft: g
                }))
            }, 1500) : _.to(l.current, {
                scrollLeft: g,
                duration: 1,
                delay: 2.5,
                onComplete: () => {
                    _.to(l.current, {
                        duration: 1,
                        scrollLeft: 0,
                        delay: .5
                    })
                }
            });
            return () => {
                _.killTweensOf(l.current)
            }
        }, []);
        const c = f.exports.useCallback(d => {
                let v = d.target.scrollLeft;
                v === 0 ? r(!0) : v >= g - 5 && r(!1)
            }, []),
            A = d => {
                var v, h;
                let m = 0;
                d || (m = ((v = l.current) == null ? void 0 : v.scrollWidth) - ((h = l.current) == null ? void 0 : h.offsetWidth)), _.to(l.current, {
                    duration: .5,
                    scrollLeft: m
                })
            };
        return n("div", {
            className: `${_t} vip-bonus`,
            children: [n("div", {
                className: "vip-bonus-title",
                children: [e("img", {
                    className: "img-star",
                    src: p.isDarken ? t.star : t.star_w,
                    alt: ""
                }), e("span", {
                    className: "vip-bonus-subtit",
                    children: a("page.vip.dialog.level_name")
                }), e("img", {
                    className: "img-star",
                    src: p.isDarken ? t.star : t.star_w,
                    alt: ""
                })]
            }), n("div", {
                onClick: () => A(!0),
                className: `tag t-left ${s?"disabled":""}`,
                children: [e("img", {
                    className: "tag-img",
                    src: p.isDarken ? t.right_b : t.right_w
                }), e("img", {
                    className: "hover-img",
                    src: p.isDarken ? t.right_b_h : t.right_w_h
                })]
            }), n("div", {
                onClick: () => A(!1),
                className: `tag t-right ${s?"":"disabled"}`,
                children: [e("img", {
                    className: "tag-img",
                    src: p.isDarken ? t.right_b : t.right_w
                }), e("img", {
                    className: "hover-img",
                    src: p.isDarken ? t.right_b_h : t.right_w_h
                })]
            }), e("div", {
                className: "bp-wrap",
                ref: l,
                onScroll: c,
                children: n("div", {
                    className: "bp-scroll",
                    children: [e(ut, {
                        level: i,
                        list: te
                    }), e(ue, {
                        level: i,
                        list: te,
                        dialog: !0,
                        percent: i >= 102 ? 95 : void 0
                    })]
                })
            }), e("div", {
                className: "vip-bonus-cont",
                children: a("page.vip.dialog.level_more")
            })]
        })
    };
O({
    cl1: [V("#1e2024", .8), "#fff"],
    cl2: [V("#2d3035", .5), "#f5f6f7"],
    cl3: ["#f5f6f7", "#31373d"]
});
const _t = "vzakgay";
const ie = ({
        finished: a,
        level: s,
        nextbar: r,
        nextbarPercent: i,
        nextdiffxp: l
    }) => {
        let g = p.isMobile ? 1.1 : 1.5,
            o = Number(Number(s) / g) + 12 + "px";
        const c = R();
        return n("div", {
            className: W("xp-pr-wrap", St, r && "m-next-bar"),
            children: [n("div", {
                className: "xp-progress",
                style: {
                    width: o
                },
                children: [a < 2 && e("div", {
                    className: "pr-complete"
                }), a >= 2 && r && e("div", {
                    className: "pr-completing",
                    style: {
                        width: i + "%"
                    }
                })]
            }), a === 0 && e("div", {
                className: "xp-pr-complete",
                children: c("common.finished")
            }), a === 1 && e("div", {
                className: "xp-pr-completing",
                children: c("common.finished")
            }), a != 0 && a != 1 && r && n("div", {
                className: "xp-pr-nextlv",
                children: [n("div", {
                    className: "xp-diff",
                    children: [l, " XP"]
                }), n("div", {
                    className: "xp-percent",
                    children: [i, "%"]
                })]
            }), a != 0 && a != 1 && !r && e("div", {
                className: "xp-pr-nocomplete",
                children: c("common.no_started")
            })]
        })
    },
    St = "xtc9i0e",
    Ct = ({
        finished: a,
        highLight: s,
        clv: r,
        nextbar: i
    }) => {
        let l;
        return i ? s ? l = e("img", {
            className: "jb-img near",
            src: p.isDarken ? t.boxr : t.box_r_w
        }) : l = e("img", {
            className: "jb-img near",
            src: p.isDarken ? t.jbr : t.jbr_w
        }) : a === 0 && s ? l = e("img", {
            className: "jb-img",
            src: p.isDarken ? t.tr_r : t.tr_r_w
        }) : a === 0 ? l = e("img", {
            className: "jb-img",
            src: p.isDarken ? t.jbc : t.jbc_w
        }) : a === 1 && s ? l = e("img", {
            className: "jb-img",
            src: t.getColorTr(r)
        }) : a === 1 ? l = e("img", {
            className: "jb-img",
            src: t.jbnc
        }) : a === 2 && s ? l = e("img", {
            className: "jb-img",
            src: p.isDarken ? t.tr : t.tr_w
        }) : a === 2 && (l = e("img", {
            className: "jb-img",
            src: p.isDarken ? t.jb : t.jb_w
        })), e(K, {
            children: l
        })
    };
const Lt = {
        bronze: t.bronzeMedal,
        silver: t.silverMedal,
        gold: t.goldMedal,
        platinum: t.platinumMedal,
        diamond: t.diamondMedal
    },
    It = k.memo(({
        list: a,
        title: s,
        level: r,
        last: i = !1
    }) => {
        const l = R(),
            g = r >= Number(a[0].level) && r <= Number(a[a.length - 1].level),
            [o, c] = f.exports.useState(!1),
            A = f.exports.useCallback(() => Lt[s.toLocaleLowerCase()], []),
            d = t[`${s}Medal`];
        f.exports.useEffect(() => {
            const v = setTimeout(() => {
                g && c(g)
            }, 1e3);
            return () => clearTimeout(v)
        }, []);
        const m = v => {
            switch (v) {
                case "Bronze":
                    return l("page.vip.cards.bronze");
                case "Diamond":
                    return l("page.vip.cards.diamond");
                case "Gold":
                    return l("page.vip.cards.golden");
                case "Silver":
                    return l("page.vip.cards.silver");
                default:
                    return l("page.vip.cards.platinum")
            }
        };
        return n(K, {
            children: [n("div", {
                className: `${Mt} vip-system-list`,
                children: [n("div", {
                    className: "vip-system-bar",
                    onClick: () => c(!o),
                    children: [n("div", {
                        className: "bar-cont",
                        children: [e("img", {
                            className: "level-icon",
                            alt: "level",
                            src: d
                        }), e("div", {
                            className: "bar-tit",
                            children: m(s)
                        }), s === "Diamond" && n("div", {
                            className: "bar-svip",
                            children: [e("img", {
                                src: w.svip,
                                alt: ""
                            }), "SVIP"]
                        })]
                    }), e(Y, {
                        className: `bar-arrow ${o?"show-arrow":""}`,
                        name: "Arrow"
                    })]
                }), e(Pe, {
                    className: "v-toggle-view",
                    visible: o,
                    children: e("div", {
                        className: "v-table-wrap",
                        children: n("div", {
                            className: `${o?"show":""} ${s}-list v-table`,
                            children: [e("div", {
                                className: "v-thead",
                                children: n("div", {
                                    className: "v-tr",
                                    children: [e("div", {
                                        className: "v-th width_1 align-left",
                                        children: l("page.vip.dialog.table.head1")
                                    }), !p.isMobile && e("div", {
                                        className: "v-th width_2 align-center",
                                        children: l("page.vip.dialog.table.head2")
                                    }), !p.isMobile && e("div", {
                                        className: "v-th width_2 align-center",
                                        children: l("page.vip.dialog.table.head3")
                                    }), e("div", {
                                        className: "v-th width_1 m-align-center align-center",
                                        children: l("page.vip.dialog.table.head4")
                                    }), e("div", {
                                        className: "v-th width_1 width_m_1 m-align-center align-right",
                                        children: l("page.vip.dialog.table.head5")
                                    }), p.isMobile && e("div", {
                                        className: "v-th width_1 align-right",
                                        children: l("page.vip.dialog.table.head6")
                                    })]
                                })
                            }), e("div", {
                                className: "v-tbody",
                                children: a.map((v, h) => n("div", {
                                    className: `${v.highLight?"highLight":""} ${v.curLevel?"cur-level":""} v-tr-wrap`,
                                    children: [n("div", {
                                        className: "v-tr-item v-tr",
                                        children: [n("div", {
                                            className: "align-left tlevel v-td width_1 level-td",
                                            children: [e("img", {
                                                src: A(),
                                                alt: ""
                                            }), N.viptxt(v.level)]
                                        }), !p.isMobile && e("div", {
                                            className: `${v.nextbar?"next-active":""} align-center v-td width_2`,
                                            children: v.xpamount
                                        }), !p.isMobile && e("div", {
                                            className: "v-td width_2",
                                            children: e(ie, {
                                                finished: v.finished,
                                                level: v.level,
                                                nextbar: v.nextbar,
                                                nextbarPercent: v.nextbarPercent,
                                                nextdiffxp: v.nextdiffxp
                                            })
                                        }), e("div", {
                                            className: "flex-center v-td width_1 levelStar-td",
                                            children: e(ne, {
                                                level: v.level
                                            })
                                        }), e("div", {
                                            className: "align-right jb-img-wrap v-td width_1 m-align-center width_m_1",
                                            children: e(Ct, {
                                                finished: v.finished,
                                                highLight: v.highLight,
                                                clv: s,
                                                nextbar: v.nextbar
                                            })
                                        }), p.isMobile && n("div", {
                                            className: "width_1 align-right m-last-item",
                                            children: [e("div", {
                                                className: "m-xpamount",
                                                children: v.xpamount
                                            }), e("div", {
                                                className: "m-status",
                                                children: e(ie, {
                                                    finished: v.finished,
                                                    level: v.level,
                                                    nextbar: v.nextbar,
                                                    nextbarPercent: v.nextbarPercent,
                                                    nextdiffxp: v.nextdiffxp
                                                })
                                            })]
                                        })]
                                    }), v.curLevel && n("div", {
                                        className: "lv-active",
                                        children: [s === "Bronze" && e("img", {
                                            src: t.b_bar,
                                            alt: ""
                                        }), s === "Silver" && e("img", {
                                            src: t.s_bar,
                                            alt: ""
                                        }), s === "Gold" && e("img", {
                                            src: t.g_bar,
                                            alt: ""
                                        }), s === "Platinum" && e("img", {
                                            src: t.p_bar,
                                            alt: ""
                                        }), s === "Diamond" && e("img", {
                                            src: t.d_bar,
                                            alt: ""
                                        })]
                                    })]
                                }, h))
                            })]
                        })
                    })
                })]
            }), i && o && e(de, {
                id: "super-svip-protal",
                children: n("div", {
                    className: "super-svip-reward",
                    children: [n("div", {
                        className: "width_1",
                        children: [e("img", {
                            src: t.diamondMedal,
                            alt: ""
                        }), "SVIP..."]
                    }), e("div", {
                        className: "width_2",
                        children: "......"
                    }), e("div", {
                        className: "width_3",
                        children: "......"
                    }), !p.isMobile && e("div", {
                        className: "width_4",
                        children: "......"
                    }), e("div", {
                        className: "width_5",
                        children: e(be, {
                            children: n("div", {
                                className: "flower-svip-tr",
                                children: [e("img", {
                                    alt: "",
                                    src: w.gettr(3, !0)
                                }), n("div", {
                                    className: "infinite-levelup",
                                    children: [e("p", {
                                        children: "INFINITE"
                                    }), e("p", {
                                        className: "big",
                                        children: "LEVELUP"
                                    })]
                                })]
                            })
                        })
                    })]
                })
            })]
        })
    });
O({
    cl1: ["#1e2024", "#fff"],
    cl2: [V("#2d3035", .7), "#f5f6fa"],
    cl3: ["#fff", "#000"],
    cl4: ["#f5f6f7", "#31373d"],
    s1: ["#cfd9e5", "#8b9fb2"],
    s2: ["#eaeaff", "#8282ba"],
    s3: ["#ffe065", "#d38720"],
    s4: ["#caa9ff", "#733cd0"],
    s5: ["#fe98b2", "#c22950"]
});
const Mt = "vco6yc7";
const Pt = function() {
        const s = R(),
            r = N.state.level,
            i = c => c.map((A, d) => {
                let m = A[0] < 10 ? "0" + A[0] : A[0],
                    v = A[0] === r,
                    h = r > A[0] ? 0 : 2;
                h = r === A[0] ? 1 : h;
                let L = r + 1,
                    I = A[0] === L,
                    P = 0,
                    M = 0;
                return I && (M = A[3] - (A[1] - N.state.totalXp), P = Math.floor(M * 100 / A[3])), {
                    level: m,
                    curLevel: v,
                    xpamount: A[1],
                    star: A[2],
                    xpprogress: A[3],
                    finished: h,
                    highLight: !!A[5],
                    nextbar: I,
                    nextbarPercent: P,
                    nextdiffxp: M
                }
            });
        let l = Qe(z, c => c[4]),
            g = {
                Bronze: null,
                Silver: null,
                Gold: null,
                Platinum: null,
                Diamond: null
            };
        for (let c in l) {
            let A = i(l[c]);
            switch (c) {
                case "1":
                    g.Bronze = A;
                    break;
                case "2":
                    g.Silver = A;
                    break;
                case "3":
                    g.Gold = A;
                    break;
                case "4":
                    g.Platinum = A;
                    break;
                case "5":
                    g.Diamond = A;
                    break
            }
        }
        const o = Object.keys(g);
        return e(ye, {
            title: s("title.user_vip_about"),
            className: `${yt} vip_xidalog_about`,
            size: [782, 800],
            nostyle: !0,
            children: n(Be, {
                className: `${Bt} vip-level`,
                children: [n("div", {
                    className: "vip-level-banner",
                    children: [e("img", {
                        className: "img-element_a",
                        src: p.isDarken ? t.element : t.element_w,
                        alt: "element.png"
                    }), e("img", {
                        className: "img-element_b",
                        src: p.isDarken ? t.element : t.element_w,
                        alt: "element.png"
                    }), e("img", {
                        className: "img-element_c",
                        src: p.isDarken ? t.element : t.element_w,
                        alt: "element.png"
                    }), n("div", {
                        className: "wager-wrap",
                        children: [e("img", {
                            className: "img-tstar",
                            src: p.isDarken ? t.tstar : t.tstar_w,
                            alt: ""
                        }), n("div", {
                            className: "ribbon",
                            children: [e(U, {
                                k: "page.vip.dialog.wager_title",
                                children: e("span", {
                                    className: "cl-primary",
                                    children: e(ce, {
                                        amount: 1
                                    })
                                })
                            }), e("span", {
                                className: "cl-primary",
                                children: "1 XP"
                            })]
                        }), e("div", {
                            className: "wager-desc",
                            children: s("page.vip.dialog.wager_des")
                        }), e("div", {
                            className: "wager-subtit",
                            children: s("page.vip.dialog.wager_subtit")
                        })]
                    })]
                }), e(wt, {}), n("div", {
                    className: "vip-system",
                    children: [e("div", {
                        className: "vip-system-title",
                        children: s("page.vip.dialog.level_title")
                    }), o.map((c, A) => e(It, {
                        list: g[c],
                        title: c,
                        level: r,
                        last: A === o.length - 1
                    }, c)), e(de, {
                        id: "super-svip-protal"
                    }), n("div", {
                        className: "vip-reward",
                        children: [e("img", {
                            className: "img-vipillu",
                            src: t.vipillu,
                            alt: "vipillu.png"
                        }), n("div", {
                            className: "vip-reward-list",
                            children: [e("div", {
                                className: "vip-reward-title",
                                children: s("page.vip.dialog.jb_bonus")
                            }), e("div", {
                                className: "vip-reward-item",
                                children: s("page.vip.dialog.jb_bonus.des1")
                            }), e("div", {
                                className: "vip-reward-item",
                                children: s("page.vip.dialog.jb_bonus.des2")
                            }), e("div", {
                                className: "vip-reward-item",
                                children: s("page.vip.dialog.jb_bonus.des3")
                            })]
                        })]
                    }), e("div", {
                        className: "more-bottom"
                    })]
                })]
            })
        })
    },
    yt = "vncb229",
    Bt = "v2sqc6d";
const Rt = Q(function() {
        const a = R(),
            s = X(),
            r = [{
                img: t.fn_emoji,
                img_m: t.fn_emoji_m,
                img_w: t.fn_emoji_w,
                img_m_w: t.fn_emoji_m_w,
                title: a("page.vip.benefits.vip1_title"),
                desc: a("page.vip.benefits.vip1_des")
            }, {
                img: t.fn_wallet,
                img_m: t.fn_wallet_m,
                img_w: t.fn_wallet_w,
                img_m_w: t.fn_wallet_m_w,
                title: a("page.vip.benefits.vip2_title"),
                desc: a("page.vip.benefits.vip2_des")
            }, {
                img: t.fn_start,
                img_m: t.fn_start_m,
                img_w: t.fn_start_w,
                img_m_w: t.fn_start_m_w,
                title: a("page.vip.benefits.vip3_title"),
                desc: a("page.vip.benefits.vip3_des")
            }, {
                img: t.fn_gift,
                img_m: t.fn_gift_m,
                img_w: t.fn_gift_w,
                img_m_w: t.fn_gift_m_w,
                title: a("page.vip.benefits.vip4_title"),
                desc: a("page.vip.benefits.vip4_des")
            }, {
                img: t.fn_card,
                img_m: t.fn_card_m,
                img_w: t.fn_card_w,
                img_m_w: t.fn_card_m_w,
                title: a("page.vip.benefits.vip5_title"),
                desc: a("page.vip.benefits.vip5_des")
            }, {
                img: t.fn_diamond,
                img_m: t.fn_diamond_m,
                img_w: t.fn_diamond_w,
                img_m_w: t.fn_diamond_m_w,
                title: a("page.vip.benefits.vip6_title"),
                desc: a("page.vip.benefits.vip6_des")
            }, {
                img: t.fn_ship,
                img_m: t.fn_ship_m,
                img_w: t.fn_ship_w,
                img_m_w: t.fn_ship_m_w,
                title: a("page.vip.benefits.vip7_title"),
                desc: a("page.vip.benefits.vip7_des")
            }, {
                img: t.fn_sail,
                img_m: t.fn_sail_m,
                img_w: t.fn_sail_w,
                img_m_w: t.fn_sail_m_w,
                title: a("page.vip.benefits.vip8_title"),
                desc: a("page.vip.benefits.vip8_des")
            }, {
                img: t.fn_air,
                img_m: t.fn_air_m,
                img_w: t.fn_air_w,
                img_m_w: t.fn_air_m_w,
                title: a("page.vip.benefits.vip9_title"),
                desc: a("page.vip.benefits.vip9_des")
            }];
        f.exports.useEffect(() => {
            N.init().then(() => {
                s() && N.receiveVip()
            })
        }, []);
        const i = () => r.map((l, g) => e("div", {
            className: "card",
            children: n("div", {
                className: "card-cont",
                children: [e("div", {
                    className: "card-img-wrap",
                    children: e("img", {
                        className: "card-img",
                        src: p.isMobile ? p.isDarken ? l.img_m : l.img_m_w : p.isDarken ? l.img : l.img_w,
                        alt: ""
                    })
                }), n("div", {
                    className: "card-box " + (g % 2 === 0 ? "box-p-bg" : ""),
                    children: [e("div", {
                        className: "card-title",
                        children: l.title
                    }), e("div", {
                        className: "card-desc",
                        dangerouslySetInnerHTML: {
                            __html: l.desc
                        }
                    })]
                })]
            })
        }, g));
        return N.loading ? e(Re, {}) : n("div", {
            className: Ut,
            id: "game-vip",
            children: [e(st, {
                onAlertVipLevel: () => Ue.push(e(Pt, {}))
            }), n("div", {
                className: "center-cont",
                children: [e("div", {
                    className: "svip-title",
                    children: a("page.vip.rights_title")
                }), e(tt, {
                    level: N.state.level
                })]
            }), n("div", {
                className: "bot-other",
                children: [e("div", {
                    className: "svip-title",
                    children: a("page.vip.benefits_title")
                }), e("div", {
                    className: "card-wrap",
                    children: i()
                })]
            }), n("div", {
                className: "foot-desc",
                children: [e("div", {
                    children: a("page.vip.footer.one")
                }), e("div", {
                    children: a("page.vip.footer.two")
                }), e("div", {
                    children: a("page.vip.footer.three")
                })]
            })]
        })
    }),
    Ut = "u1jrlv2s";
var Gt = Rt,
    kt = "/assets/treasure.96c5b204.json",
    Vt = "/assets/badge.ef9dd073.png",
    jt = "/assets/sf.d1f7428c.png",
    xt = "/assets/badge_svip.f55f3608.png";
const Et = k.memo(function() {
    const a = ke(),
        {
            level: s = "0",
            rewardId: r = ""
        } = a,
        i = R(),
        [l, g] = f.exports.useState(0),
        [o, c] = f.exports.useState([]),
        {
            isSvip: A,
            vipLevel: d
        } = C.getUserLevelInfo(parseInt(s)),
        m = A ? "SVIP" : "VIP",
        v = d,
        h = X(),
        L = f.exports.useRef(null),
        I = f.exports.useRef(null),
        P = f.exports.useRef(null),
        M = f.exports.useRef(null),
        j = f.exports.useRef(null),
        B = f.exports.useCallback(() => l === 2 ? (N.state.rewards.shift(), H.close(), C.emit("vipReceive"), !1) : Ve.post("/game/support/vip/reward/receive/", {
            rewardId: r
        }).then(S => {
            var b;
            if (!h()) return !1;
            (b = T.current) == null || b.play(2), c(S), C.emit("taskClaim"), g(2), _.to(I.current, {
                delay: 1.2,
                transform: "translateY(100%)",
                opacity: 0,
                duration: .5
            }), _.to(P.current, {
                delay: 2,
                transform: "translateY(0)",
                opacity: 1,
                duration: .5
            })
        }).catch(je), [l, r]),
        T = f.exports.useRef(null);
    f.exports.useEffect(() => {
        let S = setTimeout(() => {
            var b;
            h() && ((b = T.current) == null || b.stop(2))
        }, 200);
        return _.to(L.current, {
            delay: 2,
            transform: "translateY(100%)",
            opacity: 0,
            duration: .5
        }), _.to(I.current, {
            delay: 2,
            transform: "translateY(0)",
            opacity: 1,
            duration: 1
        }), _.to(M.current, {
            delay: 2,
            top: -30,
            transform: "scale(.5)",
            duration: .5
        }), _.to(j.current, {
            delay: 2,
            opacity: 1,
            duration: .5,
            onStart: () => {
                g(1)
            }
        }), () => {
            clearTimeout(S), _.killTweensOf(L.current), _.killTweensOf(I.current), _.killTweensOf(M.current), _.killTweensOf(j.current)
        }
    }, []);
    const x = S => {
        if (!S || S.length === 0) return null;
        const b = [];
        let u;
        for (let y = 0; y < S.length; y++) S[y].currencyName === "JB" ? u = S[y] : b.push(S[y]);
        return u && b.push(u), b.map((y, E) => n("span", {
            children: [y.amount, " ", Ee.getAlias(y.currencyName), E === S.length - 1 ? "" : " & "]
        }, E))
    };
    return e("div", {
        className: `${Qt} receive-pop`,
        children: n("div", {
            className: "main-bg",
            children: [n("div", {
                className: "ani-wrap",
                children: [n("div", {
                    className: "badge-wrap",
                    ref: M,
                    children: [A ? e("img", {
                        src: xt,
                        alt: ""
                    }) : e("img", {
                        src: Vt,
                        alt: ""
                    }), e("div", {
                        className: "badge-num",
                        children: v
                    })]
                }), n("div", {
                    className: "tr-wrap",
                    ref: j,
                    children: [e("img", {
                        className: "sf-img",
                        src: jt,
                        alt: ""
                    }), e(xe, {
                        className: "tr-img",
                        ref: T,
                        path: kt
                    })]
                }), e("img", {
                    className: "star-img",
                    src: w.w_star,
                    alt: ""
                }), e("img", {
                    className: "gstar-img",
                    src: w.g_star,
                    alt: ""
                })]
            }), n("div", {
                className: "receive-txt",
                ref: L,
                children: [e("p", {
                    className: "vip-receive-title",
                    children: i("page.vip.receive.levelup")
                }), e("p", {
                    className: "vip-receive-desc",
                    children: e(U, {
                        k: "page.vip.receive.vipnow",
                        children: n("span", {
                            children: [m, v]
                        })
                    })
                })]
            }), n("div", {
                className: "receive-txt nopen-txt",
                ref: I,
                children: [e("div", {
                    className: "cont-title",
                    children: e(U, {
                        k: "page.vip.receive.contratulations",
                        children: n("span", {
                            children: [m, v]
                        })
                    })
                }), n("div", {
                    className: "cont-desc",
                    children: [i("page.vip.receive.right1"), s === "14" || s === "22" ? n(K, {
                        children: [e("br", {}), i("page.vip.receive.right2")]
                    }) : ""]
                })]
            }), n("div", {
                className: "receive-txt nopen-txt",
                ref: P,
                children: [n("div", {
                    className: "cont-title",
                    children: [e("div", {
                        children: i("page.vip.receive.congrats")
                    }), x(o)]
                }), e("div", {
                    className: "cont-desc-title",
                    children: i("common.credited_balance")
                }), s === "14" ? n("div", {
                    className: "cont-desc more",
                    children: [i("page.vip.receive.unlocked"), i("page.vip.rights.title11"), " / ", i("page.vip.rights.title12"), " /", " ", i("page.vip.rights.title13")]
                }) : null, s === "22" ? n("div", {
                    className: "cont-desc more",
                    children: [i("page.vip.receive.unlocked"), i("page.vip.rights.title14"), " / ", i("page.vip.rights.title15")]
                }) : null]
            }), l != 0 && e(Ae, {
                className: "open-btn",
                onClick: B,
                type: "conic",
                children: i(l === 1 ? "common.open" : "common.ok")
            })]
        })
    })
});
var Jt = Et;
const Qt = "r1bkefe9";
export {
    Gt as VipEnter, Jt as VipReceive
};
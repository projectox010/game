System.register(["./index-legacy.1416f96c.js", "./AggregateList-legacy.7a6fb47a.js"], (function(e) {
    "use strict";
    var t, n, a, i;
    return {
        setters: [function(e) {
            t = e.a2, n = e.bo, a = e.a
        }, function(e) {
            i = e.F
        }],
        execute: function() {
            e("default", (function() {
                const e = t(),
                    r = n(e);
                return a(i, {
                    tagName: r[0],
                    subTagName: r[1] ? r[1] : void 0,
                    isprovider: !0
                })
            }))
        }
    }
}));
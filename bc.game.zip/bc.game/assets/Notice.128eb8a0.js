var z = Object.defineProperty,
    O = Object.defineProperties;
var U = Object.getOwnPropertyDescriptors;
var M = Object.getOwnPropertySymbols;
var V = Object.prototype.hasOwnProperty,
    q = Object.prototype.propertyIsEnumerable;
var A = (r, e, s) => e in r ? z(r, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : r[e] = s,
    T = (r, e) => {
        for (var s in e || (e = {})) V.call(e, s) && A(r, s, e[s]);
        if (M)
            for (var s of M(e)) q.call(e, s) && A(r, s, e[s]);
        return r
    },
    C = (r, e) => O(r, U(e));
import {
    e as P,
    r as h,
    o as N,
    u as I,
    j as n,
    a,
    A as p,
    cC as D,
    dA as E,
    l as x,
    d as G,
    cQ as d,
    F as R,
    a4 as W,
    t as y,
    q as m,
    s as v,
    al as H,
    v as L,
    M as $,
    b as B,
    cW as Q,
    ck as Y,
    S as J
} from "./index.28e31dff.js";
const K = /^\//;

function X(r) {
    const e = P();
    h.exports.useEffect(() => {
        const s = r.current;
        if (s) {
            const t = i => {
                let c = i.target;
                for (; c;) {
                    if (c.tagName === "A") {
                        const l = c.getAttribute("href");
                        K.test(l) && (i.preventDefault(), e(l));
                        break
                    }
                    c = c.parentElement === s ? null : c.parentElement
                }
            };
            return s.addEventListener("click", t), () => {
                s.removeEventListener("click", t)
            }
        }
    }, [r.current])
}
const Z = N(function({
        onClose: e
    }) {
        const s = I();
        return n("div", {
            className: ee,
            children: [a("div", {
                className: "title",
                children: s("page.notice.title")
            }), a("div", {
                className: "close-icon",
                onClick: () => e(),
                children: a(p, {
                    name: "Close"
                })
            })]
        })
    }),
    ee = "nnhmmbc";
var ae = "/assets/hand.1053c278.svg",
    se = "/assets/hand-w.391870da.svg",
    ce = "/assets/finger.1b642f84.svg",
    re = "/assets/flower.b78eecee.png",
    te = "/assets/coin-bg.b80f86d1.png",
    ne = "/assets/tag.5c01fd72.svg",
    le = "/assets/gift.1d6007eb.svg",
    b = {
        avatar: D.logo4,
        avatarw: D.logo4_w,
        hand: ae,
        handWhite: se,
        finger: ce,
        flower: re,
        coinBg: te,
        tag: ne,
        gift: le
    };

function F(r) {
    const e = new Date(r),
        s = e.getFullYear();
    let t = e.getMonth() + 1,
        i = e.getDate(),
        c = e.getHours(),
        l = e.getMinutes(),
        f = e.getSeconds(),
        o = c >= 12 ? "PM" : "AM";
    return c = c % 12, c = c || 12, t = t < 10 ? `0${t}` : t, i = i < 10 ? `0${i}` : i, c = c < 10 ? `0${c}` : c, l = l < 10 ? `0${l}` : l, f = f < 10 ? `0${f}` : f, `${t}/${i}/${s} ${c}:${l}:${f} ${o}`
}

function _(r) {
    let e = [];
    return r && (r.split(/<\s?br\s?\/?\s?>/).map((s, t) => {
        t >= 1 && e.push(a("br", {}, t)), e.push(s)
    }), e)
}

function ie(r) {
    return r.version === 1 ? a("div", {
        className: "old",
        dangerouslySetInnerHTML: {
            __html: r.contentV1
        }
    }) : r.contentV2.map((e, s) => {
        switch (e.contentType) {
            case 1:
                return a("p", {
                    className: "p",
                    children: _(e.content)
                }, s);
            case 2:
                return n("div", {
                    className: "p link-box",
                    children: [a("div", {
                        className: "flex",
                        children: a("div", {
                            className: "tip",
                            children: a("span", {
                                className: "finger",
                                children: "Click here"
                            })
                        })
                    }), a("div", {
                        children: a("a", {
                            className: "hover",
                            href: e.content,
                            children: e.desc
                        })
                    })]
                }, s);
            case 3:
                return a("img", {
                    src: e.content,
                    alt: e.desc,
                    className: "image p"
                }, s);
            default:
                return null
        }
    })
}
const oe = N(function({
        className: e = "",
        data: s
    }) {
        const t = E();
        return n("div", {
            className: x(me, e),
            children: [n("div", {
                className: "item-head",
                children: [a("div", {
                    className: "title",
                    children: s.title
                }), n("div", {
                    className: "base flex-center",
                    children: [n("div", {
                        className: "user flex-center",
                        children: [a("img", {
                            src: t ? b.avatar : b.avatarw,
                            className: "avatar"
                        }), a("div", {
                            className: "user-name",
                            children: "BC.GAME Official"
                        })]
                    }), a("div", {
                        className: "time",
                        children: F(s.createTime)
                    })]
                })]
            }), n("div", {
                className: "item-content",
                children: [n("div", {
                    className: "welcome",
                    children: ["Hi ", G.name]
                }), ie(s)]
            })]
        })
    }),
    de = N(function() {
        var s;
        const e = d.systemData;
        return (s = e == null ? void 0 : e.afficheList) != null && s.length ? a(R, {
            children: e.afficheList.map(t => a(oe, {
                data: t,
                className: e.currentAfficheId < t.afficheId ? "unread" : ""
            }, t.afficheId))
        }) : a(W, {})
    });
y({
    cl1: [m("#2d3035", .6), m("#e9eaf2", .6)],
    cl2: [m("#555b65", .2), m("#c0c4d0", .3)],
    cl3: ["#f5f6f7", "#31373d"],
    cl4: [m("#99a4b0", .6), "#5f6975"],
    cl5: [m("#99a4b0", .8), m("#5f6975", .8)],
    cl6: ['url("../assets/hand.svg")', 'url("../assets/hand-w.svg")'],
    cl7: [m("#1e2024", .7), "#ffffff"],
    cl8: ["#f5f6f7", "#5f6975"]
});
const me = "sswsdjr";
const fe = N(function() {
        return n("div", {
            className: Ne,
            children: [a(p, {
                name: "Unfold",
                className: d.rewardIsFold ? "" : "active",
                onClick: () => d.rewardIsFold = !1
            }), a(p, {
                name: "Fold",
                className: d.rewardIsFold ? "active" : "",
                onClick: () => d.rewardIsFold = !0
            })]
        })
    }),
    ue = N(function({
        data: e,
        zIndex: s
    }) {
        const t = I(),
            i = E(),
            c = e.status !== 0,
            l = v.rewardTypes[e.rewardType] || {},
            f = l.bgBig ? {
                backgroundImage: `url(${l.bgBig})`,
                zIndex: s
            } : {
                zIndex: s
            },
            [o, u] = h.exports.useState(!1),
            [k, w] = h.exports.useState(!1);
        return h.exports.useEffect(() => {
            c && o && w(!0)
        }, [c]), n("div", {
            className: x(ge, j, c && "disabled"),
            style: f,
            children: [a("div", {
                className: "tag-box",
                children: a("div", {
                    className: "tag",
                    children: l.label
                })
            }), a("div", {
                className: "title ttu",
                children: e.title || l.title
            }), c && e.url && n("div", {
                className: "go-to-link",
                children: [a(H, {
                    to: e.url,
                    onClick: () => {
                        v.isMobile && (v.chatOrNtice = "", L.close())
                    },
                    children: e.urlDesc
                }), a(p, {
                    name: "Arrow"
                })]
            }), n("div", {
                className: "flex-center status",
                children: [n("div", {
                    className: `monospace rewards-wrap ${e.rewards.length>1?"multiple":""}`,
                    children: [(!c || o) && a("div", {
                        className: `effect-box ${k?"effect":""}`,
                        onAnimationEnd: () => {
                            w(!1), u(!1)
                        },
                        children: e.rewards.map((g, S) => a("div", {
                            children: a($, {
                                name: g.name,
                                amount: Number(g.amount),
                                sign: !0
                            })
                        }, S))
                    }), e.rewards.map((g, S) => a($, {
                        name: g.name,
                        amount: Number(g.amount),
                        icon: !0,
                        sign: !0,
                        showName: !0
                    }, S))]
                }), c ? a("div", {
                    className: "claimed",
                    children: t("common.claimed")
                }) : a(B, {
                    type: "conic",
                    className: "claim",
                    disabled: o,
                    onClick: () => {
                        u(!0), d.receiveReward(e.rewardId)
                    },
                    children: t("page.task.receive")
                })]
            }), n("div", {
                className: "flex-center from",
                children: [a("img", {
                    src: i ? b.avatar : b.avatarw,
                    className: "avatar"
                }), a("div", {
                    className: "origin",
                    children: l.name
                }), a("div", {
                    className: "time",
                    children: F(e.createTime)
                })]
            })]
        })
    }),
    he = N(function({
        data: e
    }) {
        const s = I(),
            t = E(),
            i = e.status !== 0,
            c = v.rewardTypes[e.rewardType] || {},
            l = c.bgBig ? {
                backgroundImage: `url(${c.bgBig})`
            } : {},
            [f, o] = h.exports.useState(!1),
            [u, k] = h.exports.useState(!1);
        return h.exports.useEffect(() => {
            u && i && o(!0)
        }, [i]), n("div", {
            style: l,
            className: x(pe, j, i && "disabled"),
            children: [a("div", {
                className: "tag-box",
                children: a("div", {
                    className: "tag",
                    children: c.label
                })
            }), a("div", {
                className: "flower"
            }), a("div", {
                className: "small-bg",
                style: {
                    backgroundImage: `url(${c.bgSmall})`
                }
            }), a("div", {
                className: "title ttu",
                children: e.title || c.title
            }), a("div", {
                className: "desc",
                children: _(e.content || c.desc)
            }), n("div", {
                className: "main-box",
                children: [n("div", {
                    className: "status",
                    children: [a("div", {
                        className: `flex-center coin-wrap ${f?"effect":""}`,
                        onAnimationEnd: () => {
                            o(!1), k(!1)
                        },
                        children: a("div", {
                            className: `rewards-wrap monospace ${e.rewards.length===1?"single":""}`,
                            children: e.rewards.map((w, g) => a($, {
                                name: w.name,
                                amount: Number(w.amount),
                                icon: !0,
                                sign: !0,
                                showName: !0
                            }, g))
                        })
                    }), i ? n(R, {
                        children: [a("div", {
                            className: "flex-center",
                            children: a("div", {
                                className: "claimed",
                                children: s("common.claimed")
                            })
                        }), e.url && n("div", {
                            className: "flex-center go-to-link",
                            children: [a(H, {
                                to: e.url,
                                onClick: () => {
                                    v.isMobile && (v.chatOrNtice = "", L.close())
                                },
                                children: e.urlDesc
                            }), a(p, {
                                name: "Arrow"
                            })]
                        })]
                    }) : a(B, {
                        type: "conic",
                        className: "claim",
                        disabled: u,
                        onClick: () => {
                            k(!0), d.receiveReward(e.rewardId)
                        },
                        children: s("common.claim_now")
                    })]
                }), n("div", {
                    className: "flex-center from",
                    children: [a("img", {
                        src: t ? b.avatar : b.avatarw,
                        className: "avatar"
                    }), a("div", {
                        className: "origin",
                        children: c.name
                    }), a("div", {
                        className: "time",
                        children: F(e.createTime)
                    })]
                })]
            })]
        })
    }),
    ve = N(function() {
        const {
            rewardData: e
        } = d;
        return n("div", {
            className: be,
            children: [a(fe, {}), e != null && e.length ? a("div", {
                className: "reward-container",
                children: e.map((s, t) => d.rewardIsFold ? a(ue, {
                    data: s,
                    zIndex: e.length - t
                }, s.rewardId) : a(he, {
                    data: s
                }, s.rewardId))
            }) : a(W, {})]
        })
    });
y({
    cl1: ["#1e2024", "#ffffff"],
    cl2: [m("#000000", .19), m("#000000", .1)],
    cl3: ["#555b65", "#aeb3c2"],
    cl4: ["#d8d8d8", "#6a6e73"]
});
const Ne = "rqldstm";
y({
    cl5: ["#17181b", "#f5f6fa"],
    cl6: ["#f5f6f7", "#31373d"],
    cl7: ["#f5f6f7", "#5f6975"],
    cl8: ["#ffffff", "#5f6975"],
    cl9: [m("#555b65", .2), m("#c0c4d0", .3)]
});
const j = "r1wg44be";
y({
    cla: [m("#2c2f36", .4), "#e9eaf2"]
});
const ge = "sas4pnf",
    pe = "f1fz82zo",
    be = "n1p5zyw1";

function we() {
    const {
        systemUnreadCount: r,
        rewardUnreadCount: e
    } = d, s = I(), [t, i] = h.exports.useState({
        system: 0,
        reward: 0
    }), c = [{
        label: s("page.notice.tab.notice"),
        value: 0
    }, {
        label: s("page.notice.tab.reward"),
        value: 1
    }], l = h.exports.useRef(null);
    X(l);

    function f(o) {
        if (l.current) {
            let u = l.current.scrollTop;
            i(o === 0 ? C(T({}, t), {
                reward: u
            }) : C(T({}, t), {
                system: u
            }))
        }
        d.currentType = o, o === 1 && d.clearSystemNotice(!0)
    }
    return h.exports.useEffect(() => {
        l.current && (d.currentType === 0 ? l.current.scrollTop = t.system : l.current.scrollTop = t.reward)
    }, [t]), n("div", {
        className: ke,
        children: [a(Q, {
            className: "notice-tabs",
            value: d.currentType,
            options: c,
            onChange: o => f(o),
            children: ({
                option: o,
                active: u
            }) => n("button", {
                className: u ? "is-active tab" : "tab",
                children: [o.value === 1 && a(R, {
                    children: u || e > 0 ? a("div", {
                        className: "reward"
                    }) : a(p, {
                        name: "Reward"
                    })
                }), n("span", {
                    className: "label",
                    children: [o.label, a(Y, {
                        num: o.value === 0 ? r : e,
                        className: "badge"
                    })]
                })]
            })
        }), a("div", {
            className: "scroll-wrap",
            children: a(J, {
                className: "notice-container",
                ref: l,
                bodyLock: v.isMobile,
                children: d.currentType === 0 ? a(de, {}) : a(ve, {})
            })
        })]
    })
}
var ye = N(we);
y({
    cl1: ["#1e2024", "#ffffff"],
    cl2: ["linear-gradient(to bottom, #111415, rgba(17, 20, 21, 0))", "linear-gradient(to bottom, #a5aeb8, rgba(197, 203, 213, 0))"],
    cl3: ["0.44", "0.15"],
    cl4: [m("#31383d", .6), m("#c0c4d0", .6)],
    cl5: ["#f5f6f7", "#31373d"],
    cl6: ["#555b65", "#aeb3c2"]
});
const ke = "nz2bv4i";

function Ie({
    className: r,
    style: e,
    onClose: s = () => {}
}) {
    return h.exports.useEffect(() => (d.loadData(), () => {
        d.clearSystemNotice(), v.isMobile && (v.chatOrNtice = "")
    }), []), n("div", {
        style: e,
        className: x(r, xe),
        id: "notification",
        children: [!v.isMobile && a(Z, {
            onClose: s
        }), a(ye, {})]
    })
}
var Ce = N(Ie);
const xe = "nhencm8";
export {
    Ce as
    default
};
import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as e
} from "./index.28e31dff.js";
var n = `<section>
  <h2>Registration and Login</h2>
  <p>
    You must be at least 18 years old to register. If you want to add your email
    address, please make sure the email address you entered is correct so that
    later it can be used in KYC account verification.
  </p>
  <p>
    You can login at any time. For added security, we recommend you to add 2FA.
    To know more about Google authenticator.
  </p>
  <p>
    If you need to change your registered email, we are so sorry, but we are not
    able to update this information. If you insist on changing your username
    and/or registered email, we suggest you close the current account and
    register a new one.
  </p>
</section>
`,
    r = `<section>\r
  <h2>Cadastro e Login</h2>\r
  <p>\r
   Voc\xEA deve ter pelo menos 18 anos para se registrar. Se voc\xEA quiser adicionar seu endere\xE7o de e-mail, certifique-se de que o endere\xE7o de e-mail que voc\xEA digitou est\xE1 correto para que posteriormente possa ser usado na verifica\xE7\xE3o da conta KYC.\r
  </p>\r
  <p>\r
   Voc\xEA pode fazer login a qualquer momento. Para maior seguran\xE7a, recomendamos adicionar 2FA.\r
     Para saber mais sobre o autenticador do Google.\r
  </p>\r
  <p>\r
   Se voc\xEA precisar alterar seu e-mail cadastrado, sentimos muito, mas n\xE3o podemos atualizar essas informa\xE7\xF5es. Caso insista em alterar seu nome de usu\xE1rio e/ou e-mail cadastrado, sugerimos que encerre a conta atual e registre uma nova.\r
  </p>\r
</section>`,
    o = `<section>
  <h2>Daftar dan Masuk</h2>
   <p>
     Anda harus berusia minimal 18 tahun untuk mendaftar. Jika Anda ingin menambahkan alamat email Anda, pastikan alamat email yang Anda masukkan sudah benar agar nantinya bisa digunakan dalam verifikasi akun KYC.
   </p>
   <p>
     Anda dapat masuk kapan saja. Untuk keamanan tambahan, kami menyarankan Anda untuk menambahkan 2FA. Untuk mengetahui lebih lanjut tentang Google authenticator.
   </p>
   <p>
     Jika Anda perlu mengubah email terdaftar Anda, kami mohon maaf, tetapi kami tidak dapat memperbarui informasi ini. Jika Anda bersikeras mengubah nama pengguna dan/atau email terdaftar, kami sarankan Anda menutup akun saat ini dan mendaftarkan akun baru.
  </p>
</section>
`;

function s() {
    return e(a, {
        br: r,
        en: n,
        id: o
    })
}
export {
    s as
    default
};
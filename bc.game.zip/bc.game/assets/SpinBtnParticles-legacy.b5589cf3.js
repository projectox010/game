System.register(["./index-legacy.1416f96c.js", "./usePixiGsap-legacy.c051c439.js"], (function(e) {
    "use strict";
    var t, i, c, r, n;
    return {
        setters: [function(e) {
            t = e.a5, i = e.cX, c = e.a
        }, function(e) {
            r = e.P, n = e.a
        }],
        execute: function() {
            e("default", t.memo((function({
                color: e,
                className: t
            }) {
                return i.bright_emitter.color = {
                    start: e,
                    end: e
                }, c("div", {
                    className: t,
                    children: c(r, {
                        width: 90,
                        height: 90,
                        children: c(n, {
                            textures: i.bright,
                            config: i.bright_emitter
                        }, e)
                    })
                })
            })))
        }
    }
}));
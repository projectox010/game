import {
    s as c,
    t as u,
    q as n,
    o as g,
    j as o,
    a as s,
    A as x,
    r as l,
    b as m,
    u as h,
    F as N,
    x as r,
    e as S,
    az as W,
    cN as k,
    cC as f,
    C as _
} from "./index.28e31dff.js";
var $ = "/assets/ios_icon.dd4131cd.svg",
    C = "/assets/android_icon.f7a93e8d.svg",
    I = "/assets/ios-1@2x.de22eff0.png",
    T = "/assets/ios-1@2x-w.d24df7ce.png",
    A = "/assets/ios-2@2x.e5982325.png",
    P = "/assets/ios-2@2x-w.b3bba1c7.png",
    y = "/assets/ios-3@2x.3eb4d82d.png",
    D = "/assets/ios-3@2x-w.21ce20fd.png",
    B = "/assets/ios1@2x.9d2422dc.png",
    M = "/assets/ios1@2x-w.eabefd80.png",
    j = "/assets/ios2@2x.df64dc42.png",
    G = "/assets/ios2@2x-w.62a0a4e7.png",
    V = "/assets/ios3@2x.44488710.png",
    q = "/assets/ios3@2x-w.c4aa9416.png",
    E = "/assets/android1@2x.6806bbfe.png",
    H = "/assets/android1@2x-w.ca8e763f.png",
    L = "/assets/android2@2x.6b815e27.png",
    O = "/assets/android2@2x-w.a52aad52.png",
    z = "/assets/android3@2x.b677f4a3.png",
    F = "/assets/android3@2x-w.74749d5a.png";
const a = {
    fios1: I,
    fios1White: T,
    fios2: A,
    fios2White: P,
    fios3: y,
    fios3White: D,
    ios1: B,
    ios1White: M,
    ios2: j,
    ios2White: G,
    ios3: V,
    ios3White: q,
    android1: E,
    android1White: H,
    android2: L,
    android2White: O,
    android3: z,
    android3White: F
};
var p = {
    get fios1() {
        return c.isDarken ? a.fios1 : a.fios1White
    },
    get fios2() {
        return c.isDarken ? a.fios2 : a.fios2White
    },
    get fios3() {
        return c.isDarken ? a.fios3 : a.fios3White
    },
    get ios1() {
        return c.isDarken ? a.ios1 : a.ios1White
    },
    get ios2() {
        return c.isDarken ? a.ios2 : a.ios2White
    },
    get ios3() {
        return c.isDarken ? a.ios3 : a.ios3White
    },
    get android1() {
        return c.isDarken ? a.android1 : a.android1White
    },
    get android2() {
        return c.isDarken ? a.android2 : a.android2White
    },
    get android3() {
        return c.isDarken ? a.android3 : a.android3White
    },
    iosIcon: $,
    androidIcon: C
};

function v({
    isIOS: t
}) {
    const [e, i] = l.exports.useState(1);
    return o("div", {
        className: U,
        children: [s(Y, {
            index: e,
            changeStep: i
        }), s(X, {
            index: e,
            isIOS: t
        }), o("div", {
            className: "bottom",
            children: [s(Q, {
                index: e,
                isIOS: t
            }), s(m, {
                type: "conic",
                onClick: () => {
                    i(e === 3 ? 1 : e + 1)
                },
                children: "Next"
            })]
        })]
    })
}
u({
    cl1: [n("#1e2024", .3), n("#f6f7fa", .43)]
});
const U = "m1bcfdim";

function Y({
    index: t,
    changeStep: e
}) {
    return o("div", {
        className: J,
        children: [s("div", {
            className: `step-item ${t===1?"active":""}`,
            onClick: () => e(1),
            children: "Step01"
        }), s("div", {
            className: `step-item ${t===2?"active":""}`,
            onClick: () => e(2),
            children: "Step02"
        }), s("div", {
            className: `step-item ${t===3?"active":""}`,
            onClick: () => e(3),
            children: "Step03"
        })]
    })
}
u({
    cl1: [n("#5b5e67", .42), n("#5f6975", .3)],
    cl2: ["#3b3f4a", n("#5f6975", .3)],
    cl3: [n("#99a4b0", .8), n("#5f6975", .8)],
    cl4: ["#31343c", "#ffffff"],
    cl5: ["#dde0e3", "#31373d"]
});
const J = "ssaylmd";

function K(t, e) {
    if (e) switch (t) {
        case 1:
            return {
                title: "1.Open website in Safari browser.",
                desc: "Click to open the Safari browser on the phone desktop."
            };
        case 2:
            return {
                title: "2. Tap Sharing button.",
                desc: "Use Safari Explore APP and go to BC.GAME, Then tap the Sharing Button."
            };
        default:
            return {
                title: "3.Tap Add to Home Screen.",
                desc: "Press Add to Home Screen in the list popup to add to the home screen. You may need to swipe left to locate the Add to Home Screen button."
            }
    } else switch (t) {
        case 1:
            return {
                title: "1.Open website in Chrome browser.",
                desc: "Tap to open Google Chrome on the phone desktop"
            };
        case 2:
            return {
                title: "2.Tap menu button.",
                desc: "Use Google Chrome APP to go BC.GAME and then click the button"
            };
        default:
            return {
                title: "3.Tap menu button.",
                desc: "Press Add to Home Screen in the list popup to add to the home screen."
            }
    }
}
const Q = g(function({
        index: e,
        isIOS: i
    }) {
        const d = K(e, i);
        return o("div", {
            className: R,
            children: [s("div", {
                className: "tip-title",
                children: d.title
            }), o("div", {
                className: "tip-desc",
                children: [d.desc, e === 2 && o("span", {
                    className: "more",
                    children: ['"', s(x, {
                        name: "More"
                    }), '".']
                })]
            })]
        })
    }),
    R = "s1sh216j";

function X({
    index: t,
    isIOS: e
}) {
    const i = e ? p[`ios${t}`] : p[`android${t}`],
        d = p[`fios${t}`];
    return o("div", {
        className: Z,
        children: [s("img", {
            src: i,
            className: "img1"
        }), s("img", {
            src: d,
            className: "img2"
        })]
    })
}
const Z = "s1dpixu7";

function w({
    isIOS: t
}) {
    const e = h(),
        [i, d] = l.exports.useState(1);
    return o("div", {
        className: ee,
        children: [s(se, {
            index: i,
            changeStep: d
        }), s(ae, {
            index: i,
            isIOS: t
        }), s(ne, {
            index: i,
            isIOS: t
        }), s("div", {
            className: "bottom",
            children: s(m, {
                type: "conic",
                onClick: () => {
                    d(i === 3 ? 1 : i + 1)
                },
                children: e("page.record.next")
            })
        })]
    })
}
u({
    cl1: [n("#1e2024", .3), n("#f6f7fa", .43)]
});
const ee = "p1qsacy9";

function se({
    index: t,
    changeStep: e
}) {
    return o("div", {
        className: te,
        children: [s("div", {
            className: `step-item ${t===1?"active":""}`,
            onClick: () => e(1),
            children: "Step01"
        }), s("div", {
            className: `step-item ${t===2?"active":""}`,
            onClick: () => e(2),
            children: "Step02"
        }), s("div", {
            className: `step-item ${t===3?"active":""}`,
            onClick: () => e(3),
            children: "Step03"
        })]
    })
}
u({
    cl1: [n("#5b5e67", .42), n("#5f6975", .3)],
    cl2: ["#3b3f4a", n("#5f6975", .3)],
    cl3: [n("#99a4b0", .8), n("#5f6975", .8)],
    cl4: ["#31343c", n("#ffffff", 1)],
    cl5: ["#dde0e3", "#31373d"]
});
const te = "son4ga2";

function ie(t, e) {
    if (e) switch (t) {
        case 1:
            return {
                title: "1." + r.t("page.pcview.ios1_tit"),
                desc: r.t("page.pcview.ios1_desc")
            };
        case 2:
            return {
                title: "2." + r.t("page.pcview.ios2_tit"),
                desc: r.t("page.pcview.ios2_desc")
            };
        default:
            return {
                title: "3." + r.t("page.pcview.ios3_tit"),
                desc: r.t("page.pcview.ios3_desc")
            }
    } else switch (t) {
        case 1:
            return {
                title: "1." + r.t("page.pcview.android1_tit"),
                desc: r.t("page.pcview.android1_desc")
            };
        case 2:
            return {
                title: "2." + r.t("page.pcview.android2_tit"),
                desc: r.t("page.pcview.android2_desc")
            };
        default:
            return {
                title: "3." + r.t("page.pcview.android3_tit"),
                desc: r.t("page.pcview.android3_desc")
            }
    }
}

function ae({
    index: t,
    isIOS: e
}) {
    const i = ie(t, e);
    return o("div", {
        className: oe,
        children: [s("div", {
            className: "tip-title",
            children: i.title
        }), o("div", {
            className: "tip-desc",
            children: [i.desc, t === 2 && o(N, {
                children: ['"', s("span", {
                    className: "icon-bg",
                    style: {
                        backgroundImage: `url(${e?p.iosIcon:p.androidIcon})`
                    }
                }), '"']
            }), "."]
        })]
    })
}
const oe = "s1w04xjn",
    ne = g(function({
        index: e,
        isIOS: i
    }) {
        const d = i ? p[`ios${e}`] : p[`android${e}`],
            b = p[`fios${e}`];
        return o("div", {
            className: re,
            children: [s("img", {
                src: d,
                className: "img1"
            }), s("img", {
                src: b,
                className: "img2"
            })]
        })
    }),
    re = "s6vefhd";
const ce = () => c.isMobile ? s(v, {
        isIOS: !0
    }) : s(w, {
        isIOS: !0
    }),
    de = () => c.isMobile ? s(v, {
        isIOS: !1
    }) : s(w, {
        isIOS: !1
    });

function ue() {
    const t = h(),
        e = S();
    l.exports.useEffect(() => {
        location.pathname === "/app_download" && e("/app_download/ios", {
            replace: !0
        })
    }, [location.pathname]);
    const i = l.exports.useMemo(() => s(W, {
        prex: "/app_download/",
        routes: [{
            label: t("page.app.download.option1"),
            path: "ios",
            element: s(ce, {})
        }, {
            label: t("page.app.download.option2"),
            path: "android",
            element: s(de, {})
        }]
    }), []);
    return o("div", {
        className: `${pe} appsetup-wrap`,
        id: "app_setup",
        children: [o(k, {
            children: [o("p", {
                className: "title",
                children: [s("img", {
                    src: c.isDarken ? f.small : f.small_w,
                    className: "logo"
                }), s("span", {
                    className: "title",
                    children: t("page.app.download.title")
                })]
            }), s(_, {
                onClick: () => e(-1)
            })]
        }), i]
    })
}
const pe = "ab7g02z";
export {
    ue as
    default
};
import {
    b as s
} from "./_baseAssignValue.0532e777.js";
import {
    ce as f,
    aI as c,
    cf as p
} from "./index.28e31dff.js";

function u(r, e, t, n) {
    for (var o = -1, a = r == null ? 0 : r.length; ++o < a;) {
        var g = r[o];
        e(n, g, t(g), r)
    }
    return n
}

function i(r, e, t, n) {
    return f(r, function(o, a, g) {
        e(n, o, t(o), g)
    }), n
}

function b(r, e) {
    return function(t, n) {
        var o = c(t) ? u : i,
            a = e ? e() : {};
        return o(t, r, p(n), a)
    }
}
var h = Object.prototype,
    A = h.hasOwnProperty,
    v = b(function(r, e, t) {
        A.call(r, t) ? r[t].push(e) : s(r, t, [e])
    }),
    y = v;
export {
    y as g
};
var F = Object.defineProperty;
var q = (a, i, e) => i in a ? F(a, i, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : a[i] = e;
var u = (a, i, e) => (q(a, typeof i != "symbol" ? i + "" : i, e), e);
import {
    dp as v,
    a as t,
    dx as V,
    j as o,
    dy as J,
    dz as U,
    r as b,
    o as N,
    du as k,
    ec as K,
    a5 as R,
    P as X,
    aO as G,
    s as S,
    u as A,
    dk as Q,
    dl as $,
    t as Z,
    q as H,
    F as ee,
    dj as te,
    b as z,
    e9 as ne,
    G as P,
    Y as ae,
    dG as ie,
    dm as se,
    ed as oe,
    dY as le,
    eb as re,
    dC as ce,
    dD as he,
    dZ as ue,
    dE as de,
    bN as E,
    d_ as me,
    ba as pe,
    bb as B,
    bc as fe,
    dR as be,
    aH as ge,
    y as T,
    e0 as ye,
    df as we,
    A as C
} from "./index.28e31dff.js";
import {
    s as x
} from "./index.dd8128e8.js";
import {
    G as y
} from "./index.06a59a68.js";
const g = v.Reader,
    j = v.Writer,
    O = v.util,
    p = v.roots.gameHashdice || (v.roots.gameHashdice = {});
p.BetValue = (() => {
    function a(i) {
        if (i)
            for (let e = Object.keys(i), n = 0; n < e.length; ++n) i[e[n]] != null && (this[e[n]] = i[e[n]])
    }
    return a.prototype.payout = 0, a.prototype.isHigh = !1, a.create = function(e) {
        return new a(e)
    }, a.encode = function(e, n) {
        return n || (n = j.create()), e.payout != null && Object.hasOwnProperty.call(e, "payout") && n.uint32(8).sint32(e.payout), e.isHigh != null && Object.hasOwnProperty.call(e, "isHigh") && n.uint32(16).bool(e.isHigh), n
    }, a.encodeDelimited = function(e, n) {
        return this.encode(e, n).ldelim()
    }, a.decode = function(e, n) {
        e instanceof g || (e = g.create(e));
        let s = n === void 0 ? e.len : e.pos + n,
            l = new p.BetValue;
        for (; e.pos < s;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    l.payout = e.sint32();
                    break;
                case 2:
                    l.isHigh = e.bool();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return l
    }, a.decodeDelimited = function(e) {
        return e instanceof g || (e = new g(e)), this.decode(e, e.uint32())
    }, a.verify = function(e) {
        return typeof e != "object" || e === null ? "object expected" : e.payout != null && e.hasOwnProperty("payout") && !O.isInteger(e.payout) ? "payout: integer expected" : e.isHigh != null && e.hasOwnProperty("isHigh") && typeof e.isHigh != "boolean" ? "isHigh: boolean expected" : null
    }, a.fromObject = function(e) {
        if (e instanceof p.BetValue) return e;
        let n = new p.BetValue;
        return e.payout != null && (n.payout = e.payout | 0), e.isHigh != null && (n.isHigh = Boolean(e.isHigh)), n
    }, a.toObject = function(e, n) {
        n || (n = {});
        let s = {};
        return n.defaults && (s.payout = 0, s.isHigh = !1), e.payout != null && e.hasOwnProperty("payout") && (s.payout = e.payout), e.isHigh != null && e.hasOwnProperty("isHigh") && (s.isHigh = e.isHigh), s
    }, a.prototype.toJSON = function() {
        return this.constructor.toObject(this, v.util.toJSONOptions)
    }, a
})();
p.GameValue = (() => {
    function a(i) {
        if (i)
            for (let e = Object.keys(i), n = 0; n < e.length; ++n) i[e[n]] != null && (this[e[n]] = i[e[n]])
    }
    return a.prototype.gameValue = 0, a.prototype.number = 0, a.prototype.chance = 0, a.create = function(e) {
        return new a(e)
    }, a.encode = function(e, n) {
        return n || (n = j.create()), e.gameValue != null && Object.hasOwnProperty.call(e, "gameValue") && n.uint32(8).sint32(e.gameValue), e.number != null && Object.hasOwnProperty.call(e, "number") && n.uint32(16).sint32(e.number), e.chance != null && Object.hasOwnProperty.call(e, "chance") && n.uint32(25).double(e.chance), n
    }, a.encodeDelimited = function(e, n) {
        return this.encode(e, n).ldelim()
    }, a.decode = function(e, n) {
        e instanceof g || (e = g.create(e));
        let s = n === void 0 ? e.len : e.pos + n,
            l = new p.GameValue;
        for (; e.pos < s;) {
            let r = e.uint32();
            switch (r >>> 3) {
                case 1:
                    l.gameValue = e.sint32();
                    break;
                case 2:
                    l.number = e.sint32();
                    break;
                case 3:
                    l.chance = e.double();
                    break;
                default:
                    e.skipType(r & 7);
                    break
            }
        }
        return l
    }, a.decodeDelimited = function(e) {
        return e instanceof g || (e = new g(e)), this.decode(e, e.uint32())
    }, a.verify = function(e) {
        return typeof e != "object" || e === null ? "object expected" : e.gameValue != null && e.hasOwnProperty("gameValue") && !O.isInteger(e.gameValue) ? "gameValue: integer expected" : e.number != null && e.hasOwnProperty("number") && !O.isInteger(e.number) ? "number: integer expected" : e.chance != null && e.hasOwnProperty("chance") && typeof e.chance != "number" ? "chance: number expected" : null
    }, a.fromObject = function(e) {
        if (e instanceof p.GameValue) return e;
        let n = new p.GameValue;
        return e.gameValue != null && (n.gameValue = e.gameValue | 0), e.number != null && (n.number = e.number | 0), e.chance != null && (n.chance = Number(e.chance)), n
    }, a.toObject = function(e, n) {
        n || (n = {});
        let s = {};
        return n.defaults && (s.gameValue = 0, s.number = 0, s.chance = 0), e.gameValue != null && e.hasOwnProperty("gameValue") && (s.gameValue = e.gameValue), e.number != null && e.hasOwnProperty("number") && (s.number = e.number), e.chance != null && e.hasOwnProperty("chance") && (s.chance = n.json && !isFinite(e.chance) ? String(e.chance) : e.chance), s
    }, a.prototype.toJSON = function() {
        return this.constructor.toObject(this, v.util.toJSONOptions)
    }, a
})();
const ve = function() {
        return t(V, {
            children: o("div", {
                className: "item",
                children: [t("h2", {
                    children: "What Is HashDice?"
                }), t("div", {
                    className: "help-content",
                    children: t("p", {
                        children: "HashDice, a probability game established by blockchain hash value calculation and algorithm, provides more fun with bet and prediction, in which the closer the number rolled by players to the random number, the higher the probability winning."
                    })
                }), t("h2", {
                    children: "How to play Hash Dice?"
                }), o("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "Set a predicted interval first, such as 49999 < random number;"
                    }), t("p", {
                        children: "Then set the amount of this round, and click ROLL;"
                    }), t("p", {
                        children: "The result will be a random number between 0 and 99999;"
                    }), t("p", {
                        children: "If 49999 < random number, then you win; or you lose. "
                    }), t("p", {
                        children: "Tip:Players may set high and low interval"
                    }), o("ul", {
                        children: [t("li", {
                            children: "High: 1999-99998 < random number"
                        }), t("li", {
                            children: "Low: random numbe < 1 - 98000"
                        })]
                    }), t("p", {
                        children: "Winning profit is at least 1.0102x and the maximum could go up to 99,000 x."
                    })]
                }), t("h2", {
                    children: "What is the HashDice return rate?"
                }), t("div", {
                    className: "help-content",
                    children: t("p", {
                        children: "Only 1% edge, meaning that in long-term betting 99% of the bet amount will be attributed to the players, provides 99% return rate."
                    })
                })]
            })
        })
    },
    ke = function({
        game: i
    }) {
        return t(J, {
            game: i,
            children: o("div", {
                className: "item",
                children: [t("h2", {
                    children: "What is the bankroll?"
                }), o("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                    }), t("p", {
                        children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                    }), o("ul", {
                        children: [t("li", {
                            children: "Each player can only win 0.75\u2009% of the bankroll per round"
                        }), t("li", {
                            children: "All players can only win 1.125% of the funds per round"
                        })]
                    }), t("p", {
                        children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                    }), t("p", {
                        onClick: () => U(i, 1),
                        className: "cl-primary pointer",
                        children: "Read more about bankrollers."
                    })]
                }), t("h2", {
                    children: "How does the pool of funds operate? "
                }), o("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                    }), o("p", {
                        children: [t("b", {
                            className: "cl-primary",
                            children: "The house edge is 1%."
                        }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                    }), t("p", {
                        children: "Payouts made to the winning players will be deducted from the bankroll."
                    })]
                }), t("h2", {
                    children: "How does leverage investment work?"
                }), o("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                    }), t("p", {
                        children: "Hint: You can also use this feature as an Off-Site investment."
                    }), t("p", {
                        children: "Let's make an example:"
                    }), t("p", {
                        children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                    })]
                }), t("h2", {
                    children: "What is the bankroller dilution fee?"
                }), o("div", {
                    className: "help-content",
                    children: [t("p", {
                        children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                    }), t("p", {
                        children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                    }), t("p", {
                        children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                    }), t("p", {
                        children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                    })]
                })]
            })
        })
    };
var Se = ke,
    Ne = "/assets/hashdice_banner1.f503a2fc.png",
    Be = "/assets/hashdice_banner2.ae3c8cce.png",
    Ae = "/assets/hashdice.67d91e96.png",
    xe = "/assets/hand.584d3731.png";
const He = [{
        filename: "01.png",
        frame: {
            x: 1,
            y: 85,
            w: 45,
            h: 79
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 0,
            w: 45,
            h: 79
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "02.png",
        frame: {
            x: 1,
            y: 318,
            w: 45,
            h: 65
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 14,
            w: 45,
            h: 65
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "03.png",
        frame: {
            x: 1,
            y: 449,
            w: 45,
            h: 51
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 28,
            w: 45,
            h: 51
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "04.png",
        frame: {
            x: 1,
            y: 555,
            w: 45,
            h: 46
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 54,
            w: 45,
            h: 46
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "05.png",
        frame: {
            x: 1,
            y: 603,
            w: 45,
            h: 45
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 69,
            w: 45,
            h: 45
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "06.png",
        frame: {
            x: 1,
            y: 603,
            w: 45,
            h: 45
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 87,
            w: 45,
            h: 45
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "07.png",
        frame: {
            x: 1,
            y: 502,
            w: 45,
            h: 51
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 102,
            w: 45,
            h: 51
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "08.png",
        frame: {
            x: 1,
            y: 385,
            w: 45,
            h: 62
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 102,
            w: 45,
            h: 62
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "09.png",
        frame: {
            x: 1,
            y: 246,
            w: 45,
            h: 70
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 102,
            w: 45,
            h: 70
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "10.png",
        frame: {
            x: 1,
            y: 166,
            w: 45,
            h: 78
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 102,
            w: 45,
            h: 78
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }, {
        filename: "11.png",
        frame: {
            x: 1,
            y: 1,
            w: 45,
            h: 82
        },
        rotated: !1,
        trimmed: !0,
        spriteSourceSize: {
            x: 14,
            y: 102,
            w: 45,
            h: 82
        },
        sourceSize: {
            w: 60,
            h: 184
        }
    }],
    Ce = {
        app: "https://www.codeandweb.com/texturepacker",
        version: "1.0",
        image: "hand.png",
        format: "RGBA8888",
        size: {
            w: 47,
            h: 649
        },
        scale: "1",
        smartupdate: "$TexturePacker:SmartUpdate:a8786a50b21a11d961852370f9060293:c8b7e989545d86eadca5fab6e894e47b:b2489f6b7d10447a0d6fee1c4a9f4924$"
    };
var Oe = {
        frames: He,
        meta: Ce
    },
    Ie = "/assets/hashdice-bg.0c4de66a.png",
    De = "/assets/hashdice-bg-w.2ccbaa25.png",
    Ge = "/assets/spin-btn.0e2c0750.png",
    Te = "/assets/roll-num.1035d5fe.png",
    Ve = "/assets/hashdice-mask.43179a68.png",
    Re = "/assets/hashdice-mask.43179a68.png",
    ze = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADQAAAA0CAMAAADypuvZAAAAY1BMVEUAAADkbMHkbcLlbMPpbsXpbsfnbcTqb8jscMntcMnuccvwcszyc8/uccrxc87lbMTwcs32ddL1dND1dNHzc9Dsccb5d9X4dtP7d9b7d9b4dtTzdc/2ddLwccz+eNn9eNj8eNcB5xaEAAAAIXRSTlMABwwRHyQWKS4zPUJQOEsaR2RaX1Ubc2l8d25VaUaNhoFULNY8AAACD0lEQVRIx7XW21LjMBAEUNjsem/gMcFCgCXg/7+SnvY4Y0sRDkXRDw4POdVCkSxdNXN99blcr3Kx+LHKJY7ioOk6ftDtEnwdEZEgoUPgwHaJBPlpCUGazIwRfPmXBX9KUNZQqFFC8fuU2YGhrDasCTKLP6fQoY1l5w1aKP6eQoc2cVUa1Ki4Rf4h+qlOy6ouzkEnakAI/jOEYFDoKmZjYyiGPCB0iwqqzhnUgOTcW9RpmXcVCIY1eej7G0vf5wFlVI5qQzKNCB7KSuWIBghGyfF4vL/HYwKDAqJy5EVmRhV3iLrJFFGgcuRmIokpRrLR1Qati9ADkuIzEhMYlFdJR+Sjo9EeJQ8MmCufiu3o8lwE88RAAU3F+HzuiGaTYB4ZKlYt43MkM9KiSYvUvL2+vqlKS9WMpEA2DRwczMsLFKtsfERhQV1YIRsdDJSNb1yhbkGyQfEjJAs6WBP/p2p46e64Roctul1+2rSeCM6eT0RoTXncmfJy6bnSuKl+3HoZxbQso9RYRpzzcsHGecHGesHubY3U2BrVJszFJqTJ9Sast/u4s93LKu1SNvHFMoGoqYpMhcYrbCheRs2X5QCmAcmNl6VX+WsZbsgqWFMbIlP7B0B11Ej7qKEB+uqh5l2t49NM46AO5w7qYAd1+0oQhI6hELsSXH75ELn4zgIIqcDJ1y9U+1e3b7kkurPH2bwDPOpTDAlb58YAAAAASUVORK5CYII=",
    Pe = "/assets/dice_bg.602ebc14.jpg",
    Ee = "/assets/dice_bg_w.ed430dde.jpg",
    je = "/assets/oval.efb1326f.png";
const w = {
    imgHashDiceBg: Ne,
    imgHashDice: Be,
    hashdiceIcon: Ae,
    hand: xe,
    handJson: Oe,
    hashdiceBg: Ie,
    hashdiceBg_w: De,
    spinBtn: Ge,
    rollNum: Te,
    mask: Ve,
    mask_w: Re,
    light: ze,
    dice_bg: Pe,
    dice_bg_w: Ee,
    oval: je
};
const Le = function() {
        const [a, i] = b.exports.useState(!1);
        b.exports.useEffect(() => {
            const s = setInterval(() => {
                i(l => !l)
            }, 1e3);
            return () => clearInterval(s)
        }, []);
        const e = (s, l) => {
                const r = s % 2 === 0;
                return !!(r && l || !r && !l)
            },
            n = s => s.map((l, r) => t("img", {
                className: "img-" + (r + 1),
                alt: "lights",
                src: w.light,
                style: {
                    visibility: e(r, a) ? "visible" : "hidden"
                }
            }, r));
        return t("div", {
            className: Me,
            children: Array(2).fill([1, 1, 1, 1]).map((s, l) => t("div", {
                className: l === 0 ? "left" : "right",
                children: n(s)
            }, "img-" + l))
        })
    },
    Me = "l17xoxyg";
const _e = () => {
        const a = k(),
            i = b.exports.useRef(),
            e = X(),
            n = b.exports.useRef(0),
            [s, l] = b.exports.useState(!1);
        b.exports.useEffect(() => {
            a.settings.fastEnable || (a.isBetting && l(!0), setTimeout(() => {
                e() && l(!1)
            }, 1e3))
        }, [a.isBetting]), b.exports.useEffect(() => {
            n.current === 0 ? (n.current++, I(a.gameResult)) : a.settings.fastEnable ? I(a.gameResult) : M(a.gameResult)
        }, [a.gameResult]);
        const r = () => {
                a.settings.soundEnable && a.gameIsWin && a.sounds.playSound("win")
            },
            M = h => {
                var c;
                if (i.current) {
                    const f = D(h),
                        m = (c = i.current) == null ? void 0 : c.children;
                    for (let d = 0; d < m.length; d++) {
                        let W = m.length - 1 - d;
                        setTimeout(() => {
                            a.sounds.playSound("playingSound"), _(m[d].firstChild, Number(f[d]))
                        }, W * 200)
                    }
                    a.settings.soundEnable && a.gameIsWin && setTimeout(() => {
                        a.sounds.playSound("win")
                    }, 1800)
                }
            },
            _ = (h, c) => {
                h.style.backgroundPositionY = 0, h.scrollOption || (h.scrollOption = {
                    angle: 0
                }), G.to(h.scrollOption, 1, {
                    angle: h.scrollOption.angle + 360 - h.scrollOption.angle % 360 + c * 36,
                    ease: "easeInCirc",
                    onUpdate() {
                        let f = -h.scrollOption.angle * 940 / 360 % 940;
                        G.set(h, {
                            y: f
                        })
                    }
                })
            },
            I = h => {
                var c;
                if (i.current) {
                    const f = D(h),
                        m = (c = i.current) == null ? void 0 : c.children;
                    for (let d = 0; d < m.length; d++) m[d].firstChild.style.transform = null, m[d].firstChild.style.backgroundPositionY = -f[d] * 94 + "px";
                    r()
                }
            },
            D = h => {
                let c = h.toString().split("");
                const f = c.length;
                if (c.length < 5)
                    for (let m = 0; m < 5 - f; m++) c.unshift("0");
                else f > 5 && (c = c.splice(5));
                return c
            },
            Y = t("img", {
                alt: "mask",
                src: S.isDarken ? w.mask : w.mask_w
            });
        return t("div", {
            className: Fe,
            children: t("div", {
                className: "roll-panel",
                children: o("div", {
                    className: "man-display",
                    children: [t("img", {
                        src: S.isDarken ? w.hashdiceBg : w.hashdiceBg_w,
                        alt: ""
                    }), t(Le, {}), t(Ye, {
                        onClick: a.handGameBet
                    }), t("div", {
                        className: "lottery-numb",
                        ref: i,
                        children: Array(5).fill(1).map((h, c) => o("div", {
                            className: "roll-numb-wrap",
                            children: [t("div", {
                                className: "roll-numb"
                            }), Y]
                        }, c))
                    }), t("button", {
                        className: s ? "spin-btn down" : "spin-btn",
                        disabled: a.isBetting,
                        onMouseDown: () => l(!0),
                        onMouseUp: () => l(!1),
                        onMouseOut: () => l(!1),
                        onTouchStart: () => l(!0),
                        onTouchEnd: () => l(!1),
                        onTouchCancel: () => l(!1),
                        onClick: a.handGameBet
                    })]
                })
            })
        })
    },
    Ye = N(function({
        onClick: i
    }) {
        const e = k(),
            [n, s] = K({
                config: w.handJson,
                image: w.hand,
                options: {
                    yoyo: !0,
                    repeat: 1,
                    paused: !0
                }
            });
        return b.exports.useEffect(() => {
            e.isBetting && !e.settings.fastEnable && s.restart()
        }, [e.isBetting]), t("div", {
            className: "hand",
            onClick: () => {
                s.restart(), i()
            },
            style: {
                pointerEvents: e.isBetting ? "none" : "auto"
            },
            children: n
        })
    });
var We = R.memo(N(_e));
const Fe = "n84ztxs";
const qe = N(function() {
    const i = k(),
        e = A(),
        n = () => i.priceLevel === "high" ? o("span", {
            className: "num",
            children: [">", 99999 - Math.floor(i.getChance(i.payout) * 1e3)]
        }) : o("span", {
            className: "num",
            children: ["<", Math.floor(i.getChance(i.payout) * 1e3)]
        });
    return o(Q, {
        className: Je,
        children: [o("div", {
            className: "main-hashdice",
            children: [t("div", {
                className: "dice-bg"
            }), t(We, {}), (() => t("div", {
                className: "amount-info",
                children: o("span", {
                    className: "amount-bg",
                    children: [t("span", {
                        className: i.priceLevel === "high" ? "" : "no-select",
                        onClick: () => {
                            i.isBetting || (i.priceLevel = "high")
                        },
                        children: e("common.high")
                    }), n(), t("span", {
                        className: i.priceLevel === "high" ? "no-select" : "",
                        onClick: () => {
                            i.isBetting || (i.priceLevel = "low")
                        },
                        children: e("common.low")
                    })]
                })
            }))()]
        }), t($, {})]
    })
});
Z({
    cl1: ["url(../assets/dice_bg.jpg)", "url(../assets/dice_bg_w.jpg)"],
    cl2: ["#3c3f48", "#c3cae5"],
    cl3: ["none", "0 0 12px 0 rgba(100, 106, 135, 0.07)"],
    cl4: ["2px", "0"],
    cl5: ["0", "2px"],
    cl6: [H("#99a4b0", .8), "#545b63"],
    cl9: [H("#31343c", .8), H("#a1a9cb", .8)],
    cl10: ["none", "linear-gradient(to bottom, #60667a, #b6b8c1),linear-gradient(to bottom, #d8d8d8, #d8d8d8)"]
});
const Je = "n13jplhj",
    Ue = N(function() {
        const a = k(),
            i = x.useSingleDetail();
        return o(ee, {
            children: [t(te, {
                list: a.myBets,
                keyof: "betId",
                onDetail: i,
                getResult: e => e.gameValue.gameValue
            }), t(qe, {})]
        })
    });
var Ke = N(function() {
    const i = k(),
        e = i.autoBet,
        n = A(),
        s = () => {
            e.isRunning ? e.stop() : e.start().catch(P)
        },
        l = () => t(z, {
            className: "bet-button",
            size: "big",
            type: "conic",
            onClick: s,
            children: i.autoBet.isRunning ? n("common.stop_auto_bet") : n("common.start_auto_bet")
        });
    return o("div", {
        className: Xe,
        children: [S.isMobile && l(), t(y.CoinInput, {
            checkIncrease: !0
        }), t(y.TimesInput, {}), t(y.IncreaseInput, {}), t(y.StopInput, {}), t(y.IncreaseInput, {
            isLose: !0
        }), t(y.StopInput, {
            isLose: !0
        }), t(ne, {}), !S.isMobile && l()]
    })
});
const Xe = "a76vzzu";
const Qe = N(function() {
        const i = A(),
            e = k(),
            n = () => t(z, {
                className: "bet-button",
                type: "conic",
                size: "big",
                disabled: e.isBetting,
                onClick: e.handGameBet,
                children: i("common.bet")
            });
        return o("div", {
            className: $e,
            children: [S.isMobile && n(), t(y.CoinInput, {}), t(ae, {
                label: o("div", {
                    className: "hashdice-payout",
                    children: [t("div", {
                        children: i("common.payout")
                    }), o("div", {
                        children: [t("span", {
                            children: i("common.chance")
                        }), o("span", {
                            className: "green",
                            children: [e.getChance(e.payout), "%"]
                        })]
                    })]
                }),
                size: "small",
                value: e.payout,
                onChange: e.changePayout,
                max: 99e3,
                min: 1.0102,
                precision: 4,
                children: t("div", {
                    className: "payout-span",
                    children: "X"
                })
            }), !S.isMobile && n()]
        })
    }),
    $e = "m1h7zqas",
    Ze = R.memo(() => {
        const a = A(),
            i = k(),
            e = [{
                title: a("common.game_intro"),
                node: t(ve, {})
            }, {
                title: a("common.fairness"),
                node: "/hashdice_help/fairness"
            }, {
                title: a("common.bankroll"),
                node: t(Se, {
                    game: i
                })
            }];
        return t(ie, {
            manualControl: t(Qe, {}),
            autoControl: t(Ke, {}),
            advancedControl: t(se, {}),
            gameView: t(Ue, {}),
            tabs: [{
                label: a("common.all_bet"),
                value: x.AllBet
            }, {
                label: a("common.my_bet"),
                value: x.MyBet
            }],
            actions: [t(oe, {}), t(le, {}), t(re, {}), t(ce, {}), t(he, {}), t(ue, {}), t(de, {
                list: e
            })]
        })
    });
var et = "/assets/click.f0459de5.mp3",
    tt = "/assets/playing.36e063b1.mp3",
    nt = "/assets/hashdice.0b0c3017.mp3",
    at = "/assets/win.1981b036.mp3";
const it = E.decode(p.GameValue);
class st extends me {
    constructor() {
        super({
            name: "HashDice",
            namespace: "/g/hd",
            sounds: {
                clickSound: et,
                playingSound: tt,
                win: at,
                hashdice: {
                    src: nt,
                    isBackground: !0,
                    loop: !0
                }
            },
            fairLink: "/hashdice_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/hashdice.html"
        }, Ze);
        u(this, "betInterval", 350);
        u(this, "priceLevel", "high");
        u(this, "payout", 1.98);
        u(this, "gameResult", 0);
        u(this, "gameIsWin", !1);
        u(this, "autoType", "Preset");
        u(this, "betStartTime", new Date().getTime());
        u(this, "handGameBet", () => {
            this.isBetting || this.handleBet().catch(P)
        });
        u(this, "changeToggleWin", () => {
            this.isBetting || (this.priceLevel = this.priceLevel === "high" ? "low" : "high")
        });
        u(this, "onBetRequest", async e => {
            let n = await e;
            const s = n.gameValue;
            this.gameResult = s.gameValue, this.gameIsWin = n.odds > 0;
            let l = 1800;
            if (this.settings.fastEnable) {
                const r = new Date().getTime() - this.betStartTime;
                l = r > this.betInterval ? 0 : this.betInterval - r
            }
            return await ge(l), n
        });
        u(this, "getChance", e => {
            const n = Number(new T(e).toFixed(4));
            return Math.floor(99 / n * 1e4) / 1e4
        });
        u(this, "changePayout", e => {
            this.payout = e
        });
        pe(this, {
            priceLevel: B,
            payout: B,
            gameResult: B,
            gameIsWin: B,
            autoType: B,
            maxProfit: fe
        }), this.changePayout = this.changePayout.bind(this), this.addHotkey("q", this.changeToggleWin, "Toggle condition to win");
        const e = this.hotkeyList.find(n => n.key == "space");
        e && (e.handler = () => (this.controlIdx === 2 || (this.controlIdx === 1 ? this.autoBet.isRunning ? this.autoBet.stop() : this.autoBet.start() : this.handGameBet()), !1)), be(() => {
            this.needDeduction = !this.settings.fastEnable
        }), this.on("betStart", () => {
            this.betStartTime = new Date().getTime(), this.sounds.playSound("clickSound")
        })
    }
    get maxProfit() {
        return this.amount.mul(this.payout).sub(this.amount)
    }
    gameValueDecoder(e) {
        return it(e)
    }
    async handleScriptBet(e, {
        payout: n = this.payout
    }) {
        return this.payout = n, super.handleScriptBet(e)
    }
    betValue() {
        let e = new T(this.payout).mul(this.oddsScale).toNumber();
        return E.encode(p.BetValue)({
            payout: e,
            isHigh: this.priceLevel === "high"
        })
    }
}
const L = new st;
var ot = L;
window.hdg = L;

function mt({
    bodyLock: a
}) {
    return t(V, {
        bodyLock: a,
        children: o("div", {
            className: "item",
            children: [t("h2", {
                children: "Is HashDice a fair game?"
            }), o("div", {
                className: "help-content",
                children: [t("p", {
                    children: "We are a fair and transparent betting platform, aiming to eliminate all unfair factors and let players have fun, provides HashDice with provable and verified system that allows each game fair in encrypted way."
                }), t("p", {
                    children: "In order to allow players to verify their bets, a pair of Server Seed and Client Seed is used to calculate a roll number."
                }), t("p", {
                    children: "Knowing Server Seed, Client Seed and Nonce it's possible to calculate bet result. To prevent a player from result prediction, Server Seed is hidden, and a SHA-256 hash of the seed is shown instead. After next randomization, previous Server Seed is revealed and a player is able to verify the bet. Also, players can make sure that Server Seed wasn't changed by comparing their hashes before and after randomization."
                })]
            }), t("h2", {
                children: "How is the data calculated?"
            }), o("div", {
                className: "help-content",
                children: [t("p", {
                    children: "To generate a roll number between 0 and 99,999:"
                }), o("ol", {
                    children: [t("li", {
                        children: "First we calculate the hash value of the combination with HMAC_SHA512. This gives us a 64-character hexadecimal string: hash = HMAC_SHA512 (clientSeed:nonce, serverSeed)."
                    }), t("li", {
                        children: "We then take the first 5 characters of that hash and convert them to a decimal number ranging from 0 to 1,048,575 (16 ^ 5 - 1). If it is less than 1 million, we divide it by 100,000 and use it as your roll outcome. Otherwise, we repeat using the next five characters. We are able to repeat the process up to 25 times."
                    }), t("li", {
                        children: "In the very rare case ((48,576 / 1,000,000) ^ 25) that none of the 25 trials are lower than 1 million when converted to decimal, we use the remaining 3 characters and convert them to your roll number."
                    })]
                }), t("p", {
                    children: "Code Example"
                }), t("p", {
                    children: "The following code example can be used to verify a bet:"
                }), t(ye, {
                    children: `function getRoll (serverSeed, clientSeed, nonce) {
  var hash = hmac_sha512(clientSeed:nonce, serverSeed);
  var index = 0;
  do {
    var lucky = parseInt(hash.substr(index, 5), 16);
    index += 5;
  } while (lucky >= 1000000);
  return lucky % 100000;
}
`
                }), o("p", {
                    children: ["Please also check our online bet", t("a", {
                        className: "text-decoration cl-primary",
                        href: "https://bcgame-project.github.io/verify/hashdice.html",
                        target: "_blank",
                        children: "verify"
                    }), "."]
                }), t("p", {
                    children: "Tip: A new seed must be set to verify the previous data (the server seed is encrypted)."
                })]
            })]
        })
    })
}
const lt = (a, i, e) => {
        let n = `${ot.config.validateLink}?s=${a}&c=${i}&n=${e}`;
        window.open(n)
    },
    rt = x.withSingleDetail({
        onValidate: lt,
        result: ({
            betLog: a
        }) => {
            const {
                gameValue: i,
                number: e,
                chance: n
            } = a.gv, s = A(), {
                high: l
            } = a.bv;
            return o(we, {
                className: "rt_items",
                children: [o("div", {
                    className: "item-wrap",
                    children: [o("div", {
                        className: "item-num",
                        children: [t(C, {
                            className: "result",
                            name: "Result"
                        }), s("common.result")]
                    }), t("div", {
                        className: "item-desc",
                        children: i
                    })]
                }), o("div", {
                    className: "item-wrap",
                    children: [o("div", {
                        className: "item-num",
                        children: [t(C, {
                            className: "bettype",
                            name: "Bet"
                        }), s("common.bet")]
                    }), t("div", {
                        className: "item-desc",
                        children: o("span", {
                            className: "mthan",
                            children: [l ? ">" : "<", e]
                        })
                    })]
                }), o("div", {
                    className: "item-wrap",
                    children: [o("div", {
                        className: "item-num",
                        children: [t(C, {
                            className: "chance",
                            name: "Chance"
                        }), s("common.chance")]
                    }), t("div", {
                        className: "item-desc",
                        children: (n * 100).toFixed(2) + "%"
                    })]
                })]
            })
        }
    });
var pt = rt;
export {
    Se as Bankroll, pt as Detail, mt as Fairness, ot as Game
};
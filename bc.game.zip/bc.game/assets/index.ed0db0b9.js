import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as e
} from "./index.28e31dff.js";
var o = `<section>
    <p>Bonuses are always exciting and when there is no limit behind them gets even more exciting! BC.GAME believes that our players are worth more and they should receive good bonuses hence we offer deposit bonus on your first 4 deposits instead of 1 which others give out! So check the details below and start grabbing your amazing bonuses!</p>
    <p>Our deposit bonus comes with 3 sections in each 4 deposits please read below to understand how it works to take complete advantage of this amazing offer:</p>
    <p><b style="color: var(--title-color);">1st deposit with upto 180% bonus:</b>With your first deposit you can receive minimum 80% and maximum of 180% bonus!</p>
    <ol>
        <li>If you deposit between $30 - $80 you will be eligible for 80% bonus so for example you deposit $30 you will receive $24 as bonus.</li>
        <li>If you deposit between $80 - $400 you will be eligible for 100% bonus so for example you deposit $80 you will receive $80 as bonus.</li>
        <li>If you deposit $400 and above you will be eligible for 180% bonus so for example you deposit $400 you will receive $720 as bonus.</li>
    </ol>
    <p><b style="color: var(--title-color);">2nd deposit with upto 200% bonus:</b>With your second deposit you can receive minimum 100% and maximum of 200% bonus! </p>
    <ol>
        <li>If you deposit between $60 - $120 you will be eligible for 100% bonus so for example you deposit $60 you will receive $60 as bonus.</li>
        <li>If you deposit between $120 - $600 you will be eligible for 150% bonus so for example you deposit $120 you will receive $180 as bonus.</li>
        <li>If you deposit $600 and above you will be eligible for 200% bonus so for example you deposit $600 you will receive $1200 as bonus.</li>
    </ol>
    <p><b style="color: var(--title-color);">3rd deposit bonus with upto 220% bonus:</b>With your third deposit you can receive minimum 100% and maximum of 220% bonus! </p>
    <ol>
        <li>If you deposit between $120 - $300 you will be eligible for 100% bonus so for example you deposit $120 you will receive $120 as bonus.</li>
        <li>If you deposit between $300 - $1500 you will be eligible for 150% bonus so for example you deposit $300 you will receive $450 as bonus.</li>
        <li>If you deposit $1500 and above you will be eligible for 220% bonus so for example you deposit $1500 you will receive $3300 as bonus.</li>
    </ol>
    <p><b style="color: var(--title-color);">4th deposit bonus with upto 240% bonus: </b>With your first deposit you can receive minimum 100% and maximum of 240% bonus! </p>
    <ol>
        <li>If you deposit between $150 - $400 you will be eligible for 100% bonus so for example you deposit $150 you will receive $150 as bonus.</li>
        <li>If you deposit between $400 - $3000 you will be eligible for 150% bonus so for example you deposit $400 you will receive $600 as bonus.</li>
        <li>If you deposit $3000 and above you will be eligible for 240% bonus so for example you deposit $3000 you will receive $7200 as bonus.</li>
    </ol>

    <h2>How you will receive deposit bonus?</h2>
    <p>Once you make the deposit with any of the valid amounts as mentioned above you will automatically receive the deposit bonus in BCD, This BCD will be locked and which can be unlocked by wagering on any of the games available on our platform.</p>

    <h2>What is BCD?</h2>
    <p>BCD is our in-house cryptocurrency and its value is equivalent to 1 USDT. You can use BCD for playing any games on our platform or you can exchange them to other coins on our swap at any time.</p>

    <h2>How to UNLOCK BCD Rewards?</h2>
    <p>BCD unlocks when you wager on any of the games available at our platform. Below you can find out the calculation to know how much you have to wager to unlock.</p>
    <p>Wager amount x 1% x 25% = Unlock amount</p>
    <p>For example you wagered $400 on any of our games it will unlock 400x1%x25% = 1 BCD for you. </p>
    <p>400% wagering requirements may seem high but there are many advantages. Why you should choose BC.GAME deposit bonus over any other platform? Please read below to understand the advantages:</p>
    <ol>
        <li><b>No Restrictions on Withdrawals: </b>Unlike other platforms we do not hold or lock your initial deposit and you are free to withdraw at any time you like.</li>
        <li><b>No time limits: </b>There is no time limit to wager and unlock your locked BCD you can do it anytime you like and it will be available with all details on your BCD dashboard.</li>
        <li><b>6000+ Games to wager on:</b>BC.GAME offers wide range of games where you can wager and unlock your BCD rewards whether its in-house games or slots.</li>
        <li><b>Enjoy more features:</b>While you unlock your BCD you will be able to enjoy more features and get more rewards along such as rakeback, recharge, tasks, etc.</li>
    </ol>

    <h2>FAQs</h2>
    <p><b style="color: var(--title-color);">What welcome bonus BC.GAME offers?</b></p>
    <p>As a special Welcome bonus we offer 300% deposit bonus to all new players who deposit minimum $10 within 20 minutes of registration. If you fail to do it in 20 minutes then you have the other 4 deposit bonus as mentioned above.</p>
    <p></p>
    <p><b style="color: var(--title-color);">Is there any time restriction on wager?</b></p>
    <p>No, there is no time restrictions you can wager and unlock your bonus anytime you like.</p>
    <p></p>
    <p><b style="color: var(--title-color);">Will you block my deposit funds till I wager?</b></p>
    <p>No, your initial deposit will not be locked at any stage you can withdraw, swap, or play at anytime without any restrictions.</p>
    <p></p>
    <p><b style="color: var(--title-color);">If I deposit less than minimum amount will it still give me option to deposit again for bonus?</b></p>
    <p>Yes, if you have not met the minimum deposit requirements you can surely deposit again with minimum amount to receive the deposit bonus.</p>
</section>`,
    n = `<section>\r
  <p>Os b\xF4nus s\xE3o sempre emocionantes e quando n\xE3o h\xE1 limite por tr\xE1s deles ficam ainda mais emocionantes! BC.GAME acredita que nossos jogadores valem mais e deve receber os melhores b\xF4nus, por isso oferecemos b\xF4nus de dep\xF3sito nos seus primeiros 4 dep\xF3sitos em vez de 1 que os outros d\xE3o! Ent\xE3o confira os detalhes abaixo e comece a pegar seus b\xF4nus incr\xEDveis!\r
\r
Nosso b\xF4nus de dep\xF3sito vem com 3 se\xE7\xF5es em cada 4 dep\xF3sitos, leia abaixo para entender como funciona para aproveitar ao m\xE1ximo esta oferta incr\xEDvel:</p>\r
  <p><b style="color: var(--title-color);">1\xBA dep\xF3sito com b\xF4nus de at\xE9 180%:</b> Com seu primeiro dep\xF3sito voc\xEA pode receber um b\xF4nus m\xEDnimo de 80% e m\xE1ximo de 180%!</p>\r
  <ol>\r
      <li>Se voc\xEA depositar entre $ 30 - $ 80, voc\xEA ser\xE1 eleg\xEDvel para um b\xF4nus de 80%, ent\xE3o, por exemplo, se voc\xEA depositar $ 30, receber\xE1 $ 24 como b\xF4nus.</li>\r
     <li>Se voc\xEA depositar entre US$ 80 e US$ 400, ser\xE1 eleg\xEDvel para um b\xF4nus de 100%. por exemplo, se voc\xEA depositar $ 80, receber\xE1 $ 80 como b\xF4nus.</li>\r
       <li>Se voc\xEA depositar $ 400 ou mais, ser\xE1 eleg\xEDvel para um b\xF4nus de 180%, por exemplo, se voc\xEA depositar $ 400, receber\xE1 $ 720 como b\xF4nus.</li>\r
  </ol>\r
  <p><b style="color: var(--title-color);">2\xBA dep\xF3sito com b\xF4nus de at\xE9 200%: </b> Com seu segundo dep\xF3sito voc\xEA pode receber um b\xF4nus m\xEDnimo de 100% e m\xE1ximo de 200%!</p>\r
  <ol>\r
      <li>Se voc\xEA depositar entre $ 60 e $ 120, ser\xE1 eleg\xEDvel para um b\xF4nus de 100%, ent\xE3o, por exemplo, se voc\xEA depositar $ 60, receber\xE1 $ 60 como b\xF4nus.</li>\r
       <li>Se voc\xEA depositar entre $ 120 e $ 600, ser\xE1 eleg\xEDvel para um b\xF4nus de 150%, por exemplo, se voc\xEA depositar $120, receber\xE1 $ 180 como b\xF4nus.</li>\r
       <li>Se voc\xEA depositar $ 600 ou mais, ser\xE1 eleg\xEDvel para um b\xF4nus de 200%, ent\xE3o, por exemplo, se voc\xEA depositar $ 600, receber\xE1 $ 1200 como b\xF4nus.</li>\r
  </ol>\r
  <p><b style="color: var(--title-color);">B\xF4nus de 3\xBA dep\xF3sito com b\xF4nus de at\xE9 220%:</b> Com seu terceiro dep\xF3sito voc\xEA pode receber um b\xF4nus m\xEDnimo de 100% e m\xE1ximo de 220%!</p>\r
  <ol>\r
      <li> Se voc\xEA depositar entre $ 120 - $ 300, voc\xEA ser\xE1 eleg\xEDvel para um b\xF4nus de 100%, ent\xE3o, por exemplo, se voc\xEA depositar $ 120, receber\xE1 $ 120 como b\xF4nus. </li>\r
       <li> Se voc\xEA depositar entre $ 300 - $ 1500, voc\xEA ser\xE1 eleg\xEDvel para um b\xF4nus de 150%, ent\xE3o, por exemplo, se voc\xEA depositar $ 300, receber\xE1 $ 450 como b\xF4nus. </li>\r
       <li> Se voc\xEA depositar $ 1.500 ou mais, ser\xE1 eleg\xEDvel para um b\xF4nus de 220%, ent\xE3o, por exemplo, se voc\xEA depositar $ 1.500, receber\xE1 $ 3.300 como b\xF4nus. </li>\r
  </ol>\r
  <p><b style="color: var(--title-color);">B\xF4nus de 4\xBA dep\xF3sito com b\xF4nus de at\xE9 240%:</b> Com seu primeiro dep\xF3sito voc\xEA pode receber um b\xF4nus m\xEDnimo de 100% e m\xE1ximo de 240%!</p>\r
  <ol>\r
      <li> Se voc\xEA depositar entre $ 150 - $ 400, ser\xE1 eleg\xEDvel para um b\xF4nus de 100%, ent\xE3o, por exemplo, se voc\xEA depositar $ 150, receber\xE1 $ 150 como b\xF4nus. </li>\r
       <li> Se voc\xEA depositar entre $ 400 - $ 3000, voc\xEA ser\xE1 eleg\xEDvel para um b\xF4nus de 150%, ent\xE3o, por exemplo, se voc\xEA depositar $ 400, receber\xE1 $ 600 como b\xF4nus. </li>\r
       <li> Se voc\xEA depositar $ 3.000 ou mais, ser\xE1 eleg\xEDvel para um b\xF4nus de 240%, ent\xE3o, por exemplo, se voc\xEA depositar $ 3.000, receber\xE1 $ 7.200 como b\xF4nus. </li>\r
  </ol>\r
\r
  <h2>Como voc\xEA receber\xE1 o b\xF4nus de dep\xF3sito?</h2>\r
  <p>Assim que voc\xEA fizer o dep\xF3sito com qualquer um dos valores v\xE1lidos mencionados acima, voc\xEA receber\xE1 automaticamente o b\xF4nus de dep\xF3sito em BCD, este BCD ser\xE1 bloqueado e pode ser desbloqueado apostando em qualquer um dos jogos dispon\xEDveis em nossa plataforma.</p>\r
\r
  <h2>O que \xE9 o BCD?</h2>\r
  <p>BCD \xE9 nossa criptomoeda interna e seu valor \xE9 equivalente a 1 USDT. Voc\xEA pode usar o BCD para jogar qualquer jogo em nossa plataforma ou troc\xE1-los por outras moedas em nosso swap a qualquer momento.</p>\r
\r
  <h2>Como desbloquear recompensas BCD?</h2>\r
<p>O BCD \xE9 desbloqueado quando voc\xEA aposta em qualquer um dos jogos dispon\xEDveis em nossa plataforma. Abaixo voc\xEA encontra o c\xE1lculo para saber quanto voc\xEA tem que apostar para desbloquear.</p>\r
   <p>Valor da aposta x 1% x 25% = Valor desbloqueado</p>\r
   <p>Por exemplo, voc\xEA apostou $400 em qualquer um de nossos jogos, ele desbloquear\xE1 400x1%x25% = 1 BCD para voc\xEA. </p>\r
   <p>Os requisitos de aposta de 400% podem parecer altos, mas h\xE1 muitas vantagens. Por que voc\xEA deve escolher o b\xF4nus de dep\xF3sito BC.GAME em vez de qualquer outra plataforma? Leia abaixo para entender as vantagens:</p>\r
  <ol>\r
    <li><b>Sem restri\xE7\xF5es aos saques: </b>Ao contr\xE1rio de outras plataformas, n\xE3o retemos ou bloqueamos seu dep\xF3sito inicial e voc\xEA pode sacar a qualquer momento.</li>\r
       <li><b>Sem limites de tempo: </b>N\xE3o h\xE1 limite de tempo para apostar e desbloquear seu BCD bloqueado, voc\xEA pode fazer isso quando quiser e ele estar\xE1 dispon\xEDvel com todos os detalhes no painel do BCD.</li>\r
       <li><b>Mais de 6.000 jogos para apostar:</b>BC.GAME oferece uma ampla variedade de jogos onde voc\xEA pode apostar e desbloquear suas recompensas BCD, sejam jogos internos ou slots.</li>\r
       <li><b>Aproveite mais recursos:</b> ao desbloquear seu BCD, voc\xEA poder\xE1 aproveitar mais recursos e obter mais recompensas, como rakeback, recarga, tarefas etc.</li>\r
  </ol>\r
\r
  <h2>FAQs</h2>\r
<p><b style="color: var(--title-color);">Que b\xF4nus de boas-vindas BC.GAME oferece?</b></p>\r
  <p>Como um b\xF4nus especial de boas-vindas, oferecemos um b\xF4nus de dep\xF3sito de 300% a todos os novos jogadores que depositarem um m\xEDnimo de $ 10 em 20 minutos ap\xF3s a inscri\xE7\xE3o. Se voc\xEA n\xE3o conseguir fazer isso em 20 minutos, voc\xEA tem os outros 4 b\xF4nus de dep\xF3sito, conforme mencionado acima.  </p>\r
<p><b style="color: var(--title-color);">Existe alguma restri\xE7\xE3o de tempo na aposta?</b></p>\r
  <p>N\xE3o, n\xE3o h\xE1 restri\xE7\xF5es de tempo, voc\xEA pode apostar e desbloquear seu b\xF4nus sempre que quiser.  </p>\r
<p><b style="color: var(--title-color);">Voc\xEA bloquear\xE1 meus fundos de dep\xF3sito at\xE9 eu apostar?</b></p>\r
  <p>N\xE3o, seu dep\xF3sito inicial n\xE3o ser\xE1 bloqueado em nenhum est\xE1gio em que voc\xEA possa sacar, trocar ou jogar a qualquer momento sem restri\xE7\xF5es.    </p>\r
  <p><b style="color: var(--title-color);">Se eu depositar menos do que o valor m\xEDnimo, isso ainda me dar\xE1 a op\xE7\xE3o de depositar novamente para o b\xF4nus?</b></p>\r
  <p>Sim, se voc\xEA n\xE3o atendeu aos requisitos m\xEDnimos de dep\xF3sito, certamente pode depositar novamente com o valor m\xEDnimo para receber o b\xF4nus de dep\xF3sito.</p>\r
</section>`,
    i = `<section>
    <p>Bonus selalu menarik dan ketika tidak ada batasannya itu menjadikan lebih menarik lagi!! BC.GAME percaya bahwa pemain kami lebih berharga dan mereka harus menerima bonus yang bagus karena itu kami menawarkan bonus setoran pada 4 setoran pertama Anda, tidak hanya sekali seperti yang lainnya!! Jadi, periksa detail di bawah ini dan mulailah meraih bonus luar biasa Anda!</p>
    <p>Bonus setoran kami hadir dengan 3 bagian di setiap 4 setoran, silakan baca di bawah ini untuk memahami cara kerjanya untuk memanfaatkan sepenuhnya penawaran luar biasa ini:</p>
    <p><b style="color: var(--title-color);">Setoran pertama dengan bonus hingga 180%:</b>Dengan setoran pertama Anda, Anda dapat menerima bonus minimal 80% dan maksimal 180%!</p>
    <ol>
        <li>Jika Anda menyetor antara $30 - $80, Anda akan memenuhi syarat untuk mendapatkan bonus 80%, jadi misalnya Anda menyetor $30, Anda akan menerima $24 sebagai bonus.</li>
        <li>Jika Anda menyetor antara $80 - $400, Anda akan memenuhi syarat untuk mendapatkan bonus 100%, misalnya; jika Anda menyetor $80, Anda akan menerima $80 sebagai bonus.</li>
        <li>Jika Anda menyetor $400 ke atas, Anda akan memenuhi syarat untuk mendapatkan bonus 180%, jadi misalnya, Anda menyetor $400, Anda akan menerima $720 sebagai bonus.</li>
    </ol>
    <p><b style="color: var(--title-color);">Setoran ke-2 dengan bonus hingga 200%:</b>Dengan setoran kedua, Anda dapat menerima bonus minimum 100% dan maksimum 200%! </p>
    <ol>
        <li>Jika Anda menyetor antara $60 - $120, Anda berhak mendapatkan bonus 100%, jadi misalnya; jika Anda menyetor $60, Anda akan menerima $60 sebagai bonus.</li>
        <li>Jika Anda menyetor antara $120 - $600, Anda berhak mendapatkan bonus 150%, jadi misalnya; jika Anda menyetor $120, Anda akan menerima $180 sebagai bonus.</li>
        <li>Jika Anda menyetor $600 ke atas, Anda akan memenuhi syarat untuk bonus 200%, jadi misalnya; jika Anda menyetor $600, Anda akan menerima $1200 sebagai bonus.</li>
    </ol>
    <p><b style="color: var(--title-color);">Bonus setoran ke-3 dengan bonus hingga 220%:</b>Dengan setoran ketiga, Anda dapat menerima bonus minimum 100% dan maksimum 220%!</p>
    <ol>
        <li>Jika Anda menyetor antara $120 - $300, Anda akan memenuhi syarat untuk mendapatkan bonus 100%, jadi misalnya; jika Anda menyetor $120, Anda akan menerima $120 sebagai bonus.</li>
        <li>Jika Anda menyetor antara $300 - $1500, Anda akan memenuhi syarat untuk bonus 150%, jadi misalnya; jika Anda menyetor $300, Anda akan menerima $450 sebagai bonus.</li>
        <li>Jika Anda menyetor $1500 ke atas, Anda akan memenuhi syarat untuk bonus 220%, jadi misalnya Anda menyetor $1500, Anda akan menerima $3300 sebagai bonus.</li>
    </ol>
    <p><b style="color: var(--title-color);">Bonus setoran ke-4 dengan bonus hingga 240%: </b>Dengan setoran pertama Anda, Anda dapat menerima bonus minimum 100% dan maksimum 240%! </p>
    <ol>
        <li>Jika Anda menyetor antara $150 - $400, Anda akan memenuhi syarat untuk mendapatkan bonus 100%, jadi misalnya; jika Anda menyetor $150, Anda akan menerima $150 sebagai bonus.</li>
        <li>Jika Anda menyetor antara $400 - $3000, Anda berhak mendapatkan bonus 150%, jadi misalnya; jika Anda menyetor $400, Anda akan menerima $600 sebagai bonus.</li>
        <li>Jika Anda menyetor $3000 ke atas, Anda akan memenuhi syarat untuk mendapatkan bonus 240%, jadi misalnya Anda menyetor $3000, Anda akan menerima $7200 sebagai bonus.</li>
    </ol>

    <h2>Bagaimana Anda akan menerima bonus dari setoran?</h2>
    <p>Setelah Anda melakukan deposit dengan jumlah yang valid seperti yang disebutkan di atas, Anda akan secara otomatis menerima bonus deposit dalam BCD, BCD ini akan dikunci dan dapat dibuka dengan bertaruh pada salah satu permainan yang tersedia di platform kami.</p>

    <h2>Apa itu BCD?</h2>
    <p>BCD adalah cryptocurrency internal kami dan nilainya setara dengan 1 USDT. Anda dapat menggunakan BCD untuk memainkan permainan apa pun di platform kami atau Anda dapat menukarnya dengan koin lain di swap kami kapan saja.</p>

    <h2>Bagaimana cara MEMBUKA Hadiah BCD?</h2>
    <p>BCD terbuka ketika Anda bertaruh pada salah satu permainan yang tersedia di platform kami. Di bawah ini Anda dapat mengetahui perhitungan untuk mengetahui berapa banyak yang harus Anda pertaruhkan untuk membuka kunci.</p>
    <p>Jumlah Taruhan x 1% x 25% = Jumlah yang dibuka</p>
    <p>Misalnya Anda bertaruh $400 pada salah satu permainan kami, itu akan membuka 400x1%x25% = 1 BCD untuk Anda.</p>
    <p>Persyaratan taruhan 400% mungkin terlihat tinggi tetapi ada banyak keuntungan. Mengapa Anda harus memilih bonus setoran BC.GAME daripada platform lain? Silakan baca di bawah ini untuk memahami kelebihannya:</p>
    <ol>
        <li><b>Tidak Ada Batasan Penarikan: </b>Tidak seperti platform lain, kami tidak menahan atau mengunci setoran awal Anda dan Anda bebas untuk menarik kapan saja Anda mau.</li>
        <li><b>Tidak ada batasan waktu: </b>Tidak ada batasan waktu untuk bertaruh dan membuka kunci BCD Anda yang terkunci. Anda dapat melakukannya kapan saja Anda suka, dan itu akan tersedia dengan semua detail di dasbor BCD Anda.</li>
        <li><b>6000+ Game untuk dipertaruhkan:</b>BC.GAME menawarkan berbagai macam game tempat Anda dapat bertaruh dan membuka hadiah BCD, baik game internal maupun slotnya.</li>
        <li><b>6000+ Game untuk dipertaruhkan:</b>Penawaran BC.GAME Nikmati lebih banyak fitur:</b>Saat Anda membuka kunci BCD, Anda akan dapat menikmati lebih banyak fitur dan mendapatkan lebih banyak hadiah seperti rakeback, pengisian ulang, tugas, dll .</li>
    </ol>

    <h2>FAQs (Pertanyaan Yang Sering Diajukan)</h2>
    <p><b style="color: var(--title-color);">Bonus selamat datang apa yang ditawarkan BC.GAME?</b></p>
    <p>Sebagai bonus sambutan khusus, kami menawarkan bonus setoran 300% kepada semua pemain baru yang menyetor minimal $10 dalam waktu 20 menit setelah pendaftaran. Jika Anda gagal melakukannya dalam 20 menit, Anda memiliki 4 bonus setoran lain yang disebutkan di atas.</p>
    <p></p>
    <p><b style="color: var(--title-color);">Apakah ada batasan waktu untuk bertaruh?</b></p>
    <p>Tidak, tidak ada batasan waktu. Anda dapat bertaruh dan membuka kunci bonus Anda kapan pun Anda mau.</p>
    <p></p>
    <p><b style="color: var(--title-color);">Apakah Anda akan memblokir dana deposit saya sampai saya bertaruh?</b></p>
    <p>Tidak, setoran awal Anda tidak akan dikunci pada tahap apa pun. Anda dapat menarik, menukar, atau bermain kapan saja tanpa batasan.</p>
    <p></p>
    <p><b style="color: var(--title-color);">Jika saya menyetor kurang dari jumlah minimum, apakah masih memberi saya pilihan untuk menyetor lagi untuk bonus?</b></p>
    <p>Ya, jika Anda belum memenuhi persyaratan setoran minimum, Anda pasti dapat menyetor lagi dengan jumlah minimum untuk menerima bonus setoran.</p>
</section>`;

function t() {
    return e(a, {
        br: n,
        en: o,
        id: i
    })
}
export {
    t as
    default
};
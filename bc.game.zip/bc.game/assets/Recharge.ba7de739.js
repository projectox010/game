import {
    v as k,
    a as e,
    u as h,
    D as R,
    S as $,
    j as c,
    s as g,
    o as u,
    t as N,
    q as i,
    aA as t,
    A as S,
    I as f,
    b as w,
    r as d,
    aB as b,
    ab as H,
    aC as E,
    d as M,
    P as F,
    F as U,
    ax as I,
    p as y,
    aD as q,
    J as W,
    M as _,
    aE as P,
    ak as j,
    L,
    al as T,
    aF as z,
    a3 as V
} from "./index.28e31dff.js";
import {
    P as x
} from "./ParticleLayer.e2a68149.js";
import {
    r as O
} from "./recaptcha.94966f3c.js";
import "./usePixiGsap.bf451f35.js";

function G() {
    const a = h();
    return e(R, {
        title: a("page.recharge.about"),
        children: e($, {
            className: J,
            children: c("ul", {
                children: [c("li", {
                    children: [e("h3", {
                        children: a("page.recharge.about.tit_1")
                    }), e("p", {
                        children: a("page.recharge.about.desc_1")
                    })]
                }), c("li", {
                    children: [e("h3", {
                        children: a("page.recharge.about.tit_2")
                    }), e("p", {
                        dangerouslySetInnerHTML: {
                            __html: a("page.recharge.about.desc_2")
                        }
                    })]
                }), c("li", {
                    children: [e("h3", {
                        children: a("page.recharge.about.tit_3")
                    }), e("p", {
                        children: a("page.recharge.about.desc_3")
                    })]
                }), c("li", {
                    children: [e("h3", {
                        children: a("page.recharge.about.tit_4")
                    }), e("p", {
                        children: a("page.recharge.about.desc_4")
                    })]
                })]
            })
        })
    })
}
const A = () => {
        k.push(e(G, {}))
    },
    J = "hbmsw65";
var K = "/assets/disabled.872efa0c.svg",
    Q = "/assets/recharge.586261e1.json",
    X = "/assets/rechargew-white.fe1cd6d5.json",
    Y = "/assets/recharge_reward.6fe75678.json",
    Z = "/assets/recharge-0.86e44653.png",
    ee = "/assets/recharge-0-white.bba84859.png",
    ae = "/assets/recharge-25.00a320b4.png",
    re = "/assets/recharge-25-white.95bcca03.png",
    ce = "/assets/recharge-50.e17fcb0e.png",
    te = "/assets/recharge-50-white.707cf11a.png",
    se = "/assets/recharge-75.65f4c194.png",
    ne = "/assets/recharge-75-white.f019d73c.png",
    ie = "/assets/recharge-100.22090dcd.png",
    le = "/assets/recharge-100-white.6da3ced4.png";

function B(a) {
    return a < 25 ? g.isDarken ? Z : ee : a < 50 ? g.isDarken ? ae : re : a < 75 ? g.isDarken ? ce : te : a < 100 ? g.isDarken ? se : ne : g.isDarken ? ie : le
}
var D = {
    disabled: K,
    rechargeLottile: g.isDarken ? Q : X,
    rechargeReward: Y
};
window.$crisp && window.$crisp.push("on", "chat:closed", () => {
    window.$crisp.push(["set", "session:segments", [
        [""]
    ]], !0)
});

function de() {
    M.emit("openLiveSupport"), window.$crisp && (window.$crisp.push(["set", "session:segments", [
        ["start-vip"]
    ]]), window.$crisp.push(["do", "message:send", ["text", "\u26A1\uFE0F\u{1F50B}Recharge activate\u{1F50B}\u26A1\uFE0F"]]))
}

function oe({
    isRech: a
}) {
    const n = d.exports.useRef(null);
    d.exports.useEffect(() => {
        var r;
        (r = n.current) == null || r.play(0)
    }, []);
    const s = B(a ? 100 : 50);
    return c("div", {
        className: a ? "ready status-box" : "status-box",
        children: [e(b, {
            className: "charging",
            ref: n,
            loop: !0,
            style: {
                backgroundImage: `url(${s})`
            }
        }), e("div", {
            className: "current-box",
            children: e("svg", {
                width: "26",
                height: "40",
                xmlns: "http://www.w3.org/2000/svg",
                children: e("path", {
                    d: "M0 22.89L17.013 0v16.855H26L8.86 40V22.89z",
                    fill: a ? "#ffffff" : "#20A75E"
                })
            })
        })]
    })
}

function he() {
    H.trackEvent("recharge_request"), E().then(() => {
        t.forceUpdate(), k.close()
    }), de()
}

function ue() {
    const a = h(),
        n = {
            vipLevel: t.data.vipLevel,
            turnover: Number(t.data.lastBetUsd.length > 8 ? t.data.lastBetUsd.slice(0, 8) : t.data.lastBetUsd)
        },
        s = t.conditions;
    t.lastSyncTime;
    const r = t.conditionsOn;
    return e("div", {
        className: me,
        children: c("div", {
            className: "recharge-wrap",
            children: [e(S, {
                name: "Help",
                className: "question",
                onClick: A
            }), c("div", {
                className: "fg",
                children: [e(x, {}), e(oe, {
                    isRech: r
                }), c("div", {
                    className: "title-box",
                    children: [e("div", {
                        className: "title",
                        children: a(r ? "page.recharge.title.ready" : "page.recharge.title.wait")
                    }), e("div", {
                        className: "title-sub",
                        children: a(r ? "page.recharge.desc.ready" : "page.recharge.desc.wait")
                    })]
                })]
            }), c("div", {
                className: "bg",
                children: [c("div", {
                    className: "conditions",
                    children: [c("div", {
                        className: n.vipLevel >= s.vipLevel ? "ready item" : "item",
                        children: [e("div", {
                            className: "icon-status"
                        }), e("div", {
                            className: "desc",
                            children: e(f, {
                                k: "page.recharge.conditions.vip",
                                children: s.vipLevel
                            })
                        }), e("div", {
                            className: "current",
                            children: c("div", {
                                className: "vip",
                                children: [a("page.recharge.vip"), " ", n.vipLevel]
                            })
                        })]
                    }), c("div", {
                        className: n.turnover >= s.turnover ? "ready item" : "item",
                        children: [e("div", {
                            className: "icon-status"
                        }), e("div", {
                            className: "desc",
                            children: e(f, {
                                k: "page.recharge.conditions.wager",
                                children: s.turnover
                            })
                        }), e("div", {
                            className: "current",
                            children: e("div", {
                                className: "amount",
                                children: n.turnover > s.turnover ? s.turnover + "+" : n.turnover.toFixed(2)
                            })
                        })]
                    })]
                }), e("div", {
                    className: "countdown-box flex-center",
                    children: a("page.recharge.apply.countdown")
                }), e(w, {
                    className: "claim",
                    disabled: !r,
                    type: "conic",
                    onClick: he,
                    children: a("page.recharge.request")
                })]
            })]
        })
    })
}
var ge = u(ue);
N({
    cl1: ["linear-gradient(151deg, #007c6f 2%, #183333 23%, #1e2024 33%)", "linear-gradient(151deg, #6dafac 4%, #90c0c0 11%, #e9eaf2 29%)"],
    cl2: ["#c5c5c5", "#fff"],
    cl3: ["#f5f6f7", "#31373d"],
    cl4: [i("#99a4b0", .6), i("#5f6975", .8)],
    cl5: [i("#2d3035", .5), "#f5f6fa"],
    cl6: ["#fff", "#31373d"],
    cl7: ["#2d3035", "#dadde6"],
    cl8: [i("#6b7180", .6), i("#6b7180", .4)],
    cl9: ["#f5f6f7", "#fff"],
    gd1: [`linear-gradient(to right, ${i("#007c6f",.47)}, ${i("#2d3035",.5)} 30%, #2d3035)`, `linear-gradient(to right, ${i("#62c0b7",.2)}, ${i("#f5f6fa",.2)} 30%, #f5f6fa)`]
});
const me = "a1cogifu";

function C(a) {
    let n = Math.floor(a / 1e3 % 60),
        s = Math.floor(a / 1e3 / 60 % 60),
        r = Math.floor(a / 1e3 / 60 / 60 % 24);
    return n < 10 && (n = "0" + n), s < 10 && (s = "0" + s), r < 10 && (r = "0" + r), {
        sec: n,
        min: s,
        hour: r
    }
}

function pe({
    ms: a
}) {
    const n = h(),
        [s, r] = d.exports.useState(C(a)),
        l = F();
    return d.exports.useEffect(() => {
        let o = a,
            m = setInterval(() => {
                t.isRech || (o = Math.max(o - 1e3, 0), o === 0 && (clearInterval(m), t.forceUpdate()), l() && r(C(o)))
            }, 1e3);
        return () => {
            clearInterval(m)
        }
    }, [a]), e("div", {
        className: ve,
        children: t.isRech ? e("div", {
            className: "ready",
            children: n("page.recharge.recharge_ready")
        }) : c(U, {
            children: [e("div", {
                className: "title",
                children: n("page.recharge.recharge_in")
            }), c("div", {
                className: "flex",
                children: [c("div", {
                    className: "item",
                    children: [e("div", {
                        className: "desc",
                        children: "Hours"
                    }), e("div", {
                        className: "time",
                        children: s.hour
                    })]
                }), c("div", {
                    className: "item spec",
                    children: [e("div", {
                        className: "desc",
                        children: "Minutes"
                    }), e("div", {
                        className: "time",
                        children: s.min
                    })]
                }), c("div", {
                    className: "item",
                    children: [e("div", {
                        className: "desc",
                        children: "Seconds"
                    }), e("div", {
                        className: "time",
                        children: s.sec
                    })]
                })]
            })]
        })
    })
}
N({
    cl1: [i("#686e78", .6), i("#5f6975", .8)],
    cl2: ["#fff", "#31373d"],
    cl3: ["transparent", i("#5f6975", .3)],
    cl4: [i("#17181b", .45), `linear-gradient(to bottom, #dadde6, #dadde6 50%, ${i("#5f6975",.57)} 50%, ${i("#5f6975",0)})`]
});
const ve = "c1xpoiva";

function fe() {
    const {
        nextReceiveTime: a
    } = t.data;
    return c("div", {
        className: ye,
        children: [e(we, {}), e(pe, {
            ms: Math.max(new Date(a).getTime() - Date.now(), 0)
        })]
    })
}
var Ne = u(fe);
const we = u(function() {
        const {
            percent: n,
            isRech: s
        } = t, {
            intervalTime: r
        } = t.data, l = r > 60 * 6e4 ? r / (60 * 6e4) : r / 6e4, o = Math.floor(l * n / 100);
        return c("div", {
            className: "status-box",
            children: [e(be, {}), c("div", {
                className: `current-box ${s?"ready":""}`,
                children: [e("div", {
                    className: "current",
                    children: o
                }), c("div", {
                    className: "percent",
                    children: [Math.floor(n), "%"]
                })]
            })]
        })
    }),
    be = u(function() {
        const {
            percent: n
        } = t, s = d.exports.useRef(null);
        return d.exports.useEffect(() => {
            var r;
            (r = s.current) == null || r.play(0)
        }, []), e(b, {
            className: "charging",
            ref: s,
            path: D.rechargeLottile,
            loop: !0,
            style: {
                backgroundImage: `url(${B(n)})`
            }
        })
    }),
    ye = "w9devxj";

function xe() {
    const a = h();

    function n(r) {
        y.confirm(c("div", {
            className: `${Le} message`,
            children: [e("div", {
                className: "title",
                children: a("page.recharge.interval.title")
            }), e("div", {
                className: "content",
                children: a("page.recharge.interval.desc")
            })]
        })).then(l => {
            l && q(r).then(() => {
                t.currentInterval = r, t.forceUpdate()
            })
        })
    }

    function s(r) {
        return c("div", {
            className: "flex",
            children: [r.disabled && e("div", {
                className: "icon"
            }), r.label]
        })
    }
    return e("div", {
        className: Ce,
        children: e(I, {
            options: t.intervalOptions,
            value: t.currentInterval,
            onChange: n,
            renderOption: s,
            className: "interval-select"
        })
    })
}
var _e = u(xe);
const Le = "c1c62uq1",
    Ce = "i1h7yuwk";

function ke() {
    const a = h(),
        n = t.data.rewards.map(r => ({
            label: W.getAlias(r.currencyName),
            value: r.currencyName,
            amount: +r.amount
        }));

    function s(r) {
        t.currencyName = r
    }
    return c("div", {
        className: $e,
        children: [e("div", {
            className: "type",
            children: a("common.currency")
        }), e(I, {
            className: "recharge-currency",
            value: t.currencyName,
            options: n,
            onChange: s,
            disabled: t.isAnimation,
            top: !0,
            renderLabel: r => e(_, {
                name: r.value,
                disableLocal: !0,
                amount: r.amount,
                icon: !0
            }),
            renderOption: r => e(_, {
                name: r.value,
                disableLocal: !0,
                amount: r.amount,
                icon: !0
            })
        })]
    })
}
var Re = u(ke);
const $e = "c1veba8h";
const Se = {
    scale: {
        list: [{
            value: 1,
            time: 0
        }, {
            value: 1.5,
            time: 1
        }]
    },
    color: {
        start: "#892aff",
        end: "#892aff"
    },
    maxParticles: 8,
    spawnRect: {
        w: 414,
        h: 580
    }
};

function Ie({
    amount: a,
    currencyName: n
}) {
    const s = h(),
        r = d.exports.useRef(null);
    return d.exports.useEffect(() => {
        setTimeout(() => {
            var l;
            (l = r.current) == null || l.play(0)
        }, 300)
    }, []), c("div", {
        className: `result-pop ${We}`,
        children: [e(b, {
            className: "lottie-wrap",
            ref: r,
            path: D.rechargeReward
        }), e(x, {
            config: Se
        }), c("div", {
            className: "front",
            children: [e("div", {
                className: "recharge",
                children: s("page.recharge.recharge")
            }), e("div", {
                className: "text",
                children: s("page.recharge.result")
            }), c("div", {
                className: "result-value flex-center",
                children: [e("div", {
                    className: "amount",
                    children: a
                }), e("div", {
                    className: "currency-name",
                    children: W.getAlias(n)
                })]
            }), e(w, {
                onClick: () => y.close(),
                type: "conic",
                children: s("common.actions.confirm")
            })]
        })]
    })
}
const We = "r1bii1g0";
var Ae = "/assets/recharge_success.b0813da2.mp3";
const Be = new P({
    src: Ae
});

function De() {
    if (g.settings.soundEffectEnable) try {
        Be.play()
    } catch (a) {}
}

function He() {
    const a = h(),
        {
            isAnimation: n,
            isRech: s,
            data: r
        } = t,
        [l, o] = d.exports.useState(!1);

    function m() {
        const p = t.data.rewards.find(v => v.currencyName === t.currencyName);
        !p || (o(!0), O("login").then(v => z(t.currencyName, v)).then(() => {
            o(!1), t.forceUpdate(), De(), y.push(e(Ie, {
                amount: p.amount,
                currencyName: p.currencyName
            }))
        }).catch(() => {
            o(!1)
        }))
    }
    return d.exports.useEffect(() => () => {
        t.isAnimation && (t.isAnimation = !1)
    }, []), e("div", {
        className: Me,
        children: c("div", {
            className: "recharge-wrap",
            children: [e(j, {
                children: e(_e, {})
            }), e(S, {
                name: "Help",
                className: "question",
                onClick: A
            }), c("div", {
                className: "fg",
                children: [e(x, {}), e(Ne, {})]
            }), c("div", {
                className: "bg",
                children: [c("div", {
                    className: "details",
                    children: [e(Re, {}), c("div", {
                        className: "flex-center",
                        children: [c("div", {
                            className: "item br",
                            children: [e("div", {
                                className: "bold",
                                children: e(L, {
                                    amount: Number(r.receiveUsd)
                                })
                            }), e("div", {
                                children: a("page.recharge.total_claimed")
                            })]
                        }), c("div", {
                            className: "item",
                            children: [e("div", {
                                className: "bold",
                                children: e(L, {
                                    amount: Number(r.nextBetUsd)
                                })
                            }), e("div", {
                                children: a("page.recharge.new_wagered")
                            })]
                        })]
                    }), e("div", {
                        className: "time",
                        children: new Date(r.endTime).toLocaleString()
                    }), e("div", {
                        children: a("page.recharge.expires")
                    })]
                }), e(w, {
                    className: "claim",
                    loading: l,
                    onClick: m,
                    type: "conic",
                    disabled: !s || n || l,
                    children: a("page.recharge.claim_recharge")
                }), r.viphostUserId !== 0 && e("div", {
                    className: "contact",
                    children: e(f, {
                        k: "page.recharge.contact_host",
                        children: e(T, {
                            to: `/chat/${r.viphostUserId}${r.isSendBonus?"?phrase=claim_weekly":""}`,
                            children: a("common.viphost")
                        })
                    })
                })]
            })]
        })
    })
}
var Ee = u(He);
N({
    gd1: ["linear-gradient(151deg, #007c6f 2%, #183333 23%, #1e2024 33%)", "linear-gradient(151deg, #6dafac 4%, #90c0c0 11%, #e9eaf2 29%)"],
    cl1: ["#2d3035", "transparent"],
    cl2: [i("#2d3035", .5), i("#dadde6", .6)],
    cl3: [i("#99a4b0", .6), i("#5f6975", .8)],
    cl4: ["#fff", "#31373d"],
    cl5: [i("#6b727c", .3), i("#5f697", .13)],
    cl6: ["#70b317", "#7BC514"],
    cl7: [i("#6b7180", .6), i("#6b7180", .4)],
    cl8: ["#f5f6f7", "#fff"]
});
const Me = "h1sznhdr";
const Te = u(function() {
        const n = h();
        return d.exports.useEffect(() => () => {
            t.destory()
        }, []), e(R, {
            title: n("page.recharge.recharge"),
            size: [464, 830],
            nostyle: !0,
            children: e($, {
                className: Fe,
                children: e(V, {
                    pms: t.init(),
                    children: () => t.data.status < 2 ? e(ge, {}) : e(Ee, {})
                })
            })
        })
    }),
    Fe = "rnkdh93";
export {
    Te as
    default
};
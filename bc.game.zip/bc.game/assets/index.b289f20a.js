var V = Object.defineProperty,
    W = Object.defineProperties;
var O = Object.getOwnPropertyDescriptors;
var w = Object.getOwnPropertySymbols;
var U = Object.prototype.hasOwnProperty,
    F = Object.prototype.propertyIsEnumerable;
var k = (a, t, s) => t in a ? V(a, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : a[t] = s,
    A = (a, t) => {
        for (var s in t || (t = {})) U.call(t, s) && k(a, s, t[s]);
        if (w)
            for (var s of w(t)) F.call(t, s) && k(a, s, t[s]);
        return a
    },
    I = (a, t) => W(a, O(t));
import {
    a5 as R,
    r as m,
    G as J,
    j as c,
    l as B,
    a as e,
    F as G,
    t as y,
    q as d,
    o as D,
    du as x,
    u as P,
    $ as j,
    de as g,
    s as N,
    ah as q,
    a4 as K,
    dD as Q,
    eO as X,
    dE as Y,
    dy as Z,
    dJ as T,
    ba as ee,
    bb as S,
    bc as ae,
    df as te,
    A as f,
    an as se,
    ee as h,
    ef as p,
    am as $,
    b as _
} from "./index.28e31dff.js";
import {
    S as re
} from "./SlotsILayout.a8936350.js";
const ne = R.memo(({
    pms: a,
    children: t,
    className: s,
    size: r
}) => {
    const [n, i] = m.exports.useState({
        loading: !0,
        data: null
    });
    return m.exports.useEffect(() => {
        if (a) {
            let l = !0;
            return i({
                loading: !0,
                data: null
            }), a.then(o => {
                l && i({
                    loading: !1,
                    data: o
                })
            }).catch(J), () => {
                l = !1
            }
        }
    }, [a]), n.loading ? c("div", {
        className: B(ce, s),
        children: [e("div", {
            className: "head"
        }), Array(r).fill(0).map((l, o) => e("div", {
            className: "tr-itrm"
        }, o)), e("div", {
            className: "pages"
        })]
    }) : e(G, {
        children: t ? t(n.data) : null
    })
});
y({
    cl1: ["#555966", d("#e9eaf2", .6)]
});
const ce = "s10pw654";

function C(a) {
    if (!a) return 0;
    let t = a.split(","),
        s = 0;
    return t.forEach(r => {
        let n = Number(r) & 15;
        s += n >= 10 ? 0 : n
    }), s % 10
}

function z(a) {
    return j.post("/baccarat/history/", a)
}

function le(a) {
    return `https://bcgame-project.github.io/verify/baccarat.html?hash=${a.hash}`
}

function ie(a) {
    let [t, s] = a.split(";");
    return `${N.isMobile?"":"Banker: "}${C(t)},${N.isMobile?"":" Player: "}${C(s)}`
}

function oe() {
    const a = x(),
        [t, s] = m.exports.useState({
            page: 1,
            pageSize: a.historyPageSize
        }),
        r = m.exports.useMemo(() => z(t), [t.page]);
    return e("div", {
        className: ue,
        children: e(ne, {
            size: a.historyPageSize,
            pms: r,
            children: n => n.list.length ? c(G, {
                children: [e(me, {
                    list: n.list,
                    params: t
                }), e(q, {
                    page: n.page,
                    total: n.total,
                    limit: n.pageSize,
                    onChange: i => s(I(A({}, t), {
                        page: i
                    }))
                })]
            }) : e(K, {})
        })
    })
}
const me = D(function(t) {
    const s = x(),
        [r, n] = m.exports.useState(t.list),
        i = P();
    return m.exports.useEffect(() => {
        let l = !1,
            o = setInterval(() => {
                l || z(t.params).then(u => {
                    l || n(u.list)
                }).catch(u => {
                    console.error(u)
                })
            }, 2e4);
        return () => {
            l = !0, window.clearInterval(o)
        }
    }, []), c("div", {
        className: he,
        children: [c("div", {
            className: "head flex",
            children: [e("div", {
                className: "col",
                children: i("common.game_number")
            }), e("div", {
                className: "col",
                children: i("common.result")
            }), e("div", {
                className: "col-2",
                children: i("common.hash")
            })]
        }), e("ul", {
            className: "list",
            children: r.map(l => c("li", {
                className: "item flex",
                children: [e("div", {
                    className: "col hover",
                    onClick: () => g.openAllPlayers({
                        gameName: s.name,
                        gameId: l.gameId
                    }),
                    children: l.gameId
                }), e("div", {
                    className: "col",
                    children: e("div", {
                        children: ie(l.resultCards)
                    })
                }), c("div", {
                    className: "seed-box col-2",
                    children: [e("input", {
                        type: "text",
                        className: "seed",
                        value: l.hash,
                        readOnly: !0
                    }), e("a", {
                        href: le(l),
                        target: "_blank",
                        className: "cl-primary",
                        children: i("common.verify")
                    })]
                })]
            }, l.gameId))
        })]
    })
});
var de = D(oe);
y({
    cl1: [d("#2d3035", .6), d("#dadde6", .6)],
    cl2: [d("#2d3035", .4), d("#dadde6", .3)]
});
const ue = "h15zxnpy";
y({
    cl1: ["#99a4b0", "#5f6975"],
    cl2: ["#2d3035", d("#e9eaf2", .6)],
    cl3: [d("#99a4b0", .6), "#5f6975"]
});
const he = "l1fjh707",
    pe = R.memo(() => {
        const a = P(),
            t = x(),
            s = m.exports.useRef(null);
        return m.exports.useEffect(() => {
            const r = s.current;
            if (r) {
                const n = i => {
                    t.betRecent = i
                };
                return r.on("recent-result", n), () => {
                    r.off("recent-result", n)
                }
            }
        }, []), e(re, {
            src: t.gameUrl,
            ref: s,
            banner: t.gameInfo.cover,
            actions: [e(Q, {}), e(X, {}), e(Y, {
                list: [{
                    title: a("common.max_profits"),
                    node: e(Z, {
                        game: t,
                        title: a("common.max_profits")
                    })
                }]
            })],
            tabs: [{
                label: a("common.my_bet"),
                value: g.Mybet
            }, {
                label: a("common.history"),
                value: de
            }]
        })
    });
class be extends T {
    constructor() {
        super({
            name: "Baccarat",
            namespace: "/g/unknown"
        }, pe), this.disableAutoConnect = !0, this.historyPageSize = 20, this.betRecent = [], this.timestemp = Date.now(), ee(this, {
            betRecent: S,
            timestemp: S,
            gameUrl: ae
        }), this.getJackPot()
    }
    get gameUrl() {
        return N.isDev ? `http://baccarat.bc.com?t=${this.timestemp}` : `//baccarat.${N.domain}?t=${this.timestemp}`
    }
    getJackPot() {
        j.get("/baccarat/currency/").then(t => {
            if (Array.isArray(t)) {
                let s = {};
                t.forEach(r => {
                    s[r.currencyName] = {
                        currencyName: r.currencyName,
                        maxProfitAmount: Number(r.maxProfit),
                        jackpotAmount: 0,
                        maxBetAmount: Number(r.maxBet),
                        minBetAmount: Number(r.minBet)
                    }
                }), this.jackpot = s
            }
        })
    }
}
const E = new be;
var Pe = E;
window.btg = E;

function L(a) {
    if (!a) return 0;
    let t = a.split(","),
        s = 0;
    return t.forEach(r => {
        let n = Number(r) & 15;
        s += n >= 10 ? 0 : n
    }), s % 10
}
var H = (a => (a[a.banker = 0] = "banker", a[a.player = 1] = "player", a[a.tie = 2] = "tie", a[a.bankerPair = 3] = "bankerPair", a[a.playerPair = 4] = "playerPair", a))(H || {});
const ve = g.withMultipleDetail(a => {
    const t = P(),
        {
            gv: s,
            gb: r
        } = a,
        [, n, i] = r.extend.resultValue.split(":"),
        [l, o] = n ? n.split(";") : [],
        u = s[0].bets[0].extend.betValue,
        M = i && i.split(",")[H[u]],
        b = l ? l.split(",") : [],
        v = o ? o.split(",") : [];
    return c("div", {
        className: fe,
        children: [c(te, {
            className: "rt_items",
            children: [c("div", {
                className: "item-wrap",
                children: [c("div", {
                    className: "item-num",
                    children: [e(f, {
                        className: "result",
                        name: "Result"
                    }), e("span", {
                        children: t("common.result")
                    })]
                }), c("div", {
                    className: "item-desc",
                    children: ["Banker:", L(l), " Player:", L(o)]
                })]
            }), c("div", {
                className: "item-wrap",
                children: [c("div", {
                    className: "item-num",
                    children: [e(f, {
                        className: "bettype",
                        name: "Bet"
                    }), e("span", {
                        children: t("common.bet")
                    })]
                }), e("div", {
                    className: "item-desc",
                    children: e("span", {
                        className: "mthan",
                        children: u
                    })
                })]
            }), c("div", {
                className: "item-wrap",
                children: [c("div", {
                    className: "item-num",
                    children: [e(f, {
                        className: "chance",
                        name: "Chance"
                    }), e("span", {
                        children: t("common.chance")
                    })]
                }), e("div", {
                    className: "item-desc",
                    children: M
                })]
            })]
        }), e(se, {
            label: "Cards",
            children: c("div", {
                className: B(ge, "card-result"),
                children: [c("div", {
                    className: "banker",
                    children: [e("div", {
                        className: "card-box",
                        children: e(h, {
                            active: !0,
                            card: new p(b[0])
                        })
                    }), e("div", {
                        className: "card-box",
                        children: e(h, {
                            active: !0,
                            card: new p(b[1])
                        })
                    }), e("div", {
                        className: "card-box",
                        children: b[2] && e(h, {
                            active: !0,
                            card: new p(b[2])
                        })
                    })]
                }), c("div", {
                    className: "player",
                    children: [e("div", {
                        className: "card-box",
                        children: e(h, {
                            active: !0,
                            card: new p(v[0])
                        })
                    }), e("div", {
                        className: "card-box",
                        children: e(h, {
                            active: !0,
                            card: new p(v[1])
                        })
                    }), e("div", {
                        className: "card-box",
                        children: v[2] && e(h, {
                            active: !0,
                            card: new p(v[2])
                        })
                    })]
                })]
            })
        }), e($, {
            label: t("common.game_number"),
            value: r.gameId,
            readOnly: !0
        }), e($, {
            label: t("common.hash"),
            value: r.extend.hash,
            readOnly: !0
        }), c("div", {
            className: "flex btns",
            children: [c(_, {
                className: "all",
                type: "gray",
                onClick: () => g.openAllPlayers({
                    gameName: r.gameName,
                    gameId: r.gameId
                }),
                children: [e("span", {
                    children: t("common.all_players")
                }), e(f, {
                    name: "Arrow"
                })]
            }), e(_, {
                type: "conic",
                onClick: () => {
                    window.open(`https://bcgame-project.github.io/verify/baccarat.html?hash=${r.extend.hash}`)
                },
                children: t("common.verify")
            })]
        })]
    })
});
var we = ve;
const fe = "bfvhi2r",
    ge = "cmxqz01";
export {
    we as Detail, Pe as Game
};
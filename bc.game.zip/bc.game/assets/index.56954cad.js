var Z = Object.defineProperty;
var K = (s, n, t) => n in s ? Z(s, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: t
}) : s[n] = t;
var c = (s, n, t) => (K(s, typeof n != "symbol" ? n + "" : n, t), t);
import {
    a5 as j,
    u as d,
    a as e,
    D as R,
    dx as F,
    j as i,
    dy as Q,
    dz as X,
    o as C,
    du as f,
    r as h,
    y as g,
    Y as G,
    A as k,
    t as P,
    q as w,
    P as ee,
    aO as W,
    dk as te,
    dl as ne,
    F as ae,
    dj as se,
    s as _,
    b as L,
    e9 as ie,
    G as $,
    J as M,
    ea as oe,
    dG as le,
    dY as re,
    eb as ce,
    dC as he,
    dD as de,
    dZ as ue,
    dE as me,
    dp as x,
    bN as q,
    d_ as be,
    ba as ge,
    bb as N,
    bc as pe,
    dR as fe,
    aH as ye,
    df as ve
} from "./index.28e31dff.js";
import {
    s as H
} from "./index.dd8128e8.js";
import {
    G as u
} from "./index.06a59a68.js";
const we = j.memo(({
        game: s
    }) => {
        const n = d();
        return e(R, {
            title: n("common.game_intro"),
            children: e(F, {
                children: i("div", {
                    className: "item",
                    children: [e("h2", {
                        children: " What Is Classic Dice? "
                    }), e("div", {
                        className: "help-content",
                        children: s.gameInfo.detail.split(`
`).map((t, a) => e("p", {
                            children: `${t}`
                        }, a.toString()))
                    }), e("h2", {
                        children: "How to play Classic Dice? "
                    }), i("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "1.Only roll outcomes that hit the green area are winners."
                        }), e("p", {
                            children: "2.Players are prohibited from using their own dice. "
                        }), e("p", {
                            children: "3.Use of script is optional and as such players must assume full responsibility for any attendant risks. we will not be held liable in this regard."
                        })]
                    }), e("h2", {
                        children: "What is the Classic Dice return rate? "
                    }), e("div", {
                        className: "help-content",
                        children: "Only 1% HouseEdge."
                    }), e("h2", {
                        children: "Auto Mode Operation Instructions"
                    }), i("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "[ ON WIN ] when you win, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                        }), i("p", {
                            children: ["[ ON LOSE ] when you lose, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'.", " "]
                        }), e("p", {
                            children: "[ STOP ON WIN ] Once the amount winned (from start to this bet) is bigger/equal than _(your set)_ , auto will stop;"
                        }), e("p", {
                            children: "[ STOP ON LOSS ] Once the amount lost (from start to next bet) may be bigger/equal than _(your set)_ , auto will stop."
                        })]
                    })]
                })
            })
        })
    }),
    Ce = function({
        game: n
    }) {
        const t = d();
        return e(R, {
            title: t("common.bankroll"),
            children: e(Q, {
                game: n,
                children: i("div", {
                    className: "item",
                    children: [e("h2", {
                        children: "What is the bankroll?"
                    }), i("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                        }), e("p", {
                            children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                        }), e("p", {
                            children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                        }), e("p", {
                            onClick: () => X(n, 1),
                            className: "cl-primary pointer",
                            children: "Read more about bankrollers."
                        })]
                    }), e("h2", {
                        children: "How does the pool of funds operate? "
                    }), i("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                        }), i("p", {
                            children: [e("b", {
                                className: "cl-primary",
                                children: "The house edge is 1%."
                            }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                        }), e("p", {
                            children: "Payouts made to the winning players will be deducted from the bankroll."
                        })]
                    }), e("h2", {
                        children: "How does leverage investment work?"
                    }), i("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                        }), e("p", {
                            children: "Hint: You can also use this feature as an Off-Site investment."
                        }), e("p", {
                            children: "Let's make an example:"
                        }), e("p", {
                            children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                        })]
                    }), e("h2", {
                        children: "What is the bankroller dilution fee?"
                    }), i("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                        }), e("p", {
                            children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                        }), e("p", {
                            children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                        }), e("p", {
                            children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                        })]
                    })]
                })
            })
        })
    };
var Ne = "/assets/banner_a1.35d763d7.png",
    ke = "/assets/banner_a2.39a95092.png",
    Be = "/assets/banner_a3.44762be3.png",
    _e = "/assets/icon.954f481f.png",
    xe = "/assets/range.a915fc2b.png",
    He = "/assets/win.449738f6.png",
    Se = "/assets/win_w.62dc31a7.png",
    Te = "/assets/dice.1007262a.png",
    Ie = "/assets/tip.1ae46146.png",
    Ge = "/assets/tip_w.a52237b5.png",
    Re = "/assets/dice.8796ef26.png",
    De = {
        banner_a1: Ne,
        banner_a2: ke,
        banner_a3: Be,
        icon: _e,
        range: xe,
        win: He,
        win_w: Se,
        dice: Te,
        tip: Ie,
        tip_w: Ge,
        dice_loading: Re
    };
const E = s => Number(new g(99).div(s).toFixed(2)),
    B = s => Math.floor(new g(99).div(s).toNumber() * 1e4) / 1e4,
    Ae = C(function() {
        const n = f(),
            t = d(),
            [a, l] = h.exports.useState(B(n.betChance)),
            r = o => {
                let T = E(o),
                    y = B(T);
                l(y), n.betChance = E(y)
            };
        return h.exports.useEffect(() => {
            l(B(n.betChance))
        }, [n.betChance]), i("div", {
            className: Oe,
            children: [e(G, {
                label: t("common.payout"),
                size: "small",
                value: a,
                onChange: o => r(o),
                precision: 4,
                disabled: n.isBetting,
                min: 1.0102,
                max: 9900,
                children: e("span", {
                    className: "right-info",
                    children: "x"
                })
            }), e(G, {
                label: n.isHigh ? t("game.dice.roll_over") : t("game.dice.roll_under"),
                size: "small",
                className: "roll-switch",
                value: n.isHigh ? 100 - n.betChance : n.betChance,
                onChange: () => {},
                onClick: () => {
                    n.isBetting || (n.isHigh = !n.isHigh)
                },
                max: 99.99,
                min: .01,
                disabled: n.isBetting,
                precision: 2,
                readOnly: !0,
                children: e("span", {
                    className: "right-info",
                    children: e(k, {
                        name: "Exchange"
                    })
                })
            }), e(G, {
                label: t("game.dice.winChance"),
                size: "small",
                value: n.betChance,
                onChange: o => n.betChance = o,
                max: 98,
                disabled: n.isBetting,
                min: .01,
                precision: 2,
                className: "win-change",
                children: i("div", {
                    className: "right-info",
                    children: [e("span", {
                        className: "right-percent",
                        children: "%"
                    }), e("button", {
                        disabled: n.isBetting,
                        onClick: () => n.betChance = .01,
                        className: "amount-scale",
                        children: "Min"
                    }), e("button", {
                        disabled: n.isBetting,
                        onClick: () => {
                            const o = n.betChance - 5;
                            o < .01 ? n.betChance = .01 : n.betChance = o
                        },
                        className: "amount-scale",
                        children: "-5"
                    }), e("button", {
                        disabled: n.isBetting,
                        onClick: () => {
                            const o = n.betChance + 5;
                            o > 98 ? n.betChance = 98 : n.betChance = o
                        },
                        className: "amount-scale",
                        children: "+5"
                    }), e("button", {
                        disabled: n.isBetting,
                        onClick: () => n.betChance = 98,
                        className: "amount-scale",
                        children: "Max"
                    })]
                })
            })]
        })
    });
P({
    cl1: [w("#31343c", .4), "#f5f6fa"],
    cl2: ["none", "0 1px 9px 0 rgba(0, 0, 0, 0.12)"],
    cl3: ["rgba(49, 52, 60, 0.5)", "#fff"],
    cl4: ["#99a4b0", "#5f6975"],
    cl5: ["#31343c", w("#dadde6", .4)],
    cl6: ["#3c404a", w("#dadde6", .2)]
});
const Oe = "c1tqq5ch";
const We = C(function() {
    const n = ee(),
        t = f(),
        [a, l] = h.exports.useState(!1),
        [r, o] = h.exports.useState(!1),
        [T, y] = h.exports.useState(!0),
        I = h.exports.useRef(),
        m = h.exports.useRef(!0),
        v = t.isHigh ? new g(100).sub(t.betChance).toNumber() : t.betChance,
        D = h.exports.useRef(t.gameResult / 100);
    h.exports.useEffect(() => {
        y(!1);
        const b = {
                val: D.current
            },
            O = m.current ? 50 : t.gameResult / 100,
            J = t.settings.fastEnable ? .2 : .4;
        return !m.current && !t.settings.fastEnable && t.sounds.playSound("moveSound"), W.to(b, J, {
            val: O,
            onUpdate: () => {
                I.current && (I.current.innerHTML = b.val.toFixed(2))
            },
            onComplete: () => {
                m.current || (n() && y(!0), t.gameIsWin && t.sounds.playSound("winSound"))
            }
        }), () => {
            D.current = O, m.current = !1, W.killTweensOf(b)
        }
    }, [t.gameResult]);
    const z = "dice_num " + (t.gameIsWin ? "dice_win " : "") + (m.current ? "" : t.gameIsWin ? "win" : "lose") + (t.settings.fastEnable ? " fast" : ""),
        U = "dice_png" + (T ? " dice-animate" : ""),
        A = m.current ? 50 : t.gameResult / 100;
    return i(te, {
        className: Me,
        children: [e(ne, {}), i("div", {
            className: "game-slider " + (t.settings.fastEnable ? "turbo-bet" : ""),
            children: [i("div", {
                className: "slider-wrapper",
                children: [i("div", {
                    className: "slider-handles",
                    children: [a && e("div", {
                        className: "slider-tip",
                        style: {
                            left: `${v}%`
                        },
                        children: v
                    }), e("input", {
                        type: "range",
                        min: 2,
                        max: 98,
                        step: 1,
                        disabled: t.isBetting,
                        className: "drag-block " + (r ? "dragging" : ""),
                        onMouseEnter: () => l(!0),
                        onMouseLeave: () => l(!1),
                        onMouseDown: () => o(!0),
                        onMouseUp: () => o(!1),
                        onTouchStart: () => l(!0),
                        onTouchEnd: () => l(!1),
                        value: v,
                        onChange: b => {
                            t.sounds.playSound("rangeSound"), t.betChance = t.isHigh ? 100 - Number(b.target.value) : Number(b.target.value)
                        }
                    }), i("div", {
                        className: "slider-track " + (t.gameIsWin ? "slider-win" : ""),
                        style: {
                            transform: `translate(${A}%, 0px)`
                        },
                        children: [e("div", {
                            ref: I,
                            className: z
                        }), e("div", {
                            className: U,
                            children: e("img", {
                                alt: "dice.png",
                                src: De.dice
                            })
                        })]
                    }), i("div", {
                        className: "slider-line ",
                        children: [e("div", {
                            className: t.isHigh ? "slide-lose" : "slide-win",
                            style: {
                                width: `${v}%`
                            }
                        }), e("div", {
                            className: t.isHigh ? "slide-win" : "slide-lose",
                            style: {
                                width: `${100-v}%`
                            }
                        }), e("div", {
                            className: "slider-sign",
                            style: {
                                transform: `translate(${A}%, 0px)`
                            },
                            children: e("div", {
                                className: "sign"
                            })
                        })]
                    })]
                }), i("div", {
                    className: "slider-mark",
                    children: [e("span", {
                        className: "mark",
                        children: "0"
                    }), e("span", {
                        className: "mark",
                        children: "25"
                    }), e("span", {
                        className: "mark",
                        children: "50"
                    }), e("span", {
                        className: "mark",
                        children: "75"
                    }), e("span", {
                        className: "mark",
                        children: "100"
                    })]
                })]
            }), e(Ae, {})]
        })]
    })
});
P({
    cl1: ["url(../assets/tip.png)", "url(../assets/tip_w.png)"],
    cl2: ["none", "0 4px 11px 0 rgba(0, 0, 0, 0.13)"],
    cl3: ["#fff", "#31373d"],
    cl4: ["#31343c", "#CED1D9"],
    cl5: ["#23262b", "#F5F6FA"],
    cl6: ["url(../assets/win.png)", "url(../assets/win_w.png)"],
    cl7: [w("#31343c", .4), "#f5f6fa"],
    cl8: ["#f5f6f7", "#f5f6fa"],
    cl9: [w("#31343c", .4), "#f5f6fa"]
});
const Me = "g17ie1or",
    Ee = C(() => {
        const s = f(),
            n = H.useSingleDetail();
        return i(ae, {
            children: [e(se, {
                list: s.myBets,
                keyof: "betId",
                onDetail: n,
                getResult: t => (t.gameValue / 100).toFixed(2)
            }), e(We, {})]
        })
    });
var je = C(function() {
    const n = f(),
        t = n.autoBet,
        a = d(),
        l = () => {
            t.isRunning ? t.stop() : t.start().catch($)
        },
        r = () => e(L, {
            className: "bet-button",
            size: "big",
            type: "conic",
            onClick: l,
            children: n.autoBet.isRunning ? a("common.stop_auto_bet") : a("common.start_auto_bet")
        });
    return i("div", {
        className: Fe,
        children: [_.isMobile && r(), e(u.CoinInput, {
            checkIncrease: !0
        }), e(u.TimesInput, {}), e(u.IncreaseInput, {}), e(u.StopInput, {}), e(u.IncreaseInput, {
            isLose: !0
        }), e(u.StopInput, {
            isLose: !0
        }), e(ie, {}), !_.isMobile && r()]
    })
});
const Fe = "a7epe3h";
const Pe = C(function() {
        const n = f(),
            t = d();
        M.dict[n.currencyName];
        const a = () => e(L, {
            className: "bet-button",
            type: "conic",
            disabled: n.isBetting,
            size: "big",
            onClick: () => n.handGameBet(),
            children: t("game.dice.rollnow")
        });
        return i("div", {
            className: Le,
            children: [_.isMobile && a(), e(u.CoinInput, {}), e(oe, {
                label: t("common.win_amount"),
                size: "small",
                currencyName: M.current,
                value: n.amount.mul(B(n.betChance)).toNumber(),
                onChange: () => {},
                disabled: !0
            }), !_.isMobile && a()]
        })
    }),
    Le = "mgoa7wi",
    $e = j.memo(() => {
        const s = f(),
            n = d(),
            t = [{
                title: n("common.game_intro"),
                node: e(we, {
                    game: s
                })
            }, {
                title: n("common.fairness"),
                node: "/classicdice_help/fairness"
            }, {
                title: n("common.bankroll"),
                node: e(Ce, {
                    game: s
                })
            }];
        return e(le, {
            manualControl: e(Pe, {}),
            autoControl: e(je, {}),
            gameView: e(Ee, {}),
            tabs: [{
                label: n("common.all_bet"),
                value: H.AllBet
            }, {
                label: n("common.my_bet"),
                value: H.MyBet
            }],
            actions: [e(re, {}), e(ce, {}), e(he, {}), e(de, {}), e(ue, {}), e(me, {
                list: t
            })]
        })
    }),
    S = x.Reader,
    V = x.Writer,
    p = x.roots.gameClassicDice || (x.roots.gameClassicDice = {});
p.BetChance = (() => {
    function s(n) {
        if (n)
            for (let t = Object.keys(n), a = 0; a < t.length; ++a) n[t[a]] != null && (this[t[a]] = n[t[a]])
    }
    return s.prototype.betChance = 0, s.prototype.isHigh = !1, s.encode = function(t, a) {
        return a || (a = V.create()), t.betChance != null && Object.hasOwnProperty.call(t, "betChance") && a.uint32(8).sint32(t.betChance), t.isHigh != null && Object.hasOwnProperty.call(t, "isHigh") && a.uint32(16).bool(t.isHigh), a
    }, s.decode = function(t, a) {
        t instanceof S || (t = S.create(t));
        let l = a === void 0 ? t.len : t.pos + a,
            r = new p.BetChance;
        for (; t.pos < l;) {
            let o = t.uint32();
            switch (o >>> 3) {
                case 1:
                    r.betChance = t.sint32();
                    break;
                case 2:
                    r.isHigh = t.bool();
                    break;
                default:
                    t.skipType(o & 7);
                    break
            }
        }
        return r
    }, s
})();
p.GameResult = (() => {
    function s(n) {
        if (n)
            for (let t = Object.keys(n), a = 0; a < t.length; ++a) n[t[a]] != null && (this[t[a]] = n[t[a]])
    }
    return s.prototype.gameResult = 0, s.encode = function(t, a) {
        return a || (a = V.create()), t.gameResult != null && Object.hasOwnProperty.call(t, "gameResult") && a.uint32(32).sint32(t.gameResult), a
    }, s.decode = function(t, a) {
        t instanceof S || (t = S.create(t));
        let l = a === void 0 ? t.len : t.pos + a,
            r = new p.GameResult;
        for (; t.pos < l;) {
            let o = t.uint32();
            switch (o >>> 3) {
                case 4:
                    r.gameResult = t.sint32();
                    break;
                default:
                    t.skipType(o & 7);
                    break
            }
        }
        return r
    }, s
})();
var qe = "/assets/range.e3b88736.mp3",
    Ve = "/assets/move.5b30624c.mp3",
    Ye = "/assets/win.ae4b0d6d.mp3";
const ze = q.decode(p.GameResult),
    Ue = {
        rangeSound: qe,
        moveSound: Ve,
        winSound: Ye
    };
class Je extends be {
    constructor() {
        super({
            name: "ClassicDice",
            namespace: "/g/cd",
            sounds: Ue,
            fairLink: "/classicdice_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/classicdice.html"
        }, $e);
        c(this, "betInterval", 350);
        c(this, "betStartTime", new Date().getTime());
        c(this, "isHigh", !1);
        c(this, "betChance", 50);
        c(this, "gameResult", 0);
        c(this, "gameIsWin", !1);
        c(this, "needDeduction", !1);
        c(this, "handGameBet", () => {
            this.isBetting || this.handleBet().catch($)
        });
        c(this, "onBetRequest", async t => {
            let a = await t;
            this.gameResult = a.gameValue, this.gameIsWin = a.odds > 0;
            let l = 400;
            if (this.settings.fastEnable) {
                const r = new Date().getTime() - this.betStartTime;
                l = r > this.betInterval ? 0 : this.betInterval - r
            }
            return await ye(l), a
        });
        c(this, "changeToggleWin", () => {
            this.isBetting || (this.isHigh = !this.isHigh)
        });
        c(this, "lowerTarget", () => {
            this.isBetting || (this.betChance = this.betChance - 1)
        });
        c(this, "higerTarget", () => {
            this.isBetting || (this.betChance = this.betChance + 1)
        });
        ge(this, {
            isHigh: N,
            betChance: N,
            gameResult: N,
            gameIsWin: N,
            maxProfit: pe
        }), this.addHotkey("q", this.changeToggleWin, "Toggle condition to win"), this.addHotkey("w", this.lowerTarget, "Lower the target"), this.addHotkey("e", this.higerTarget, "Higher the target"), fe(() => {
            this.autoBet.interval = this.settings.fastEnable ? 350 : 1500
        });
        const t = this.hotkeyList.find(a => a.key == "space");
        t && (t.handler = () => (this.controlIdx === 1 ? this.autoBet.isRunning ? this.autoBet.stop() : this.autoBet.start() : this.handGameBet(), !1)), this.on("betStart", () => {
            this.betStartTime = new Date().getTime(), this.sounds.playSound("rangeSound")
        })
    }
    get maxProfit() {
        return this.amount.mul(99).div(this.betChance).sub(this.amount)
    }
    gameValueDecoder(t) {
        return ze(t).gameResult
    }
    betValue() {
        return q.encode(p.BetChance)({
            betChance: new g(this.betChance).mul(100).toNumber(),
            isHigh: this.isHigh
        })
    }
}
const Y = new Je;
var Ze = Y;
window.cd = Y;

function at({
    bodyLock: s
}) {
    const n = d();
    return e(R, {
        title: n("common.fairness"),
        children: e(F, {
            bodyLock: s,
            children: i("div", {
                className: "item",
                children: [e("h2", {
                    children: "How are results calculated?"
                }), i("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "To get the results."
                    }), i("ul", {
                        children: [e("li", {
                            children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                        }), e("li", {
                            children: "Finally, we take 8 characters of the hash and convert it to an int32 value. Then we divide the converted value by 0x100000000, multiply it by 10001 and divide it by 100 so that the resulting number conforms to the constraints of the dice range."
                        })]
                    }), e("br", {}), e("p", {
                        children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                    }), e("p", {}), e("p", {
                        children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                    }), e("p", {
                        children: 'We put our "cards on the table." '
                    }), e("p", {
                        children: "Good luck!"
                    })]
                })]
            })
        })
    })
}
const Ke = (s, n, t) => {
        let a = `${Ze.config.validateLink}?s=${s}&c=${n}&n=${t}`;
        window.open(a)
    },
    Qe = H.withSingleDetail({
        onValidate: Ke,
        result: ({
            betLog: s
        }) => {
            const {
                high: n
            } = s.bv, t = d(), a = s.gv / 100, l = new g(s.bv.betChance).div(100).toNumber(), r = n ? new g(100).sub(l).toNumber() : l, o = l.toFixed(2);
            return i(ve, {
                className: "rt_items",
                children: [i("div", {
                    className: "item-wrap",
                    children: [i("div", {
                        className: "item-num",
                        children: [e(k, {
                            className: "result",
                            name: "Result"
                        }), t("common.result")]
                    }), e("div", {
                        className: "item-desc",
                        children: a
                    })]
                }), i("div", {
                    className: "item-wrap",
                    children: [i("div", {
                        className: "item-num",
                        children: [e(k, {
                            className: "bettype",
                            name: "Bet"
                        }), t("common.bet")]
                    }), e("div", {
                        className: "item-desc",
                        children: i("span", {
                            className: "mthan",
                            children: [n ? ">" : "<", r]
                        })
                    })]
                }), i("div", {
                    className: "item-wrap",
                    children: [i("div", {
                        className: "item-num",
                        children: [e(k, {
                            className: "chance",
                            name: "Chance"
                        }), t("common.chance")]
                    }), e("div", {
                        className: "item-desc",
                        children: o + "%"
                    })]
                })]
            })
        }
    });
var st = Qe;
export {
    st as Detail, at as Fairness, Ze as Game
};
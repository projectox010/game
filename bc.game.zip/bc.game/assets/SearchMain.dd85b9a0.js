import {
    a5 as h,
    r as N,
    j as c,
    a as e,
    A as S,
    fk as u,
    d,
    $ as v,
    fl as w,
    G as y,
    e as R,
    l as b,
    F as k,
    fm as C,
    S as I,
    bZ as L,
    bQ as p,
    bK as _
} from "./index.28e31dff.js";
const f = () => {
        const i = window.localStorage.getItem("game-search-list");
        return i ? i.split("**") : []
    },
    x = h.memo(function() {
        const [t, s] = N.exports.useState(f());
        if (!t || f.length < 0) return null;
        const r = l => {
                const n = [...t];
                n.splice(l, 1), s(n), window.localStorage.setItem("game-search-list", n.join("**"))
            },
            a = () => {
                s([]), window.localStorage.setItem("game-search-list", "")
            };
        return t.length === 0 ? null : c("div", {
            className: H,
            children: [c("div", {
                className: "history-top",
                children: [e("p", {
                    children: "Search History"
                }), t.length > 0 && e(S, {
                    name: "Delete",
                    onClick: a
                })]
            }), e("div", {
                className: "history-list-wrap",
                children: t.length > 0 ? t.map((l, n) => e(D, {
                    onDelete: () => {
                        r(n)
                    },
                    name: l
                }, n)) : e("p", {
                    className: "no",
                    children: "No Search history."
                })
            })]
        })
    }),
    D = h.memo(function({
        name: i,
        onDelete: t
    }) {
        const {
            isSearching: s,
            changeInputText: r,
            changeIsSearching: a,
            changeSearchResult: l,
            changePageInfo: n
        } = u(), g = async m => {
            await d.inited, !s && (a(!0), v.post("/home/search/game/", {
                keyword: m,
                page: 1,
                pageSize: 100,
                areaCode: d.areaCode
            }).then(o => {
                o && (l(o.list || []), a(!1), n({
                    page: o.page,
                    total: o.total
                }), o.list && o.list.length > 0 && w(m))
            }).catch(y))
        };
        return c("div", {
            className: W,
            onClick: () => {
                r(i), g(i)
            },
            children: [e("p", {
                children: i
            }), e("button", {
                onClick: m => {
                    m.stopPropagation(), t()
                },
                children: e(S, {
                    name: "Close"
                })
            })]
        })
    }),
    H = "h1ivtg2n",
    W = "h1n7lk5i";
const j = h.memo(function({
        resultItem: t,
        isLoading: s,
        closeFn: r
    }) {
        const a = R(),
            n = t.thumbnail.indexOf("http") >= 0 ? t.thumbnail : `http://img2.supersell.com${t.thumbnail}`;
        return c("div", {
            className: b(M, "result-item", s && "result-loading"),
            children: [e("div", {
                className: "result-top",
                onClick: () => {
                    r(), d.emit("game_click", "game_search"), a(t.gameUrl)
                },
                children: !s && e("img", {
                    alt: "logo",
                    src: n
                })
            }), c("div", {
                className: "result-bottom",
                children: [e("p", {
                    children: t.fullName
                }), e("p", {
                    className: "result-rtp",
                    children: s ? "" : c(k, {
                        children: ["RTP:", c("span", {
                            children: [t.rtpDes, "%"]
                        })]
                    })
                }), e("div", {
                    className: "more more-one",
                    children: e("span", {
                        children: t.categoryName
                    })
                }), e("div", {
                    className: "more more-two",
                    children: e("span", {
                        children: t.providerName
                    })
                })]
            })]
        })
    }),
    M = "rftkjoj";
const A = h.memo(function({
        closeFn: t
    }) {
        const {
            isSearching: s,
            searchResult: r,
            pageInfo: a
        } = u(), l = s ? Array(20).fill(C) : r;
        return !s && a.page < a.total, c("div", {
            className: T,
            children: [c("div", {
                className: "result-title",
                children: [e("p", {
                    className: "title",
                    children: "Search Result"
                }), !s && r.length > 0 && c("p", {
                    children: ["About", e("span", {
                        children: a.total > 99 ? "99+" : a.total
                    }), "results"]
                })]
            }), r.length === 0 && !s ? e("div", {
                className: "no-result",
                children: e("p", {
                    children: "No results found."
                })
            }) : e(I, {
                className: "result-list-wrap hidden-scroll-y",
                children: l.map((n, g) => e(j, {
                    closeFn: t,
                    resultItem: n,
                    isLoading: s
                }, g))
            })]
        })
    }),
    T = "r1mhbogg",
    G = [{
        width: 1716,
        num: 8
    }, {
        width: 1396,
        num: 7
    }, {
        width: 1076,
        num: 6
    }, {
        width: 900,
        num: 5
    }, {
        width: 724,
        num: 4
    }, {
        width: p,
        num: 3
    }, {
        width: p,
        num: 2
    }],
    O = h.memo(function({
        closeFn: t
    }) {
        const {
            recommendList: s,
            changeRecommendList: r
        } = u();
        N.exports.useEffect(() => {
            const l = "/home/statistic/search-recommended/" + (d.areaCode || "UNKNOWN") + "/";
            v.get(l, {
                cache: !0
            }).then(n => {
                r(n || [])
            }).catch(console.log)
        }, []);
        const a = s.length > 0 ? s : void 0;
        return e(L, {
            list: a,
            isSlots: !0,
            sliderClassName: "search-recommend",
            clickSource: "game_search_recommend",
            sreenOpt: G,
            onClick: t
        })
    });
const q = h.memo(function({
        closeFn: t
    }) {
        const {
            inputText: s,
            isSearching: r
        } = u(), a = s.length > 2 || r;
        return c("div", {
            className: `search-main ${P}`,
            children: [s.length < 3 && e("p", {
                className: "require-wrod",
                children: "Search requires at Least 3 Characters"
            }), a ? e(A, {
                closeFn: t
            }) : e(x, {}), c("div", {
                className: "recommend-wrap",
                children: [e("p", {
                    className: "recommend-title",
                    children: "Recommended for you"
                }), e(_, {
                    name: "search-recommend"
                })]
            }), e(O, {
                closeFn: t
            })]
        })
    }),
    P = "s1it4miu";
export {
    q as
    default
};
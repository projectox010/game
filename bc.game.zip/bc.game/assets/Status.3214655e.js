import {
    a5 as u,
    a as s,
    s as c,
    j as l,
    l as n,
    B as t
} from "./index.28e31dff.js";

function b({
    className: e
}) {
    const a = c.isDarken;
    return l("div", {
        className: n(i, e),
        children: [s("img", {
            src: a ? t.status_bg : t.status_bg_w,
            className: "bg",
            alt: ""
        }), s("div", {
            className: "bubble"
        })]
    })
}

function o({
    className: e
}) {
    const a = c.isDarken;
    return l("div", {
        className: n(i, e),
        children: [s("img", {
            src: a ? t.status_bg2 : t.status_bg2_w,
            className: "bg",
            alt: ""
        }), s("div", {
            className: "bubble"
        }), s("img", {
            src: t.status_coin,
            className: "coin",
            alt: ""
        }), s("img", {
            src: t.status_mark,
            className: "mark",
            alt: ""
        })]
    })
}

function g({
    className: e
}) {
    const a = c.isDarken;
    return l("div", {
        className: n(i, N, e),
        children: [s("div", {
            className: "light-bg",
            children: s("img", {
                className: "light",
                src: t.status_light,
                alt: ""
            })
        }), s("img", {
            src: a ? t.status_bg3 : t.status_bg3_w,
            className: "bg",
            alt: ""
        })]
    })
}
const _ = u.memo(function(a) {
        const m = Number(a.bonusAmount),
            r = Number(a.bonusThreshold);
        return m === 0 ? s(b, {
            className: a.className
        }) : m >= r ? s(g, {
            className: a.className
        }) : s(o, {
            className: a.className
        })
    }),
    i = "sjrjgcq",
    N = "s1b4lpsd";
export {
    _ as B
};
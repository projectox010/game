var f = Object.defineProperty;
var n = Object.getOwnPropertySymbols;
var r = Object.prototype.hasOwnProperty,
    o = Object.prototype.propertyIsEnumerable;
var d = (a, e, s) => e in a ? f(a, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : a[e] = s,
    m = (a, e) => {
        for (var s in e || (e = {})) r.call(e, s) && d(a, s, e[s]);
        if (n)
            for (var s of n(e)) o.call(e, s) && d(a, s, e[s]);
        return a
    };
var h = (a, e) => {
    var s = {};
    for (var c in a) r.call(a, c) && e.indexOf(c) < 0 && (s[c] = a[c]);
    if (a != null && n)
        for (var c of n(a)) e.indexOf(c) < 0 && o.call(a, c) && (s[c] = a[c]);
    return s
};
import {
    a5 as p,
    u as v,
    j as k,
    a as i,
    l as w
} from "./index.28e31dff.js";
const b = p.memo(function({
        str: e
    }) {
        const s = v(),
            c = e.length;
        let t = 0,
            l = 0;
        return /[\d+]/.test(e) && t++, /[a-z]+/.test(e) && t++, /[A-Z]+/.test(e) && t++, /[!@#$%^&*(),.'{}]+/.test(e) && t++, t > 1 && c > 15 ? l = 3 : t === 1 && c > 10 ? l = 2 : t > 2 && c > 7 ? l = 3 : t > 1 && c > 5 ? l = 2 : c === 0 ? l = 0 : l = 1, l === 0 ? null : k(g, {
            className: "password-check",
            children: [i("div", {
                className: `item type-1${l==1?" check":""}`,
                children: i("div", {
                    className: "label",
                    children: s("page.settings.password_week")
                })
            }), i("div", {
                className: `item type-2${l==2?" check":""}`,
                children: i("div", {
                    className: "label",
                    children: s("page.settings.password_medium")
                })
            }), i("div", {
                className: `item type-3${l==3?" check":""}`,
                children: i("div", {
                    className: "label",
                    children: s("page.settings.password_strong")
                })
            })]
        })
    }),
    g = s => {
        var c = s,
            {
                className: a
            } = c,
            e = h(c, ["className"]);
        return i("div", m({
            className: w(u, a)
        }, e))
    },
    u = "cz2v6jj";
export {
    b as C
};
var Q = Object.defineProperty;
var X = (i, n, e) => n in i ? Q(i, n, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: e
}) : i[n] = e;
var R = (i, n, e) => (X(i, typeof n != "symbol" ? n + "" : n, e), e);
import {
    u as y,
    a as s,
    D as P,
    dx as z,
    j as c,
    o as v,
    du as w,
    l as f,
    T as ee,
    h as te,
    k as ne,
    r as k,
    aO as H,
    ao as se,
    di as oe,
    y as u,
    F as J,
    dj as ie,
    dk as ae,
    dl as le,
    s as _,
    b as B,
    J as $,
    G as Y,
    dy as ce,
    a5 as re,
    dG as de,
    ed as ue,
    dY as he,
    eb as me,
    dC as fe,
    dD as ge,
    dZ as pe,
    dE as be,
    dp as x,
    bN as C,
    d_ as ye,
    ba as ve,
    bb as A,
    d as F,
    aH as we,
    a2 as Ne,
    bo as ke,
    cD as Se,
    x as Re,
    S as xe,
    am as O,
    cJ as Ce,
    t as Ge,
    q as T,
    df as Ie,
    n as Ae
} from "./index.28e31dff.js";
import {
    s as D
} from "./index.dd8128e8.js";
import {
    G as q
} from "./index.06a59a68.js";
import {
    i as L
} from "./isNumber.3847f240.js";
const Oe = function({
    game: n
}) {
    const e = y();
    return s(P, {
        title: e("common.game_intro"),
        children: s(z, {
            children: c("div", {
                className: "item",
                children: [s("h2", {
                    children: " What Is Coinflip? "
                }), s("div", {
                    className: "content",
                    children: n.gameInfo.detail.split(`
`).map((t, o) => s("p", {
                        children: `${t}`
                    }, o.toString()))
                })]
            })
        })
    })
};
var Ve = "/assets/head.a1e82bad.png",
    _e = "/assets/tail.6faa0ccf.png";
const j = {
        head: Ve,
        tail: _e
    },
    E = {
        odds: 0,
        winAmount: 0,
        currencyName: ""
    },
    M = [j.head, j.tail];
const Be = v(function() {
        const n = w(),
            e = n.rounds.length > 0;
        return s("div", {
            className: f(De, "coinflip-list-area", e && "show"),
            children: s("div", {
                className: "bot-area",
                children: s("div", {
                    className: "imgs",
                    children: n.rounds.map((t, o) => s(ee, {
                        config: te.default,
                        children: s(ne.img, {
                            src: M[t.coin || 0],
                            alt: "img"
                        })
                    }, "img-" + o))
                })
            })
        })
    }),
    De = "b16uza7g";
const je = v(function() {
        const n = w(),
            e = k.exports.useRef(null),
            [t] = k.exports.useState({
                progress: 0
            });
        k.exports.useEffect(() => {
            n.animRounds.length > 0 && !n.settings.fastEnable && H.fromTo(t, {
                progress: t.progress + 1
            }, {
                progress: 0,
                duration: 1.2,
                onUpdate() {
                    let a = (1 - t.progress) * .75;
                    t.progress <= .5 && (a = t.progress * .5);
                    const l = (1 - t.progress) * 720;
                    H.set(e.current, {
                        transform: `rotateY(${l}deg) scale(${a+1})`
                    })
                }
            })
        }, [n.animRounds]);
        let o = !0;
        return n.animRounds.length > 0 && (o = n.animRounds[n.animRounds.length - 1].coin === 0), c("div", {
            className: f(Me, "coinflip-center"),
            ref: e,
            children: [s("figure", {
                className: f("game-coinflip-result head", o && "result")
            }), s("figure", {
                className: f("game-coinflip-result tail", !o && "result")
            })]
        })
    }),
    Me = "riek3pp";
const $e = v(function() {
        const n = y(),
            [e, t] = se({
                show: !1,
                showOdds: 0
            }),
            o = w(),
            a = k.exports.useRef(o.rounds.length),
            [l, d] = oe(),
            p = o.getLastRoundInfo(),
            h = new u((p == null ? void 0 : p.odds) || 0);
        k.exports.useEffect(() => {
            o.resultInfo.odds > 1 ? d({
                profitAmount: o.resultInfo.winAmount,
                currencyName: o.resultInfo.currencyName,
                odds: +o.resultInfo.odds.toFixed(2),
                isBigWin: !1,
                enableSound: o.settings.soundEnable
            }) : d(null)
        }, [o.resultInfo]), k.exports.useEffect(() => {
            if (o.rounds.length > 0) {
                if (a.current !== o.rounds.length) {
                    const S = o.rounds[o.rounds.length - 1].odds || 0;
                    if (o.rounds.length > 1) {
                        const K = o.rounds[o.rounds.length - 2].odds || 0;
                        S <= 0 ? t({
                            showOdds: -K,
                            show: !0
                        }) : t({
                            showOdds: S,
                            show: !0
                        })
                    } else t({
                        showOdds: S,
                        show: !0
                    })
                }
            } else t({
                showOdds: 0,
                show: !1
            });
            a.current = o.rounds.length
        }, [o.rounds]);
        const m = o.rounds.length > 0,
            b = h.gt(1),
            N = o.rounds.length === 0 ? "normal" : h.gt(0) ? "green" : "red";
        return c("div", {
            className: Pe,
            children: [c("div", {
                className: "coinflip-area",
                children: [c("div", {
                    className: f("coinflip-left", m && "w-sp"),
                    children: [s("p", {
                        className: "t",
                        children: o.rounds.length
                    }), s("p", {
                        children: n("game.series")
                    })]
                }), s(je, {}), c("div", {
                    className: f("coinflip-right", b && "w-sp"),
                    children: [c("p", {
                        className: f("t", N),
                        children: [s("span", {
                            className: "x",
                            children: "\xD7"
                        }), s("span", {
                            children: h.toFixed(2, u.ROUND_DOWN)
                        })]
                    }), s("p", {
                        children: n("game.multip")
                    }), e.show && c("div", {
                        onAnimationEnd: () => t({
                            show: !1
                        }),
                        className: f("anim-odds", e.showOdds > 0 ? "win-odds" : "lose-odds"),
                        children: ["\xD7", new u(e.showOdds).abs().toFixed(2, u.ROUND_DOWN)]
                    })]
                }), l]
            }), s(Be, {}), s("div", {
                className: "coinflip-star star-1"
            }), s("div", {
                className: "coinflip-star star-2"
            }), s("div", {
                className: "coinflip-star star-3"
            }), s("div", {
                className: "coinflip-star star-4"
            })]
        })
    }),
    Pe = "g14n9byv";
const We = () => {
        const i = w(),
            n = D.useSingleDetail();
        return c(J, {
            children: [s(ie, {
                hideJackpot: !0,
                list: i.myBets,
                keyof: "betId",
                onDetail: n
            }), s(ae, {
                className: He,
                children: c("div", {
                    className: "inner-bg",
                    children: [s($e, {}), s(le, {})]
                })
            })]
        })
    },
    He = "gz1fysp";
var Fe = v(We);
const Te = v(function() {
        return c("div", {
            className: Ee,
            children: [!_.isMobile && s(q.CoinInput, {}), s(qe, {}), _.isMobile && s(q.CoinInput, {})]
        })
    }),
    U = v(function() {
        const i = y(),
            n = w(),
            e = n.isBetting || n.amount.lte(0);
        return n.isBetting ? c(B, {
            className: "bet-button cashout-btn",
            type: "conic",
            size: "big",
            disabled: n.rounds.length === 0,
            onClick: () => n.cashout(),
            children: [n.rounds.length > 0 && s("p", {
                children: $.toLocaleCurrency(n.getMaxProfit(), n.currencyName)
            }), s("p", {
                children: i("crash.common.escape")
            })]
        }) : s(B, {
            className: "bet-button",
            type: "conic",
            size: "big",
            disabled: e,
            loading: n.isBetting,
            onClick: () => {
                n.handleBet().catch(t => {
                    Y(t)
                })
            },
            children: i("common.bet")
        })
    }),
    qe = v(function() {
        const i = y(),
            n = w(),
            e = n.isBetting ? n.guessing : !0;
        return c(J, {
            children: [_.isMobile && s(U, {}), c("div", {
                className: f("select-type-wrap", Le),
                children: [c(B, {
                    onClick: () => n.handleItemClick(0),
                    disabled: e,
                    children: [s("img", {
                        alt: "head",
                        src: j.head
                    }), s("p", {
                        children: i("game.heads")
                    })]
                }), c(B, {
                    onClick: () => n.handleItemClick(1),
                    disabled: e,
                    children: [s("img", {
                        alt: "tail",
                        src: j.tail
                    }), s("p", {
                        children: i("game.tails")
                    })]
                })]
            }), !_.isMobile && s(U, {})]
        })
    }),
    Le = "cg33cix",
    Ee = "m1bufolc",
    Ue = function({
        game: n
    }) {
        return s(ce, {
            title: "Max Profits",
            game: n
        })
    };
const ze = re.memo(() => {
        const i = y(),
            n = w(),
            e = [{
                title: i("common.game_intro"),
                node: s(Oe, {
                    game: n
                })
            }, {
                title: i("common.fairness"),
                node: "/coinflip_help/fairness"
            }, {
                title: "Max Profits",
                node: s(Ue, {
                    game: n
                })
            }];
        return s(de, {
            className: Je,
            manualControl: s(Te, {}),
            gameView: s(Fe, {}),
            tabs: [{
                label: i("common.all_bet"),
                value: D.AllBet
            }, {
                label: i("common.my_bet"),
                value: D.MyBet
            }],
            actions: [s(ue, {}), s(he, {}), s(me, {}), s(fe, {}), s(ge, {}), s(pe, {}), s(be, {
                list: e
            })]
        })
    }),
    Je = "c10wf9oh",
    g = x.Reader,
    G = x.Writer,
    Ye = x.util,
    r = x.roots.gameCoinflip || (x.roots.gameCoinflip = {});
r.BetValue = (() => {
    function i(n) {
        if (n)
            for (let e = Object.keys(n), t = 0; t < e.length; ++t) n[e[t]] != null && (this[e[t]] = n[e[t]])
    }
    return i.encode = function(e, t) {
        return t || (t = G.create()), t
    }, i.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new r.BetValue;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                default: e.skipType(l & 7);
                break
            }
        }
        return a
    }, i
})();
r.GameValue = (() => {
    function i(n) {
        if (this.rounds = [], n)
            for (let e = Object.keys(n), t = 0; t < e.length; ++t) n[e[t]] != null && (this[e[t]] = n[e[t]])
    }
    return i.prototype.rounds = Ye.emptyArray, i.encode = function(e, t) {
        if (t || (t = G.create()), e.rounds != null && e.rounds.length)
            for (let o = 0; o < e.rounds.length; ++o) r.Round.encode(e.rounds[o], t.uint32(18).fork()).ldelim();
        return t
    }, i.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new r.GameValue;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 2:
                    a.rounds && a.rounds.length || (a.rounds = []), a.rounds.push(r.Round.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, i
})();
r.Round = (() => {
    function i(n) {
        if (n)
            for (let e = Object.keys(n), t = 0; t < e.length; ++t) n[e[t]] != null && (this[e[t]] = n[e[t]])
    }
    return i.prototype.round = 0, i.prototype.coin = 0, i.prototype.guess = 0, i.prototype.odds = 0, i.encode = function(e, t) {
        return t || (t = G.create()), e.round != null && Object.hasOwnProperty.call(e, "round") && t.uint32(8).sint32(e.round), e.coin != null && Object.hasOwnProperty.call(e, "coin") && t.uint32(16).sint32(e.coin), e.guess != null && Object.hasOwnProperty.call(e, "guess") && t.uint32(24).sint32(e.guess), e.odds != null && Object.hasOwnProperty.call(e, "odds") && t.uint32(33).double(e.odds), t
    }, i.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new r.Round;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    a.round = e.sint32();
                    break;
                case 2:
                    a.coin = e.sint32();
                    break;
                case 3:
                    a.guess = e.sint32();
                    break;
                case 4:
                    a.odds = e.double();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, i
})();
r.Next = (() => {
    function i(n) {
        if (n)
            for (let e = Object.keys(n), t = 0; t < e.length; ++t) n[e[t]] != null && (this[e[t]] = n[e[t]])
    }
    return i.prototype.guess = 0, i.encode = function(e, t) {
        return t || (t = G.create()), e.guess != null && Object.hasOwnProperty.call(e, "guess") && t.uint32(8).sint32(e.guess), t
    }, i.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new r.Next;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    a.guess = e.sint32();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, i
})();
r.CashoutValue = (() => {
    function i(n) {
        if (n)
            for (let e = Object.keys(n), t = 0; t < e.length; ++t) n[e[t]] != null && (this[e[t]] = n[e[t]])
    }
    return i.prototype.frontgroundId = 0, i.encode = function(e, t) {
        return t || (t = G.create()), e.frontgroundId != null && Object.hasOwnProperty.call(e, "frontgroundId") && t.uint32(120).sint32(e.frontgroundId), t
    }, i.decode = function(e, t) {
        e instanceof g || (e = g.create(e));
        let o = t === void 0 ? e.len : e.pos + t,
            a = new r.CashoutValue;
        for (; e.pos < o;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 15:
                    a.frontgroundId = e.sint32();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return a
    }, i
})();
var Ze = "/assets/win.dabefd8c.mp3",
    Ke = "/assets/lose.d101642b.mp3",
    Qe = "/assets/start.08e3caec.mp3",
    Xe = "/assets/bg.4c9fd524.mp3",
    et = "/assets/sound_bet.42530855.mp3";
const tt = C.encode(r.CashoutValue);
C.encode(r.BetValue);
const nt = C.encode(r.Next);
C.decode(r.BetValue);
const V = C.decode(r.GameValue);
class st extends ye {
    constructor() {
        super({
            name: "CoinFlip",
            namespace: "/g/coinflip",
            fairLink: "/coinflip_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/coinflipsingle.html",
            sounds: {
                sound_lose: Ke,
                sound_win: Ze,
                sound_start: Qe,
                sound_bet: et,
                sound_bg: {
                    src: Xe,
                    isBackground: !0,
                    loop: !0
                }
            }
        }, ze);
        R(this, "rounds", []);
        R(this, "animRounds", []);
        R(this, "guessing", !1);
        R(this, "resultInfo", E);
        ve(this, {
            rounds: A,
            animRounds: A,
            guessing: A,
            resultInfo: A
        }), this.socket.on("connect", () => this.join()), F.waitLogin().then(() => this.join()), this.addHotkey("w", () => this.cashout(), "Cashout"), this.addHotkey("q", () => this.handleItemClick(0), "Pick Head"), this.addHotkey("p", () => this.handleItemClick(1), "Pick Tail");
        const e = this.hotkeyList.find(t => t.key == "space");
        e && (e.handler = () => {
            if (this.controlIdx !== 1) {
                if (this.isBetting) return;
                this.handleBet().catch(t => {
                    Y(t)
                })
            }
            return !1
        })
    }
    get canCashout() {
        return this.rounds.length >= 1
    }
    get isAutoMode() {
        return this.controlIdx === 1
    }
    get maxProfit() {
        if (this.rounds.length <= 0) return new u(0); {
            const e = this.rounds.length,
                o = this.rounds[e - 1].odds || 0;
            return new u(this.amount).mul(o).mul(1.98).sub(this.amount)
        }
    }
    resetStatus() {
        this.rounds = [], this.animRounds = [], this.resultInfo = E
    }
    getLastRoundInfo() {
        const e = this.rounds.length;
        return e === 0 ? null : this.rounds[e - 1]
    }
    getMaxProfit() {
        const e = this.getLastRoundInfo();
        if (e) {
            const t = e.odds || 0,
                o = new u(this.amount).mul(t),
                a = $.dict[this.currencyName],
                l = this.jackpot[this.currencyName].maxProfitAmount;
            return u.min(l, o.toDP(a.precision, u.ROUND_DOWN))
        } else return new u(0)
    }
    canGuess() {
        return this.isBetting && !this.guessing
    }
    updateGrids(e) {
        this.rounds = [...e]
    }
    async join() {
        if (!this.isActived || !F.login) return;
        this.resetStatus();
        let e = await this.socketRequest("join").then(this.betResultDecoder),
            t = V(e.gameValue);
        if (e.odds > 0) {
            this.guessing = !1, this.setBetStatus(!0);
            let o = this.getBetlog(e);
            t.rounds.length > 0 && (this.currencyName = o.currencyName, setTimeout(() => this.amount = new u(o.betAmount), 100));
            try {
                await this.bet(new u(o.betAmount), o), this.setBetStatus(!1)
            } catch (a) {
                console.log("join error"), this.setBetStatus(!1)
            }
        }
    }
    handleItemClick(e) {
        this.isAutoMode ? console.log("no auto mode") : this.handleNext(e)
    }
    async handleNext(e) {
        if (!(!this.isBetting || this.guessing)) {
            this.sounds.playSound("sound_start"), this.guessing = !0;
            try {
                const o = (await this.socketRequest("next", nt({
                    guess: e
                })).then(V)).rounds[0];
                if (o) {
                    const a = [...this.rounds].concat(o);
                    this.animRounds = [...a], await we(this.settings.fastEnable ? 0 : 1200), this.rounds = [...a], (o.odds || 0) > 0 ? this.sounds.playSound("sound_win") : (this.sounds.playSound("sound_lose"), this.emit("end", {
                        odds: 0,
                        winAmount: 0
                    }))
                }
            } catch (t) {
                console.log("bet error", t), this.join()
            } finally {
                this.guessing = !1
            }
        }
    }
    async cashout() {
        if (!(!this.canGuess() || !this.canCashout)) {
            this.guessing = !0;
            try {
                const e = await this.socketRequest("cashout", tt({
                    frontgroundId: this.txId
                })).then(this.betResultDecoder);
                let {
                    odds: t,
                    winAmount: o,
                    currencyName: a
                } = e, l = V(e.gameValue);
                t /= this.oddsScale;
                const d = $.bn2amount(o, a);
                this.rounds.length !== l.rounds.length && (console.log("cashout update"), this.isAutoMode || this.join()), this.updateGrids(l.rounds), this.resultInfo = {
                    odds: t,
                    winAmount: d,
                    currencyName: a
                }, this.emit("end", {
                    odds: t,
                    winAmount: d
                })
            } catch (e) {
                console.log("cashout error")
            } finally {
                this.guessing = !1
            }
        }
    }
    async bet(e = this.amount, t = 0) {
        if (this.resetStatus(), L(t)) {
            this.sounds.playSound("sound_bet"), this.guessing = !0;
            try {
                let h = this.betRequest(e, this.betValue(), t);
                this.onBetRequest && (h = this.onBetRequest(h)), t = await h
            } finally {
                L(t) && this.join(), this.guessing = !1
            }
        }
        let o = V(t.gameValue);
        this.updateGrids(o.rounds);
        let {
            odds: a,
            winAmount: l
        } = await new Promise((h, m) => {
            const b = I => {
                    this.removeListener("deactivate", N), h(I)
                },
                N = () => {
                    this.removeListener("end", b), m()
                };
            this.once("end", b), this.once("deactivate", N)
        });
        t.odds = a, t.winAmount = l, t.profitAmount = l - t.betAmount, delete t.gameValue;
        let d = t.betId;
        return this.myBets.find(h => h.betId === d) || (this.addMyBet(t), this.emit("betEnd", {
            amount: new u(t.betAmount),
            odds: t.odds,
            currencyName: t.currencyName
        })), t
    }
    betValue() {
        return new Uint8Array
    }
}
const Z = new st;
var yt = Z;
window.cfg = Z;

function vt({
    bodyLock: i
}) {
    const n = y();
    return s(P, {
        title: n("common.fairness"),
        children: s(z, {
            bodyLock: i,
            children: c("div", {
                className: "item",
                children: [s("h2", {
                    children: "How are results calculated?"
                }), c("div", {
                    className: "help-content",
                    children: [s("p", {
                        children: "To get the results."
                    }), c("ul", {
                        children: [s("li", {
                            children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce:round, serverSeed)."
                        }), s("li", {
                            children: "Finally, we take 8 characters of the hash and convert it to an int32 value. Then we divide the converted value by 0x100000000, multiply it by 2,"
                        })]
                    }), s("br", {}), s("p", {
                        children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                    }), s("p", {}), s("p", {
                        children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                    }), s("p", {
                        children: 'We put our "cards on the table." '
                    }), s("p", {
                        children: "Good luck!"
                    })]
                })]
            })
        })
    })
}
const ot = "https://bcgame-project.github.io/verify/coinflip.html",
    it = () => {
        const i = Ne(),
            n = ke(i),
            e = Se(() => ({
                serverSeed: n[0] || "",
                clientSeed: n[1] || "",
                nonce: parseInt(n[2]) || 0,
                round: parseInt(n[3]) || 10
            })),
            {
                serverSeed: t,
                clientSeed: o,
                nonce: a,
                round: l
            } = e;
        return s(P, {
            title: Re.t("common.validate"),
            children: c(xe, {
                className: rt,
                children: [s("h2", {
                    children: "Input"
                }), s(O, {
                    label: "Server Seed",
                    value: t,
                    onChange: d => e.serverSeed = d
                }), s(O, {
                    label: "Client Seed",
                    value: o,
                    onChange: d => e.clientSeed = d
                }), s(O, {
                    label: "Nonce",
                    value: a,
                    onChange: d => e.nonce = Number(d)
                }), s(O, {
                    label: "Round",
                    value: l,
                    onChange: d => e.round = Number(d)
                }), s("h2", {
                    children: "Final Result"
                }), Array(l).fill(1).map((d, p) => {
                    const h = at(t, o, a, p + 1),
                        m = lt(h),
                        b = ct(m.hex);
                    return c("div", {
                        className: "result-list result-item",
                        children: [c("p", {
                            className: "round-title",
                            children: ["round ", p + 1, ":"]
                        }), s("p", {
                            children: "hmac_sha256(client_seed:nonce:round, server_seed)"
                        }), s("div", {
                            className: "table-wrap",
                            children: s("table", {
                                children: s("tbody", {
                                    children: [m.dec, m.hex].map((N, I) => s("tr", {
                                        children: N.map((S, W) => s("td", {
                                            children: S
                                        }, "td-" + W))
                                    }, "tr-" + I))
                                })
                            })
                        }), c("div", {
                            className: "table-result",
                            children: [`(${m.dec[0]}, ${m.dec[1]}, ${m.dec[2]}, ${m.dec[3]}) -> [0, ...4] = `, s("span", {
                                className: "sp",
                                children: b.result
                            })]
                        }), c("div", {
                            className: "coinflip-result-num",
                            children: [s("span", {
                                children: b.result
                            }), s("span", {
                                className: "ar",
                                children: "->"
                            }), s("img", {
                                alt: "coin",
                                src: M[b.result]
                            })]
                        })]
                    }, "round-" + p)
                }), s("p", {
                    className: "githubverify",
                    children: s("a", {
                        href: `${ot}?s=${e.serverSeed}&c=${e.clientSeed}&n=${e.nonce}&r=${e.round}`,
                        target: "_blank",
                        children: "Verify on Github"
                    })
                })]
            })
        })
    };

function at(i, n, e, t) {
    return String(Ce([n, e, t].join(":"), i))
}

function lt(i) {
    let n = {
        dec: [],
        hex: []
    };
    for (let e = 0; e < i.length; e += 2) {
        let t = i[e] + i[e + 1],
            o = parseInt(t, 16);
        n.dec.push(t), n.hex.push(o)
    }
    return n
}

function ct(i) {
    const n = i[0] / Math.pow(256, 1),
        e = i[1] / Math.pow(256, 2),
        t = i[2] / Math.pow(256, 3),
        o = i[3] / Math.pow(256, 4),
        a = (n + e + t + o) * 2,
        l = Math.floor(a);
    return {
        clscList: [n.toFixed(9), e.toFixed(9), t.toFixed(9), o.toFixed(9)],
        resultStep: a.toFixed(9),
        result: l
    }
}
var wt = it;
Ge({
    cl1: [T("#99a4b0", .8), T("#5f6975", .8)]
});
const rt = "f1ke8se9";
const dt = (i, n, e, t, o) => {
        let a = 10;
        o && o.betLog && o.betLog.gv && o.betLog.gv.rounds && (a = o.betLog.gv.rounds.length), Ae(`/coinflip_help/validate/${i}/${n}/${e}/${a}`)
    },
    ut = D.withSingleDetail({
        onValidate: dt,
        result: ({
            betLog: i
        }) => {
            const n = y(),
                e = i.gv.rounds || [];
            if (e.length == 0) return null;
            const t = e[e.length - 1],
                o = new u(t.odds);
            return s(Ie, {
                className: "rt_items",
                style: {
                    backgroundColor: "transparent",
                    padding: 0
                },
                children: c("div", {
                    className: ht,
                    children: [s("p", {
                        className: "result-title",
                        children: n("common.result")
                    }), c("div", {
                        className: "coinflip-result-wrap",
                        children: [c("div", {
                            className: "game-result-area",
                            children: [c("div", {
                                className: "game-left",
                                children: [s("p", {
                                    className: "t",
                                    children: e.length
                                }), s("p", {
                                    children: n("game.series")
                                })]
                            }), s("div", {
                                className: "game-center",
                                children: s("img", {
                                    alt: "coin",
                                    src: M[t.coin]
                                })
                            }), c("div", {
                                className: "game-right",
                                children: [c("p", {
                                    className: f("t", o.gte(1) ? "win" : "lose"),
                                    children: [s("span", {
                                        className: "x",
                                        children: "\xD7"
                                    }), s("span", {
                                        children: o.toFixed(2, u.ROUND_DOWN)
                                    })]
                                }), s("p", {
                                    children: n("game.multip")
                                })]
                            })]
                        }), s("div", {
                            className: "game-result-list",
                            children: e.map((a, l) => s("img", {
                                alt: "coin",
                                src: M[a.coin]
                            }, "detail-" + l))
                        })]
                    })]
                })
            })
        }
    }),
    ht = "djw3zlj";
var Nt = ut;
export {
    Nt as Detail, vt as Fairness, yt as Game, wt as Validate
};
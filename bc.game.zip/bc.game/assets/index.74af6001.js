var L = Object.defineProperty;
var j = (s, a, t) => a in s ? L(s, a, {
    enumerable: !0,
    configurable: !0,
    writable: !0,
    value: t
}) : s[a] = t;
var r = (s, a, t) => (j(s, typeof a != "symbol" ? a + "" : a, t), t);
import {
    a as e,
    dx as I,
    j as o,
    dy as P,
    dz as Y,
    r as d,
    o as p,
    P as E,
    aO as M,
    l as R,
    u as f,
    du as g,
    dl as F,
    am as O,
    t as W,
    q as H,
    F as U,
    dj as _,
    s as m,
    b as V,
    G as x,
    e9 as X,
    a5 as z,
    dG as Z,
    ed as J,
    dY as q,
    eb as K,
    dC as Q,
    dD as $,
    dZ as ee,
    dE as te,
    dp as b,
    bN as T,
    d_ as ae,
    ba as ne,
    bb as k,
    bc as se,
    dR as oe,
    y as w,
    aH as ie,
    df as le,
    A as B
} from "./index.28e31dff.js";
import {
    G as u
} from "./index.06a59a68.js";
import {
    s as y
} from "./index.dd8128e8.js";
const re = function() {
        return e(I, {
            children: o("div", {
                className: "item",
                children: [e("h2", {
                    children: " What Is Limbo? "
                }), e("div", {
                    className: "help-content",
                    children: e("p", {
                        children: 'Coco has a rocket called "Limbo". It is rising every moment and can explode at any time. Limbo will drop treasures during rising up and only those who accurately predict its explosion time can catch them.'
                    })
                }), e("h2", {
                    children: "How to play Limbo? "
                }), o("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "1.Target payout must be below the limbo result to win."
                    }), e("p", {
                        children: "2.The maximum target multiplier is x1,000,000. "
                    }), e("p", {
                        children: "3.This is not really the edge of hell, rest assured to catch up."
                    })]
                }), e("h2", {
                    children: "What is the Limbo return rate? "
                }), e("div", {
                    className: "help-content",
                    children: "Only 1% HouseEdge."
                }), e("h2", {
                    children: "Auto Mode Operation Instructions"
                }), o("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "[ ON WIN ] when you win, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'."
                    }), o("p", {
                        children: ["[ ON LOSE ] when you lose, the next bet amout will 'Increase by _(your set)_' or 'Reset to initial amount'.", " "]
                    }), e("p", {
                        children: "[ STOP ON WIN ] Once the amount winned (from start to this bet) is bigger/equal than _(your set)_ , auto will stop;"
                    }), e("p", {
                        children: "[ STOP ON LOSS ] Once the amount lost (from start to next bet) may be bigger/equal than _(your set)_ , auto will stop."
                    })]
                })]
            })
        })
    },
    ce = function({
        game: a
    }) {
        return e(P, {
            game: a,
            children: o("div", {
                className: "item",
                children: [e("h2", {
                    children: "What is the bankroll?"
                }), o("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                    }), e("p", {
                        children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                    }), e("p", {
                        children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                    }), e("p", {
                        onClick: () => Y(a, 1),
                        className: "cl-primary pointer",
                        children: "Read more about bankrollers."
                    })]
                }), e("h2", {
                    children: "How does the pool of funds operate? "
                }), o("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                    }), o("p", {
                        children: [e("b", {
                            className: "cl-primary",
                            children: "The house edge is 1%."
                        }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                    }), e("p", {
                        children: "Payouts made to the winning players will be deducted from the bankroll."
                    })]
                }), e("h2", {
                    children: "How does leverage investment work?"
                }), o("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                    }), e("p", {
                        children: "Hint: You can also use this feature as an Off-Site investment."
                    }), e("p", {
                        children: "Let's make an example:"
                    }), e("p", {
                        children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                    })]
                }), e("h2", {
                    children: "What is the bankroller dilution fee?"
                }), o("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                    }), e("p", {
                        children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                    }), e("p", {
                        children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                    }), e("p", {
                        children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                    })]
                })]
            })
        })
    };
var ue = ce;
const de = function() {
        const [a, t] = d.exports.useState(-1), n = d.exports.useRef();
        return d.exports.useEffect(() => (n.current = setInterval(() => {
            t(Math.ceil(Math.random() * 3))
        }, 5e3), () => {
            clearInterval(n.current)
        }), []), e("div", {
            className: he,
            children: o("div", {
                className: "bg-star show_" + a,
                children: [e("div", {
                    className: "l-star e-r"
                }), e("div", {
                    className: "l-star s-p"
                }), e("div", {
                    className: "l-star r-p"
                })]
            })
        })
    },
    he = "blzt9s6";
var me = "/assets/limbo_bg.2ead334e.png",
    be = "/assets/limbo_bg_w.a7f38413.png",
    pe = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAPYAAABABAMAAADbr5eTAAAAD1BMVEX///8AAAD///////////9cEmbOAAAABXRSTlMTAA4JBDkaubkAAAGqSURBVFjDxdjRjeIwEIDh/xwKwLELcBIKSBYKiDn6r+mk1Z5Gy2YzIszI/yM8fJp4YiGIL/T4GCGMt2jTC3Yu/G+KSsb2HaSwRCUrW2hJwY1soXXcw05gjuu2rNlzoUYlE3tlqy4qWdiJ7YaoZGDPbBfiU/Z2AvvBdVvG1gf3sDN4DK7bsuTaqrvY7FVd7Z69TlGyt2cAfdtcbParjnav2H+iZG2vAPqmu9gFpSgZ2xmtJUq2dg9OB67bMzgduG6jFrzshF6N0cU+ozc42TOScqWb2fk6lnG6RUDvdh0hXKuNnQoHulnYiWNd3rczRxvetmcOV4/Y+aOEaVGeuF53wL7LgcnY3k8dob/wBP6Diy0c06PwVstrdsaw7jV7Rclg1fNj005sZLttfwsw1Z/2imnh938tlmc7Y9zlc8ywPNGCi93j1GXjmqzfbfnKB7+D1H238Ugecf59E0n4FeQFlo8kehw7xbTzCnLGszrv3HvMeNbxo8XR1i/8x9fPSgotmj7tRnUNbYaGdmhoMzS0u4Y2lUKrhob2iZlWday0KnCmXZl2xXuhTd0/i6cAPsoSejMAAAAASUVORK5CYII=",
    fe = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAAAwBAMAAAC1YGgtAAAAD1BMVEX///8AAAD///////////9cEmbOAAAABXRSTlMTAA4IBCABiPgAAAEzSURBVFjDtdVhjoIwEEDhx+ABLO0BBtYDWPUAVPf+Z9qYuAGkRIHp95+8DNApbpNHB3TX5D7aFPDKy08qEfAMJNoHAhPRPKBMJeNAw5vaNhCYaU0DDXPJMqDMHQwDDTmGgTM5rVkgkFWbBY7kJauAktcaBTwLaqPAkSVGAWVJNAl4FlUmgZ5FtUmAZWIRaBjkTkJImwPhonzQPhQkbgt45VunLQHPCnF9ICgryOuh3+8DZ1ZpX+9Ubl8GPCsl50ffA+sBQC7jYbAbYE7SW8BfpLvN1sMOh2ngztPP7I7cIY0D9//scHqlU3apRgE/PY1BMSCjgE4Xl2IikluV9fBz7lWRvQ1jj5EDwwBFyDMQHtcrA/OAV0pyQSnK9ZTlKErwFCUcKaqmp6gapaiqdCBSlJzcHzwgmJkN1iU1AAAAAElFTkSuQmCC",
    ge = "/assets/mountain.60a22ac3.png",
    ye = "/assets/fire.f512cda1.png",
    Ae = "/assets/boom.6948e164.png",
    ve = "/assets/limbo_rocket.e2fbb7ee.png",
    ke = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACYAAAApCAMAAAButatJAAABL1BMVEUAAABrcXFITVMuND2AgICGiIx0dno9Qkg+QkdQVFs4QEU0PkiPkZSDhol/gYV4e3+ChIh3en5wc3hvcnZqbXJjZ2tgY2hUV11YXGBhZWpRVltDRk0zNj1DTVA0NDlVXmiNj5KMjpGKjJCJi46ChYh8foKIi45rbXJnam9kaGxcYGZcYGRYXGFVWV5OU1iSk5dKTlNKTVNmaG50dnpHSU45PUJ3en0yOD1AQEaDg4pKUFWDjY0vLzx8fIOAk5ORkpZ6fYF9gIR7fYKMj5Jsb3R+gYaRlJZ7f4Jrb3JnaW9ZW2F4fIGNj5GPkZRjZ2xNUFhpbG93en2Kio1ucXRBSEtwc3dNVFc8REddYWiGiop1eX17e4A0OT5cXGI9PUiEhIxaWmMrMzxqcnJxcXEcHByz6GXpAAAAZXRSTlMAA1MZB9y1Ph0TCwbw1s3Avrqwq6KRim5kY2FJIhsQDevo5eLPyLyem5eFgXt0Z2FdWVZCNzYtKygmGBcTEg3HxL+7tqemko+Pfnl1dHJqY1xaVVFOSUZEQjs7NDEvLh8fHh0JCSgTVVAAAAEOSURBVDjLjdLVcsJgEIZh/oQkhQBxIQnBXYpLkbq7u/f+r6GXsN8ePzM7+85G0GEyQ5j8F4dcPAwRxxb8AnEy/81Da4MAcuF0soY4fvIGuWA0Qhz7kCTEyUPpMYOcK/k+4mL+HbcBuAzHQW7a6/ZigBt2Lz3AsYdOx8vSLso5jgu4rNduu79AFuek5UZp99VqNtOAe2807DSj3ZNtW4jrW1b9Csh3Ua/V+kC+46pp3tJueWTuGfe0+6kauj6g3djQRfGFdgNR1LRX2l1rirIzpt2pslXentH5DsuplPpJutV+qpRU56Sbq8mkUFmSblYShGJlRbpnoVjI79Lvd1PI5xLrdJazXAJhkfPNA/YPCScdoJSKnpIAAAAASUVORK5CYII=";
const we = {
    cloud_b: pe,
    cloud_s: fe,
    mountain: ge,
    fire: ye,
    boom: Ae,
    limbo_bg: me,
    limbo_bg_w: be,
    limbo_rocket: ve,
    limbo_star: ke
};
const Be = p(function({
        game: a
    }) {
        const t = d.exports.useRef(null),
            n = E(),
            i = d.exports.useRef(1),
            l = d.exports.useRef(!0),
            [c, v] = d.exports.useState(1),
            N = () => {
                a.gameIsWin ? a.gameResult <= 2 ? a.sounds.playSound("lt2Sound") : a.gameResult <= 5 ? a.sounds.playSound("lt5Sound") : a.gameResult <= 10 ? a.sounds.playSound("lt10Sound") : a.sounds.playSound("mt10Sound") : a.sounds.playSound("boomSound")
            };
        return d.exports.useEffect(() => {
            if (l.current) l.current = !1;
            else {
                if (a.settings.fastEnable) N(), t.current && (t.current.innerHTML = a.gameResult.toFixed(2));
                else {
                    v(2);
                    const S = {
                        num: i.current
                    };
                    M.to(S, .5, {
                        num: a.gameResult,
                        ease: "Linear.easeNone",
                        onUpdate: () => {
                            t.current && (t.current.innerHTML = S.num.toFixed(2))
                        }
                    }), setTimeout(() => {
                        N(), n() && v(3), setTimeout(() => {
                            n() && v(1)
                        }, 300)
                    }, 200)
                }
                i.current = a.gameResult
            }
        }, [a.gameResult]), e("div", {
            className: R(Ne, a.controlIdx !== 1 && "auto"),
            children: o("div", {
                className: "notranslate game-rocket " + (a.settings.fastEnable ? "game-turbo" : ""),
                children: [o("div", {
                    className: "rocket-number " + (l.current ? "" : a.gameIsWin ? "game-green" : "game-red"),
                    children: [e("span", {
                        ref: t,
                        children: "1.00"
                    }), e("span", {
                        className: "gv-x",
                        children: "\xD7"
                    }), e("div", {
                        className: "rocket-boom " + (c > 1 ? "boom" : "")
                    })]
                }), o("div", {
                    className: "rocket-wrap " + (c === 3 ? "flying boom" : c === 2 ? "flying" : ""),
                    children: [e("div", {
                        className: "rocket-img",
                        children: e("img", {
                            src: we.limbo_rocket,
                            alt: "rocket.png"
                        })
                    }), e("div", {
                        className: "rocket-fire"
                    })]
                })]
            })
        })
    }),
    Ne = "g15dj8tv";
const Se = p(function() {
    const a = f(),
        t = g();
    return o("div", {
        className: Ge,
        children: [e(F, {}), e(de, {}), e(Be, {
            game: t
        }), t.controlIdx === 1 ? o("div", {
            className: "payout-inputs",
            children: [e(u.PayoutInput, {
                label: a("common.payout"),
                size: "small",
                value: t.payout,
                disabled: t.isBetting,
                onChange: n => t.payout = n,
                max: 1e6,
                min: 1.01,
                precision: 2
            }), e(O, {
                label: a("game.dice.winChance"),
                value: t.getChance(t.payout),
                size: "small",
                readOnly: !0,
                disabled: t.isBetting,
                children: e("span", {
                    children: "%"
                })
            })]
        }) : null]
    })
});
W({
    cl1: ["url(../assets/limbo_bg.png)", "url(../assets/limbo_bg_w.png)"],
    cl2: ["#17181b", "#f5f6fa"],
    cl3: [H("#31343c", .6), "#ffffff"],
    cl4: ["#f5f6f7", "#31373d"]
});
const Ge = "g122s95w",
    Ie = () => {
        const s = g(),
            a = y.useSingleDetail();
        return o(U, {
            children: [e(_, {
                list: s.myBets,
                keyof: "betId",
                onDetail: a,
                getResult: t => `${(t.gameValue/100).toFixed(2)}x`
            }), e(Se, {})]
        })
    };
var Re = p(Ie);
const Ve = p(function() {
        const a = g(),
            t = f(),
            n = () => e(V, {
                className: "bet-button",
                type: "conic",
                size: "big",
                onClick: () => {
                    a.autoBet.isRunning ? a.autoBet.stop() : a.autoBet.start().catch(x)
                },
                children: a.autoBet.isRunning ? t("common.stop_auto_bet") : t("common.start_auto_bet")
            });
        return o("div", {
            className: R(xe, "game-form"),
            children: [m.isMobile && n(), e(u.CoinInput, {
                checkIncrease: !0
            }), e(u.TimesInput, {}), e(u.IncreaseInput, {}), e(u.StopInput, {}), e(u.IncreaseInput, {
                isLose: !0
            }), e(u.StopInput, {
                isLose: !0
            }), e(X, {}), !m.isMobile && n()]
        })
    }),
    xe = "a1144de1";
const Te = p(function() {
        const a = f(),
            t = g(),
            n = () => e(V, {
                className: "bet-button",
                type: "conic",
                size: "big",
                disabled: t.isBetting,
                onClick: t.handGameBet,
                children: a("common.bet")
            });
        return o("div", {
            className: Ce,
            children: [m.isMobile && n(), e(u.CoinInput, {}), e(u.PayoutInput, {
                label: o("div", {
                    className: "libmo-payout",
                    children: [e("div", {
                        children: a("common.payout")
                    }), o("div", {
                        children: [e("span", {
                            children: a("common.chance")
                        }), o("span", {
                            className: "green",
                            children: [t.getChance(t.payout), "%"]
                        })]
                    })]
                }),
                size: "small",
                value: t.payout,
                disabled: t.isBetting,
                onChange: i => t.payout = i,
                max: 1e6,
                min: 1.01,
                precision: 2
            }), !m.isMobile && n()]
        })
    }),
    Ce = "m17h636e",
    De = z.memo(() => {
        const s = f(),
            a = g(),
            t = [{
                title: s("common.game_intro"),
                node: e(re, {})
            }, {
                title: s("common.fairness"),
                node: "/limbo_help/fairness"
            }, {
                title: s("common.bankroll"),
                node: e(ue, {
                    game: a
                })
            }];
        return e(Z, {
            manualControl: e(Te, {}),
            autoControl: e(Ve, {}),
            gameView: e(Re, {}),
            tabs: [{
                label: s("common.all_bet"),
                value: y.AllBet
            }, {
                label: s("common.my_bet"),
                value: y.MyBet
            }],
            actions: [e(J, {}), e(q, {}), e(K, {}), e(Q, {}), e($, {}), e(ee, {}), e(te, {
                list: t
            })]
        })
    }),
    A = b.Reader,
    C = b.Writer,
    G = b.util,
    h = b.roots.gameLimbo || (b.roots.gameLimbo = {});
h.BetValue = (() => {
    function s(a) {
        if (a)
            for (let t = Object.keys(a), n = 0; n < t.length; ++n) a[t[n]] != null && (this[t[n]] = a[t[n]])
    }
    return s.prototype.payout = 0, s.encode = function(t, n) {
        return n || (n = C.create()), t.payout != null && Object.hasOwnProperty.call(t, "payout") && n.uint32(8).sint32(t.payout), n
    }, s.decode = function(t, n) {
        t instanceof A || (t = A.create(t));
        let i = n === void 0 ? t.len : t.pos + n,
            l = new h.BetValue;
        for (; t.pos < i;) {
            let c = t.uint32();
            switch (c >>> 3) {
                case 1:
                    l.payout = t.sint32();
                    break;
                default:
                    t.skipType(c & 7);
                    break
            }
        }
        return l
    }, s
})();
h.GameValue = (() => {
    function s(a) {
        if (a)
            for (let t = Object.keys(a), n = 0; n < t.length; ++n) a[t[n]] != null && (this[t[n]] = a[t[n]])
    }
    return s.prototype.gameValue = G.Long ? G.Long.fromBits(0, 0, !1) : 0, s.encode = function(t, n) {
        return n || (n = C.create()), t.gameValue != null && Object.hasOwnProperty.call(t, "gameValue") && n.uint32(8).sint64(t.gameValue), n
    }, s.decode = function(t, n) {
        t instanceof A || (t = A.create(t));
        let i = n === void 0 ? t.len : t.pos + n,
            l = new h.GameValue;
        for (; t.pos < i;) {
            let c = t.uint32();
            switch (c >>> 3) {
                case 1:
                    l.gameValue = t.sint64();
                    break;
                default:
                    t.skipType(c & 7);
                    break
            }
        }
        return l
    }, s
})();
var Le = "/assets/boom.fdf6b43d.mp3",
    je = "/assets/flying.0f732610.mp3",
    Pe = "/assets/lt2.a9bd3398.mp3",
    Ye = "/assets/lt5.23a8c254.mp3",
    Ee = "/assets/lt10.2eb39989.mp3",
    Me = "/assets/mt10.6df9ddf5.mp3",
    Fe = "/assets/limbo.d0972eea.mp3";
const Oe = T.decode(h.GameValue),
    We = T.encode(h.BetValue);
class He extends ae {
    constructor() {
        super({
            name: "Limbo",
            namespace: "/g/l",
            sounds: {
                boomSound: Le,
                fireSound: je,
                lt2Sound: Pe,
                lt5Sound: Ye,
                lt10Sound: Ee,
                mt10Sound: Me,
                limbo: {
                    src: Fe,
                    loop: !0,
                    isBackground: !0
                }
            },
            fairLink: "/limbo_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/limbo.html"
        }, De);
        r(this, "betInterval", 350);
        r(this, "betStartTime", new Date().getTime());
        r(this, "gameResult", 1);
        r(this, "payout", 1.98);
        r(this, "gameIsWin", !1);
        r(this, "needDeduction", !1);
        r(this, "handGameBet", () => {
            this.isBetting || (this.gameIsWin = !1, this.handleBet().catch(x))
        });
        r(this, "addPayout", () => {
            this.isBetting || (this.payout = this.payout + .02)
        });
        r(this, "deletePayout", () => {
            this.isBetting || (this.payout = this.payout - .02)
        });
        r(this, "onBetRequest", async t => {
            let n = await t;
            this.gameResult = new w(n.gameValue).div(100).toNumber(), this.gameIsWin = n.odds > 0;
            let i = 500;
            if (this.settings.fastEnable) {
                const l = new Date().getTime() - this.betStartTime;
                i = l > this.betInterval ? 0 : this.betInterval - l
            }
            return this.settings.fastEnable || this.sounds.playSound("fireSound"), await ie(i), n
        });
        r(this, "getChance", t => {
            const n = new w(99).div(t).toNumber();
            let i = m.isMobile ? 2 : 5;
            return n.toFixed(i)
        });
        ne(this, {
            gameResult: k,
            payout: k,
            gameIsWin: k,
            maxProfit: se
        }), this.addHotkey("w", this.deletePayout, "payout - 0.02"), this.addHotkey("e", this.addPayout, "payout + 0.02"), oe(() => {
            this.autoBet.interval = this.settings.fastEnable ? this.betInterval : 500
        });
        const t = this.hotkeyList.find(n => n.key == "space");
        t && (t.handler = () => (this.controlIdx === 1 ? this.autoBet.isRunning ? this.autoBet.stop() : this.autoBet.start() : this.handGameBet(), !1)), this.on("betStart", () => {
            this.betStartTime = new Date().getTime()
        })
    }
    get maxProfit() {
        return this.amount.mul(this.payout).sub(this.amount)
    }
    gameValueDecoder(t) {
        return Oe(t).gameValue.toNumber()
    }
    betValue() {
        return We({
            payout: new w(this.payout).mul(100).toNumber()
        })
    }
}
const D = new He;
var Ue = D;
window.lbg = D;

function Ke({
    bodyLock: s
}) {
    return e(I, {
        bodyLock: s,
        children: o("div", {
            className: "item",
            children: [e("h2", {
                children: "How are results calculated?"
            }), o("div", {
                className: "help-content",
                children: [e("p", {
                    children: "To get the results."
                }), e("div", {
                    children: "Hex string: hash = HMAC_SHA256(clientSeed:nonce, serverSeed)"
                }), e("p", {
                    children: "Example: 6b5124897c3c48d0e46cc9249f08c7e560792459f1bad1171224643b5d2be231"
                }), o("ol", {
                    className: "special",
                    children: [e("li", {
                        children: "Take a random value in the 2^52 range, namely 16^13, i.e. a 13-bit hexadecimal number (because the hash value is hexadecimal, 2^52 === 16^13)6b5124897c3c4 (6b5124897c3c4 equals 1887939992208324 in the decimal system)."
                    }), e("li", {
                        children: "Distribute the random value to 0~1, by dividing it by the maximum value of 13 fs, namely 6b5124897c3c4/fffffffffffff. Given the discrete random nature of the hash value, we then can think that any hash value can be transformed into a random number of 0~1 (fffffffffffff is equal to 45035996270496 in the decimal system) 1887939992208324/4503599627370496 = 0.419206889692064."
                    }), o("li", {
                        children: ["Make the house edge 1%. Further to calculate 99/(1-X), where X is the random value calculated at Step 2. When X is 0, the result is 99; when X is 1, the result is positive infinite; when X is 0.01, the result is 100; when X is less than 0.01, the result is less than 100. ", e("p", {
                            children: "99/(1-0.419206889692064) = 170.45656748150867"
                        })]
                    }), o("li", {
                        children: ["All values less than 100 will be set to 100. In other words, there is a probability of 1% that 100 will appear. Round off the number and divide it by 100 to get the final result.", e("p", {
                            children: "170/100 = 1.70"
                        })]
                    })]
                }), e("br", {}), e("p", {
                    children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                }), e("p", {}), e("p", {
                    children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                }), e("p", {
                    children: "We put our \u201Ccards on the table.\u201D "
                }), e("p", {
                    children: "Good luck!"
                })]
            })]
        })
    })
}
const _e = (s, a, t) => {
        let n = Ue.config.validateLink + "?s=" + s + "&c=" + a + "&n=" + t;
        window.open(n)
    },
    Xe = y.withSingleDetail({
        onValidate: _e,
        result: ({
            betLog: s
        }) => {
            const a = f(),
                {
                    payout: t
                } = s.bv,
                n = s.gv / 100,
                i = 99 / t,
                l = t / 100;
            return o(le, {
                className: "rt_items",
                children: [o("div", {
                    className: "item-wrap",
                    children: [o("div", {
                        className: "item-num",
                        children: [e(B, {
                            className: "result",
                            name: "Result"
                        }), a("common.result")]
                    }), e("div", {
                        className: "item-desc",
                        children: n
                    })]
                }), o("div", {
                    className: "item-wrap",
                    children: [o("div", {
                        className: "item-num",
                        children: [e(B, {
                            className: "bettype",
                            name: "Bet"
                        }), a("common.bet")]
                    }), e("div", {
                        className: "item-desc",
                        children: o("span", {
                            className: "mthan",
                            children: [">=", l]
                        })
                    })]
                }), o("div", {
                    className: "item-wrap",
                    children: [o("div", {
                        className: "item-num",
                        children: [e(B, {
                            className: "chance",
                            name: "Chance"
                        }), a("common.chance")]
                    }), e("div", {
                        className: "item-desc",
                        children: (i * 100).toFixed(2) + "%"
                    })]
                })]
            })
        }
    });
var Qe = Xe;
export {
    ue as Bankroll, Qe as Detail, Ke as Fairness, Ue as Game
};
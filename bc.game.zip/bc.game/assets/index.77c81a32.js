var V1 = Object.defineProperty,
    j1 = Object.defineProperties;
var z1 = Object.getOwnPropertyDescriptors;
var J = Object.getOwnPropertySymbols;
var p1 = Object.prototype.hasOwnProperty,
    b1 = Object.prototype.propertyIsEnumerable;
var l1 = (o, t, e) => t in o ? V1(o, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : o[t] = e,
    M = (o, t) => {
        for (var e in t || (t = {})) p1.call(t, e) && l1(o, e, t[e]);
        if (J)
            for (var e of J(t)) b1.call(t, e) && l1(o, e, t[e]);
        return o
    },
    x = (o, t) => j1(o, z1(t));
var i1 = (o, t) => {
    var e = {};
    for (var n in o) p1.call(o, n) && t.indexOf(n) < 0 && (e[n] = o[n]);
    if (o != null && J)
        for (var n of J(o)) t.indexOf(n) < 0 && b1.call(o, n) && (e[n] = o[n]);
    return e
};
var A = (o, t, e) => (l1(o, typeof t != "symbol" ? t + "" : t, e), e);
import {
    y as f,
    u as q,
    a as s,
    D as a1,
    dx as A1,
    j as r,
    S as B1,
    o as N,
    l as B,
    cS as U,
    r as b,
    du as w,
    ao as m1,
    a5 as R,
    F as K,
    A as X,
    a7 as F,
    ax as q1,
    g as C1,
    h as f1,
    k as k1,
    c0 as L1,
    J as V,
    dA as U1,
    s as k,
    aO as G,
    di as K1,
    a$ as J1,
    dk as Y1,
    dl as Q1,
    dj as X1,
    ea as ee,
    b as e1,
    t as M1,
    q as j,
    e9 as te,
    dy as se,
    dG as ne,
    dY as oe,
    eb as ae,
    dC as ce,
    dD as le,
    dZ as ie,
    dE as re,
    dp as z,
    bN as x1,
    d_ as ue,
    eu as g1,
    ba as me,
    bb as I,
    dr as Y,
    dR as y1,
    dh as de,
    G as O,
    aH as v1,
    d4 as he,
    a2 as pe,
    bo as be,
    cD as fe,
    dH as ge,
    cJ as ye,
    x as ve,
    am as W,
    as as Ne,
    df as we,
    at as Se,
    n as Ae
} from "./index.28e31dff.js";
import {
    l as Q
} from "./lodash.f3c7da90.js";
import {
    s as t1
} from "./index.dd8128e8.js";
import {
    G as H
} from "./index.06a59a68.js";
var Be = "/assets/chip_auto.f6cec1e6.png",
    Ce = "/assets/chip_K.1b9d603e.png",
    ke = "/assets/chip_M.bf27b6c5.png",
    Le = "/assets/chip_B.dc50bb1b.png",
    Me = "/assets/chip_T.6cb1dab7.png",
    xe = "/assets/firework.1fcf372c.png",
    Re = "/assets/circle.6e2a7b9c.svg",
    Ie = "/assets/down.5cb63abe.svg";
const d1 = {
        chip_auto: Be,
        chip_K: Ce,
        chip_M: ke,
        chip_B: Le,
        chip_T: Me,
        firework: xe,
        circle: Re,
        down: Ie
    },
    R1 = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26],
    s1 = 37,
    I1 = [{
        label: "Voisins",
        value: 0,
        desc: "(Neighbors of zero)"
    }, {
        label: "Orphelins",
        value: 1,
        desc: "(Orphans)"
    }, {
        label: "Tiers",
        value: 2,
        desc: "(Third of the wheel)"
    }, {
        label: "Zero",
        value: 3,
        desc: "(Zero game)"
    }],
    n1 = [
        [{
            action: {
                label: "v-h",
                nums: [0, 2, 3],
                pos: ["1/span 2", "1/span 2"],
                type: "3",
                column: "2",
                isHidden: !0
            },
            odds: 2
        }, {
            action: {
                label: "v",
                nums: [4, 7],
                pos: [3, "3/span 2"],
                type: "1",
                column: "7"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [12, 15],
                pos: [1, "5/span 2"],
                type: "1",
                column: "15"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [18, 21],
                pos: [1, "7/span 2"],
                type: "1",
                column: "21"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [19, 22],
                pos: [3, "8/span 2"],
                type: "1",
                column: "22"
            },
            odds: 1
        }, {
            action: {
                label: "v-h",
                nums: [25, 26, 28, 29],
                pos: ["2/span 2", "10/span 2"],
                type: "4",
                column: "28",
                isHidden: !0
            },
            odds: 2
        }, {
            action: {
                label: "v",
                nums: [32, 35],
                pos: [2, "12/span 2"],
                type: "1",
                column: "35"
            },
            odds: 1
        }],
        [{
            action: {
                label: "1",
                nums: [1],
                pos: [2, 3],
                type: "0",
                column: "1"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [6, 9],
                pos: [1, "3/span 2"],
                type: "1",
                column: "9"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [14, 17],
                pos: [2, "6/span 2"],
                type: "1",
                column: "17"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [17, 20],
                pos: [2, "7/span 2"],
                type: "1",
                column: "20"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [31, 34],
                pos: [3, "12/span 2"],
                type: "1",
                column: "34"
            },
            odds: 1
        }],
        [{
            action: {
                label: "v",
                nums: [5, 8],
                pos: [2, "3/span 2"],
                type: "1",
                column: "8"
            },
            odds: 1
        }, {
            action: {
                label: "h",
                nums: [10, 11],
                pos: ["2/span 2", 5],
                type: "2",
                column: "10"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [13, 16],
                pos: [3, "6/span 2"],
                type: "1",
                column: "16"
            },
            odds: 1
        }, {
            action: {
                label: "h",
                nums: [23, 24],
                pos: ["1/span 2", 3],
                type: "2",
                column: "23"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [27, 30],
                pos: [1, "10/span 2"],
                type: "1",
                column: "30"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [33, 36],
                pos: [1, "12/span 2"],
                type: "1",
                column: "36"
            },
            odds: 1
        }],
        [{
            action: {
                label: "v",
                nums: [0, 3],
                pos: [1, "1/span 2"],
                type: "1",
                column: "3"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [12, 15],
                pos: [1, "5/span 2"],
                type: "1",
                column: "15"
            },
            odds: 1
        }, {
            action: {
                label: "26",
                nums: [26],
                pos: [2, 10],
                type: "0",
                column: "26"
            },
            odds: 1
        }, {
            action: {
                label: "v",
                nums: [32, 35],
                pos: [2, "12/span 2"],
                type: "1",
                column: "35"
            },
            odds: 1
        }]
    ],
    v = [
        [{
            num: 0,
            type: "green",
            pos: [0, 0]
        }],
        [{
            num: 3,
            type: "red",
            pos: [1, 2]
        }, {
            num: 6,
            type: "black",
            pos: [1, 3]
        }, {
            num: 9,
            type: "red",
            pos: [1, 4]
        }, {
            num: 12,
            type: "red",
            pos: [1, 5]
        }, {
            num: 15,
            type: "black",
            pos: [1, 6]
        }, {
            num: 18,
            type: "red",
            pos: [1, 7]
        }, {
            num: 21,
            type: "red",
            pos: [1, 8]
        }, {
            num: 24,
            type: "black",
            pos: [1, 9]
        }, {
            num: 27,
            type: "red",
            pos: [1, 10]
        }, {
            num: 30,
            type: "red",
            pos: [1, 11]
        }, {
            num: 33,
            type: "black",
            pos: [1, 12]
        }, {
            num: 36,
            type: "red",
            pos: [1, 13]
        }],
        [{
            num: 2,
            type: "black",
            pos: [2, 2]
        }, {
            num: 5,
            type: "red",
            pos: [2, 3]
        }, {
            num: 8,
            type: "black",
            pos: [2, 4]
        }, {
            num: 11,
            type: "black",
            pos: [2, 5]
        }, {
            num: 14,
            type: "red",
            pos: [2, 6]
        }, {
            num: 17,
            type: "black",
            pos: [2, 7]
        }, {
            num: 20,
            type: "black",
            pos: [2, 8]
        }, {
            num: 23,
            type: "red",
            pos: [2, 9]
        }, {
            num: 26,
            type: "black",
            pos: [2, 10]
        }, {
            num: 29,
            type: "black",
            pos: [2, 11]
        }, {
            num: 32,
            type: "red",
            pos: [2, 12]
        }, {
            num: 35,
            type: "black",
            pos: [2, 13]
        }],
        [{
            num: 1,
            type: "red",
            pos: [3, 2]
        }, {
            num: 4,
            type: "black",
            pos: [3, 3]
        }, {
            num: 7,
            type: "red",
            pos: [3, 4]
        }, {
            num: 10,
            type: "black",
            pos: [3, 5]
        }, {
            num: 13,
            type: "black",
            pos: [3, 6]
        }, {
            num: 16,
            type: "red",
            pos: [3, 7]
        }, {
            num: 19,
            type: "red",
            pos: [3, 8]
        }, {
            num: 22,
            type: "black",
            pos: [3, 9]
        }, {
            num: 25,
            type: "red",
            pos: [3, 10]
        }, {
            num: 28,
            type: "black",
            pos: [3, 11]
        }, {
            num: 31,
            type: "black",
            pos: [3, 12]
        }, {
            num: 34,
            type: "red",
            pos: [3, 13]
        }]
    ],
    _e = [{
        label: "2:1",
        nums: [3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36],
        pos: [1, 14],
        type: "row",
        column: "1"
    }, {
        label: "2:1",
        nums: [2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35],
        pos: [2, 14],
        type: "row",
        column: "2"
    }, {
        label: "2:1",
        nums: [1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34],
        pos: [3, 14],
        type: "row",
        column: "3"
    }, {
        label: "1ST 12",
        nums: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        pos: [4, "2/span 4"],
        type: "dozen",
        column: "1"
    }, {
        label: "2ND 12",
        nums: [13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24],
        pos: [4, "span 4"],
        type: "dozen",
        column: "2"
    }, {
        label: "3RD 12",
        nums: [25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36],
        pos: [4, "span 4"],
        type: "dozen",
        column: "3"
    }, {
        label: "1 TO 18",
        nums: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18],
        pos: [5, "2/span 2"],
        type: "low",
        column: ""
    }, {
        label: "EVEN",
        nums: [2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36],
        pos: [5, "span 2"],
        type: "even",
        column: ""
    }, {
        label: "red",
        nums: [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36],
        pos: [5, "span 2"],
        type: "red",
        column: ""
    }, {
        label: "black",
        nums: [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35],
        pos: [5, "span 2"],
        type: "black",
        column: ""
    }, {
        label: "ODD",
        nums: [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35],
        pos: [5, "span 2"],
        type: "odds",
        column: ""
    }, {
        label: "19 TO 36",
        nums: [19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36],
        pos: [5, "span 2"],
        type: "high",
        column: ""
    }];

function De() {
    const o = [];
    return [1, 2, 3].map((t, e) => {
        Array(11).fill(0).map((n, a) => {
            const c = v[t][a].num,
                l = v[t][a + 1].num;
            o.push({
                label: "v",
                nums: [c, l],
                pos: [e + 1, `${a+2}/span 2`],
                type: "1",
                column: l.toString(),
                isHidden: !0
            })
        })
    }), [1, 2].forEach((t, e) => {
        Array(12).fill(0).forEach((n, a) => {
            const c = v[t][a].num,
                l = v[t + 1][a].num;
            o.push({
                label: "h",
                nums: [c, l],
                pos: [`${t}/span 2`, a + 2],
                type: "2",
                column: l.toString(),
                isHidden: !0
            })
        })
    }), Array(12).fill(0).forEach((t, e) => {
        const n = v[1][e].num,
            a = v[2][e].num,
            c = v[3][e].num;
        o.push({
            label: "t",
            nums: [n, a, c],
            pos: [1, e + 2],
            type: "3",
            column: c.toString(),
            isHidden: !0
        })
    }), [1, 2].forEach((t, e) => {
        Array(11).fill(0).forEach((n, a) => {
            const c = v[t][a].num,
                l = v[t][a + 1].num,
                u = v[t + 1][a].num,
                i = v[t + 1][a + 1].num;
            o.push({
                label: "v-h",
                nums: [c, l, u, i],
                pos: [`${t}/span 2`, `${a+2}/span 2`],
                type: "4",
                column: i.toString(),
                isHidden: !0
            })
        })
    }), Array(11).fill(0).forEach((t, e) => {
        const n = v[1][e].num,
            a = v[1][e + 1].num,
            c = v[2][e].num,
            l = v[2][e + 1].num,
            u = v[3][e].num,
            i = v[3][e + 1].num;
        o.push({
            label: "t-d",
            nums: [n, a, c, l, u, i],
            pos: [1, `${e+2}/span 2`],
            type: "5",
            column: i.toString(),
            isHidden: !0
        })
    }), o.push({
        label: "v",
        nums: [0, 3],
        pos: [1, "1/span 2"],
        type: "1",
        column: "3",
        isHidden: !0
    }), o.push({
        label: "v",
        nums: [0, 2],
        pos: [2, "1/span 2"],
        type: "1",
        column: "2",
        isHidden: !0
    }), o.push({
        label: "v",
        nums: [0, 1],
        pos: [3, "1/span 2"],
        type: "1",
        column: "1",
        isHidden: !0
    }), o.push({
        label: "v-h",
        nums: [0, 2, 3],
        pos: ["1/span 2", "1/span 2"],
        type: "3",
        column: "2",
        isHidden: !0
    }), o.push({
        label: "v-h",
        nums: [0, 1, 2],
        pos: ["2/span 2", "1/span 2"],
        type: "3",
        column: "0",
        isHidden: !0
    }), o
}

function Ee() {
    const o = De();
    return _e.concat(o)
}

function _1(o, t) {
    if (o.length !== t.length) return !1;
    const e = o.sort((a, c) => a - c),
        n = t.sort((a, c) => a - c);
    return e.join("") === n.join("")
}

function He(o) {
    const t = [],
        e = o.round(),
        n = String(e),
        a = n.length;
    return Array(a).fill(1).forEach((c, l) => {
        const u = new f(n[l]),
            i = u.mul(10 ** (a - l - 1)),
            p = D1(i).imgType;
        i.gt(0) && Array(u.toNumber()).fill(0).forEach((m, d) => {
            const g = "chip_" + p;
            t.push(d1[g])
        })
    }), t
}

function D1(o) {
    let t = 1,
        e = "auto";
    o.gte(1e12) ? (t = 1e12, e = "T") : o.gte(1e9) ? (t = 1e9, e = "B") : o.gte(1e6) ? (t = 1e6, e = "M") : o.gte(1e3) && (t = 1e3, e = "K");
    const a = o.div(t).floor();
    return t === 1 ? {
        chip: String(o),
        imgType: e
    } : {
        chip: a + e,
        imgType: e
    }
}

function N1(o) {
    return R1.findIndex(t => t === o)
}

function c2(o) {
    return new f(.1).pow(o)
}

function E1(o) {
    return o.toFixed(18).replace(/\.?0+$/, "")
}

function H1(o) {
    return o.reduce((t, e) => t.concat(e.action.nums), [])
}
const Ze = function() {
    const t = q();
    return s(a1, {
        title: t("common.game_intro"),
        children: s(A1, {
            children: r("div", {
                className: "item",
                children: [s("h2", {
                    children: " What Is Roulette? "
                }), s("div", {
                    className: "help-content",
                    children: r("p", {
                        children: [`Roulette is a very popular casino game that was named after the French word "roulette", which means as much as 'little wheel'. The rules are relatively simple and easy-to-understand. However, roulette offers a surprisingly high level of depth for serious betters. We, at CryptoGames are offering a variant called "European roulette", which is being played on a 37-number wheel, with one zero only. The payout table is the same as in American roulette. However, with one zero the house edge is being cut down by half, resulting in a low `, s("span", {
                            className: "cl-primary",
                            children: "2.70%"
                        }), ", in comparison to the 5.40% of the american variant."]
                    })
                })]
            })
        })
    })
};
const Te = [{
        label: "Odd Numbers (Impair)",
        odds: "1:1"
    }, {
        label: "Even Numbers (Pair)",
        odds: "1:1"
    }, {
        label: "Black Numbers (Noir)",
        odds: "1:1"
    }, {
        label: "Red Numbers (Rouge)",
        odds: "1:1"
    }, {
        label: "1 to 18 (Low, Manque)",
        odds: "1:1"
    }, {
        label: "19 to 36 (High, Passe)",
        odds: "1:1"
    }, {
        label: "1 to 12 (P12, first dozen)",
        odds: "2:1"
    }, {
        label: "13 to 24 (M12, second dozen)",
        odds: "2:1"
    }, {
        label: "25 to 36 (D12, third dozen)",
        odds: "2:1"
    }, {
        label: "Column bet",
        odds: "2:1"
    }, {
        label: "Single Number / Straight",
        odds: "35:1"
    }, {
        label: "Split (2 numbers)",
        odds: "17:1"
    }, {
        label: "Street (3 numbers)",
        odds: "11:1"
    }, {
        label: "Corner / Square (4 numbers)",
        odds: "8:1"
    }, {
        label: "Six line / Double Street (6 numbers)",
        odds: "5:1"
    }],
    $e = function() {
        return s(a1, {
            title: "Payouts",
            children: s(B1, {
                className: Pe,
                children: Te.map((t, e) => r("div", {
                    className: "payout-item",
                    children: [s("p", {
                        className: "payout-label",
                        children: t.label
                    }), s("p", {
                        className: "payout-odds",
                        children: t.odds
                    })]
                }, e.toString()))
            })
        })
    },
    Pe = "g1nb88kc";
const Ge = N(function({
        chip: t
    }) {
        const e = D1(t),
            a = He(t).slice(0, 3);
        return s("div", {
            className: B(Oe, "chip-img"),
            title: t + " chips",
            children: s("div", {
                className: "chip-img-wrap",
                children: s("div", {
                    className: "chips-btn",
                    children: a.map((c, l) => {
                        const u = -l * 15,
                            i = l === a.length - 1;
                        return s("div", {
                            className: "chip-img-item",
                            style: {
                                transform: `translate(0%, ${u}%)`
                            },
                            children: s("div", {
                                className: "bg",
                                style: {
                                    backgroundImage: `url(${c})`
                                },
                                children: i && s("div", {
                                    className: U("chip-num", "len-" + e.chip.length),
                                    children: s("p", {
                                        children: e.chip
                                    })
                                })
                            })
                        }, String(l))
                    })
                })
            })
        })
    }),
    Oe = "cnqig85",
    r1 = new f(0),
    Z1 = N(function(p) {
        var m = p,
            {
                onClick: t,
                onContextMenu: e,
                className: n,
                children: a,
                action: c,
                row: l,
                cloumn: u
            } = m,
            i = i1(m, ["onClick", "onContextMenu", "className", "children", "action", "row", "cloumn"]);
        const d = b.exports.useRef(!1),
            g = b.exports.useRef(null),
            h = w(),
            [S, D] = m1({
                showChip: !1,
                chip: r1,
                isHover: !1,
                isError: !1
            });
        b.exports.useEffect(() => {
            if (h.betChipList.length > 0) {
                const E = h.betChipList.slice(-1)[0].betInfo.findIndex(P => _1(P.action.nums, c.nums));
                if (E >= 0) {
                    const P = h.getBetAmountInfoByList();
                    D({
                        showChip: !0,
                        chip: P[E].chips
                    })
                } else D({
                    showChip: !1,
                    chip: r1
                })
            } else S.showChip && D({
                showChip: !1,
                chip: r1
            })
        }, [h.amount]), b.exports.useEffect(() => {
            if (c.type === "0") {
                const L = c.nums[0],
                    E = h.hoverNumList.indexOf(L) >= 0;
                D({
                    isHover: E
                })
            }
        }, [h.hoverNumList, h.isSlotsError]), b.exports.useEffect(() => {
            if (c.type === "0") {
                const L = c.nums[0],
                    E = h.warningNumList.indexOf(L) >= 0,
                    P = h.isSlotsError && E;
                D({
                    isError: P
                })
            }
        }, [h.isSlotsError, h.warningNumList]);
        const c1 = L => {
                d.current || (d.current = !0, t && t(L), h.changeBetChipList(c, "add", h.chip.value), g.current = setTimeout(() => {
                    d.current = !1
                }, 100))
            },
            W1 = L => {
                L.preventDefault(), e && e(L), h.changeBetChipList(c, "sub", h.chip.value)
            };
        b.exports.useEffect(() => g.current && clearTimeout(g.current), []);
        const F1 = c.nums.length === 1 && c.nums[0] === h.betResult.result;
        return s("button", x(M({}, i), {
            onContextMenu: W1,
            onClick: c1,
            className: U(n, "chip-item", S.isError && "slot-error", S.isHover && "slot-hover", F1 && "result"),
            onMouseEnter: () => h.setHoverList(c.nums),
            onMouseLeave: () => h.setHoverList([]),
            style: {
                gridRow: l,
                gridColumn: u
            },
            children: r("div", {
                className: "inner-wrap",
                children: [s("span", {
                    children: a
                }), S.showChip && s(Ge, {
                    chip: S.chip
                })]
            })
        }))
    });
const T1 = N(function({
        isSmall: t
    }) {
        return r("div", {
            className: B(je, "chip-btn-btns-wrap"),
            children: [s(Fe, {}), s(Ve, {}), t && s(We, {})]
        })
    }),
    We = R.memo(function() {
        const o = w();
        return r(K, {
            children: [s("button", {
                className: "div-action preset-action",
                onClick: () => o.halfAndDoubleAction("half"),
                children: s("span", {
                    children: "/2"
                })
            }), s("button", {
                className: "mul-action preset-action",
                onClick: () => o.halfAndDoubleAction("double"),
                children: s("span", {
                    children: "x2"
                })
            }), s("button", {
                className: "undo-action preset-action",
                onClick: () => o.betBackFn(),
                children: s(X, {
                    name: "Undo"
                })
            }), s("button", {
                className: "clear-action preset-action",
                onClick: () => o.betBackFn(!0),
                children: s(X, {
                    name: "Clear"
                })
            })]
        })
    }),
    Fe = R.memo(function() {
        return s(K, {
            children: v.map((t, e) => t.map((n, a) => {
                const l = n.type === "green" ? "0" : n.pos[0] + "-" + n.pos[1];
                return s(Z1, {
                    className: U("slot", "slot-" + n.type, "slot-" + l),
                    row: n.pos[0],
                    cloumn: n.pos[1],
                    action: {
                        label: String(n.num),
                        nums: [n.num],
                        pos: n.pos,
                        type: "0",
                        column: String(n.num)
                    },
                    children: n.num
                }, "slots-" + a.toString())
            }))
        })
    }),
    Ve = R.memo(function() {
        const t = Ee();
        return s(K, {
            children: t.map((e, n) => {
                const a = e.label === "red" || e.label === "black",
                    c = e.isHidden,
                    l = a || c;
                return s(Z1, {
                    className: U("action", l && "action-" + e.label, c && "hidden"),
                    row: e.pos[0],
                    cloumn: e.pos[1],
                    action: e,
                    children: l ? "" : e.label
                }, "action-" + n.toString())
            })
        })
    }),
    je = "r1atizpx";
const ze = R.memo(function() {
        const t = w();
        return r("div", {
            className: B(qe, "chip-actions"),
            children: [s(F, {
                title: "Half",
                children: s("button", {
                    onClick: () => t.halfAndDoubleAction("half"),
                    children: "/2"
                })
            }), s(F, {
                title: "Double",
                children: s("button", {
                    onClick: () => t.halfAndDoubleAction("double"),
                    children: "x2"
                })
            }), s(F, {
                title: "Undo",
                children: s("button", {
                    onClick: () => t.betBackFn(),
                    children: s(X, {
                        className: "undo",
                        name: "Undo"
                    })
                })
            }), s(F, {
                title: "Clear",
                children: s("button", {
                    onClick: () => t.betBackFn(!0),
                    children: s(X, {
                        name: "Clear",
                        className: "clear-icon"
                    })
                })
            })]
        })
    }),
    qe = "cv34qy",
    Ue = R.memo(function(n) {
        var a = n,
            {
                fill: t
            } = a,
            e = i1(a, ["fill"]);
        return s("svg", x(M({
            className: "down-svg",
            version: "1.1",
            xmlns: "http://www.w3.org/2000/svg",
            width: "36",
            height: "24",
            viewBox: "0 0 36 24"
        }, e), {
            children: r("g", {
                fill: t,
                children: [s("path", {
                    d: "M0 15.162v-5.65c.1-.425.223-.846.297-1.275.112-.647.409-1.207.746-1.754.11-.178.25-.171.431-.112.417.137.835.323 1.264.36.735.063 1.488.057 2.034-.592.031-.036.087-.05.123-.083.518-.479 1.076-.923 1.452-1.532.065-.104.065-.29.02-.412-.13-.363-.454-.506-.796-.615-.265-.084-.527-.175-.791-.264l-.009-.088c.118-.065.234-.133.353-.196.533-.286 1.057-.59 1.602-.85.449-.214.919-.385 1.386-.556.63-.231 1.262-.459 1.902-.66.412-.129.835-.224 1.26-.306a94.655 94.655 0 0 1 2.993-.544c.502-.08.485-.047.536.46.022.224.095.51.25.64.385.324.87.434 1.379.43.65-.006 1.3.02 1.95-.005.693-.025 1.398.099 2.077-.152.37-.137.717-.292.766-.75.014-.14.015-.28.012-.42-.004-.169.058-.253.237-.228.181.026.363.047.545.07 2.064.26 4.076.732 6.022 1.477 1.074.411 2.095.927 3.09 1.5.056.033.09.105.136.159-.06.035-.118.077-.181.104-.352.147-.719.264-1.056.44-.427.223-.5.645-.175.982.514.53 1.038 1.053 1.584 1.55.183.166.434.296.675.354.778.187 1.533.037 2.269-.245.35-.134.442-.106.63.205a6.19 6.19 0 0 1 .932 3.148c.003.12.036.24.055.36v4.2c-.02.13-.045.26-.058.39-.06.59-.41 1.016-.799 1.419-.005.006-.03-.006-.075-.016-.006-.096-.017-.2-.017-.305-.002-.908-.006-1.816.001-2.724.002-.224-.068-.341-.303-.365-.155-.016-.306-.075-.458-.116-.368-.1-.73-.235-1.105-.296-.72-.118-1.362.059-1.9.585-.415.407-.849.796-1.288 1.177-.447.388-.464.869-.021 1.203.04.03.082.06.128.078.364.139.736.258 1.091.417.207.092.415.219.567.382.07.077.01.277.008.42v.05c.008.7.004 1.4.03 2.099.01.302-.114.486-.365.62-.285.154-.567.313-.847.475a19.309 19.309 0 0 1-3.102 1.427c-1.899.69-3.859 1.126-5.857 1.398-.343.046-.38.023-.376-.32.011-1.324.03-2.647.034-3.97a.649.649 0 0 0-.142-.356c-.323-.43-.808-.51-1.294-.517a149.3 149.3 0 0 0-3.671-.005c-.254.002-.52.04-.755.13-.287.11-.573.291-.624.627-.052.344-.051.697-.049 1.046.007 1.066.025 2.131.04 3.197.002.15-.058.213-.213.19-.369-.055-.74-.101-1.11-.154a25.19 25.19 0 0 1-3.814-.862 22.016 22.016 0 0 1-5.078-2.304.554.554 0 0 1-.231-.329 3.716 3.716 0 0 1-.048-.739 53.77 53.77 0 0 1 .049-1.945c.005-.1.096-.232.185-.284.063-.037.228.003.283.065.325.37.754.551 1.198.716a.53.53 0 0 1 .24.156c.155.212.369.203.586.177.05-.006.127-.072.131-.117.005-.042-.063-.123-.11-.133-.263-.057-.49-.175-.73-.29a4.392 4.392 0 0 1-.824-.531c-.066-.052-.104-.14-.155-.21.087-.055.171-.148.262-.155.086-.006.187.066.264.127.062.049.084.158.15.192.076.04.18.028.273.039-.028-.082-.033-.19-.09-.243-.234-.218-.243-.317.048-.459.268-.131.377-.365.487-.607a.223.223 0 0 0-.012-.182c-.242-.379-.57-.678-.908-.97-.225-.193-.44-.398-.659-.6-.188-.172-.35-.389-.564-.515-.605-.353-1.268-.376-1.935-.218-.371.089-.731.223-1.1.326-.401.113-.405.108-.405.52 0 .916.003 1.832.001 2.748 0 .085-.024.17-.036.254l-.068.021c-.067-.087-.13-.179-.202-.261-.217-.243-.439-.482-.658-.723Zm17.986 1.143c.79-.047 1.582-.062 2.366-.148 1.855-.203 3.66-.62 5.372-1.382 1.36-.605 2.61-1.38 3.55-2.565 1.12-1.412 1.389-2.942.56-4.593-.376-.75-.935-1.356-1.578-1.883-1.406-1.153-3.038-1.851-4.774-2.32-3.03-.818-6.1-.92-9.188-.4-1.852.313-3.628.866-5.26 1.821-1.126.66-2.126 1.462-2.788 2.62-.47.821-.67 1.699-.518 2.641.172 1.062.722 1.924 1.47 2.666 1.255 1.243 2.792 2.01 4.445 2.55 2.057.672 4.176.982 6.343.993Zm-9.683 1.254-.038.108c.141.141.294.267.521.237.046-.006.1-.055.12-.098.01-.024-.038-.101-.072-.112-.175-.053-.354-.091-.531-.135Zm1.32.716.254-.175c-.107-.06-.209-.143-.324-.174-.056-.014-.137.07-.207.11l.278.239Zm1.469.145c-.17-.177-.35-.183-.535-.117-.025.009-.027.173-.018.176.18.045.363.082.553-.06Zm-3.49-1.101-.015.13.316.022.01-.121-.312-.031Z"
                }), s("path", {
                    d: "M8.303 17.559c.177.044.356.082.53.135.035.01.083.088.072.112-.018.043-.073.092-.119.098-.227.03-.38-.096-.521-.237l.038-.108Zm1.32.716-.277-.239c.07-.04.151-.124.207-.11.115.03.217.113.324.174l-.253.175Zm1.469.145c-.19.14-.374.104-.553.059-.01-.003-.007-.167.019-.176.184-.066.364-.06.534.117Zm-3.49-1.101.31.03-.01.122-.315-.022.014-.13ZM17.892 15.26c-2.23-.018-4.576-.388-6.792-1.401-.962-.44-1.844-1.002-2.574-1.78-1.499-1.594-1.498-3.545.004-5.138.876-.93 1.957-1.545 3.126-2.018 1.812-.732 3.709-1.072 5.654-1.143 2.481-.09 4.907.212 7.228 1.142 1.163.465 2.24 1.075 3.109 1.997.695.738 1.16 1.584 1.147 2.634-.012 1.01-.466 1.826-1.134 2.539-.873.931-1.957 1.544-3.128 2.013-2.07.83-4.234 1.15-6.64 1.156ZM5.733 16.763c.396.08.776.262 1.099.504.13.097.253-.12.126-.216a2.947 2.947 0 0 0-1.159-.529c-.157-.032-.224.21-.066.241Z"
                }), s("path", {
                    d: "M6.443 16.957c.19.068.37.155.55.245l.097-.228a6.644 6.644 0 0 1-.807-.258c-.08-.03-.153.046-.158.12-.076 1.13 1.421 1.094 2.19 1.093.094 0 .156-.106.107-.188-.196-.328-.626-.408-.948-.56l-.03.228c.474-.068.877.284 1.321.387l.067-.241c-.282-.06-.567-.1-.84-.194l-.066.241c.432.073.845.216 1.259.355l.066-.241c-.395-.076-.76-.249-1.162-.295-.122-.014-.148.14-.089.213.207.258.54.38.863.392.142.005.17-.211.033-.246a3.719 3.719 0 0 1-.42-.129l-.066.241c.575.11 1.198.009 1.745.246l.063-.233c-.283.02-.557-.056-.839-.065-.134-.004-.157.166-.063.233.133.096.273.183.42.258l.126-.215a7.671 7.671 0 0 1-.678-.355l-.096.228c.331.108.633.288.968.387l.066-.24c-.204-.057-.411-.099-.613-.162-.142-.045-.208.152-.096.228.718.494 1.61.565 2.451.432.112-.017.115-.178.03-.228-.463-.274-.973-.187-1.482-.27-.156-.027-.224.193-.066.24.199.06.385.157.58.226l.067-.241c-.12-.037-.234-.092-.355-.129-.154-.047-.22.194-.066.241.12.037.234.092.355.13.155.047.216-.189.066-.242-.196-.07-.382-.167-.58-.226l-.067.241c.477.079.99-.01 1.422.246l.03-.229c-.777.123-1.597.048-2.259-.407l-.096.229c.201.063.409.105.613.161.156.043.22-.195.066-.24-.335-.1-.636-.28-.968-.388-.136-.044-.218.16-.096.229.222.126.444.25.677.354.144.065.272-.14.127-.215a3.378 3.378 0 0 1-.42-.258l-.063.232c.282.01.555.085.839.065.11-.008.187-.179.063-.233-.578-.25-1.199-.155-1.804-.27-.16-.031-.217.183-.067.24.138.053.277.094.42.13l.033-.246a.908.908 0 0 1-.686-.318l-.088.213c.377.043.724.215 1.096.286.157.03.22-.19.066-.241-.414-.139-.826-.282-1.258-.355-.158-.026-.22.188-.066.241.272.095.557.134.838.194.157.033.224-.205.067-.241-.509-.118-.907-.466-1.454-.387-.106.015-.122.184-.03.228.27.128.696.199.859.471l.108-.188c-.62.001-2.003.095-1.94-.843l-.158.121c.265.1.53.193.806.258.134.031.228-.163.097-.228-.2-.1-.4-.196-.61-.271-.153-.054-.218.187-.067.241Z"
                }), s("path", {
                    d: "M5.444 16.703c.532.05.863.567 1.353.738l.067-.241c-.345-.079-.528-.356-.74-.614-.19-.232-.412-.383-.713-.423-.16-.021-.157.23 0 .25.33.044.514.323.706.562.182.224.394.4.68.466.159.036.218-.189.067-.241-.527-.184-.833-.692-1.42-.747-.161-.015-.16.235 0 .25Z"
                }), s("path", {
                    d: "M5.336 16.351c.021.047.028.117-.02.152-.055.04-.082.107-.045.17.032.055.116.086.171.046.167-.122.193-.312.11-.494-.03-.062-.117-.077-.172-.045-.063.037-.073.11-.044.171Z"
                }), s("path", {
                    d: "m5.29 16.287-.193.233a.175.175 0 0 0 0 .214.111.111 0 0 0 .177 0l.193-.234a.175.175 0 0 0 0-.213.111.111 0 0 0-.176 0Zm.523-.407c-.073.238-.147.47-.171.724-.019.193.232.19.25 0 .02-.223.098-.435.162-.644.056-.183-.186-.261-.241-.08Z"
                }), s("path", {
                    d: "M6.195 15.79c-.128.111-.236.243-.367.35-.052.044-.044.133 0 .177.052.052.124.043.177 0 .13-.107.24-.239.367-.35.122-.106-.056-.282-.177-.177Z"
                }), s("path", {
                    d: "M6.004 15.904c-.105.057-.196.145-.288.22a3.551 3.551 0 0 1-.163.13 1.076 1.076 0 0 1-.073.049c-.065.04.006-.016.061.063-.092-.13-.309-.006-.216.126.11.155.283.032.394-.052.136-.102.26-.238.41-.32.143-.077.016-.292-.125-.216Z"
                }), s("path", {
                    d: "M5.6 16.058a.506.506 0 0 0-.234.109c-.068.05-.13.112-.216.125-.067.01-.104.094-.087.153.02.072.086.098.154.088.178-.027.275-.21.45-.234.067-.009.103-.094.087-.153-.02-.073-.086-.097-.154-.088Z"
                }), s("path", {
                    d: "M5.37 15.988c-.108.048-.195.128-.3.183-.143.075-.016.29.126.216.105-.055.192-.135.3-.183.063-.029.077-.117.045-.172-.037-.063-.109-.072-.17-.044Z"
                }), s("path", {
                    d: "M5.254 15.954c-.072.032-.133.08-.197.125-.065.045-.108.072-.169.011l-.025.197c.08-.036.254-.04.363-.08.161-.056.258-.188.211-.361-.018-.07-.087-.101-.154-.088-.038.008-.064.025-.096.046-.135.088-.01.304.126.216A.104.104 0 0 1 5.35 16l-.154-.088c.008.03.01.028-.005.038-.041.027-.094.037-.141.047-.106.023-.214.029-.313.074-.074.034-.078.144-.025.196.097.097.22.14.352.09.117-.043.203-.137.316-.187.147-.065.02-.28-.126-.216Z"
                }), s("path", {
                    d: "M5.154 15.838c-.174.088-.357.148-.537.22-.124.05-.118.247.033.246.468-.005 1.226-.05 1.538-.453.098-.126-.078-.305-.176-.177-.27.348-.96.376-1.362.38l.033.245c.2-.08.404-.147.597-.245.143-.074.017-.29-.126-.216Z"
                }), s("path", {
                    d: "M5.859 15.55a.948.948 0 0 1-.272.32c-.055.041-.082.108-.045.172.032.054.116.085.171.045.147-.109.277-.249.362-.412.074-.143-.142-.269-.216-.126Z"
                }), s("path", {
                    d: "M5.87 15.47c-.167.09-.28.244-.433.35-.132.092-.007.309.126.217.153-.106.268-.262.433-.35.143-.076.017-.292-.126-.216Z"
                }), s("path", {
                    d: "M5.767 15.575c-.29.049-.47.3-.73.413-.148.064-.02.28.126.216.237-.104.408-.344.67-.388.159-.027.091-.267-.066-.241Z"
                }), s("path", {
                    d: "M5.754 15.538c-.12.086-.232.18-.35.266-.056.04-.082.108-.045.171.032.055.115.085.17.045.12-.086.232-.18.35-.266.056-.04.083-.108.046-.172-.032-.054-.116-.084-.171-.044Z"
                }), s("path", {
                    d: "M5.5 16c.126-.019.245-.065.367-.1.154-.046.088-.287-.067-.242-.122.036-.24.082-.367.1-.067.01-.103.095-.087.154.02.072.086.097.154.087Zm-.308.45c-.191.436-.343.98-.059 1.413.23.351.679.46 1.075.456.876-.008 1.923-.595 1.967-1.557.005-.101-.108-.147-.188-.108-.5.243-.783.77-.958 1.275l.184-.075c-.364-.246-.51-.635-.817-.926-.303-.29-.733-.125-1.06.026l.189.108c-.009-.11-.03-.205-.005-.317.024-.101-.086-.203-.183-.14-.164.104-.336.194-.5.3l.183.14c.055-.186.184-.276.343-.375l-.171-.045c.187.3.263.65.45.95.028.045.088.077.141.058.345-.129.629-.358.93-.563l-.184-.075c.096.38.05.78.046 1.167-.001.161.248.161.25 0 .004-.395.053-.782.146-1.167h-.242c.042.238.046.476.046.717 0 .161.25.161.25 0 0-.264-.009-.523-.054-.783-.022-.124-.214-.115-.241 0a5.48 5.48 0 0 0-.155 1.233h.25c.003-.412.047-.829-.054-1.233-.02-.075-.118-.12-.184-.075-.28.19-.55.418-.87.538l.141.057c-.187-.3-.263-.65-.45-.95-.035-.057-.112-.081-.171-.045-.217.135-.384.273-.457.525-.03.103.09.2.183.141.164-.105.336-.195.5-.3l-.183-.141c-.031.135-.016.247-.005.383.008.1.099.15.188.108.187-.086.41-.19.621-.141.133.03.223.164.296.269.207.296.402.566.707.772.07.048.159-.003.184-.075.154-.446.4-.91.842-1.125l-.188-.108c-.037.804-.933 1.258-1.645 1.305-.319.02-.671-.04-.895-.285-.297-.325-.13-.86.023-1.207.064-.146-.151-.273-.216-.126Z"
                }), s("path", {
                    d: "M7.025 16.562c-.056.616-.197 1.218-.346 1.817-.034.14.152.215.229.096.055-.086.075-.185.112-.28.06-.15-.181-.214-.24-.066-.03.072-.045.154-.088.22l.228.096c.155-.62.297-1.245.355-1.883.015-.16-.236-.159-.25 0Zm.667.313c.198.462.312.954.55 1.4.076.143.292.016.216-.126-.237-.445-.352-.938-.55-1.4-.064-.148-.279-.02-.216.126Zm1.137.12c.097.526-.008 1.134.213 1.63.065.147.28.02.216-.126-.103-.232-.094-.522-.108-.77-.016-.268-.03-.536-.08-.8-.029-.158-.27-.091-.24.066Zm.546.617c-.003.48-.04.96.054 1.433.016.08.119.116.184.075.104-.064.144-.136.195-.245.067-.145-.148-.272-.216-.126-.028.061-.043.117-.105.155l.183.075c-.09-.45-.048-.91-.045-1.367.001-.161-.249-.161-.25 0ZM10.075 18.012c0 .33.004.657.054.983.025.16.266.092.241-.066-.046-.303-.045-.61-.045-.917 0-.161-.25-.161-.25 0ZM10.675 18.012c0 .214.006.425.054.633.037.158.278.09.241-.066a2.495 2.495 0 0 1-.045-.567c0-.161-.25-.161-.25 0Z"
                }), s("path", {
                    d: "M10.925 17.662c-.003.45-.059.887-.196 1.317-.049.154.193.22.241.066.144-.45.201-.911.205-1.383.001-.161-.249-.16-.25 0ZM11.38 18.195l.15 1.05c.022.16.263.092.24-.066l-.15-1.05c-.022-.16-.263-.091-.24.066Z"
                }), s("path", {
                    d: "M12.792 17.7c-.292.41-.575.828-.93 1.19-.327.334-.846.71-1.345.613-.359-.07-.363-.562-.367-.844-.006-.4.043-.797.025-1.197-.003-.074-.055-.116-.125-.125-.761-.09-1.425.477-2.133.655l.153.087c-.127-.31-.013-.689-.103-1.013-.086-.314-.475-.194-.687-.101-.368.16-.66.399-1.076.372-.452-.028-1.017-.22-1.246-.638l-.02.152c.25-.279.583-.41.945-.468l-.154-.088c.18.498.052 1.009-.004 1.517-.015.14.168.148.233.063.233-.302.278-.695.5-1l-.229-.03c.139.41.092.833-.05 1.234h.242c-.19-.595.244-1.263.537-1.754l-.229-.03c.141.46.099.943.096 1.417 0 .107.138.169.213.089.257-.272.418-.61.65-.9l-.208-.056c.087.437.049.88-.005 1.317h.25c-.039-.459.2-.907.433-1.287l-.233-.063c.046.35.05.699.05 1.05 0 .14.212.172.246.033.058-.241.175-.436.367-.594l-.208-.056c.09.47 0 .95-.055 1.417h.25c-.037-.459.126-.911.383-1.287l-.228-.03c.18.49.12 1.118-.218 1.529l.213.088c-.035-.44.193-.855.383-1.237l-.228-.03c.047.27.045.545.045.817 0 .108.137.168.214.089.236-.247.42-.56.724-.73l-.183-.075c.181.462.012.97.212 1.43.033.074.145.078.197.025.272-.282.479-.618.75-.9l-.197-.026c.16.342.2.725.4 1.05.05.082.166.08.216 0 .16-.252.251-.629.505-.805l-.183-.074c.053.174.083.35.05.533-.03.158.211.225.24.067a1.377 1.377 0 0 0-.05-.667c-.021-.072-.114-.122-.183-.075-.306.212-.403.593-.595.895h.216c-.198-.322-.242-.709-.4-1.05-.034-.073-.144-.08-.196-.025-.271.282-.478.618-.75.9l.196.025c-.188-.429-.014-.928-.187-1.37-.03-.075-.108-.117-.184-.075-.326.183-.522.506-.775.77l.213.088c0-.295-.003-.59-.054-.883-.019-.106-.182-.123-.229-.03-.21.42-.456.88-.417 1.363.008.097.138.181.214.089.393-.478.495-1.194.282-1.772-.038-.104-.165-.122-.229-.03-.28.408-.457.915-.417 1.413.014.163.232.159.25 0 .057-.494.142-.988.046-1.483-.02-.1-.143-.11-.209-.055a1.277 1.277 0 0 0-.432.705l.245.033c0-.351-.004-.7-.05-1.05-.015-.117-.162-.178-.233-.063-.253.414-.509.913-.467 1.413.014.164.231.159.25 0 .057-.462.088-.923-.004-1.383-.017-.087-.151-.127-.209-.055-.231.29-.395.63-.65.9l.213.088c.003-.497.043-1-.104-1.483-.031-.103-.172-.124-.228-.03-.33.552-.774 1.28-.563 1.947.039.122.2.116.241 0 .156-.44.202-.92.05-1.367-.037-.108-.164-.118-.228-.03-.223.305-.268.698-.5 1l.233.063c.058-.532.183-1.062-.005-1.583-.025-.07-.082-.099-.154-.087-.401.064-.78.225-1.055.532a.128.128 0 0 0-.02.151c.191.348.55.538.915.658.324.107.742.18 1.064.036.121-.054.95-.533 1.006-.387.12.318-.027.696.103 1.014.026.064.082.105.154.087.684-.172 1.335-.732 2.067-.646l-.125-.125c.02.468-.047.936-.018 1.404.022.362.13.735.503.867.485.171 1.065-.182 1.421-.475.478-.393.822-.934 1.177-1.433.093-.131-.124-.256-.217-.126Z"
                }), s("path", {
                    d: "M4.725 16.262c-.05.632-.05 1.266-.05 1.9 0 .107.138.169.213.089.429-.455.516-1.098.82-1.626h-.216c.186.44.23.914.233 1.387.001.162.247.161.25 0 .01-.43.136-.842.196-1.267l-.246-.033c.044.383.05.766.05 1.15 0 .09.108.163.188.108.456-.314.529-.896.795-1.345h-.216c.424.598.339 1.343.383 2.037.009.133.223.18.246.033.054-.352.145-.697.2-1.05.024-.157-.217-.225-.241-.066-.055.352-.146.698-.2 1.05l.245.033c-.047-.738.034-1.527-.417-2.163-.053-.075-.165-.086-.216 0-.236.397-.305.98-.705 1.255l.188.108c0-.384-.006-.767-.05-1.15-.015-.127-.224-.184-.245-.033-.063.447-.195.88-.205 1.333h.25c-.003-.522-.062-1.029-.267-1.513-.038-.09-.173-.074-.216 0-.29.505-.372 1.142-.78 1.575l.213.088c0-.634 0-1.268.05-1.9.013-.16-.237-.16-.25 0Z"
                }), s("path", {
                    d: "M7.512 17.4c.255.219.275.597.285.91.011.317-.02.635-.022.952-.001.162.249.161.25 0 .004-.617.203-1.578-.337-2.038-.121-.104-.3.072-.176.177ZM9.475 17.262c-.05.916-.097 1.833-.05 2.75.005.102.1.147.188.108.16-.07.209-.204.295-.345.084-.138-.132-.263-.216-.126-.06.098-.094.207-.205.255l.188.108c-.047-.917 0-1.834.05-2.75.009-.16-.241-.16-.25 0ZM10.78 17.795c.145.702.2 1.425.45 2.1.034.095.132.116.208.056.153-.12.222-.276.282-.456.052-.153-.19-.218-.24-.066-.049.143-.097.25-.218.345l.208.055c-.25-.676-.304-1.399-.45-2.1-.032-.158-.273-.09-.24.066ZM12.08 17.845c.2.6.1 1.248.145 1.867.012.16.25.163.25 0v-.25c0-.161-.25-.161-.25 0v.25h.25c-.047-.642.054-1.312-.154-1.933-.052-.152-.293-.087-.242.066Z"
                }), s("path", {
                    d: "M12.33 17.895c.093.563.055 1.137.15 1.7.026.16.267.092.24-.066-.094-.563-.055-1.137-.15-1.7-.026-.159-.267-.091-.24.066ZM12.78 18.395c.157.453.145.944.145 1.417 0 .161.25.161.25 0 0-.494.01-1.01-.154-1.483-.053-.151-.295-.086-.242.066Z"
                }), s("path", {
                    d: "M12.825 18.312c.002.209.185 1.538-.125 1.525-.161-.007-.16.243 0 .25.663.028.379-1.41.375-1.775-.002-.16-.252-.161-.25 0ZM11.537 18.254c-.344.258-.565.72-.97.888-.147.06-.083.303.066.24.448-.185.656-.632 1.03-.912.127-.095.003-.313-.126-.216ZM9.162 17.474c-.329.353-.374.952-.775 1.23-.132.091-.007.308.126.216.444-.307.473-.89.825-1.27.11-.117-.066-.294-.176-.176ZM7.487 17.004c-.475.21-.482.853-.775 1.22-.1.124.076.303.176.177.136-.17.22-.363.302-.564.093-.228.18-.51.423-.617.147-.065.02-.28-.126-.216ZM6.062 16.974c-.182.184-.326.4-.383.655-.035.157.206.224.241.066.048-.215.166-.389.318-.544.113-.115-.063-.292-.176-.177ZM5.312 16.574c-.228.247-.27.604-.5.85-.11.117.066.294.176.177.232-.248.276-.607.5-.85.11-.119-.067-.296-.176-.177Z"
                }), s("path", {
                    d: "M4.68 16.579c-.1.267-.105.552-.105.833 0 .161.25.161.25 0 0-.26.004-.519.096-.767.055-.151-.186-.216-.242-.066Z"
                }), s("path", {
                    d: "M4.713 16.62c.164-.105.739-.551.833-.186.091.352.014.768.029 1.128.006.135.219.178.246.033.05-.276.145-.526.287-.77l-.229-.03c.092.35.096.708.096 1.067 0 .1.142.177.213.089.316-.392.259-.968.65-1.3l-.151.02c.431.314.436 1.011.438 1.491 0 .14.211.172.246.034.097-.39.196-.779.35-1.15l-.21.055c.426.344.53.96.719 1.445.04.105.161.12.228.03.211-.287.278-.643.45-.95h-.216c.095.19.174.37.183.586.007.161.244.162.25 0 .01-.27.09-.53.1-.8l-.213.089c.252.282.222.759.263 1.111.018.157.245.165.25 0 .008-.247.075-.465.183-.687l-.196.026c.291.313.375.753.518 1.145.044.12.195.116.24 0 .13-.33.142-.697.288-1.02h-.216c.287.407.34.906.488 1.37.037.116.206.121.24 0 .095-.33.19-.66.338-.97l-.196.025c.349.273.424.75.568 1.145.028.079.144.134.209.055.312-.385.444-.855.632-1.305l-.21.055c.276.294.383.675.519 1.045.04.112.205.125.24 0 .1-.35.188-.704.3-1.05l-.228.03c.269.426.337.962.238 1.453l.209-.055a1.181 1.181 0 0 1-.18-.275c-.074-.144-.29-.017-.217.126.061.12.13.226.22.326.06.067.19.035.209-.056.112-.555.042-1.161-.263-1.646a.126.126 0 0 0-.228.03c-.113.346-.201.7-.3 1.05h.24c-.15-.412-.275-.827-.581-1.155-.071-.076-.175-.026-.21.055-.169.406-.285.847-.567 1.195l.209.055c-.158-.435-.248-.954-.632-1.255-.059-.046-.158-.055-.197.025-.158.33-.262.679-.362 1.03h.24c-.154-.485-.212-1.004-.512-1.43-.048-.068-.174-.093-.216 0-.156.345-.174.729-.312 1.08h.24c-.158-.435-.257-.906-.581-1.255-.053-.056-.162-.046-.197.025-.126.26-.207.522-.217.813h.25c-.05-.43-.03-.945-.336-1.288-.077-.086-.21-.014-.214.088-.01.27-.09.53-.1.8h.25c-.011-.26-.102-.482-.217-.713-.042-.084-.172-.078-.216 0-.171.307-.239.664-.45.95l.229.03c-.205-.524-.322-1.183-.782-1.555-.079-.064-.172-.036-.21.055-.153.372-.252.76-.35 1.15l.246.033c-.002-.589-.042-1.33-.562-1.708-.047-.034-.111-.014-.151.02-.413.35-.33.903-.65 1.3l.213.088c0-.381-.007-.762-.104-1.133-.028-.105-.175-.123-.229-.03a2.55 2.55 0 0 0-.312.83l.245.033c-.017-.415.097-.953-.091-1.34-.219-.449-.908.028-1.147.182-.135.087-.01.304.126.216Z"
                }), s("path", {
                    d: "M7.617 16.342c-.311.081-.583.343-.827.54-.316.255-.627.556-.997.733-.318.152-.293-.556-.312-.72-.041-.35-.177-.664-.548-.753-.071-.018-.128.022-.154.087-.156.4-.157.854-.05 1.267.019.07.088.1.154.087.22-.043.338-.238.437-.42.117-.216.3-.608.607-.427.221.13.275.511.314.738.046.26.053.526.084.788.012.105.128.17.213.089.52-.497.56-1.284 1.05-1.8l-.151.02c.683.516.563 1.594.842 2.325.04.103.165.123.229.03.15-.22.313-.483.548-.62.126-.074.199.095.244.185.211.415.313.874.542 1.284.032.058.114.081.171.045.284-.179.503-.412.747-.638.277-.257.553.302.682.493.035.052.113.087.171.045.487-.353.5-1.073 1-1.4l-.151-.02c.269.291.323.69.467 1.045.032.077.143.137.21.056.091-.114.154-.246.219-.376l-.229-.03c.029.092.045.171.046.267.001.161.251.162.25 0 0-.117-.02-.22-.054-.333-.03-.097-.178-.131-.229-.03-.054.108-.104.23-.18.325l.209.055c-.163-.4-.23-.828-.533-1.155a.125.125 0 0 0-.151-.02c-.229.15-.372.364-.495.603-.14.275-.245.609-.505.797l.17.045c-.173-.257-.454-.779-.84-.69-.139.031-.253.162-.349.258-.18.182-.363.35-.581.487l.17.045a6.227 6.227 0 0 1-.386-.905c-.074-.203-.147-.417-.288-.585-.382-.456-.92.392-1.09.64l.228.03c-.315-.822-.186-1.89-.958-2.475-.043-.033-.116-.017-.151.02-.491.517-.536 1.309-1.05 1.8l.213.088c-.061-.525-.006-1.368-.49-1.719-.244-.177-.54-.105-.737.105-.172.185-.26.641-.531.694l.154.087a1.841 1.841 0 0 1 .05-1.134l-.154.088c.424.102.365.63.41.971.036.273.171.58.497.529.338-.053.674-.402.927-.607.284-.231.617-.597.982-.693.156-.041.09-.282-.066-.241Z"
                }), s("path", {
                    d: "M4.525 16.362c-.002.612-.047 1.227.054 1.833.02.115.176.113.229.03.303-.472.459-1.011.662-1.53l-.208.056c.273.349.222.845.263 1.261.011.111.174.187.233.063.195-.406.293-.868.58-1.224h-.176c.3.327.328.83.417 1.244.019.086.152.13.21.056.232-.296.344-.674.6-.95l-.152.02c.375.26.35.836.388 1.241.01.103.131.173.213.089.19-.195.36-.406.55-.6l-.196-.026c.114.223.24.44.338.67.037.09.13.121.208.056.13-.11.266-.21.42-.287.255-.128.311.069.317.298.003.106.136.17.213.089.257-.272.418-.61.65-.9l-.196-.026c.129.216.186.477.238.72.022.109.176.12.228.03.106-.18.28-.286.43-.424l-.196-.026c.19.414.135.895.133 1.337h.25c-.038-.308-.006-.582.183-.837h-.216c.085.163.174.298.183.487l.246-.033c-.055-.245-.066-.5-.105-.749-.034-.22-.065-.474-.292-.572-.258-.11-.564.018-.802.121-.414.18-.773.284-1.236.252-.47-.032-.931-.202-1.386-.313-.52-.127-1.053-.188-1.577-.288-.318-.06-.681-.104-.943-.313-.238-.19-.35-.516-.46-.788l-.087.154c.352-.103.607-.03.743.323.114.298.139.629.204.94.03.146.234.098.245-.034.016-.186.129-.345.196-.516l-.21.055c.236.301.32.684.481 1.024.034.072.145.082.197.026.192-.208.379-.466.625-.613.253-.15.485.33.578.487.052.089.16.073.216 0 .2-.261.465-.398.754-.174.126.097.304-.079.177-.177-.428-.33-.839-.179-1.147.225h.216c-.15-.254-.39-.694-.752-.636-.351.057-.623.471-.844.711l.196.025c-.174-.364-.267-.751-.52-1.075-.064-.082-.179-.021-.208.055-.079.2-.186.365-.205.583l.246-.033c-.08-.382-.107-.79-.295-1.14-.198-.369-.594-.403-.96-.297-.059.017-.112.09-.086.154.214.532.432.962 1.007 1.149.42.136.879.183 1.313.254a16.55 16.55 0 0 1 1.52.34c.427.11.852.18 1.293.13.359-.04.652-.209.985-.333.1-.037.388-.14.475-.027.065.084.075.233.093.334.048.265.055.54.114.803.03.137.252.107.245-.034-.01-.238-.109-.407-.217-.613-.048-.09-.164-.07-.216 0-.212.287-.26.615-.217.963.02.156.25.166.25 0 .003-.495.044-1-.167-1.463-.035-.076-.142-.075-.196-.025-.168.154-.352.274-.47.475l.229.03c-.056-.265-.123-.545-.263-.78-.038-.063-.145-.09-.196-.025-.231.29-.396.63-.65.9l.213.088c-.007-.273-.075-.571-.394-.594-.28-.021-.572.24-.77.406l.21.055c-.106-.251-.239-.487-.363-.73-.037-.072-.142-.08-.196-.025-.19.194-.361.405-.55.6l.213.088c-.049-.514-.042-1.131-.512-1.458-.044-.03-.115-.019-.151.02-.26.28-.367.653-.6.95l.209.055c-.1-.468-.144-.987-.482-1.355-.043-.046-.136-.051-.177 0-.306.378-.413.845-.62 1.275l.233.063c-.05-.499-.01-1.022-.336-1.438-.065-.082-.18-.021-.21.055-.195.499-.345 1.016-.637 1.47l.229.03c-.098-.583-.048-1.179-.046-1.767 0-.161-.25-.161-.25 0Z"
                })]
            })
        }))
    });
const Ke = N(function() {
        const t = w(),
            [e, n] = m1({
                value: 1
            }),
            a = b.exports.useCallback(c => n1[c].map(u => ({
                action: u.action,
                amount: t.chip.value.mul(u.odds)
            })), [t.chip]);
        return r("div", {
            className: B(Je, "preset-wrap"),
            children: [s("p", {
                className: "preset-title",
                children: "Neighbour bets"
            }), r("div", {
                className: "select-wrap",
                onMouseEnter: () => t.setHoverList(H1(n1[e.value])),
                onMouseLeave: () => t.setHoverList([]),
                children: [s(q1, {
                    renderLabel: c => r("div", {
                        className: "preset-label",
                        children: [s("p", {
                            children: `${c.label} ${c.desc}`
                        }), s("div", {
                            className: "em"
                        })]
                    }),
                    disableHover: !0,
                    options: I1,
                    renderOption: c => r("div", {
                        children: [s("span", {
                            style: {
                                fontWeight: "bold",
                                marginRight: "3px"
                            },
                            children: c.label
                        }), s("span", {
                            children: c.desc
                        })]
                    }),
                    value: e.value,
                    onChange: c => {
                        n({
                            value: c
                        }), t.stepAddBetChip(a(c))
                    }
                }), s(F, {
                    title: "Apply predefined bets",
                    children: s("button", {
                        className: "use",
                        onClick: () => {
                            t.stepAddBetChip(a(e.value))
                        },
                        children: s(Ue, {})
                    })
                })]
            })]
        })
    }),
    Je = "peh5tgj";
const w1 = R.memo(function({
        visible: t,
        children: e
    }) {
        const [n, a] = C1(() => ({
            scale: 0,
            opacity: 0
        }));
        return b.exports.useEffect(() => {
            a.start({
                scale: t ? 1 : 0,
                opacity: t ? 1 : 0,
                config: t ? f1.wobbly : f1.default
            })
        }, [t]), s(k1.div, {
            className: Ye,
            style: n,
            children: e
        })
    }),
    Ye = "aai8tja",
    Qe = N(function() {
        const t = w(),
            e = L1(),
            n = b.exports.useRef(null),
            [a, c] = m1({
                show: !1,
                isWin: !1
            });
        b.exports.useEffect(() => {
            e || (t.betResult.odds >= 1 ? (t.betResult.odds === 1 ? (t.sounds.playSound("tiedSound"), t.settings.fastEnable || c({
                show: !0,
                isWin: !1
            })) : t.betResult.bigwin || (t.sounds.playSound("winSound"), t.settings.fastEnable || c({
                show: !0,
                isWin: !0
            })), t.settings.fastEnable || (n.current = setTimeout(() => {
                c({
                    show: !1,
                    isWin: !1
                })
            }, 2e3))) : t.betResult.odds !== -999 && t.sounds.playSound("loseSound"))
        }, [t.betResult]), b.exports.useEffect(() => {
            t.manualBetting && (c({
                show: !1,
                isWin: !1
            }), n.current && clearTimeout(n.current))
        }, [t.manualBetting]);
        const l = a.show && a.isWin,
            u = a.show && !a.isWin,
            i = E1(new f(t.betResult.winAmount));
        return r(K, {
            children: [s(w1, {
                visible: l,
                children: r("div", {
                    className: "win-result",
                    children: [s("img", {
                        alt: "firework",
                        src: d1.firework,
                        className: "firework"
                    }), r("div", {
                        className: "win-info",
                        children: [s("p", {
                            className: "result-title",
                            children: "YOU WON!"
                        }), r("p", {
                            className: "result-odds",
                            children: [t.betResult.odds, "x"]
                        }), r("p", {
                            className: "result-amount",
                            children: [i, " ", V.getAlias(t.betResult.currencyName)]
                        })]
                    })]
                })
            }), s(w1, {
                visible: u,
                children: s("div", {
                    className: "tied-result",
                    children: s("p", {
                        children: "YOU TIED!"
                    })
                })
            })]
        })
    });
const y = 145,
    Z = 132,
    T = 106,
    o1 = Math.PI * 2 / s1,
    Xe = 360 / s1,
    $1 = R.memo(function() {
        const t = b.exports.useRef(ot()),
            e = b.exports.useRef(at()),
            n = U1();
        return r("div", {
            className: st,
            children: [r("div", {
                className: B(nt, "wheel-wrap"),
                children: [r("svg", {
                    className: "roulette-wheel",
                    viewBox: "0 0 290 290",
                    children: [s("circle", {
                        cx: y,
                        cy: y,
                        r: y,
                        fill: n ? "rgba(34,35,40,0.6)" : "rgba(255,255,255,0.35)"
                    }), s("defs", {
                        children: s("g", {
                            id: "wheel-sector",
                            children: s("path", {
                                d: `
                M ${y} 13
                A ${Z} ${Z} 1, 0, 1, ${t.current.x} ${t.current.y}
                L ${y} ${y}
                L ${y} 13
              `
                            })
                        })
                    }), s("defs", {
                        children: s("g", {
                            id: "wheel-sector-inner",
                            children: s("path", {
                                d: `
                M ${y} 13
                A ${Z} ${Z} 1, 0, 1, ${t.current.x} ${t.current.y}
                L ${e.current.x} ${e.current.y}
                A ${T} ${T} 1, 0, 0, ${y} ${y-T}
                L ${y} 13
              `
                            })
                        })
                    }), R1.map((a, c) => s(et, {
                        item: a,
                        index: c
                    }, c.toString())), s("circle", {
                        cx: y,
                        cy: y,
                        r: T,
                        fill: "rgba(6, 23, 39, 0.3)"
                    }), s("circle", {
                        cx: y,
                        cy: y,
                        r: 74,
                        fill: "#101113"
                    }), s("image", {
                        className: "rod",
                        xlinkHref: d1.circle,
                        x: 70,
                        y: 70,
                        width: 150,
                        height: 150
                    })]
                }), s(tt, {})]
            }), s(Qe, {})]
        })
    }),
    et = N(function({
        index: t,
        item: e
    }) {
        const n = w(),
            a = t % 2 === 0,
            c = t === 0 ? "green" : a ? "black" : "red",
            l = n.hoverNumList.findIndex(i => i === e),
            u = k.isMobile && n.betNumList.indexOf(e) >= 0;
        return r("g", {
            className: U("sector-item", "sector-" + c, l >= 0 && "is-hover", u && "is-light"),
            style: {
                transform: `rotate(${Xe*t}deg)`
            },
            children: [s("use", {
                xlinkHref: "#wheel-sector",
                className: "use-tag"
            }), s("use", {
                xlinkHref: "#wheel-sector-inner",
                className: "use-inner-tag"
            }), s("text", {
                className: "sector-text",
                transform: "translate(155,30) rotate(2)",
                children: e
            })]
        })
    }),
    u1 = 26,
    tt = N(function() {
        const t = L1(),
            e = w(),
            n = b.exports.useRef(null),
            a = b.exports.useRef(null),
            c = b.exports.useRef(0),
            l = b.exports.useRef(0);
        return b.exports.useEffect(() => {
            if (e.resultNum.result >= 0 && !t) {
                G.set(n.current, {
                    rotate: l.current % 360
                }), G.set(a.current, {
                    top: e.settings.fastEnable ? u1 : 0
                });
                const u = ct(e.resultNum.result, c.current, l.current % 360);
                l.current = u;
                let i = 0;
                const p = G.to(n.current, {
                    duration: e.settings.fastEnable ? 0 : 4,
                    rotate: u,
                    ease: "easeInOut",
                    onUpdate() {
                        if (!e.settings.fastEnable && p.time() >= 1.5 && a.current) {
                            i += .25;
                            let d = a.current.offsetTop + i;
                            (d >= u1 || d <= 0) && (i = -i * .9, d = u1), G.set(a.current, {
                                top: d
                            })
                        }
                    }
                });
                !e.settings.fastEnable && e.sounds.playSound("wheelSound"), c.current = e.resultNum.result
            }
            return () => {
                G.killTweensOf(n.current)
            }
        }, [e.resultNum]), s("div", {
            ref: n,
            className: "ball",
            style: {
                opacity: e.resultNum.result >= 0 && !t ? "1" : "0"
            },
            children: s("div", {
                ref: a,
                className: "dont-wrp",
                children: s("div", {
                    className: "dont"
                })
            })
        })
    }),
    st = "w1h1x2on",
    nt = "w88kh7q",
    ot = () => {
        const o = Math.sin(o1) * Z + y,
            t = y - Math.cos(o1) * Z;
        return {
            x: o,
            y: t
        }
    },
    at = () => {
        const o = Math.sin(o1) * T + y,
            t = y - Math.cos(o1) * T;
        return {
            x: o,
            y: t
        }
    },
    ct = (o, t, e) => {
        const n = e === 0 ? .5 : 0,
            a = N1(o),
            c = N1(t),
            l = 360 / s1;
        return 720 + l * (a + n) + l * (s1 - c) + e
    };
const lt = N(function() {
        const t = w(),
            e = b.exports.useRef(null),
            [n, a] = K1(),
            [c, l] = b.exports.useState(1),
            u = J1(i => {
                l(i.width >= 821 ? 1 : i.width / 821)
            }, 300);
        return b.exports.useEffect(() => (t.betResult.bigwin && (a({
            profitAmount: new f(t.betResult.winAmount).toNumber(),
            currencyName: t.betResult.currencyName,
            odds: t.betResult.odds,
            isBigWin: !0,
            enableSound: t.settings.soundEnable
        }), e.current = setTimeout(() => {
            a(null)
        }, 3e3)), () => {
            e.current && clearTimeout(e.current)
        }), [t.betResult]), r(Y1, {
            className: it,
            children: [r("div", {
                ref: u,
                className: B(bt, k.isMobile && "small-wrap"),
                children: [k.isMobile ? s(ut, {}) : s(rt, {
                    scale: c
                }), s(Q1, {
                    className: B(k.isMobile && t.isBetting && "betting-houseedge", "roulette-single-edge")
                })]
            }), n]
        })
    }),
    it = "g1s1znr2",
    rt = R.memo(function({
        scale: t
    }) {
        const e = 144 + 290 * t;
        return r("div", {
            className: pt,
            children: [s($1, {}), r("div", {
                className: "roulette-nums-wrap",
                style: {
                    height: `${e}px`
                },
                children: [r("div", {
                    className: "preset-action",
                    children: [s(Ke, {}), s(ze, {})]
                }), s("div", {
                    className: "nums-wrap",
                    style: {
                        transform: `scale(${t})`
                    },
                    children: s(T1, {})
                })]
            })]
        })
    }),
    ut = N(function() {
        const t = w(),
            [e, n] = C1(() => ({
                opacity: 0
            }));
        return b.exports.useEffect(() => {
            n.start({
                opacity: t.isBetting ? 1 : 0
            })
        }, [t.isBetting]), r("div", {
            className: B(ht, t.isBetting && "in-betting"),
            children: [s(mt, {}), s(k1.div, {
                className: "result-wrap",
                style: e,
                children: s($1, {})
            })]
        })
    }),
    mt = N(function() {
        const o = w(),
            t = b.exports.useCallback(e => n1[e].map(a => ({
                action: a.action,
                amount: o.chip.value.mul(a.odds)
            })), [o.chip]);
        return r("div", {
            className: B(dt, "nums-wrap"),
            children: [s("div", {
                className: "presetbtns-wrap",
                children: I1.map((e, n) => {
                    const a = n1[n];
                    return r("button", {
                        className: B("preset-btn", "btn-" + n),
                        onMouseEnter: () => o.setHoverList(H1(a)),
                        onMouseLeave: () => o.setHoverList([]),
                        onClick: () => o.stepAddBetChip(t(n)),
                        children: [s("p", {
                            children: e.label
                        }), s("p", {
                            className: "desc",
                            children: e.desc
                        })]
                    }, String(n))
                })
            }), s(T1, {
                isSmall: !0
            })]
        })
    }),
    dt = "m4p4pap",
    ht = "mxv8g5",
    pt = "p1p1anw7",
    bt = "w1vxcx78",
    ft = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35],
    gt = [1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36],
    yt = () => {
        const o = w(),
            t = t1.useSingleDetail();
        return r(K, {
            children: [s(X1, {
                list: o.myBets,
                keyof: "betId",
                hideJackpot: !0,
                onDetail: t,
                getResult: e => e.gameValue.result,
                getClassName: e => {
                    const n = e.gameValue.result;
                    return ft.indexOf(n) >= 0 ? "result-black" : gt.indexOf(n) >= 0 ? "result-red" : n === 0 ? "result-green" : ""
                }
            }), s(lt, {})]
        })
    };
var vt = N(yt);
const P1 = N(() => {
    const o = Gt();
    return s(H.ChipInput, {
        value: o.chip,
        chips: o.chips,
        onChange: t => o.chip = t
    })
});
const G1 = N(function() {
    const t = w(),
        e = a => {
            if (V.dict[t.currencyName].amount > 0) {
                if (t.betChipList.length > 0) {
                    const l = Q.exports.cloneDeep(t.betChipList).slice(-1)[0],
                        u = l.betInfo.length,
                        i = [];
                    let p = new f(0);
                    if (l.betInfo.forEach(m => {
                            i.push(x(M({}, m), {
                                amountPercent: new f(1).div(u)
                            }))
                        }), a === "min") {
                        const m = new f(t.chip.unit).mul(u);
                        m > t.minAmount ? p = m : p = t.minAmount
                    } else p = t.getMaxBetAmount;
                    t.maxLenSetbetList({
                        betInfo: i,
                        amount: p
                    })
                }
            } else t.betBackFn(!0)
        },
        n = t.isBetting || t.betChipList.length === 0;
    return s(ee, {
        label: "Total Bet",
        size: "small",
        currencyName: t.currencyName,
        value: t.amount.toNumber(),
        onChange: () => {},
        className: "total-bet-input",
        readOnly: !0,
        children: r("div", {
            className: B(Nt, "change-action-min-max"),
            children: [s(e1, {
                className: "min",
                disabled: n,
                onClick: () => {
                    e("min")
                },
                children: s("span", {
                    children: "Min"
                })
            }), s(e1, {
                className: "max",
                disabled: n,
                onClick: () => {
                    e("max")
                },
                children: s("span", {
                    children: "Max"
                })
            })]
        })
    })
});
M1({
    cl1: ["#31343c", j("#dadde6", .4)],
    cl2: ["#99a4b0", j("#5f6975", .8)],
    cl3: ["#3c404a", j("#dadde6", .2)]
});
const Nt = "mjmxyfa";
const wt = N(function() {
        return r("div", {
            className: B(St, "game-form"),
            children: [k.isMobile && s(S1, {}), s(P1, {}), s(G1, {}), s(H.TimesInput, {}), s(H.IncreaseInput, {}), s(H.StopInput, {}), s(H.IncreaseInput, {
                isLose: !0
            }), s(H.StopInput, {
                isLose: !0
            }), s(te, {}), !k.isMobile && s(S1, {})]
        })
    }),
    S1 = N(function() {
        const t = w(),
            e = q();
        return s(e1, {
            className: "bet-button",
            type: "conic",
            size: "big",
            disabled: t.amount.lte(0),
            onClick: () => t.mainBetFn(),
            children: t.autoBet.isRunning ? e("common.stop_auto_bet") : e("common.start_auto_bet")
        })
    }),
    St = "a1nu90fg";
const At = N(function() {
        const t = w(),
            e = t.isBetting || t.amount.lte(0),
            n = () => s(e1, {
                className: "bet-button",
                type: "conic",
                size: "big",
                disabled: e,
                loading: t.isBetting,
                onClick: () => t.mainBetFn(),
                children: "Spin Now"
            });
        return r("div", {
            className: Bt,
            children: [k.isMobile && n(), s(P1, {}), s(G1, {}), !k.isMobile && n()]
        })
    }),
    Bt = "m19dry02",
    Ct = function({
        game: t
    }) {
        return s(se, {
            title: "Max Profits",
            game: t
        })
    };
const kt = R.memo(() => {
        const o = q(),
            t = w(),
            e = [{
                title: o("common.game_intro"),
                node: s(Ze, {})
            }, {
                title: o("common.fairness"),
                node: "/roulette_help/fairness"
            }, {
                title: "Max Profits",
                node: s(Ct, {
                    game: t
                })
            }, {
                title: "Payouts",
                node: s($e, {})
            }];
        return s(ne, {
            className: Lt,
            manualControl: s(At, {}),
            autoControl: s(wt, {}),
            gameView: s(vt, {}),
            tabs: [{
                label: o("common.all_bet"),
                value: t1.AllBet
            }, {
                label: o("common.my_bet"),
                value: t1.MyBet
            }],
            actions: [s(oe, {}), s(ae, {}), s(ce, {}), s(le, {}), s(ie, {}), s(re, {
                list: e
            })]
        })
    }),
    Lt = "rm6hojw",
    $ = z.Reader,
    h1 = z.Writer,
    Mt = z.util,
    C = z.roots.gameRoulette || (z.roots.gameRoulette = {});
C.BetValue = (() => {
    function o(t) {
        if (this.bets = [], t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return o.prototype.bets = Mt.emptyArray, o.encode = function(e, n) {
        if (n || (n = h1.create()), e.bets != null && e.bets.length)
            for (let a = 0; a < e.bets.length; ++a) C.BetData.encode(e.bets[a], n.uint32(10).fork()).ldelim();
        return n
    }, o.decode = function(e, n) {
        e instanceof $ || (e = $.create(e));
        let a = n === void 0 ? e.len : e.pos + n,
            c = new C.BetValue;
        for (; e.pos < a;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    c.bets && c.bets.length || (c.bets = []), c.bets.push(C.BetData.decode(e, e.uint32()));
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return c
    }, o
})();
C.BetData = (() => {
    function o(t) {
        if (t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return o.prototype.type = "", o.prototype.betAmount = "", o.prototype.column = "", o.encode = function(e, n) {
        return n || (n = h1.create()), e.type != null && Object.hasOwnProperty.call(e, "type") && n.uint32(10).string(e.type), e.betAmount != null && Object.hasOwnProperty.call(e, "betAmount") && n.uint32(18).string(e.betAmount), e.column != null && Object.hasOwnProperty.call(e, "column") && n.uint32(26).string(e.column), n
    }, o.decode = function(e, n) {
        e instanceof $ || (e = $.create(e));
        let a = n === void 0 ? e.len : e.pos + n,
            c = new C.BetData;
        for (; e.pos < a;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    c.type = e.string();
                    break;
                case 2:
                    c.betAmount = e.string();
                    break;
                case 3:
                    c.column = e.string();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return c
    }, o
})();
C.GameValue = (() => {
    function o(t) {
        if (t)
            for (let e = Object.keys(t), n = 0; n < e.length; ++n) t[e[n]] != null && (this[e[n]] = t[e[n]])
    }
    return o.prototype.odds = 0, o.prototype.result = 0, o.encode = function(e, n) {
        return n || (n = h1.create()), e.odds != null && Object.hasOwnProperty.call(e, "odds") && n.uint32(9).double(e.odds), e.result != null && Object.hasOwnProperty.call(e, "result") && n.uint32(16).sint32(e.result), n
    }, o.decode = function(e, n) {
        e instanceof $ || (e = $.create(e));
        let a = n === void 0 ? e.len : e.pos + n,
            c = new C.GameValue;
        for (; e.pos < a;) {
            let l = e.uint32();
            switch (l >>> 3) {
                case 1:
                    c.odds = e.double();
                    break;
                case 2:
                    c.result = e.sint32();
                    break;
                default:
                    e.skipType(l & 7);
                    break
            }
        }
        return c
    }, o
})();
var xt = "/assets/chip_change.af52ffb4.mp3",
    Rt = "/assets/chip_click.1b74d725.mp3",
    It = "/assets/lose.1e55f09e.mp3",
    _t = "/assets/win.1981b036.mp3",
    Dt = "/assets/tied.47646fc0.mp3",
    Et = "/assets/wheel.3b56c873.mp3",
    Ht = "/assets/fireword.8893c97e.mp3",
    Zt = "/assets/warning.05b60034.mp3";
const Tt = x1.decode(C.GameValue),
    $t = x1.encode(C.BetValue),
    _ = new f(0);
class Pt extends ue {
    constructor() {
        super({
            name: "RouletteSingle",
            namespace: "/g/roulettes",
            fairLink: "/roulette_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/roulettesingle.html",
            disableLimitMinAmount: !0,
            sounds: {
                chipChangeSound: xt,
                chipClickSound: Rt,
                loseSound: It,
                winSound: _t,
                tiedSound: Dt,
                wheelSound: Et,
                firewordSound: Ht,
                warningSound: Zt
            }
        }, kt);
        A(this, "chip", new g1(new f(1), new f(8)));
        A(this, "chips", []);
        A(this, "betChipList", []);
        A(this, "hoverNumList", []);
        A(this, "warningNumList", []);
        A(this, "betNumList", []);
        A(this, "isSlotsError", !1);
        A(this, "resultNum", {
            result: -1,
            odds: -999
        });
        A(this, "betResult", {
            result: -1,
            odds: -999,
            currencyName: "",
            winAmount: 0,
            bigwin: !1
        });
        A(this, "manualBetting", !1);
        A(this, "lastCurrencyInfo", {
            currencyName: "",
            minAmount: _,
            maxAmount: _
        });
        A(this, "onBetRequest", async e => {
            let n = await e;
            this.resultNum = {
                result: n.gameValue.result || 0,
                odds: n.odds
            }, this.manualBetting = !1, await he(this.settings.fastEnable ? 200 : 4100), this.betResult = {
                result: n.gameValue.result || 0,
                odds: n.odds,
                currencyName: n.currencyName,
                winAmount: n.winAmount,
                bigwin: n.odds >= 50
            };
            const a = n.odds >= 1 ? 2e3 : 200;
            let c = this.settings.fastEnable ? 500 : a;
            k.isMobile && !this.settings.fastEnable && (c += 400);
            const l = this.autoBet.isRunning ? c : k.isMobile ? 1500 : 0,
                u = n.odds >= 50 ? 3e3 : l;
            return await v1(u), n
        });
        me(this, {
            chip: I,
            chips: I,
            betChipList: I,
            hoverNumList: I,
            isSlotsError: I,
            resultNum: I,
            betResult: I,
            manualBetting: I,
            changeBetChipList: Y,
            betBackFn: Y,
            setHoverList: Y,
            setWarningList: Y
        }), this.removeHotKey("a"), this.removeHotKey("s"), this.addHotkey("a", () => this.halfAndDoubleAction("half"), "Half bet amount"), this.addHotkey("s", () => this.halfAndDoubleAction("double"), "Double bet amount"), this.addHotkey("q", () => this.betBackFn(), "Undo"), this.addHotkey("w", () => this.betBackFn(!0), "Clear");
        const e = this.hotkeyList.find(n => n.key == "space");
        e && (e.handler = () => (this.controlIdx === 1 ? this.autoBet.isRunning ? this.autoBet.stop() : this.mainBetFn() : this.mainBetFn(), !1)), y1(() => {
            this.isSlotsError && setTimeout(() => {
                this.isSlotsError = !1
            }, 1e3)
        }), y1(() => {
            const {
                currencyName: n,
                minAmount: a
            } = this.lastCurrencyInfo;
            if (n != this.currencyName || !a.eq(this.minAmount)) {
                const c = this.minAmount.eq(0) ? new f(.01) : this.minAmount,
                    l = this.maxAmount.eq(0) ? new f(1e6) : this.maxAmount;
                let u = new f(1).div(10 ** V.dict[this.currencyName].precision);
                this.currencyName === "JB" && (u = new f(1));
                const i = g1.chipList(c, l, u);
                i.length > 0 && (this.chip = this.getDefaultChip(i)), this.chips = [...i], this.lastCurrencyInfo = {
                    currencyName: this.currencyName,
                    minAmount: c,
                    maxAmount: l
                }
            }
        }), de(() => this.currencyName, () => {
            this.betBackFn(!0)
        })
    }
    get getMaxBetAmount() {
        const e = V.dict[this.currencyName],
            n = e ? new f(e.amount) : _;
        return f.min(n, this.maxAmount)
    }
    getDefaultChip(e) {
        return e.length < 3 ? e[0] : e[2]
    }
    mainBetFn() {
        if (!this.amount.lte(0)) {
            if (this.sounds.playSound("chipChangeSound"), this.controlIdx === 0) {
                if (this.isBetting) return;
                if (this.amount.lt(this.minAmount)) {
                    O("Bet Amount Invalid. Minimum amount " + this.minAmount.toNumber() + ".");
                    return
                }
                this.handleBet().catch(e => {
                    O(e), this.betChipList = [], this.amount = _
                })
            } else if (this.controlIdx === 1)
                if (this.autoBet.isRunning) this.autoBet.stop();
                else {
                    if (this.isBetting) return;
                    if (this.amount.lt(this.minAmount)) {
                        O("Bet Amount Invalid. Minimum amount " + this.minAmount.toNumber() + ".");
                        return
                    }
                    this.autoBet.start().catch(e => {
                        O(e), this.betChipList = [], this.amount = new f(0)
                    })
                }
        }
    }
    halfAndDoubleAction(e) {
        if (this.isBetting || this.amount.lte(0)) return;
        let n = Q.exports.cloneDeep(this.betChipList.slice(-1)[0]);
        if (e === "half") {
            const a = this.amount.div(2);
            a.gte(this.minAmount) && (n.amount = a, this.maxLenSetbetList(n), this.amount = a)
        } else {
            const a = this.amount.mul(2);
            if (this.amount.eq(this.getMaxBetAmount)) return;
            const c = f.min(a, this.getMaxBetAmount);
            n.amount = c, this.maxLenSetbetList(n), this.amount = c
        }
    }
    changeBetChipList(e, n, a) {
        if (this.isBetting) return !1;
        const c = Q.exports.cloneDeep(this.betChipList),
            l = c.length > 0 ? c.slice(-1)[0].betInfo : [],
            u = l.findIndex(m => _1(m.action.nums, e.nums)),
            i = [],
            p = n === "add";
        if (u >= 0) {
            const m = l[u].amountPercent.mul(this.amount),
                d = m.sub(a).gt(0),
                g = p ? m.add(a) : d ? m.sub(a) : _,
                h = p ? this.amount.add(a) : this.amount.sub(d ? a : m);
            return l.forEach((S, D) => {
                if (D === u) g.gt(0) && i.push(x(M({}, S), {
                    amountPercent: g.div(h)
                }));
                else {
                    const c1 = this.amount.mul(S.amountPercent);
                    i.push(x(M({}, S), {
                        amountPercent: c1.div(h)
                    }))
                }
            }), this.maxLenSetbetList({
                betInfo: i,
                amount: h
            })
        } else {
            if (n === "sub") return !1;
            const m = a.add(this.amount);
            return l.forEach(d => {
                const g = this.amount.mul(d.amountPercent);
                i.push(x(M({}, d), {
                    amountPercent: g.div(m)
                }))
            }), i.push({
                action: e,
                amountPercent: a.div(m)
            }), this.maxLenSetbetList({
                betInfo: i,
                amount: m
            })
        }
    }
    async stepAddBetChip(e) {
        this.betBackFn(!0);
        let n = !0;
        const a = [...e];
        if (a.reduce((l, u) => l.add(u.amount), new f(0)).gt(this.getMaxBetAmount)) {
            const l = a.reduce((u, i) => u.concat(i.action.nums), []);
            this.warningNumList = l, this.isSlotsError = !0, this.sounds.playSound("warningSound")
        } else
            for (; a.length > 0 && n;) {
                await v1(100);
                const l = a.shift();
                l && (n = this.changeBetChipList(l.action, "add", l.amount))
            }
    }
    betBackFn(e) {
        if (this.isBetting) return;
        const n = [...this.betChipList];
        n.length > 0 && (e ? (this.betChipList = [], this.amount = _) : (n.pop(), this.betChipList = n, n.length > 0 ? this.amount = n.slice(-1)[0].amount : this.amount = _))
    }
    setHoverList(e) {
        this.hoverNumList = [...e]
    }
    setWarningList(e) {
        this.warningNumList = [...e]
    }
    maxLenSetbetList(e) {
        if (!e) return !1;
        if (e.amount.gt(this.getMaxBetAmount)) {
            const a = e.betInfo.slice(-1)[0].action.nums;
            return this.setWarningList(a), this.isSlotsError = !0, this.sounds.playSound("warningSound"), e.amount.gt(this.maxAmount) && O("Bet Amount Invalid. Maximum amount " + this.maxAmount.toNumber() + "."), !1
        }
        const n = Q.exports.cloneDeep(this.betChipList);
        return n.push(e), n.length > 50 && n.unshift(), this.betChipList = n, this.amount = e.amount, this.sounds.playSound("chipClickSound"), !0
    }
    getBetAmountInfoByList() {
        if (this.betChipList.length === 0 || this.amount.lte(0)) return [];
        const e = this.betChipList.slice(-1)[0],
            n = [],
            a = e.betInfo.length,
            c = V.dict[this.currencyName].precision,
            u = this.amount.toDP(c, f.ROUND_DOWN).div(this.chip.unit);
        return e.betInfo.forEach((i, p) => {
            if (p === a - 1) {
                const m = n.reduce((h, S) => h.add(S.chips), _),
                    d = u.sub(m).round(),
                    g = this.amount.mul(i.amountPercent);
                n.push(x(M({}, i), {
                    chips: d,
                    amount: g
                }))
            } else {
                const m = this.amount.mul(i.amountPercent),
                    d = Math.floor(m.div(this.chip.unit).toNumber());
                n.push(x(M({}, i), {
                    chips: new f(d),
                    amount: m
                }))
            }
        }), n
    }
    gameValueDecoder(e) {
        return Tt(e)
    }
    betValue() {
        const e = this.getBetAmountInfoByList(),
            n = [];
        let a = [];
        return e.forEach(c => {
            c.chips.gt(0) && (a = a.concat(c.action.nums), n.push({
                type: c.action.type,
                betAmount: E1(c.chips.mul(this.chip.unit)),
                column: c.action.column
            }))
        }), this.betNumList = [...new Set(a)], this.manualBetting = !0, $t({
            bets: n
        })
    }
}

function Gt() {
    return w()
}
const O1 = new Pt;
var Ot = O1;
window.rtg = O1;

function Wt({
    bodyLock: o
}) {
    const t = q();
    return s(a1, {
        title: t("common.fairness"),
        children: s(A1, {
            bodyLock: o,
            children: r("div", {
                className: "item",
                children: [s("h2", {
                    children: "How are results calculated?"
                }), r("div", {
                    className: "help-content",
                    children: [s("p", {
                        children: "To get the results."
                    }), r("ul", {
                        children: [s("li", {
                            children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                        }), s("li", {
                            children: "Finally, we take 8 characters of the hash and convert it to an int32 value. Then we divide the converted value by 0x100000000, multiply it by 37 so that the resulting number conforms to the constraints of the range."
                        })]
                    }), s("br", {}), s("p", {
                        children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                    }), s("p", {}), s("p", {
                        children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                    }), s("p", {
                        children: 'We put our "cards on the table." '
                    }), s("p", {
                        children: "Good luck!"
                    })]
                })]
            })
        })
    })
}
const Ft = "https://bcgame-project.github.io/verify/roulettesingle.html",
    Vt = () => {
        const o = pe(),
            t = be(o),
            e = fe(() => ({
                serverSeed: t[0] || "",
                clientSeed: t[1] || "",
                nonce: parseInt(t[2]) || 0
            })),
            {
                serverSeed: n,
                clientSeed: a,
                nonce: c
            } = e,
            l = String(ge(n)),
            i = String(ye([a, c].join(":"), n)),
            p = jt(i),
            m = zt(p.hex);
        return s(a1, {
            title: ve.t("common.validate"),
            children: r(B1, {
                className: Ut,
                children: [s("h2", {
                    children: "Input"
                }), s(W, {
                    label: "Server Seed",
                    value: n,
                    onChange: d => e.serverSeed = d
                }), s(W, {
                    label: "Client Seed",
                    value: a,
                    onChange: d => e.clientSeed = d
                }), s(W, {
                    label: "Nonce",
                    value: c,
                    onChange: d => e.nonce = Number(d)
                }), s("h2", {
                    children: "Output"
                }), s(W, {
                    label: "Sha256(server_seed)",
                    value: l,
                    readOnly: !0
                }), s(W, {
                    label: "Hmac_sha256(client_seed:nonce, server_seed)",
                    value: i,
                    readOnly: !0
                }), s("h2", {
                    children: "Final Result"
                }), r("div", {
                    className: "result-list result-item",
                    children: [s("p", {
                        children: "hmac_sha256(client_seed:nonce, server_seed)"
                    }), s("div", {
                        className: "table-wrap",
                        children: s("table", {
                            children: s("tbody", {
                                children: [p.dec, p.hex].map((d, g) => s("tr", {
                                    children: d.map((h, S) => s("td", {
                                        children: h
                                    }, "td-" + S))
                                }, "tr-" + g))
                            })
                        })
                    })]
                }), r("div", {
                    className: "result-number result-item",
                    children: [r("div", {
                        children: [`(${p.dec[0]}, ${p.dec[1]}, ${p.dec[2]}, ${p.dec[3]}) -> [0, ...4] = `, s("span", {
                            className: "sp",
                            children: m.result
                        })]
                    }), p.dec.slice(0, 4).map((d, g) => r("div", {
                        className: "rst",
                        children: [s("span", {
                            className: "symbol",
                            children: g === 0 ? "" : "+"
                        }), s("span", {
                            className: "num",
                            children: m.clscList[g]
                        }), s("span", {
                            className: "calc",
                            children: `( ${p.dec[g]} / ( 256 ^ ${g+1} )`
                        })]
                    }, g.toString())), r("div", {
                        className: "rst",
                        children: [s("span", {
                            className: "symbol",
                            children: "="
                        }), s("span", {
                            className: "num",
                            children: m.resultStep
                        }), s("span", {
                            className: "calc",
                            children: "( * 37 )"
                        })]
                    }), r("div", {
                        className: "rst",
                        children: [s("span", {
                            className: "symbol",
                            children: "="
                        }), s("span", {
                            className: "num sp",
                            children: m.result
                        })]
                    })]
                }), s("p", {
                    className: "githubverify",
                    children: s("a", {
                        href: `${Ft}?s=${e.serverSeed}&c=${e.clientSeed}&n=${e.nonce}`,
                        target: "_blank",
                        children: "Verify on Github"
                    })
                })]
            })
        })
    };

function jt(o) {
    let t = {
        dec: [],
        hex: []
    };
    for (let e = 0; e < o.length; e += 2) {
        let n = o[e] + o[e + 1],
            a = parseInt(n, 16);
        t.dec.push(n), t.hex.push(a)
    }
    return t
}

function zt(o) {
    const t = o[0] / Math.pow(256, 1),
        e = o[1] / Math.pow(256, 2),
        n = o[2] / Math.pow(256, 3),
        a = o[3] / Math.pow(256, 4),
        c = (t + e + n + a) * 37,
        l = Math.floor(c);
    return {
        clscList: [t.toFixed(9), e.toFixed(9), n.toFixed(9), a.toFixed(9)],
        resultStep: c.toFixed(9),
        result: l
    }
}
var qt = Vt;
M1({
    cl1: [j("#99a4b0", .8), j("#5f6975", .8)]
});
const Ut = "fn6dmpk";
const Kt = Ne(() => Se(() =>
        import ("./DetailArea.0f57f38a.js"), ["assets/DetailArea.0f57f38a.js", "assets/DetailArea.cea8ce12.css", "assets/index.28e31dff.js", "assets/index.3647d14f.css", "assets/lodash.f3c7da90.js", "assets/index.dd8128e8.js", "assets/index.06a59a68.js"])),
    Jt = (o, t, e, n, a) => {
        Ae(`/roulette_help/validate/${o}/${t}/${e}`)
    },
    Yt = t1.withSingleDetail({
        onValidate: Jt,
        result: ({
            betLog: o
        }) => {
            const t = q(),
                e = o.bv.bets,
                n = o.gv.result;
            return s(we, {
                className: "rt_items",
                children: r("div", {
                    className: Qt,
                    children: [s("p", {
                        className: "result-title",
                        children: t("common.result")
                    }), s("div", {
                        className: "roulette-single-result-wrap",
                        children: s(Kt, {
                            bets: e,
                            currencyName: o.currencyName,
                            result: n
                        })
                    })]
                })
            })
        }
    }),
    Qt = "dcsuy77";
var Xt = Yt,
    l2 = Object.freeze(Object.defineProperty({
        __proto__: null,
        Game: Ot,
        Fairness: Wt,
        Validate: qt,
        Detail: Xt
    }, Symbol.toStringTag, {
        value: "Module"
    }));
export {
    Ge as C, c2 as a, Ee as g, l2 as i, v as s
};
var x = Object.defineProperty;
var v = Object.getOwnPropertySymbols;
var A = Object.prototype.hasOwnProperty,
    D = Object.prototype.propertyIsEnumerable;
var y = (n, t, r) => t in n ? x(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : n[t] = r,
    b = (n, t) => {
        for (var r in t || (t = {})) A.call(t, r) && y(n, r, t[r]);
        if (v)
            for (var r of v(t)) D.call(t, r) && y(n, r, t[r]);
        return n
    };
import {
    r as g,
    j as o,
    a as e,
    A as L,
    cd as I,
    o as j,
    e as w,
    x as N,
    s as P,
    l as T,
    J as H,
    bv as q,
    y as O,
    t as k,
    q as R
} from "./index.28e31dff.js";
const F = function({
        labelNode: t,
        children: r,
        open: a
    }) {
        const [i, s] = g.exports.useState(a || !1);
        return o("div", {
            className: `${W} toggle-item`,
            children: [o("div", {
                className: "toggle-nav",
                onClick: () => s(!i),
                children: [t, e(L, {
                    className: "open-icon " + (i ? "open" : ""),
                    name: "Arrow"
                })]
            }), e(I, {
                visible: i,
                children: r
            })]
        })
    },
    W = "tcj4aj0";
const $ = j(function({
        br: n,
        en: t,
        id: r,
        isCoinlimit: a = !1,
        isSuport: i = !1
    }) {
        const s = g.exports.useRef(null),
            m = w(),
            u = l => l === "pt-BR" ? n : l === "id-ID" ? r : t,
            c = new DOMParser().parseFromString(u(N.lng), "text/html").querySelectorAll("section"),
            f = () => {
                let l = "";
                for (let d = 0; d < c.length; d++) l += c[d].innerHTML;
                return l
            };
        return g.exports.useEffect(() => {
            s.current && s.current.addEventListener("click", l => {
                const h = l.target.getAttribute("href") || "";
                /^\//.test(h) && (l.preventDefault(), m(h))
            })
        }, []), P.isMobile ? e("div", {
            ref: s,
            children: e(C, {
                br: n,
                en: t,
                id: r,
                isCoinlimit: a,
                isSuport: i
            })
        }) : o("div", {
            className: T("doc-page", J),
            children: [i && e(S, {}), e("div", {
                className: "item",
                ref: s,
                dangerouslySetInnerHTML: {
                    __html: f()
                }
            }), a && e("div", {
                className: "item",
                children: e(M, {})
            })]
        })
    }),
    M = () => {
        const n = b({}, H.dict),
            t = r => new O(10).pow(-r.precision).toFixed(r.precision);
        return o(q, {
            stripe: !0,
            hover: !1,
            children: [e("thead", {
                children: o("tr", {
                    children: [e("th", {
                        children: e("span", {
                            children: "Currency"
                        })
                    }), e("th", {
                        children: e("span", {
                            children: "Accuracy Limit"
                        })
                    })]
                })
            }), e("tbody", {
                children: Object.keys(n).map((r, a) => o("tr", {
                    children: [e("td", {
                        children: e("span", {
                            children: H.getAlias(n[r].currencyName)
                        })
                    }), e("td", {
                        children: e("span", {
                            children: t(n[r]).toString()
                        })
                    })]
                }, a))
            })]
        })
    },
    S = () => e("p", {
        className: `${B} icon-p`,
        children: e("a", {
            href: "https://help.bc.game/en/",
            target: "_blank",
            rel: "noopener noreferrer",
            children: e(L, {
                name: "Support"
            })
        })
    }),
    B = "sbu3o0g",
    C = function({
        br: n,
        en: t,
        isCoinlimit: r = !1,
        isSuport: a = !1
    }) {
        const s = new DOMParser().parseFromString(N.lng === "pt-BR" ? n : t, "text/html").querySelectorAll("section"),
            m = () => {
                let p = "";
                for (let c = 0; c < s.length; c++) p += s[c].innerHTML;
                return p
            },
            u = () => a ? null : Array.from(s).map((p, c) => {
                var d;
                const f = ((d = p.querySelector("h2")) == null ? void 0 : d.innerHTML) || "",
                    l = p.querySelectorAll("p, .content");
                return o(F, {
                    labelNode: e("h2", {
                        dangerouslySetInnerHTML: {
                            __html: f
                        }
                    }),
                    open: c === 0,
                    children: [Array.from(l).map((h, _) => e("div", {
                        className: "content",
                        dangerouslySetInnerHTML: {
                            __html: h.innerHTML
                        }
                    }, _)), r && e(M, {})]
                }, "section-" + c)
            });
        return o("div", {
            className: T("doc-page", E),
            children: [u(), a && o("div", {
                className: "support-info",
                children: [e(S, {}), e("div", {
                    dangerouslySetInnerHTML: {
                        __html: m()
                    }
                })]
            })]
        })
    };
var G = $;
const E = "mx9n9ro";
k({
    cl1: ["#dfe2e6", "#31373d"],
    cl2: [R("#24262b", .6), "#f5f6fa"]
});
const J = "sav515t";
export {
    G as H
};
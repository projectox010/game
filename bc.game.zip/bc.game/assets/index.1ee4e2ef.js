var it = Object.defineProperty,
    rt = Object.defineProperties;
var at = Object.getOwnPropertyDescriptors;
var te = Object.getOwnPropertySymbols;
var xe = Object.prototype.hasOwnProperty,
    Ne = Object.prototype.propertyIsEnumerable;
var be = (c, t, i) => t in c ? it(c, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: i
    }) : c[t] = i,
    I = (c, t) => {
        for (var i in t || (t = {})) xe.call(t, i) && be(c, i, t[i]);
        if (te)
            for (var i of te(t)) Ne.call(t, i) && be(c, i, t[i]);
        return c
    },
    we = (c, t) => rt(c, at(t));
var Z = (c, t) => {
    var i = {};
    for (var n in c) xe.call(c, n) && t.indexOf(n) < 0 && (i[n] = c[n]);
    if (c != null && te)
        for (var n of te(c)) t.indexOf(n) < 0 && Ne.call(c, n) && (i[n] = c[n]);
    return i
};
import {
    a5 as B,
    u as g,
    a as e,
    k as Ge,
    a7 as F,
    j as r,
    I as X,
    r as v,
    aV as ot,
    l as y,
    o as _,
    s as C,
    C as ft,
    p as ie,
    b as N,
    cQ as st,
    cR as lt,
    ba as mt,
    bb as $,
    bc as ce,
    d as h,
    bN as ke,
    $ as k,
    am as de,
    A as j,
    t as M,
    q as x,
    N as P,
    a3 as L,
    D as R,
    S as U,
    bi as Te,
    G,
    ak as ut,
    v as T,
    m as dt,
    F as ee,
    e as Y,
    J as S,
    bv as oe,
    cS as re,
    x as K,
    a$ as Me,
    bI as vt,
    bJ as pt,
    bK as gt,
    al as ae,
    ah as ht,
    ao as q,
    cT as ve,
    L as Pe,
    ax as yt,
    a4 as fe,
    bM as De,
    cU as bt,
    a2 as se,
    bo as Ee,
    b2 as xt,
    H as Nt,
    T as wt,
    ap as kt,
    bs as je,
    y as Ce,
    aQ as jt,
    Y as qe,
    cV as Ct,
    cW as _t,
    z as zt,
    a1 as It,
    _ as Lt,
    O as At,
    cm as St
} from "./index.28e31dff.js";
import {
    P as Bt,
    S as Gt
} from "./usePixiGsap.bf451f35.js";
const Tt = B.memo(({
    data: c,
    it: t
}) => {
    const i = g(),
        n = c.userName === "****" ? i("common.hidden") : c.userName;
    return e(Ge.div, {
        style: I({
            position: "absolute"
        }, t),
        children: e(F, {
            title: `${n}: ${c.quantity} tickets`,
            children: r("div", {
                className: "win-item",
                children: [e("b", {
                    children: n
                }), " ", e(X, {
                    k: "page.lottery.bought_tickets",
                    children: e("span", {
                        children: c.quantity
                    })
                })]
            })
        })
    })
});

function Mt({
    list: c
}) {
    const [t, i] = v.exports.useState(0), n = c[t % c.length], a = ot(n, {
        from: {
            y: "100%"
        },
        enter: {
            y: "0%"
        },
        leave: {
            y: "-100%"
        }
    });
    return v.exports.useEffect(() => {
        const s = window.setInterval(() => i(o => o + 1), 3e3);
        return () => {
            clearInterval(s)
        }
    }, [c]), e("div", {
        className: y(Pt, "auto-scroll"),
        children: a((s, o, m, l) => e(Tt, {
            data: o,
            it: s
        }, l))
    })
}
const Pt = "al8y64g";
var $e = "/assets/bonus.4dbbf756.png",
    Dt = "/assets/jackpot_ball_banner.d504da09.png",
    Et = "/assets/jackpot_ball_banner_white.bb538a6c.png",
    Re = "/assets/ball.161fa8af.png",
    He = "/assets/jackpot_ball.23b29c5d.png",
    pe = "/assets/ball_white.d3c1de7f.png",
    qt = "/assets/m_jackpot_ball_bg.f5958b54.png",
    $t = "/assets/m_jackpot_ball_w.8610971b.png";
const Ve = _(function({
        nums: t,
        jackpotNum: i,
        className: n
    }) {
        return r("div", {
            className: y(Ht, n && n),
            children: [e("img", {
                className: "jackpot-bg",
                src: C.isDarken ? Dt : Et,
                alt: ""
            }), e("div", {
                className: "nums",
                children: t.map(a => r("div", {
                    className: "ball",
                    children: [e("img", {
                        src: C.isDarken ? Re : pe,
                        alt: ""
                    }), e("div", {
                        className: "num",
                        children: a
                    })]
                }, a))
            }), r("div", {
                className: "jackpotNum",
                children: [e("img", {
                    src: He
                }), e("div", {
                    className: "num",
                    children: i
                })]
            })]
        })
    }),
    Rt = _(function({
        nums: t,
        jackpotNum: i,
        className: n
    }) {
        return r("div", {
            className: y(Vt, n && n),
            children: [e("img", {
                className: "jackpot-bg",
                src: C.isDarken ? qt : $t
            }), e("div", {
                className: "nums",
                children: t.map(a => r("div", {
                    className: "ball",
                    children: [e("img", {
                        className: "ball-img",
                        src: C.isDarken ? Re : pe,
                        alt: ""
                    }), e("div", {
                        className: "num",
                        children: a
                    })]
                }, a))
            }), r("div", {
                className: "jackpotNum",
                children: [e("img", {
                    className: "ball-img",
                    src: He
                }), e("div", {
                    className: "num",
                    children: i
                })]
            })]
        })
    });

function We(c) {
    return C.isMobile ? e(Rt, I({}, c)) : e(Ve, I({}, c))
}
const Ht = "vj7ioha",
    Vt = "m3yx6gv";
var Wt = "/assets/banner.5b92f69a.png",
    Ot = "/assets/banner_mobile.c2ba6baf.png",
    Ft = "/assets/coco.d8d0203a.png",
    Ut = "/assets/whatisbcl.8079172d.png",
    Jt = "/assets/drawn.e19abca7.png";
const Kt = {
        hash: "K08D47CGnBNRt/FX3geZtGDKILI",
        spine: "3.8.95",
        x: -200.91,
        y: 24.36,
        width: 397.43,
        height: 232.77,
        images: "./images/",
        audio: "D:/\u5176\u4ED6\u9879\u76EE\u7EC4\u7684\u4E1C\u897F/\u7ED3\u7B97/images"
    },
    Xt = [{
        name: "root"
    }, {
        name: "bone2",
        parent: "root",
        length: 100.02,
        rotation: 91.19,
        x: -55.11,
        y: 47.35,
        color: "ffeb00ff"
    }, {
        name: "bone3",
        parent: "bone2",
        length: 38.78,
        rotation: -1.19,
        x: 7.43,
        y: -52.56,
        color: "ffeb00ff"
    }, {
        name: "bone4",
        parent: "bone3",
        length: 32.34,
        rotation: 2.15,
        x: 39.39,
        color: "ffeb00ff"
    }, {
        name: "bone5",
        parent: "bone4",
        length: 32.63,
        rotation: 11.46,
        x: 32.34,
        color: "ffeb00ff"
    }, {
        name: "bone6",
        parent: "bone5",
        length: 34.87,
        rotation: -93.6,
        x: 10.64,
        y: -14.42,
        color: "ffeb00ff"
    }, {
        name: "bone7",
        parent: "bone4",
        length: 27.31,
        rotation: -89.18,
        x: 14.08,
        y: -23.37,
        color: "ffeb00ff"
    }, {
        name: "bone8",
        parent: "bone7",
        length: 52.17,
        rotation: -100.53,
        x: 16.45,
        y: -2.67,
        color: "ffeb00ff"
    }, {
        name: "bone9",
        parent: "bone4",
        length: 18,
        rotation: 132.85,
        x: 25.52,
        y: 1.27,
        color: "ffeb00ff"
    }, {
        name: "bone10",
        parent: "bone9",
        length: 20.95,
        rotation: 79,
        x: 18,
        color: "ffeb00ff"
    }, {
        name: "bone11",
        parent: "bone5",
        x: 40.51,
        y: 4.81,
        color: "ffeb00ff"
    }, {
        name: "bone12",
        parent: "bone5",
        x: 39.62,
        y: -15.23,
        color: "ffeb00ff"
    }, {
        name: "bone13",
        parent: "bone12",
        x: -5.49,
        y: 21.77,
        color: "ffeb00ff"
    }, {
        name: "bone14",
        parent: "bone12",
        x: -5.57,
        y: -.5,
        color: "ffeb00ff"
    }, {
        name: "bone15",
        parent: "bone14",
        x: 2.28,
        y: 3.03,
        color: "ffeb00ff"
    }, {
        name: "bone16",
        parent: "bone13",
        x: 2.92,
        y: 2.38,
        color: "ffeb00ff"
    }, {
        name: "bone17",
        parent: "bone5",
        x: 55.45,
        y: 8.27,
        color: "ffeb00ff"
    }, {
        name: "bone18",
        parent: "bone5",
        x: 52.7,
        y: -11.04,
        color: "ffeb00ff"
    }, {
        name: "bone19",
        parent: "bone5",
        length: 27.04,
        rotation: 13.07,
        x: 43.57,
        y: 1.46,
        color: "ffeb00ff"
    }, {
        name: "bone20",
        parent: "bone4",
        x: 27.27,
        y: -21.05,
        color: "ffeb00ff"
    }, {
        name: "bone21",
        parent: "bone20",
        length: 10.76,
        rotation: 86.45,
        x: .07,
        y: 3.5,
        color: "ffeb00ff"
    }, {
        name: "bone22",
        parent: "bone20",
        length: 6.41,
        rotation: -90.38,
        x: -.11,
        y: -2.97,
        color: "ffeb00ff"
    }, {
        name: "bone23",
        parent: "root",
        x: -2.76,
        y: 45.53
    }, {
        name: "bone24",
        parent: "root",
        x: 102.6,
        y: 160.19,
        color: "0dff00ff"
    }, {
        name: "bone25",
        parent: "root",
        x: 164.19,
        y: 111.46,
        color: "0dff00ff"
    }, {
        name: "bone26",
        parent: "root",
        x: 33.23,
        y: 203.25,
        color: "0dff00ff"
    }, {
        name: "bone27",
        parent: "root",
        x: -42.42,
        y: 197.87,
        color: "0dff00ff"
    }, {
        name: "bone28",
        parent: "root",
        x: -124.94,
        y: 154.51,
        color: "0dff00ff"
    }, {
        name: "bone29",
        parent: "root",
        x: -183.24,
        y: 107.87,
        color: "0dff00ff"
    }, {
        name: "bone30",
        parent: "root",
        length: 24.22,
        rotation: -28.78,
        x: -93.84,
        y: 152.72
    }, {
        name: "bone31",
        parent: "root",
        x: 83.5,
        y: 85.29,
        color: "fa00ffff"
    }, {
        name: "bone32",
        parent: "root",
        x: -38.51,
        y: 91.57,
        color: "fa00ffff"
    }, {
        name: "bone33",
        parent: "root",
        x: -13.25,
        y: 93.98,
        color: "fa00ffff"
    }, {
        name: "bone34",
        parent: "root",
        x: -20.52,
        y: 89.62,
        color: "fa00ffff"
    }, {
        name: "bone35",
        parent: "root",
        x: -20.83,
        y: 83.49,
        color: "fa00ffff"
    }, {
        name: "bone36",
        parent: "root",
        x: .46,
        y: 107.52,
        color: "fa00ffff"
    }, {
        name: "bone37",
        parent: "root",
        x: .62,
        y: 100.51,
        color: "fa00ffff"
    }, {
        name: "bone38",
        parent: "root",
        x: .63,
        y: 94.54,
        color: "fa00ffff"
    }, {
        name: "bone39",
        parent: "root",
        x: -1.19,
        y: 89.94,
        color: "fa00ffff"
    }, {
        name: "bone40",
        parent: "root",
        x: 59.27,
        y: 96.63,
        color: "fa00ffff"
    }, {
        name: "bone41",
        parent: "root",
        x: 1.16,
        y: 86.34,
        color: "fa00ffff"
    }, {
        name: "bone42",
        parent: "root",
        x: 22.63,
        y: 96.36,
        color: "fa00ffff"
    }, {
        name: "bone43",
        parent: "root",
        rotation: 90,
        x: 24.1,
        y: 86.6,
        color: "fa00ffff"
    }, {
        name: "bone44",
        parent: "root",
        rotation: 90,
        x: 38.68,
        y: 90.02,
        color: "fa00ffff"
    }, {
        name: "bone45",
        parent: "root",
        x: 19.23,
        y: 90.23,
        color: "fa00ffff"
    }, {
        name: "bone46",
        parent: "root",
        x: -86.79,
        y: 202.79
    }, {
        name: "bone47",
        parent: "root",
        x: 82.66,
        y: 119.79
    }, {
        name: "bone48",
        parent: "root",
        x: -52.87,
        y: 89.96,
        color: "fa00ffff"
    }, {
        name: "xingxing1",
        parent: "root",
        rotation: -32.12,
        x: -50.21,
        y: 85.97,
        scaleX: .6833,
        scaleY: .6833,
        color: "ff004fff"
    }, {
        name: "xingxing2",
        parent: "root",
        rotation: -37.24,
        x: -8.46,
        y: 105.04,
        scaleX: .7006,
        scaleY: .7006,
        color: "ff004fff"
    }, {
        name: "xingxing3",
        parent: "root",
        x: 16.28,
        y: 83.25,
        scaleX: .5479,
        scaleY: .5479,
        color: "ff004fff"
    }, {
        name: "xingxing4",
        parent: "root",
        x: 37.9,
        y: 87.4,
        scaleX: .666,
        scaleY: .666,
        color: "ff004fff"
    }, {
        name: "xingxing5",
        parent: "root",
        rotation: -42.31,
        x: 51.05,
        y: 94.32,
        scaleX: .666,
        scaleY: .666,
        color: "ff004fff"
    }, {
        name: "bone49",
        parent: "root",
        length: 24.22,
        rotation: -28.78,
        x: 69.46,
        y: 192.83
    }, {
        name: "guangxian1",
        parent: "bone23",
        length: 205.02,
        rotation: 90,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian2",
        parent: "bone23",
        length: 205.02,
        rotation: 120,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian3",
        parent: "bone23",
        length: 205.02,
        rotation: 150,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian4",
        parent: "bone23",
        length: 205.02,
        rotation: 180,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian5",
        parent: "bone23",
        length: 205.02,
        rotation: -150,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian6",
        parent: "bone23",
        length: 205.02,
        rotation: -120,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian7",
        parent: "bone23",
        length: 205.02,
        rotation: -90,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian8",
        parent: "bone23",
        length: 205.02,
        rotation: -60,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian9",
        parent: "bone23",
        length: 205.02,
        rotation: -30,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian10",
        parent: "bone23",
        length: 205.02,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian11",
        parent: "bone23",
        length: 205.02,
        rotation: 30,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }, {
        name: "guangxian12",
        parent: "bone23",
        length: 205.02,
        rotation: 60,
        x: -.07,
        y: .03,
        color: "17ff00ff"
    }],
    Yt = [{
        name: "jinbi18",
        bone: "root",
        attachment: "jinbi17"
    }, {
        name: "Group-1",
        bone: "guangxian1",
        attachment: "Group-1"
    }, {
        name: "Group-2",
        bone: "guangxian2",
        attachment: "Group-1"
    }, {
        name: "Group-3",
        bone: "guangxian3",
        attachment: "Group-1"
    }, {
        name: "Group-4",
        bone: "guangxian4",
        attachment: "Group-1"
    }, {
        name: "Group-5",
        bone: "guangxian5",
        attachment: "Group-1"
    }, {
        name: "Group-6",
        bone: "guangxian6",
        attachment: "Group-1"
    }, {
        name: "Group-7",
        bone: "guangxian7",
        attachment: "Group-1"
    }, {
        name: "Group-8",
        bone: "guangxian8",
        attachment: "Group-1"
    }, {
        name: "Group-9",
        bone: "guangxian9",
        attachment: "Group-1"
    }, {
        name: "Group-10",
        bone: "guangxian10",
        attachment: "Group-1"
    }, {
        name: "Group-11",
        bone: "guangxian11",
        attachment: "Group-1"
    }, {
        name: "Group-12",
        bone: "guangxian12",
        attachment: "Group-1"
    }, {
        name: "shou2",
        bone: "bone7",
        attachment: "shou2"
    }, {
        name: "maozi2",
        bone: "bone19",
        attachment: "maozi"
    }, {
        name: "shenti",
        bone: "bone3",
        attachment: "shenti"
    }, {
        name: "yangkang2",
        bone: "bone11",
        attachment: "yangkang1"
    }, {
        name: "yankuang3",
        bone: "bone12",
        attachment: "yankuang2"
    }, {
        name: "yanzhu4",
        bone: "bone14",
        attachment: "yanzhu2"
    }, {
        name: "yanzhu2",
        bone: "bone14"
    }, {
        name: "gaoguang4",
        bone: "bone15",
        attachment: "gaoguang2"
    }, {
        name: "yanzhu3",
        bone: "bone13",
        attachment: "yanzhu1"
    }, {
        name: "gaoguang3",
        bone: "bone16",
        attachment: "gaoguang1"
    }, {
        name: "mei4",
        bone: "bone18",
        attachment: "mei2"
    }, {
        name: "mei3",
        bone: "bone17",
        attachment: "mei1"
    }, {
        name: "hudiejie",
        bone: "bone20",
        attachment: "hudiejie"
    }, {
        name: "shou1",
        bone: "bone9",
        attachment: "shou1"
    }, {
        name: "guaizhang",
        bone: "bone8",
        attachment: "guaizhang"
    }, {
        name: "caidai9",
        bone: "bone26",
        attachment: "caidai6"
    }, {
        name: "caidai8",
        bone: "bone24",
        attachment: "caidai5"
    }, {
        name: "caidai4",
        bone: "bone27",
        attachment: "caidai4"
    }, {
        name: "caidai3",
        bone: "bone28",
        attachment: "caidai3"
    }, {
        name: "caidai7",
        bone: "bone25",
        attachment: "caidai2"
    }, {
        name: "caidai1",
        bone: "bone29",
        attachment: "caidai1"
    }, {
        name: "jinbi21",
        bone: "bone47",
        attachment: "jinbi18"
    }, {
        name: "jinbi17",
        bone: "bone46",
        attachment: "jinbi17"
    }, {
        name: "zhibi1",
        bone: "bone30",
        attachment: "zhibi1"
    }, {
        name: "zhibi2",
        bone: "bone49",
        attachment: "zhibi1"
    }, {
        name: "jinbi16",
        bone: "bone48",
        attachment: "jinbi16"
    }, {
        name: "jinbi15",
        bone: "bone44",
        attachment: "jinbi15"
    }, {
        name: "jinbi14",
        bone: "bone43",
        attachment: "jinbi14"
    }, {
        name: "jinbi13",
        bone: "bone45",
        attachment: "jinbi13"
    }, {
        name: "jinbi12",
        bone: "bone42",
        attachment: "jinbi12"
    }, {
        name: "jinbi11",
        bone: "bone41",
        attachment: "jinbi11"
    }, {
        name: "jinbi10",
        bone: "bone39",
        attachment: "jinbi10"
    }, {
        name: "jinbi9",
        bone: "bone38",
        attachment: "jinbi9"
    }, {
        name: "jinbi8",
        bone: "bone37",
        attachment: "jinbi8"
    }, {
        name: "jinbi7",
        bone: "bone36",
        attachment: "jinbi7"
    }, {
        name: "jinbi6",
        bone: "bone35",
        attachment: "jinbi6"
    }, {
        name: "jinbi5",
        bone: "bone34",
        attachment: "jinbi5"
    }, {
        name: "jinbi4",
        bone: "bone33",
        attachment: "jinbi4"
    }, {
        name: "jinbi3",
        bone: "bone32",
        attachment: "jinbi3"
    }, {
        name: "jinbi19",
        bone: "bone40",
        attachment: "jinbi2"
    }, {
        name: "jinbi20",
        bone: "bone31",
        attachment: "jinbi1"
    }, {
        name: "shanguang",
        bone: "xingxing1",
        attachment: "shanguang",
        blend: "additive"
    }, {
        name: "shanguang2",
        bone: "xingxing2",
        attachment: "shanguang",
        blend: "additive"
    }, {
        name: "shanguang3",
        bone: "xingxing3",
        attachment: "shanguang",
        blend: "additive"
    }, {
        name: "shanguang4",
        bone: "xingxing4",
        attachment: "shanguang",
        blend: "additive"
    }, {
        name: "shanguang5",
        bone: "xingxing5",
        attachment: "shanguang",
        blend: "additive"
    }],
    Qt = [{
        name: "default",
        attachments: {
            "Group-1": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-2": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-3": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-4": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-5": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-6": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-7": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-8": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-9": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-10": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-11": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            "Group-12": {
                "Group-1": {
                    x: 105.06,
                    y: -1.27,
                    rotation: -90,
                    width: 62,
                    height: 213
                }
            },
            caidai1: {
                caidai1: {
                    x: -.34,
                    width: 8,
                    height: 8
                }
            },
            caidai3: {
                caidai3: {
                    x: .36,
                    y: -.64,
                    width: 12,
                    height: 10
                }
            },
            caidai4: {
                caidai4: {
                    x: .34,
                    y: -.5,
                    width: 13,
                    height: 13
                }
            },
            caidai7: {
                caidai2: {
                    x: .23,
                    y: -.08,
                    width: 10,
                    height: 11
                }
            },
            caidai8: {
                caidai5: {
                    x: -.18,
                    y: .18,
                    width: 10,
                    height: 13
                }
            },
            caidai9: {
                caidai6: {
                    x: .19,
                    y: -.38,
                    width: 10,
                    height: 10
                }
            },
            gaoguang3: {
                gaoguang1: {
                    x: -.18,
                    y: -.2,
                    rotation: -103.61,
                    width: 5,
                    height: 5
                }
            },
            gaoguang4: {
                gaoguang2: {
                    x: .1,
                    y: .44,
                    rotation: -103.61,
                    width: 4,
                    height: 4
                }
            },
            guaizhang: {
                guaizhang: {
                    x: 26.42,
                    y: -1.29,
                    rotation: 97.57,
                    width: 21,
                    height: 63
                }
            },
            hudiejie: {
                hudiejie: {
                    type: "mesh",
                    uvs: [.25366, .02695, .37917, .07074, .53289, .19204, .66656, .20234, .76099, .08452, .9274, .0687, .99999, .20748, .99999, .44123, 1, .74038, .94253, .89613, .73824, .90572, .66259, .76561, .51846, .74465, .34003, .97979, .17138, .99832, .0576, .87046, 0, .6354, 0, .4686, .02, .20507, .11062, .05071, .51268, .45492, .70668, .46586, .85667, .44944, .23468, .47134],
                    triangles: [20, 1, 2, 23, 19, 0, 23, 0, 1, 23, 1, 20, 18, 19, 23, 17, 18, 23, 16, 17, 23, 12, 20, 11, 3, 20, 2, 23, 20, 12, 15, 16, 23, 23, 14, 15, 12, 13, 23, 13, 14, 23, 22, 4, 5, 22, 5, 6, 22, 6, 7, 3, 4, 22, 21, 3, 22, 22, 7, 8, 21, 20, 3, 21, 11, 20, 22, 8, 11, 22, 11, 21, 9, 10, 8, 8, 10, 11],
                    vertices: [2, 19, 8.4, 8.97, .00571, 20, 5.98, -7.98, .99429, 2, 19, 7.44, 5.74, .05108, 20, 2.7, -7.23, .94892, 3, 19, 4.99, 1.83, .36986, 21, -4.84, 5.07, .05089, 20, -1.36, -5.02, .57925, 3, 19, 4.66, -1.63, .37643, 21, -1.37, 4.77, .55129, 20, -4.83, -4.91, .07229, 3, 19, 6.81, -4.17, .10971, 21, 1.16, 6.93, .89005, 20, -7.23, -7.21, 25e-5, 2, 19, 6.95, -8.5, .01425, 21, 5.49, 7.1, .98575, 2, 19, 4.24, -10.29, 39e-5, 21, 7.29, 4.4, .99961, 1, 21, 7.16, -.04, 1, 2, 19, -5.88, -9.91, .00721, 21, 6.98, -5.72, .99279, 2, 19, -8.78, -8.31, .02796, 21, 5.4, -8.63, .97204, 3, 19, -8.76, -2.99, .12699, 21, .08, -8.65, .86704, 20, -7.03, 8.41, .00597, 3, 19, -6.03, -1.13, .28274, 21, -1.8, -5.93, .61357, 20, -4.99, 5.79, .10369, 3, 19, -5.49, 2.6, .2476, 21, -5.53, -5.41, .0944, 20, -1.24, 5.49, .658, 2, 19, -9.78, 7.41, .00867, 20, 3.29, 10.07, .99133, 1, 20, 7.66, 10.53, 1, 1, 20, 10.68, 8.17, 1, 1, 20, 12.29, 3.74, 1, 1, 20, 12.37, .57, 1, 1, 20, 11.97, -4.44, 1, 1, 20, 9.69, -7.43, 1, 2, 19, .02, 2.55, .26118, 20, -.95, -.01, .73882, 2, 19, -.38, -2.49, .11113, 21, -.48, -.27, .88887, 1, 21, 3.43, -.08, 1, 1, 20, 6.27, .48, 1],
                    hull: 20,
                    edges: [0, 38, 0, 2, 2, 4, 4, 6, 6, 8, 8, 10, 10, 12, 16, 18, 18, 20, 24, 26, 26, 28, 28, 30, 30, 32, 36, 38, 20, 22, 22, 24, 12, 14, 14, 16, 32, 34, 34, 36],
                    width: 26,
                    height: 19
                }
            },
            jinbi3: {
                jinbi3: {
                    x: .93,
                    y: -1.19,
                    width: 20,
                    height: 23
                }
            },
            jinbi4: {
                jinbi4: {
                    x: -.33,
                    y: -1.11,
                    width: 24,
                    height: 12
                }
            },
            jinbi5: {
                jinbi5: {
                    x: -.06,
                    y: -.75,
                    width: 24,
                    height: 12
                }
            },
            jinbi6: {
                jinbi6: {
                    x: .25,
                    y: .39,
                    width: 24,
                    height: 12
                }
            },
            jinbi7: {
                jinbi7: {
                    x: -.04,
                    y: -1.65,
                    width: 24,
                    height: 12
                }
            },
            jinbi8: {
                jinbi8: {
                    x: -.2,
                    y: -.63,
                    width: 24,
                    height: 12
                }
            },
            jinbi9: {
                jinbi9: {
                    x: -.21,
                    y: .34,
                    width: 24,
                    height: 12
                }
            },
            jinbi10: {
                jinbi10: {
                    x: -.89,
                    y: -.06,
                    width: 25,
                    height: 12
                }
            },
            jinbi11: {
                jinbi11: {
                    x: -.74,
                    y: -1.47,
                    width: 24,
                    height: 12
                }
            },
            jinbi12: {
                jinbi12: {
                    x: -.21,
                    y: -1.49,
                    width: 24,
                    height: 12
                }
            },
            jinbi13: {
                jinbi13: {
                    x: .69,
                    y: -.36,
                    width: 25,
                    height: 12
                }
            },
            jinbi14: {
                jinbi14: {
                    x: -1.73,
                    y: 1.68,
                    rotation: -90,
                    width: 24,
                    height: 12
                }
            },
            jinbi15: {
                jinbi15: {
                    x: -2.14,
                    y: .26,
                    rotation: -90,
                    width: 24,
                    height: 12
                }
            },
            jinbi16: {
                jinbi16: {
                    x: -1.21,
                    y: -2.09,
                    width: 25,
                    height: 12
                }
            },
            jinbi17: {
                jinbi17: {
                    x: 1.21,
                    y: -1.42,
                    width: 20,
                    height: 21
                }
            },
            jinbi18: {
                jinbi17: {
                    type: "clipping",
                    end: "zhibi2",
                    vertexCount: 4,
                    vertices: [-290.97, 94.27, 343.78, 96.17, 354.55, 372.19, -294.87, 360.13],
                    color: "ce3a3aff"
                }
            },
            jinbi19: {
                jinbi2: {
                    x: -.35,
                    y: -.75,
                    width: 19,
                    height: 14
                }
            },
            jinbi20: {
                jinbi1: {
                    x: -.58,
                    y: .09,
                    width: 13,
                    height: 15
                }
            },
            jinbi21: {
                jinbi18: {
                    x: 1.26,
                    y: -.92,
                    width: 23,
                    height: 16
                }
            },
            maozi2: {
                maozi: {
                    x: .47,
                    y: .3,
                    rotation: -116.68,
                    width: 73,
                    height: 52
                }
            },
            mei3: {
                mei1: {
                    x: -1.58,
                    y: -1.6,
                    rotation: -103.61,
                    width: 11,
                    height: 9
                }
            },
            mei4: {
                mei2: {
                    x: -1.24,
                    y: -.74,
                    rotation: -103.61,
                    width: 10,
                    height: 9
                }
            },
            shanguang: {
                shanguang: {
                    x: .55,
                    y: .51,
                    width: 131,
                    height: 131
                }
            },
            shanguang2: {
                shanguang: {
                    x: .55,
                    y: .51,
                    width: 131,
                    height: 131
                }
            },
            shanguang3: {
                shanguang: {
                    x: .55,
                    y: .51,
                    width: 131,
                    height: 131
                }
            },
            shanguang4: {
                shanguang: {
                    x: .55,
                    y: .51,
                    width: 131,
                    height: 131
                }
            },
            shanguang5: {
                shanguang: {
                    x: .55,
                    y: .51,
                    width: 131,
                    height: 131
                }
            },
            shenti: {
                shenti: {
                    type: "mesh",
                    uvs: [.56836, 0, .69121, .03272, .80119, .02507, .89682, .02497, .95588, .03892, .99814, .08189, .99999, .10963, .99644, .13744, .97598, .16694, .98635, .19692, .97477, .23192, .85833, .27827, .79626, .30108, .79728, .45337, .80753, .55606, .83074, .67665, .8309, .74929, .81838, .78602, .74599, .85481, .79186, .87664, .78588, .9353, .71646, .97506, .56136, .9423, .54522, .96631, .47604, 1, .4481, 1, .31433, .94874, .29534, .89014, .05497, .84461, 0, .81981, 0, .77779, .0761, .74194, .07606, .68367, .1268, .68622, .12706, .62065, .17672, .61923, .1366, .55551, .19122, .52965, .14963, .45803, .2142, .43997, .16703, .40096, .23122, .35613, .18688, .32475, .1961, .29024, .23127, .27478, .19124, .21897, .25287, .19341, .20529, .13838, .2817, .11399, .32196, .05818, .36806, .02659, .48679, 0, .57132, .58196, .56067, .31182, .56585, .18691, .66752, .18683, .84135, .16666, .33036, .56729, .36758, .30459, .39395, .18062, .5785, .75766, .32571, .74438],
                    triangles: [55, 12, 53, 12, 55, 56, 12, 56, 11, 56, 1, 2, 1, 56, 55, 10, 11, 8, 4, 56, 3, 56, 8, 11, 10, 8, 9, 4, 8, 56, 55, 54, 1, 7, 8, 6, 56, 2, 3, 6, 4, 5, 4, 6, 8, 55, 53, 54, 42, 43, 41, 41, 44, 58, 41, 43, 44, 58, 59, 53, 53, 59, 54, 44, 46, 58, 58, 46, 59, 44, 45, 46, 46, 48, 59, 46, 47, 48, 59, 51, 54, 54, 51, 0, 1, 54, 0, 48, 49, 59, 49, 50, 59, 59, 50, 51, 35, 61, 33, 35, 33, 34, 61, 35, 57, 31, 32, 33, 35, 37, 57, 35, 36, 37, 57, 53, 52, 52, 53, 13, 13, 53, 12, 57, 58, 53, 37, 39, 57, 57, 39, 58, 58, 39, 41, 37, 38, 39, 39, 40, 41, 23, 24, 22, 22, 24, 25, 20, 21, 18, 27, 22, 25, 25, 26, 27, 27, 61, 22, 21, 22, 18, 22, 60, 18, 22, 61, 60, 20, 18, 19, 28, 31, 27, 27, 31, 61, 61, 31, 33, 18, 60, 17, 31, 28, 30, 28, 29, 30, 17, 60, 16, 61, 52, 60, 60, 15, 16, 15, 52, 14, 15, 60, 52, 61, 57, 52, 52, 13, 14],
                    vertices: [2, 4, 37.12, -9.41, .84859, 5, -6.67, 26.11, .15141, 2, 4, 29.76, -22.54, .25193, 5, 6.9, 19.59, .74807, 2, 4, 27.63, -35.38, .01782, 5, 19.85, 18.27, .98218, 1, 5, 30.96, 16.32, 1, 1, 5, 37.53, 13.41, 1, 1, 5, 41.51, 7.29, 1, 1, 5, 41.13, 3.87, 1, 1, 5, 40.12, .55, 1, 1, 5, 37.1, -2.64, 1, 1, 5, 37.66, -6.51, 1, 2, 3, 40.05, -48.69, 1e-4, 5, 35.56, -10.55, .9999, 2, 3, 34.82, -34.75, .05889, 5, 21.03, -13.82, .94111, 3, 2, 72.66, -26.09, 6e-5, 3, 32.27, -27.32, .27052, 5, 13.33, -15.33, .72942, 3, 2, 53.78, -26.21, .0925, 3, 13.4, -26.73, .74738, 5, 10.17, -33.95, .16011, 3, 2, 41.05, -27.42, .42924, 3, .63, -27.47, .53247, 5, 9.14, -46.7, .03829, 3, 2, 26.09, -30.16, .84471, 3, -14.42, -29.64, .15275, 5, 9.24, -61.9, .00254, 3, 2, 17.09, -30.18, .94537, 3, -23.42, -29.32, .05458, 5, 7.7, -70.77, 5e-5, 2, 2, 12.53, -28.7, .96855, 3, -27.92, -27.68, .03145, 2, 2, 4, -20.16, .99891, 3, -36.12, -18.82, .00109, 1, 2, 1.29, -25.57, 1, 1, 2, -5.98, -24.87, 1, 1, 2, -10.91, -16.68, 1, 2, 2, -6.85, 1.63, .99685, 3, -46.14, 3.36, .00315, 2, 2, -9.82, 3.53, .99188, 3, -49.05, 5.37, .00812, 2, 2, -14, 11.69, .97364, 3, -52.92, 13.69, .02636, 2, 2, -14, 14.99, .96578, 3, -52.79, 16.98, .03422, 2, 2, -7.65, 30.78, .86759, 3, -45.85, 32.52, .13241, 2, 2, -.38, 33.02, .77853, 3, -38.5, 34.48, .22147, 2, 2, 5.27, 61.38, .54234, 3, -31.8, 62.61, .45766, 2, 2, 8.34, 67.87, .53718, 3, -28.48, 68.98, .46282, 3, 2, 13.55, 67.87, .53594, 3, -23.28, 68.79, .46402, 4, -40.85, 78.46, 5e-5, 3, 2, 18, 58.89, .52034, 3, -19.17, 59.65, .47697, 4, -38.64, 68.69, .00269, 3, 2, 25.22, 58.89, .49717, 3, -11.95, 59.38, .49684, 4, -31.61, 67, .00599, 3, 2, 24.91, 52.9, .4702, 3, -12.49, 53.41, .51791, 4, -33.33, 61.25, .01189, 3, 2, 33.04, 52.87, .4016, 3, -4.37, 53.07, .57219, 4, -25.43, 59.31, .02621, 3, 2, 33.21, 47.01, .34211, 3, -4.41, 47.21, .61412, 4, -26.64, 53.57, .04376, 3, 2, 41.11, 51.75, .23373, 3, 3.66, 51.65, .6861, 4, -17.85, 56.31, .08017, 3, 2, 44.32, 45.3, .17331, 3, 6.63, 45.09, .71026, 4, -16.25, 49.3, .11644, 3, 2, 53.2, 50.21, .09164, 3, 15.68, 49.66, .72732, 4, -6.46, 51.98, .18104, 3, 2, 55.44, 42.59, .05768, 3, 17.64, 41.96, .69791, 4, -6.08, 44.04, .24442, 3, 2, 60.28, 48.16, .02751, 3, 22.68, 47.34, .65741, 4, -.07, 48.32, .31508, 3, 2, 65.84, 40.58, .00984, 3, 27.95, 39.56, .55388, 4, 3.55, 39.65, .43628, 3, 2, 69.73, 45.81, .00108, 3, 32.03, 44.64, .46263, 4, 8.57, 43.82, .53629, 3, 2, 74.01, 44.73, 38e-5, 3, 36.27, 43.4, .44088, 4, 12.47, 41.75, .55874, 3, 2, 75.93, 40.58, 8e-5, 3, 38.03, 39.18, .37673, 4, 13.36, 37.27, .62319, 2, 3, 45.12, 43.64, .28112, 4, 21.2, 40.23, .71888, 2, 3, 48.02, 36.25, .20761, 4, 22.56, 32.42, .79239, 2, 3, 55.05, 41.61, .13835, 4, 30.52, 36.27, .86165, 2, 3, 57.73, 32.48, .10173, 4, 31.34, 26.79, .89827, 2, 3, 64.47, 27.48, .03832, 4, 36.94, 20.55, .96168, 2, 3, 68.18, 21.89, .01455, 4, 39.47, 14.34, .98545, 2, 4, 39.38, -.05, .99601, 5, -16.14, 27.78, .00399, 2, 2, 37.83, .45, .99997, 4, -33.1, 7.23, 3e-5, 2, 3, 31.98, .51, .58214, 4, -.25, .57, .41786, 2, 4, 14.66, -3.67, .84674, 5, -10.98, 3.34, .15326, 2, 4, 11.85, -15.33, .00981, 5, .83, 1.26, .99019, 1, 5, 21.47, .16, 1, 3, 2, 39.65, 28.88, .2114, 3, 1.35, 28.85, .72141, 4, -24.65, 34.43, .0672, 2, 3, 33.73, 23.24, .41233, 4, 5.98, 22.5, .58767, 2, 3, 48.98, 19.56, .0943, 4, 20.19, 15.86, .9057, 1, 2, 16.05, -.4, 1, 3, 2, 17.69, 29.43, .62782, 3, -20.58, 30.22, .36725, 4, -45.86, 40.13, .00493],
                    hull: 52,
                    edges: [0, 102, 0, 2, 2, 4, 4, 6, 6, 8, 8, 10, 20, 22, 22, 24, 24, 26, 26, 28, 28, 30, 30, 32, 32, 34, 34, 36, 36, 38, 38, 40, 40, 42, 42, 44, 44, 46, 46, 48, 48, 50, 50, 52, 52, 54, 54, 56, 56, 58, 58, 60, 60, 62, 62, 64, 64, 66, 66, 68, 68, 70, 70, 72, 72, 74, 74, 76, 82, 84, 84, 86, 86, 88, 88, 90, 94, 96, 96, 98, 98, 100, 100, 102, 14, 16, 18, 20, 16, 18, 10, 12, 12, 14, 76, 78, 78, 80, 80, 82, 90, 92, 92, 94],
                    width: 118,
                    height: 124
                }
            },
            shou1: {
                shou1: {
                    type: "mesh",
                    uvs: [.77539, 0, .78808, .05405, .85935, .4508, .87174, .54609, .96867, .64833, .99999, .74858, 1, .8421, .92499, .94717, .77501, 1, .643, 1, .55964, .95817, .31539, .98277, .25051, .91862, .32153, .72451, .19307, .70465, .05394, .63475, 0, .54622, 0, .4532, .05197, .38055, .35533, .15841, .69262, 0, .33611, .42755, .54756, .26432, .58985, .64129],
                    triangles: [22, 19, 20, 20, 0, 1, 22, 20, 1, 21, 18, 19, 21, 19, 22, 22, 1, 2, 21, 16, 17, 21, 17, 18, 15, 16, 21, 2, 21, 22, 23, 2, 3, 23, 21, 2, 14, 15, 21, 21, 13, 14, 23, 13, 21, 23, 4, 5, 4, 23, 3, 6, 23, 5, 23, 6, 10, 10, 13, 23, 6, 8, 10, 12, 13, 10, 11, 12, 10, 8, 9, 10, 6, 7, 8],
                    vertices: [-5.34, -3.37, -3.93, -1.41, 6.85, 12.5, 9.54, 15.73, 10.6, 21.04, 13.03, 24.85, 15.94, 27.76, 20.85, 29.38, 25.78, 27.74, 28.68, 24.84, 29.2, 21.71, 35.32, 17.13, 34.75, 13.71, 27.15, 9.23, 29.35, 5.79, 30.22, .57, 28.65, -3.37, 25.76, -6.26, 22.36, -7.39, 8.8, -7.65, -3.52, -5.18, 17.59, .31, 7.88, -.14, 18.68, 12.52],
                    hull: 21,
                    edges: [0, 40, 0, 2, 2, 4, 4, 6, 6, 8, 8, 10, 10, 12, 12, 14, 14, 16, 16, 18, 18, 20, 20, 22, 22, 24, 24, 26, 26, 28, 28, 30, 30, 32, 32, 34, 34, 36, 36, 38, 38, 40],
                    width: 31,
                    height: 44
                }
            },
            shou2: {
                shou2: {
                    type: "mesh",
                    uvs: [.35393, .03886, .72603, .03923, .84718, .11034, .94281, .24153, 1, .55805, 1, .68115, .76657, 1, .64582, 1, .2929, .84006, .0589, .681, 0, .52134, 0, .35758, .0308, .23212, .09545, .15626, .39912, .42798, .76388, .52626],
                    triangles: [14, 0, 1, 13, 0, 14, 14, 10, 11, 15, 1, 2, 15, 2, 3, 14, 1, 15, 15, 3, 4, 14, 11, 13, 13, 11, 12, 9, 10, 14, 15, 4, 5, 8, 9, 14, 7, 14, 15, 6, 7, 15, 8, 14, 7, 5, 6, 15],
                    vertices: [11.98, 12.08, 24.62, 11.42, 28.64, 9.43, 31.72, 5.99, 33.25, -2.02, 33.09, -5.09, 24.75, -12.64, 20.65, -12.43, 8.87, -7.81, 1.13, -3.43, -.66, .66, -.45, 4.75, .76, 7.83, 3.06, 9.61, 13.01, 2.29, 25.27, -.81],
                    hull: 14,
                    edges: [0, 26, 0, 2, 2, 4, 4, 6, 6, 8, 8, 10, 10, 12, 12, 14, 14, 16, 16, 18, 18, 20, 20, 22, 22, 24, 24, 26],
                    width: 34,
                    height: 25
                }
            },
            yangkang2: {
                yangkang1: {
                    x: -1.42,
                    y: .29,
                    rotation: -103.61,
                    width: 23,
                    height: 23
                }
            },
            yankuang3: {
                yankuang2: {
                    x: -1.23,
                    y: .44,
                    rotation: -103.61,
                    width: 20,
                    height: 21
                }
            },
            yanzhu3: {
                yanzhu1: {
                    x: -.39,
                    y: -.15,
                    rotation: -103.61,
                    width: 9,
                    height: 8
                }
            },
            yanzhu4: {
                yanzhu2: {
                    x: -.51,
                    y: .05,
                    rotation: -103.61,
                    width: 8,
                    height: 8
                }
            },
            zhibi1: {
                zhibi1: {
                    x: 11.72,
                    y: 2.05,
                    rotation: 28.78,
                    width: 34,
                    height: 28
                }
            },
            zhibi2: {
                zhibi1: {
                    x: 11.72,
                    y: 2.05,
                    rotation: 28.78,
                    width: 34,
                    height: 28
                }
            }
        }
    }],
    Zt = {
        animation1_1: {
            slots: {
                "Group-1": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-2": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-3": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-4": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-5": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-6": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-7": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-8": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-9": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-10": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-11": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                "Group-12": {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                gaoguang3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                gaoguang4: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                guaizhang: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                hudiejie: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                jinbi3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.3,
                        color: "ffffff00"
                    }, {
                        time: 1.4,
                        color: "ffffffff"
                    }]
                },
                jinbi4: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.4,
                        color: "ffffff00"
                    }, {
                        time: 1.5333,
                        color: "ffffffff"
                    }]
                },
                jinbi5: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.2667,
                        color: "ffffff00"
                    }, {
                        time: 1.3667,
                        color: "ffffffff"
                    }]
                },
                jinbi6: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.1333,
                        color: "ffffff00"
                    }, {
                        time: 1.1667,
                        color: "ffffffff"
                    }]
                },
                jinbi7: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.1,
                        color: "ffffff00"
                    }, {
                        time: 1.2,
                        color: "ffffffff"
                    }]
                },
                jinbi8: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1,
                        color: "ffffff00"
                    }, {
                        time: 1.1,
                        color: "ffffffff"
                    }]
                },
                jinbi9: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .9333,
                        color: "ffffff00"
                    }, {
                        time: 1.0333,
                        color: "ffffffff"
                    }]
                },
                jinbi10: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .8667,
                        color: "ffffff00"
                    }, {
                        time: .9,
                        color: "ffffffff"
                    }]
                },
                jinbi11: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .8333,
                        color: "ffffff00"
                    }, {
                        time: .9333,
                        color: "ffffffff"
                    }]
                },
                jinbi12: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        color: "ffffff00"
                    }, {
                        time: 1.2667,
                        color: "ffffffff"
                    }]
                },
                jinbi13: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.1,
                        color: "ffffff00"
                    }, {
                        time: 1.2,
                        color: "ffffffff"
                    }]
                },
                jinbi14: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.0333,
                        color: "ffffff00"
                    }, {
                        time: 1.1333,
                        color: "ffffffff"
                    }]
                },
                jinbi15: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        color: "ffffff00"
                    }, {
                        time: 1.2667,
                        color: "ffffffff"
                    }]
                },
                jinbi16: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        color: "ffffff00"
                    }, {
                        time: 1.2667,
                        color: "ffffffff"
                    }]
                },
                jinbi17: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                jinbi19: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.2333,
                        color: "ffffff00"
                    }, {
                        time: 1.3667,
                        color: "ffffffff"
                    }]
                },
                jinbi20: {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                jinbi21: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                maozi2: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                mei3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                mei4: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                shanguang: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        color: "ffffff00"
                    }]
                },
                shanguang2: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.6667,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 3,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        color: "ffffff00"
                    }]
                },
                shanguang3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 2,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        color: "ffffff00"
                    }]
                },
                shanguang4: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.7667,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.1,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.4333,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 3.1,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.4333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.7667,
                        color: "ffffff00"
                    }]
                },
                shanguang5: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        color: "ffffff00"
                    }]
                },
                shenti: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                shou1: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                shou2: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                yangkang2: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                yankuang3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                yanzhu2: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                yanzhu3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                yanzhu4: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3,
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff"
                    }]
                },
                zhibi1: {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 1.9667,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 2,
                        color: "ffffff00"
                    }, {
                        time: 2.3333,
                        color: "ffffffff"
                    }]
                },
                zhibi2: {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .8,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: .8333,
                        color: "ffffff00"
                    }, {
                        time: 1.1667,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 2.8,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 2.8333,
                        color: "ffffff00"
                    }, {
                        time: 3.1667,
                        color: "ffffffff"
                    }]
                }
            },
            bones: {
                bone2: {
                    translate: [{
                        y: -121.34,
                        curve: "stepped"
                    }, {
                        time: .5,
                        y: -121.34,
                        curve: 0,
                        c2: .22,
                        c3: .75
                    }, {
                        time: .6667,
                        x: 4.27,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .8333,
                        x: -5.21,
                        curve: .25,
                        c3: .965,
                        c4: .87
                    }, {
                        time: .9667
                    }],
                    scale: [{
                        time: .5,
                        curve: 0,
                        c2: .22,
                        c3: .75
                    }, {
                        time: .6667,
                        x: 1.089,
                        y: .938,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .8333,
                        x: .9,
                        y: 1.1,
                        curve: .25,
                        c3: .965,
                        c4: .87
                    }, {
                        time: .9667
                    }]
                },
                bone22: {
                    rotate: [{
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: .5,
                        angle: 6.44,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: -4.15,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: 6.44,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -4.15,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 4
                    }]
                },
                bone21: {
                    rotate: [{
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: .5,
                        angle: -5.82,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: 2.54,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: -5.82,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: 2.54,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 4
                    }]
                },
                bone9: {
                    rotate: [{
                        curve: 0,
                        c2: .16,
                        c3: .75
                    }, {
                        time: .5,
                        angle: -4.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: 5.03,
                        curve: .25,
                        c3: .974,
                        c4: .9
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .16,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: -4.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: 5.03,
                        curve: .25,
                        c3: .974,
                        c4: .9
                    }, {
                        time: 4
                    }]
                },
                bone8: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: 7.93,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 7.93,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone7: {
                    rotate: [{
                        curve: 0,
                        c2: .2,
                        c3: .75
                    }, {
                        time: .5,
                        angle: 7.47,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: -8.03,
                        curve: .25,
                        c4: .91
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .2,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: 7.47,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -8.03,
                        curve: .25,
                        c4: .91
                    }, {
                        time: 4
                    }]
                },
                bone19: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: 2.89,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 2.89,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone18: {
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: 4.23,
                        y: .09,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: 4.23,
                        y: .09,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone17: {
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: 1.93,
                        y: .4,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: 1.93,
                        y: .4,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone14: {
                    translate: [{
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: 1.25
                    }]
                },
                bone13: {
                    translate: [{
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: 1.25
                    }]
                },
                bone6: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: 6.01,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 6.01,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone5: {
                    rotate: [{
                        angle: -4.42,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: -8.85,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        angle: -4.42,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -8.85,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        angle: -4.42
                    }],
                    translate: [{
                        x: -1.4,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        x: -2.8,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        x: -1.4,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: -2.8,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: -1.4
                    }]
                },
                bone4: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: -1.58,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: -1.58,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }],
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: -2.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: -2.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone23: {
                    rotate: [{
                        time: .1333
                    }, {
                        time: .5,
                        angle: -60
                    }, {
                        time: 2,
                        angle: 180
                    }, {
                        time: 4
                    }],
                    scale: [{
                        x: .299,
                        y: .299,
                        curve: "stepped"
                    }, {
                        time: .1333,
                        x: .299,
                        y: .299
                    }, {
                        time: .5
                    }]
                },
                bone28: {
                    rotate: [{
                        angle: -112.28,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: .2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .3,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.3,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 2,
                        angle: -112.28,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: 2.2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.3,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.3,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 4,
                        angle: -112.28
                    }],
                    translate: [{
                        y: -34.57,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: .2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: .3,
                        y: 139.64,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: 1.3,
                        y: 139.64,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 2,
                        y: -34.57,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: 2.2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: 2.3,
                        y: 139.64,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: 3.3,
                        y: 139.64,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 4,
                        y: -34.57
                    }]
                },
                bone27: {
                    rotate: [{
                        angle: -39.3,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: .6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .6667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.6667,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 2,
                        angle: -39.3,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: 2.6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.6667,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 4,
                        angle: -39.3
                    }],
                    translate: [{
                        y: 30.83,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: .6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: .6667,
                        y: 91.8,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: 1.6667,
                        y: 91.8,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 2,
                        y: 30.83,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: 2.6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        y: 91.8,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: 3.6667,
                        y: 91.8,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 4,
                        y: 30.83
                    }]
                },
                bone26: {
                    rotate: [{
                        angle: -97.75,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: .3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .3667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.3667,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 2,
                        angle: -97.75,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: 2.3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.3667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.3667,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 4,
                        angle: -97.75
                    }],
                    translate: [{
                        y: -58.58,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: .3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: .3667,
                        y: 93.1,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: 1.3667,
                        y: 93.1,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 2,
                        y: -58.58,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: 2.3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: 2.3667,
                        y: 93.1,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: 3.3667,
                        y: 93.1,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 4,
                        y: -58.58
                    }]
                },
                bone24: {
                    rotate: [{
                        angle: -143.34,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: .1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .1667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 2,
                        angle: -143.34,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: 2.1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.1667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.1667,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 4,
                        angle: -143.34
                    }],
                    translate: [{
                        y: -87.5,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: .1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: .1667,
                        y: 134.9,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        y: 134.9,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 2,
                        y: -87.5,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: 2.1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: 2.1667,
                        y: 134.9,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: 3.1667,
                        y: 134.9,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 4,
                        y: -87.5
                    }]
                },
                bone25: {
                    rotate: [{
                        angle: -104.83,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: .3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .3333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 2,
                        angle: -104.83,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: 2.3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 4,
                        angle: -104.83
                    }],
                    translate: [{
                        y: 20.52,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: .3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: .3333,
                        y: 183.17,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        y: 183.17,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 2,
                        y: 20.52,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: 2.3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: 2.3333,
                        y: 183.17,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        y: 183.17,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 4,
                        y: 20.52
                    }]
                },
                bone29: {
                    rotate: [{
                        angle: -63.73,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: .5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .5333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.5333,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 2,
                        angle: -63.73,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: 2.5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.5333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.5333,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 4,
                        angle: -63.73
                    }],
                    translate: [{
                        y: 88.16,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: .5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: .5333,
                        y: 187.05,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: 1.5333,
                        y: 187.05,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 2,
                        y: 88.16,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: 2.5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: 2.5333,
                        y: 187.05,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: 3.5333,
                        y: 187.05,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 4,
                        y: 88.16
                    }]
                },
                bone30: {
                    rotate: [{}, {
                        time: 1.9667,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: 2
                    }, {
                        time: 4,
                        angle: -145.47
                    }],
                    translate: [{
                        y: 152.3
                    }, {
                        time: 1.9667,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: 2,
                        y: 152.3
                    }, {
                        time: 4,
                        y: -138.81
                    }]
                },
                bone48: {
                    rotate: [{}, {
                        time: 1.1667,
                        angle: 24.6,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4
                    }, {
                        time: 1.4667,
                        y: 4.69
                    }, {
                        time: 1.5
                    }]
                },
                bone45: {
                    rotate: [{}, {
                        time: 1.1,
                        angle: 27.44,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.3667
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.1,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.3667
                    }]
                },
                bone44: {
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4
                    }, {
                        time: 1.4667,
                        y: 1.32
                    }, {
                        time: 1.5
                    }]
                },
                bone43: {
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.0333,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.2667
                    }]
                },
                bone42: {
                    rotate: [{}, {
                        time: 1.1667,
                        angle: -20.96,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.5333
                    }, {
                        time: 1.6,
                        angle: -19.4
                    }, {
                        time: 1.6667
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.5333
                    }, {
                        time: 1.6,
                        y: 3.69
                    }, {
                        time: 1.6667
                    }]
                },
                bone41: {
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: .8333,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.0333
                    }]
                },
                bone40: {
                    rotate: [{
                        time: 1.2333,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4667,
                        angle: -39.7
                    }, {
                        time: 1.5333,
                        angle: -27.48
                    }, {
                        time: 1.5667
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.2333,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4667,
                        x: -.86,
                        y: -1.05
                    }, {
                        time: 1.5333,
                        x: -.86,
                        y: 1.74
                    }, {
                        time: 1.5667,
                        x: -4.09,
                        y: -5.32
                    }]
                },
                bone39: {
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: .9,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.1333
                    }]
                },
                bone38: {
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: .9333,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.2
                    }]
                },
                bone37: {
                    rotate: [{}, {
                        time: 1,
                        angle: -35.38,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.2333
                    }, {
                        time: 1.3,
                        angle: 4.64
                    }, {
                        time: 1.3333
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.2333
                    }, {
                        time: 1.3,
                        x: .16,
                        y: 2.18
                    }, {
                        time: 1.3333
                    }]
                },
                bone36: {
                    rotate: [{
                        time: 1.4
                    }, {
                        time: 1.4667,
                        angle: 10.43
                    }, {
                        time: 1.5333
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.1,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4
                    }, {
                        time: 1.4667,
                        x: .15,
                        y: 3.31
                    }, {
                        time: 1.5333
                    }]
                },
                bone35: {
                    rotate: [{
                        time: 1.4333
                    }, {
                        time: 1.5,
                        angle: -14.62
                    }, {
                        time: 1.5333
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.4333
                    }, {
                        time: 1.5,
                        y: 1.97
                    }, {
                        time: 1.5333
                    }]
                },
                bone34: {
                    rotate: [{}, {
                        time: 1.2667,
                        angle: 23.37,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.5
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.2667,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.5
                    }]
                },
                bone33: {
                    rotate: [{}, {
                        time: 1.4,
                        angle: -26.48,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.7333
                    }, {
                        time: 1.8333,
                        angle: -30.37
                    }, {
                        time: 1.9
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.4,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.7333
                    }, {
                        time: 1.8333,
                        y: 5.88
                    }, {
                        time: 1.9
                    }]
                },
                bone32: {
                    rotate: [{
                        time: 1.3,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.5333,
                        angle: 32.64
                    }, {
                        time: 1.6,
                        angle: 14.68
                    }, {
                        time: 1.6667
                    }],
                    translate: [{
                        y: 235.73,
                        curve: "stepped"
                    }, {
                        time: 1.3,
                        y: 235.73,
                        curve: .287,
                        c4: .68
                    }, {
                        time: 1.5333,
                        x: -3.88
                    }, {
                        time: 1.6,
                        y: 6.73
                    }, {
                        time: 1.6667
                    }]
                },
                bone46: {
                    rotate: [{
                        time: .3333,
                        curve: 0,
                        c2: .27,
                        c3: .75
                    }, {
                        time: .7667,
                        angle: 23.22
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 23.22,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        angle: 6.59
                    }],
                    translate: [{
                        x: 81.06,
                        y: -134.1,
                        curve: "stepped"
                    }, {
                        time: .3333,
                        x: 81.06,
                        y: -134.1,
                        curve: 0,
                        c2: .27,
                        c3: .75
                    }, {
                        time: .7667,
                        x: -12.35,
                        y: 11.36
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: -12.35,
                        y: 11.36,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        x: -3.5,
                        y: 3.22
                    }]
                },
                bone47: {
                    rotate: [{
                        angle: 18.82,
                        curve: "stepped"
                    }, {
                        time: .4333,
                        angle: 18.82,
                        curve: 0,
                        c2: .18,
                        c3: .75
                    }, {
                        time: .6333,
                        angle: -22.28
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        angle: -22.28,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }],
                    translate: [{
                        x: -86.42,
                        y: -54.24,
                        curve: "stepped"
                    }, {
                        time: .4333,
                        x: -86.42,
                        y: -54.24,
                        curve: 0,
                        c2: .18,
                        c3: .75
                    }, {
                        time: .6333,
                        x: 19.07,
                        y: 8.94
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        x: 19.07,
                        y: 8.94,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone31: {
                    rotate: [{
                        angle: 32.4,
                        curve: "stepped"
                    }, {
                        time: .5,
                        angle: 32.4,
                        curve: 0,
                        c2: .15,
                        c3: .75
                    }, {
                        time: .7,
                        angle: -22.03
                    }, {
                        time: 2.2667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        angle: -22.03,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        angle: -11.02
                    }],
                    translate: [{
                        x: -84.04,
                        y: -6.56,
                        curve: "stepped"
                    }, {
                        time: .5,
                        x: -84.04,
                        y: -6.56,
                        curve: 0,
                        c2: .15,
                        c3: .75
                    }, {
                        time: .7,
                        x: 16.09,
                        y: -12.52
                    }, {
                        time: 2.2667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        x: 16.09,
                        y: -12.52,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        x: 8.05,
                        y: -6.26
                    }]
                },
                xingxing1: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing2: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.6667,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 3,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing3: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 2,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing4: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.7667,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.1,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.4333,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 3.1,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.4333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.7667,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing5: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522
                    }]
                },
                bone49: {
                    rotate: [{
                        angle: -86.3
                    }, {
                        time: .8,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: .8333
                    }, {
                        time: 2.8,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: 2.8333
                    }, {
                        time: 4,
                        angle: -86.3
                    }],
                    translate: [{
                        y: -20.39
                    }, {
                        time: .8,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: .8333,
                        y: 152.3
                    }, {
                        time: 2.8,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: 2.8333,
                        y: 152.3
                    }, {
                        time: 4,
                        y: -20.39
                    }]
                }
            }
        },
        animation2_1: {
            slots: {
                shanguang: {
                    color: [{
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: .3333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: .6667,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        color: "ffffff00"
                    }]
                },
                shanguang2: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: .6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 2.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        color: "ffffff00"
                    }]
                },
                shanguang3: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .6667,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.3333,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        color: "ffffff00"
                    }]
                },
                shanguang4: {
                    color: [{
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: .4333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: .7667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.1,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 2.4333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.7667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.1,
                        color: "ffffff00"
                    }]
                },
                shanguang5: {
                    color: [{
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: .3333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: .6667,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        color: "ffffff00",
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        color: "ffffff00",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        color: "ffffffff",
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        color: "ffffff00"
                    }]
                },
                zhibi1: {
                    color: [{
                        color: "ffffff00"
                    }, {
                        time: .3333,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 1.9667,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 2,
                        color: "ffffff00"
                    }, {
                        time: 2.3333,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 3.9667,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 4,
                        color: "ffffff00"
                    }]
                },
                zhibi2: {
                    color: [{
                        time: .8,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: .8333,
                        color: "ffffff00"
                    }, {
                        time: 1.1667,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 2.8,
                        color: "ffffffff",
                        curve: "stepped"
                    }, {
                        time: 2.8333,
                        color: "ffffff00"
                    }, {
                        time: 3.1667,
                        color: "ffffffff"
                    }]
                }
            },
            bones: {
                bone22: {
                    rotate: [{
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: .5,
                        angle: 6.44,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: -4.15,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: 6.44,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -4.15,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 4
                    }]
                },
                bone21: {
                    rotate: [{
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: .5,
                        angle: -5.82,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: 2.54,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .21,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: -5.82,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: 2.54,
                        curve: .25,
                        c3: .993,
                        c4: .89
                    }, {
                        time: 4
                    }]
                },
                bone9: {
                    rotate: [{
                        curve: 0,
                        c2: .16,
                        c3: .75
                    }, {
                        time: .5,
                        angle: -4.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: 5.03,
                        curve: .25,
                        c3: .974,
                        c4: .9
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .16,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: -4.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: 5.03,
                        curve: .25,
                        c3: .974,
                        c4: .9
                    }, {
                        time: 4
                    }]
                },
                bone8: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: 7.93,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 7.93,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone7: {
                    rotate: [{
                        curve: 0,
                        c2: .2,
                        c3: .75
                    }, {
                        time: .5,
                        angle: 7.47,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: -8.03,
                        curve: .25,
                        c4: .91
                    }, {
                        time: 2,
                        curve: 0,
                        c2: .2,
                        c3: .75
                    }, {
                        time: 2.5,
                        angle: 7.47,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -8.03,
                        curve: .25,
                        c4: .91
                    }, {
                        time: 4
                    }]
                },
                bone19: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: 2.89,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 2.89,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone18: {
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: 4.23,
                        y: .09,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: 4.23,
                        y: .09,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone17: {
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: 1.93,
                        y: .4,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: 1.93,
                        y: .4,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone14: {
                    translate: [{
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: 1.25
                    }]
                },
                bone13: {
                    translate: [{
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        x: 1.25,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: 2.5,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: 1.25
                    }]
                },
                bone6: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: 6.01,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: 6.01,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone5: {
                    rotate: [{
                        angle: -4.42,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        angle: -8.85,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        angle: -4.42,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -8.85,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        angle: -4.42
                    }],
                    translate: [{
                        x: -1.4,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.5,
                        x: -2.8,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 2,
                        x: -1.4,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: -2.8,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: -1.4
                    }]
                },
                bone4: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: -1.58,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: -1.58,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }],
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: -2.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: -2.46,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone23: {
                    rotate: [{}, {
                        time: 2,
                        angle: 180
                    }, {
                        time: 4
                    }]
                },
                bone28: {
                    rotate: [{
                        angle: -112.28,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: .2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .3,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.3,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 2,
                        angle: -112.28,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: 2.2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.3,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.2667,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.3,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 4,
                        angle: -112.28
                    }],
                    translate: [{
                        y: -34.57,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: .2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: .3,
                        y: 139.64,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: 1.3,
                        y: 139.64,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 2,
                        y: -34.57,
                        curve: .533,
                        c2: .47,
                        c3: .912,
                        c4: .85
                    }, {
                        time: 2.2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: 2.3,
                        y: 139.64,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.2667,
                        y: -139.64,
                        curve: "stepped"
                    }, {
                        time: 3.3,
                        y: 139.64,
                        curve: .218,
                        c3: .717,
                        c4: .6
                    }, {
                        time: 4,
                        y: -34.57
                    }]
                },
                bone27: {
                    rotate: [{
                        angle: -39.3,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: .6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .6667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.6667,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 2,
                        angle: -39.3,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: 2.6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.6333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.6667,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 4,
                        angle: -39.3
                    }],
                    translate: [{
                        y: 30.83,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: .6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: .6667,
                        y: 91.8,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: 1.6667,
                        y: 91.8,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 2,
                        y: 30.83,
                        curve: .448,
                        c2: .35,
                        c3: .944,
                        c4: .88
                    }, {
                        time: 2.6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        y: 91.8,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.6333,
                        y: -187.48,
                        curve: "stepped"
                    }, {
                        time: 3.6667,
                        y: 91.8,
                        curve: .231,
                        c3: .604,
                        c4: .42
                    }, {
                        time: 4,
                        y: 30.83
                    }]
                },
                bone26: {
                    rotate: [{
                        angle: -97.75,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: .3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .3667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.3667,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 2,
                        angle: -97.75,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: 2.3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.3667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.3667,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 4,
                        angle: -97.75
                    }],
                    translate: [{
                        y: -58.58,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: .3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: .3667,
                        y: 93.1,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: 1.3667,
                        y: 93.1,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 2,
                        y: -58.58,
                        curve: .528,
                        c2: .46,
                        c3: .923,
                        c4: .86
                    }, {
                        time: 2.3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: 2.3667,
                        y: 93.1,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3333,
                        y: -186.19,
                        curve: "stepped"
                    }, {
                        time: 3.3667,
                        y: 93.1,
                        curve: .216,
                        c3: .683,
                        c4: .56
                    }, {
                        time: 4,
                        y: -58.58
                    }]
                },
                bone24: {
                    rotate: [{
                        angle: -143.34,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: .1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .1667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 2,
                        angle: -143.34,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: 2.1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.1667,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.1333,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.1667,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 4,
                        angle: -143.34
                    }],
                    translate: [{
                        y: -87.5,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: .1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: .1667,
                        y: 134.9,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: 1.1667,
                        y: 134.9,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 2,
                        y: -87.5,
                        curve: .517,
                        c2: .45,
                        c3: .868,
                        c4: .8
                    }, {
                        time: 2.1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: 2.1667,
                        y: 134.9,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.1333,
                        y: -144.38,
                        curve: "stepped"
                    }, {
                        time: 3.1667,
                        y: 134.9,
                        curve: .228,
                        c3: .808,
                        c4: .71
                    }, {
                        time: 4,
                        y: -87.5
                    }]
                },
                bone25: {
                    rotate: [{
                        angle: -104.83,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: .3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .3333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 2,
                        angle: -104.83,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: 2.3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 4,
                        angle: -104.83
                    }],
                    translate: [{
                        y: 20.52,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: .3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: .3333,
                        y: 183.17,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        y: 183.17,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 2,
                        y: 20.52,
                        curve: .531,
                        c2: .47,
                        c3: .918,
                        c4: .86
                    }, {
                        time: 2.3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: 2.3333,
                        y: 183.17,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.3,
                        y: -96.11,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        y: 183.17,
                        curve: .216,
                        c3: .699,
                        c4: .58
                    }, {
                        time: 4,
                        y: 20.52
                    }]
                },
                bone29: {
                    rotate: [{
                        angle: -63.73,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: .5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: .5333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 1.5333,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 2,
                        angle: -63.73,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: 2.5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 2.5333,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.5,
                        angle: 180,
                        curve: "stepped"
                    }, {
                        time: 3.5333,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 4,
                        angle: -63.73
                    }],
                    translate: [{
                        y: 88.16,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: .5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: .5333,
                        y: 187.05,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 1.5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: 1.5333,
                        y: 187.05,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 2,
                        y: 88.16,
                        curve: .493,
                        c2: .42,
                        c3: .938,
                        c4: .88
                    }, {
                        time: 2.5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: 2.5333,
                        y: 187.05,
                        curve: .25,
                        c3: .946,
                        c4: .87
                    }, {
                        time: 3.5,
                        y: -92.23,
                        curve: "stepped"
                    }, {
                        time: 3.5333,
                        y: 187.05,
                        curve: .219,
                        c3: .626,
                        c4: .47
                    }, {
                        time: 4,
                        y: 88.16
                    }]
                },
                bone30: {
                    rotate: [{}, {
                        time: 1.9667,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: 2
                    }, {
                        time: 3.9667,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: 4
                    }],
                    translate: [{
                        y: 152.3
                    }, {
                        time: 1.9667,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: 2,
                        y: 152.3
                    }, {
                        time: 3.9667,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: 4,
                        y: 152.3
                    }]
                },
                bone40: {
                    translate: [{
                        x: -4.09,
                        y: -5.32
                    }]
                },
                bone46: {
                    rotate: [{
                        angle: 6.59,
                        curve: .382,
                        c2: .57,
                        c3: .735
                    }, {
                        time: .3333
                    }, {
                        time: 1.3333,
                        angle: 23.22,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        angle: 23.22,
                        curve: .243,
                        c3: .649,
                        c4: .6
                    }, {
                        time: 4,
                        angle: 6.59
                    }],
                    translate: [{
                        x: -3.5,
                        y: 3.22,
                        curve: .382,
                        c2: .57,
                        c3: .735
                    }, {
                        time: .3333
                    }, {
                        time: 1.3333,
                        x: -12.35,
                        y: 11.36,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        x: -12.35,
                        y: 11.36,
                        curve: .243,
                        c3: .649,
                        c4: .6
                    }, {
                        time: 4,
                        x: -3.5,
                        y: 3.22
                    }]
                },
                bone47: {
                    rotate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        angle: -22.28,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        angle: -22.28,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }],
                    translate: [{
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: 19.07,
                        y: 8.94,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: 19.07,
                        y: 8.94,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4
                    }]
                },
                bone31: {
                    rotate: [{
                        angle: -11.02,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5
                    }, {
                        time: 1.5,
                        angle: -22.03,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        angle: -22.03,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        angle: -11.02
                    }],
                    translate: [{
                        x: 8.05,
                        y: -6.26,
                        curve: .375,
                        c2: .5,
                        c3: .75
                    }, {
                        time: .5
                    }, {
                        time: 1.5,
                        x: 16.09,
                        y: -12.52,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.5,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.5,
                        x: 16.09,
                        y: -12.52,
                        curve: .25,
                        c3: .625,
                        c4: .5
                    }, {
                        time: 4,
                        x: 8.05,
                        y: -6.26
                    }]
                },
                xingxing1: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .6667,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing2: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: .3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 2.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing3: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: .6667,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.3333,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 2.6667,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing4: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: .4333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .7667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.1,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 2.4333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.7667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.1,
                        x: .522,
                        y: .522
                    }]
                },
                xingxing5: {
                    scale: [{
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: .6667,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 1.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 1.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.3333,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 2.6667,
                        x: .522,
                        y: .522,
                        curve: "stepped"
                    }, {
                        time: 3.3333,
                        x: .522,
                        y: .522,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 3.6667,
                        curve: .25,
                        c3: .75
                    }, {
                        time: 4,
                        x: .522,
                        y: .522
                    }]
                },
                bone49: {
                    rotate: [{
                        angle: -86.3
                    }, {
                        time: .8,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: .8333
                    }, {
                        time: 2,
                        angle: -86.3
                    }, {
                        time: 2.8,
                        angle: -145.47,
                        curve: "stepped"
                    }, {
                        time: 2.8333
                    }, {
                        time: 4,
                        angle: -86.3
                    }],
                    translate: [{
                        y: -20.39
                    }, {
                        time: .8,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: .8333,
                        y: 152.3
                    }, {
                        time: 2,
                        y: -20.39
                    }, {
                        time: 2.8,
                        y: -138.81,
                        curve: "stepped"
                    }, {
                        time: 2.8333,
                        y: 152.3
                    }, {
                        time: 4,
                        y: -20.39
                    }]
                }
            }
        }
    };
var ec = {
        skeleton: Kt,
        bones: Xt,
        slots: Yt,
        skins: Qt,
        animations: Zt
    },
    tc = `
zhongjiangdonghua.png
size: 512,256
format: RGBA8888
filter: Linear,Linear
repeat: none
Group-1
  rotate: false
  xy: 2, 45
  size: 61, 209
  orig: 62, 213
  offset: 0, 0
  index: -1
caidai1
  rotate: false
  xy: 70, 2
  size: 8, 8
  orig: 8, 8
  offset: 0, 0
  index: -1
caidai2
  rotate: true
  xy: 92, 82
  size: 10, 11
  orig: 10, 11
  offset: 0, 0
  index: -1
caidai3
  rotate: true
  xy: 93, 94
  size: 12, 10
  orig: 12, 10
  offset: 0, 0
  index: -1
caidai4
  rotate: false
  xy: 274, 241
  size: 13, 13
  orig: 13, 13
  offset: 0, 0
  index: -1
caidai5
  rotate: false
  xy: 93, 108
  size: 10, 13
  orig: 10, 13
  offset: 0, 0
  index: -1
caidai6
  rotate: false
  xy: 90, 46
  size: 9, 9
  orig: 10, 10
  offset: 1, 1
  index: -1
gaoguang1
  rotate: false
  xy: 2, 2
  size: 5, 5
  orig: 5, 5
  offset: 0, 0
  index: -1
gaoguang2
  rotate: false
  xy: 9, 3
  size: 4, 4
  orig: 4, 4
  offset: 0, 0
  index: -1
guaizhang
  rotate: true
  xy: 234, 158
  size: 21, 63
  orig: 21, 63
  offset: 0, 0
  index: -1
hudiejie
  rotate: false
  xy: 65, 102
  size: 26, 19
  orig: 26, 19
  offset: 0, 0
  index: -1
jinbi1
  rotate: false
  xy: 268, 193
  size: 13, 15
  orig: 13, 15
  offset: 0, 0
  index: -1
jinbi10
  rotate: false
  xy: 65, 88
  size: 25, 12
  orig: 25, 12
  offset: 0, 0
  index: -1
jinbi13
  rotate: false
  xy: 65, 88
  size: 25, 12
  orig: 25, 12
  offset: 0, 0
  index: -1
jinbi11
  rotate: false
  xy: 79, 57
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi14
  rotate: false
  xy: 79, 57
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi15
  rotate: true
  xy: 198, 155
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi16
  rotate: false
  xy: 65, 74
  size: 25, 12
  orig: 25, 12
  offset: 0, 0
  index: -1
jinbi17
  rotate: false
  xy: 252, 233
  size: 20, 21
  orig: 20, 21
  offset: 0, 0
  index: -1
jinbi18
  rotate: true
  xy: 223, 131
  size: 23, 16
  orig: 23, 16
  offset: 0, 0
  index: -1
jinbi2
  rotate: true
  xy: 252, 189
  size: 19, 14
  orig: 19, 14
  offset: 0, 0
  index: -1
jinbi3
  rotate: false
  xy: 212, 156
  size: 20, 23
  orig: 20, 23
  offset: 0, 0
  index: -1
jinbi4
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi12
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi5
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi6
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi7
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi8
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
jinbi9
  rotate: true
  xy: 65, 45
  size: 24, 12
  orig: 24, 12
  offset: 0, 0
  index: -1
maozi
  rotate: true
  xy: 198, 181
  size: 73, 52
  orig: 73, 52
  offset: 0, 0
  index: -1
mei1
  rotate: false
  xy: 92, 71
  size: 11, 9
  orig: 11, 9
  offset: 0, 0
  index: -1
mei2
  rotate: true
  xy: 79, 45
  size: 10, 9
  orig: 10, 9
  offset: 0, 0
  index: -1
shanguang
  rotate: false
  xy: 65, 123
  size: 131, 131
  orig: 131, 131
  offset: 0, 0
  index: -1
shenti
  rotate: true
  xy: 105, 3
  size: 118, 124
  orig: 118, 124
  offset: 0, 0
  index: -1
shou1
  rotate: true
  xy: 59, 12
  size: 31, 44
  orig: 31, 44
  offset: 0, 0
  index: -1
shou2
  rotate: true
  xy: 32, 9
  size: 34, 25
  orig: 34, 25
  offset: 0, 0
  index: -1
yangkang1
  rotate: false
  xy: 198, 130
  size: 23, 23
  orig: 23, 23
  offset: 0, 0
  index: -1
yankuang2
  rotate: false
  xy: 252, 210
  size: 20, 21
  orig: 20, 21
  offset: 0, 0
  index: -1
yanzhu1
  rotate: false
  xy: 59, 2
  size: 9, 8
  orig: 9, 8
  offset: 0, 0
  index: -1
yanzhu2
  rotate: false
  xy: 80, 2
  size: 8, 8
  orig: 8, 8
  offset: 0, 0
  index: -1
zhibi1
  rotate: true
  xy: 2, 9
  size: 34, 28
  orig: 34, 28
  offset: 0, 0
  index: -1
`;
const ne = {
        banner: Wt,
        banner_mobile: Ot,
        drawcoco: Ft,
        whatisbcl: Ut,
        drawn: Jt,
        drawnjson: ec,
        drawnatlas: tc
    },
    _e = ["animation1_1", "animation2_1"];

function cc() {
    const [c, t] = v.exports.useState(_e[0]);
    v.exports.useEffect(() => {
        const n = setTimeout(() => {
            t(_e[1])
        }, 4e3);
        return () => clearTimeout(n)
    }, []);
    const i = C.isMobile ? 340 : 500;
    return e(Bt, {
        width: i,
        height: 270,
        fps: 60,
        children: e(Gt, {
            x: i / 2,
            y: 310,
            skel: ne.drawnjson,
            atlas: ne.drawnatlas,
            img: ne.drawn,
            animate: c,
            scale: 1
        })
    })
}

function nc({
    periodId: c,
    jackpotBallNumber: t,
    boughtTickets: i,
    bonusTickets: n,
    numbers: a,
    winTickets: s
}) {
    const o = g();
    return r("div", {
        className: ic,
        children: [e(cc, {}), r("div", {
            className: "cont",
            children: [e(ft, {
                onClick: ie.close
            }), r("div", {
                className: "sub-tit",
                children: [o("page.lottery.gameid"), " ", e("span", {
                    children: c
                })]
            }), r("div", {
                className: "tit",
                children: ["THE ", e("span", {
                    children: "LUCKY NUMBERS"
                }), " ARE.."]
            }), e(Ve, {
                className: "ball-list",
                nums: a,
                jackpotNum: t
            }), r("div", {
                className: "tickets-num",
                children: ["You have ", e("span", {
                    className: "cl-primary",
                    children: i
                }), " tickets in this round"]
            }), r("div", {
                className: "draw",
                children: [e("img", {
                    src: $e,
                    className: "bonus"
                }), " +", e("span", {
                    children: n
                }), " Bonus Tickets"]
            }), s > 0 && r(N, {
                className: "cl-primary get-btn",
                onClick: () => {
                    C.chatOrNtice = "notice", st.openNotice(!1), ie.close()
                },
                children: ["Get your prize", ">>"]
            })]
        })]
    })
}
const ic = "v4c0im7",
    rc = B.memo(({
        children: c
    }) => {
        const [t] = v.exports.useState(() => new ac);
        return v.exports.useEffect(() => t.destory, [t]), e(Oe.Provider, {
            value: t,
            children: c
        })
    }),
    Oe = B.createContext(null);
class ac extends lt.exports.EventEmitter {
    constructor() {
        super(), this.periodId = 0, this.status = 0, this.userId = 0, this.numbers = null, this.jackpotBallNumber = null, this.boughtTickets = 0, this.bonusTickets = 0, this.winTickets = 0, this.isDestory = !1, this.myTicketsLenth = 0, this.block = {
            periodId: 0,
            blockNum: 0,
            distBlockNum: 0,
            blockHash: ""
        }, this.header = {
            currentJackpot: 0,
            currentSoldTickets: 0,
            drawnTime: 0,
            expireTimeInMs: 0,
            giftLinkCurrency: "",
            giftLinkMinAmount: "0",
            giftLinkMaxAmount: "0",
            buyerInfo: []
        }, mt(this, {
            userId: $,
            periodId: $,
            status: $,
            numbers: $,
            jackpotBallNumber: $,
            header: $,
            block: $,
            myTicketsLenth: $,
            drawAwrad: ce,
            canBuyTicket: ce,
            drawEnd: ce,
            buyDrawEnd: ce
        }), this.destory = this.destory.bind(this), this.init = this.init.bind(this), this.syncData = this.syncData.bind(this), this.syncBlock = this.syncBlock.bind(this), this.init(), h.on("lottery-ticket", this.init), h.socket.on("lottery-begin", this.init), h.socket.on("lottery-end-buy", this.syncData), h.socket.on("lottery-reward-sending", this.syncData), h.socket.on("lottery-rewarded", this.syncData), h.socket.on("lottery-block-num", ke.decodeBind(this.syncBlock))
    }
    get canBuyTicket() {
        return this.status === 0
    }
    get drawAwrad() {
        return this.status >= 32
    }
    get drawEnd() {
        return this.status === 40
    }
    get buyDrawEnd() {
        return this.userId ? this.drawEnd : !1
    }
    syncBlock(t) {
        this.block = JSON.parse(t)
    }
    async init() {
        await h.inited;
        const l = await k.get("/lottery/five-plus-one/current-info/"),
            {
                periodId: t,
                status: i,
                myTickets: n,
                currentBlockHash: a,
                distBlockNum: s,
                currentBlockNum: o
            } = l,
            m = Z(l, ["periodId", "status", "myTickets", "currentBlockHash", "distBlockNum", "currentBlockNum"]);
        this.periodId = t, this.header = Object.assign({}, this.header, m), this.myTicketsLenth = n.total, this.block = {
            periodId: t,
            blockHash: a,
            blockNum: o,
            distBlockNum: s
        }, this.status = i, this.status >= 30 && this.syncData()
    }
    async syncData() {
        const t = await k.get(`/lottery/five-plus-one/period-info/?periodId=${this.periodId}`);
        this.userId = t.userId, this.status = t.status, this.jackpotBallNumber = t.jackpotBallNumber ? t.jackpotBallNumber : 0, this.boughtTickets = t.boughtTickets, this.bonusTickets = t.bonusTickets, this.winTickets = t.winTickets, this.numbers = t.numbers ? t.numbers : null
    }
    getLocalPeriodId() {
        return localStorage.getItem("lottery")
    }
    setLocalPeriodId(t) {
        localStorage.setItem("lottery", t)
    }
    destory() {
        h.off("lottery-ticket", this.init), h.socket.off("lottery-begin", this.syncData), h.socket.off("lottery-end-buy", this.syncData), h.socket.off("lottery-reward-sending", this.syncData), h.socket.off("lottery-rewarded", this.syncData), h.socket.off("lottery-block-num", ke.decodeBind(this.syncBlock))
    }
}

function D() {
    return B.useContext(Oe)
}

function oc(c) {
    return k.get(`/lottery/five-plus-one/fairness/${c?"?periodId="+c:""}`)
}
const Fe = function({
        pid: t
    }) {
        const i = P(() => oc(t)),
            n = g();
        if (!i.data) return e(L, {});
        const {
            periodId: a,
            serverSeedHashed: s,
            serverSeed: o,
            stopBlock: m,
            clientSeedBlock: l,
            clientSeed: f,
            ticketsFile: u
        } = i.data;

        function d() {
            if (m) window.open(`https://bcgame-project.github.io/verify/lottery.html?s=${o}&c=${f}`);
            else return G("Verify will be available after the draw.")
        }
        const p = C.createPath(u, "img2");
        return e(R, {
            title: n("page.lottery.fariness"),
            children: r(U, {
                className: y(fc, "dialog-box"),
                children: [e("div", {
                    className: "tips",
                    children: e(X, {
                        k: "page.lottery.fariness.tit",
                        children: e("button", {
                            onClick: d,
                            children: n("common.online_verifier")
                        })
                    })
                }), e(Te, {
                    value: s,
                    readOnly: !0,
                    label: r("div", {
                        className: "tooltip-label",
                        children: [e("span", {
                            children: n("common.server_seed_hash")
                        }), e(F, {
                            delay: 200,
                            forceWrap: !0,
                            title: n("common.verify.server_seed.desc"),
                            children: e(j, {
                                name: "Help"
                            })
                        })]
                    })
                }), e(le, {
                    label: n("common.server_seed"),
                    value: o || n("common.verify.server_seed.holder"),
                    readOnly: !0,
                    titleWord: n("common.verify.server_seed.tit")
                }), e(le, {
                    label: n("common.verify.stop_block"),
                    value: m || "",
                    placeholder: n("common.verify.stop_block.holder"),
                    readOnly: !0,
                    titleWord: n("common.verify.stop_block.tit")
                }), e(le, {
                    label: n("common.verify.client_seed"),
                    value: l,
                    placeholder: n("common.verify.client_seed.holder"),
                    readOnly: !0,
                    titleWord: n("common.verify.client_seed.tit")
                }), e(de, {
                    label: r("div", {
                        className: "download-label",
                        children: [r("span", {
                            children: [n("common.verify.client_hash"), " ", e(F, {
                                delay: 200,
                                title: n("common.verify.client_hash.tit"),
                                children: e(j, {
                                    name: "Help"
                                })
                            })]
                        }), p && r("a", {
                            download: "download.csv",
                            href: p,
                            children: [e(j, {
                                name: "Download"
                            }), n("common.verify.client_filelist")]
                        })]
                    }),
                    value: f || "",
                    placeholder: n("common.verify.client_hash.holder"),
                    readOnly: !0
                }), e(N, {
                    className: "sub-btn",
                    type: "conic",
                    onClick: d,
                    children: n("common.verify")
                })]
            })
        })
    },
    le = B.memo(function(n) {
        var a = n,
            {
                titleWord: c,
                label: t
            } = a,
            i = Z(a, ["titleWord", "label"]);
        return e(de, I({
            label: r("div", {
                className: "tooltip-label",
                children: [e("span", {
                    children: t
                }), e(F, {
                    delay: 200,
                    forceWrap: !0,
                    title: c,
                    children: e(j, {
                        name: "Help"
                    })
                })]
            })
        }, i))
    });
M({
    cl1: ["#43b309", "#5ddb1c"],
    cl2: ["rgba(93, 160, 0, 0.07)", "rgba(93, 219, 28, 0.1)"],
    cl3: [x("#99a4b0", .6), x("#5f6975", .6)],
    cl4: ["#f5f6f7", "#31373d"]
});
const fc = "v1hvfvi2";

function Ue({
    pid: c
}) {
    const t = g();
    return e(R, {
        title: t("common.faq_fairness"),
        children: r(U, {
            className: sc,
            children: [e(ut, {
                children: e(j, {
                    style: {
                        cursor: "pointer"
                    },
                    name: "Fairness",
                    onClick: () => T.push(e(Fe, {
                        pid: c
                    }))
                })
            }), e("div", {
                className: "item",
                children: t("page.lottery.fariness_1")
            }), e("div", {
                className: "item",
                children: t("page.lottery.fariness_2")
            }), r("div", {
                className: "item",
                children: [e("div", {
                    children: t("page.lottery.fariness_3")
                }), e("div", {
                    className: "pri-tips",
                    children: "hash = HMAC_SHA256 (clientSeed, serverSeed)"
                }), e("div", {
                    dangerouslySetInnerHTML: {
                        __html: t("page.lottery.fariness_4")
                    }
                })]
            })]
        })
    })
}
const sc = "vz39rro";

function me(c) {
    return c > 9 ? c : "0" + c
}
const lc = B.memo(function({
        draw: t
    }) {
        const [i, n] = v.exports.useState(0), a = g();
        v.exports.useEffect(() => {
            const o = setInterval(() => {
                n(m => m + 1)
            }, 1e3);
            return () => clearInterval(o)
        }, []);
        const s = new Array(i % 3).fill(null).map((o, m) => e(B.Fragment, {
            children: "."
        }, m));
        return r("div", {
            className: "res-txt",
            children: [t ? "Next round will begin in minutes" : a("common.coming"), " ", r("span", {
                style: {
                    width: "20px",
                    textAlign: "left",
                    display: "inline-block"
                },
                children: [".", s]
            })]
        })
    }),
    mc = _(function() {
        const t = g(),
            i = D(),
            n = i.header,
            a = i.block,
            s = i.periodId === a.periodId && a.blockNum > 0 && !i.drawAwrad;
        if (!i.canBuyTicket) {
            if (s) {
                const o = a.distBlockNum - a.blockNum;
                return r("div", {
                    className: "next-time",
                    children: [e("div", {
                        className: "txt",
                        children: t("common.coming")
                    }), e("div", {
                        className: "time letter-spacing",
                        dangerouslySetInnerHTML: {
                            __html: t("page.lottery.draw", String(o > 0 ? o : 0))
                        }
                    })]
                })
            }
            return r("div", {
                className: "next-time",
                children: [e("div", {
                    className: "txt"
                }), e("div", {
                    className: "time",
                    children: e(lc, {
                        draw: i.drawAwrad
                    })
                })]
            })
        }
        return r("div", {
            className: "next-time",
            children: [e("div", {
                className: "txt",
                children: t("common.nextdraw")
            }), e("div", {
                className: "time",
                children: e(dt, {
                    endTime: n.drawnTime,
                    onEnd: () => {},
                    children: ({
                        hours: o,
                        minutes: m,
                        seconds: l
                    }) => r(ee, {
                        children: [r("span", {
                            children: [me(o), "h"]
                        }), ":", r("span", {
                            children: [me(m), "m"]
                        }), ":", r("span", {
                            children: [me(l), "s"]
                        })]
                    })
                })
            })]
        })
    });

function uc({
    hash: c
}) {
    if (c.length < 10) return e("span", {
        children: c
    }); {
        const t = c.substring(0, 4),
            i = c.substring(c.length - 7, c.length - 1);
        return r("span", {
            title: c,
            children: [t, "...", i]
        })
    }
}
const dc = _(function() {
    const t = D(),
        i = Y(),
        n = g(),
        a = t.block,
        s = t.periodId === a.periodId && a.blockHash && !t.canBuyTicket,
        o = t.header;
    return v.exports.useEffect(() => {
        t.drawAwrad && t.numbers && (console.log(t, t.getLocalPeriodId()), Number(t.getLocalPeriodId()) !== Number(t.periodId) && (t.setLocalPeriodId(String(t.periodId)), ie.push(e(nc, I({}, t)))))
    }, [t.drawAwrad, t.numbers]), r("div", {
        className: y(vc, "lottery-header"),
        children: [r("div", {
            className: "wrap",
            children: [r("div", {
                className: "period",
                children: [n("page.lottery.gameid"), " ", e("span", {
                    children: t.periodId
                })]
            }), r("div", {
                className: "right-top",
                children: [e("a", {
                    href: "#lottery_rule",
                    className: "rule",
                    onClick: () => {},
                    children: n("page.casino.rules")
                }), e("button", {
                    onClick: () => T.push(e(Ue, {
                        pid: t.periodId
                    })),
                    className: "fairness",
                    children: n("common.faq_fairness")
                })]
            }), r("div", {
                className: "cont",
                children: [e(mc, {}), e(N, {
                    type: "conic4",
                    disabled: t.status != 0,
                    onClick: () => i("/buyticket"),
                    children: e(F, {
                        delay: 100,
                        title: t.status != 0 ? e("div", {
                            dangerouslySetInnerHTML: {
                                __html: n("page.lottery.drawtip", "5")
                            }
                        }) : null,
                        children: r("div", {
                            className: "btn-ticket",
                            children: [e("div", {
                                className: "tit",
                                children: n("page.lottery.buyticket")
                            }), e("div", {
                                className: "sub-tit",
                                children: n("page.lottery.ticketprice")
                            })]
                        })
                    })
                })]
            })]
        }), r("div", {
            className: "desc",
            children: [s ? r("div", {
                className: "block",
                children: [r("div", {
                    className: "block-num",
                    children: [e("span", {
                        children: n("page.lottery.currentblock")
                    }), " ", a.blockNum]
                }), r("div", {
                    className: "block-hash",
                    children: [n("common.hash"), ": ", e(uc, {
                        hash: a.blockHash
                    })]
                })]
            }) : e(Mt, {
                list: o.buyerInfo
            }), e("div", {
                className: "sp",
                children: e(X, {
                    k: "page.lottery.desc",
                    children: e("span", {
                        className: "lottery-green",
                        children: o.currentSoldTickets
                    })
                })
            })]
        })]
    })
});
M({
    cl1: [x("#000000", .3), "#17171b"],
    cl2: ["#43b309", "#6ace24"],
    cl3: ["rgba(152, 167, 181, 0.7)", "#98a7b5"]
});
const vc = "h15phseo";

function pc() {
    const c = D(),
        t = g();
    return r("div", {
        className: gc,
        children: [e("div", {
            id: "lottery_rule"
        }), r("div", {
            className: "tit",
            children: [t("page.lottery.instrustions"), ":"]
        }), r("div", {
            className: "cont",
            children: [e("div", {
                className: "li",
                children: t("page.lottery.instrustions_1")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_2")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_3")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_4")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_5")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_6")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_7")
            }), e("div", {
                className: "li",
                children: t("page.lottery.instrustions_8")
            })]
        }), r("div", {
            className: "tit",
            children: [t("page.lottery.winning"), ":"]
        }), r("div", {
            className: "cont",
            children: [e("div", {
                className: "li",
                children: t("page.lottery.winning_1")
            }), e("div", {
                className: "li",
                children: t("page.lottery.winning_2")
            }), e("div", {
                className: "li",
                children: t("page.lottery.winning_3")
            }), e("div", {
                className: "li",
                children: t("page.lottery.winning_4")
            }), e("div", {
                className: "li",
                children: t("page.lottery.winning_5")
            })]
        }), r(N, {
            className: "btn",
            onClick: () => T.push(e(Ue, {
                pid: c.periodId
            })),
            children: [t("common.faq_fairness"), e(j, {
                name: "Arrow"
            })]
        })]
    })
}
const gc = "v9tgbn4";
var hc = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAAAaVBMVEUAAABqziJ61TNqziS777trzyVu0CxrziZrziRqziNrzyRqziRs0SZqziRqziVqzyRszyZqzyRrzyRqziRszyVozCJszyZrzCZrzyRqzyRt0CZs0S5qziRqziRqzyZrziVqzSRqzyNs0Cb5WvHbAAAAI3RSTlMADAQuATYRFkFzY0kdhFGUMntqWigePTufgCMIwpCOTq+uV6yoZAMAAAGJSURBVEjH7VTXbsMwDNTesiVb8sz+/4+sFCdtCjgeb0WRezAMkieRFI/gg/8EBBPQHoKJ0YybQsn0xQnoYVgEZFMAFaJ9WOBiPI9sIhRFAzKY4XAp3mB69zul7jeMFIf3DMIiTrnk3IOULluEptgw8p5BRVHnXIy1Q86sLjTlZKkIXVcyAIDKMhUzyKrWbOUFGultijl2id17qddfI9jSE9AfAahK68AGMH+tQeXB+dLzxWQQedZeH9xZDQeFngaE5uo1mFIXTPa5rtVdm0/hwVGKI5wjRCwKJW157KtzW6vmXPWn0kpVCBw5mr1hInRHr7SqtPKnboXQNI0bct+HrtEdzg0YXNu08ymh8fsUfWgLhQ838uJaAKwuKrf1dvUMbMDQlz0C/QkQX9qwrjgqveUAnLpUgLVSrCh7FGn43HP4Qho+ARenguqi1umHT+MtlsebMIOp1uOPgNCKgCAPmLJXiUKKw4qo+e8lwCOHu9YMYXD3ItsCFI0x465lzDlE+/Y3Ah/8ZXwB1qcUPHJAtGAAAAAASUVORK5CYII=",
    yc = "/assets/base_ball.225c2bf6.png",
    bc = "/assets/base_jackpot_ball.a3f4613c.png";
const xc = _(function({
        nums: t
    }) {
        const i = [1, 2, 3, 4, 5];
        return r("div", {
            className: y(Nc, t === 6 && "jackpot"),
            children: [i.map(n => e("img", {
                className: y("ball", t >= n && "active"),
                src: C.isDarken ? yc : pe,
                alt: ""
            }, n)), e("img", {
                className: y("ball jackpot-ball", t === 6 && "active"),
                src: bc
            })]
        })
    }),
    Nc = "v1fximrd";
const wc = [{
    matches: "5 NUMBERS",
    submatches: "JACKPOT BALL",
    number: 6,
    prize: S.toLocaleCurrency(1e5, "USD"),
    status: 2
}, {
    matches: "5 numbers",
    number: 5,
    prize: S.toLocaleCurrency(3e3, "USD"),
    status: 1
}, {
    matches: "4 numbers",
    number: 4,
    prize: S.toLocaleCurrency(20, "USD"),
    status: 1
}, {
    matches: "3 numbers",
    number: 3,
    prize: S.toLocaleCurrency(1, "USD"),
    status: 1
}, {
    matches: "2 numbers",
    number: 2,
    prize: "+1 ticket",
    status: 0
}, {
    matches: "No numbers",
    number: 0,
    prize: "+1 ticket",
    status: 0
}];

function kc() {
    const c = g();
    return r("div", {
        className: jc,
        children: [e("div", {
            className: "title",
            children: c("page.lottery.rule")
        }), e("div", {
            className: "cont",
            children: r(oe, {
                hover: !1,
                children: [e("thead", {
                    children: r("tr", {
                        children: [e("th", {
                            children: c("common.matches")
                        }), e("th", {
                            children: c("common.numbers")
                        }), e("th", {
                            children: c("common.prize")
                        })]
                    })
                }), e("tbody", {
                    children: wc.map(t => r("tr", {
                        className: re(t.status === 2 && "big-prize", t.status === 1 && "normal-prize"),
                        children: [r("td", {
                            className: "matches",
                            children: [t.status === 2 && e("img", {
                                src: hc
                            }), t.matches, t.submatches && e("div", {
                                children: t.submatches
                            })]
                        }), e("td", {
                            children: e(xc, {
                                nums: t.number
                            })
                        }), r("td", {
                            className: "prize",
                            children: [t.status === 0 && e("img", {
                                src: $e
                            }), t.prize, t.status === 2 && e("div", {
                                className: "star-img"
                            })]
                        })]
                    }, t.number))
                })]
            })
        })]
    })
}
const jc = "vyfz1sz";
var Cc = "/assets/buyticket.95472b7d.png",
    _c = "/assets/checkprizes.4d0b07fb.png",
    zc = "/assets/draw.e92398c8.png";
const O = [{
    label: K.t("page.lottery.htp1_label"),
    img: Cc,
    cont: K.t("page.lottery.htp1_cont")
}, {
    label: K.t("page.lottery.htp2_label"),
    img: zc,
    cont: K.t("page.lottery.htp2_cont")
}, {
    label: K.t("page.lottery.htp3_label"),
    img: _c,
    cont: K.t("page.lottery.htp3_cont")
}];

function Je({
    item: c,
    index: t
}) {
    return r("div", {
        className: y(Sc, "item", `col-${t+1}`),
        children: [e("img", {
            src: c.img,
            alt: ""
        }), e("div", {
            className: "tit",
            children: c.label
        }), e("div", {
            className: "cont",
            children: c.cont
        })]
    })
}

function Ic() {
    return e(ee, {
        children: O.map((c, t) => e(Je, {
            item: c,
            index: t
        }, c.label))
    })
}

function Lc({
    isMobile: c
}) {
    const t = c ? [
        [O[0]],
        [O[1]],
        [O[2]]
    ] : [
        [O[0], O[1]],
        [O[2]]
    ];
    return r(ee, {
        children: [e(vt, {
            slidesPerView: "auto",
            threshold: 6,
            navigation: {
                prevEl: ".navigation-prev-lottery",
                nextEl: ".navigation-next-lottery"
            },
            children: t.map((i, n) => e(pt, {
                children: i.map(a => e(Je, {
                    item: a,
                    index: n
                }, a.label))
            }, n))
        }), e(gt, {
            name: "lottery"
        })]
    })
}

function Ac() {
    const [c, t] = v.exports.useState(C.isMobile ? 0 : 2), i = Me(n => {
        C.isMobile ? t(0) : n.width <= 880 ? t(1) : t(2)
    }, 300);
    return e("div", {
        ref: i,
        className: y(Bc, c < 2 && "mb"),
        children: c != 2 ? e(Lc, {
            isMobile: c === 0
        }) : e(Ic, {})
    })
}
const Sc = "iop9si5",
    Bc = "v8i6f0k";

function Gc() {
    const c = g();
    return e(R, {
        title: "What is BCL?",
        children: r(U, {
            className: Tc,
            children: [e("h2", {
                children: c("page.bcl.whatis")
            }), e("div", {
                className: "help-content",
                children: e("p", {
                    children: e(X, {
                        k: "page.bcl.whatis_desc",
                        children: e(ae, {
                            to: "/lottery",
                            onClick: () => T.close(),
                            className: "btn",
                            children: c("common.lottery")
                        })
                    })
                })
            }), e("h2", {
                children: c("page.bcl.howto")
            }), e("div", {
                className: "help-content",
                children: e(X, {
                    k: "page.bcl.howto_desc",
                    children: e(ae, {
                        to: "/wallet/swap",
                        className: "btn",
                        children: c("wallet.swap.title")
                    })
                })
            }), e("h2", {
                children: c("page.bcl.gift")
            }), e("div", {
                className: "help-content",
                children: e("p", {
                    children: e(X, {
                        k: "page.bcl.gift_desc",
                        children: e("span", {
                            className: "lottery-green",
                            children: c("title.user_sendtip")
                        })
                    })
                })
            })]
        })
    })
}
const Tc = "vst4usa";
var ge = "/assets/award.47749612.png";

function Mc({
    balance: c
}) {
    const t = Y(),
        i = g();
    return r("div", {
        className: qc,
        children: [r("div", {
            className: "bcl-balance",
            children: [e("div", {
                className: "label",
                children: i("common.you_balance", "BCL")
            }), e("div", {
                className: "balance",
                children: c
            })]
        }), e("div", {
            className: "btn swap",
            onClick: () => t("/wallet/swap?to=BCL"),
            children: i("page.lottery.getmore")
        }), r("div", {
            className: "btn",
            onClick: () => t("/send_ticket"),
            children: [e("img", {
                src: ge
            }), i("common.sendgift")]
        })]
    })
}
const Pc = _(function() {
    const c = h.login,
        t = S.dict.BCL.amount;
    return c ? e("div", {
        className: "right-wrap",
        children: e(Mc, {
            balance: t
        })
    }) : e("div", {
        className: "empty",
        children: e("img", {
            src: ne.whatisbcl
        })
    })
});

function Dc() {
    const c = g();
    return r("div", {
        className: y(Ec, "lottery-subheader"),
        children: [r("div", {
            className: "cont sh",
            children: [e("div", {
                className: "title",
                dangerouslySetInnerHTML: {
                    __html: c("page.lottery.whatbcl")
                }
            }), e("div", {
                className: "desc",
                children: c("page.lottery.about")
            }), e("div", {
                className: "btn",
                children: r("button", {
                    onClick: () => T.push(e(Gc, {})),
                    children: [c("common.actions.details"), " ", e(j, {
                        name: "Arrow"
                    })]
                })
            })]
        }), e(Pc, {})]
    })
}
const Ec = "sqx1u4r";
M({
    cl5: ["#fff", "#000"],
    cl6: ["#222428", "#fff"],
    cl7: ["#2d3035", "#fff"],
    cl8: ["#2c3138", x("#5f6975", .2)]
});
const qc = "g18qg53k";
const $c = B.memo(function() {
        const t = g();
        return r("div", {
            className: Rc,
            children: [e("div", {
                className: "title",
                children: t("common.howtoplay")
            }), e(Ac, {}), e(kc, {}), e(pc, {}), e(Dc, {})]
        })
    }),
    Rc = "v862hbl";

function he({
    lenth: c,
    showMore: t,
    setShowMore: i,
    page: n,
    total: a,
    onChangePage: s
}) {
    return a <= 10 ? null : r("div", {
        className: Hc,
        children: [n === 1 && c > 10 && e(N, {
            className: "hide-show",
            onClick: () => i(!t),
            children: t ? "hide" : "more"
        }), t && e(ht, {
            page: n,
            total: a,
            onChange: s
        })]
    })
}
M({
    cl1: [x("#4e5563", .3), x("#e9eaf2", .4)],
    cl2: ["#2d3035", "#e9eaf2"]
});
const Hc = "vovss2v";

function Vc(c, t) {
    return k.post("/lottery/five-plus-one/history/", {
        periodId: c,
        page: t,
        pageSize: 20
    })
}
const ye = _(function() {
    const t = D(),
        i = g(),
        n = Y(),
        a = t.status != 0;
    return r("div", {
        className: y(Jc, "no-ticket"),
        children: [e("div", {
            className: "tips",
            children: i("page.lottery.noticket")
        }), e(N, {
            type: "conic4",
            disabled: a,
            onClick: () => n("/buyticket"),
            children: e(F, {
                delay: 100,
                title: a ? r("div", {
                    children: ["Ticket sale suspended for ", e("br", {}), " 5 mins before each draw."]
                }) : null,
                children: i("page.lottery.buynow")
            })
        })]
    })
});

function Wc({
    item: c,
    quantity: t,
    txt: i
}) {
    if (c.status > 1) {
        if (c.rewardType === 1) return r("span", {
            children: ["+", t, " ", i]
        }); {
            const n = Number(c.rewardAmount);
            return n > 0 ? e("span", {
                className: "freen-word",
                children: e(Pe, {
                    amount: n
                })
            }) : e("span", {
                children: Math.floor(n)
            })
        }
    } else return e("span", {
        children: "-"
    })
}
const Oc = B.memo(function({
        periodId: t,
        isFirstPage: i,
        enforceUpdate: n
    }) {
        const [a, s] = v.exports.useState(0), [o, m] = v.exports.useState(0), l = g(), f = Me(({
            width: b
        }) => {
            m(b)
        }), [u, d] = q({
            page: 1,
            showMore: !1,
            updateId: 0
        }), p = P(() => Vc(t, u.page), [u.page, t, a]);
        v.exports.useEffect(() => {
            d({
                page: 1
            })
        }, [t]);
        const H = async () => {
            i && s(b => b + 1)
        };
        if (v.exports.useEffect(() => {
                n && H()
            }, [n]), !p.data) return e("div", {
            className: Uc,
            children: e(L, {})
        });
        const A = p.data;
        if (A.pageList.list.length === 0 || !t) return e(ye, {});
        const E = A.pageList.list,
            z = A.pageList.total,
            V = !u.showMore && E.length > 10 ? E.slice(0, 10) : E,
            Q = l("page.lottery.ticket");
        return r("div", {
            className: y(Fc, "table-wrap", o > 600 && "wid"),
            ref: f,
            children: [A.luckyNumbers && A.luckyJackpotBallNumber && e(We, {
                nums: A.luckyNumbers,
                jackpotNum: A.luckyJackpotBallNumber
            }), r(oe, {
                hover: !1,
                children: [e("thead", {
                    children: r("tr", {
                        children: [e("th", {
                            className: "hnums",
                            children: l("page.lottery.ticketnum")
                        }), e("th", {
                            children: l("page.lottery.tickets")
                        }), e("th", {
                            children: l("common.prize")
                        })]
                    })
                }), e("tbody", {
                    children: V.map((b, w) => r("tr", {
                        children: [e("td", {
                            className: "nums",
                            children: e(ve, I({}, b))
                        }), r("td", {
                            className: "res",
                            children: ["X ", b.quantity]
                        }), e("td", {
                            className: "el",
                            children: e(Wc, {
                                item: b,
                                quantity: b.quantity,
                                txt: Q
                            })
                        })]
                    }, w))
                })]
            }), e(he, {
                showMore: u.showMore,
                setShowMore: b => d({
                    showMore: b
                }),
                lenth: E.length,
                page: u.page,
                total: z,
                onChangePage: b => d({
                    page: b
                })
            })]
        })
    }),
    Fc = "vee89u1",
    Uc = "lms727e",
    Jc = "n1yyx5fn";

function Kc(c) {
    return c.map(t => ({
        label: String(t.periodId),
        value: t.periodId
    }))
}

function Ke(c, t, i, n) {
    const [a, s] = v.exports.useState(0), [o, m] = v.exports.useState(t), l = g();
    v.exports.useEffect(() => {
        c.length > 0 && t === 1 && s(c[0].periodId)
    }, [c]);
    const f = c.findIndex(w => w.periodId === a),
        u = c[f],
        d = n && f === c.length - 1,
        p = f >= c.length - 1,
        H = f < 1,
        A = f === 0,
        E = () => {
            o < i && f >= c.length - 6 && m(J => J + 1);
            const w = c[f + 1];
            s(w.periodId)
        },
        z = () => {
            if (f >= 1) {
                const w = c[f - 1];
                s(w.periodId)
            }
        },
        V = () => {
            const w = c[0];
            s(w.periodId)
        },
        Q = w => {
            const J = c.findIndex(W => W.periodId === w);
            o < i && J >= c.length - 6 && m(W => W + 1), s(w)
        };
    return {
        view: r("div", {
            className: y(Xc, "gameno-check"),
            children: [e("div", {
                className: "game-no",
                children: l("common.game_number")
            }), r("div", {
                className: "gameno-control",
                children: [e(N, {
                    disabled: p,
                    loading: d,
                    className: "pre",
                    onClick: E,
                    children: e(j, {
                        name: "Arrow"
                    })
                }), e(yt, {
                    value: a,
                    renderLabel: w => e("p", {
                        className: "select-option",
                        children: w.label
                    }),
                    options: Kc(c),
                    onChange: Q
                }), e(N, {
                    disabled: H,
                    onClick: z,
                    children: e(j, {
                        name: "Arrow"
                    })
                }), e(N, {
                    disabled: A,
                    onClick: V,
                    children: e(j, {
                        name: "Final"
                    })
                }), u && e("span", {
                    className: "time",
                    children: new Date(c[f].drawnTime).toLocaleString()
                })]
            }), e("button", {
                className: "fairness",
                onClick: () => T.push(e(Fe, {
                    pid: a
                })),
                children: e(j, {
                    name: "Fairness"
                })
            })]
        }),
        curPage: o,
        periodId: a,
        curObj: u
    }
}
M({
    cl1: ["#2a2c32", "rgba(151, 151, 151, .2)"],
    cl2: ["#2d3035", "rgba(152, 167, 181, 0.2)"],
    cl3: ["rgba(45, 48, 53, 0.5)", "rgba(233, 234, 242, 0.3)"],
    cl4: ["#fff", "#000"],
    cl5: ["#2d3035", "rgba(152, 167, 181, 0.2)"],
    cl6: [x("#2d3035", .8), x("#e9eaf2", .8)],
    cl7: ["#fff", "#9aa1a9"]
});
const Xc = "v1tetjd0";

function Yc(c) {
    return k.post("/lottery/five-plus-one/my-period-list/", {
        page: c,
        pageSize: 20
    })
}
const Qc = _(function() {
        const t = D(),
            i = t.periodId,
            [n, a] = q({
                list: [],
                loading: !1,
                init: !1,
                totalPage: 1,
                page: 1
            }),
            s = () => {
                a({
                    loading: !0
                }), Yc(n.page).then(f => {
                    const u = n.page === 1 ? f.list : n.list.concat(f.list);
                    u.length != 0 && !u.find(p => p.periodId === i) && u.unshift({
                        periodId: i,
                        drawnTime: t.header.drawnTime,
                        jackpotBallNumber: 0,
                        numbers: []
                    });
                    const d = u.findIndex(p => p.periodId !== i && p.jackpotBallNumber === 0);
                    d > -1 && u.splice(d, 1), a({
                        list: u,
                        loading: !1,
                        init: !0,
                        totalPage: f.totalPage
                    })
                }).catch(G)
            },
            {
                view: o,
                periodId: m,
                curPage: l
            } = Ke(n.list, n.page, n.totalPage, n.loading && n.init);
        return v.exports.useEffect(() => {
            a({
                page: l
            })
        }, [l]), v.exports.useEffect(() => {
            s();
            const f = () => {
                n.page === 1 ? s() : a({
                    page: 1
                })
            };
            return h.on("lottery-ticket", f), () => {
                h.off("lottery-ticket", f)
            }
        }, [n.page, i]), v.exports.useEffect(() => {
            t.buyDrawEnd && s()
        }, [t.buyDrawEnd]), n.init ? n.list.length === 0 ? e(ye, {}) : r("div", {
            className: Zc,
            children: [o, m && e(Oc, {
                enforceUpdate: n.loading,
                periodId: m,
                isFirstPage: n.page === 1
            })]
        }) : e("div", {
            className: e0,
            children: e(L, {})
        })
    }),
    ze = _(function() {
        return h.login ? e(Qc, {}) : e(ye, {})
    }),
    Zc = "v1ngx7da",
    e0 = "lhchryx";

function t0({
    item: c,
    quantity: t,
    txt: i
}) {
    if (c.rewardType === 1) return r("span", {
        children: ["+", t, " ", i]
    }); {
        const n = Number(c.rewardAmount) || 0;
        return n > 0 ? e("span", {
            className: "green-word",
            children: e(Pe, {
                amount: n
            })
        }) : e("span", {
            children: Math.floor(n)
        })
    }
}

function c0(c, t, i) {
    return k.post("/lottery/five-plus-one/winners/", {
        periodId: c,
        page: t,
        pageSize: i
    })
}

function n0({
    periodId: c
}) {
    const t = g(),
        [i, n] = q({
            periodId: c,
            page: 1,
            pageSize: 20,
            showMore: !1
        });
    v.exports.useEffect(() => {
        n({
            periodId: c,
            page: 1
        })
    }, [c]);
    const a = P(() => c0(c, i.page, i.pageSize), [i.page, i.periodId]);
    if (!a.data) return e("div", {
        className: Ie,
        children: e(L, {})
    });
    const s = a.data;
    if (s.winnersPageList.list.length === 0) return e("div", {
        className: Ie,
        children: e(fe, {})
    });
    const o = s.winnersPageList.list,
        m = i.showMore ? o : o.slice(0, 10),
        l = t("page.lottery.ticket");
    return r("div", {
        className: i0,
        children: [r("div", {
            className: "wrap",
            children: [r("div", {
                className: "top",
                children: [e("div", {
                    className: "sub-tit",
                    children: t("page.lottery.winners")
                }), r("div", {
                    className: "sub-txt",
                    children: [t("page.lottery.hint"), " ", e("span", {
                        children: s.soldTickets
                    })]
                })]
            }), r(oe, {
                hover: !1,
                children: [e("thead", {
                    children: r("tr", {
                        children: [e("th", {
                            children: C.isMobile ? t("common.name") : t("common.winnerName")
                        }), e("th", {
                            className: "hnums",
                            children: t("common.numbers")
                        }), e("th", {
                            children: t("common.matches")
                        }), e("th", {
                            children: t("common.prize")
                        })]
                    })
                }), e("tbody", {
                    children: m.map((f, u) => r("tr", {
                        children: [e("td", {
                            children: e(De, {
                                userId: f.userId,
                                name: f.userName
                            })
                        }), e("td", {
                            children: e("div", {
                                className: "nums-wrap",
                                children: r("div", {
                                    className: "nums-inner",
                                    children: [e(ve, I({}, f)), r("p", {
                                        className: "quantity",
                                        children: ["x ", f.quantity]
                                    })]
                                })
                            })
                        }), e("td", {
                            className: "res",
                            children: f.result
                        }), e("td", {
                            className: "el",
                            children: e(t0, {
                                item: f,
                                quantity: f.result,
                                txt: l
                            })
                        })]
                    }, u))
                })]
            })]
        }), e(he, {
            showMore: i.showMore,
            setShowMore: f => n({
                showMore: f
            }),
            lenth: o.length,
            page: i.page,
            total: s.winnersPageList.total,
            onChangePage: f => n({
                page: f
            })
        })]
    })
}
const Ie = "li817bq",
    i0 = "v1kdh8r0";

function r0(c) {
    return k.post("/lottery/five-plus-one/drawn-list/", {
        page: c,
        pageSize: 20
    })
}
const Le = _(function() {
        const t = D(),
            [i, n] = q({
                list: [],
                loading: !1,
                init: !1,
                totalPage: 1,
                page: 1
            }),
            {
                view: a,
                periodId: s,
                curPage: o,
                curObj: m
            } = Ke(i.list, i.page, i.totalPage, i.loading),
            l = () => {
                n({
                    loading: !0
                }), r0(i.page).then(f => {
                    const u = i.page === 1 ? f.list : i.list.concat(f.list);
                    n({
                        list: u,
                        loading: !1,
                        init: !0,
                        totalPage: f.totalPage
                    })
                }).catch(G)
            };
        return v.exports.useEffect(() => {
            t.drawEnd && l()
        }, [t.drawEnd]), v.exports.useEffect(l, [i.page]), v.exports.useEffect(() => {
            n({
                page: o
            })
        }, [o]), v.exports.useEffect(() => {
            const f = i.list.findIndex(u => u.periodId === s) === 0;
            t.periodId && f && (n({
                init: !1
            }), l())
        }, [t.periodId]), i.init ? i.list.length === 0 ? e("div", {
            className: Ae,
            children: e(fe, {})
        }) : r("div", {
            children: [a, r("div", {
                className: "table-wrap",
                children: [m && e(We, {
                    nums: m.numbers,
                    jackpotNum: m.jackpotBallNumber
                }), e(n0, {
                    periodId: s
                })]
            })]
        }) : e("div", {
            className: Ae,
            children: e(L, {})
        })
    }),
    Ae = "w18n4rih";
const a0 = function(c) {
        return k.post("/lottery/five-plus-one/prize-list/", {
            page: c,
            pageSize: 20
        })
    },
    o0 = _(function() {
        const t = g(),
            i = D(),
            [n, a] = q({
                list: [],
                loading: !1,
                init: !1,
                page: 1,
                showMore: !1
            }),
            {
                data: s
            } = P(() => a0(n.page), [n.page, i.buyDrawEnd]);
        if (!s) return e("div", {
            className: Se,
            children: e(L, {})
        });
        const o = s.list;
        if (o.length === 0) return e("div", {
            className: Se,
            children: e(fe, {})
        });
        const m = !n.showMore && o.length > 10 ? o.slice(0, 10) : o,
            l = t("page.share.success"),
            f = async function(u) {
                const d = bt.currentRoom.id;
                if (await ie.confirm(t("page.share.share_to_room_confirm"))) return k.post("/lottery/five-plus-one/share/chatroom/", {
                    ticketId: u,
                    roomId: d
                }).then(() => G(l))
            };
        return r("div", {
            className: y(f0, "table-wrap"),
            children: [r(oe, {
                hover: !1,
                children: [e("thead", {
                    children: r("tr", {
                        children: [e("th", {
                            className: "hnums",
                            children: C.isMobile ? t("page.lottery.ticket") : t("page.lottery.ticketnum")
                        }), e("th", {
                            children: t("common.game_number")
                        }), e("th", {
                            children: t("page.lottery.tickets")
                        }), e("th", {
                            children: t("common.prize")
                        })]
                    })
                }), e("tbody", {
                    children: m.map((u, d) => r("tr", {
                        children: [e("td", {
                            className: "nums",
                            children: e(ve, I({}, u))
                        }), e("td", {
                            children: u.periodId
                        }), r("td", {
                            children: ["X ", u.quantity]
                        }), r("td", {
                            className: "el",
                            children: [r("span", {
                                className: re(Number(u.rewardAmount) > 0 && "green-word"),
                                children: ["$", Math.floor(Number(u.rewardAmount))]
                            }), e(F, {
                                title: t("page.share.share_to_room"),
                                delay: 100,
                                children: e(N, {
                                    onClick: () => f(u.ticketId),
                                    children: e(j, {
                                        name: "Share"
                                    })
                                })
                            })]
                        })]
                    }, d))
                })]
            }), e(he, {
                showMore: n.showMore,
                setShowMore: u => a({
                    showMore: u
                }),
                lenth: o.length,
                page: n.page,
                total: s.total,
                onChangePage: u => a({
                    page: u
                })
            })]
        })
    }),
    Se = "l1b2t3tf",
    f0 = "v1mcun0b";
const s0 = _(() => {
        const c = D(),
            t = g();
        return r(ee, {
            children: [t("common.myticket"), " (", c.myTicketsLenth, ")"]
        })
    }),
    l0 = _(function() {
        const t = D(),
            i = g(),
            n = h.login,
            a = se(),
            s = Ee(a),
            o = Y();
        v.exports.useEffect(() => {
            n && t.init()
        }, [n]), v.exports.useEffect(() => {
            t.myTicketsLenth || o("/lottery/history")
        }, []);
        const m = [{
                label: e(s0, {}),
                href: "",
                value: ze
            }, {
                label: i("common.mywinnings"),
                href: "winnings",
                value: o0
            }, {
                label: i("common.history"),
                href: "history",
                value: Le
            }],
            l = [{
                label: i("common.myticket"),
                href: "",
                value: ze
            }, {
                label: i("common.history"),
                href: "history",
                value: Le
            }],
            f = n ? m : l,
            u = f.findIndex(p => p.href === s[0]),
            d = u === -1 ? 0 : u;
        return e("div", {
            className: m0,
            children: e(xt, {
                className: y(n && "login"),
                type: "circle",
                tabs: f,
                value: d,
                onChange: p => o(p === 0 ? "/lottery" : `/lottery/${f[p].href}`)
            })
        })
    }),
    m0 = "vghx9va";
const u0 = _(function() {
        return D().periodId ? e(d0, {}) : e("div", {
            className: y(Xe, "loading"),
            children: e(L, {})
        })
    }),
    d0 = B.memo(function() {
        return r("div", {
            className: Xe,
            children: [e(dc, {}), e(l0, {}), e($c, {})]
        })
    });

function V0() {
    return e(rc, {
        children: e(u0, {})
    })
}
const Xe = "w1blyup0";
const v0 = B.memo(function({
        min: c,
        max: t,
        onChange: i,
        value: n
    }) {
        const [a, s] = v.exports.useState(!1), o = Nt(() => {
            s(!1)
        }), [m, l] = v.exports.useState(() => n === c ? 2 : n === t ? 1 : -1);

        function f(d) {
            let p = -1;
            d === t && (p = 1), d === c && (p = 2), l(p), i(d)
        }

        function u(d) {
            l(d ? 1 : 2), i(d ? t : c)
        }
        return r(ee, {
            children: [e(wt, {
                children: a && r(Ge.div, {
                    ref: o,
                    className: "fix-layer",
                    children: [e("button", {
                        className: m === 2 ? "active" : "",
                        onClick: () => u(!1),
                        children: "Min"
                    }), e(kt, {
                        min: c,
                        max: t,
                        value: n,
                        onChange: f
                    }), e("button", {
                        className: m === 1 ? "active" : "",
                        onClick: () => u(!0),
                        children: "Max"
                    })]
                })
            }), r("button", {
                className: p0,
                onClick: () => s(!a),
                children: [e(j, {
                    name: "Arrow"
                }), e(j, {
                    name: "Arrow"
                })]
            })]
        })
    }),
    p0 = "tr4z8ud";

function g0(c, t, i) {
    const [n, a] = q({
        quantity: 1,
        expiredTime: 0,
        fromCurrencyName: "",
        fromCurrencyPrice: "",
        toCurrencyName: "BCL",
        toCurrencyPrice: "",
        error: !1,
        loading: !0
    }), s = () => {
        c === "BCL" ? a({
            expiredTime: 0,
            fromCurrencyPrice: ".1",
            fromCurrencyName: "BCL",
            toCurrencyPrice: ".1",
            loading: !1
        }) : (a({
            loading: !0
        }), k.post("/game/support/swap/price/", {
            fromCurrencyName: c,
            toCurrencyName: n.toCurrencyName
        }).then(d => {
            a(I({
                loading: !1,
                error: !1
            }, d))
        }).catch(d => {
            G(d), a({
                error: !0
            })
        }))
    };
    v.exports.useEffect(s, [c]), v.exports.useEffect(() => {
        i && n.quantity > i && a({
            quantity: i
        })
    }, [i, n.quantity]);
    let o = "-",
        m = "-";
    n.loading || (m = je(new Ce(n.toCurrencyPrice).div(n.fromCurrencyPrice).toString()), o = je(new Ce(n.quantity).mul(m).toString()));
    const l = d => {
            i && (d = d > i ? i : d), a({
                quantity: Math.floor(d)
            })
        },
        f = Number(o) > t;
    return {
        view: r("div", {
            className: h0,
            children: [r("div", {
                className: "label",
                children: ["Number of tickets", e(jt, {
                    endTime: n.expiredTime,
                    onComplete: s,
                    className: "cut-time"
                })]
            }), r("div", {
                className: re("input-tickets", n.loading && "loading"),
                children: [r("div", {
                    className: "pre-input",
                    children: [e(qe, {
                        value: n.quantity,
                        onChange: l,
                        min: 1
                    }), r(Ct, {
                        children: [e(N, {
                            onClick: () => l(10),
                            children: "10"
                        }), e(N, {
                            onClick: () => l(50),
                            children: "50"
                        }), e(N, {
                            onClick: () => l(100),
                            children: "100"
                        }), e(v0, {
                            onChange: l,
                            value: n.quantity,
                            max: 1e3,
                            min: 1
                        })]
                    })]
                }), e("div", {
                    className: "suff-desc",
                    children: r("div", {
                        className: "cont",
                        children: [e("div", {
                            className: "cost",
                            children: "Total Cost:"
                        }), r("div", {
                            className: re("amount", f && "error"),
                            children: [o, " ", S.getAlias(c)]
                        })]
                    })
                })]
            }), r("div", {
                className: "desc",
                children: [m, " ", S.getAlias(c), "/Ticket"]
            })]
        }),
        error: f || n.error,
        quantity: n.quantity,
        fromCurrencyName: n.fromCurrencyName,
        fromCurrencyAmount: o === "-" ? "0" : o,
        toCurrencyName: n.toCurrencyName,
        expiredTime: n.expiredTime
    }
}
M({
    cl1: ["#25272c", "#f5f6fa"],
    cl2: ["#2d3035", "#e9eaf2"],
    cl3: [x("#3c404a", .5), x("#cccfd9", .6)],
    cl4: ["#f5f6f7", "#5f6975"],
    cl5: ["#3c404a", x("#e9eaf2", .5)],
    cl6: ["#212328", "#f5f6fa"],
    cl7: ["#17181b", x("#77808b", .5)],
    cl8: ["#cccfd9", "#cccfd9"]
});
const h0 = "s1vm5csb";

function Ye(c) {
    return Math.ceil(Math.random() * (c || 36))
}

function Qe(c) {
    const t = Ye();
    c.find(i => i === t) ? Qe(c) : c.push(t)
}

function y0() {
    const [c, t] = q({
        check: !1,
        nums: [],
        jackpotNum: 0
    }), i = m => {
        const l = c.nums.findIndex(f => f === m);
        l != -1 ? (c.nums.splice(l, 1), t({
            nums: [...c.nums]
        })) : c.nums.length < 5 && t({
            nums: [...c.nums, m]
        })
    }, n = () => {
        const m = [];
        for (let l = 0; l < 5; l++) Qe(m);
        t({
            nums: m,
            jackpotNum: Ye(10)
        })
    }, a = m => {
        const l = c.nums.findIndex(f => f === m) !== -1;
        return y(l && "active")
    }, s = c.check ? c.nums.length < 5 || c.jackpotNum <= 0 : !1;
    return {
        view: r("div", {
            className: b0,
            children: [e(_t, {
                options: [{
                    label: "Auto Generate",
                    value: !1
                }, {
                    label: "Manual Select",
                    value: !0
                }],
                value: c.check,
                onChange: m => t({
                    check: m
                })
            }), c.check && r("div", {
                className: "select-box",
                children: [r("div", {
                    className: "simple",
                    children: [r("div", {
                        className: "random-wrap",
                        children: [e("div", {
                            className: "sub-tips",
                            children: "5 digits optional"
                        }), e("button", {
                            className: "random",
                            onClick: n,
                            children: "Random"
                        })]
                    }), e("div", {
                        className: "box",
                        children: new Array(36).fill(null).map((m, l) => e(N, {
                            className: a(l + 1),
                            onClick: () => i(l + 1),
                            children: l + 1
                        }, l))
                    })]
                }), r("div", {
                    className: "jackpot",
                    children: [e("div", {
                        className: "sub-tips",
                        children: "1 Jackpot Ball"
                    }), e("div", {
                        className: "box",
                        children: new Array(10).fill(null).map((m, l) => e(N, {
                            className: y(l + 1 === c.jackpotNum && "active"),
                            onClick: () => t({
                                jackpotNum: l + 1
                            }),
                            children: l + 1
                        }, l))
                    })]
                })]
            }), e("div", {
                className: y("error-txt", s && "show"),
                children: "Please choose 6 numbers to take part in the BC.GAME Lottery!"
            })]
        }),
        error: s,
        numbers: c.nums,
        jackpotBallNumber: c.jackpotNum,
        pickType: c.check ? 0 : 1
    }
}
M({
    cl1: ["#4e5563", "rgba(110,120,131,0.2)"],
    cl2: ["rgba(110,120,131,0.5)", "rgba(110,120,131,0.5)"],
    cl3: ['url("../../assets/select_ball.png")', 'url( "../../assets/select_ball_white.png")'],
    cl4: ["#26282d", x("#6e7883", .2)],
    cl5: ["rgba(110,120,131,0.5)", "rgba(110,120,131,0.5)"]
});
const b0 = "s1f33xrg";

function x0() {
    return k.get("/game/support/swap/config/")
}
async function N0() {
    return (await k.get("/lottery/five-plus-one/current-info/")).status != 0
}

function W0() {
    const c = se();
    return Ee(c)[0] ? e(w0, {}) : e(Ze, {})
}

function w0() {
    const {
        data: c
    } = P(N0);
    return c === null ? e(L, {}) : e(Ze, {
        btnDisabled: c
    })
}

function Ze({
    btnDisabled: c
}) {
    const [t, i] = q({
        currency: "BCL"
    }), n = S.dict[t.currency].amount, {
        data: a
    } = P(() => x0()), {
        view: s,
        numbers: o,
        error: m,
        jackpotBallNumber: l,
        pickType: f
    } = y0(), E = g0(t.currency, n, f === 1 ? 1e3 : void 0), {
        view: u,
        error: d
    } = E, p = Z(E, ["view", "error"]);
    if (!a) return e(L, {});
    const H = async () => {
            let z = a.list.map(b => S.dict[b]);
            const V = z.findIndex(b => b.currencyName === "BCL");
            if (V > -1) {
                const b = z.splice(V, 1),
                    w = z.filter(W => W.amount > 0),
                    J = z.filter(W => W.amount === 0);
                b[0].amount > 1 ? z = [b[0], ...w, ...J] : z = [...w, b[0], ...J]
            }
            const Q = await It(t.currency, !1, z);
            i({
                currency: Q
            })
        },
        A = () => {
            const z = I({
                pickType: f
            }, p);
            return f === 0 && Object.assign(z, {
                jackpotBallNumber: l,
                numbers: o,
                pickType: f
            }), k.post("/lottery/five-plus-one/buy/", z).then(V => {
                T.close(), G("Congratulations! You\u2019ve Successfully bought a Lottery Ticket. Good Luck!"), h.emit("lottery-ticket")
            }).catch(G)
        };
    return e(R, {
        title: "Buy Lottery Tickets",
        children: r(U, {
            className: k0,
            children: [e("div", {
                className: "warn",
                children: r("span", {
                    children: ["You can get more BCL from ", e(ae, {
                        to: "/wallet/swap?to=BCL",
                        children: "BCSwap"
                    }), " at anytime"]
                })
            }), r("div", {
                className: "layout",
                children: [e("div", {
                    className: "label",
                    children: "Pay with"
                }), r("div", {
                    className: "pay-input",
                    onClick: H,
                    children: [e(zt, {
                        className: "coin-icon",
                        name: t.currency
                    }), e("span", {
                        className: "currency",
                        children: S.getAlias(t.currency)
                    }), e("span", {
                        className: "balance",
                        children: n
                    }), e(j, {
                        name: "Arrow"
                    })]
                })]
            }), u, s, e(N, {
                disabled: d || m || c,
                onClick: A,
                className: "submit-btn",
                type: "conic",
                children: "Buy Tickets"
            })]
        })
    })
}
M({
    cl1: ["#43b309", "#5ddb1c"],
    cl2: [x("#5da00", .1), x("#7bc514", .1)],
    cl3: ["#fff", "#25272c"],
    cl4: ["#25272c", "#f5f6fa"],
    cl5: ["#2d3035", "#e9eaf2"]
});
const k0 = "so5vt58";

function j0(c, t, i) {
    const [n, a] = v.exports.useState(i > c ? c : i), s = l => {
        a(Math.ceil(l))
    }, o = n > t || n < c, m = r("div", {
        className: y(C0, "gift-btn"),
        children: [e("button", {
            className: "sub-btn",
            disabled: n <= c,
            onClick: () => n > 1 && a(n - 1),
            children: "-"
        }), e(qe, {
            value: n,
            onChange: s,
            min: c,
            max: t
        }), e("button", {
            className: "add-btn",
            disabled: n >= t,
            onClick: () => a(n + 1),
            children: "+"
        })]
    });
    return {
        num: n,
        view: m,
        error: o
    }
}
M({
    cl1: ["#2d3035", "rgba(152, 167, 181, 0.2)"],
    cl2: [x("#2d3035", .8), x("#e9eaf2", .5)]
});
const C0 = "n1mhsy74";
var et = "/assets/BCL.e50b3f6d.png";

function tt(c) {
    return C.createPath(`/giftbcl/${c}`)
}

function _0({
    link: c
}) {
    const t = g(),
        {
            data: i
        } = P(() => At({
            title: t("common.gift_link"),
            content: t("common.gift_share"),
            shareUrl: c,
            isGame: !1
        }));
    return i ? r("div", {
        className: A0,
        children: [e("div", {
            className: "share-tit",
            children: e("div", {
                className: "share-txt",
                children: t("common.share_with")
            })
        }), e("div", {
            className: "cont",
            children: i.map((n, a) => n.src ? e("a", {
                href: n.src,
                target: "_blank",
                rel: "noopener noreferrer",
                className: "share-item enabled",
                children: e("img", {
                    className: "icon",
                    src: n.icon
                })
            }, a) : e("div", {
                className: "share-item disable",
                children: e("img", {
                    className: "icon",
                    src: n.icon
                })
            }, a))
        })]
    }) : null
}

function ct({
    link: c,
    amount: t,
    message: i
}) {
    const n = g();
    return r(U, {
        className: I0,
        children: [e("div", {
            className: "bg"
        }), r("div", {
            className: "award",
            children: [e("img", {
                src: ge,
                className: "img-award"
            }), r("div", {
                className: "desc",
                children: ["BCL ", e("img", {
                    src: et,
                    className: "img-bcl"
                }), " x", t || 0]
            }), e("div", {
                className: "title",
                children: i
            })]
        }), e(Te, {
            label: n("common.gift_link"),
            readOnly: !0,
            value: c
        }), e(_0, {
            link: c
        })]
    })
}

function z0({
    max: c,
    min: t
}) {
    const i = g(),
        [n, a] = q({
            message: i("page.lottery.gift.holder"),
            link: "",
            loading: !1
        }),
        s = Math.floor(S.dict.BCL.amount),
        {
            num: o,
            view: m,
            error: l
        } = j0(Number(t), Number(c), s),
        f = async () => {
            a({
                loading: !0
            });
            const d = await Lt();
            if (!d) {
                a({
                    loading: !1
                });
                return
            }
            k.post("/game/support/gift/create/", {
                amount: o,
                code: (d == null ? void 0 : d.code) || "",
                currencyName: "BCL",
                message: n.message,
                receiverId: 0,
                timestamp: d.timestamp,
                verifyType: (d == null ? void 0 : d.verifyType) || ""
            }).then(p => {
                const H = tt(p);
                a({
                    link: H,
                    loading: !1
                })
            }).catch(p => {
                a({
                    loading: !1
                }), G(p)
            })
        },
        u = d => {
            d.length <= 40 && a({
                message: d
            })
        };
    return e(R, {
        title: `${i("common.gift")} BCL`,
        children: n.link ? e(ct, we(I({}, n), {
            amount: o
        })) : r(U, {
            className: L0,
            children: [r("div", {
                className: "top",
                children: [e("img", {
                    src: ge
                }), r("div", {
                    className: "cont",
                    children: [i("common.gift"), " ", m, " BCL of ", s]
                })]
            }), e("div", {
                className: "txt",
                children: i("page.lottery.gift.cont")
            }), e(de, {
                label: i("page.lottery.gift.label"),
                value: n.message,
                onChange: u
            }), e(N, {
                disabled: l,
                loading: n.loading,
                className: "submit-btn",
                type: "conic",
                onClick: f,
                children: i("common.actions.generate_link")
            })]
        })
    })
}

function O0() {
    const {
        data: c
    } = P(() => k.get("/game/support/gift/currency/"));
    if (!c || !c.BCL) return e(L, {});
    const {
        min: t,
        max: i
    } = c.BCL;
    return e(z0, {
        max: i,
        min: t
    })
}
const I0 = "s19ivqu5",
    L0 = "d1e5j3cy";
M({
    cl1: ["#16181a", "#f5f6fa"],
    cl2: [x("#373b43", .5), "#E2E3E8"],
    cl3: [x("#373b43", .5), "#E2E3E8"]
});
const A0 = "sx4zd5n";
var S0 = "/assets/get_award.d570e372.png";

function ue(c, t) {
    const i = t ? "/game/support/gift/use/" : "/game/support/gift/info/";
    return k.get(i + c)
}

function nt(i) {
    var n = i,
        {
            txt: c
        } = n,
        t = Z(n, ["txt"]);
    const a = g();
    return r("div", {
        className: y(G0, "receive-gift"),
        children: [e("div", {
            className: "bcl-bg"
        }), e("img", {
            src: S0,
            className: "img-award"
        }), e("div", {
            className: "tit",
            children: c || a("common.received_gift")
        }), r("div", {
            className: "desc",
            children: ["BCL ", e("img", {
                src: et,
                className: "img-bcl"
            }), " x", t.stringAmount]
        }), r("div", {
            className: "cont",
            children: [e(De, {
                userId: t.giverId,
                name: t.giverName
            }), e("div", {
                className: "sub-txt",
                children: t.message
            })]
        })]
    })
}
const Be = _(function({
    code: t,
    isReceive: i
}) {
    const n = Y(),
        a = g(),
        s = St(),
        {
            data: o
        } = P(() => ue(t));
    return v.exports.useEffect(() => {
        !i && s && h.login && t && ue(t, !0).then(m => {}).catch(m => {
            G(m, {
                duration: 6e3
            }), T.close()
        })
    }, [h.login, s, t, i]), o ? e(R, {
        title: `${a("common.gift")} BCL`,
        children: r(U, {
            className: B0,
            children: [e(nt, I({}, o)), h.login ? e(N, {
                type: "conic",
                onClick: () => {
                    n("/lottery"), T.close(), n("/buyticket/chatroom")
                },
                children: a("page.lottery.goto")
            }) : e(N, {
                type: "conic",
                onClick: () => n("/login", {
                    replace: !0
                }),
                children: a("common.register_grab")
            })]
        })
    }) : e(R, {
        title: `${a("common.gift")} BCL`,
        children: e(L, {})
    })
});

function F0() {
    const {
        code: c
    } = se(), t = Y();
    return v.exports.useEffect(() => {
        t("/"), h.inited.then(() => {
            !c || (h.login ? ue(c, !0).then(i => {
                T.push(e(Be, {
                    code: c,
                    isReceive: !0
                }))
            }).catch(i => {
                G(i, {
                    duration: 6e3
                })
            }) : T.push(e(Be, {
                code: c
            })))
        })
    }, []), null
}
const B0 = "v1956eo8",
    G0 = "su6evqb";

function T0(c) {
    return k.get(`game/support/gift/record/${c}/`).catch(G)
}

function M0({
    relateId: c
}) {
    const {
        data: t
    } = P(() => T0(c));
    return t ? t.receiverId && t.receiverName ? e(nt, {
        txt: "Gift claimed by:",
        giverId: t.receiverId,
        giverName: t.receiverName,
        message: t.message,
        stringAmount: t.stringAmount
    }) : e(ct, {
        link: tt(t.giftCode),
        message: t.message,
        amount: Number(t.stringAmount)
    }) : e(L, {})
}

function U0() {
    const {
        relateId: c
    } = se();
    return e(R, {
        className: P0,
        title: "Gift BCL",
        children: c ? e(M0, {
            relateId: c
        }) : e(fe, {})
    })
}
const P0 = "v5op4tc";
var D0 = "/assets/jackpot_ticket.a1e440a6.png",
    E0 = "/assets/jackpot_ticket_w.5d543956.png";

function J0({
    periodId: c,
    message: t
}) {
    return r(ae, {
        className: q0,
        to: "/lottery",
        children: [e("img", {
            src: C.isDarken ? D0 : E0
        }), r("div", {
            children: [r("span", {
                children: ["No.", c]
            }), t]
        })]
    })
}
const q0 = "vc6w29a";
export {
    U0 as BillGift, W0 as BuyTicket, V0 as Lottery, J0 as LotteryNotify, F0 as ReceiveGift, O0 as SendGift
};
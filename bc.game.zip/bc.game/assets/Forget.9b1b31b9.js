import {
    o as p,
    u as g,
    r as o,
    a as t,
    D as d,
    j as m,
    S as f,
    am as h,
    b,
    $ as w,
    G as r,
    v as x
} from "./index.28e31dff.js";
const v = s => w.post("/user/password/recovery/login/", {
        email: s
    }),
    j = p(() => {
        const s = g(),
            [n, e] = o.exports.useState(!1),
            [a, l] = o.exports.useState(""),
            c = () => {
                e(!0);
                const i = s("common.messages.send_success");
                v(a).then(() => {
                    e(!1), r(i), x.back()
                }).catch(u => {
                    e(!1), r(u)
                })
            };
        return t(d, {
            title: s("title.forget"),
            children: m(f, {
                className: S,
                children: [t(h, {
                    label: s("page.forget.email"),
                    className: "input",
                    type: "text",
                    autoComplete: "off",
                    value: a,
                    onChange: l
                }), t(b, {
                    type: "conic",
                    loading: n,
                    onClick: c,
                    children: s("title.forget")
                })]
            })
        })
    }),
    S = "shw406d";
export {
    j as
    default
};
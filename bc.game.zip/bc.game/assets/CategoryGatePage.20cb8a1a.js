import {
    a2 as o,
    bo as r,
    a as t
} from "./index.28e31dff.js";
import {
    F as e
} from "./AggregateList.fd1a9818.js";

function u() {
    const s = o(),
        a = r(s);
    return t(e, {
        tagName: a[0],
        subTagName: a[1] ? a[1] : void 0
    })
}
export {
    u as
    default
};
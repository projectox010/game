import {
    aJ as r,
    aK as t
} from "./index.28e31dff.js";
var a = "[object Number]";

function i(e) {
    return typeof e == "number" || r(e) && t(e) == a
}
export {
    i
};
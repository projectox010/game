! function() {
    var e = document.createElement("style");
    e.innerHTML = ".mr0xt0w{--1wwsc2:#fff}.darken .mr0xt0w{--1wwsc2:rgba(0,0,0,.2)}.mr0xt0w .search-input-bigwrap{height:2.875rem;margin-bottom:.75rem}.mr0xt0w .search-main{background-color:var(--1wwsc2);border-radius:1.25rem;padding:.75rem}.mr0xt0w .require-wrod{margin-top:1.5rem}.mr0xt0w .recommend-wrap{margin-top:2rem}@media screen and (max-width:621px){.mr0xt0w .require-wrod{margin-top:.625rem}}\n", document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js", "./SearchMain-legacy.517a4235.js"], (function(e) {
        "use strict";
        var r, t, n, a, c, i;
        return {
            setters: [function(e) {
                r = e.a5, t = e.r, n = e.j, a = e.a, c = e.fn
            }, function(e) {
                i = e.default
            }],
            execute: function() {
                e("default", r.memo((function({
                    big: e,
                    onCLose: r
                }) {
                    const o = t.exports.useRef(null);
                    return t.exports.useEffect((() => {
                        var r;
                        let t;
                        return e ? null === (r = o.current) || void 0 === r || r.focus() : t = setTimeout((() => {
                            var e;
                            null === (e = o.current) || void 0 === e || e.focus()
                        }), 200), () => {
                            clearTimeout(t)
                        }
                    }), []), n("div", {
                        className: `${m} mobile-search-main`,
                        children: [a(c, {
                            isSmall: !0,
                            closeFn: r,
                            ref: o,
                            className: "search-input-bigwrap"
                        }), a(i, {
                            closeFn: r
                        })]
                    })
                })));
                const m = "mr0xt0w"
            }
        }
    }))
}();
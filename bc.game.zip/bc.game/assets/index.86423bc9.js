import {
    H as e
} from "./HelpPage.5a10ddbc.js";
import {
    a
} from "./index.28e31dff.js";
var n = `<section>
  <h2>Self-exclusion</h2>
  <p>1. By requesting a period of self-exclusion, you agree to follow the below terms and conditions, which will be in effect from the time that CS implements the chosen period of self-exclusion.</p>
  <p>2. You may self-exclude for periods of 1, 3, 6, 12 month/s or permanent. Self-exclusion requests are to be made via Live Support.</p>
  <p>3. Once you have self-excluded you will not be able to access your account or withdraw during this period.</p>
  <p>4. If you have excluded your account whilst you have pending bets on your account, bets placed will remain valid and settle according to official results. </p>
  <p>5. Once the period of self-exclusion has lapsed you may withdraw winnings from qualifying bets. BC.GAME does not cancel or void any bets placed before a self-exclusion has been affected.</p>
  <p>6. Once you have self-excluded you will not be able to change or alter the period for a shorter length of time or have your self-exclusion cancelled until the period that you selected for self-exclusion has passed.</p>
  <p>7. Please contact our customer services team if you wish to extend your self-exclusion period.</p>
  <p>8. Once your self-exclusion period has elapsed, reinstatement of the account can be done by emailing the request to support@BC.GAME.</p>
  <p>9. By self-excluding, you agree that:</p>
  <ul class="content">
    <li>You will not create another account during this period.</li>
    <li>You will not deposit or attempt to deposit funds into a  BC.GAME account. </li>
    <li>You will not wager on this website during this period.</li>
    <li>This is a voluntary act initiated by yourself, and BlockDance B.V. will not be liable for any losses you may incur during the period of self-exclusion in any form.</li>
  </ul>
</section>`,
    o = `<section>\r
  <h2>Autoexclus\xE3o</h2>\r
    <p>1. Ao solicitar um per\xEDodo de autoexclus\xE3o, voc\xEA concorda em seguir os termos e condi\xE7\xF5es abaixo, que entrar\xE3o em vigor a partir do momento em que o CS implementar o per\xEDodo de autoexclus\xE3o escolhido.</p>\r
    <p>2. Voc\xEA pode se autoexcluir por per\xEDodos de 1, 3, 6, 12 m\xEAs/s ou permanente. As solicita\xE7\xF5es de autoexclus\xE3o devem ser feitas por meio do suporte ao vivo.</p>\r
    <p>3. Depois de se autoexcluir, voc\xEA n\xE3o poder\xE1 acessar sua conta ou fazer saques durante esse per\xEDodo.</p>\r
    <p>4. Se voc\xEA excluiu sua conta enquanto tem apostas pendentes em sua conta, as apostas feitas permanecer\xE3o v\xE1lidas e ser\xE3o liquidadas de acordo com os resultados oficiais. </p>\r
    <p>5. Uma vez que o per\xEDodo de autoexclus\xE3o tenha expirado, voc\xEA pode retirar os ganhos das apostas qualificadas. BC.GAME n\xE3o cancela ou anula quaisquer apostas feitas antes que uma autoexclus\xE3o tenha sido afetada.</p>\r
    <p>6. Depois de se autoexcluir, voc\xEA n\xE3o poder\xE1 alterar ou alterar o per\xEDodo por um per\xEDodo menor ou cancelar sua autoexclus\xE3o at\xE9 que o per\xEDodo selecionado para a autoexclus\xE3o tenha passado.</p>\r
    <p>7. Entre em contato com nossa equipe de atendimento ao cliente se desejar estender seu per\xEDodo de autoexclus\xE3o.</p>\r
    <p>8. Ap\xF3s o t\xE9rmino do per\xEDodo de autoexclus\xE3o, o restabelecimento da conta pode ser feito enviando a solicita\xE7\xE3o por e-mail para support@BC.GAME.</p>\r
    <p>9. Ao se autoexcluir, voc\xEA concorda que:</p>\r
    <ul>\r
      <li>Voc\xEA n\xE3o criar\xE1 outra conta durante esse per\xEDodo.</li>\r
      <li>Voc\xEA n\xE3o depositar\xE1 ou tentar\xE1 depositar fundos em uma conta BC.GAME. </li>\r
      <li>Voc\xEA n\xE3o apostar\xE1 neste site durante este per\xEDodo.</li>\r
      <li>Este \xE9 um ato volunt\xE1rio iniciado por voc\xEA, e a BlockDance B.V. n\xE3o ser\xE1 respons\xE1vel por quaisquer perdas que voc\xEA possa incorrer durante o per\xEDodo de autoexclus\xE3o de qualquer forma.</li>\r
    </ul>\r
  </section>`,
    i = `<section>
  <h2>Pengunduran diri sendiri</h2>
  <p>1. Dengan meminta periode Pengunduran diri, Anda setuju untuk mengikuti syarat dan ketentuan di bawah ini, yang akan berlaku sejak CS menerapkan periode Pengunduran diri yang dipilih.</p>
  <p>2. Anda dapat mengecualikan diri untuk periode 1, 3, 6, 12 bulan/s atau permanen. Permintaan Pengunduran diri harus dibuat melalui Live Support.</p>
  <p>3. Setelah Anda mengecualikan diri, Anda tidak akan dapat mengakses akun Anda atau menarik diri selama periode ini.</p>
  <p>4. Jika Anda telah mengecualikan akun Anda sementara Anda memiliki taruhan tertunda di akun Anda, taruhan yang ditempatkan akan tetap berlaku dan diselesaikan sesuai dengan hasil resmi. </p>
  <p>5. Setelah periode Pengunduran diri berakhir, Anda dapat menarik kemenangan dari taruhan yang memenuhi syarat. BC.GAME tidak membatalkan atau membatalkan taruhan yang ditempatkan sebelum Pengunduran diri terpengaruh.</p>
  <p>6. Setelah Anda mengecualikan diri, Anda tidak akan dapat mengubah atau mengubah periode untuk jangka waktu yang lebih singkat atau Pengunduran diri Anda dibatalkan hingga periode yang Anda pilih untuk Pengunduran diri telah berlalu..</p>
  <p>7. Silakan hubungi tim layanan pelanggan kami jika Anda ingin memperpanjang masa Pengunduran diri Anda.</p>
  <p>8. Setelah periode Pengunduran diri Anda berlalu, pemulihan akun dapat dilakukan dengan mengirim email permintaan ke support@BC.GAME.</p>
  <p>9. Dengan mengecualikan diri, Anda setuju bahwa:</p>
  <ul class="content">
    <li>Anda tidak akan membuat akun lain selama periode ini.</li>
     <li>Anda tidak akan menyetor atau mencoba menyetor dana ke akun BC.GAME. </li>
     <li>Anda tidak akan bertaruh di situs web ini selama periode ini.</li>
     <li>Ini adalah tindakan sukarela yang dilakukan oleh Anda sendiri, dan BlockDance B.V. tidak akan bertanggung jawab atas kerugian apa pun yang mungkin Anda alami selama periode Pengunduran diri dalam bentuk apa pun.</li>
  </ul>
</section>`;

function u() {
    return a(e, {
        br: o,
        en: n,
        id: i
    })
}
export {
    u as
    default
};
import {
    u as I,
    a as e,
    D as M,
    dx as P,
    j as d,
    a5 as g,
    du as Z,
    r as w,
    dy as K,
    dD as Q,
    dZ as X,
    eO as ee,
    dE as ne,
    d as G,
    d_ as te,
    s as L,
    ba as ae,
    bc as se,
    y as re,
    l as S,
    o as j,
    A as O,
    n as le,
    a2 as oe,
    bo as ie,
    dH as ce,
    cJ as z,
    S as de,
    am as v,
    Y as ue
} from "./index.28e31dff.js";
import {
    s as D
} from "./index.dd8128e8.js";
import {
    S as he
} from "./SlotsILayout.a8936350.js";
import {
    u as me
} from "./useLocalStore.f739c306.js";
const be = () => {
        const r = I();
        return e(M, {
            title: r("common.game_intro"),
            children: e(P, {
                children: d("div", {
                    className: "item",
                    children: [e("h2", {
                        children: "What is Oriental Beauties?"
                    }), e("div", {
                        className: "help-content",
                        children: e("p", {
                            children: "Oriental Beauties is a beautifully designed slots that is provably fair like all our games."
                        })
                    }), e("h2", {
                        children: "How to play Oriental Beauties?"
                    }), d("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "Click \u201CSPIN\u201D to start the game, and hold \u201CSPIN'\u201D to activate auto."
                        }), e("p", {
                            children: "Click the triangle button in the upper right corner and select \u201C?\u201D in the list to view rules in more details."
                        })]
                    }), e("h2", {
                        children: "What is the return rate of Oriental Beauties?"
                    }), e("div", {
                        className: "help-content",
                        children: e("p", {
                            children: "RTP is 97.9%."
                        })
                    })]
                })
            })
        })
    },
    ve = g.memo(() => {
        const r = I(),
            n = Z(),
            a = w.exports.useRef(null);
        w.exports.useEffect(() => {
            const t = a.current;
            if (t) {
                const l = o => {
                    const c = pe(o);
                    n.handleBet(c.betAmount, c)
                };
                return t.on("betSuccess", l), () => {
                    t.off("betSuccess", l)
                }
            }
        }, []);
        const s = [{
            title: r("common.game_intro"),
            node: e(be, {})
        }, {
            title: r("common.fairness"),
            node: "/beauties_help/fairness"
        }, {
            title: r("common.max_profits"),
            node: e(K, {
                game: n,
                title: r("common.max_profits")
            })
        }];
        return e(he, {
            src: n.gameUrl,
            ref: a,
            actions: [e(Q, {}), e(X, {}), e(ee, {}), e(ne, {
                list: s
            })],
            banner: n.gameInfo.cover,
            tabs: [{
                label: r("common.all_bet"),
                value: D.AllBet
            }, {
                label: r("common.my_bet"),
                value: D.MyBet
            }]
        })
    });

function pe(r) {
    const {
        betAmount: n,
        betId: a,
        betTime: s,
        currencyName: t,
        nonce: l,
        odds: o,
        winAmount: c,
        gameValue: h
    } = r;
    return {
        userId: G.userId,
        nickName: G.name,
        betAmount: n,
        betId: a,
        betTime: s,
        currencyName: t,
        nonce: l,
        odds: o,
        winAmount: c,
        profitAmount: c - n,
        gameValue: h
    }
}
class ge extends te {
    get gameUrl() {
        return L.isDev ? "http://sob.bc.com/" : `//sob.${L.domain}`
    }
    constructor() {
        super({
            name: "SlotsOrientalBeauties",
            namespace: "/g/sob",
            fairLink: "/beauties_help/fairness",
            validateLink: "/beauties_help/validate"
        }, ve), ae(this, {
            gameUrl: se
        })
    }
    betValue() {
        return new Uint8Array
    }
    async handleBet(n, a) {
        this.addMyBet(a), this.emit("betEnd", {
            amount: new re(a.betAmount),
            odds: a.odds,
            currencyName: a.currencyName
        })
    }
}
const W = new ge;
var an = W;
window.sob = W;
var fe = "/assets/m_banner.cb95b759.jpg",
    ye = "/assets/banner_a1.808c0179.png",
    Se = "/assets/banner_a2.714cf3c0.png",
    _e = "/assets/game_icon.2701c443.png",
    Be = "/assets/play_now.9d7e455d.png",
    Ne = "/assets/Icon_1.b1ebcc4f.png",
    we = "/assets/Icon_2.274d706c.png",
    De = "/assets/Icon_3.ade2e4ea.png",
    Ie = "/assets/Icon_4.e1489a0f.png",
    xe = "/assets/Icon_5.372d5a30.png",
    Ce = "/assets/Icon_6.5a88c44b.png",
    Ae = "/assets/Icon_7.685ee3d3.png",
    He = "/assets/Icon_8.53f1c0de.png",
    Me = "/assets/Icon_9.1b6e3ace.png",
    Ve = "/assets/Icon_10.5e0f7d39.png",
    Te = "/assets/Icon_11.f9d097d0.png",
    Re = "/assets/Icon_12.3a55eb5c.png",
    ke = "/assets/Icon_13.52280594.png",
    $e = `1,3,4,3,2,3
2,7,2,9,7,8
3,10,9,10,11,6
4,9,8,9,8,9
5,7,10,4,9,10
6,8,8,8,3,2
7,10,9,7,8,10
8,6,11,10,10,9
9,9,5,2,11,7
10,8,9,13,6,1
11,4,8,13,8,10
12,10,10,13,9,5
13,8,8,1,3,7
14,9,5,8,10,10
15,10,10,10,1,12
16,8,13,9,8,8
17,2,13,11,7,10
18,10,13,9,9,9
19,7,13,10,2,13
20,5,7,8,6,13
21,10,5,10,10,13
22,3,4,12,3,9
23,8,7,9,9,10
24,7,6,1,8,8
25,12,10,8,4,12
26,6,5,10,13,9
27,10,6,1,13,2
28,2,10,9,13,10
29,9,1,8,13,1
30,7,10,12,9,10
31,8,11,3,3,9
32,10,7,9,7,7
33,12,10,7,10,12
34,7,4,12,1,1
35,8,9,3,10,10
36,9,11,8,11,8
37,10,6,11,9,9
38,8,9,6,2,13
39,6,1,13,7,13
40,12,6,13,3,13
41,7,8,13,1,9
42,10,10,9,9,6
43,8,3,11,8,6
44,9,2,2,10,2
45,3,10,3,11,12
46,5,7,10,9,3
47,1,11,5,1,10
48,7,6,7,4,4
49,12,5,2,5,9
50,9,13,5,3,7
51,8,13,9,10,1
52,1,13,8,8,10
53,7,13,7,4,4
54,5,1,12,5,12
55,10,8,10,9,5
56,9,9,4,2,8
57,4,10,9,10,3
58,9,4,11,3,10
59,10,3,4,9,4
60,7,5,5,8,10
61,5,10,8,4,0
62,10,9,9,13,0
63,12,11,6,13,0
64,9,8,1,13,0
65,6,9,13,13,0
66,7,7,13,6,0
67,2,6,13,8,0
68,9,9,3,5,0
69,4,7,6,9,0
70,5,8,7,4,0
71,1,10,2,11,0
72,7,3,11,5,0
73,8,5,6,2,0
74,10,10,12,10,0
75,9,9,7,8,0
76,4,7,6,4,0
77,8,8,10,3,0
78,3,3,4,5,0
79,10,7,9,2,0
80,6,2,5,10,0
81,0,10,10,0,0
82,0,6,8,0,0
83,0,10,9,0,0
84,0,8,7,0,0
85,0,4,2,0,0
86,0,3,7,0,0
87,0,0,0,0,0
88,0,0,0,0,0
89,0,0,0,0,0
90,0,0,0,0,0
91,0,0,0,0,0
92,0,0,0,0,0
93,0,0,0,0,0
94,0,0,0,0,0
95,0,0,0,0,0
96,0,0,0,0,0
97,0,0,0,0,0
98,0,0,0,0,0
99,0,0,0,0,0
100,0,0,0,0,0
101,0,0,0,0,0
102,0,0,0,0,0
103,0,0,0,0,0
104,0,0,0,0,0
105,0,0,0,0,0
106,0,0,0,0,0
`,
    Fe = `1,3,4,3,2,3
2,6,2,9,7,8
3,4,9,10,11,6
4,2,3,9,8,4
5,7,10,4,5,10
6,5,4,8,3,2
7,10,9,7,4,13
8,6,11,6,10,13
9,4,5,2,11,13
10,8,9,13,6,1
11,4,3,13,8,10
12,10,10,13,5,5
13,4,6,1,3,6
14,9,5,8,10,5
15,1,7,5,1,8
16,8,13,6,4,3
17,2,13,11,7,10
18,9,13,9,5,4
19,4,13,10,2,7
20,5,7,4,6,2
21,10,3,10,10,9
22,3,4,6,5,4
23,4,7,9,2,13
24,6,6,1,8,13
25,9,5,8,4,13
26,6,4,5,13,9
27,10,6,1,13,2
28,2,10,5,13,10
29,9,1,8,13,1
30,4,10,6,9,5
31,5,11,3,3,4
32,1,7,9,7,7
33,7,8,7,10,9
34,5,4,4,1,1
35,1,3,5,10,10
36,9,11,8,11,8
37,4,6,11,9,4
38,8,9,6,2,7
39,6,1,7,7,1
40,9,6,10,3,10
41,6,2,3,1,4
42,10,3,9,9,6
43,2,5,11,4,13
44,9,2,2,10,13
45,4,8,3,11,13
46,5,7,8,5,3
47,1,11,6,1,10
48,7,6,7,4,4
49,9,5,2,13,9
50,4,13,5,13,7
51,5,13,1,13,1
52,1,13,8,13,10
53,7,13,7,4,4
54,5,10,6,5,6
55,1,6,10,9,5
56,9,1,4,2,8
57,4,8,9,10,3
58,4,4,11,5,10
59,2,3,4,2,4
60,7,5,5,8,3
61,5,6,8,4,0
62,10,9,9,13,0
63,6,11,6,13,0
64,9,8,1,13,0
65,6,9,13,13,0
66,10,2,13,6,0
67,2,6,13,8,0
68,9,9,8,5,0
69,4,7,6,3,0
70,5,8,7,4,0
71,1,4,2,11,0
72,7,13,11,5,0
73,5,13,6,2,0
74,1,13,8,10,0
75,9,13,7,8,0
76,4,7,6,4,0
77,8,8,10,7,0
78,9,1,4,5,0
79,10,7,9,2,0
80,6,2,5,10,0
`,
    Ge = `1,1,2,1,1,1
2,1,2,1,2,2
3,1,2,2,2,2
4,1,2,2,3,3
5,1,2,3,2,1
6,1,4,3,4,1
7,2,2,1,2,1
8,2,2,2,2,1
9,2,2,2,3,3
10,2,2,3,2,2
11,2,3,3,3,2
12,2,1,1,1,2
13,2,1,2,1,2
14,2,1,3,1,2
15,2,1,2,4,2
16,3,4,3,3,2
17,3,4,2,1,1
18,3,4,2,4,3
19,3,4,1,4,3
20,3,3,3,4,3
21,3,2,2,3,1
22,3,2,1,2,3
23,3,1,3,1,3
24,3,1,2,4,1
25,3,1,1,1,3
`,
    Le = `1,1,0,0
2,1,2,40
3,1,3,50
4,1,5,60
5,1,7,30
6,1,10,15
7,1,15,10
8,2,0,50
9,2,2,35
10,2,3,45
11,2,5,55
12,2,7,100
13,2,10,30
14,2,15,15
15,3,0,150
16,3,2,40
17,3,3,50
18,3,5,60
19,3,7,60
20,3,10,80
21,3,15,60
22,4,0,475
23,4,2,20
24,4,3,30
25,4,5,40
26,4,7,50
27,4,10,240
28,4,15,200`;
const y = {
    m_banner: fe,
    banner_a1: ye,
    banner_a2: Se,
    play_now: Be,
    game_icon: _e,
    base_csv: $e,
    free_csv: Fe,
    lines_csv: Ge,
    bonus_csv: Le,
    icons: [Ne, we, De, Ie, xe, Ce, Ae, He, Me, Ve, Te, Re, ke]
};
const U = g.memo(r => {
        const {
            index: n,
            className: a
        } = r;
        return e("div", {
            className: a || "item",
            children: e("img", {
                src: y.icons[n],
                className: "item-icon"
            })
        })
    }),
    E = g.memo(({
        table: r
    }) => e("div", {
        className: S(q, "slots-table"),
        children: r.map((n, a) => e("div", {
            className: "cow",
            children: n.map((s, t) => e(U, {
                index: s - 1
            }, t))
        }, a))
    })),
    q = "s1yhgbkg",
    Oe = g.memo(({
        table: r,
        select: n
    }) => {
        const a = Math.max(...r.map(s => s.length));
        return d("div", {
            className: S(q, "slots-table-more"),
            children: [e("div", {
                className: "serials",
                children: Array(a).fill(1).map((s, t) => e("div", {
                    children: e("div", {
                        children: t
                    })
                }, t))
            }), r.map((s, t) => e("div", {
                className: "cow",
                children: s.map((l, o) => e(U, {
                    className: n && n[t] === o ? "item select" : "item",
                    index: l - 1
                }, o))
            }, t))]
        })
    });
class ze {
    constructor() {
        this.cowNums = [3, 4, 3, 4, 3], this.baseData = this.formatDataByCSV(y.base_csv), this.freeData = this.formatDataByCSV(y.free_csv), this.linesData = this.formatLinesByCSV(y.lines_csv), this.bonusData = this.formatBonusByCSV(y.bonus_csv)
    }
    getDataByIndex(n, a) {
        return this.cowNums.map((s, t) => {
            const l = a[t],
                o = l + s;
            return n[t].concat(n[t].slice(0, s)).slice(l, o)
        })
    }
    getBaseDataByIndex(n) {
        return this.getDataByIndex(this.baseData, n)
    }
    getFreeDataByIndex(n) {
        return this.getDataByIndex(this.freeData, n)
    }
    formatCsv(n) {
        return n.split(`
`).map(a => a.split(",").map(s => Number(s)))
    }
    formatDataByCSV(n) {
        const a = this.formatCsv(n),
            s = [
                [],
                [],
                [],
                [],
                []
            ];
        for (let t = 0, l = a.length; t < l; t++)
            for (let o = 0; o < 5; o++) {
                let c = a[t][o + 1];
                c > 0 && s[o].push(c)
            }
        return s
    }
    formatLinesByCSV(n) {
        const a = this.formatCsv(n),
            s = [];
        for (let t = 0, l = a.length; t < l; t++) s.push(a[t].slice(1));
        return s
    }
    formatBonusByCSV(n) {
        const a = this.formatCsv(n),
            s = [
                [],
                [],
                [],
                []
            ];
        for (let t = 0, l = a.length; t < l; t++) {
            const o = a[t];
            s[o[1] - 1].push([o[2], o[3]])
        }
        return s
    }
    getNumsByHash(n, a = 2) {
        let s = [];
        for (let t = 0; t < n.length; t += a) {
            let l = n[t] + n[t + 1],
                o = parseInt(l, 16);
            s.push(o)
        }
        return s
    }
    getResultNumsByHash(n, a, s = 4) {
        let t = this.getNumsByHash(n);
        return a.map((l, o) => {
            let h = t.slice(o * s, (o + 1) * s).map((m, p) => m / Math.pow(256, p + 1)).reduce((m, p) => m + p, 0);
            return Math.floor(h * l)
        })
    }
}
const u = new ze;
const Pe = g.memo(({
        lines: r
    }) => {
        const n = 360 / r.length,
            a = () => r.map(t => u.linesData[t].map((o, c) => {
                const h = c % 2 == 0 ? 20 : 10,
                    m = 10;
                return {
                    x: c * 20 + m,
                    y: (o - 1) * 20 + h
                }
            })),
            s = () => a().map(t => {
                let l = `M${t[0].x},${t[0].y}`,
                    o = t.slice(1).map(c => ` L${c.x},${c.y}`).join("");
                return l + o
            });
        return e("svg", {
            className: S(je, "slots-line"),
            xmlns: "http://www.w3.org/2000/svg",
            viewBox: "0 0 100 80",
            children: s().map((t, l) => e("path", {
                d: t,
                stroke: `hsl(${l*n}, 64%, 42%)`
            }, l))
        })
    }),
    je = "a1que581";
const We = g.memo(({
        table: r,
        lines: n
    }) => d("div", {
        className: S(Ue, "sob-table"),
        children: [e(E, {
            table: r
        }), e(Pe, {
            lines: n
        })]
    })),
    Ue = "ru7sojo";
const Ee = j(({
        rounds: r
    }) => {
        const [n, a] = w.exports.useState(0), s = o => {
            let c = n + o + r.length;
            c = c % r.length, a(c)
        }, t = () => {
            const o = n == 0 ? u.baseData : u.freeData,
                c = r[n].offsets.map(h => h - 1);
            return u.getDataByIndex(o, c)
        }, l = () => r[n].lines.map(o => o.line - 1);
        return d("div", {
            className: S(qe, "slots-result"),
            children: [e(We, {
                table: t(),
                lines: l()
            }), r.length > 1 && d("div", {
                className: "slots-result-actions",
                children: [d("div", {
                    className: "selected",
                    children: [d("div", {
                        className: "text",
                        children: ["Round ", n + 1]
                    }), e("button", {
                        className: "add",
                        onClick: () => s(1),
                        children: e(O, {
                            name: "Arrow"
                        })
                    }), e("button", {
                        className: "min",
                        onClick: () => s(-1),
                        children: e(O, {
                            name: "Arrow"
                        })
                    })]
                }), d("div", {
                    className: "payout",
                    children: ["Payout: ", r[n].odds]
                })]
            })]
        })
    }),
    qe = "rb5teir",
    Je = (r, n, a) => {
        le(`/beauties_help/validate/${r}/${n}/${a}`)
    },
    Ye = D.withSingleDetail({
        onValidate: Je,
        result: ({
            betLog: r
        }) => e(Ee, {
            rounds: r.gv.rounds
        })
    });
var sn = Ye;
const Ze = ({
    bodyLock: r
}) => {
    const n = I();
    return e(M, {
        title: n("common.fairness"),
        children: e(P, {
            bodyLock: r,
            children: d("div", {
                className: "item",
                children: [e("h2", {
                    children: "Fairness Verification"
                }), d("div", {
                    className: "help-content",
                    children: [e("p", {
                        children: "To get the results:"
                    }), d("ul", {
                        children: [e("li", {
                            children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce:round, serverSeed)."
                        }), e("li", {
                            children: "Finally, we get 8 characters of the hash, and convert them to an int32 value. Then we divide the converted value by 0x100000000 and multiply it by the number of symbols on each reel, so that the resulting number conforms to the constraints of the reel range."
                        })]
                    }), e("p", {
                        children: `Note: The number of symbols for the regular reels and the free reels
              are different. For more details, please go to My Bet -> Choose Game ID
              -> Verify.`
                    }), e("p", {
                        children: e("br", {})
                    }), e("p", {
                        children: "If three BONUS symbols appear in the first round, you will enter the bonus game, and can flip up to 4 puzzles."
                    }), d("ul", {
                        children: [e("li", {
                            children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce:round:puzzle, serverSeed)."
                        }), e("li", {
                            children: "Finally, we take 8 characters of the hash, and convert them to an int32 value. Then we divide the converted value by 0x100000000 and multiply it by the probability of the corresponding puzzle. If the result hits 0, the bonus game ends."
                        })]
                    })]
                })]
            })
        })
    })
};
var rn = Ze;
const Ke = j(function() {
    const n = oe(),
        a = I(),
        s = ie(n),
        t = D.HashTable,
        l = me(() => ({
            serverSeed: s[0],
            clientSeed: s[1],
            nonce: parseInt(s[2]) || 0,
            rounds: 0,
            bonusDetail: !1,
            bonusIndex: 0,
            detail: !1
        })),
        {
            serverSeed: o,
            clientSeed: c,
            nonce: h,
            rounds: m,
            bonusDetail: p,
            bonusIndex: b,
            detail: V
        } = l,
        J = String(ce(o)),
        T = [c, h, m],
        x = String(z(T.join(":"), o)),
        C = String(z([...T, b + 1].join(":"), o)),
        A = m > 0 ? u.freeData : u.baseData,
        R = A.map(i => i.length),
        k = u.getResultNumsByHash(x, R),
        $ = () => {
            let i = [];
            return u.bonusData.forEach((B, H) => {
                let f = 0;
                B.forEach(N => {
                    i.push([H, N[0], N[1], f, f + N[1]]), f += N[1]
                })
            }), i
        },
        F = w.exports.useMemo(() => [u.bonusData[b].reduce((H, f) => H + f[1], 0)], [b]),
        Y = p ? $() : $().filter(i => i[0] == b),
        _ = u.getResultNumsByHash(C, F)[0];
    return e(M, {
        title: a("common.fairness"),
        children: d(de, {
            className: Qe,
            children: [e("h2", {
                children: "Input"
            }), e(v, {
                label: "Server Seed",
                value: o,
                onChange: i => l.serverSeed = i
            }), e(v, {
                label: "Client Seed",
                value: c,
                onChange: i => l.clientSeed = i
            }), e(v, {
                label: "Nonce",
                value: h,
                onChange: i => l.nonce = Number(i) || 0
            }), e(v, {
                label: "Rounds",
                value: m,
                onChange: i => l.rounds = Number(i) || 0
            }), e("h2", {
                children: "Output"
            }), e(v, {
                label: "Sha256(server_seed)",
                value: J,
                readOnly: !0
            }), e(v, {
                label: "HMAC_Sha256(client_seed:nonce:rounds, server_seed)",
                value: x,
                readOnly: !0
            }), e(t, {
                hash: x,
                modulusList: R
            }), e("h3", {
                children: "Final Result"
            }), e(E, {
                table: u.getDataByIndex(A, k)
            }), e("div", {
                className: "hidden-show",
                children: e("button", {
                    onClick: () => l.detail = !l.detail,
                    children: V ? "Hide More" : "Show More"
                })
            }), V && e(Oe, {
                select: k,
                table: A
            }), e("h2", {
                children: "Bonus"
            }), e(ue, {
                label: "Index",
                max: 3,
                min: 0,
                value: b,
                onChange: i => l.bonusIndex = Number(i) || 0
            }), e(v, {
                label: "HMAC_Sha256(client_seed:nonce:rounds:index, server_seed)",
                value: C,
                readOnly: !0
            }), e(t, {
                hash: C,
                modulusList: F
            }), e("h3", {
                children: "bonus table"
            }), d("table", {
                style: {
                    width: "100%"
                },
                children: [e("thead", {
                    children: d("tr", {
                        children: [e("td", {
                            children: "Index"
                        }), e("td", {
                            children: "Payout"
                        }), e("td", {
                            children: "Weights"
                        }), e("td", {
                            children: "Range"
                        }), e("td", {})]
                    })
                }), e("tbody", {
                    children: Y.map((i, B) => d("tr", {
                        children: [e("td", {
                            children: i[0]
                        }), e("td", {
                            className: i[0] === b && _ >= i[3] && _ < i[4] ? "cl-primary" : "",
                            children: i[1]
                        }), e("td", {
                            children: i[2]
                        }), d("td", {
                            children: ["[", i[3], ",", i[4], ")"]
                        }), e("td", {
                            children: i[0] == b && _ >= i[3] && _ < i[4] && e("div", {
                                children: "Bingo"
                            })
                        })]
                    }, B))
                })]
            }), e("div", {
                className: "hidden-show",
                children: e("button", {
                    onClick: () => l.bonusDetail = !l.bonusDetail,
                    children: p ? "Hide More" : "Show More"
                })
            })]
        })
    })
});
var ln = Ke;
const Qe = "v1qaz0xz";
export {
    sn as Detail, rn as Fairness, an as Game, ln as Validate
};
var lt = Object.defineProperty,
    ct = Object.defineProperties;
var ht = Object.getOwnPropertyDescriptors;
var X = Object.getOwnPropertySymbols;
var Ce = Object.prototype.hasOwnProperty,
    Be = Object.prototype.propertyIsEnumerable;
var _e = (e, t, a) => t in e ? lt(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    K = (e, t) => {
        for (var a in t || (t = {})) Ce.call(t, a) && _e(e, a, t[a]);
        if (X)
            for (var a of X(t)) Be.call(t, a) && _e(e, a, t[a]);
        return e
    },
    Z = (e, t) => ct(e, ht(t));
var Ae = (e, t) => {
    var a = {};
    for (var o in e) Ce.call(e, o) && t.indexOf(o) < 0 && (a[o] = e[o]);
    if (e != null && X)
        for (var o of X(e)) t.indexOf(o) < 0 && Be.call(e, o) && (a[o] = e[o]);
    return a
};
import {
    bE as ut,
    bF as dt,
    bG as Me,
    a5 as g,
    a as n,
    o as M,
    s as k,
    al as ye,
    l as b,
    d as N,
    j as l,
    F,
    bH as ge,
    t as E,
    q as L,
    r as d,
    m as pt,
    P as be,
    bI as oe,
    bJ as B,
    ar as mt,
    aO as pe,
    bK as q,
    a$ as se,
    b9 as ft,
    $ as H,
    e as V,
    u as x,
    ao as ve,
    G as yt,
    b as we,
    J as ke,
    bL as ne,
    bM as Fe,
    ba as gt,
    bb as ee,
    a4 as bt,
    be as vt,
    bN as Oe,
    aw as ze,
    bO as wt,
    M as Ue,
    bP as kt,
    bQ as qe,
    bR as Nt,
    bS as St,
    U as xt,
    a3 as Tt,
    bv as Lt,
    A as ae,
    bT as _t,
    bU as Ct,
    b2 as Ve,
    bV as Ie,
    L as Ye,
    bW as I,
    k as Bt,
    N as Je,
    bX as At,
    bY as Mt,
    bZ as Ut,
    b_ as Pt,
    b$ as jt,
    at as ie,
    c0 as Wt,
    c1 as Et,
    c2 as $t,
    c3 as Gt,
    c4 as Rt
} from "./index.28e31dff.js";
import {
    G as Ht
} from "./GameGridList.b3c3af9c.js";

function Dt(e, t) {
    for (var a, o = -1, s = e.length; ++o < s;) {
        var i = t(e[o]);
        i !== void 0 && (a = a === void 0 ? i : a + i)
    }
    return a
}

function Ft(e) {
    return e && e.length ? Dt(e, ut) : 0
}

function Ot({
    swiper: e,
    extendParams: t,
    on: a
}) {
    t({
        virtual: {
            enabled: !1,
            slides: [],
            cache: !0,
            renderSlide: null,
            renderExternal: null,
            renderExternalUpdate: !0,
            addSlidesBefore: 0,
            addSlidesAfter: 0
        }
    });
    let o;
    e.virtual = {
        cache: {},
        from: void 0,
        to: void 0,
        slides: [],
        offset: 0,
        slidesGrid: []
    };

    function s(c, h) {
        const f = e.params.virtual;
        if (f.cache && e.virtual.cache[h]) return e.virtual.cache[h];
        const w = f.renderSlide ? Me(f.renderSlide.call(e, c, h)) : Me(`<div class="${e.params.slideClass}" data-swiper-slide-index="${h}">${c}</div>`);
        return w.attr("data-swiper-slide-index") || w.attr("data-swiper-slide-index", h), f.cache && (e.virtual.cache[h] = w), w
    }

    function i(c) {
        const {
            slidesPerView: h,
            slidesPerGroup: f,
            centeredSlides: w
        } = e.params, {
            addSlidesBefore: S,
            addSlidesAfter: P
        } = e.params.virtual, {
            from: $,
            to: _,
            slides: C,
            slidesGrid: it,
            offset: rt
        } = e.virtual;
        e.params.cssMode || e.updateActiveIndex();
        const xe = e.activeIndex || 0;
        let J;
        e.rtlTranslate ? J = "right" : J = e.isHorizontal() ? "left" : "top";
        let re, le;
        w ? (re = Math.floor(h / 2) + f + P, le = Math.floor(h / 2) + f + S) : (re = h + (f - 1) + P, le = f + S);
        const j = Math.max((xe || 0) - le, 0),
            G = Math.min((xe || 0) + re, C.length - 1),
            O = (e.slidesGrid[j] || 0) - (e.slidesGrid[0] || 0);
        Object.assign(e.virtual, {
            from: j,
            to: G,
            offset: O,
            slidesGrid: e.slidesGrid
        });

        function Te() {
            e.updateSlides(), e.updateProgress(), e.updateSlidesClasses(), e.lazy && e.params.lazy.enabled && e.lazy.load()
        }
        if ($ === j && _ === G && !c) {
            e.slidesGrid !== it && O !== rt && e.slides.css(J, `${O}px`), e.updateProgress();
            return
        }
        if (e.params.virtual.renderExternal) {
            e.params.virtual.renderExternal.call(e, {
                offset: O,
                from: j,
                to: G,
                slides: function() {
                    const Q = [];
                    for (let he = j; he <= G; he += 1) Q.push(C[he]);
                    return Q
                }()
            }), e.params.virtual.renderExternalUpdate && Te();
            return
        }
        const Le = [],
            ce = [];
        if (c) e.$wrapperEl.find(`.${e.params.slideClass}`).remove();
        else
            for (let y = $; y <= _; y += 1)(y < j || y > G) && e.$wrapperEl.find(`.${e.params.slideClass}[data-swiper-slide-index="${y}"]`).remove();
        for (let y = 0; y < C.length; y += 1) y >= j && y <= G && (typeof _ > "u" || c ? ce.push(y) : (y > _ && ce.push(y), y < $ && Le.push(y)));
        ce.forEach(y => {
            e.$wrapperEl.append(s(C[y], y))
        }), Le.sort((y, Q) => Q - y).forEach(y => {
            e.$wrapperEl.prepend(s(C[y], y))
        }), e.$wrapperEl.children(".swiper-slide").css(J, `${O}px`), Te()
    }

    function r(c) {
        if (typeof c == "object" && "length" in c)
            for (let h = 0; h < c.length; h += 1) c[h] && e.virtual.slides.push(c[h]);
        else e.virtual.slides.push(c);
        i(!0)
    }

    function u(c) {
        const h = e.activeIndex;
        let f = h + 1,
            w = 1;
        if (Array.isArray(c)) {
            for (let S = 0; S < c.length; S += 1) c[S] && e.virtual.slides.unshift(c[S]);
            f = h + c.length, w = c.length
        } else e.virtual.slides.unshift(c);
        if (e.params.virtual.cache) {
            const S = e.virtual.cache,
                P = {};
            Object.keys(S).forEach($ => {
                const _ = S[$],
                    C = _.attr("data-swiper-slide-index");
                C && _.attr("data-swiper-slide-index", parseInt(C, 10) + w), P[parseInt($, 10) + w] = _
            }), e.virtual.cache = P
        }
        i(!0), e.slideTo(f, 0)
    }

    function p(c) {
        if (typeof c > "u" || c === null) return;
        let h = e.activeIndex;
        if (Array.isArray(c))
            for (let f = c.length - 1; f >= 0; f -= 1) e.virtual.slides.splice(c[f], 1), e.params.virtual.cache && delete e.virtual.cache[c[f]], c[f] < h && (h -= 1), h = Math.max(h, 0);
        else e.virtual.slides.splice(c, 1), e.params.virtual.cache && delete e.virtual.cache[c], c < h && (h -= 1), h = Math.max(h, 0);
        i(!0), e.slideTo(h, 0)
    }

    function m() {
        e.virtual.slides = [], e.params.virtual.cache && (e.virtual.cache = {}), i(!0), e.slideTo(0, 0)
    }
    a("beforeInit", () => {
        !e.params.virtual.enabled || (e.virtual.slides = e.params.virtual.slides, e.classNames.push(`${e.params.containerModifierClass}virtual`), e.params.watchSlidesProgress = !0, e.originalParams.watchSlidesProgress = !0, e.params.initialSlide || i())
    }), a("setTranslate", () => {
        !e.params.virtual.enabled || (e.params.cssMode && !e._immediateVirtual ? (clearTimeout(o), o = setTimeout(() => {
            i()
        }, 100)) : i())
    }), a("init update resize", () => {
        !e.params.virtual.enabled || e.params.cssMode && dt(e.wrapperEl, "--swiper-virtual-size", `${e.virtualSize}px`)
    }), Object.assign(e.virtual, {
        appendSlide: r,
        prependSlide: u,
        removeSlide: p,
        removeAllSlides: m,
        update: i
    })
}
const Qe = g.memo(function() {
        return n("div", {
            className: zt,
            children: n("div", {
                className: "inner",
                children: "New"
            })
        })
    }),
    zt = "s1soke7x";
var qt = "/assets/lottery.cb45faf6.png";

function Pe(e) {
    return e > 9 ? e : "0" + e
}

function Vt() {
    const [e, t] = d.exports.useState(0);
    return l(ye, {
        to: "/lottery",
        style: {
            flex: 1
        },
        className: Ze,
        onClick: () => {
            N.emit("game_click", "game_homeBanner")
        },
        children: [n(pt, {
            endTime: e,
            onEnd: () => {
                const o = mt.getServerTime(),
                    s = o.getUTCFullYear(),
                    i = o.getUTCMonth(),
                    r = o.getUTCHours();
                let u = o.getUTCDate();
                r >= 15 && (u += 1), t(Date.UTC(s, i, u, 14, 50))
            },
            children: ({
                hours: o,
                minutes: s
            }) => l("div", {
                className: "cut-time",
                children: [l("span", {
                    children: [Pe(o), "H "]
                }), " : ", l("span", {
                    children: [Pe(s), "M "]
                })]
            })
        }), n(Qe, {}), n("img", {
            src: qt,
            alt: "banner.png",
            draggable: !1
        })]
    })
}
const Xe = M(({
    item: e,
    isMobile: t
}) => {
    if (e.lottery) return n(Vt, {});
    const a = k.isDarken;
    let o = a ? e.bannerUrl : e.whiteBannerUrl;
    t && (o = a ? e.mobileBannerUrl : e.whiteMobileBannerUrl);
    const s = e.linkUrl.indexOf("http") >= 0,
        i = t ? 1 : e.gridNum;
    return n(ye, {
        className: b(Ze, !e.bannerUrl && "empty", i === 2 && "half"),
        to: s ? "" : e.linkUrl,
        style: {
            flex: t ? 1 : e.gridNum
        },
        onClick: () => {
            N.emit("game_click", "game_homeBanner"), s && window.open(e.linkUrl, "_blank")
        },
        children: e.bannerUrl && l(F, {
            children: [e.flagNew && n(Qe, {}), n(ge, {
                src: o,
                alt: "banner.png",
                draggable: !1
            })]
        })
    })
});

function ue(e, t) {
    e && (pe.set(e, {
        opacity: t ? 1 : .3
    }), pe.to(e, {
        duration: 1,
        opacity: t ? .3 : 1
    }))
}
const It = ({
        flist: e
    }) => {
        const t = be();
        return e.length === 0 ? n("div", {
            className: fe
        }) : l(oe, {
            className: Ke,
            autoplay: !1,
            loop: !0,
            speed: 1e3,
            threshold: 6,
            loopedSlides: 5,
            slidesPerView: "auto",
            navigation: {
                prevEl: ".navigation-prev-banner",
                nextEl: ".navigation-next-banner"
            },
            pagination: {
                el: ".swiper-pagination"
            },
            onInit: a => {
                setTimeout(() => {
                    t() && (a.params.autoplay = {
                        delay: 5e3,
                        disableOnInteraction: !1,
                        pauseOnMouseEnter: !0
                    }, a.autoplay.start())
                }, 5e3)
            },
            onTransitionStart: a => {
                const o = a.slides,
                    s = a.activeIndex,
                    i = o[s + 1],
                    r = o[s - 1],
                    u = o[s];
                i && ue(i.lastChild, !0), r && ue(r.lastChild, !0), u && ue(u.lastChild)
            },
            children: [e.map((a, o) => n(B, {
                children: n("div", {
                    className: me,
                    children: n(Xe, {
                        item: a,
                        isMobile: !0
                    })
                })
            }, o)), n("div", {
                className: b(Yt, "swiper-pagination")
            })]
        })
    },
    Yt = "p1puwuv8",
    Jt = ({
        flist: e,
        size: t
    }) => {
        const a = new Array(t - 2).fill(null),
            o = a.map((s, i) => n("div", {
                className: b(fe, "suffix")
            }, i));
        return n(oe, {
            className: Ke,
            autoplay: {
                delay: 8e6,
                disableOnInteraction: !1,
                pauseOnMouseEnter: !0
            },
            loop: !0,
            speed: 1e3,
            threshold: 6,
            slidesPerView: "auto",
            loopedSlides: 2,
            navigation: {
                prevEl: ".navigation-prev-banner",
                nextEl: ".navigation-next-banner"
            },
            children: e.length === 0 ? a.map((s, i) => n(B, {
                children: l("div", {
                    className: me,
                    children: [n("div", {
                        className: b(fe, "suffix", "half"),
                        style: {
                            flex: 2
                        }
                    }), o]
                })
            }, i)) : e.map((s, i) => n(B, {
                children: n("div", {
                    className: me,
                    children: s.map((r, u) => n(Xe, {
                        item: r
                    }, u))
                })
            }, i))
        })
    },
    me = "s1sgoeti",
    Ke = "swhgpqh";
E({
    cl1: ["#31343c", L("#e9eaf2", .6)]
});
const Ze = "l1e6f379";
E({
    cl1: ["#31343c", L("#e9eaf2", .6)]
});
const fe = "l1x6x56h";

function et(e) {
    return e.whiteMobileBannerUrl = e.whiteMobileBannerUrl ? e.whiteMobileBannerUrl : e.mobileBannerUrl, e.bannerUrl = e.bannerUrl ? e.bannerUrl : e.mobileBannerUrl, e.whiteBannerUrl = e.whiteBannerUrl ? e.whiteBannerUrl : e.bannerUrl, e
}

function Qt(e, t) {
    e = e.map(et);
    const a = [];
    let o = 0;
    return e.forEach(s => {
        let i = a[Math.floor(o / t)];
        const r = Object.assign({}, s);
        if (i ? Ft(i.map(p => p.gridNum)) + s.gridNum > t && (r.gridNum = 1, r.bannerUrl = r.mobileBannerUrl, r.whiteBannerUrl = r.whiteMobileBannerUrl) : (i = [], a.push(i)), i.push(r), o += r.gridNum, s === e[e.length - 1] && o % t != 0) {
            const u = t - o % t,
                p = a[a.length - 1],
                m = e.filter(c => c.gridNum !== 2 && !c.lottery);
            for (let c = 0; c < u; c++) {
                const h = Object.assign({}, s, m[c]);
                p.push(Object.assign(h))
            }
        }
    }), a
}

function z(e) {
    return e + 32
}
const Xt = [{
    width: z(1800),
    num: 6
}, {
    width: z(1480),
    num: 5
}, {
    width: z(984),
    num: 4
}, {
    width: z(808),
    num: 3
}, {
    width: z(680),
    num: 2
}];

function Kt(e) {
    const [t, a] = d.exports.useState(k.isMobile ? 2 : 4), [o, s] = d.exports.useState(!1), i = se(u => {
        const p = Xt.find(m => u.width >= m.width);
        a(p ? p.num : 2), s(p ? p.num >= 6 : !1)
    }, 300);
    return {
        flist: Qt(e, t),
        ref: i,
        size: t,
        showSide: o
    }
}
const Zt = ({
    list: e
}) => {
    let t = [...e];
    const {
        flist: a,
        ref: o,
        size: s,
        showSide: i
    } = Kt(t), r = s < 3;
    return n("div", {
        ref: o,
        id: "home-banner",
        className: b(tn, i ? "show-side " : "banner", r && "gradient-mobile"),
        children: l("div", {
            className: "gradient-wrap",
            children: [r ? n(It, {
                flist: t.map(et)
            }) : n(Jt, {
                flist: a,
                size: s
            }), !k.isMobile && n(q, {
                name: "banner"
            })]
        })
    })
};
var en = M(Zt);
const tn = "so4edg";

function tt({
    cont: e,
    isGreen: t
}) {
    return n("div", {
        className: b(nn, "nav-tit"),
        children: n("div", {
            className: `cont-txt ${t?"green":""}`,
            dangerouslySetInnerHTML: {
                __html: e
            }
        })
    })
}
const nn = "sbfp6o6";
const an = 5;

function on(e, t, a) {
    return a && (e ? t.isBcoriginal && !t.isHome && a[1] ? (a[1].iconWide = "", a) : a.filter((o, s) => s <= an && s != 1) : t.isBcoriginal && !t.isHome ? [...a].map(o => Z(K({}, o), {
        iconWide: ""
    })) : a)
}
const sn = ft((e, t, a) => H.get("/home/game/tags/", {
    cache: !0,
    params: {
        page: 1,
        pageSzie: 30,
        device: t,
        tagName: e,
        areaCode: a
    }
}), e => e);
async function rn(e, t) {
    return await N.inited, sn(e, t, N.areaCode)
}
const ln = function({
        tab: t,
        tabView: a,
        list: o
    }) {
        const s = V(),
            i = x(),
            [r, u] = ve({
                list: o,
                hasPage: !1
            });
        d.exports.useEffect(() => {
            t.isBcoriginal || (u({
                list: void 0
            }), rn(t.value, k.isMobile ? 1 : 2).then(c => {
                u({
                    list: c.list,
                    hasPage: c.totalPage > 1
                })
            }).catch(yt))
        }, [t]);
        const p = t.isBcoriginal ? o : r.list,
            m = d.exports.useCallback(c => {
                let h = "";
                switch (c) {
                    case "Lobby":
                        h = i("page.home.tit.lobby");
                        break;
                    case "Original":
                        h = i("page.home.tit.lobby");
                        break;
                    case "Slots":
                        h = i("page.home.tit.slots");
                        break;
                    case "Live Casino":
                        h = i("page.home.tit.livecasion");
                        break;
                    case "Game Show":
                        h = i("page.home.tit.gameshow");
                        break;
                    case "Table Game":
                        h = i("page.home.tit.tablegame");
                        break;
                    default:
                        h = i("page.home.tit");
                        break
                }
                return h
            }, []);
        return l(F, {
            children: [n(Ht, {
                clickSource: "game_home",
                list: on(k.isMobile, t, p),
                isSupper: !0,
                isMakeup: !0,
                className: cn,
                isSlots: !t.isBcoriginal,
                loadingSize: k.isMobile ? 5 : 30,
                header: l("div", {
                    className: un,
                    children: [n(tt, {
                        cont: m(t.value)
                    }), a]
                })
            }), !t.isBcoriginal && n(we, {
                className: hn,
                onClick: () => {
                    s(t.href || `/tagname/${t.value}`)
                },
                children: i("common.view_all_game")
            })]
        })
    },
    cn = "sg4ndp5";
E({
    cl1: ["#31343a", L("#6b7180", .6)],
    cl2: [L("#99a4b0", .6), "#f5f6f7"]
});
const hn = "b1fwr9t9",
    un = "h3fk5zq",
    dn = ({
        ritem: e,
        rindex: t,
        className: a,
        word: o,
        isTop: s = !1
    }) => {
        const i = x();
        return l("div", {
            className: b("rich-item", a),
            children: [l("div", {
                className: "user-number",
                children: [n("img", {
                    src: t === 0 ? ne.gold : t === 1 ? ne.silver : ne.copper,
                    className: "winner-trophy"
                }), n(Fe, {
                    className: "rich-user",
                    userId: e.userId,
                    name: e.userName
                })]
            }), o && n("div", {
                className: "top-winner",
                children: i("common.top_winner")
            }), n(pn, {
                amount: e.upAmount
            })]
        })
    },
    pn = M(function({
        amount: t
    }) {
        return n("div", {
            className: "rich-amount cl-primary",
            children: ke.toLocaleCurrency(Number(t), "USD")
        })
    });
class mn {
    constructor() {
        this.list = [null, null, null], this.inited = !1, this.activeChat = !1, this.activeHome = !1, this.timejb = -1, gt(this, {
            list: ee,
            inited: ee,
            activeChat: ee,
            activeHome: ee
        })
    }
    async active() {
        this.inited || (await this.getData(), this.inited = !0, this.setTime())
    }
    disactive() {
        clearTimeout(this.timejb), this.inited = !1
    }
    setTime() {
        if (!this.inited) return !1;
        clearTimeout(this.timejb), this.timejb = window.setTimeout(() => {
            this.getData()
        }, 6e4)
    }
    async getData() {
        let t = await H.post("/game/support/rich-list/get/");
        this.formateList(t), this.setTime()
    }
    formateList(t) {
        this.list = t.map(a => {
            let o = a.cpAmount.map(i => {
                let r = i.amount >= 1e6 ? Math.round(i.amount) : Number(i.amount).toFixed(8).substr(0, 8);
                return {
                    value: i.currencyName,
                    label: r
                }
            });
            return {
                userId: a.userId,
                userName: a.userName,
                avatar: a.avatar,
                level: a.level,
                likeNumber: a.likeNumber,
                upAmount: a.upAmount,
                showProfit: a.showProfit,
                cpAmount: o
            }
        })
    }
}
var W = new mn;
const fn = M(({
        className: e,
        id: t
    }) => {
        d.exports.useEffect(() => (W.active(), W.activeHome = !0, () => {
            W.activeHome = !1, W.activeChat || W.disactive()
        }), [W.activeChat]);
        const a = x(),
            o = W.list;
        return l("div", {
            className: b(yn, e),
            id: t,
            children: [o.length > 0 && n("img", {
                className: "winner-img",
                src: ne.topwin,
                alt: ""
            }), o.length === 0 ? n(bt, {}) : o.map((s, i) => s ? n(dn, {
                className: gn,
                ritem: s,
                rindex: i,
                word: !0
            }, i) : n("div", {
                children: a("common.loading")
            }, i))]
        })
    }),
    yn = "w1fyj1m1";
E({
    cl1: [L("#31343c", .6), "#f6f7fa"],
    cl2: ["transparent", "#ffffff"],
    cl3: ["#1e2024", "#f5f6fa"],
    cl4: ["#17181b", "#edf0f2"]
});
const gn = "iatream";
const bn = () => {
        const e = V(),
            t = x();
        return l("div", {
            id: "home-bigwin",
            children: [n("div", {
                className: vn,
                children: t("page.home.bigwin.title").toLocaleUpperCase()
            }), l("div", {
                className: wn,
                children: [l("div", {
                    className: kn,
                    children: [l("div", {
                        className: "info",
                        children: [n("div", {
                            className: "tit",
                            dangerouslySetInnerHTML: {
                                __html: t("page.home.bigwin.banner")
                            }
                        }), n(we, {
                            type: "conic4",
                            onClick: () => e("/crash"),
                            children: t("common.playnow")
                        })]
                    }), n("img", {
                        className: "bg",
                        alt: "bg",
                        src: vt.biggest
                    })]
                }), n(fn, {
                    className: Nn
                })]
            })]
        })
    },
    vn = "t16i4rcv",
    wn = "cz87rgg",
    kn = "b12iqbol";
E({
    cl1: ["#24262b", "#fff"],
    cl2: ["#fafaf9", "#31373d"],
    cl3: ["#fafaf9", "#31373d"],
    cl4: ["#24262b", "#edf0f2"],
    cl5: [L("#99a4b0", .7), "#31373d"]
});
const Nn = "w1eqql6r";
let je = 0;
const Sn = Oe.socket("/home"),
    xn = () => {
        const e = x(),
            t = be(),
            a = kt(),
            o = d.exports.useRef([]),
            [s, i] = d.exports.useState(!1),
            [r, u] = d.exports.useState(k.isMobile ? 0 : 1),
            p = se(c => {
                c.width <= qe ? u(0) : c.width <= 1e3 ? u(1) : u(2)
            }, 300),
            m = d.exports.useMemo(() => Nt(Oe.decodeBind(c => {
                !t() || (o.current.unshift(Object.assign(c, {
                    key: je
                })), o.current.length > 50 && o.current.pop(), je++, a())
            }, "json"), 600), []);
        return St(Sn, "home-game-throw", m), n(xt, {
            children: n("div", {
                className: Ln,
                ref: p,
                children: o.current.length === 0 ? n("div", {
                    className: "flex-center",
                    style: {
                        height: "100%"
                    },
                    children: n(Tt, {
                        className: "full-abs"
                    })
                }) : l(F, {
                    children: [l(Lt, {
                        children: [n("thead", {
                            children: l("tr", {
                                children: [n("th", {
                                    children: e("common.game")
                                }), n("th", {
                                    children: e("common.player")
                                }), r >= 1 && n("th", {
                                    children: e("common.betamount")
                                }), r > 1 && n("th", {
                                    children: e("common.time")
                                }), n("th", {
                                    children: e("common.multiplier")
                                }), n("th", {
                                    className: "m-width",
                                    children: e("common.profitamount")
                                })]
                            })
                        }), n("tbody", {
                            children: o.current.slice(0, s ? 50 : 10).map(c => n(Tn, {
                                data: c,
                                size: r
                            }, c.key))
                        })]
                    }), o.current.length > 10 && l("div", {
                        className: "more",
                        onClick: () => {
                            i(!s)
                        },
                        children: [e(s ? "common.show_less" : "common.show_more"), " ", n(ae, {
                            name: "Arrow",
                            style: {
                                transform: `rotate(${s?"-90deg":"90deg"})`
                            }
                        })]
                    })]
                })
            })
        })
    },
    Tn = g.memo(({
        data: e,
        size: t
    }) => {
        const {
            gameList: a
        } = ze();

        function o() {
            let s = 3;
            a.find(i => i.gameName === e.gameName) && (s = 0), N.emit("opengamedetail", {
                gameName: e.gameName,
                betId: e.betId,
                userName: e.userName,
                userId: e.userId,
                gameId: e.gameId,
                gameType: s
            })
        }
        return l("tr", {
            onClick: o,
            children: [l("td", {
                className: "game-name",
                children: [n("img", {
                    src: wt(e.gameName),
                    className: "game-icon",
                    alt: ""
                }), n("div", {
                    className: "name",
                    children: e.fullName || e.gameName
                })]
            }), n("td", {
                onClick: s => {
                    s.stopPropagation()
                },
                children: n(Fe, {
                    userId: e.userId,
                    name: e.userName,
                    avatar: !1
                })
            }), t >= 1 && n("td", {
                children: n(Ue, {
                    icon: !0,
                    name: e.currencyName,
                    amount: Number(e.throwAmount)
                })
            }), t > 1 && n("td", {
                children: new Date(e.createTime).toLocaleTimeString()
            }), l("td", {
                children: [Number(e.payout / 100).toFixed(2), "x"]
            }), n("td", {
                className: Number(e.payout / 100) < 1 ? "lose" : "win",
                children: n(Ue, {
                    icon: !0,
                    sign: !0,
                    name: e.currencyName,
                    amount: Number(e.profitAmount)
                })
            })]
        }, e.key)
    }),
    Ln = "slbw8j7";
const _n = () => {
        const e = x(),
            [t, a] = d.exports.useState(0),
            [o] = d.exports.useState(() => [{
                label: e("common.last_bets"),
                value: xn
            }, {
                label: e("common.highrolls"),
                value: _t
            }, {
                label: e("page.contest.title"),
                value: Ct
            }]);
        return n("div", {
            className: Cn,
            children: n(Ve, {
                className: Bn,
                value: t,
                tabs: o,
                onChange: a
            })
        })
    },
    Cn = "cnv46lc",
    Bn = "tzvcgwg",
    U = g.createContext({
        bigProfits: [],
        bigWins: [],
        hots: [],
        news: [],
        isLoading: !0
    });

function te(e, t) {
    if (!e || e.length === 0) return [];
    let a = [];
    for (; a.length < t;) a = a.concat(e);
    return a.length > t ? a.splice(0, t) : a
}

function An(e) {
    return e[0].categoryName || ""
}

function We(e) {
    const t = [];
    return e.map(a => (t.push(Z(K({}, a), {
        categoryName: An(a.categories)
    })), a)), t
}

function Mn(e) {
    const t = [];
    for (let a in e) {
        const o = {
            gameFullName: e[a].fullName,
            gameIcon: e[a].thumbnail,
            providerName: e[a].providerName,
            rtp: e[a].rtpDes * 1e4,
            categoryName: e[a].categoryName,
            gameUrl: e[a].gameUrl
        };
        t.push(o)
    }
    return t
}
const R = [660, 808, 980, 1160, 1288, 1440, 1590, 1800],
    Un = [190, 190, 190, 208, 208, 208, 208, 208];

function Pn(e) {
    const t = R.findIndex(a => e < a);
    if (t < 0) return R.length - 1;
    if (t === 0) return 0; {
        const a = (R[t] + R[t - 1]) / 2;
        return e < a ? t - 1 : t
    }
}
const v = M(function({
        loading: t,
        type: a,
        className: o = "",
        children: s
    }) {
        const i = jn(a, N.login);
        return l("div", {
            className: b(Wn, o, t && "loading-wrap"),
            children: [l("div", {
                className: "top",
                children: [n("div", {
                    className: "circle",
                    children: !t && n(Ie, {
                        alt: "logo",
                        name: i.icon
                    })
                }), n("div", {
                    className: "word",
                    children: t ? n("p", {}) : l("p", {
                        children: [i.spTitle && n("span", {
                            style: {
                                color: i.color
                            },
                            children: i.spTitle
                        }), i.title]
                    })
                })]
            }), s]
        })
    }),
    jn = (e, t) => {
        const a = x();
        let o;
        switch (e) {
            case "bigwin":
                {
                    o = {
                        icon: "bigprofit",
                        color: "#e70b6c",
                        spTitle: a("common.much"),
                        title: a("page.home.wowwin")
                    };
                    break
                }
            case "bigprofit":
                {
                    o = {
                        icon: "topprofit",
                        color: "#f5c01f",
                        spTitle: "Top",
                        title: a("page.home.winning_games")
                    };
                    break
                }
            case "toppopular":
                {
                    o = {
                        icon: "popular",
                        color: "#5ddb1c",
                        spTitle: a("common.trending"),
                        title: a("page.home.right_now")
                    };
                    break
                }
            case "recentplay":
                {
                    o = {
                        icon: "recent",
                        color: "#5ddb1c",
                        spTitle: "",
                        title: t ? a("page.home.recently_played") : "Recently Added"
                    };
                    break
                }
            default:
                o = {
                    icon: "bigprofit",
                    color: "#f5c01f",
                    spTitle: a("common.much"),
                    title: a("page.home.wowwin")
                }
        }
        return o
    },
    Wn = "skqd617",
    nt = g.memo(function({
        index: t,
        children: a
    }) {
        const o = d.exports.useRef(a),
            s = d.exports.useRef(!0),
            i = En(t);
        return s.current && (o.current = a), i && (o.current = a, s.current = !1), o.current
    });

function En(e) {
    const t = d.exports.useContext(at);
    return t.index === e && !t.isAnim
}
const at = g.createContext({
        index: 0,
        changeIndex(e) {},
        isAnim: !1,
        changeIsAnim(e) {}
    }),
    Y = g.memo(function(o) {
        var s = o,
            {
                children: e,
                delay: t = 5e3
            } = s,
            a = Ae(s, ["children", "delay"]);
        const i = be(),
            [r, u] = d.exports.useState(1),
            [p, m] = d.exports.useState(!1);
        return n(at.Provider, {
            value: {
                index: r,
                changeIndex: u,
                isAnim: p,
                changeIsAnim: m
            },
            children: n(oe, Z(K({
                autoplay: !1,
                loop: !0,
                onInit: c => {
                    setTimeout(() => {
                        i() && (c.params.autoplay = {
                            delay: t,
                            disableOnInteraction: !1,
                            pauseOnMouseEnter: !0
                        }, c.autoplay.start())
                    }, 5e3)
                },
                threshold: 6,
                spaceBetween: 12,
                loopPreventsSlide: !1,
                speed: 1e3,
                onRealIndexChange: c => u(c.activeIndex),
                onAnimationStart: () => m(!0),
                onAnimationEnd: () => m(!1),
                effect: "fade"
            }, a), {
                children: e
            }))
        })
    });
const Ne = g.memo(function({
        gameUrl: t = "",
        gameIcon: a = ""
    }) {
        const o = V(),
            s = a.indexOf("http") >= 0,
            i = a ? s ? a : `http://img2.supersell.com${a}` : "";
        return n(ge, {
            src: i,
            className: b($n, "left"),
            onClick: () => {
                o(t), N.emit("game_click", "game_ranking")
            }
        })
    }),
    $n = "s1hg7yh3";
const ot = g.memo(function({
        gameItem: t
    }) {
        const a = V(),
            o = !t,
            s = (t == null ? void 0 : t.playerName) === "****";
        return l("div", {
            className: b(Gn, "win-game-item", o && "loading"),
            children: [n(Ne, {
                gameUrl: t == null ? void 0 : t.gameUrl,
                gameIcon: t == null ? void 0 : t.gameIcon
            }), l("div", {
                className: "right",
                children: [n("div", {
                    className: "right-word-wrap",
                    children: n("p", {
                        className: b("sp", s && "hidden"),
                        onClick: () => {
                            s || a(`/user/profile/${t==null?void 0:t.userId}`)
                        },
                        children: s ? "Hidden" : (t == null ? void 0 : t.playerName) || ""
                    })
                }), n("div", {
                    className: "right-word-wrap big-word",
                    children: (t == null ? void 0 : t.winAmountUsd) || (t == null ? void 0 : t.winAmountUsd) == 0 ? l("p", {
                        title: `Won: ${ke.toLocaleCurrency(t.winAmountUsd,"USD")}`,
                        children: ["Won:", n("span", {
                            children: n(Ye, {
                                amount: t.winAmountUsd
                            })
                        })]
                    }) : n("p", {})
                }), n("div", {
                    className: "right-word-wrap",
                    children: t != null && t.gameFullName ? l("p", {
                        children: ["In ", (t == null ? void 0 : t.gameFullName) || ""]
                    }) : n("p", {})
                })]
            })]
        })
    }),
    Gn = "s1hwi5zy";
const st = g.memo(function({
        gameItem: t
    }) {
        return l("div", {
            className: b(Rn, "win-game-item", !t && "loading"),
            children: [n(Ne, {
                gameUrl: t == null ? void 0 : t.gameUrl,
                gameIcon: t == null ? void 0 : t.gameIcon
            }), l("div", {
                className: "right",
                children: [n("div", {
                    className: "right-word-wrap big-word",
                    children: t != null && t.winAmountUsd ? l("p", {
                        title: `Profit: ${ke.toLocaleCurrency(t.winAmountUsd,"USD")}`,
                        children: ["Profit:", n("span", {
                            children: n(Ye, {
                                amount: t.winAmountUsd
                            })
                        })]
                    }) : n("p", {})
                }), n("div", {
                    className: "right-word-wrap",
                    children: t != null && t.gameFullName ? l("p", {
                        children: ["In ", (t == null ? void 0 : t.gameFullName) || ""]
                    }) : n("p", {})
                })]
            })]
        })
    }),
    Rn = "s1a9maji";
const A = g.memo(function({
        list: t,
        type: a
    }) {
        const o = t.length > 0 ? t : Array(6).fill(-1),
            s = a === "bigwin" ? ot : st;
        return n(Y, {
            modules: [Ot],
            direction: "vertical",
            delay: a === "bigwin" ? 7500 : 10500,
            children: I(o, 2).map((i, r) => n(B, {
                children: n(nt, {
                    index: r + 1,
                    children: l("div", {
                        className: Hn,
                        children: [n("div", {
                            className: "item-wrap",
                            children: n(s, {
                                gameItem: i[0] === -1 ? null : i[0]
                            })
                        }), n("div", {
                            className: "item-wrap",
                            children: n(s, {
                                gameItem: i[1] === -1 ? null : i[1]
                            })
                        })]
                    })
                })
            }, r))
        })
    }),
    Hn = "sggk3qd";
const T = g.memo(function({
        isBig: t,
        gameItem: a
    }) {
        return l("div", {
            className: b(Dn, "win-game-item", t && "big", !a && "loading"),
            children: [n(Ne, {
                gameUrl: a == null ? void 0 : a.gameUrl,
                gameIcon: a == null ? void 0 : a.gameIcon
            }), l("div", {
                className: "right",
                children: [n("div", {
                    className: "right-word-wrap one-p",
                    children: n("p", {
                        children: (a == null ? void 0 : a.gameFullName) || ""
                    })
                }), n("div", {
                    className: "right-word-wrap two-p",
                    children: a != null && a.rtp ? t ? l("p", {
                        children: ["RTP:", l("span", {
                            children: [a.rtp / 1e4, "%"]
                        })]
                    }) : n("p", {
                        className: "pn",
                        children: a.providerName
                    }) : n("p", {})
                }), t && l(F, {
                    children: [n("div", {
                        className: "right-word-wrap three-p",
                        children: n("p", {
                            children: (a == null ? void 0 : a.categoryName) || ""
                        })
                    }), n("div", {
                        className: "right-word-wrap four-p",
                        children: n("p", {
                            children: (a == null ? void 0 : a.providerName) || ""
                        })
                    })]
                })]
            })]
        })
    }),
    Dn = "sr0y2hg";
const D = g.memo(function({
        list: t,
        isBig: a,
        name: o
    }) {
        const s = a ? 2 : 3,
            i = t.length > 0 ? t : Array(6).fill(-1),
            r = I(i, s);
        return a && r.pop(), l("div", {
            className: Fn,
            children: [n(Y, {
                className: On,
                navigation: {
                    prevEl: ".navigation-prev-" + o,
                    nextEl: ".navigation-next-" + o
                },
                delay: o === "one" ? 13500 : 19500,
                children: r.map((u, p) => n(B, {
                    children: n(nt, {
                        index: p + 1,
                        children: l("div", {
                            className: "good-games-wrap",
                            children: [n("div", {
                                className: "item-wrap",
                                children: n(T, {
                                    isBig: a,
                                    gameItem: u[0] === -1 ? null : u[0]
                                })
                            }), n("div", {
                                className: "item-wrap",
                                children: n(T, {
                                    isBig: a,
                                    gameItem: u[1] === -1 ? null : u[1]
                                })
                            }), !a && n("div", {
                                className: "item-wrap",
                                children: n(T, {
                                    isBig: a,
                                    gameItem: u[2] === -1 ? null : u[2]
                                })
                            })]
                        })
                    })
                }, p))
            }), n(q, {
                name: o
            })]
        })
    }),
    Fn = "syl7ash",
    On = "s1t86i88";
const zn = g.memo(function() {
        const {
            bigProfits: t,
            bigWins: a,
            hots: o,
            news: s,
            isLoading: i
        } = d.exports.useContext(U);
        return l("div", {
            className: qn,
            children: [n(v, {
                className: "list-one",
                type: "bigwin",
                loading: i,
                children: n(A, {
                    type: "bigwin",
                    list: a
                })
            }), n(v, {
                className: "list-two",
                type: "bigprofit",
                loading: i,
                children: n(A, {
                    type: "bigprofit",
                    list: t
                })
            }), n(v, {
                className: "list-three",
                type: "toppopular",
                loading: i,
                children: n(D, {
                    list: o,
                    isBig: !1,
                    name: "one"
                })
            }), n(v, {
                className: "list-four",
                loading: i,
                type: "recentplay",
                children: n(D, {
                    list: s,
                    isBig: !1,
                    name: "two"
                })
            })]
        })
    }),
    qn = "slaee4z";
const Vn = g.memo(function({
        size: t,
        type: a,
        children: o
    }) {
        const s = R[a],
            i = t / s;
        return n(Bt.div, {
            className: In,
            style: {
                width: s,
                transform: `scale(${i})`
            },
            children: o
        })
    }),
    In = "v1xlu23m";
const Ee = g.memo(function({
        big: t = !1
    }) {
        const {
            bigProfits: a,
            bigWins: o,
            hots: s,
            news: i,
            isLoading: r
        } = d.exports.useContext(U);
        return l("div", {
            className: b(Yn, t && "big-large"),
            children: [n(v, {
                className: "list-one",
                type: "bigwin",
                loading: r,
                children: n(A, {
                    type: "bigwin",
                    list: o
                })
            }), n(v, {
                className: "list-two",
                type: "bigprofit",
                loading: r,
                children: n(A, {
                    type: "bigprofit",
                    list: a
                })
            }), n(v, {
                className: "list-three",
                type: "toppopular",
                loading: r,
                children: n(D, {
                    list: s,
                    isBig: !1,
                    name: "one"
                })
            }), n(v, {
                className: "list-four",
                loading: r,
                type: "recentplay",
                children: n(D, {
                    list: i,
                    isBig: !1,
                    name: "two"
                })
            })]
        })
    }),
    Yn = "sybic1c";
const $e = g.memo(function({
        big: t = !0
    }) {
        const {
            bigProfits: a,
            bigWins: o,
            hots: s,
            news: i,
            isLoading: r
        } = d.exports.useContext(U);
        return l("div", {
            className: b(Jn, t ? "" : "superbig-small"),
            children: [l("div", {
                className: "left-wrap",
                children: [n(v, {
                    className: "list-one",
                    type: "bigwin",
                    loading: r,
                    children: n(A, {
                        type: "bigwin",
                        list: o
                    })
                }), n(v, {
                    className: "list-two",
                    type: "bigprofit",
                    loading: r,
                    children: n(A, {
                        type: "bigprofit",
                        list: a
                    })
                })]
            }), n(v, {
                className: "list-three",
                type: "toppopular",
                loading: r,
                children: n(D, {
                    list: s,
                    isBig: !0,
                    name: "one"
                })
            }), n(v, {
                className: "list-four",
                loading: r,
                type: "recentplay",
                children: n(D, {
                    list: i,
                    isBig: !0,
                    name: "two"
                })
            })]
        })
    }),
    Jn = "s1xbnsdm";
const Se = g.memo(function({
        tab: t,
        setTab: a,
        loading: o,
        className: s,
        children: i,
        tabs: r
    }) {
        return n("div", {
            className: b(Qn, s, o && "swiper-tab-loading"),
            children: n(Ve, {
                value: t,
                onChange: u => a(u),
                tabs: [{
                    label: n(v, {
                        loading: o,
                        type: r[0]
                    }),
                    value: null
                }, {
                    label: n(v, {
                        loading: o,
                        type: r[1]
                    }),
                    value: null
                }],
                children: i
            })
        })
    }),
    Qn = "sd4yeyp";
const Xn = g.memo(function() {
        const t = "midden-swipe",
            [a, o] = d.exports.useState(0),
            {
                hots: s,
                news: i,
                isLoading: r
            } = d.exports.useContext(U),
            u = a === 0 ? s : i,
            p = u.length > 0 ? u : Array(6).fill(-1);
        return n(Se, {
            tab: a,
            setTab: o,
            loading: r,
            className: b(Kn, "midden-right"),
            tabs: ["toppopular", "recentplay"],
            children: l(Y, {
                navigation: {
                    prevEl: ".navigation-prev-" + t,
                    nextEl: ".navigation-next-" + t
                },
                children: [I(p, 3).map((m, c) => n(B, {
                    children: l("div", {
                        className: "good-games-wrap",
                        children: [n("div", {
                            className: "item-wrap",
                            children: n(T, {
                                isBig: !1,
                                gameItem: m[0] === -1 ? null : m[0]
                            })
                        }), n("div", {
                            className: "item-wrap",
                            children: n(T, {
                                isBig: !1,
                                gameItem: m[1] === -1 ? null : m[1]
                            })
                        }), n("div", {
                            className: "item-wrap",
                            children: n(T, {
                                isBig: !1,
                                gameItem: m[2] === -1 ? null : m[2]
                            })
                        })]
                    })
                }, c)), n(q, {
                    name: t
                })]
            })
        })
    }),
    Kn = "sag7oed";
const Ge = g.memo(function({
        big: t = !1
    }) {
        const {
            bigProfits: a,
            bigWins: o,
            hots: s,
            news: i,
            isLoading: r
        } = d.exports.useContext(U);
        return l("div", {
            className: b(Zn, t && "small-large"),
            children: [n(v, {
                className: "list-one",
                type: "bigwin",
                loading: r,
                children: n(A, {
                    type: "bigwin",
                    list: o
                })
            }), n(v, {
                className: "list-two",
                type: "bigprofit",
                loading: r,
                children: n(A, {
                    type: "bigprofit",
                    list: a
                })
            }), n("div", {
                className: "small-right",
                children: n(Xn, {})
            })]
        })
    }),
    Zn = "s1qohyz3";
const ea = g.memo(function() {
        const [t, a] = d.exports.useState(0), {
            hots: o,
            news: s,
            isLoading: i
        } = d.exports.useContext(U), r = t === 0 ? o : s, u = i || r.length === 0 ? Array(6).fill(-1) : r;
        return n(Se, {
            tab: t,
            setTab: a,
            className: ta,
            loading: i,
            tabs: ["toppopular", "recentplay"],
            children: n(Y, {
                freeMode: !0,
                slidesPerView: "auto",
                spaceBetween: 0,
                delay: 15500,
                children: I(u, 3).map((p, m) => n(B, {
                    children: l("div", {
                        className: "mobile-bottom-games-wrap",
                        children: [n(T, {
                            isBig: !1,
                            gameItem: p[0] === -1 ? null : p[0]
                        }), n(T, {
                            isBig: !1,
                            gameItem: p[1] === -1 ? null : p[1]
                        }), n(T, {
                            isBig: !1,
                            gameItem: p[2] === -1 ? null : p[1]
                        })]
                    })
                }, m))
            })
        })
    }),
    ta = "s1rlute9";
const na = g.memo(function() {
        const [t, a] = d.exports.useState(0), {
            bigProfits: o,
            bigWins: s,
            isLoading: i
        } = d.exports.useContext(U), r = t === 0 ? s : o, u = t === 0 ? ot : st, p = i || r.length === 0 ? Array(6).fill(-1) : r;
        return n(Se, {
            tab: t,
            setTab: a,
            loading: i,
            className: b(aa, "mobile-top-swiper"),
            tabs: ["bigwin", "bigprofit"],
            children: n(Y, {
                delay: 11500,
                children: I(p, 3).map((m, c) => n(B, {
                    children: l("div", {
                        className: "mobile-top-games-wrap",
                        children: [n("div", {
                            className: "item-wrap",
                            children: n(u, {
                                gameItem: m[0] === -1 ? null : m[0]
                            })
                        }), n("div", {
                            className: "item-wrap",
                            children: n(u, {
                                gameItem: m[1] === -1 ? null : m[1]
                            })
                        })]
                    })
                }, c))
            })
        })
    }),
    aa = "s1um3zph";
const oa = g.memo(function({
        mobileTop: e = !0
    }) {
        return n("div", {
            className: sa,
            children: e ? n(na, {}) : n(ea, {})
        })
    }),
    sa = "sk3jc4a";
const Re = M(function({
        mobileBottom: t = !1
    }) {
        const [a, o] = d.exports.useState(0), [s, i] = d.exports.useState(k.isMobile ? 0 : 2), [r, u] = d.exports.useState(0), p = se(c => {
            const h = Pn(c.width),
                f = Un[h],
                w = R[s],
                P = c.width / w - 1;
            o(f * P + f), u(c.width), i(h)
        }, 500), m = d.exports.useMemo(() => n("div", {
            className: ia,
            ref: p,
            style: {
                height: s === 0 ? "auto" : a + "px"
            },
            children: s === 0 ? n(oa, {
                mobileTop: !t
            }) : l(Vn, {
                size: r,
                type: s,
                children: [s === 1 && n(Ge, {}), s === 2 && n(Ge, {
                    big: !0
                }), s === 3 && n(zn, {}), s === 4 && n(Ee, {}), s === 5 && n(Ee, {
                    big: !0
                }), s === 6 && n($e, {
                    big: !1
                }), s === 7 && n($e, {})]
            })
        }), [a, s, r]);
        return t && !k.isMobile ? null : m
    }),
    ia = "sm6w69n";
const ra = [{
        width: 1799,
        num: 11
    }, {
        width: 1500,
        num: 10
    }, {
        width: 1248,
        num: 9
    }, {
        width: 1008,
        num: 8
    }, {
        width: 832,
        num: 7
    }, {
        width: qe,
        num: 3
    }],
    la = M(function({
        data: t
    }) {
        const a = k.isDarken;
        return n(ye, {
            to: t.path.replace("slots-list", "provider"),
            className: b(da, "provider-img"),
            children: n(ge, {
                className: "img",
                src: a ? t.logo : t.logoWhite,
                margin: 100
            })
        })
    });

function ca() {
    return n("div", {
        className: ma
    })
}
const ha = ({
        list: e
    }) => {
        const t = At({
                Model: la,
                list: e,
                lineNum: 2,
                gridGap: 1,
                sreenOpt: ra,
                Loading: ca,
                isSupper: !1
            }),
            a = x(),
            o = e ? e.length % 2 === 0 : !1;
        return l("div", {
            className: b(pa, o && "last-two-radius"),
            children: [l("div", {
                className: "provider-tit",
                children: [n("div", {
                    className: "txt",
                    children: a("game.slots.game_provider").toLocaleUpperCase()
                }), n(q, {
                    name: "provider"
                })]
            }), n(oe, {
                navigation: {
                    prevEl: ".navigation-prev-provider",
                    nextEl: ".navigation-next-provider"
                },
                effect: "fade",
                children: t
            })]
        })
    },
    ua = ({
        live: e
    }) => {
        const t = Je(async () => (await N.inited, H.get("/home/provider/iconList/", {
            cache: !0,
            params: {
                categoryId: e,
                device: k.isMobile ? 1 : 2,
                restriction: N.areaCode
            }
        })));
        return n(ha, {
            list: t.data ? t.data : void 0
        })
    },
    da = "s1b84so5",
    pa = "p1o2hsq1";
E({
    cl1: ["#31343c", L("#e9eaf2", .6)]
});
const ma = "l14qiepq",
    fa = M(function({
        children: t
    }) {
        const [a, o] = ve({
            bigProfits: [],
            bigWins: [],
            hots: [],
            news: [],
            isLoading: !0
        });
        return d.exports.useEffect(() => {
            const s = [H.get("/home/statistic/rank-abc/", {
                cache: !0
            }), H.post("/home/statistic/last/")];
            N.login && s.push(H.post("/home/game/recent/", {
                page: 1,
                areaCode: N.areaCode ? N.areaCode : "IN",
                pageSize: 20
            })), Promise.all(s).then(i => {
                const r = [];
                i[2] && i[2].list && r.push(Mn(i[2].list.splice(0, 3))), r.push(We(i[1])), o({
                    bigProfits: te(i[0].bigProfits, 8),
                    bigWins: te(i[0].bigWins, 8),
                    hots: te(We(i[0].hots), 9),
                    news: te(Mt(r), 9),
                    isLoading: !1
                })
            })
        }, []), n(U.Provider, {
            value: a,
            children: t
        })
    });

function ya() {
    const e = x();
    return [{
        label: e("common.lobby"),
        value: "Lobby",
        isHome: !0,
        isBcoriginal: !0,
        activeImg: "lobby",
        icon: "Lobby",
        href: "",
        status: 1
    }, {
        label: e("common.original"),
        value: "Original",
        isBcoriginal: !0,
        activeImg: "originalcasino",
        icon: "ClassicDice",
        href: "",
        status: 1
    }, {
        label: e("common.slots"),
        value: "Slots",
        activeImg: "slots",
        icon: "HashDice",
        href: "/slots-list/all",
        status: 1
    }, {
        label: e("common.live_casino"),
        value: "Live Casino",
        activeImg: "livecasino",
        icon: "LiveCasino",
        href: "/live-list/all",
        status: 1
    }, {
        label: e("common.table_game"),
        value: "Table Game",
        activeImg: "tablegame",
        icon: "TableGame",
        href: "",
        status: 1
    }, {
        label: e("common.game_show"),
        value: "Game Show",
        activeImg: "gameShow",
        icon: "GameShow",
        href: "",
        status: 1
    }]
}

function ga(e, t, a) {
    const o = e / 2,
        s = t.querySelectorAll(".nav-item")[a],
        i = s ? s.offsetLeft : 0,
        r = s ? s.offsetWidth : 0;
    return i - o + r / 2
}

function He(e, t, a) {
    pe.to(e, {
        scrollLeft: t,
        duration: a
    })
}

function ba() {
    const e = ya(),
        t = 132 * e.length,
        a = d.exports.useRef(0),
        o = d.exports.useRef({}),
        s = d.exports.useRef(null),
        [i, r] = ve({
            index: 0,
            showNav: !1
        }),
        u = se(h => {
            r({
                showNav: h.width < t && !k.isMobile
            }), a.current = h.width
        });
    o.current = i.index;
    const p = h => {
            if (s && s.current) {
                const f = ga(a.current, s.current, h);
                He(s.current, f, .3)
            }
            r({
                index: h
            })
        },
        m = h => {
            if (s.current) {
                const w = s.current.scrollLeft + (h ? +a.current : -a.current);
                He(s.current, w, a.current / t)
            }
        };
    return {
        view: l("div", {
            ref: u,
            className: b(va, "nav-tag-list"),
            style: {
                marginRight: i.showNav ? "16px" : "",
                maxWidth: `${t}px`
            },
            children: [n("div", {
                className: "cont-scroll",
                ref: s,
                children: n("div", {
                    className: "nav-bg",
                    style: {
                        width: `${t}px`
                    },
                    children: e.map((h, f) => l(we, {
                        onClick: () => p(f),
                        className: `nav-item ${i.index===f?"active":""}`,
                        children: [l("div", {
                            className: "icon-box",
                            children: [n(ae, {
                                name: h.icon
                            }), n(Ie, {
                                className: "img-icon",
                                name: h.activeImg
                            })]
                        }), n("div", {
                            className: "nav-name",
                            children: h.label
                        })]
                    }, f))
                })
            }), i.showNav && l(F, {
                children: [n("button", {
                    className: "prev navigation-btn",
                    onClick: () => m(),
                    children: n(ae, {
                        name: "Arrow"
                    })
                }), n("button", {
                    className: "navigation-btn",
                    onClick: () => m(!0),
                    children: n(ae, {
                        name: "Arrow"
                    })
                })]
            })]
        }),
        tab: e[i.index]
    }
}
E({
    cl1: ["#191a1e", "#fff"],
    cl2: ["#fff", "#000"],
    cl3: [L("#2b2e34", .6), L("#e9eaf2", .6)],
    cl4: ["rgba(0, 0, 0, 0.3)", "#fff"],
    cl5: ["#2d3035", "#fff"]
});
const va = "sgczo3o";

function wa(e, t) {
    if (t) {
        if (t.length > 0) {
            const a = e ? 0 : 1;
            return t.map((o, s) => (s > a && (o.iconWide = ""), o))
        }
        return t
    } else return t
}

function de({
    props: e
}) {
    const t = V(),
        a = Je(e.asyncFun),
        o = x(),
        s = a.data ? a.data.list : void 0;
    let i = !1;
    e.supper && s && s.length > 1 && (i = Boolean(s[0].iconWide) && Boolean(s[1].iconWide));
    const r = u => o(u === "best_slots" ? "page.home.tit.best_slots" : u === "recommended_live" ? "page.home.tit.recommended_live" : "page.home.tit.feature_slots");
    return n(Ut, {
        list: wa(k.isMobile, s),
        isSlots: !0,
        className: ka,
        lineNum: e.linNum ? e.linNum : 2,
        isSupper: i,
        clickSource: e.clickSource,
        sliderClassName: e.sliderName,
        isMakeup: !0,
        children: l("div", {
            className: "grid-header",
            children: [n(tt, {
                cont: r(e.title),
                isGreen: e.title === "recommended_live"
            }), l("div", {
                onClick: () => t(e.href),
                className: "slost-num",
                children: ["All", " ", n("span", {
                    className: "cl-primary",
                    children: a.data ? a.data.total : 0
                }), n("span", {
                    className: "name",
                    children: e.tag
                })]
            }), n(q, {
                name: e.sliderName
            })]
        })
    })
}
const ka = "ss8f5wn";
var De = `<h2>Crypto Online Casino</h2>
<p>Casinos online have not always been around, but we can safely say that online casinos have been used a lot since they came on the market. And it's not in short demand nor options, and now in 2022, we have 1000s and 1000s to pick from \u2013 it's just a matter of what you like and what payment options you would like to see at the casino.</p>
<p>Players are always looking for something new, which will help make the gaming experience so much better and more accessible. Allowing the player to focus on the absolute fun of a casino, that's right, the games themselves.</p>
<p>That's why we are now going to tell you all you need to know about a crypto casino or bitcoin gambling or bitcoin casino, whatever you want to call it.</p>

<div class="other-info">
  <h2>What is crypto?</h2>
  <p>Before discussing what casino games you can play, you first need to understand what crypto is and why people prefer to use this payment option when you play your favorite games.</p>
  <p>Bitcoin and other cryptocurrencies have been growing and making a big name for themselves over the last few years. When it just started, it was a risk to buy bitcoin and the ones taking the risk are the ones benefiting from it now. Crypto has been probable fair income from it going up and down in the market, and the best about it all \u2013 is that you can do it completely anonymously.</p>
  <p>It might have been a risk back then, but today you can use bitcoin like any other payment option. A few are not accepting it, but BTC casino is a big hit and has continued to grow over the last 5+ years.</p>
  <p>And what most like about bitcoin as a deposit bonus or as a payment option, in general, is that you can easily link your bitcoin account to your bank account and have direct and instant access to your top crypto fun.</p>

  <h2>Can you use bitcoin on all online gambling sites?</h2>
  <p>All players would dream that all the different online casinos you find will allow you to use bitcoin and other crypto for your deposit and withdrawals. Unfortunately, the sad truth is that very few casinos accept it. But the good news is that the top online casinos will have one or the other crypto that you can at least use for deposits. When it comes to withdrawals, it's a bit harder to find a casino. Most likely, you'll have to pick one of the other payment options. The most found payment option to combine with bitcoin and crypto is a bank transfer straight into your bank account.</p>
  <p>For the newbies out there, we will drop a few names for other casinos to look at if you would like to try out betting sites that accept crypto. We have Doge Casino, Shiba Casino, and Solana Casino, and they are all worth your time. They will bring the excitement you are all seeking. You can pay with bitcoin \u2013 and the best part is that they are all giving you a great deposit bonus for using their casino and joining the crypto gambling world.</p>
  
  <h2>What are the advantages of Crypto gambling?</h2>
  <ul>
    <li>Anonymity \u2013 when using crypto on the online market, you do not need to give information that can lead back to you. You can hide 100% behind the computer screen and never give up as much as your first name. This is the top-selling point for this type of payment option for many.</li>
    <li>Worldwide access \u2013 as we know, many payment options are only available for some, not all, and it can be very frustrating and can be challenging for some players in some countries \u2013 because their limitations on payment options are severely blocking them from playing on the casinos and games they want to play on. With Bitcoin casinos and other crypto casinos, they will remove this limit and no longer have to look elsewhere for their fun.</li>
    <li>Verification \u2013 a real party pooper is when you have to fill out much information to access the fun. The simple answer is to use crypto, and you will no longer need to experience this.</li>
    <li>Transaction fees \u2013 ok, we understand that everyone needs to make money and that it's not all that gets covered by the ads, etc., that runs in the background and the standard fees that come with a transaction. But we also know that some payment options like to lay heavy on the fees they charge their clients when they use their service. If you use crypto as a payment option, you will not find this problem.</li>
  </ul>
  
  <h2>Disadvantages of crypto gambling</h2>
  <ul>
    <li>No chargebacks/reversals \u2013 unfortunately, you have no take backs when using this payment option. Once the transaction has been confirmed on your account and left your wallet, that's it. So be sure that you do your background check on the casino or online gambling site you want to spend your time and money on as you do not have the same security as credit cards and other traditional payment methods.</li>
    <li>No "the customer is always right" \u2013 their customer service when problems with transactions have been described not to be the best. They run good communication with all their customers, and you will not be left to sort it by yourself or anything. But the chances of getting money back once it has left your account are slim to none. So you need to be sure when you use it and how much you wish to use and that you really can trust the person/company you are making the payment to.</li>
  </ul>
  
  <h2>How can I be sure the online casino site is safe?</h2>
  <p>Most casinos online today are safe, and you don't need to worry about spending your time at them. However, there are some casinos that do not have your best interest at heart. That's why you always need to do your background check even when it comes to crypto gambling, or should we say at least if you want to use bitcoin to gamble. There's no extra security, and when the money leaves your wallet, you do not have a lot of chances to get the money back.</p>
  <p>Luckily there are ways to find out if you can truly trust the casino you want to spend your time on. The best way is to check if the casino has a valid license for online gambling. All casinos need this to run their casino legally, and it is not free, so it wouldn't be something they hide. Some casinos choose to obtain more than one of these licenses. This is a red flag for some, and we are here to tell you that it is not a red flag. A casino can have as many licenses as they please, but they can also have one.</p>
  <p>Also, searching the casino to look at what other players are saying is always a good idea. If a casino were to be unfair, you would not be the first one they have done it to \u2013 so there will be some kind of reviews out there telling you about what happened and what has been done about it. Use your best judgment, and if something feels off about the gambling site, then there's a lot more out there. Pick a different one, and there's no need to gamble with faith.</p>

  <h2>Do you still get bonuses if you deposit with crypto?</h2>
  <p>We can say that it's the casino experience, the thrill, the fun, and the games that bring the players to the different casinos, but we all know it would be a lie. Players want bonuses and a lot of bonuses to help them on their way to winning big. Bonuses are just like free money, and just watch the conditions that come with the bonuses before you accept them.</p>
  <p>Suppose you are to be deposited with crypto. In that case, user experience tells us that the bonuses are minor but not bad for what you get. If you are a first-time player at the casino, you will find a welcome package on a bitcoin casino. This is the bonus that will start your journey on the casino, and it will help you go for the big jackpot.</p>
  <p>It's not just the welcome bonus that's available. After using the welcome bonus, you need to keep your eyes out for the deposit bonus. That's the bonus the casinos sometimes give on a random deposit you set during your play. And if you are fortunate, it will bring big or small jackpots with it as you go.</p>
  <p>Just as when you set a standard deposit, you claim your bonus in the cashier when you put a crypto deposit. And remember that no one can force you into taking that bonus. The choice is yours. It's a choice you should make after you have looked over all the terms and conditions that come with the bonus. Remember, the wager requirements must be the entire field before you can withdraw any of the winnings you are lucky enough to win. Also, remember that even though there's a chance of winning a lot of money, you have to remember casinos are only for entertainment.</p>
  
  <h2>How to choose the right Bitcoin casino</h2>
  <p>We all want to find the best option right away, we want to hit the jackpot on the first spin, we all want to get it all, and we want it straight away. Unfortunately, that's not reality. We learn.</p>
  <p>There's no secret road map to massive payouts and the perfect casino on the first spin, even when it comes to the crypto casino \u2013 but here are a few tips:</p>
  <ul>
    <li>You need to look at what kind of games the casino offers if they don't have any games you like or any games you would like to try out.</li>
    <li>Suppose you have a type of cryptocurrency and not all of them or don't want to try a different one than the one you know. In that case, you have to check the payment methods to ensure that crypto casinos accept that type as a payment method on their casino.</li>
    <li>Bonus - we know we already talked about the important bonus, but we will repeat it. We know that many players are only paying attention to what kind of bonus the casino has to offer to their new and old players.</li>
    <li>Make sure you can play \u2013 most casinos have a list of restricted countries that cannot play in their casino. Make sure that your country isn't on the restricted list.</li>
  </ul>
  
  <h2>Is it difficult to deposit or make a withdrawal?</h2>
  <p>Many payment methods are difficult to understand, and crypto casinos' selling point is that everything is supposed to be more accessible when using it \u2013 so is it easier?</p>
  <p>Yes, it's as easy as stealing candy from a kid. There are just a few steps to make a deposit and just a few steps to make a withdrawal. And of course, we are here to tell you how to do just that:</p>
  <p>This is how you make a deposit using bitcoin or another crypto:</p>
  <ul>
    <li>First, you have to find your favorite casino that accepts crypto as payment options and make your way to the cashier.</li>
    <li>Pick if you want to use bitcoin or a different type of crypto.</li>
    <li>And then all that's left is to type in how much you would like to deposit and click enter. And within a few moments, the balance should be on your player account.</li>
  </ul>
  <p>This is how you make a withdrawal if and when you are lucky enough to win:</p>
  <ul>
    <li>The first thing you will have to do is to go over the to cashier and choose the method of withdrawal you prefer to use</li>
    <li>Fill in the amount you wish to make a withdrawal of, and then press confirm</li>
  </ul>
  <p>As you can see, this is a lot easier than what it would be with many of the other payment options you find on an online casino \u2013 but as we all know, it's not something we see all over.</p>

  <h2>What games can you find in a crypto casino?</h2>
  <p>After all, it is said that bonuses deposit all the other fun in a casino. What makes the best user experience for an online gambling site is what games you can find at the casino. A player needs to be able to find a few to choose from, and it needs to be some kind of balance to keep the market open for more than one type of player.</p>
  <p>Online slots are the absolute favorite among the players on the market, and let us just tell you a bit of what you can expect from an online slot machine on a crypto gambling site.</p>
  <p>Any game on a slot machine will be completely random, just like tossing coins. The computer program that controls the game selects a random symbol on the first row, then the second. Payback is the percentage of money paid back to the player on average. Each spin on the game has the same chance of winning or losing as the previous game; it has nothing to say how long since the last jackpot was paid out or whether the slot machine is "hot" or "cold."</p>
  <p>In the 80s, slot machines became very popular and even surpassed table games such as craps and blackjack. Slot machines and video poker now make up more than 70 percent of the casinos' profits. Now that we have gone online, it continues to profit from online crypto and bitcoin casinos and the casinos that don't accept the crypto methods. This is for a simple reason: big jackpots. When slot machines were digitized, it became possible to make the jackpot win less frequent, which also meant that the jackpot on online slot machines became larger when you first won it. And players love big jackpots! If you play for 5 dollars on a blackjack table, you can win a maximum of 7.5 dollars, but if you play with 3 dollars on a slot machine, you can win several thousand or millions of dollars in one go, but this is only if you are lucky. As we said before, you have to always look at casino games as entertainment and not a quick payday.</p>
  <p>But despite their popularity, there are three major problems with playing slot machines versus table games. First of all, casinos are not always open about the odds they place on each game, and this means that it is difficult to know how likely it is to win. Second, no matter what these secret odds are, they are often wrong and worse than table games such as craps, baccarat, and blackjack. Thirdly, slot machines run much faster than other games, and thus you can lose a lot of money in a short amount of time.</p>
  <p>Table games are the next big thing on online casinos, so let's talk about what you can expect from this type of game and give you newbies out there a chance to quickly learn before they buy bitcoin to spend their hard-earned money on online slots and other games for a quick payout.</p>
  <p>Most casinos offer table games, and if you play at a casino that does not have them, you should consider finding another casino that offers this.</p>
  <p>You do not have to play for money to play table games. Many casinos offer free play or demo play, so you do not deposit real money. In the long run, this may get a little boring, but there are full opportunities to deposit cash at a later date.</p>
  <p>How much you bet on a table game is up to you, but it is often a minimum bet to participate. This varies with the different casino sites, so feel free to check out yourself when you have found a casino that you will play at.</p>
  <p>Online Blackjack, also called twenty-one, is a table game most people associate with the casino. Nowadays, you can play blackjack at home in the living room, as long as you connect online and make a deposit at a casino. All the primary providers of casinos have blackjack in their portfolio.</p>
  <p>Online Poker is an exciting card game that suits most people. It takes time to become good at poker, and there has been a lot of discussion about whether poker is a game of skill. Here, there are conflicting opinions from the poker industry and authorities. The poker industry, for its part, believes that it is a game of skill. At the same time, the authorities see poker as a game under the Lottery Act and are more about luck than skill.</p>
  <p>Video Poker was early to be digital, so it was one of the first games you could play without having to hold cards in your hand. Video poker is almost always based on regular poker, where you play with the top five cards in your hand.</p>
  <p>Jacks, or better, is a common form of video poker. Here you win money as soon as you have a pair of jacks or better.</p>
  <p>In roulette, you can bet on combinations, single numbers, colors, rows, and whether the ball lands on odd or even numbers. The payout amount varies according to what you bet on. For even numbers and odd numbers, the payout sum is 1 to 1, which applies to red or black.</p>
  <p>There is also a different range you can bet on here. The payout varies depending on which field you choose.</p>
  <p>Craps is a dice game where a player bets on the outcome of two dice. It sounds pretty simple but probably needs some explanation to understand how to play the game. The advantage of craps is that only dice are required to play, so you can easily play craps as long as you have two dice.</p>
  <p>If you have been to a casino, you know how it feels. Live casino gives you a bit of the same feeling. In some of the casinos, you have the opportunity to chat with the host along the way. It provides excitement, joy, and maybe a little frustration to play live casino, depending on the game's result.</p>
  <p>If you want to play live casino, you must register with one of the gaming providers that offer this. It is easy to register with a foreign gaming company, and you only fill in with information about yourself. After this, you deposit bitcoin or another form of real money and start playing.</p>
  <p>Casino players expect the casino to offer live casinos. It is so common to play live casinos that all casinos should have this in their range.</p>
  <p>There are several types of live casino games you can play online, and roulette and blackjack are the most common forms of live casinos. But there are also games like Monopoly, and you will become a millionaire and spin wheels you can play live.</p>
  <p>The selection of games is usually massive, but you need to know that it varies from casino to casino, so you will not always wind the same crypto casino games on different crypto casino sites. This is why we told you when giving you tips for what casinos to play, or not what casinos to play, but how to find the perfect casino for you to look at the games you can find on the casino.</p>
  <p>And remember to check out what kind of bonuses you can get, not all casinos give you a deposit bonus, but you will find reload bonuses and no deposit bonus where you are not looking if you are not looking hard enough to start with. And if you are lucky, you can find casinos that give away daily cashback.</p>
  

  <h2>Can I use a mobile or tablet?</h2>
  <p>Suppose you want to play on the top online casinos. In that case, you want them all to be mobile casinos, just simply for the pure pleasure of playing whenever and wherever you are at the time of the day you want to play.</p>
  <p>Betting sites that offer mobile casinos are getting more hits in a day than the ones not offering mobile casinos. We all know that no one wants to sit in front of a laptop anymore for their online gambling. The best is that you can find all the fair games and the fantastic welcome bonus that you usually see if you play from a laptop.</p>
</div>`;
const Na = () => ie(() =>
        import ("./de-DE.0c62da6e.js"), []),
    Sa = () => ie(() =>
        import ("./pt-BR.56840834.js"), []),
    xa = () => ie(() =>
        import ("./ru-RU.a017707c.js"), []),
    Ta = () => ie(() =>
        import ("./id-ID.535db4f4.js"), []),
    La = {
        sliderName: "home-slots",
        clickSource: "game_home_slots",
        title: "best_slots",
        href: "/slots-list/all",
        tag: "Slots",
        supper: !0,
        asyncFun: $t
    },
    _a = {
        sliderName: "home-live-slots",
        clickSource: "game_home_live",
        title: "recommended_live",
        href: "/live-list/all",
        tag: "Live Games",
        supper: !0,
        asyncFun: () => Gt(4)
    },
    Ca = {
        sliderName: "home-feature-slots",
        clickSource: "game_home_feature_slots",
        title: "feature_slots",
        href: "",
        tag: "Slots",
        linNum: 1,
        asyncFun: Rt
    };

function $a() {
    const e = Pt(),
        {
            bannerList: t,
            allGameList: a
        } = ze(e.lng),
        {
            view: o,
            tab: s
        } = ba();
    return l("div", {
        id: "home",
        children: [n(en, {
            list: t
        }), n(Ba, {
            allGameList: a,
            tab: s,
            view: o
        }), n(Aa, {
            lng: e.lng
        })]
    })
}
const Ba = g.memo(function({
        allGameList: t,
        tab: a,
        view: o
    }) {
        return n(fa, {
            children: l("div", {
                className: Ua,
                children: [n(jt, {}), n(Re, {}), n(ln, {
                    list: t.length > 0 ? t : void 0,
                    tabView: o,
                    tab: a
                }), a.isHome && l(F, {
                    children: [n(de, {
                        props: La
                    }), n(de, {
                        props: Ca
                    }), n(ua, {
                        live: 1
                    }), n(de, {
                        props: _a
                    }), l("div", {
                        className: "screen-wrap",
                        children: [n(bn, {}), n(_n, {})]
                    }), n(Re, {
                        mobileBottom: !0
                    })]
                })]
            })
        })
    }),
    Aa = g.memo(function({
        lng: t
    }) {
        const [a, o] = d.exports.useState(De);
        return d.exports.useEffect(() => {
            t === "de-DE" ? Na().then(s => o(s.default)) : t === "pt-BR" ? Sa().then(s => o(s.default)) : t === "ru-RU" ? xa().then(s => o(s.default)) : t === "id-ID" ? Ta().then(s => o(s.default)) : o(De)
        }, [t]), a ? n(Ma, {
            html: a
        }) : null
    });

function Ma({
    html: e
}) {
    const t = x(),
        a = Wt(),
        [o, s] = d.exports.useState(!1),
        i = d.exports.useRef(null);
    return d.exports.useLayoutEffect(() => {
        const r = i.current;
        if (!r) return;
        const u = r.querySelector(".other-info");
        !o && a && (u.style.height = "0px"), Et(u, o)
    }, [o, a, e]), n("div", {
        className: Pa,
        children: l("div", {
            className: "center-box",
            children: [n("div", {
                ref: i,
                dangerouslySetInnerHTML: {
                    __html: e
                }
            }), n("div", {
                children: l("span", {
                    className: "cl-primary btn-more",
                    onClick: () => s(!o),
                    children: [t(o ? "common.show_less" : "common.show_more"), " >>"]
                })
            })]
        })
    })
}
const Ua = "w5bbtuc",
    Pa = "h152y13l";
export {
    $a as Home
};
System.register(["./index-legacy.1416f96c.js"], (function(e, r) {
    "use strict";
    var n;
    return {
        setters: [function(e) {
            n = e.at
        }],
        execute: function() {
            e({
                s: async function(e) {
                    const r = await b(),
                        [n] = await O(),
                        t = await r.request({
                            method: "personal_sign",
                            params: [e, n]
                        });
                    return {
                        publicAddress: n,
                        signature: t
                    }
                },
                t: async function(e, r, n = "ETH") {
                    const t = await b(),
                        i = await O(),
                        o = await I(n);
                    try {
                        return await t.request({
                            method: "eth_sendTransaction",
                            params: [{
                                to: e,
                                value: new N(r).multipliedBy("1000000000000000000").toString(16),
                                from: i[0],
                                chainId: o.chainId
                            }]
                        })
                    } catch (s) {
                        throw new Error(s.message)
                    }
                }
            });
            var t = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i,
                i = Math.ceil,
                o = Math.floor,
                s = "[BigNumber Error] ",
                c = s + "Number primitive has more than 15 significant digits: ",
                u = 1e14,
                a = 14,
                l = 9007199254740991,
                f = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13],
                h = 1e7,
                p = 1e9;

            function g(e) {
                var r = 0 | e;
                return e > 0 || e === r ? r : r - 1
            }

            function m(e) {
                for (var r, n, t = 1, i = e.length, o = e[0] + ""; t < i;) {
                    for (r = e[t++] + "", n = a - r.length; n--; r = "0" + r);
                    o += r
                }
                for (i = o.length; 48 === o.charCodeAt(--i););
                return o.slice(0, i + 1 || 1)
            }

            function w(e, r) {
                var n, t, i = e.c,
                    o = r.c,
                    s = e.s,
                    c = r.s,
                    u = e.e,
                    a = r.e;
                if (!s || !c) return null;
                if (n = i && !i[0], t = o && !o[0], n || t) return n ? t ? 0 : -c : s;
                if (s != c) return s;
                if (n = s < 0, t = u == a, !i || !o) return t ? 0 : !i ^ n ? 1 : -1;
                if (!t) return u > a ^ n ? 1 : -1;
                for (c = (u = i.length) < (a = o.length) ? u : a, s = 0; s < c; s++)
                    if (i[s] != o[s]) return i[s] > o[s] ^ n ? 1 : -1;
                return u == a ? 0 : u > a ^ n ? 1 : -1
            }

            function d(e, r, n, t) {
                if (e < r || e > n || e !== o(e)) throw Error(s + (t || "Argument") + ("number" == typeof e ? e < r || e > n ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(e))
            }

            function v(e) {
                var r = e.c.length - 1;
                return g(e.e / a) == r && e.c[r] % 2 != 0
            }

            function y(e, r) {
                return (e.length > 1 ? e.charAt(0) + "." + e.slice(1) : e) + (r < 0 ? "e" : "e+") + r
            }

            function E(e, r, n) {
                var t, i;
                if (r < 0) {
                    for (i = n + "."; ++r; i += n);
                    e = i + e
                } else if (++r > (t = e.length)) {
                    for (i = n, r -= t; --r; i += n);
                    e += i
                } else r < t && (e = e.slice(0, r) + "." + e.slice(r));
                return e
            }
            var N = function e(r) {
                var n, N, b, O, A, I, S, x, _, T, B = $.prototype = {
                        constructor: $,
                        toString: null,
                        valueOf: null
                    },
                    C = new $(1),
                    U = 20,
                    M = 4,
                    P = -7,
                    R = 21,
                    D = -1e7,
                    L = 1e7,
                    k = !1,
                    q = 1,
                    G = 0,
                    F = {
                        prefix: "",
                        groupSize: 3,
                        secondaryGroupSize: 0,
                        groupSeparator: ",",
                        decimalSeparator: ".",
                        fractionGroupSize: 0,
                        fractionGroupSeparator: " ",
                        suffix: ""
                    },
                    j = "0123456789abcdefghijklmnopqrstuvwxyz",
                    H = !0;

                function $(e, r) {
                    var n, i, s, u, f, h, p, g, m = this;
                    if (!(m instanceof $)) return new $(e, r);
                    if (null == r) {
                        if (e && !0 === e._isBigNumber) return m.s = e.s, void(!e.c || e.e > L ? m.c = m.e = null : e.e < D ? m.c = [m.e = 0] : (m.e = e.e, m.c = e.c.slice()));
                        if ((h = "number" == typeof e) && 0 * e == 0) {
                            if (m.s = 1 / e < 0 ? (e = -e, -1) : 1, e === ~~e) {
                                for (u = 0, f = e; f >= 10; f /= 10, u++);
                                return void(u > L ? m.c = m.e = null : (m.e = u, m.c = [e]))
                            }
                            g = String(e)
                        } else {
                            if (!t.test(g = String(e))) return b(m, g, h);
                            m.s = 45 == g.charCodeAt(0) ? (g = g.slice(1), -1) : 1
                        }(u = g.indexOf(".")) > -1 && (g = g.replace(".", "")), (f = g.search(/e/i)) > 0 ? (u < 0 && (u = f), u += +g.slice(f + 1), g = g.substring(0, f)) : u < 0 && (u = g.length)
                    } else {
                        if (d(r, 2, j.length, "Base"), 10 == r && H) return X(m = new $(e), U + m.e + 1, M);
                        if (g = String(e), h = "number" == typeof e) {
                            if (0 * e != 0) return b(m, g, h, r);
                            if (m.s = 1 / e < 0 ? (g = g.slice(1), -1) : 1, $.DEBUG && g.replace(/^0\.0*|\./, "").length > 15) throw Error(c + e)
                        } else m.s = 45 === g.charCodeAt(0) ? (g = g.slice(1), -1) : 1;
                        for (n = j.slice(0, r), u = f = 0, p = g.length; f < p; f++)
                            if (n.indexOf(i = g.charAt(f)) < 0) {
                                if ("." == i) {
                                    if (f > u) {
                                        u = p;
                                        continue
                                    }
                                } else if (!s && (g == g.toUpperCase() && (g = g.toLowerCase()) || g == g.toLowerCase() && (g = g.toUpperCase()))) {
                                    s = !0, f = -1, u = 0;
                                    continue
                                }
                                return b(m, String(e), h, r)
                            }
                        h = !1, (u = (g = N(g, r, 10, m.s)).indexOf(".")) > -1 ? g = g.replace(".", "") : u = g.length
                    }
                    for (f = 0; 48 === g.charCodeAt(f); f++);
                    for (p = g.length; 48 === g.charCodeAt(--p););
                    if (g = g.slice(f, ++p)) {
                        if (p -= f, h && $.DEBUG && p > 15 && (e > l || e !== o(e))) throw Error(c + m.s * e);
                        if ((u = u - f - 1) > L) m.c = m.e = null;
                        else if (u < D) m.c = [m.e = 0];
                        else {
                            if (m.e = u, m.c = [], f = (u + 1) % a, u < 0 && (f += a), f < p) {
                                for (f && m.c.push(+g.slice(0, f)), p -= a; f < p;) m.c.push(+g.slice(f, f += a));
                                f = a - (g = g.slice(f)).length
                            } else f -= p;
                            for (; f--; g += "0");
                            m.c.push(+g)
                        }
                    } else m.c = [m.e = 0]
                }

                function z(e, r, n, t) {
                    var i, o, s, c, u;
                    if (null == n ? n = M : d(n, 0, 8), !e.c) return e.toString();
                    if (i = e.c[0], s = e.e, null == r) u = m(e.c), u = 1 == t || 2 == t && (s <= P || s >= R) ? y(u, s) : E(u, s, "0");
                    else if (o = (e = X(new $(e), r, n)).e, c = (u = m(e.c)).length, 1 == t || 2 == t && (r <= o || o <= P)) {
                        for (; c < r; u += "0", c++);
                        u = y(u, o)
                    } else if (r -= s, u = E(u, o, "0"), o + 1 > c) {
                        if (--r > 0)
                            for (u += "."; r--; u += "0");
                    } else if ((r += o - c) > 0)
                        for (o + 1 == c && (u += "."); r--; u += "0");
                    return e.s < 0 && i ? "-" + u : u
                }

                function V(e, r) {
                    for (var n, t = 1, i = new $(e[0]); t < e.length; t++) {
                        if (!(n = new $(e[t])).s) {
                            i = n;
                            break
                        }
                        r.call(i, n) && (i = n)
                    }
                    return i
                }

                function W(e, r, n) {
                    for (var t = 1, i = r.length; !r[--i]; r.pop());
                    for (i = r[0]; i >= 10; i /= 10, t++);
                    return (n = t + n * a - 1) > L ? e.c = e.e = null : n < D ? e.c = [e.e = 0] : (e.e = n, e.c = r), e
                }

                function X(e, r, n, t) {
                    var s, c, l, h, p, g, m, w = e.c,
                        d = f;
                    if (w) {
                        e: {
                            for (s = 1, h = w[0]; h >= 10; h /= 10, s++);
                            if ((c = r - s) < 0) c += a,
                            l = r,
                            m = (p = w[g = 0]) / d[s - l - 1] % 10 | 0;
                            else if ((g = i((c + 1) / a)) >= w.length) {
                                if (!t) break e;
                                for (; w.length <= g; w.push(0));
                                p = m = 0, s = 1, l = (c %= a) - a + 1
                            } else {
                                for (p = h = w[g], s = 1; h >= 10; h /= 10, s++);
                                m = (l = (c %= a) - a + s) < 0 ? 0 : p / d[s - l - 1] % 10 | 0
                            }
                            if (t = t || r < 0 || null != w[g + 1] || (l < 0 ? p : p % d[s - l - 1]), t = n < 4 ? (m || t) && (0 == n || n == (e.s < 0 ? 3 : 2)) : m > 5 || 5 == m && (4 == n || t || 6 == n && (c > 0 ? l > 0 ? p / d[s - l] : 0 : w[g - 1]) % 10 & 1 || n == (e.s < 0 ? 8 : 7)), r < 1 || !w[0]) return w.length = 0, t ? (r -= e.e + 1, w[0] = d[(a - r % a) % a], e.e = -r || 0) : w[0] = e.e = 0, e;
                            if (0 == c ? (w.length = g, h = 1, g--) : (w.length = g + 1, h = d[a - c], w[g] = l > 0 ? o(p / d[s - l] % d[l]) * h : 0), t)
                                for (;;) {
                                    if (0 == g) {
                                        for (c = 1, l = w[0]; l >= 10; l /= 10, c++);
                                        for (l = w[0] += h, h = 1; l >= 10; l /= 10, h++);
                                        c != h && (e.e++, w[0] == u && (w[0] = 1));
                                        break
                                    }
                                    if (w[g] += h, w[g] != u) break;
                                    w[g--] = 0, h = 1
                                }
                            for (c = w.length; 0 === w[--c]; w.pop());
                        }
                        e.e > L ? e.c = e.e = null : e.e < D && (e.c = [e.e = 0])
                    }
                    return e
                }

                function Y(e) {
                    var r, n = e.e;
                    return null === n ? e.toString() : (r = m(e.c), r = n <= P || n >= R ? y(r, n) : E(r, n, "0"), e.s < 0 ? "-" + r : r)
                }
                return $.clone = e, $.ROUND_UP = 0, $.ROUND_DOWN = 1, $.ROUND_CEIL = 2, $.ROUND_FLOOR = 3, $.ROUND_HALF_UP = 4, $.ROUND_HALF_DOWN = 5, $.ROUND_HALF_EVEN = 6, $.ROUND_HALF_CEIL = 7, $.ROUND_HALF_FLOOR = 8, $.EUCLID = 9, $.config = $.set = function(e) {
                    var r, n;
                    if (null != e) {
                        if ("object" != typeof e) throw Error(s + "Object expected: " + e);
                        if (e.hasOwnProperty(r = "DECIMAL_PLACES") && (d(n = e[r], 0, p, r), U = n), e.hasOwnProperty(r = "ROUNDING_MODE") && (d(n = e[r], 0, 8, r), M = n), e.hasOwnProperty(r = "EXPONENTIAL_AT") && ((n = e[r]) && n.pop ? (d(n[0], -p, 0, r), d(n[1], 0, p, r), P = n[0], R = n[1]) : (d(n, -p, p, r), P = -(R = n < 0 ? -n : n))), e.hasOwnProperty(r = "RANGE"))
                            if ((n = e[r]) && n.pop) d(n[0], -p, -1, r), d(n[1], 1, p, r), D = n[0], L = n[1];
                            else {
                                if (d(n, -p, p, r), !n) throw Error(s + r + " cannot be zero: " + n);
                                D = -(L = n < 0 ? -n : n)
                            }
                        if (e.hasOwnProperty(r = "CRYPTO")) {
                            if ((n = e[r]) !== !!n) throw Error(s + r + " not true or false: " + n);
                            if (n) {
                                if ("undefined" == typeof crypto || !crypto || !crypto.getRandomValues && !crypto.randomBytes) throw k = !n, Error(s + "crypto unavailable");
                                k = n
                            } else k = n
                        }
                        if (e.hasOwnProperty(r = "MODULO_MODE") && (d(n = e[r], 0, 9, r), q = n), e.hasOwnProperty(r = "POW_PRECISION") && (d(n = e[r], 0, p, r), G = n), e.hasOwnProperty(r = "FORMAT")) {
                            if ("object" != typeof(n = e[r])) throw Error(s + r + " not an object: " + n);
                            F = n
                        }
                        if (e.hasOwnProperty(r = "ALPHABET")) {
                            if ("string" != typeof(n = e[r]) || /^.?$|[+\-.\s]|(.).*\1/.test(n)) throw Error(s + r + " invalid: " + n);
                            H = "0123456789" == n.slice(0, 10), j = n
                        }
                    }
                    return {
                        DECIMAL_PLACES: U,
                        ROUNDING_MODE: M,
                        EXPONENTIAL_AT: [P, R],
                        RANGE: [D, L],
                        CRYPTO: k,
                        MODULO_MODE: q,
                        POW_PRECISION: G,
                        FORMAT: F,
                        ALPHABET: j
                    }
                }, $.isBigNumber = function(e) {
                    if (!e || !0 !== e._isBigNumber) return !1;
                    if (!$.DEBUG) return !0;
                    var r, n, t = e.c,
                        i = e.e,
                        c = e.s;
                    e: if ("[object Array]" == {}.toString.call(t)) {
                        if ((1 === c || -1 === c) && i >= -p && i <= p && i === o(i)) {
                            if (0 === t[0]) {
                                if (0 === i && 1 === t.length) return !0;
                                break e
                            }
                            if ((r = (i + 1) % a) < 1 && (r += a), String(t[0]).length == r) {
                                for (r = 0; r < t.length; r++)
                                    if ((n = t[r]) < 0 || n >= u || n !== o(n)) break e;
                                if (0 !== n) return !0
                            }
                        }
                    } else
                    if (null === t && null === i && (null === c || 1 === c || -1 === c)) return !0;
                    throw Error(s + "Invalid BigNumber: " + e)
                }, $.maximum = $.max = function() {
                    return V(arguments, B.lt)
                }, $.minimum = $.min = function() {
                    return V(arguments, B.gt)
                }, $.random = (O = 9007199254740992, A = Math.random() * O & 2097151 ? function() {
                    return o(Math.random() * O)
                } : function() {
                    return 8388608 * (1073741824 * Math.random() | 0) + (8388608 * Math.random() | 0)
                }, function(e) {
                    var r, n, t, c, u, l = 0,
                        h = [],
                        g = new $(C);
                    if (null == e ? e = U : d(e, 0, p), c = i(e / a), k)
                        if (crypto.getRandomValues) {
                            for (r = crypto.getRandomValues(new Uint32Array(c *= 2)); l < c;)(u = 131072 * r[l] + (r[l + 1] >>> 11)) >= 9e15 ? (n = crypto.getRandomValues(new Uint32Array(2)), r[l] = n[0], r[l + 1] = n[1]) : (h.push(u % 1e14), l += 2);
                            l = c / 2
                        } else {
                            if (!crypto.randomBytes) throw k = !1, Error(s + "crypto unavailable");
                            for (r = crypto.randomBytes(c *= 7); l < c;)(u = 281474976710656 * (31 & r[l]) + 1099511627776 * r[l + 1] + 4294967296 * r[l + 2] + 16777216 * r[l + 3] + (r[l + 4] << 16) + (r[l + 5] << 8) + r[l + 6]) >= 9e15 ? crypto.randomBytes(7).copy(r, l) : (h.push(u % 1e14), l += 7);
                            l = c / 7
                        }
                    if (!k)
                        for (; l < c;)(u = A()) < 9e15 && (h[l++] = u % 1e14);
                    for (c = h[--l], e %= a, c && e && (u = f[a - e], h[l] = o(c / u) * u); 0 === h[l]; h.pop(), l--);
                    if (l < 0) h = [t = 0];
                    else {
                        for (t = -1; 0 === h[0]; h.splice(0, 1), t -= a);
                        for (l = 1, u = h[0]; u >= 10; u /= 10, l++);
                        l < a && (t -= a - l)
                    }
                    return g.e = t, g.c = h, g
                }), $.sum = function() {
                    for (var e = 1, r = arguments, n = new $(r[0]); e < r.length;) n = n.plus(r[e++]);
                    return n
                }, N = function() {
                    var e = "0123456789";

                    function r(e, r, n, t) {
                        for (var i, o, s = [0], c = 0, u = e.length; c < u;) {
                            for (o = s.length; o--; s[o] *= r);
                            for (s[0] += t.indexOf(e.charAt(c++)), i = 0; i < s.length; i++) s[i] > n - 1 && (null == s[i + 1] && (s[i + 1] = 0), s[i + 1] += s[i] / n | 0, s[i] %= n)
                        }
                        return s.reverse()
                    }
                    return function(t, i, o, s, c) {
                        var u, a, l, f, h, p, g, w, d = t.indexOf("."),
                            v = U,
                            y = M;
                        for (d >= 0 && (f = G, G = 0, t = t.replace(".", ""), p = (w = new $(i)).pow(t.length - d), G = f, w.c = r(E(m(p.c), p.e, "0"), 10, o, e), w.e = w.c.length), l = f = (g = r(t, i, o, c ? (u = j, e) : (u = e, j))).length; 0 == g[--f]; g.pop());
                        if (!g[0]) return u.charAt(0);
                        if (d < 0 ? --l : (p.c = g, p.e = l, p.s = s, g = (p = n(p, w, v, y, o)).c, h = p.r, l = p.e), d = g[a = l + v + 1], f = o / 2, h = h || a < 0 || null != g[a + 1], h = y < 4 ? (null != d || h) && (0 == y || y == (p.s < 0 ? 3 : 2)) : d > f || d == f && (4 == y || h || 6 == y && 1 & g[a - 1] || y == (p.s < 0 ? 8 : 7)), a < 1 || !g[0]) t = h ? E(u.charAt(1), -v, u.charAt(0)) : u.charAt(0);
                        else {
                            if (g.length = a, h)
                                for (--o; ++g[--a] > o;) g[a] = 0, a || (++l, g = [1].concat(g));
                            for (f = g.length; !g[--f];);
                            for (d = 0, t = ""; d <= f; t += u.charAt(g[d++]));
                            t = E(t, l, u.charAt(0))
                        }
                        return t
                    }
                }(), n = function() {
                    function e(e, r, n) {
                        var t, i, o, s, c = 0,
                            u = e.length,
                            a = r % h,
                            l = r / h | 0;
                        for (e = e.slice(); u--;) c = ((i = a * (o = e[u] % h) + (t = l * o + (s = e[u] / h | 0) * a) % h * h + c) / n | 0) + (t / h | 0) + l * s, e[u] = i % n;
                        return c && (e = [c].concat(e)), e
                    }

                    function r(e, r, n, t) {
                        var i, o;
                        if (n != t) o = n > t ? 1 : -1;
                        else
                            for (i = o = 0; i < n; i++)
                                if (e[i] != r[i]) {
                                    o = e[i] > r[i] ? 1 : -1;
                                    break
                                } return o
                    }

                    function n(e, r, n, t) {
                        for (var i = 0; n--;) e[n] -= i, i = e[n] < r[n] ? 1 : 0, e[n] = i * t + e[n] - r[n];
                        for (; !e[0] && e.length > 1; e.splice(0, 1));
                    }
                    return function(t, i, s, c, l) {
                        var f, h, p, m, w, d, v, y, E, N, b, O, A, I, S, x, _, T = t.s == i.s ? 1 : -1,
                            B = t.c,
                            C = i.c;
                        if (!(B && B[0] && C && C[0])) return new $(t.s && i.s && (B ? !C || B[0] != C[0] : C) ? B && 0 == B[0] || !C ? 0 * T : T / 0 : NaN);
                        for (E = (y = new $(T)).c = [], T = s + (h = t.e - i.e) + 1, l || (l = u, h = g(t.e / a) - g(i.e / a), T = T / a | 0), p = 0; C[p] == (B[p] || 0); p++);
                        if (C[p] > (B[p] || 0) && h--, T < 0) E.push(1), m = !0;
                        else {
                            for (I = B.length, x = C.length, p = 0, T += 2, (w = o(l / (C[0] + 1))) > 1 && (C = e(C, w, l), B = e(B, w, l), x = C.length, I = B.length), A = x, b = (N = B.slice(0, x)).length; b < x; N[b++] = 0);
                            _ = C.slice(), _ = [0].concat(_), S = C[0], C[1] >= l / 2 && S++;
                            do {
                                if (w = 0, (f = r(C, N, x, b)) < 0) {
                                    if (O = N[0], x != b && (O = O * l + (N[1] || 0)), (w = o(O / S)) > 1)
                                        for (w >= l && (w = l - 1), v = (d = e(C, w, l)).length, b = N.length; 1 == r(d, N, v, b);) w--, n(d, x < v ? _ : C, v, l), v = d.length, f = 1;
                                    else 0 == w && (f = w = 1), v = (d = C.slice()).length;
                                    if (v < b && (d = [0].concat(d)), n(N, d, b, l), b = N.length, -1 == f)
                                        for (; r(C, N, x, b) < 1;) w++, n(N, x < b ? _ : C, b, l), b = N.length
                                } else 0 === f && (w++, N = [0]);
                                E[p++] = w, N[0] ? N[b++] = B[A] || 0 : (N = [B[A]], b = 1)
                            } while ((A++ < I || null != N[0]) && T--);
                            m = null != N[0], E[0] || E.splice(0, 1)
                        }
                        if (l == u) {
                            for (p = 1, T = E[0]; T >= 10; T /= 10, p++);
                            X(y, s + (y.e = p + h * a - 1) + 1, c, m)
                        } else y.e = h, y.r = +m;
                        return y
                    }
                }(), I = /^(-?)0([xbo])(?=\w[\w.]*$)/i, S = /^([^.]+)\.$/, x = /^\.([^.]+)$/, _ = /^-?(Infinity|NaN)$/, T = /^\s*\+(?=[\w.])|^\s+|\s+$/g, b = function(e, r, n, t) {
                    var i, o = n ? r : r.replace(T, "");
                    if (_.test(o)) e.s = isNaN(o) ? null : o < 0 ? -1 : 1;
                    else {
                        if (!n && (o = o.replace(I, (function(e, r, n) {
                                return i = "x" == (n = n.toLowerCase()) ? 16 : "b" == n ? 2 : 8, t && t != i ? e : r
                            })), t && (i = t, o = o.replace(S, "$1").replace(x, "0.$1")), r != o)) return new $(o, i);
                        if ($.DEBUG) throw Error(s + "Not a" + (t ? " base " + t : "") + " number: " + r);
                        e.s = null
                    }
                    e.c = e.e = null
                }, B.absoluteValue = B.abs = function() {
                    var e = new $(this);
                    return e.s < 0 && (e.s = 1), e
                }, B.comparedTo = function(e, r) {
                    return w(this, new $(e, r))
                }, B.decimalPlaces = B.dp = function(e, r) {
                    var n, t, i, o = this;
                    if (null != e) return d(e, 0, p), null == r ? r = M : d(r, 0, 8), X(new $(o), e + o.e + 1, r);
                    if (!(n = o.c)) return null;
                    if (t = ((i = n.length - 1) - g(this.e / a)) * a, i = n[i])
                        for (; i % 10 == 0; i /= 10, t--);
                    return t < 0 && (t = 0), t
                }, B.dividedBy = B.div = function(e, r) {
                    return n(this, new $(e, r), U, M)
                }, B.dividedToIntegerBy = B.idiv = function(e, r) {
                    return n(this, new $(e, r), 0, 1)
                }, B.exponentiatedBy = B.pow = function(e, r) {
                    var n, t, c, u, l, f, h, p, g = this;
                    if ((e = new $(e)).c && !e.isInteger()) throw Error(s + "Exponent not an integer: " + Y(e));
                    if (null != r && (r = new $(r)), l = e.e > 14, !g.c || !g.c[0] || 1 == g.c[0] && !g.e && 1 == g.c.length || !e.c || !e.c[0]) return p = new $(Math.pow(+Y(g), l ? 2 - v(e) : +Y(e))), r ? p.mod(r) : p;
                    if (f = e.s < 0, r) {
                        if (r.c ? !r.c[0] : !r.s) return new $(NaN);
                        (t = !f && g.isInteger() && r.isInteger()) && (g = g.mod(r))
                    } else {
                        if (e.e > 9 && (g.e > 0 || g.e < -1 || (0 == g.e ? g.c[0] > 1 || l && g.c[1] >= 24e7 : g.c[0] < 8e13 || l && g.c[0] <= 9999975e7))) return u = g.s < 0 && v(e) ? -0 : 0, g.e > -1 && (u = 1 / u), new $(f ? 1 / u : u);
                        G && (u = i(G / a + 2))
                    }
                    for (l ? (n = new $(.5), f && (e.s = 1), h = v(e)) : h = (c = Math.abs(+Y(e))) % 2, p = new $(C);;) {
                        if (h) {
                            if (!(p = p.times(g)).c) break;
                            u ? p.c.length > u && (p.c.length = u) : t && (p = p.mod(r))
                        }
                        if (c) {
                            if (0 === (c = o(c / 2))) break;
                            h = c % 2
                        } else if (X(e = e.times(n), e.e + 1, 1), e.e > 14) h = v(e);
                        else {
                            if (0 == (c = +Y(e))) break;
                            h = c % 2
                        }
                        g = g.times(g), u ? g.c && g.c.length > u && (g.c.length = u) : t && (g = g.mod(r))
                    }
                    return t ? p : (f && (p = C.div(p)), r ? p.mod(r) : u ? X(p, G, M, void 0) : p)
                }, B.integerValue = function(e) {
                    var r = new $(this);
                    return null == e ? e = M : d(e, 0, 8), X(r, r.e + 1, e)
                }, B.isEqualTo = B.eq = function(e, r) {
                    return 0 === w(this, new $(e, r))
                }, B.isFinite = function() {
                    return !!this.c
                }, B.isGreaterThan = B.gt = function(e, r) {
                    return w(this, new $(e, r)) > 0
                }, B.isGreaterThanOrEqualTo = B.gte = function(e, r) {
                    return 1 === (r = w(this, new $(e, r))) || 0 === r
                }, B.isInteger = function() {
                    return !!this.c && g(this.e / a) > this.c.length - 2
                }, B.isLessThan = B.lt = function(e, r) {
                    return w(this, new $(e, r)) < 0
                }, B.isLessThanOrEqualTo = B.lte = function(e, r) {
                    return -1 === (r = w(this, new $(e, r))) || 0 === r
                }, B.isNaN = function() {
                    return !this.s
                }, B.isNegative = function() {
                    return this.s < 0
                }, B.isPositive = function() {
                    return this.s > 0
                }, B.isZero = function() {
                    return !!this.c && 0 == this.c[0]
                }, B.minus = function(e, r) {
                    var n, t, i, o, s = this,
                        c = s.s;
                    if (r = (e = new $(e, r)).s, !c || !r) return new $(NaN);
                    if (c != r) return e.s = -r, s.plus(e);
                    var l = s.e / a,
                        f = e.e / a,
                        h = s.c,
                        p = e.c;
                    if (!l || !f) {
                        if (!h || !p) return h ? (e.s = -r, e) : new $(p ? s : NaN);
                        if (!h[0] || !p[0]) return p[0] ? (e.s = -r, e) : new $(h[0] ? s : 3 == M ? -0 : 0)
                    }
                    if (l = g(l), f = g(f), h = h.slice(), c = l - f) {
                        for ((o = c < 0) ? (c = -c, i = h) : (f = l, i = p), i.reverse(), r = c; r--; i.push(0));
                        i.reverse()
                    } else
                        for (t = (o = (c = h.length) < (r = p.length)) ? c : r, c = r = 0; r < t; r++)
                            if (h[r] != p[r]) {
                                o = h[r] < p[r];
                                break
                            } if (o && (i = h, h = p, p = i, e.s = -e.s), (r = (t = p.length) - (n = h.length)) > 0)
                        for (; r--; h[n++] = 0);
                    for (r = u - 1; t > c;) {
                        if (h[--t] < p[t]) {
                            for (n = t; n && !h[--n]; h[n] = r);
                            --h[n], h[t] += u
                        }
                        h[t] -= p[t]
                    }
                    for (; 0 == h[0]; h.splice(0, 1), --f);
                    return h[0] ? W(e, h, f) : (e.s = 3 == M ? -1 : 1, e.c = [e.e = 0], e)
                }, B.modulo = B.mod = function(e, r) {
                    var t, i, o = this;
                    return e = new $(e, r), !o.c || !e.s || e.c && !e.c[0] ? new $(NaN) : !e.c || o.c && !o.c[0] ? new $(o) : (9 == q ? (i = e.s, e.s = 1, t = n(o, e, 0, 3), e.s = i, t.s *= i) : t = n(o, e, 0, q), (e = o.minus(t.times(e))).c[0] || 1 != q || (e.s = o.s), e)
                }, B.multipliedBy = B.times = function(e, r) {
                    var n, t, i, o, s, c, l, f, p, m, w, d, v, y, E, N = this,
                        b = N.c,
                        O = (e = new $(e, r)).c;
                    if (!(b && O && b[0] && O[0])) return !N.s || !e.s || b && !b[0] && !O || O && !O[0] && !b ? e.c = e.e = e.s = null : (e.s *= N.s, b && O ? (e.c = [0], e.e = 0) : e.c = e.e = null), e;
                    for (t = g(N.e / a) + g(e.e / a), e.s *= N.s, (l = b.length) < (m = O.length) && (v = b, b = O, O = v, i = l, l = m, m = i), i = l + m, v = []; i--; v.push(0));
                    for (y = u, E = h, i = m; --i >= 0;) {
                        for (n = 0, w = O[i] % E, d = O[i] / E | 0, o = i + (s = l); o > i;) n = ((f = w * (f = b[--s] % E) + (c = d * f + (p = b[s] / E | 0) * w) % E * E + v[o] + n) / y | 0) + (c / E | 0) + d * p, v[o--] = f % y;
                        v[o] = n
                    }
                    return n ? ++t : v.splice(0, 1), W(e, v, t)
                }, B.negated = function() {
                    var e = new $(this);
                    return e.s = -e.s || null, e
                }, B.plus = function(e, r) {
                    var n, t = this,
                        i = t.s;
                    if (r = (e = new $(e, r)).s, !i || !r) return new $(NaN);
                    if (i != r) return e.s = -r, t.minus(e);
                    var o = t.e / a,
                        s = e.e / a,
                        c = t.c,
                        l = e.c;
                    if (!o || !s) {
                        if (!c || !l) return new $(i / 0);
                        if (!c[0] || !l[0]) return l[0] ? e : new $(c[0] ? t : 0 * i)
                    }
                    if (o = g(o), s = g(s), c = c.slice(), i = o - s) {
                        for (i > 0 ? (s = o, n = l) : (i = -i, n = c), n.reverse(); i--; n.push(0));
                        n.reverse()
                    }
                    for ((i = c.length) - (r = l.length) < 0 && (n = l, l = c, c = n, r = i), i = 0; r;) i = (c[--r] = c[r] + l[r] + i) / u | 0, c[r] = u === c[r] ? 0 : c[r] % u;
                    return i && (c = [i].concat(c), ++s), W(e, c, s)
                }, B.precision = B.sd = function(e, r) {
                    var n, t, i, o = this;
                    if (null != e && e !== !!e) return d(e, 1, p), null == r ? r = M : d(r, 0, 8), X(new $(o), e, r);
                    if (!(n = o.c)) return null;
                    if (t = (i = n.length - 1) * a + 1, i = n[i]) {
                        for (; i % 10 == 0; i /= 10, t--);
                        for (i = n[0]; i >= 10; i /= 10, t++);
                    }
                    return e && o.e + 1 > t && (t = o.e + 1), t
                }, B.shiftedBy = function(e) {
                    return d(e, -9007199254740991, l), this.times("1e" + e)
                }, B.squareRoot = B.sqrt = function() {
                    var e, r, t, i, o, s = this,
                        c = s.c,
                        u = s.s,
                        a = s.e,
                        l = U + 4,
                        f = new $("0.5");
                    if (1 !== u || !c || !c[0]) return new $(!u || u < 0 && (!c || c[0]) ? NaN : c ? s : 1 / 0);
                    if (0 == (u = Math.sqrt(+Y(s))) || u == 1 / 0 ? (((r = m(c)).length + a) % 2 == 0 && (r += "0"), u = Math.sqrt(+r), a = g((a + 1) / 2) - (a < 0 || a % 2), t = new $(r = u == 1 / 0 ? "5e" + a : (r = u.toExponential()).slice(0, r.indexOf("e") + 1) + a)) : t = new $(u + ""), t.c[0])
                        for ((u = (a = t.e) + l) < 3 && (u = 0);;)
                            if (o = t, t = f.times(o.plus(n(s, o, l, 1))), m(o.c).slice(0, u) === (r = m(t.c)).slice(0, u)) {
                                if (t.e < a && --u, "9999" != (r = r.slice(u - 3, u + 1)) && (i || "4999" != r)) {
                                    +r && (+r.slice(1) || "5" != r.charAt(0)) || (X(t, t.e + U + 2, 1), e = !t.times(t).eq(s));
                                    break
                                }
                                if (!i && (X(o, o.e + U + 2, 0), o.times(o).eq(s))) {
                                    t = o;
                                    break
                                }
                                l += 4, u += 4, i = 1
                            }
                    return X(t, t.e + U + 1, M, e)
                }, B.toExponential = function(e, r) {
                    return null != e && (d(e, 0, p), e++), z(this, e, r, 1)
                }, B.toFixed = function(e, r) {
                    return null != e && (d(e, 0, p), e = e + this.e + 1), z(this, e, r)
                }, B.toFormat = function(e, r, n) {
                    var t, i = this;
                    if (null == n) null != e && r && "object" == typeof r ? (n = r, r = null) : e && "object" == typeof e ? (n = e, e = r = null) : n = F;
                    else if ("object" != typeof n) throw Error(s + "Argument not an object: " + n);
                    if (t = i.toFixed(e, r), i.c) {
                        var o, c = t.split("."),
                            u = +n.groupSize,
                            a = +n.secondaryGroupSize,
                            l = n.groupSeparator || "",
                            f = c[0],
                            h = c[1],
                            p = i.s < 0,
                            g = p ? f.slice(1) : f,
                            m = g.length;
                        if (a && (o = u, u = a, a = o, m -= o), u > 0 && m > 0) {
                            for (o = m % u || u, f = g.substr(0, o); o < m; o += u) f += l + g.substr(o, u);
                            a > 0 && (f += l + g.slice(o)), p && (f = "-" + f)
                        }
                        t = h ? f + (n.decimalSeparator || "") + ((a = +n.fractionGroupSize) ? h.replace(new RegExp("\\d{" + a + "}\\B", "g"), "$&" + (n.fractionGroupSeparator || "")) : h) : f
                    }
                    return (n.prefix || "") + t + (n.suffix || "")
                }, B.toFraction = function(e) {
                    var r, t, i, o, c, u, l, h, p, g, w, d, v = this,
                        y = v.c;
                    if (null != e && (!(l = new $(e)).isInteger() && (l.c || 1 !== l.s) || l.lt(C))) throw Error(s + "Argument " + (l.isInteger() ? "out of range: " : "not an integer: ") + Y(l));
                    if (!y) return new $(v);
                    for (r = new $(C), p = t = new $(C), i = h = new $(C), d = m(y), c = r.e = d.length - v.e - 1, r.c[0] = f[(u = c % a) < 0 ? a + u : u], e = !e || l.comparedTo(r) > 0 ? c > 0 ? r : p : l, u = L, L = 1 / 0, l = new $(d), h.c[0] = 0; g = n(l, r, 0, 1), 1 != (o = t.plus(g.times(i))).comparedTo(e);) t = i, i = o, p = h.plus(g.times(o = p)), h = o, r = l.minus(g.times(o = r)), l = o;
                    return o = n(e.minus(t), i, 0, 1), h = h.plus(o.times(p)), t = t.plus(o.times(i)), h.s = p.s = v.s, w = n(p, i, c *= 2, M).minus(v).abs().comparedTo(n(h, t, c, M).minus(v).abs()) < 1 ? [p, i] : [h, t], L = u, w
                }, B.toNumber = function() {
                    return +Y(this)
                }, B.toPrecision = function(e, r) {
                    return null != e && d(e, 1, p), z(this, e, r, 2)
                }, B.toString = function(e) {
                    var r, n = this,
                        t = n.s,
                        i = n.e;
                    return null === i ? t ? (r = "Infinity", t < 0 && (r = "-" + r)) : r = "NaN" : (null == e ? r = i <= P || i >= R ? y(m(n.c), i) : E(m(n.c), i, "0") : 10 === e && H ? r = E(m((n = X(new $(n), U + i + 1, M)).c), n.e, "0") : (d(e, 2, j.length, "Base"), r = N(E(m(n.c), i, "0"), 10, e, t, !0)), t < 0 && n.c[0] && (r = "-" + r)), r
                }, B.valueOf = B.toJSON = function() {
                    return Y(this)
                }, B._isBigNumber = !0, B[Symbol.toStringTag] = "BigNumber", B[Symbol.for("nodejs.util.inspect.custom")] = B.valueOf, null != r && $.set(r), $
            }();
            async function b() {
                const e = await n((() => r.import("./index-legacy.1a47b3f8.js").then((function(e) {
                        return e.i
                    }))), void 0).then((e => e.default)),
                    t = await e();
                if (t) return t;
                throw new Error("No MetaMask Extension!")
            }
            async function O() {
                const e = await b();
                return await e.request({
                    method: "eth_requestAccounts"
                }), e.request({
                    method: "eth_accounts"
                })
            }
            const A = {
                ETH: {
                    chainId: "0x1",
                    rpcUrls: ["https://mainnet.infura.io/v3/"],
                    chainName: "Ethereum Mainnet",
                    nativeCurrency: {
                        name: "Ether",
                        decimals: 18,
                        symbol: "ETH"
                    },
                    blockExplorerUrls: ["https://etherscan.io"]
                },
                BNB: {
                    chainId: "0x38",
                    rpcUrls: ["https://bsc-dataseed1.binance.org"],
                    chainName: "Smart Chain",
                    nativeCurrency: {
                        name: "Binance Chain Native Token",
                        symbol: "BNB",
                        decimals: 18
                    },
                    blockExplorerUrls: ["https://bscscan.com"]
                },
                MATIC: {
                    chainId: "0x89",
                    rpcUrls: ["https://polygon-rpc.com/", "https://rpc-mainnet.matic.network"],
                    chainName: "Polygon Mainnet",
                    nativeCurrency: {
                        name: "MATIC",
                        symbol: "MATIC",
                        decimals: 18
                    },
                    blockExplorerUrls: ["https://polygonscan.com/"]
                }
            };
            async function I(e = "ETH") {
                const r = await b(),
                    n = A[e];
                if (n.chainId !== r.chainId) try {
                    await r.request({
                        method: "wallet_switchEthereumChain",
                        params: [{
                            chainId: n.chainId
                        }]
                    })
                } catch (t) {
                    if (4902 !== t.code) throw new Error(t.message);
                    try {
                        return await r.request({
                            method: "wallet_addEthereumChain",
                            params: [n]
                        }), I(e)
                    } catch (i) {
                        throw new Error(i.message)
                    }
                }
                return n
            }
        }
    }
}));
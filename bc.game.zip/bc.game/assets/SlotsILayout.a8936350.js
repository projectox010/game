var C = Object.defineProperty,
    j = Object.defineProperties;
var M = Object.getOwnPropertyDescriptors;
var p = Object.getOwnPropertySymbols;
var x = Object.prototype.hasOwnProperty,
    S = Object.prototype.propertyIsEnumerable;
var v = (e, t, a) => t in e ? C(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: a
    }) : e[t] = a,
    b = (e, t) => {
        for (var a in t || (t = {})) x.call(t, a) && v(e, a, t[a]);
        if (p)
            for (var a of p(t)) S.call(t, a) && v(e, a, t[a]);
        return e
    },
    N = (e, t) => j(e, M(t));
var R = (e, t) => {
    var a = {};
    for (var n in e) x.call(e, n) && t.indexOf(n) < 0 && (a[n] = e[n]);
    if (e != null && p)
        for (var n of p(e)) t.indexOf(n) < 0 && S.call(e, n) && (a[n] = e[n]);
    return a
};
import {
    o as _,
    r as i,
    u as $,
    bT as A,
    s as I,
    bU as E,
    a as r,
    F as T,
    j as y,
    eP as k,
    l as L,
    b as B,
    eQ as F,
    eR as H,
    eS as U,
    eT as W,
    a5 as D,
    du as J,
    e as P,
    eU as Q,
    eV as X,
    J as l,
    y as q,
    dR as z,
    d as G,
    eW as K,
    eX as O
} from "./index.28e31dff.js";
const oe = _(i.exports.forwardRef(function(h, s) {
        var u = h,
            {
                tabs: e = [],
                actions: t = [],
                src: a,
                banner: n,
                className: f = "",
                children: w
            } = u,
            g = R(u, ["tabs", "actions", "src", "banner", "className", "children"]);
        const m = $();
        e = e.concat([{
            label: m("common.highrolls"),
            value: A
        }, {
            label: I.isMobile ? m("common.contest") : m("page.contest.title"),
            value: E
        }]);
        const c = () => {
            const o = a.split("?");
            let d = {};
            o[1] && (d = K(o[1])), d.currencyName = l.current, window.open(`${o[0]}?${O(d)}`)
        };
        return r(T, {
            children: y(k, N(b({
                className: `game-style-iframe ${f}`
            }, g), {
                children: [r("div", {
                    className: "game-area",
                    children: I.isMobile ? y("div", {
                        className: L(Y, "game-thumb"),
                        children: [r("div", {
                            className: "sp-img",
                            style: {
                                backgroundImage: `url(${n})`
                            }
                        }), r(B, {
                            type: "conic2",
                            onClick: c,
                            children: m("common.play")
                        })]
                    }) : y("div", {
                        className: "game-main",
                        children: [r(Z, {
                            ref: s,
                            src: a
                        }), w, r(F, {
                            actions: t
                        })]
                    })
                }), r(H, {
                    tabs: e
                }), r(U, {}), r(W, {})]
            }))
        })
    })),
    Y = "g1sw2nop",
    Z = D.memo(D.forwardRef(({
        src: e
    }, t) => {
        const a = J(),
            n = P(),
            [f, w] = i.exports.useState(Date.now()),
            g = i.exports.useRef(null),
            [s] = i.exports.useState(() => new Q),
            {
                ref: h,
                inView: u
            } = X();
        i.exports.useImperativeHandle(t, () => s), i.exports.useLayoutEffect(() => {
            s.on("connected", () => s.emit("currencyChange", l.current)), s.on("inited", () => {}), s.on("login", () => n("/login")), s.on("wallet", () => n("/wallet/deposit")), s.on("create_deduction", ({
                amount: o,
                currencyName: d,
                timeout: V
            }) => l.createDeduction(new q(o), d, a.name, V)), s.on("resolve_deduction", o => l.resolveDeduction(o)), s.on("reject_deduction", o => l.resolveDeduction(o, !1)), s.on("currencyChange", o => {
                l.dict[o] && (l.current = o)
            });
            const c = z(() => s.emit("currencyChange", l.current));
            return () => {
                c(), s.destroy()
            }
        }, []), i.exports.useEffect(() => {
            var c;
            s.target = (c = g.current) == null ? void 0 : c.contentWindow
        }, [f]), i.exports.useEffect(() => {
            if (!G.login) {
                const c = G.waitLogin();
                return c.then(() => w(Date.now())), () => c.cancel()
            }
        }, []);
        const m = i.exports.useMemo(() => u ? ee : te, [u]);
        return r("div", {
            ref: h,
            className: L(ae, "game-iframe-wrap"),
            children: r("iframe", {
                className: "game-iframe",
                style: m,
                ref: g,
                src: e
            }, f)
        })
    })),
    ee = {},
    te = {
        position: "fixed",
        width: "2!important",
        height: "1!important",
        left: 0,
        top: 0,
        opacity: 0
    },
    ae = "wob9cer";
export {
    oe as S
};
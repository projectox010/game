var Te = Object.defineProperty,
    Me = Object.defineProperties;
var Re = Object.getOwnPropertyDescriptors;
var ne = Object.getOwnPropertySymbols;
var Ge = Object.prototype.hasOwnProperty,
    _e = Object.prototype.propertyIsEnumerable;
var L = (s, e, t) => e in s ? Te(s, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
    }) : s[e] = t,
    E = (s, e) => {
        for (var t in e || (e = {})) Ge.call(e, t) && L(s, t, e[t]);
        if (ne)
            for (var t of ne(e)) _e.call(e, t) && L(s, t, e[t]);
        return s
    },
    H = (s, e) => Me(s, Re(e));
var b = (s, e, t) => (L(s, typeof e != "symbol" ? e + "" : e, t), t);
import {
    el as De,
    em as he,
    en as Pe,
    eo as Ee,
    ep as He,
    eq as We,
    cF as Fe,
    u as A,
    a as n,
    D as te,
    dx as ue,
    j as o,
    dy as je,
    dz as Oe,
    du as x,
    r as h,
    ao as $e,
    b0 as ze,
    er as qe,
    l as de,
    y as k,
    a5 as me,
    Y as se,
    ea as ge,
    t as $,
    q as R,
    o as P,
    P as Ue,
    aO as fe,
    F as q,
    s as S,
    dk as Ve,
    b2 as Ye,
    dl as Je,
    a$ as pe,
    A as X,
    am as ae,
    bm as Le,
    dj as Xe,
    b as be,
    e9 as Ke,
    G as ve,
    J as ie,
    dG as Qe,
    dY as Ze,
    eb as et,
    dC as tt,
    dD as nt,
    dZ as st,
    dE as at,
    dp as U,
    bN as we,
    d_ as it,
    ba as ot,
    bb as j,
    bc as lt,
    dR as rt,
    aH as ct
} from "./index.28e31dff.js";
import {
    s as V
} from "./index.dd8128e8.js";
import {
    G as D
} from "./index.06a59a68.js";
var ht = 9007199254740991,
    ut = Math.floor;

function oe(s, e) {
    var t = "";
    if (!s || e < 1 || e > ht) return t;
    do e % 2 && (t += s), e = ut(e / 2), e && (s += s); while (e);
    return t
}
var dt = De("length"),
    mt = dt,
    ye = "\\ud800-\\udfff",
    gt = "\\u0300-\\u036f",
    ft = "\\ufe20-\\ufe2f",
    pt = "\\u20d0-\\u20ff",
    bt = gt + ft + pt,
    vt = "\\ufe0e\\ufe0f",
    wt = "[" + ye + "]",
    Z = "[" + bt + "]",
    ee = "\\ud83c[\\udffb-\\udfff]",
    yt = "(?:" + Z + "|" + ee + ")",
    Ne = "[^" + ye + "]",
    Ce = "(?:\\ud83c[\\udde6-\\uddff]){2}",
    ke = "[\\ud800-\\udbff][\\udc00-\\udfff]",
    Nt = "\\u200d",
    xe = yt + "?",
    Ie = "[" + vt + "]?",
    Ct = "(?:" + Nt + "(?:" + [Ne, Ce, ke].join("|") + ")" + Ie + xe + ")*",
    kt = Ie + xe + Ct,
    xt = "(?:" + [Ne + Z + "?", Z, Ce, ke, wt].join("|") + ")",
    le = RegExp(ee + "(?=" + ee + ")|" + xt + kt, "g");

function It(s) {
    for (var e = le.lastIndex = 0; le.test(s);) ++e;
    return e
}

function Se(s) {
    return he(s) ? It(s) : mt(s)
}
var St = Math.ceil;

function At(s, e) {
    e = e === void 0 ? " " : Pe(e);
    var t = e.length;
    if (t < 2) return t ? oe(e, s) : e;
    var a = oe(e, St(s / Se(e)));
    return he(e) ? Ee(He(a), 0, s).join("") : a.slice(0, s)
}

function Bt(s, e, t) {
    s = We(s), e = Fe(e);
    var a = e ? Se(s) : 0;
    return e && a < e ? At(e - a, t) + s : s
}
const Tt = function({
        game: e
    }) {
        const t = A();
        return n(te, {
            title: t("common.game_intro"),
            children: n(ue, {
                children: o("div", {
                    className: "item",
                    children: [n("h2", {
                        children: " What game is this? "
                    }), n("div", {
                        className: "help-content",
                        children: e.gameInfo.detail.split(`
`).map((a, c) => n("p", {
                            children: `${a}`
                        }, c.toString()))
                    })]
                })
            })
        })
    },
    Mt = function({
        game: e
    }) {
        const t = A();
        return n(te, {
            title: t("common.bankroll"),
            children: n(je, {
                game: e,
                children: o("div", {
                    className: "item",
                    children: [n("h2", {
                        children: "What is the bankroll?"
                    }), o("div", {
                        className: "help-content",
                        children: [n("p", {
                            children: "The bankroll is the pool of money that the bankroller uses to pay out winners of the game."
                        }), n("p", {
                            children: "The max profit that players can win from a round of the game is determined by the size of the bankroll. The larger the bankroll, the more players can win."
                        }), n("p", {
                            children: "Players can bet on the bankroll (i.e. become bankrollers), and their bet is added to the bankroll such that they win when the house wins and they lose when the house loses."
                        }), n("p", {
                            onClick: () => Oe(e, 1),
                            className: "cl-primary pointer",
                            children: "Read more about bankrollers."
                        })]
                    }), n("h2", {
                        children: "How does the pool of funds operate? "
                    }), o("div", {
                        className: "help-content",
                        children: [n("p", {
                            children: "The bankroll implements a shareholding system that allows everyone to participate and obtain the corresponding shares."
                        }), o("p", {
                            children: [n("b", {
                                className: "cl-primary",
                                children: "The house edge is 1%."
                            }), " 99% of each bet will go to the bankroll, and the remaining 1% will be reserved for platform operating costs."]
                        }), n("p", {
                            children: "Payouts made to the winning players will be deducted from the bankroll."
                        })]
                    }), n("h2", {
                        children: "How does leverage investment work?"
                    }), o("div", {
                        className: "help-content",
                        children: [n("p", {
                            children: "We'll add the selected multiplier to your initial investment ( minus dilution fee ). If the Bankroll goes down and your initial investment goes to 0, you're get liquidated and you lost your investment."
                        }), n("p", {
                            children: "Hint: You can also use this feature as an Off-Site investment."
                        }), n("p", {
                            children: "Let's make an example:"
                        }), n("p", {
                            children: `Let's say have 1 Bitcoin. You could deposit them to your Account and invest them all. You would now be entrusting your whole 1BTC to BC.GAME, with the associated risks. Alternatively, you could deposit just 0.1 BTC of them, invest them, and then tell the site "I have 0.9 more BTC that I want to invest". You keep those coins safe in your own wallet with your own private key, but they are counted as part of the Game bankroll. Your share of the bankroll and your share of the site's profits and losses is the same as if you had invested your whole 1BTC. If the site should have a run of bad luck such that your 0.1 BTC goes to 0, You'll get liquidated and your leverage will be set to 0. In that way, you can never get into debt with the site but you can deposit again and keep your share of the bankroll.`
                        })]
                    }), n("h2", {
                        children: "What is the bankroller dilution fee?"
                    }), o("div", {
                        className: "help-content",
                        children: [n("p", {
                            children: "Every time you invest in the bankroll, 2 % of your investment will be distributed to the bankrollers who joined before you, according to their shares in the bankroll."
                        }), n("p", {
                            children: "Similarly, every time bankrollers who joined after you invest in the bankroll, you get a portion of the 2 % of their investment."
                        }), n("p", {
                            children: "For example, if you invest 1 ETH in the bankroll, 2 % of your investment (0.02 ETH) will be the be distributed to the bankrollers who joined before you, and the remaining 98 %\uFF080.98 ETH\uFF09will be confirmed as your share."
                        }), n("p", {
                            children: "The earlier you invest in the bankroll, you more you\u2019ll benefit from the dilution fee system. As this is our way to reward long-time bankrollers. You\u2019re never too late to join us!"
                        })]
                    })]
                })
            })
        })
    };
var Rt = Mt,
    Gt = "/assets/icon.954f481f.png",
    _t = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAGCAYAAADUtS5UAAAAAXNSR0IArs4c6QAAAH1JREFUKBVjvHr1KtvPnz+bGP7/j2MAAUbGRezs7HXa2tq/wHw0glrqWaCWlsPN//+/HCgG4lbAxZAY1FLPBPcpkuFYxWDysJCB8UE0NjGYPDY5oBgTTJ7eNBMoTjEsxSYGU4RNDpsYAfUsoIQEjlNYkAANAYnB9KHT1FIPAOiAaX72x7l3AAAAAElFTkSuQmCC",
    re = "/assets/sider.43b9ea10.svg",
    Dt = "/assets/win.449738f6.png",
    Pt = "/assets/win_w.62dc31a7.png",
    Et = "/assets/dice.1007262a.png",
    Ht = "/assets/tip.1ae46146.png",
    Wt = "/assets/tip_w.a52237b5.png",
    Ft = "/assets/lowhigh.102357a6.svg",
    jt = "/assets/lowhigh_w.999c3299.svg",
    Ot = "/assets/result-dice.774c7d78.png",
    $t = "/assets/l.d57074dc.svg",
    zt = "/assets/l_w.c91b3e00.svg",
    qt = "/assets/lq.3396df8e.svg",
    Ut = "/assets/lq_w.d6c4ef69.svg",
    N = {
        icon: Gt,
        center: _t,
        left: re,
        right: re,
        win: Dt,
        win_w: Pt,
        dice: Et,
        tip: Ht,
        tip_w: Wt,
        result_dice: Ot,
        lowhigh: Ft,
        lowhigh_w: jt,
        less: $t,
        less_w: zt,
        lesseq: qt,
        lesseq_w: Ut
    };
const W = 9999,
    K = 9799,
    Vt = 1,
    ce = 200;

function O(s, e, t, a) {
    const c = r => {
            const d = a - K > 0 ? a - K - t : -t,
                u = Math.min(W, t + K);
            return r === "left" ? {
                left: d,
                right: a - t,
                pos: t
            } : r === "right" ? {
                left: t - a,
                right: u - a,
                pos: a
            } : {
                left: -t,
                right: W - a,
                pos: (a - t) / 2 + t
            }
        },
        l = r => {
            const d = a === W ? Vt - t : -t,
                u = t === 0 ? 9998 - a : W - a;
            return r === "left" ? {
                left: d,
                right: a - t - ce,
                pos: t
            } : r === "right" ? {
                left: t - a + ce,
                right: u,
                pos: a
            } : {
                left: -t,
                right: W - a,
                pos: (a - t) / 2 + t
            }
        };
    let i;
    return e ? i = c(s) : i = l(s), {
        left: Math.round(i.left),
        right: Math.round(i.right),
        pos: Number(i.pos)
    }
}

function Q({
    type: s,
    size: e,
    className: t,
    centerHover: a,
    set: c = () => {},
    moving: l
}) {
    const i = x(),
        r = () => ({
            left: i.low,
            right: i.high,
            center: (i.high - i.low) / 2 + i.low
        }),
        d = (g, m) => {
            const I = new k(g).add(m).round().toNumber();
            return Number(I)
        },
        u = O(s, i.isIn, i.low, i.high),
        [w, C] = h.exports.useState(r()),
        [B, T] = h.exports.useState(u.pos),
        [G, v] = $e({
            data: u,
            dragging: !1
        }),
        y = () => {
            const g = O(s, i.isIn, i.low, i.high);
            v({
                data: g
            }), T(g.pos), C(r())
        };
    h.exports.useEffect(() => {
        G.dragging || y()
    }, [i.low, i.high]);
    const M = h.exports.useRef(ze(() => {
            i.sounds.playSound("rangeSound")
        }, 20)),
        f = qe({
            onDrag: ({
                movement: [g]
            }) => {
                G.dragging || v({
                    dragging: !0
                });
                let m = Number(new k(g).div(e / W).toFixed(2));
                const {
                    left: I,
                    right: _
                } = G.data;
                m > I && m < _ && M.current(), m = m < I ? I : m > _ ? _ : m;
                const J = d(m, w[s]);
                T(J), s === "left" ? i.low = J : s === "right" ? i.high = J : (i.low = d(m, w.left), i.high = d(m, w.right))
            },
            onDragEnd: () => {
                const g = O(s, i.isIn, i.low, i.high);
                C(r()), v({
                    data: g,
                    dragging: !1
                })
            }
        }),
        p = s === "center";
    return n("button", H(E({}, f()), {
        style: {
            left: B / 100 + "%",
            zIndex: p ? 9 : l === s ? 11 : 10
        },
        className: de(Yt, t),
        onMouseEnter: () => c(!0),
        onMouseLeave: () => c(!1),
        children: o("div", {
            className: "num",
            children: [n("img", {
                draggable: !1,
                className: p ? "img-center" : "img-sider",
                alt: "img",
                src: N[s]
            }), s !== "center" ? n("div", {
                className: "tips" + (a ? " hover-center" : ""),
                children: n("span", {
                    children: B
                })
            }) : null]
        })
    }))
}
const Yt = "g1hur1xx";
const Jt = s => Number(new k(99).div(s).toFixed(2)),
    z = s => {
        const e = new k(99).div(s).toFixed(4, k.ROUND_DOWN);
        return Number(e)
    },
    Lt = me.memo(function({
        betLeft: e,
        betRight: t,
        isBetting: a,
        isIn: c,
        currencyName: l,
        amount: i
    }) {
        const r = x(),
            d = A(),
            u = r.getChanceByPosition(),
            [w, C] = h.exports.useState(z(u)),
            B = v => {
                let y = Jt(v),
                    M = z(y);
                C(M), r.changeChance(y)
            },
            T = () => {
                const v = r.getChanceByPosition();
                return z(v)
            },
            G = i.mul(T());
        return h.exports.useEffect(() => {
            C(T())
        }, [e, t, c]), o("div", {
            className: Xt,
            children: [n(se, {
                label: d("common.payout"),
                size: "small",
                value: w,
                onChange: v => B(v),
                precision: 4,
                disabled: a,
                min: 1.0102,
                max: 9900,
                children: n("span", {
                    className: "right-info",
                    children: "x"
                })
            }), n(ge, {
                label: d("common.win_amount"),
                className: "win-amount" + (a ? " betting-amount" : ""),
                size: "small",
                currencyName: l,
                value: G.toNumber(),
                onChange: () => {},
                readOnly: !0
            }), n(se, {
                label: d("game.dice.winChance"),
                size: "small",
                value: u,
                onChange: v => {
                    r.changeChance(v)
                },
                max: 98,
                disabled: a,
                min: .01,
                precision: 2,
                className: "win-change",
                children: o("div", {
                    className: "right-info",
                    children: [n("span", {
                        className: "right-percent",
                        children: "%"
                    }), n("button", {
                        disabled: a,
                        onClick: () => r.changeChance(.01),
                        className: "amount-scale",
                        children: "Min"
                    }), n("button", {
                        disabled: a,
                        onClick: () => {
                            const y = r.getChanceByPosition() - 5;
                            y < .01 ? r.changeChance(.01) : r.changeChance(y)
                        },
                        className: "amount-scale",
                        children: "-5"
                    }), n("button", {
                        disabled: a,
                        onClick: () => {
                            const y = r.getChanceByPosition() + 5;
                            y > 98 ? r.changeChance(98) : r.changeChance(y)
                        },
                        className: "amount-scale",
                        children: "+5"
                    }), n("button", {
                        disabled: a,
                        onClick: () => r.changeChance(98),
                        className: "amount-scale",
                        children: "Max"
                    })]
                })
            })]
        })
    });
$({
    cl1: [R("#31343c", .4), "#f5f6fa"],
    cl2: ["none", "0 1px 9px 0 rgba(0, 0, 0, 0.12)"],
    cl3: ["rgba(49, 52, 60, 0.5)", "#fff"],
    cl4: ["#99a4b0", "#5f6975"],
    cl5: ["#31343c", R("#dadde6", .4)],
    cl6: ["#3c404a", R("#dadde6", .2)]
});
const Xt = "coq13w";
const Kt = P(() => {
        const s = x(),
            e = Ue(),
            t = h.exports.useRef(!0),
            a = h.exports.useRef(null),
            [c, l] = h.exports.useState(!1),
            i = h.exports.useRef(null),
            r = new k(s.gameResult).div(100).toFixed(2),
            d = h.exports.useRef(s.gameResult);
        h.exports.useEffect(() => {
            l(!1), a.current = setTimeout(() => {
                e() && l(!0)
            }, 400);
            const w = s.gameResult,
                C = {
                    val: d.current
                };
            t.current || s.sounds.playSound("moveSound");
            const B = s.settings.fastEnable ? .01 : .4;
            return fe.to(C, B, {
                val: w,
                onUpdate: () => {
                    i.current && (i.current.innerHTML = Math.round(C.val).toString())
                },
                onComplete: () => {
                    s.gameIsWin && !t.current && s.sounds.playSound("winSound")
                }
            }), () => {
                clearInterval(a.current), d.current = Number(w), t.current = !1
            }
        }, [s.gameResult]);
        const u = s.gameIsWin ? "win" : "lose";
        return o(q, {
            children: [n("div", {
                className: Qt,
                style: {
                    transform: `translate3d(${r}%, 0 ,0)`
                },
                children: o("div", {
                    className: "result " + (s.gameIsWin ? "result_win" : "result_lose"),
                    children: [n("img", {
                        alt: "bg",
                        src: S.isDarken ? N.win : N.win_w
                    }), o("div", {
                        className: "dice",
                        children: [n("p", {
                            className: u,
                            ref: i
                        }), n("img", {
                            alt: "dice",
                            className: c ? "big" : "",
                            src: N.dice
                        })]
                    })]
                })
            }), n("div", {
                className: "input-result",
                style: {
                    transform: `translate3d(${r}%, 0 ,0)`
                },
                children: n("div", {})
            })]
        })
    }),
    Qt = "rjvl9na";
const Zt = [{
        label: "IN",
        value: null
    }, {
        label: "OUT",
        value: null
    }],
    en = P(function() {
        const e = x();
        return h.exports.useEffect(() => {
            const {
                low: t,
                high: a
            } = e;
            e.isIn ? a - t > 9800 && e.changeChance(98) : a - t < 2 && e.changeChance(98)
        }, [e.isIn]), o(Ve, {
            className: an,
            children: [o("div", {
                className: "dice-area",
                children: [n(Ye, {
                    className: rn,
                    value: e.isIn ? 0 : 1,
                    onChange: t => e.isIn = !(t > 0),
                    tabs: Zt
                }), o("div", {
                    className: "area",
                    children: [n(sn, {}), n(tn, {}), n(Lt, {
                        betLeft: e.low,
                        betRight: e.high,
                        isBetting: e.isBetting,
                        isIn: e.isIn,
                        currencyName: e.currencyName,
                        amount: e.amount
                    })]
                })]
            }), n(Je, {})]
        })
    }),
    tn = P(() => {
        const s = x(),
            [e, t] = h.exports.useState(0),
            [a, c] = h.exports.useState(!1),
            [l, i] = h.exports.useState(""),
            r = pe(({
                width: u
            }) => t(u)),
            d = new k(s.high).sub(s.low).toNumber();
        return h.exports.useEffect(() => i("left"), [s.low]), h.exports.useEffect(() => i("right"), [s.high]), n("div", {
            className: ln,
            children: n("div", {
                className: "input",
                children: o("div", {
                    className: "slider" + (s.isIn ? "" : " active"),
                    ref: r,
                    children: [n(Kt, {}), n("div", {
                        className: "slider-inner" + (s.isIn ? " active" : ""),
                        style: {
                            width: d / 100 + "%",
                            left: s.low / 100 + "%"
                        }
                    }), n(Q, {
                        type: "left",
                        size: e,
                        className: "slider-button left",
                        centerHover: a,
                        moving: l
                    }), n(Q, {
                        type: "center",
                        size: e,
                        className: "slider-button center",
                        centerHover: a,
                        set: c
                    }), n(Q, {
                        type: "right",
                        size: e,
                        className: "slider-button right",
                        centerHover: a,
                        moving: l
                    }), o("div", {
                        className: "num-info",
                        children: [n("span", {
                            children: "0"
                        }), n("span", {
                            children: "2500"
                        }), n("span", {
                            children: "5000"
                        }), n("span", {
                            children: "7500"
                        }), n("span", {
                            children: "9999"
                        })]
                    })]
                })
            })
        })
    }),
    nn = s => S.isMobile || s > 600 ? 1 : Number((s / 600).toFixed(4)),
    sn = P(() => {
        const s = A(),
            e = x(),
            t = h.exports.useRef(null),
            [a, c] = h.exports.useState(1),
            [l, i] = h.exports.useState(!1),
            r = pe(({
                width: f
            }) => c(nn(f))),
            d = h.exports.useRef(!0),
            [u, w] = h.exports.useState({
                left: e.low,
                right: e.high
            }),
            C = h.exports.useRef(e.gameResult),
            B = () => {
                const {
                    low: f,
                    high: p
                } = e, g = Math.round(9999 - p), m = Math.round(9999 - f);
                e.low = g, e.high = m
            },
            T = (f, p, g) => {
                let m = p;
                const I = Number(f);
                if (I || I == 0) {
                    const _ = new k(I).sub(p).toNumber();
                    _ < g.left ? m = Number((p + g.left).toFixed(2)) : _ > g.right ? m = Number((p + g.right).toFixed(2)) : m = Number((p + _).toFixed(2))
                }
                return m
            },
            G = e.settings.fastEnable ? .1 : .4;
        h.exports.useEffect(() => {
            const f = e.gameResult,
                p = {
                    val: C.current
                };
            return fe.to(p, G, {
                val: f,
                onUpdate: () => {
                    if (t.current) {
                        let g = Bt(Math.round(p.val).toString(), 4, "0");
                        for (let m = 0; m < t.current.children.length; m++) t.current.children[m].innerHTML = g[m]
                    }
                }
            }), () => {
                C.current = f
            }
        }, [e.gameResult]), h.exports.useEffect(() => (!d.current && !l && i(!0), w({
            left: e.low,
            right: e.high
        }), () => {
            d.current = !1
        }), [e.low, e.high]), h.exports.useEffect(() => {
            l && e.isBetting && i(!1)
        }, [e.isBetting]);
        const v = () => {
                e.isBetting || i(!0)
            },
            y = S.isDarken ? N.less : N.less_w,
            M = S.isDarken ? N.lesseq : N.lesseq_w;
        return o("div", {
            className: on,
            ref: r,
            style: {
                transform: `scale(${a})`
            },
            children: [n("div", {
                className: "left",
                children: e.isIn ? o("p", {
                    children: [n("span", {
                        className: "left-num num",
                        children: e.low
                    }), n("span", {
                        className: "com",
                        children: n("img", {
                            alt: "less",
                            src: M
                        })
                    })]
                }) : o(q, {
                    children: [e.low != 0 && o("p", {
                        children: [n("span", {
                            className: "left-num num",
                            children: "0"
                        }), n("span", {
                            className: "com",
                            children: n("img", {
                                alt: "less",
                                src: M
                            })
                        })]
                    }), e.high != 9999 && o("p", {
                        className: "last",
                        children: [n("span", {
                            className: "left-num num",
                            children: e.high
                        }), n("span", {
                            className: "com",
                            children: n("img", {
                                alt: "less",
                                src: y
                            })
                        })]
                    })]
                })
            }), n("div", {
                className: "center" + (l ? " open" : ""),
                onMouseEnter: v,
                onClick: v,
                children: o("div", {
                    className: "center-wrap",
                    children: [n("div", {
                        className: "change-num",
                        children: o("div", {
                            className: "bg",
                            ref: t,
                            children: [n("span", {
                                className: "flex-center"
                            }), n("span", {
                                className: "flex-center"
                            }), n("span", {
                                className: "flex-center"
                            }), n("span", {
                                className: "flex-center"
                            })]
                        })
                    }), o("div", {
                        className: "choose-num",
                        children: [o("p", {
                            className: "title ttu",
                            children: [n(X, {
                                name: "Chip"
                            }), n("span", {
                                children: "Choose Numbers"
                            }), n(X, {
                                name: "Chip"
                            })]
                        }), o("div", {
                            className: "nums",
                            children: [o("div", {
                                className: "item low",
                                children: [n("span", {
                                    children: s("common.low")
                                }), n(ae, {
                                    value: u.left,
                                    disabled: e.isBetting,
                                    onChange: f => {
                                        if (f.length > 4) return !1;
                                        w(H(E({}, u), {
                                            left: f
                                        }));
                                        const p = O("left", e.isIn, e.low, e.high),
                                            g = T(f, e.low, p);
                                        e.low = g
                                    },
                                    onBlur: () => {
                                        w(H(E({}, u), {
                                            left: e.low
                                        }))
                                    }
                                })]
                            }), n(X, {
                                className: "exchange-icon",
                                name: "Exchange",
                                onClick: B
                            }), o("div", {
                                className: "item high",
                                children: [n("span", {
                                    children: s("common.high")
                                }), n(ae, {
                                    value: u.right,
                                    disabled: e.isBetting,
                                    onChange: f => {
                                        if (f.length > 4) return !1;
                                        w(H(E({}, u), {
                                            right: f
                                        }));
                                        const p = O("right", e.isIn, e.low, e.high),
                                            g = T(f, e.high, p);
                                        e.high = g
                                    },
                                    onBlur: () => {
                                        w(H(E({}, u), {
                                            right: e.high
                                        }))
                                    }
                                })]
                            })]
                        })]
                    })]
                })
            }), n("div", {
                className: "right",
                children: e.isIn ? o("p", {
                    children: [n("span", {
                        className: "com",
                        children: n("img", {
                            alt: "less",
                            src: M
                        })
                    }), n("span", {
                        className: "right-num num",
                        children: e.high
                    })]
                }) : o(q, {
                    children: [e.low != 0 && o("p", {
                        children: [n("span", {
                            className: "com",
                            children: n("img", {
                                alt: "less",
                                src: y
                            })
                        }), n("span", {
                            className: "right-num num",
                            children: e.low
                        })]
                    }), e.high != 9999 && o("p", {
                        className: "last",
                        children: [n("span", {
                            className: "com",
                            children: n("img", {
                                alt: "less",
                                src: M
                            })
                        }), n("span", {
                            className: "right-num num",
                            children: 9999
                        })]
                    })]
                })
            })]
        })
    }),
    an = "g1fzhqgs";
$({
    cl1: ["none", "#f5f6fa"],
    cl2: ["0.5", "0.8"],
    cl3: ["#151518", "#666c85"],
    cl4: ["#212328", "#5b6178"],
    cl5: [R("#99a4b0", .8), "#ffffff"],
    cl6: ["#7e8791", "#99a4b0"],
    cl7: [R("#99a4b0", .8), "#99a4b0"],
    cl8: ["rgba(33, 35, 40, 0.33)", "#7d849d"],
    cl9: ["linear-gradient(to bottom, #37373f -44%, #19191e)", "linear-gradient(to bottom, #9098bd -44%, #6f7694)"]
});
const on = "cbu70lw";
$({
    cl1: [R("#31343c", .4), "#f5f6fa"],
    cl2: ["#f5f6f7", "#f5f6fa"]
});
const ln = "g1cxglch";
$({
    cl1: [R("#31343c", .7), "#f5f6fa"],
    cl2: ["rgba(153,164,176,0.6)", "rgba(95,105,117,0.6)"],
    cl3: ["#ffffff", "#31373d"]
});
const rn = "t1u6il63",
    cn = P(() => {
        const s = x(),
            e = V.useSingleDetail();
        return o(Le, {
            children: [n(Xe, {
                list: s.myBets,
                keyof: "betId",
                onDetail: e,
                getResult: t => t.gameValue
            }), n(en, {})]
        })
    });
var hn = P(function() {
    const e = x(),
        t = e.autoBet,
        a = A(),
        c = () => {
            t.isRunning ? t.stop() : t.start().catch(ve)
        },
        l = () => n(be, {
            className: "bet-button",
            size: "big",
            type: "conic",
            onClick: c,
            children: e.autoBet.isRunning ? a("common.stop_auto_bet") : a("common.start_auto_bet")
        });
    return o("div", {
        className: un,
        children: [S.isMobile && l(), n(D.CoinInput, {
            checkIncrease: !0
        }), n(D.TimesInput, {}), n(D.IncreaseInput, {}), n(D.IncreaseInput, {
            isLose: !0
        }), n(D.StopInput, {}), n(D.StopInput, {
            isLose: !0
        }), n(Ke, {}), !S.isMobile && l()]
    })
});
const un = "a1i5753t";
const dn = P(function() {
        const e = x(),
            t = A();
        ie.dict[e.currencyName];
        const a = () => n(be, {
                className: "bet-button",
                type: "conic",
                disabled: e.isBetting,
                size: "big",
                onClick: () => e.handGameBet(),
                children: t("game.dice.rollnow")
            }),
            c = () => {
                const l = e.getChanceByPosition();
                return z(l)
            };
        return c(), o("div", {
            className: mn,
            children: [S.isMobile && a(), n(D.CoinInput, {}), n(ge, {
                label: t("common.win_amount"),
                size: "small",
                currencyName: ie.current,
                value: e.amount.mul(c()).toNumber(),
                onChange: () => {},
                disabled: !0
            }), !S.isMobile && a()]
        })
    }),
    mn = "m18l34pl",
    gn = me.memo(() => {
        const s = x(),
            e = A(),
            t = [{
                title: e("common.game_intro"),
                node: n(Tt, {
                    game: s
                })
            }, {
                title: e("common.fairness"),
                node: "/ultimatedice_help/fairness"
            }, {
                title: e("common.bankroll"),
                node: n(Rt, {
                    game: s
                })
            }];
        return n(Qe, {
            manualControl: n(dn, {}),
            autoControl: n(hn, {}),
            gameView: n(cn, {}),
            tabs: [{
                label: e("common.all_bet"),
                value: V.AllBet
            }, {
                label: e("common.my_bet"),
                value: V.MyBet
            }],
            actions: [n(Ze, {}), n(et, {}), n(tt, {}), n(nt, {}), n(st, {}), n(at, {
                list: t
            })]
        })
    }),
    Y = U.Reader,
    Ae = U.Writer,
    F = U.roots.gameUltimateDice || (U.roots.gameUltimateDice = {});
F.BetValue = (() => {
    function s(e) {
        if (e)
            for (let t = Object.keys(e), a = 0; a < t.length; ++a) e[t[a]] != null && (this[t[a]] = e[t[a]])
    }
    return s.prototype.low = 0, s.prototype.high = 0, s.prototype.betType = "", s.encode = function(t, a) {
        return a || (a = Ae.create()), t.low != null && Object.hasOwnProperty.call(t, "low") && a.uint32(8).sint32(t.low), t.high != null && Object.hasOwnProperty.call(t, "high") && a.uint32(16).sint32(t.high), t.betType != null && Object.hasOwnProperty.call(t, "betType") && a.uint32(26).string(t.betType), a
    }, s.decode = function(t, a) {
        t instanceof Y || (t = Y.create(t));
        let c = a === void 0 ? t.len : t.pos + a,
            l = new F.BetValue;
        for (; t.pos < c;) {
            let i = t.uint32();
            switch (i >>> 3) {
                case 1:
                    l.low = t.sint32();
                    break;
                case 2:
                    l.high = t.sint32();
                    break;
                case 3:
                    l.betType = t.string();
                    break;
                default:
                    t.skipType(i & 7);
                    break
            }
        }
        return l
    }, s
})();
F.GameValue = (() => {
    function s(e) {
        if (e)
            for (let t = Object.keys(e), a = 0; a < t.length; ++a) e[t[a]] != null && (this[t[a]] = e[t[a]])
    }
    return s.prototype.gameResult = 0, s.encode = function(t, a) {
        return a || (a = Ae.create()), t.gameResult != null && Object.hasOwnProperty.call(t, "gameResult") && a.uint32(8).sint32(t.gameResult), a
    }, s.decode = function(t, a) {
        t instanceof Y || (t = Y.create(t));
        let c = a === void 0 ? t.len : t.pos + a,
            l = new F.GameValue;
        for (; t.pos < c;) {
            let i = t.uint32();
            switch (i >>> 3) {
                case 1:
                    l.gameResult = t.sint32();
                    break;
                default:
                    t.skipType(i & 7);
                    break
            }
        }
        return l
    }, s
})();
var fn = "/assets/range.e3b88736.mp3",
    pn = "/assets/move.5b30624c.mp3",
    bn = "/assets/win.ae4b0d6d.mp3";
const vn = {
        rangeSound: fn,
        moveSound: pn,
        winSound: bn
    },
    wn = we.decode(F.GameValue);
class yn extends it {
    constructor() {
        super({
            name: "UltimateDice",
            namespace: "/g/ud",
            sounds: vn,
            fairLink: "/ultimatedice_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/ultimatedice.html"
        }, gn);
        b(this, "total", 9999);
        b(this, "betInterval", 350);
        b(this, "betStartTime", new Date().getTime());
        b(this, "isIn", !0);
        b(this, "gameResult", 5e3);
        b(this, "low", 2500);
        b(this, "high", 7499);
        b(this, "gameIsWin", !1);
        b(this, "needDeduction", !1);
        b(this, "handGameBet", () => {
            this.isBetting || this.handleBet().catch(ve)
        });
        b(this, "onBetRequest", async t => {
            let a = await t;
            this.gameResult = a.gameValue, this.gameIsWin = a.odds > 0;
            let c = 400;
            if (this.settings.fastEnable) {
                const l = new Date().getTime() - this.betStartTime;
                c = l > this.betInterval ? 0 : this.betInterval - l
            }
            return await ct(c), a
        });
        b(this, "changeToggleWin", () => {
            this.isBetting || (this.isIn = !this.isIn)
        });
        b(this, "lowerTarget", () => {
            if (!this.isBetting) {
                const t = this.getChanceByPosition();
                this.changeChance(t - 1)
            }
        });
        b(this, "higerTarget", () => {
            if (!this.isBetting) {
                const t = this.getChanceByPosition();
                this.changeChance(t + 1)
            }
        });
        b(this, "getChanceByPosition", (t, a) => {
            const c = t || this.low,
                l = a || this.high,
                i = new k(l).sub(c).add(1).div(100).toFixed(2),
                r = Number(i);
            return this.isIn ? r : Number((100 - r).toFixed(2))
        });
        b(this, "changeChance", t => {
            const a = this.getChanceByPosition();
            if (a == t) return;
            const c = new k(a).sub(t),
                l = -new k(c).mul(100).toNumber(),
                i = l % 2 === 0 ? l / 2 : Math.floor(l / 2),
                r = l % 2 === 0 ? l / 2 : Math.ceil(l / 2);
            let d = this.isIn ? this.low - i : this.low + i,
                u = this.isIn ? this.high + r : this.high - r;
            d < 0 ? (u += -d, d = 0) : u > this.total && (d -= u - this.total, u = this.total), this.low = Math.round(d), this.high = Math.round(u)
        });
        ot(this, {
            isIn: j,
            gameResult: j,
            low: j,
            high: j,
            gameIsWin: j,
            maxProfit: lt
        }), this.addHotkey("q", this.changeToggleWin, "Toggle condition to win"), this.addHotkey("w", this.lowerTarget, "Lower the target"), this.addHotkey("e", this.higerTarget, "Higher the target"), rt(() => {
            this.autoBet.interval = this.settings.fastEnable ? 500 : 1500
        });
        const t = this.hotkeyList.find(a => a.key == "space");
        t && (t.handler = () => (this.controlIdx === 1 ? this.autoBet.isRunning ? this.autoBet.stop() : this.autoBet.start() : this.handGameBet(), !1)), this.on("betStart", () => {
            this.betStartTime = new Date().getTime(), this.sounds.playSound("rangeSound")
        })
    }
    get maxProfit() {
        const t = this.getChanceByPosition();
        return this.amount.mul(99).div(t).sub(this.amount)
    }
    gameValueDecoder(t) {
        return wn(t).gameResult
    }
    betValue() {
        return we.encode(F.BetValue)({
            low: this.low,
            high: this.high,
            betType: this.isIn ? "in" : "out"
        })
    }
}
const Be = new yn;
var Nn = Be;
window.prod = Be;

function Mn({
    bodyLock: s
}) {
    const e = A();
    return n(te, {
        title: e("common.fairness"),
        children: n(ue, {
            bodyLock: s,
            children: o("div", {
                className: "item",
                children: [n("h2", {
                    children: "How are results calculated?"
                }), o("div", {
                    className: "help-content",
                    children: [n("p", {
                        children: "To get the results."
                    }), o("ul", {
                        children: [n("li", {
                            children: "First we calculate the hash value of the combination with HMAC_SHA256. This gives us a 64-character hexadecimal string: hash = HMAC_SHA256 (clientSeed:nonce, serverSeed)."
                        }), n("li", {
                            children: "Finally, we take 8 characters of the hash and convert it to an int32 value. Then we divide the converted value by 0x100000000, multiply it by 10000 so that the resulting number conforms to the constraints of the dice range."
                        })]
                    }), n("br", {}), n("p", {
                        children: "Note: A new seed must be set to verify the previous data (the server seed is encrypted)."
                    }), n("p", {}), n("p", {
                        children: "Did you really need to know this? Probably not. It\u2019s there for those who expect transparency and precision in a provably fair game of chance."
                    }), n("p", {
                        children: 'We put our "cards on the table." '
                    }), n("p", {
                        children: "Good luck!"
                    })]
                })]
            })
        })
    })
}
const Cn = (s, e, t) => {
        let a = `${Nn.config.validateLink}?s=${s}&c=${e}&n=${t}`;
        window.open(a)
    },
    kn = V.withSingleDetail({
        onValidate: Cn,
        result: ({
            betLog: s
        }) => {
            const e = A(),
                {
                    low: t,
                    high: a,
                    betType: c
                } = s.bv,
                l = s.gv,
                i = c == "in" ? "#5da000" : "#ed6300";
            return o("div", {
                className: xn,
                children: [n("div", {
                    className: "label",
                    children: e("common.result")
                }), n("div", {
                    className: "wrap flex-center",
                    children: o("div", {
                        className: "bg flex-center",
                        children: [o("div", {
                            className: de(In, "flex-center", "graph-result"),
                            children: [n("div", {
                                className: "result-img",
                                style: {
                                    left: `${l/100}%`
                                },
                                children: n("span", {
                                    children: l
                                })
                            }), o("div", {
                                className: "result",
                                style: {
                                    background: c != "in" ? "#5da000" : "#ed6300"
                                },
                                children: [n("div", {
                                    className: "inner",
                                    style: {
                                        background: i,
                                        width: `${(a-t)/100}%`,
                                        left: `${t/100}%`
                                    }
                                }), n("div", {
                                    className: "left-hand hand",
                                    style: {
                                        left: `${t/100}%`
                                    },
                                    children: n("img", {
                                        alt: "",
                                        src: N.left
                                    })
                                }), n("div", {
                                    className: "right-hand hand",
                                    style: {
                                        left: `${a/100}%`
                                    },
                                    children: n("img", {
                                        alt: "",
                                        src: N.right
                                    })
                                })]
                            })]
                        }), n("div", {
                            className: "more",
                            children: a - t > 1e3 ? o(q, {
                                children: [n("span", {
                                    className: "low",
                                    style: {
                                        left: `${t/100}%`
                                    },
                                    children: t
                                }), n("span", {
                                    className: "high",
                                    style: {
                                        left: `${a/100}%`
                                    },
                                    children: a
                                })]
                            }) : o("div", {
                                className: "low-high",
                                style: {
                                    left: `${(a+t)/200}%`
                                },
                                children: [n("span", {
                                    children: t
                                }), n("img", {
                                    alt: "low-hig",
                                    src: S.isDarken ? N.lowhigh : N.lowhigh_w
                                }), n("span", {
                                    children: a
                                })]
                            })
                        })]
                    })
                })]
            })
        }
    });
$({
    cl1: ["#17181b", "#f5f6fa"],
    cl2: [R("#31343c", .4), "#edeef2"]
});
const xn = "r27nnow",
    In = "gyxnmca";
var Rn = kn;
export {
    Rt as Bankroll, Rn as Detail, Mn as Fairness, Nn as Game
};
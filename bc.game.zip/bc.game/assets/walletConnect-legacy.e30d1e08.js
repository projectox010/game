System.register(["./index-legacy.1416f96c.js", "./index-legacy.876ed6a5.js", "./dijkstra-legacy.bb67fe84.js"], (function(t) {
    "use strict";
    var e, n, r, o, i;
    return {
        setters: [function(t) {
            e = t.aM, n = t.aN, r = t.y
        }, function(t) {
            o = t.b
        }, function(t) {
            i = t.d
        }],
        execute: function() {
            t({
                sendTransaction: async function(t, e) {
                    const n = await Hi();
                    return n.sendTransaction({
                        from: n.accounts[0],
                        to: t,
                        value: `0x${Ji(e).toString(16)}`
                    })
                },
                signPersonalMessage: async function(t) {
                    const e = await Hi(),
                        n = e.accounts[0];
                    return {
                        signature: await e.signPersonalMessage([(r = t, Tt(r).buffer), n]),
                        publicAddress: n
                    };
                    var r
                }
            });
            var s = {},
                a = {};
            Object.defineProperty(a, "__esModule", {
                value: !0
            });
            var l = a.getLocalStorage = a.getLocalStorageOrThrow = a.getCrypto = a.getCryptoOrThrow = a.getLocation = a.getLocationOrThrow = a.getNavigator = a.getNavigatorOrThrow = a.getDocument = a.getDocumentOrThrow = a.getFromWindowOrThrow = a.getFromWindow = void 0;

            function u(t) {
                let e;
                return "undefined" != typeof window && void 0 !== window[t] && (e = window[t]), e
            }
            var c = a.getFromWindow = u;

            function h(t) {
                const e = u(t);
                if (!e) throw new Error(`${t} is not defined in Window`);
                return e
            }
            var d = a.getFromWindowOrThrow = h,
                f = a.getDocumentOrThrow = function() {
                    return h("document")
                },
                p = a.getDocument = function() {
                    return u("document")
                },
                m = a.getNavigatorOrThrow = function() {
                    return h("navigator")
                },
                g = a.getNavigator = function() {
                    return u("navigator")
                },
                _ = a.getLocationOrThrow = function() {
                    return h("location")
                },
                v = a.getLocation = function() {
                    return u("location")
                },
                w = a.getCryptoOrThrow = function() {
                    return h("crypto")
                },
                y = a.getCrypto = function() {
                    return u("crypto")
                },
                b = a.getLocalStorageOrThrow = function() {
                    return h("localStorage")
                };
            l = a.getLocalStorage = function() {
                return u("localStorage")
            }, Object.defineProperty(s, "__esModule", {
                value: !0
            });
            var M = s.getWindowMetadata = void 0;
            const k = a;
            M = s.getWindowMetadata = function() {
                let t, e;
                try {
                    t = k.getDocumentOrThrow(), e = k.getLocationOrThrow()
                } catch (Mo) {
                    return null
                }

                function n(...e) {
                    const n = t.getElementsByTagName("meta");
                    for (let t = 0; t < n.length; t++) {
                        const r = n[t],
                            o = ["itemprop", "property", "name"].map((t => r.getAttribute(t))).filter((t => !!t && e.includes(t)));
                        if (o.length && o) {
                            const t = r.getAttribute("content");
                            if (t) return t
                        }
                    }
                    return ""
                }
                const r = function() {
                        let e = n("name", "og:site_name", "og:title", "twitter:title");
                        return e || (e = t.title), e
                    }(),
                    o = n("description", "og:description", "twitter:description", "keywords"),
                    i = e.origin,
                    s = function() {
                        const n = t.getElementsByTagName("link"),
                            r = [];
                        for (let t = 0; t < n.length; t++) {
                            const o = n[t],
                                i = o.getAttribute("rel");
                            if (i && i.toLowerCase().indexOf("icon") > -1) {
                                const t = o.getAttribute("href");
                                if (t)
                                    if (-1 === t.toLowerCase().indexOf("https:") && -1 === t.toLowerCase().indexOf("http:") && 0 !== t.indexOf("//")) {
                                        let n = e.protocol + "//" + e.host;
                                        if (0 === t.indexOf("/")) n += t;
                                        else {
                                            const r = e.pathname.split("/");
                                            r.pop(), n += r.join("/") + "/" + t
                                        }
                                        r.push(n)
                                    } else if (0 === t.indexOf("//")) {
                                    const n = e.protocol + t;
                                    r.push(n)
                                } else r.push(t)
                            }
                        }
                        return r
                    }();
                return {
                    description: o,
                    url: i,
                    icons: s,
                    name: r
                }
            };
            var x = globalThis && globalThis.__spreadArrays || function() {
                    for (var t = 0, e = 0, n = arguments.length; e < n; e++) t += arguments[e].length;
                    var r = Array(t),
                        o = 0;
                    for (e = 0; e < n; e++)
                        for (var i = arguments[e], s = 0, a = i.length; s < a; s++, o++) r[o] = i[s];
                    return r
                },
                S = function(t, e, n) {
                    this.name = t, this.version = e, this.os = n, this.type = "browser"
                },
                E = function(t) {
                    this.version = t, this.type = "node", this.name = "node", this.os = process.platform
                },
                C = function(t, e, n, r) {
                    this.name = t, this.version = e, this.os = n, this.bot = r, this.type = "bot-device"
                },
                A = function() {
                    this.type = "bot", this.bot = !0, this.name = "bot", this.version = null, this.os = null
                },
                I = function() {
                    this.type = "react-native", this.name = "react-native", this.version = null, this.os = null
                },
                R = /(nuhk|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask\ Jeeves\/Teoma|ia_archiver)/,
                T = [
                    ["aol", /AOLShield\/([0-9\._]+)/],
                    ["edge", /Edge\/([0-9\._]+)/],
                    ["edge-ios", /EdgiOS\/([0-9\._]+)/],
                    ["yandexbrowser", /YaBrowser\/([0-9\._]+)/],
                    ["kakaotalk", /KAKAOTALK\s([0-9\.]+)/],
                    ["samsung", /SamsungBrowser\/([0-9\.]+)/],
                    ["silk", /\bSilk\/([0-9._-]+)\b/],
                    ["miui", /MiuiBrowser\/([0-9\.]+)$/],
                    ["beaker", /BeakerBrowser\/([0-9\.]+)/],
                    ["edge-chromium", /EdgA?\/([0-9\.]+)/],
                    ["chromium-webview", /(?!Chrom.*OPR)wv\).*Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
                    ["chrome", /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
                    ["phantomjs", /PhantomJS\/([0-9\.]+)(:?\s|$)/],
                    ["crios", /CriOS\/([0-9\.]+)(:?\s|$)/],
                    ["firefox", /Firefox\/([0-9\.]+)(?:\s|$)/],
                    ["fxios", /FxiOS\/([0-9\.]+)/],
                    ["opera-mini", /Opera Mini.*Version\/([0-9\.]+)/],
                    ["opera", /Opera\/([0-9\.]+)(?:\s|$)/],
                    ["opera", /OPR\/([0-9\.]+)(:?\s|$)/],
                    ["ie", /Trident\/7\.0.*rv\:([0-9\.]+).*\).*Gecko$/],
                    ["ie", /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
                    ["ie", /MSIE\s(7\.0)/],
                    ["bb10", /BB10;\sTouch.*Version\/([0-9\.]+)/],
                    ["android", /Android\s([0-9\.]+)/],
                    ["ios", /Version\/([0-9\._]+).*Mobile.*Safari.*/],
                    ["safari", /Version\/([0-9\._]+).*Safari/],
                    ["facebook", /FBAV\/([0-9\.]+)/],
                    ["instagram", /Instagram\s([0-9\.]+)/],
                    ["ios-webview", /AppleWebKit\/([0-9\.]+).*Mobile/],
                    ["ios-webview", /AppleWebKit\/([0-9\.]+).*Gecko\)$/],
                    ["searchbot", /alexa|bot|crawl(er|ing)|facebookexternalhit|feedburner|google web preview|nagios|postrank|pingdom|slurp|spider|yahoo!|yandex/]
                ],
                O = [
                    ["iOS", /iP(hone|od|ad)/],
                    ["Android OS", /Android/],
                    ["BlackBerry OS", /BlackBerry|BB10/],
                    ["Windows Mobile", /IEMobile/],
                    ["Amazon OS", /Kindle/],
                    ["Windows 3.11", /Win16/],
                    ["Windows 95", /(Windows 95)|(Win95)|(Windows_95)/],
                    ["Windows 98", /(Windows 98)|(Win98)/],
                    ["Windows 2000", /(Windows NT 5.0)|(Windows 2000)/],
                    ["Windows XP", /(Windows NT 5.1)|(Windows XP)/],
                    ["Windows Server 2003", /(Windows NT 5.2)/],
                    ["Windows Vista", /(Windows NT 6.0)/],
                    ["Windows 7", /(Windows NT 6.1)/],
                    ["Windows 8", /(Windows NT 6.2)/],
                    ["Windows 8.1", /(Windows NT 6.3)/],
                    ["Windows 10", /(Windows NT 10.0)/],
                    ["Windows ME", /Windows ME/],
                    ["Open BSD", /OpenBSD/],
                    ["Sun OS", /SunOS/],
                    ["Chrome OS", /CrOS/],
                    ["Linux", /(Linux)|(X11)/],
                    ["Mac OS", /(Mac_PowerPC)|(Macintosh)/],
                    ["QNX", /QNX/],
                    ["BeOS", /BeOS/],
                    ["OS/2", /OS\/2/]
                ];

            function N(t) {
                return t ? B(t) : "undefined" == typeof document && "undefined" != typeof navigator && "ReactNative" === navigator.product ? new I : "undefined" != typeof navigator ? B(navigator.userAgent) : "undefined" != typeof process && process.version ? new E(process.version.slice(1)) : null
            }

            function B(t) {
                var e = function(t) {
                    return "" !== t && T.reduce((function(e, n) {
                        var r = n[0],
                            o = n[1];
                        if (e) return e;
                        var i = o.exec(t);
                        return !!i && [r, i]
                    }), !1)
                }(t);
                if (!e) return null;
                var n = e[0],
                    r = e[1];
                if ("searchbot" === n) return new A;
                var o = r[1] && r[1].split(/[._]/).slice(0, 3);
                o ? o.length < 3 && (o = x(o, function(t) {
                    for (var e = [], n = 0; n < t; n++) e.push("0");
                    return e
                }(3 - o.length))) : o = [];
                var i = o.join("."),
                    s = function(t) {
                        for (var e = 0, n = O.length; e < n; e++) {
                            var r = O[e],
                                o = r[0];
                            if (r[1].exec(t)) return o
                        }
                        return null
                    }(t),
                    a = R.exec(t);
                return a && a[1] ? new C(n, i, s, a[1]) : new S(n, i, s)
            }

            function P(t) {
                return N(t)
            }

            function L() {
                const t = P();
                return t && t.os ? t.os : void 0
            }

            function q() {
                const t = L();
                return !!t && t.toLowerCase().includes("android")
            }

            function U() {
                const t = L();
                return !!t && (t.toLowerCase().includes("ios") || t.toLowerCase().includes("mac") && navigator.maxTouchPoints > 1)
            }

            function j() {
                return !!L() && (q() || U())
            }

            function D() {
                const t = P();
                return !(!t || !t.name) && "node" === t.name.toLowerCase()
            }

            function z() {
                return !D() && !!Y()
            }
            const F = c,
                W = d,
                H = f,
                $ = p,
                J = m,
                Y = g,
                V = _,
                K = v,
                Z = w,
                Q = y,
                X = b,
                G = l;

            function tt() {
                return M()
            }
            const et = function(t) {
                    if ("string" != typeof t) throw new Error("Cannot safe json parse value of type " + typeof t);
                    try {
                        return JSON.parse(t)
                    } catch (e) {
                        return t
                    }
                },
                nt = function(t) {
                    return "string" == typeof t ? t : JSON.stringify(t)
                };

            function rt(t, e) {
                const n = nt(e),
                    r = G();
                r && r.setItem(t, n)
            }

            function ot(t) {
                let e = null,
                    n = null;
                const r = G();
                return r && (n = r.getItem(t)), e = n ? et(n) : n, e
            }

            function it(t) {
                const e = G();
                e && e.removeItem(t)
            }
            const st = "WALLETCONNECT_DEEPLINK_CHOICE";

            function at(t, e) {
                return t.filter((t => t.name.toLowerCase().includes(e.toLowerCase())))[0]
            }
            const lt = "https://registry.walletconnect.com";

            function ut(t, e = "mobile") {
                var n;
                return {
                    name: t.name || "",
                    shortName: t.metadata.shortName || "",
                    color: t.metadata.colors.primary || "",
                    logo: null !== (n = t.image_url.sm) && void 0 !== n ? n : "",
                    universalLink: t[e].universal || "",
                    deepLink: t[e].native || ""
                }
            }
            var ct = Object.freeze(Object.defineProperty({
                __proto__: null,
                detectEnv: P,
                detectOS: L,
                isAndroid: q,
                isIOS: U,
                isMobile: j,
                isNode: D,
                isBrowser: z,
                getFromWindow: F,
                getFromWindowOrThrow: W,
                getDocumentOrThrow: H,
                getDocument: $,
                getNavigatorOrThrow: J,
                getNavigator: Y,
                getLocationOrThrow: V,
                getLocation: K,
                getCryptoOrThrow: Z,
                getCrypto: Q,
                getLocalStorageOrThrow: X,
                getLocalStorage: G,
                getClientMeta: tt,
                safeJsonParse: et,
                safeJsonStringify: nt,
                setLocal: rt,
                getLocal: ot,
                removeLocal: it,
                mobileLinkChoiceKey: st,
                formatIOSMobile: function(t, e) {
                    const n = encodeURIComponent(t);
                    return e.universalLink ? `${e.universalLink}/wc?uri=${n}` : e.deepLink ? `${e.deepLink}${e.deepLink.endsWith(":")?"//":"/"}wc?uri=${n}` : ""
                },
                saveMobileLinkInfo: function(t) {
                    const e = t.href.split("?")[0];
                    rt(st, Object.assign(Object.assign({}, t), {
                        href: e
                    }))
                },
                getMobileRegistryEntry: at,
                getMobileLinkRegistry: function(t, e) {
                    let n = t;
                    return e && (n = e.map((e => at(t, e))).filter(Boolean)), n
                },
                getWalletRegistryUrl: function() {
                    return lt + "/api/v2/wallets"
                },
                getDappRegistryUrl: function() {
                    return lt + "/api/v2/dapps"
                },
                formatMobileRegistryEntry: ut,
                formatMobileRegistry: function(t, e = "mobile") {
                    return Object.values(t).filter((t => !!t[e].universal || !!t[e].native)).map((t => ut(t, e)))
                }
            }, Symbol.toStringTag, {
                value: "Module"
            }));
            const ht = ["session_request", "session_update", "exchange_key", "connect", "disconnect", "display_uri", "modal_closed", "transport_open", "transport_close", "transport_error"],
                dt = ["eth_sendTransaction", "eth_signTransaction", "eth_sign", "eth_signTypedData", "eth_signTypedData_v1", "eth_signTypedData_v2", "eth_signTypedData_v3", "eth_signTypedData_v4", "personal_sign", "wallet_addEthereumChain", "wallet_switchEthereumChain", "wallet_getPermissions", "wallet_requestPermissions", "wallet_registerOnboarding", "wallet_watchAsset", "wallet_scanQRCode"];
            var ft = {
                exports: {}
            };
            ! function(t, e) {
                function n(t, e) {
                    if (!t) throw new Error(e || "Assertion failed")
                }

                function r(t, e) {
                    t.super_ = e;
                    var n = function() {};
                    n.prototype = e.prototype, t.prototype = new n, t.prototype.constructor = t
                }

                function o(t, e, n) {
                    if (o.isBN(t)) return t;
                    this.negative = 0, this.words = null, this.length = 0, this.red = null, null !== t && ("le" !== e && "be" !== e || (n = e, e = 10), this._init(t || 0, e || 10, n || "be"))
                }
                var i;
                "object" == typeof t ? t.exports = o : e.BN = o, o.BN = o, o.wordSize = 26;
                try {
                    i = require("buffer").Buffer
                } catch (Mo) {}

                function s(t, e, n) {
                    for (var r = 0, o = Math.min(t.length, n), i = e; i < o; i++) {
                        var s = t.charCodeAt(i) - 48;
                        r <<= 4, r |= s >= 49 && s <= 54 ? s - 49 + 10 : s >= 17 && s <= 22 ? s - 17 + 10 : 15 & s
                    }
                    return r
                }

                function a(t, e, n, r) {
                    for (var o = 0, i = Math.min(t.length, n), s = e; s < i; s++) {
                        var a = t.charCodeAt(s) - 48;
                        o *= r, o += a >= 49 ? a - 49 + 10 : a >= 17 ? a - 17 + 10 : a
                    }
                    return o
                }
                o.isBN = function(t) {
                    return t instanceof o || null !== t && "object" == typeof t && t.constructor.wordSize === o.wordSize && Array.isArray(t.words)
                }, o.max = function(t, e) {
                    return t.cmp(e) > 0 ? t : e
                }, o.min = function(t, e) {
                    return t.cmp(e) < 0 ? t : e
                }, o.prototype._init = function(t, e, r) {
                    if ("number" == typeof t) return this._initNumber(t, e, r);
                    if ("object" == typeof t) return this._initArray(t, e, r);
                    "hex" === e && (e = 16), n(e === (0 | e) && e >= 2 && e <= 36);
                    var o = 0;
                    "-" === (t = t.toString().replace(/\s+/g, ""))[0] && o++, 16 === e ? this._parseHex(t, o) : this._parseBase(t, e, o), "-" === t[0] && (this.negative = 1), this.strip(), "le" === r && this._initArray(this.toArray(), e, r)
                }, o.prototype._initNumber = function(t, e, r) {
                    t < 0 && (this.negative = 1, t = -t), t < 67108864 ? (this.words = [67108863 & t], this.length = 1) : t < 4503599627370496 ? (this.words = [67108863 & t, t / 67108864 & 67108863], this.length = 2) : (n(t < 9007199254740992), this.words = [67108863 & t, t / 67108864 & 67108863, 1], this.length = 3), "le" === r && this._initArray(this.toArray(), e, r)
                }, o.prototype._initArray = function(t, e, r) {
                    if (n("number" == typeof t.length), t.length <= 0) return this.words = [0], this.length = 1, this;
                    this.length = Math.ceil(t.length / 3), this.words = new Array(this.length);
                    for (var o = 0; o < this.length; o++) this.words[o] = 0;
                    var i, s, a = 0;
                    if ("be" === r)
                        for (o = t.length - 1, i = 0; o >= 0; o -= 3) s = t[o] | t[o - 1] << 8 | t[o - 2] << 16, this.words[i] |= s << a & 67108863, this.words[i + 1] = s >>> 26 - a & 67108863, (a += 24) >= 26 && (a -= 26, i++);
                    else if ("le" === r)
                        for (o = 0, i = 0; o < t.length; o += 3) s = t[o] | t[o + 1] << 8 | t[o + 2] << 16, this.words[i] |= s << a & 67108863, this.words[i + 1] = s >>> 26 - a & 67108863, (a += 24) >= 26 && (a -= 26, i++);
                    return this.strip()
                }, o.prototype._parseHex = function(t, e) {
                    this.length = Math.ceil((t.length - e) / 6), this.words = new Array(this.length);
                    for (var n = 0; n < this.length; n++) this.words[n] = 0;
                    var r, o, i = 0;
                    for (n = t.length - 6, r = 0; n >= e; n -= 6) o = s(t, n, n + 6), this.words[r] |= o << i & 67108863, this.words[r + 1] |= o >>> 26 - i & 4194303, (i += 24) >= 26 && (i -= 26, r++);
                    n + 6 !== e && (o = s(t, e, n + 6), this.words[r] |= o << i & 67108863, this.words[r + 1] |= o >>> 26 - i & 4194303), this.strip()
                }, o.prototype._parseBase = function(t, e, n) {
                    this.words = [0], this.length = 1;
                    for (var r = 0, o = 1; o <= 67108863; o *= e) r++;
                    r--, o = o / e | 0;
                    for (var i = t.length - n, s = i % r, l = Math.min(i, i - s) + n, u = 0, c = n; c < l; c += r) u = a(t, c, c + r, e), this.imuln(o), this.words[0] + u < 67108864 ? this.words[0] += u : this._iaddn(u);
                    if (0 !== s) {
                        var h = 1;
                        for (u = a(t, c, t.length, e), c = 0; c < s; c++) h *= e;
                        this.imuln(h), this.words[0] + u < 67108864 ? this.words[0] += u : this._iaddn(u)
                    }
                }, o.prototype.copy = function(t) {
                    t.words = new Array(this.length);
                    for (var e = 0; e < this.length; e++) t.words[e] = this.words[e];
                    t.length = this.length, t.negative = this.negative, t.red = this.red
                }, o.prototype.clone = function() {
                    var t = new o(null);
                    return this.copy(t), t
                }, o.prototype._expand = function(t) {
                    for (; this.length < t;) this.words[this.length++] = 0;
                    return this
                }, o.prototype.strip = function() {
                    for (; this.length > 1 && 0 === this.words[this.length - 1];) this.length--;
                    return this._normSign()
                }, o.prototype._normSign = function() {
                    return 1 === this.length && 0 === this.words[0] && (this.negative = 0), this
                }, o.prototype.inspect = function() {
                    return (this.red ? "<BN-R: " : "<BN: ") + this.toString(16) + ">"
                };
                var l = ["", "0", "00", "000", "0000", "00000", "000000", "0000000", "00000000", "000000000", "0000000000", "00000000000", "000000000000", "0000000000000", "00000000000000", "000000000000000", "0000000000000000", "00000000000000000", "000000000000000000", "0000000000000000000", "00000000000000000000", "000000000000000000000", "0000000000000000000000", "00000000000000000000000", "000000000000000000000000", "0000000000000000000000000"],
                    u = [0, 0, 25, 16, 12, 11, 10, 9, 8, 8, 7, 7, 7, 7, 6, 6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
                    c = [0, 0, 33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216, 43046721, 1e7, 19487171, 35831808, 62748517, 7529536, 11390625, 16777216, 24137569, 34012224, 47045881, 64e6, 4084101, 5153632, 6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149, 243e5, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176];

                function h(t, e, n) {
                    n.negative = e.negative ^ t.negative;
                    var r = t.length + e.length | 0;
                    n.length = r, r = r - 1 | 0;
                    var o = 0 | t.words[0],
                        i = 0 | e.words[0],
                        s = o * i,
                        a = 67108863 & s,
                        l = s / 67108864 | 0;
                    n.words[0] = a;
                    for (var u = 1; u < r; u++) {
                        for (var c = l >>> 26, h = 67108863 & l, d = Math.min(u, e.length - 1), f = Math.max(0, u - t.length + 1); f <= d; f++) {
                            var p = u - f | 0;
                            c += (s = (o = 0 | t.words[p]) * (i = 0 | e.words[f]) + h) / 67108864 | 0, h = 67108863 & s
                        }
                        n.words[u] = 0 | h, l = 0 | c
                    }
                    return 0 !== l ? n.words[u] = 0 | l : n.length--, n.strip()
                }
                o.prototype.toString = function(t, e) {
                    var r;
                    if (e = 0 | e || 1, 16 === (t = t || 10) || "hex" === t) {
                        r = "";
                        for (var o = 0, i = 0, s = 0; s < this.length; s++) {
                            var a = this.words[s],
                                h = (16777215 & (a << o | i)).toString(16);
                            r = 0 != (i = a >>> 24 - o & 16777215) || s !== this.length - 1 ? l[6 - h.length] + h + r : h + r, (o += 2) >= 26 && (o -= 26, s--)
                        }
                        for (0 !== i && (r = i.toString(16) + r); r.length % e != 0;) r = "0" + r;
                        return 0 !== this.negative && (r = "-" + r), r
                    }
                    if (t === (0 | t) && t >= 2 && t <= 36) {
                        var d = u[t],
                            f = c[t];
                        r = "";
                        var p = this.clone();
                        for (p.negative = 0; !p.isZero();) {
                            var m = p.modn(f).toString(t);
                            r = (p = p.idivn(f)).isZero() ? m + r : l[d - m.length] + m + r
                        }
                        for (this.isZero() && (r = "0" + r); r.length % e != 0;) r = "0" + r;
                        return 0 !== this.negative && (r = "-" + r), r
                    }
                    n(!1, "Base should be between 2 and 36")
                }, o.prototype.toNumber = function() {
                    var t = this.words[0];
                    return 2 === this.length ? t += 67108864 * this.words[1] : 3 === this.length && 1 === this.words[2] ? t += 4503599627370496 + 67108864 * this.words[1] : this.length > 2 && n(!1, "Number can only safely store up to 53 bits"), 0 !== this.negative ? -t : t
                }, o.prototype.toJSON = function() {
                    return this.toString(16)
                }, o.prototype.toBuffer = function(t, e) {
                    return n(void 0 !== i), this.toArrayLike(i, t, e)
                }, o.prototype.toArray = function(t, e) {
                    return this.toArrayLike(Array, t, e)
                }, o.prototype.toArrayLike = function(t, e, r) {
                    var o = this.byteLength(),
                        i = r || Math.max(1, o);
                    n(o <= i, "byte array longer than desired length"), n(i > 0, "Requested array length <= 0"), this.strip();
                    var s, a, l = "le" === e,
                        u = new t(i),
                        c = this.clone();
                    if (l) {
                        for (a = 0; !c.isZero(); a++) s = c.andln(255), c.iushrn(8), u[a] = s;
                        for (; a < i; a++) u[a] = 0
                    } else {
                        for (a = 0; a < i - o; a++) u[a] = 0;
                        for (a = 0; !c.isZero(); a++) s = c.andln(255), c.iushrn(8), u[i - a - 1] = s
                    }
                    return u
                }, Math.clz32 ? o.prototype._countBits = function(t) {
                    return 32 - Math.clz32(t)
                } : o.prototype._countBits = function(t) {
                    var e = t,
                        n = 0;
                    return e >= 4096 && (n += 13, e >>>= 13), e >= 64 && (n += 7, e >>>= 7), e >= 8 && (n += 4, e >>>= 4), e >= 2 && (n += 2, e >>>= 2), n + e
                }, o.prototype._zeroBits = function(t) {
                    if (0 === t) return 26;
                    var e = t,
                        n = 0;
                    return 0 == (8191 & e) && (n += 13, e >>>= 13), 0 == (127 & e) && (n += 7, e >>>= 7), 0 == (15 & e) && (n += 4, e >>>= 4), 0 == (3 & e) && (n += 2, e >>>= 2), 0 == (1 & e) && n++, n
                }, o.prototype.bitLength = function() {
                    var t = this.words[this.length - 1],
                        e = this._countBits(t);
                    return 26 * (this.length - 1) + e
                }, o.prototype.zeroBits = function() {
                    if (this.isZero()) return 0;
                    for (var t = 0, e = 0; e < this.length; e++) {
                        var n = this._zeroBits(this.words[e]);
                        if (t += n, 26 !== n) break
                    }
                    return t
                }, o.prototype.byteLength = function() {
                    return Math.ceil(this.bitLength() / 8)
                }, o.prototype.toTwos = function(t) {
                    return 0 !== this.negative ? this.abs().inotn(t).iaddn(1) : this.clone()
                }, o.prototype.fromTwos = function(t) {
                    return this.testn(t - 1) ? this.notn(t).iaddn(1).ineg() : this.clone()
                }, o.prototype.isNeg = function() {
                    return 0 !== this.negative
                }, o.prototype.neg = function() {
                    return this.clone().ineg()
                }, o.prototype.ineg = function() {
                    return this.isZero() || (this.negative ^= 1), this
                }, o.prototype.iuor = function(t) {
                    for (; this.length < t.length;) this.words[this.length++] = 0;
                    for (var e = 0; e < t.length; e++) this.words[e] = this.words[e] | t.words[e];
                    return this.strip()
                }, o.prototype.ior = function(t) {
                    return n(0 == (this.negative | t.negative)), this.iuor(t)
                }, o.prototype.or = function(t) {
                    return this.length > t.length ? this.clone().ior(t) : t.clone().ior(this)
                }, o.prototype.uor = function(t) {
                    return this.length > t.length ? this.clone().iuor(t) : t.clone().iuor(this)
                }, o.prototype.iuand = function(t) {
                    var e;
                    e = this.length > t.length ? t : this;
                    for (var n = 0; n < e.length; n++) this.words[n] = this.words[n] & t.words[n];
                    return this.length = e.length, this.strip()
                }, o.prototype.iand = function(t) {
                    return n(0 == (this.negative | t.negative)), this.iuand(t)
                }, o.prototype.and = function(t) {
                    return this.length > t.length ? this.clone().iand(t) : t.clone().iand(this)
                }, o.prototype.uand = function(t) {
                    return this.length > t.length ? this.clone().iuand(t) : t.clone().iuand(this)
                }, o.prototype.iuxor = function(t) {
                    var e, n;
                    this.length > t.length ? (e = this, n = t) : (e = t, n = this);
                    for (var r = 0; r < n.length; r++) this.words[r] = e.words[r] ^ n.words[r];
                    if (this !== e)
                        for (; r < e.length; r++) this.words[r] = e.words[r];
                    return this.length = e.length, this.strip()
                }, o.prototype.ixor = function(t) {
                    return n(0 == (this.negative | t.negative)), this.iuxor(t)
                }, o.prototype.xor = function(t) {
                    return this.length > t.length ? this.clone().ixor(t) : t.clone().ixor(this)
                }, o.prototype.uxor = function(t) {
                    return this.length > t.length ? this.clone().iuxor(t) : t.clone().iuxor(this)
                }, o.prototype.inotn = function(t) {
                    n("number" == typeof t && t >= 0);
                    var e = 0 | Math.ceil(t / 26),
                        r = t % 26;
                    this._expand(e), r > 0 && e--;
                    for (var o = 0; o < e; o++) this.words[o] = 67108863 & ~this.words[o];
                    return r > 0 && (this.words[o] = ~this.words[o] & 67108863 >> 26 - r), this.strip()
                }, o.prototype.notn = function(t) {
                    return this.clone().inotn(t)
                }, o.prototype.setn = function(t, e) {
                    n("number" == typeof t && t >= 0);
                    var r = t / 26 | 0,
                        o = t % 26;
                    return this._expand(r + 1), this.words[r] = e ? this.words[r] | 1 << o : this.words[r] & ~(1 << o), this.strip()
                }, o.prototype.iadd = function(t) {
                    var e, n, r;
                    if (0 !== this.negative && 0 === t.negative) return this.negative = 0, e = this.isub(t), this.negative ^= 1, this._normSign();
                    if (0 === this.negative && 0 !== t.negative) return t.negative = 0, e = this.isub(t), t.negative = 1, e._normSign();
                    this.length > t.length ? (n = this, r = t) : (n = t, r = this);
                    for (var o = 0, i = 0; i < r.length; i++) e = (0 | n.words[i]) + (0 | r.words[i]) + o, this.words[i] = 67108863 & e, o = e >>> 26;
                    for (; 0 !== o && i < n.length; i++) e = (0 | n.words[i]) + o, this.words[i] = 67108863 & e, o = e >>> 26;
                    if (this.length = n.length, 0 !== o) this.words[this.length] = o, this.length++;
                    else if (n !== this)
                        for (; i < n.length; i++) this.words[i] = n.words[i];
                    return this
                }, o.prototype.add = function(t) {
                    var e;
                    return 0 !== t.negative && 0 === this.negative ? (t.negative = 0, e = this.sub(t), t.negative ^= 1, e) : 0 === t.negative && 0 !== this.negative ? (this.negative = 0, e = t.sub(this), this.negative = 1, e) : this.length > t.length ? this.clone().iadd(t) : t.clone().iadd(this)
                }, o.prototype.isub = function(t) {
                    if (0 !== t.negative) {
                        t.negative = 0;
                        var e = this.iadd(t);
                        return t.negative = 1, e._normSign()
                    }
                    if (0 !== this.negative) return this.negative = 0, this.iadd(t), this.negative = 1, this._normSign();
                    var n, r, o = this.cmp(t);
                    if (0 === o) return this.negative = 0, this.length = 1, this.words[0] = 0, this;
                    o > 0 ? (n = this, r = t) : (n = t, r = this);
                    for (var i = 0, s = 0; s < r.length; s++) i = (e = (0 | n.words[s]) - (0 | r.words[s]) + i) >> 26, this.words[s] = 67108863 & e;
                    for (; 0 !== i && s < n.length; s++) i = (e = (0 | n.words[s]) + i) >> 26, this.words[s] = 67108863 & e;
                    if (0 === i && s < n.length && n !== this)
                        for (; s < n.length; s++) this.words[s] = n.words[s];
                    return this.length = Math.max(this.length, s), n !== this && (this.negative = 1), this.strip()
                }, o.prototype.sub = function(t) {
                    return this.clone().isub(t)
                };
                var d = function(t, e, n) {
                    var r, o, i, s = t.words,
                        a = e.words,
                        l = n.words,
                        u = 0,
                        c = 0 | s[0],
                        h = 8191 & c,
                        d = c >>> 13,
                        f = 0 | s[1],
                        p = 8191 & f,
                        m = f >>> 13,
                        g = 0 | s[2],
                        _ = 8191 & g,
                        v = g >>> 13,
                        w = 0 | s[3],
                        y = 8191 & w,
                        b = w >>> 13,
                        M = 0 | s[4],
                        k = 8191 & M,
                        x = M >>> 13,
                        S = 0 | s[5],
                        E = 8191 & S,
                        C = S >>> 13,
                        A = 0 | s[6],
                        I = 8191 & A,
                        R = A >>> 13,
                        T = 0 | s[7],
                        O = 8191 & T,
                        N = T >>> 13,
                        B = 0 | s[8],
                        P = 8191 & B,
                        L = B >>> 13,
                        q = 0 | s[9],
                        U = 8191 & q,
                        j = q >>> 13,
                        D = 0 | a[0],
                        z = 8191 & D,
                        F = D >>> 13,
                        W = 0 | a[1],
                        H = 8191 & W,
                        $ = W >>> 13,
                        J = 0 | a[2],
                        Y = 8191 & J,
                        V = J >>> 13,
                        K = 0 | a[3],
                        Z = 8191 & K,
                        Q = K >>> 13,
                        X = 0 | a[4],
                        G = 8191 & X,
                        tt = X >>> 13,
                        et = 0 | a[5],
                        nt = 8191 & et,
                        rt = et >>> 13,
                        ot = 0 | a[6],
                        it = 8191 & ot,
                        st = ot >>> 13,
                        at = 0 | a[7],
                        lt = 8191 & at,
                        ut = at >>> 13,
                        ct = 0 | a[8],
                        ht = 8191 & ct,
                        dt = ct >>> 13,
                        ft = 0 | a[9],
                        pt = 8191 & ft,
                        mt = ft >>> 13;
                    n.negative = t.negative ^ e.negative, n.length = 19;
                    var gt = (u + (r = Math.imul(h, z)) | 0) + ((8191 & (o = (o = Math.imul(h, F)) + Math.imul(d, z) | 0)) << 13) | 0;
                    u = ((i = Math.imul(d, F)) + (o >>> 13) | 0) + (gt >>> 26) | 0, gt &= 67108863, r = Math.imul(p, z), o = (o = Math.imul(p, F)) + Math.imul(m, z) | 0, i = Math.imul(m, F);
                    var _t = (u + (r = r + Math.imul(h, H) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, $) | 0) + Math.imul(d, H) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, $) | 0) + (o >>> 13) | 0) + (_t >>> 26) | 0, _t &= 67108863, r = Math.imul(_, z), o = (o = Math.imul(_, F)) + Math.imul(v, z) | 0, i = Math.imul(v, F), r = r + Math.imul(p, H) | 0, o = (o = o + Math.imul(p, $) | 0) + Math.imul(m, H) | 0, i = i + Math.imul(m, $) | 0;
                    var vt = (u + (r = r + Math.imul(h, Y) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, V) | 0) + Math.imul(d, Y) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, V) | 0) + (o >>> 13) | 0) + (vt >>> 26) | 0, vt &= 67108863, r = Math.imul(y, z), o = (o = Math.imul(y, F)) + Math.imul(b, z) | 0, i = Math.imul(b, F), r = r + Math.imul(_, H) | 0, o = (o = o + Math.imul(_, $) | 0) + Math.imul(v, H) | 0, i = i + Math.imul(v, $) | 0, r = r + Math.imul(p, Y) | 0, o = (o = o + Math.imul(p, V) | 0) + Math.imul(m, Y) | 0, i = i + Math.imul(m, V) | 0;
                    var wt = (u + (r = r + Math.imul(h, Z) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, Q) | 0) + Math.imul(d, Z) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, Q) | 0) + (o >>> 13) | 0) + (wt >>> 26) | 0, wt &= 67108863, r = Math.imul(k, z), o = (o = Math.imul(k, F)) + Math.imul(x, z) | 0, i = Math.imul(x, F), r = r + Math.imul(y, H) | 0, o = (o = o + Math.imul(y, $) | 0) + Math.imul(b, H) | 0, i = i + Math.imul(b, $) | 0, r = r + Math.imul(_, Y) | 0, o = (o = o + Math.imul(_, V) | 0) + Math.imul(v, Y) | 0, i = i + Math.imul(v, V) | 0, r = r + Math.imul(p, Z) | 0, o = (o = o + Math.imul(p, Q) | 0) + Math.imul(m, Z) | 0, i = i + Math.imul(m, Q) | 0;
                    var yt = (u + (r = r + Math.imul(h, G) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, tt) | 0) + Math.imul(d, G) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, tt) | 0) + (o >>> 13) | 0) + (yt >>> 26) | 0, yt &= 67108863, r = Math.imul(E, z), o = (o = Math.imul(E, F)) + Math.imul(C, z) | 0, i = Math.imul(C, F), r = r + Math.imul(k, H) | 0, o = (o = o + Math.imul(k, $) | 0) + Math.imul(x, H) | 0, i = i + Math.imul(x, $) | 0, r = r + Math.imul(y, Y) | 0, o = (o = o + Math.imul(y, V) | 0) + Math.imul(b, Y) | 0, i = i + Math.imul(b, V) | 0, r = r + Math.imul(_, Z) | 0, o = (o = o + Math.imul(_, Q) | 0) + Math.imul(v, Z) | 0, i = i + Math.imul(v, Q) | 0, r = r + Math.imul(p, G) | 0, o = (o = o + Math.imul(p, tt) | 0) + Math.imul(m, G) | 0, i = i + Math.imul(m, tt) | 0;
                    var bt = (u + (r = r + Math.imul(h, nt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, rt) | 0) + Math.imul(d, nt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, rt) | 0) + (o >>> 13) | 0) + (bt >>> 26) | 0, bt &= 67108863, r = Math.imul(I, z), o = (o = Math.imul(I, F)) + Math.imul(R, z) | 0, i = Math.imul(R, F), r = r + Math.imul(E, H) | 0, o = (o = o + Math.imul(E, $) | 0) + Math.imul(C, H) | 0, i = i + Math.imul(C, $) | 0, r = r + Math.imul(k, Y) | 0, o = (o = o + Math.imul(k, V) | 0) + Math.imul(x, Y) | 0, i = i + Math.imul(x, V) | 0, r = r + Math.imul(y, Z) | 0, o = (o = o + Math.imul(y, Q) | 0) + Math.imul(b, Z) | 0, i = i + Math.imul(b, Q) | 0, r = r + Math.imul(_, G) | 0, o = (o = o + Math.imul(_, tt) | 0) + Math.imul(v, G) | 0, i = i + Math.imul(v, tt) | 0, r = r + Math.imul(p, nt) | 0, o = (o = o + Math.imul(p, rt) | 0) + Math.imul(m, nt) | 0, i = i + Math.imul(m, rt) | 0;
                    var Mt = (u + (r = r + Math.imul(h, it) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, st) | 0) + Math.imul(d, it) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, st) | 0) + (o >>> 13) | 0) + (Mt >>> 26) | 0, Mt &= 67108863, r = Math.imul(O, z), o = (o = Math.imul(O, F)) + Math.imul(N, z) | 0, i = Math.imul(N, F), r = r + Math.imul(I, H) | 0, o = (o = o + Math.imul(I, $) | 0) + Math.imul(R, H) | 0, i = i + Math.imul(R, $) | 0, r = r + Math.imul(E, Y) | 0, o = (o = o + Math.imul(E, V) | 0) + Math.imul(C, Y) | 0, i = i + Math.imul(C, V) | 0, r = r + Math.imul(k, Z) | 0, o = (o = o + Math.imul(k, Q) | 0) + Math.imul(x, Z) | 0, i = i + Math.imul(x, Q) | 0, r = r + Math.imul(y, G) | 0, o = (o = o + Math.imul(y, tt) | 0) + Math.imul(b, G) | 0, i = i + Math.imul(b, tt) | 0, r = r + Math.imul(_, nt) | 0, o = (o = o + Math.imul(_, rt) | 0) + Math.imul(v, nt) | 0, i = i + Math.imul(v, rt) | 0, r = r + Math.imul(p, it) | 0, o = (o = o + Math.imul(p, st) | 0) + Math.imul(m, it) | 0, i = i + Math.imul(m, st) | 0;
                    var kt = (u + (r = r + Math.imul(h, lt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, ut) | 0) + Math.imul(d, lt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, ut) | 0) + (o >>> 13) | 0) + (kt >>> 26) | 0, kt &= 67108863, r = Math.imul(P, z), o = (o = Math.imul(P, F)) + Math.imul(L, z) | 0, i = Math.imul(L, F), r = r + Math.imul(O, H) | 0, o = (o = o + Math.imul(O, $) | 0) + Math.imul(N, H) | 0, i = i + Math.imul(N, $) | 0, r = r + Math.imul(I, Y) | 0, o = (o = o + Math.imul(I, V) | 0) + Math.imul(R, Y) | 0, i = i + Math.imul(R, V) | 0, r = r + Math.imul(E, Z) | 0, o = (o = o + Math.imul(E, Q) | 0) + Math.imul(C, Z) | 0, i = i + Math.imul(C, Q) | 0, r = r + Math.imul(k, G) | 0, o = (o = o + Math.imul(k, tt) | 0) + Math.imul(x, G) | 0, i = i + Math.imul(x, tt) | 0, r = r + Math.imul(y, nt) | 0, o = (o = o + Math.imul(y, rt) | 0) + Math.imul(b, nt) | 0, i = i + Math.imul(b, rt) | 0, r = r + Math.imul(_, it) | 0, o = (o = o + Math.imul(_, st) | 0) + Math.imul(v, it) | 0, i = i + Math.imul(v, st) | 0, r = r + Math.imul(p, lt) | 0, o = (o = o + Math.imul(p, ut) | 0) + Math.imul(m, lt) | 0, i = i + Math.imul(m, ut) | 0;
                    var xt = (u + (r = r + Math.imul(h, ht) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, dt) | 0) + Math.imul(d, ht) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, dt) | 0) + (o >>> 13) | 0) + (xt >>> 26) | 0, xt &= 67108863, r = Math.imul(U, z), o = (o = Math.imul(U, F)) + Math.imul(j, z) | 0, i = Math.imul(j, F), r = r + Math.imul(P, H) | 0, o = (o = o + Math.imul(P, $) | 0) + Math.imul(L, H) | 0, i = i + Math.imul(L, $) | 0, r = r + Math.imul(O, Y) | 0, o = (o = o + Math.imul(O, V) | 0) + Math.imul(N, Y) | 0, i = i + Math.imul(N, V) | 0, r = r + Math.imul(I, Z) | 0, o = (o = o + Math.imul(I, Q) | 0) + Math.imul(R, Z) | 0, i = i + Math.imul(R, Q) | 0, r = r + Math.imul(E, G) | 0, o = (o = o + Math.imul(E, tt) | 0) + Math.imul(C, G) | 0, i = i + Math.imul(C, tt) | 0, r = r + Math.imul(k, nt) | 0, o = (o = o + Math.imul(k, rt) | 0) + Math.imul(x, nt) | 0, i = i + Math.imul(x, rt) | 0, r = r + Math.imul(y, it) | 0, o = (o = o + Math.imul(y, st) | 0) + Math.imul(b, it) | 0, i = i + Math.imul(b, st) | 0, r = r + Math.imul(_, lt) | 0, o = (o = o + Math.imul(_, ut) | 0) + Math.imul(v, lt) | 0, i = i + Math.imul(v, ut) | 0, r = r + Math.imul(p, ht) | 0, o = (o = o + Math.imul(p, dt) | 0) + Math.imul(m, ht) | 0, i = i + Math.imul(m, dt) | 0;
                    var St = (u + (r = r + Math.imul(h, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(h, mt) | 0) + Math.imul(d, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(d, mt) | 0) + (o >>> 13) | 0) + (St >>> 26) | 0, St &= 67108863, r = Math.imul(U, H), o = (o = Math.imul(U, $)) + Math.imul(j, H) | 0, i = Math.imul(j, $), r = r + Math.imul(P, Y) | 0, o = (o = o + Math.imul(P, V) | 0) + Math.imul(L, Y) | 0, i = i + Math.imul(L, V) | 0, r = r + Math.imul(O, Z) | 0, o = (o = o + Math.imul(O, Q) | 0) + Math.imul(N, Z) | 0, i = i + Math.imul(N, Q) | 0, r = r + Math.imul(I, G) | 0, o = (o = o + Math.imul(I, tt) | 0) + Math.imul(R, G) | 0, i = i + Math.imul(R, tt) | 0, r = r + Math.imul(E, nt) | 0, o = (o = o + Math.imul(E, rt) | 0) + Math.imul(C, nt) | 0, i = i + Math.imul(C, rt) | 0, r = r + Math.imul(k, it) | 0, o = (o = o + Math.imul(k, st) | 0) + Math.imul(x, it) | 0, i = i + Math.imul(x, st) | 0, r = r + Math.imul(y, lt) | 0, o = (o = o + Math.imul(y, ut) | 0) + Math.imul(b, lt) | 0, i = i + Math.imul(b, ut) | 0, r = r + Math.imul(_, ht) | 0, o = (o = o + Math.imul(_, dt) | 0) + Math.imul(v, ht) | 0, i = i + Math.imul(v, dt) | 0;
                    var Et = (u + (r = r + Math.imul(p, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(p, mt) | 0) + Math.imul(m, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(m, mt) | 0) + (o >>> 13) | 0) + (Et >>> 26) | 0, Et &= 67108863, r = Math.imul(U, Y), o = (o = Math.imul(U, V)) + Math.imul(j, Y) | 0, i = Math.imul(j, V), r = r + Math.imul(P, Z) | 0, o = (o = o + Math.imul(P, Q) | 0) + Math.imul(L, Z) | 0, i = i + Math.imul(L, Q) | 0, r = r + Math.imul(O, G) | 0, o = (o = o + Math.imul(O, tt) | 0) + Math.imul(N, G) | 0, i = i + Math.imul(N, tt) | 0, r = r + Math.imul(I, nt) | 0, o = (o = o + Math.imul(I, rt) | 0) + Math.imul(R, nt) | 0, i = i + Math.imul(R, rt) | 0, r = r + Math.imul(E, it) | 0, o = (o = o + Math.imul(E, st) | 0) + Math.imul(C, it) | 0, i = i + Math.imul(C, st) | 0, r = r + Math.imul(k, lt) | 0, o = (o = o + Math.imul(k, ut) | 0) + Math.imul(x, lt) | 0, i = i + Math.imul(x, ut) | 0, r = r + Math.imul(y, ht) | 0, o = (o = o + Math.imul(y, dt) | 0) + Math.imul(b, ht) | 0, i = i + Math.imul(b, dt) | 0;
                    var Ct = (u + (r = r + Math.imul(_, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(_, mt) | 0) + Math.imul(v, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(v, mt) | 0) + (o >>> 13) | 0) + (Ct >>> 26) | 0, Ct &= 67108863, r = Math.imul(U, Z), o = (o = Math.imul(U, Q)) + Math.imul(j, Z) | 0, i = Math.imul(j, Q), r = r + Math.imul(P, G) | 0, o = (o = o + Math.imul(P, tt) | 0) + Math.imul(L, G) | 0, i = i + Math.imul(L, tt) | 0, r = r + Math.imul(O, nt) | 0, o = (o = o + Math.imul(O, rt) | 0) + Math.imul(N, nt) | 0, i = i + Math.imul(N, rt) | 0, r = r + Math.imul(I, it) | 0, o = (o = o + Math.imul(I, st) | 0) + Math.imul(R, it) | 0, i = i + Math.imul(R, st) | 0, r = r + Math.imul(E, lt) | 0, o = (o = o + Math.imul(E, ut) | 0) + Math.imul(C, lt) | 0, i = i + Math.imul(C, ut) | 0, r = r + Math.imul(k, ht) | 0, o = (o = o + Math.imul(k, dt) | 0) + Math.imul(x, ht) | 0, i = i + Math.imul(x, dt) | 0;
                    var At = (u + (r = r + Math.imul(y, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(y, mt) | 0) + Math.imul(b, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(b, mt) | 0) + (o >>> 13) | 0) + (At >>> 26) | 0, At &= 67108863, r = Math.imul(U, G), o = (o = Math.imul(U, tt)) + Math.imul(j, G) | 0, i = Math.imul(j, tt), r = r + Math.imul(P, nt) | 0, o = (o = o + Math.imul(P, rt) | 0) + Math.imul(L, nt) | 0, i = i + Math.imul(L, rt) | 0, r = r + Math.imul(O, it) | 0, o = (o = o + Math.imul(O, st) | 0) + Math.imul(N, it) | 0, i = i + Math.imul(N, st) | 0, r = r + Math.imul(I, lt) | 0, o = (o = o + Math.imul(I, ut) | 0) + Math.imul(R, lt) | 0, i = i + Math.imul(R, ut) | 0, r = r + Math.imul(E, ht) | 0, o = (o = o + Math.imul(E, dt) | 0) + Math.imul(C, ht) | 0, i = i + Math.imul(C, dt) | 0;
                    var It = (u + (r = r + Math.imul(k, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(k, mt) | 0) + Math.imul(x, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(x, mt) | 0) + (o >>> 13) | 0) + (It >>> 26) | 0, It &= 67108863, r = Math.imul(U, nt), o = (o = Math.imul(U, rt)) + Math.imul(j, nt) | 0, i = Math.imul(j, rt), r = r + Math.imul(P, it) | 0, o = (o = o + Math.imul(P, st) | 0) + Math.imul(L, it) | 0, i = i + Math.imul(L, st) | 0, r = r + Math.imul(O, lt) | 0, o = (o = o + Math.imul(O, ut) | 0) + Math.imul(N, lt) | 0, i = i + Math.imul(N, ut) | 0, r = r + Math.imul(I, ht) | 0, o = (o = o + Math.imul(I, dt) | 0) + Math.imul(R, ht) | 0, i = i + Math.imul(R, dt) | 0;
                    var Rt = (u + (r = r + Math.imul(E, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(E, mt) | 0) + Math.imul(C, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(C, mt) | 0) + (o >>> 13) | 0) + (Rt >>> 26) | 0, Rt &= 67108863, r = Math.imul(U, it), o = (o = Math.imul(U, st)) + Math.imul(j, it) | 0, i = Math.imul(j, st), r = r + Math.imul(P, lt) | 0, o = (o = o + Math.imul(P, ut) | 0) + Math.imul(L, lt) | 0, i = i + Math.imul(L, ut) | 0, r = r + Math.imul(O, ht) | 0, o = (o = o + Math.imul(O, dt) | 0) + Math.imul(N, ht) | 0, i = i + Math.imul(N, dt) | 0;
                    var Tt = (u + (r = r + Math.imul(I, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(I, mt) | 0) + Math.imul(R, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(R, mt) | 0) + (o >>> 13) | 0) + (Tt >>> 26) | 0, Tt &= 67108863, r = Math.imul(U, lt), o = (o = Math.imul(U, ut)) + Math.imul(j, lt) | 0, i = Math.imul(j, ut), r = r + Math.imul(P, ht) | 0, o = (o = o + Math.imul(P, dt) | 0) + Math.imul(L, ht) | 0, i = i + Math.imul(L, dt) | 0;
                    var Ot = (u + (r = r + Math.imul(O, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(O, mt) | 0) + Math.imul(N, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(N, mt) | 0) + (o >>> 13) | 0) + (Ot >>> 26) | 0, Ot &= 67108863, r = Math.imul(U, ht), o = (o = Math.imul(U, dt)) + Math.imul(j, ht) | 0, i = Math.imul(j, dt);
                    var Nt = (u + (r = r + Math.imul(P, pt) | 0) | 0) + ((8191 & (o = (o = o + Math.imul(P, mt) | 0) + Math.imul(L, pt) | 0)) << 13) | 0;
                    u = ((i = i + Math.imul(L, mt) | 0) + (o >>> 13) | 0) + (Nt >>> 26) | 0, Nt &= 67108863;
                    var Bt = (u + (r = Math.imul(U, pt)) | 0) + ((8191 & (o = (o = Math.imul(U, mt)) + Math.imul(j, pt) | 0)) << 13) | 0;
                    return u = ((i = Math.imul(j, mt)) + (o >>> 13) | 0) + (Bt >>> 26) | 0, Bt &= 67108863, l[0] = gt, l[1] = _t, l[2] = vt, l[3] = wt, l[4] = yt, l[5] = bt, l[6] = Mt, l[7] = kt, l[8] = xt, l[9] = St, l[10] = Et, l[11] = Ct, l[12] = At, l[13] = It, l[14] = Rt, l[15] = Tt, l[16] = Ot, l[17] = Nt, l[18] = Bt, 0 !== u && (l[19] = u, n.length++), n
                };

                function f(t, e, n) {
                    return (new p).mulp(t, e, n)
                }

                function p(t, e) {
                    this.x = t, this.y = e
                }
                Math.imul || (d = h), o.prototype.mulTo = function(t, e) {
                    var n, r = this.length + t.length;
                    return n = 10 === this.length && 10 === t.length ? d(this, t, e) : r < 63 ? h(this, t, e) : r < 1024 ? function(t, e, n) {
                        n.negative = e.negative ^ t.negative, n.length = t.length + e.length;
                        for (var r = 0, o = 0, i = 0; i < n.length - 1; i++) {
                            var s = o;
                            o = 0;
                            for (var a = 67108863 & r, l = Math.min(i, e.length - 1), u = Math.max(0, i - t.length + 1); u <= l; u++) {
                                var c = i - u,
                                    h = (0 | t.words[c]) * (0 | e.words[u]),
                                    d = 67108863 & h;
                                a = 67108863 & (d = d + a | 0), o += (s = (s = s + (h / 67108864 | 0) | 0) + (d >>> 26) | 0) >>> 26, s &= 67108863
                            }
                            n.words[i] = a, r = s, s = o
                        }
                        return 0 !== r ? n.words[i] = r : n.length--, n.strip()
                    }(this, t, e) : f(this, t, e), n
                }, p.prototype.makeRBT = function(t) {
                    for (var e = new Array(t), n = o.prototype._countBits(t) - 1, r = 0; r < t; r++) e[r] = this.revBin(r, n, t);
                    return e
                }, p.prototype.revBin = function(t, e, n) {
                    if (0 === t || t === n - 1) return t;
                    for (var r = 0, o = 0; o < e; o++) r |= (1 & t) << e - o - 1, t >>= 1;
                    return r
                }, p.prototype.permute = function(t, e, n, r, o, i) {
                    for (var s = 0; s < i; s++) r[s] = e[t[s]], o[s] = n[t[s]]
                }, p.prototype.transform = function(t, e, n, r, o, i) {
                    this.permute(i, t, e, n, r, o);
                    for (var s = 1; s < o; s <<= 1)
                        for (var a = s << 1, l = Math.cos(2 * Math.PI / a), u = Math.sin(2 * Math.PI / a), c = 0; c < o; c += a)
                            for (var h = l, d = u, f = 0; f < s; f++) {
                                var p = n[c + f],
                                    m = r[c + f],
                                    g = n[c + f + s],
                                    _ = r[c + f + s],
                                    v = h * g - d * _;
                                _ = h * _ + d * g, g = v, n[c + f] = p + g, r[c + f] = m + _, n[c + f + s] = p - g, r[c + f + s] = m - _, f !== a && (v = l * h - u * d, d = l * d + u * h, h = v)
                            }
                }, p.prototype.guessLen13b = function(t, e) {
                    var n = 1 | Math.max(e, t),
                        r = 1 & n,
                        o = 0;
                    for (n = n / 2 | 0; n; n >>>= 1) o++;
                    return 1 << o + 1 + r
                }, p.prototype.conjugate = function(t, e, n) {
                    if (!(n <= 1))
                        for (var r = 0; r < n / 2; r++) {
                            var o = t[r];
                            t[r] = t[n - r - 1], t[n - r - 1] = o, o = e[r], e[r] = -e[n - r - 1], e[n - r - 1] = -o
                        }
                }, p.prototype.normalize13b = function(t, e) {
                    for (var n = 0, r = 0; r < e / 2; r++) {
                        var o = 8192 * Math.round(t[2 * r + 1] / e) + Math.round(t[2 * r] / e) + n;
                        t[r] = 67108863 & o, n = o < 67108864 ? 0 : o / 67108864 | 0
                    }
                    return t
                }, p.prototype.convert13b = function(t, e, r, o) {
                    for (var i = 0, s = 0; s < e; s++) i += 0 | t[s], r[2 * s] = 8191 & i, i >>>= 13, r[2 * s + 1] = 8191 & i, i >>>= 13;
                    for (s = 2 * e; s < o; ++s) r[s] = 0;
                    n(0 === i), n(0 == (-8192 & i))
                }, p.prototype.stub = function(t) {
                    for (var e = new Array(t), n = 0; n < t; n++) e[n] = 0;
                    return e
                }, p.prototype.mulp = function(t, e, n) {
                    var r = 2 * this.guessLen13b(t.length, e.length),
                        o = this.makeRBT(r),
                        i = this.stub(r),
                        s = new Array(r),
                        a = new Array(r),
                        l = new Array(r),
                        u = new Array(r),
                        c = new Array(r),
                        h = new Array(r),
                        d = n.words;
                    d.length = r, this.convert13b(t.words, t.length, s, r), this.convert13b(e.words, e.length, u, r), this.transform(s, i, a, l, r, o), this.transform(u, i, c, h, r, o);
                    for (var f = 0; f < r; f++) {
                        var p = a[f] * c[f] - l[f] * h[f];
                        l[f] = a[f] * h[f] + l[f] * c[f], a[f] = p
                    }
                    return this.conjugate(a, l, r), this.transform(a, l, d, i, r, o), this.conjugate(d, i, r), this.normalize13b(d, r), n.negative = t.negative ^ e.negative, n.length = t.length + e.length, n.strip()
                }, o.prototype.mul = function(t) {
                    var e = new o(null);
                    return e.words = new Array(this.length + t.length), this.mulTo(t, e)
                }, o.prototype.mulf = function(t) {
                    var e = new o(null);
                    return e.words = new Array(this.length + t.length), f(this, t, e)
                }, o.prototype.imul = function(t) {
                    return this.clone().mulTo(t, this)
                }, o.prototype.imuln = function(t) {
                    n("number" == typeof t), n(t < 67108864);
                    for (var e = 0, r = 0; r < this.length; r++) {
                        var o = (0 | this.words[r]) * t,
                            i = (67108863 & o) + (67108863 & e);
                        e >>= 26, e += o / 67108864 | 0, e += i >>> 26, this.words[r] = 67108863 & i
                    }
                    return 0 !== e && (this.words[r] = e, this.length++), this
                }, o.prototype.muln = function(t) {
                    return this.clone().imuln(t)
                }, o.prototype.sqr = function() {
                    return this.mul(this)
                }, o.prototype.isqr = function() {
                    return this.imul(this.clone())
                }, o.prototype.pow = function(t) {
                    var e = function(t) {
                        for (var e = new Array(t.bitLength()), n = 0; n < e.length; n++) {
                            var r = n / 26 | 0,
                                o = n % 26;
                            e[n] = (t.words[r] & 1 << o) >>> o
                        }
                        return e
                    }(t);
                    if (0 === e.length) return new o(1);
                    for (var n = this, r = 0; r < e.length && 0 === e[r]; r++, n = n.sqr());
                    if (++r < e.length)
                        for (var i = n.sqr(); r < e.length; r++, i = i.sqr()) 0 !== e[r] && (n = n.mul(i));
                    return n
                }, o.prototype.iushln = function(t) {
                    n("number" == typeof t && t >= 0);
                    var e, r = t % 26,
                        o = (t - r) / 26,
                        i = 67108863 >>> 26 - r << 26 - r;
                    if (0 !== r) {
                        var s = 0;
                        for (e = 0; e < this.length; e++) {
                            var a = this.words[e] & i,
                                l = (0 | this.words[e]) - a << r;
                            this.words[e] = l | s, s = a >>> 26 - r
                        }
                        s && (this.words[e] = s, this.length++)
                    }
                    if (0 !== o) {
                        for (e = this.length - 1; e >= 0; e--) this.words[e + o] = this.words[e];
                        for (e = 0; e < o; e++) this.words[e] = 0;
                        this.length += o
                    }
                    return this.strip()
                }, o.prototype.ishln = function(t) {
                    return n(0 === this.negative), this.iushln(t)
                }, o.prototype.iushrn = function(t, e, r) {
                    var o;
                    n("number" == typeof t && t >= 0), o = e ? (e - e % 26) / 26 : 0;
                    var i = t % 26,
                        s = Math.min((t - i) / 26, this.length),
                        a = 67108863 ^ 67108863 >>> i << i,
                        l = r;
                    if (o -= s, o = Math.max(0, o), l) {
                        for (var u = 0; u < s; u++) l.words[u] = this.words[u];
                        l.length = s
                    }
                    if (0 === s);
                    else if (this.length > s)
                        for (this.length -= s, u = 0; u < this.length; u++) this.words[u] = this.words[u + s];
                    else this.words[0] = 0, this.length = 1;
                    var c = 0;
                    for (u = this.length - 1; u >= 0 && (0 !== c || u >= o); u--) {
                        var h = 0 | this.words[u];
                        this.words[u] = c << 26 - i | h >>> i, c = h & a
                    }
                    return l && 0 !== c && (l.words[l.length++] = c), 0 === this.length && (this.words[0] = 0, this.length = 1), this.strip()
                }, o.prototype.ishrn = function(t, e, r) {
                    return n(0 === this.negative), this.iushrn(t, e, r)
                }, o.prototype.shln = function(t) {
                    return this.clone().ishln(t)
                }, o.prototype.ushln = function(t) {
                    return this.clone().iushln(t)
                }, o.prototype.shrn = function(t) {
                    return this.clone().ishrn(t)
                }, o.prototype.ushrn = function(t) {
                    return this.clone().iushrn(t)
                }, o.prototype.testn = function(t) {
                    n("number" == typeof t && t >= 0);
                    var e = t % 26,
                        r = (t - e) / 26,
                        o = 1 << e;
                    return !(this.length <= r || !(this.words[r] & o))
                }, o.prototype.imaskn = function(t) {
                    n("number" == typeof t && t >= 0);
                    var e = t % 26,
                        r = (t - e) / 26;
                    if (n(0 === this.negative, "imaskn works only with positive numbers"), this.length <= r) return this;
                    if (0 !== e && r++, this.length = Math.min(r, this.length), 0 !== e) {
                        var o = 67108863 ^ 67108863 >>> e << e;
                        this.words[this.length - 1] &= o
                    }
                    return this.strip()
                }, o.prototype.maskn = function(t) {
                    return this.clone().imaskn(t)
                }, o.prototype.iaddn = function(t) {
                    return n("number" == typeof t), n(t < 67108864), t < 0 ? this.isubn(-t) : 0 !== this.negative ? 1 === this.length && (0 | this.words[0]) < t ? (this.words[0] = t - (0 | this.words[0]), this.negative = 0, this) : (this.negative = 0, this.isubn(t), this.negative = 1, this) : this._iaddn(t)
                }, o.prototype._iaddn = function(t) {
                    this.words[0] += t;
                    for (var e = 0; e < this.length && this.words[e] >= 67108864; e++) this.words[e] -= 67108864, e === this.length - 1 ? this.words[e + 1] = 1 : this.words[e + 1]++;
                    return this.length = Math.max(this.length, e + 1), this
                }, o.prototype.isubn = function(t) {
                    if (n("number" == typeof t), n(t < 67108864), t < 0) return this.iaddn(-t);
                    if (0 !== this.negative) return this.negative = 0, this.iaddn(t), this.negative = 1, this;
                    if (this.words[0] -= t, 1 === this.length && this.words[0] < 0) this.words[0] = -this.words[0], this.negative = 1;
                    else
                        for (var e = 0; e < this.length && this.words[e] < 0; e++) this.words[e] += 67108864, this.words[e + 1] -= 1;
                    return this.strip()
                }, o.prototype.addn = function(t) {
                    return this.clone().iaddn(t)
                }, o.prototype.subn = function(t) {
                    return this.clone().isubn(t)
                }, o.prototype.iabs = function() {
                    return this.negative = 0, this
                }, o.prototype.abs = function() {
                    return this.clone().iabs()
                }, o.prototype._ishlnsubmul = function(t, e, r) {
                    var o, i, s = t.length + r;
                    this._expand(s);
                    var a = 0;
                    for (o = 0; o < t.length; o++) {
                        i = (0 | this.words[o + r]) + a;
                        var l = (0 | t.words[o]) * e;
                        a = ((i -= 67108863 & l) >> 26) - (l / 67108864 | 0), this.words[o + r] = 67108863 & i
                    }
                    for (; o < this.length - r; o++) a = (i = (0 | this.words[o + r]) + a) >> 26, this.words[o + r] = 67108863 & i;
                    if (0 === a) return this.strip();
                    for (n(-1 === a), a = 0, o = 0; o < this.length; o++) a = (i = -(0 | this.words[o]) + a) >> 26, this.words[o] = 67108863 & i;
                    return this.negative = 1, this.strip()
                }, o.prototype._wordDiv = function(t, e) {
                    var n = (this.length, t.length),
                        r = this.clone(),
                        i = t,
                        s = 0 | i.words[i.length - 1];
                    0 != (n = 26 - this._countBits(s)) && (i = i.ushln(n), r.iushln(n), s = 0 | i.words[i.length - 1]);
                    var a, l = r.length - i.length;
                    if ("mod" !== e) {
                        (a = new o(null)).length = l + 1, a.words = new Array(a.length);
                        for (var u = 0; u < a.length; u++) a.words[u] = 0
                    }
                    var c = r.clone()._ishlnsubmul(i, 1, l);
                    0 === c.negative && (r = c, a && (a.words[l] = 1));
                    for (var h = l - 1; h >= 0; h--) {
                        var d = 67108864 * (0 | r.words[i.length + h]) + (0 | r.words[i.length + h - 1]);
                        for (d = Math.min(d / s | 0, 67108863), r._ishlnsubmul(i, d, h); 0 !== r.negative;) d--, r.negative = 0, r._ishlnsubmul(i, 1, h), r.isZero() || (r.negative ^= 1);
                        a && (a.words[h] = d)
                    }
                    return a && a.strip(), r.strip(), "div" !== e && 0 !== n && r.iushrn(n), {
                        div: a || null,
                        mod: r
                    }
                }, o.prototype.divmod = function(t, e, r) {
                    return n(!t.isZero()), this.isZero() ? {
                        div: new o(0),
                        mod: new o(0)
                    } : 0 !== this.negative && 0 === t.negative ? (a = this.neg().divmod(t, e), "mod" !== e && (i = a.div.neg()), "div" !== e && (s = a.mod.neg(), r && 0 !== s.negative && s.iadd(t)), {
                        div: i,
                        mod: s
                    }) : 0 === this.negative && 0 !== t.negative ? (a = this.divmod(t.neg(), e), "mod" !== e && (i = a.div.neg()), {
                        div: i,
                        mod: a.mod
                    }) : 0 != (this.negative & t.negative) ? (a = this.neg().divmod(t.neg(), e), "div" !== e && (s = a.mod.neg(), r && 0 !== s.negative && s.isub(t)), {
                        div: a.div,
                        mod: s
                    }) : t.length > this.length || this.cmp(t) < 0 ? {
                        div: new o(0),
                        mod: this
                    } : 1 === t.length ? "div" === e ? {
                        div: this.divn(t.words[0]),
                        mod: null
                    } : "mod" === e ? {
                        div: null,
                        mod: new o(this.modn(t.words[0]))
                    } : {
                        div: this.divn(t.words[0]),
                        mod: new o(this.modn(t.words[0]))
                    } : this._wordDiv(t, e);
                    var i, s, a
                }, o.prototype.div = function(t) {
                    return this.divmod(t, "div", !1).div
                }, o.prototype.mod = function(t) {
                    return this.divmod(t, "mod", !1).mod
                }, o.prototype.umod = function(t) {
                    return this.divmod(t, "mod", !0).mod
                }, o.prototype.divRound = function(t) {
                    var e = this.divmod(t);
                    if (e.mod.isZero()) return e.div;
                    var n = 0 !== e.div.negative ? e.mod.isub(t) : e.mod,
                        r = t.ushrn(1),
                        o = t.andln(1),
                        i = n.cmp(r);
                    return i < 0 || 1 === o && 0 === i ? e.div : 0 !== e.div.negative ? e.div.isubn(1) : e.div.iaddn(1)
                }, o.prototype.modn = function(t) {
                    n(t <= 67108863);
                    for (var e = (1 << 26) % t, r = 0, o = this.length - 1; o >= 0; o--) r = (e * r + (0 | this.words[o])) % t;
                    return r
                }, o.prototype.idivn = function(t) {
                    n(t <= 67108863);
                    for (var e = 0, r = this.length - 1; r >= 0; r--) {
                        var o = (0 | this.words[r]) + 67108864 * e;
                        this.words[r] = o / t | 0, e = o % t
                    }
                    return this.strip()
                }, o.prototype.divn = function(t) {
                    return this.clone().idivn(t)
                }, o.prototype.egcd = function(t) {
                    n(0 === t.negative), n(!t.isZero());
                    var e = this,
                        r = t.clone();
                    e = 0 !== e.negative ? e.umod(t) : e.clone();
                    for (var i = new o(1), s = new o(0), a = new o(0), l = new o(1), u = 0; e.isEven() && r.isEven();) e.iushrn(1), r.iushrn(1), ++u;
                    for (var c = r.clone(), h = e.clone(); !e.isZero();) {
                        for (var d = 0, f = 1; 0 == (e.words[0] & f) && d < 26; ++d, f <<= 1);
                        if (d > 0)
                            for (e.iushrn(d); d-- > 0;)(i.isOdd() || s.isOdd()) && (i.iadd(c), s.isub(h)), i.iushrn(1), s.iushrn(1);
                        for (var p = 0, m = 1; 0 == (r.words[0] & m) && p < 26; ++p, m <<= 1);
                        if (p > 0)
                            for (r.iushrn(p); p-- > 0;)(a.isOdd() || l.isOdd()) && (a.iadd(c), l.isub(h)), a.iushrn(1), l.iushrn(1);
                        e.cmp(r) >= 0 ? (e.isub(r), i.isub(a), s.isub(l)) : (r.isub(e), a.isub(i), l.isub(s))
                    }
                    return {
                        a: a,
                        b: l,
                        gcd: r.iushln(u)
                    }
                }, o.prototype._invmp = function(t) {
                    n(0 === t.negative), n(!t.isZero());
                    var e = this,
                        r = t.clone();
                    e = 0 !== e.negative ? e.umod(t) : e.clone();
                    for (var i, s = new o(1), a = new o(0), l = r.clone(); e.cmpn(1) > 0 && r.cmpn(1) > 0;) {
                        for (var u = 0, c = 1; 0 == (e.words[0] & c) && u < 26; ++u, c <<= 1);
                        if (u > 0)
                            for (e.iushrn(u); u-- > 0;) s.isOdd() && s.iadd(l), s.iushrn(1);
                        for (var h = 0, d = 1; 0 == (r.words[0] & d) && h < 26; ++h, d <<= 1);
                        if (h > 0)
                            for (r.iushrn(h); h-- > 0;) a.isOdd() && a.iadd(l), a.iushrn(1);
                        e.cmp(r) >= 0 ? (e.isub(r), s.isub(a)) : (r.isub(e), a.isub(s))
                    }
                    return (i = 0 === e.cmpn(1) ? s : a).cmpn(0) < 0 && i.iadd(t), i
                }, o.prototype.gcd = function(t) {
                    if (this.isZero()) return t.abs();
                    if (t.isZero()) return this.abs();
                    var e = this.clone(),
                        n = t.clone();
                    e.negative = 0, n.negative = 0;
                    for (var r = 0; e.isEven() && n.isEven(); r++) e.iushrn(1), n.iushrn(1);
                    for (;;) {
                        for (; e.isEven();) e.iushrn(1);
                        for (; n.isEven();) n.iushrn(1);
                        var o = e.cmp(n);
                        if (o < 0) {
                            var i = e;
                            e = n, n = i
                        } else if (0 === o || 0 === n.cmpn(1)) break;
                        e.isub(n)
                    }
                    return n.iushln(r)
                }, o.prototype.invm = function(t) {
                    return this.egcd(t).a.umod(t)
                }, o.prototype.isEven = function() {
                    return 0 == (1 & this.words[0])
                }, o.prototype.isOdd = function() {
                    return 1 == (1 & this.words[0])
                }, o.prototype.andln = function(t) {
                    return this.words[0] & t
                }, o.prototype.bincn = function(t) {
                    n("number" == typeof t);
                    var e = t % 26,
                        r = (t - e) / 26,
                        o = 1 << e;
                    if (this.length <= r) return this._expand(r + 1), this.words[r] |= o, this;
                    for (var i = o, s = r; 0 !== i && s < this.length; s++) {
                        var a = 0 | this.words[s];
                        i = (a += i) >>> 26, a &= 67108863, this.words[s] = a
                    }
                    return 0 !== i && (this.words[s] = i, this.length++), this
                }, o.prototype.isZero = function() {
                    return 1 === this.length && 0 === this.words[0]
                }, o.prototype.cmpn = function(t) {
                    var e, r = t < 0;
                    if (0 !== this.negative && !r) return -1;
                    if (0 === this.negative && r) return 1;
                    if (this.strip(), this.length > 1) e = 1;
                    else {
                        r && (t = -t), n(t <= 67108863, "Number is too big");
                        var o = 0 | this.words[0];
                        e = o === t ? 0 : o < t ? -1 : 1
                    }
                    return 0 !== this.negative ? 0 | -e : e
                }, o.prototype.cmp = function(t) {
                    if (0 !== this.negative && 0 === t.negative) return -1;
                    if (0 === this.negative && 0 !== t.negative) return 1;
                    var e = this.ucmp(t);
                    return 0 !== this.negative ? 0 | -e : e
                }, o.prototype.ucmp = function(t) {
                    if (this.length > t.length) return 1;
                    if (this.length < t.length) return -1;
                    for (var e = 0, n = this.length - 1; n >= 0; n--) {
                        var r = 0 | this.words[n],
                            o = 0 | t.words[n];
                        if (r !== o) {
                            r < o ? e = -1 : r > o && (e = 1);
                            break
                        }
                    }
                    return e
                }, o.prototype.gtn = function(t) {
                    return 1 === this.cmpn(t)
                }, o.prototype.gt = function(t) {
                    return 1 === this.cmp(t)
                }, o.prototype.gten = function(t) {
                    return this.cmpn(t) >= 0
                }, o.prototype.gte = function(t) {
                    return this.cmp(t) >= 0
                }, o.prototype.ltn = function(t) {
                    return -1 === this.cmpn(t)
                }, o.prototype.lt = function(t) {
                    return -1 === this.cmp(t)
                }, o.prototype.lten = function(t) {
                    return this.cmpn(t) <= 0
                }, o.prototype.lte = function(t) {
                    return this.cmp(t) <= 0
                }, o.prototype.eqn = function(t) {
                    return 0 === this.cmpn(t)
                }, o.prototype.eq = function(t) {
                    return 0 === this.cmp(t)
                }, o.red = function(t) {
                    return new b(t)
                }, o.prototype.toRed = function(t) {
                    return n(!this.red, "Already a number in reduction context"), n(0 === this.negative, "red works only with positives"), t.convertTo(this)._forceRed(t)
                }, o.prototype.fromRed = function() {
                    return n(this.red, "fromRed works only with numbers in reduction context"), this.red.convertFrom(this)
                }, o.prototype._forceRed = function(t) {
                    return this.red = t, this
                }, o.prototype.forceRed = function(t) {
                    return n(!this.red, "Already a number in reduction context"), this._forceRed(t)
                }, o.prototype.redAdd = function(t) {
                    return n(this.red, "redAdd works only with red numbers"), this.red.add(this, t)
                }, o.prototype.redIAdd = function(t) {
                    return n(this.red, "redIAdd works only with red numbers"), this.red.iadd(this, t)
                }, o.prototype.redSub = function(t) {
                    return n(this.red, "redSub works only with red numbers"), this.red.sub(this, t)
                }, o.prototype.redISub = function(t) {
                    return n(this.red, "redISub works only with red numbers"), this.red.isub(this, t)
                }, o.prototype.redShl = function(t) {
                    return n(this.red, "redShl works only with red numbers"), this.red.shl(this, t)
                }, o.prototype.redMul = function(t) {
                    return n(this.red, "redMul works only with red numbers"), this.red._verify2(this, t), this.red.mul(this, t)
                }, o.prototype.redIMul = function(t) {
                    return n(this.red, "redMul works only with red numbers"), this.red._verify2(this, t), this.red.imul(this, t)
                }, o.prototype.redSqr = function() {
                    return n(this.red, "redSqr works only with red numbers"), this.red._verify1(this), this.red.sqr(this)
                }, o.prototype.redISqr = function() {
                    return n(this.red, "redISqr works only with red numbers"), this.red._verify1(this), this.red.isqr(this)
                }, o.prototype.redSqrt = function() {
                    return n(this.red, "redSqrt works only with red numbers"), this.red._verify1(this), this.red.sqrt(this)
                }, o.prototype.redInvm = function() {
                    return n(this.red, "redInvm works only with red numbers"), this.red._verify1(this), this.red.invm(this)
                }, o.prototype.redNeg = function() {
                    return n(this.red, "redNeg works only with red numbers"), this.red._verify1(this), this.red.neg(this)
                }, o.prototype.redPow = function(t) {
                    return n(this.red && !t.red, "redPow(normalNum)"), this.red._verify1(this), this.red.pow(this, t)
                };
                var m = {
                    k256: null,
                    p224: null,
                    p192: null,
                    p25519: null
                };

                function g(t, e) {
                    this.name = t, this.p = new o(e, 16), this.n = this.p.bitLength(), this.k = new o(1).iushln(this.n).isub(this.p), this.tmp = this._tmp()
                }

                function _() {
                    g.call(this, "k256", "ffffffff ffffffff ffffffff ffffffff ffffffff ffffffff fffffffe fffffc2f")
                }

                function v() {
                    g.call(this, "p224", "ffffffff ffffffff ffffffff ffffffff 00000000 00000000 00000001")
                }

                function w() {
                    g.call(this, "p192", "ffffffff ffffffff ffffffff fffffffe ffffffff ffffffff")
                }

                function y() {
                    g.call(this, "25519", "7fffffffffffffff ffffffffffffffff ffffffffffffffff ffffffffffffffed")
                }

                function b(t) {
                    if ("string" == typeof t) {
                        var e = o._prime(t);
                        this.m = e.p, this.prime = e
                    } else n(t.gtn(1), "modulus must be greater than 1"), this.m = t, this.prime = null
                }

                function M(t) {
                    b.call(this, t), this.shift = this.m.bitLength(), this.shift % 26 != 0 && (this.shift += 26 - this.shift % 26), this.r = new o(1).iushln(this.shift), this.r2 = this.imod(this.r.sqr()), this.rinv = this.r._invmp(this.m), this.minv = this.rinv.mul(this.r).isubn(1).div(this.m), this.minv = this.minv.umod(this.r), this.minv = this.r.sub(this.minv)
                }
                g.prototype._tmp = function() {
                    var t = new o(null);
                    return t.words = new Array(Math.ceil(this.n / 13)), t
                }, g.prototype.ireduce = function(t) {
                    var e, n = t;
                    do {
                        this.split(n, this.tmp), e = (n = (n = this.imulK(n)).iadd(this.tmp)).bitLength()
                    } while (e > this.n);
                    var r = e < this.n ? -1 : n.ucmp(this.p);
                    return 0 === r ? (n.words[0] = 0, n.length = 1) : r > 0 ? n.isub(this.p) : n.strip(), n
                }, g.prototype.split = function(t, e) {
                    t.iushrn(this.n, 0, e)
                }, g.prototype.imulK = function(t) {
                    return t.imul(this.k)
                }, r(_, g), _.prototype.split = function(t, e) {
                    for (var n = 4194303, r = Math.min(t.length, 9), o = 0; o < r; o++) e.words[o] = t.words[o];
                    if (e.length = r, t.length <= 9) return t.words[0] = 0, void(t.length = 1);
                    var i = t.words[9];
                    for (e.words[e.length++] = i & n, o = 10; o < t.length; o++) {
                        var s = 0 | t.words[o];
                        t.words[o - 10] = (s & n) << 4 | i >>> 22, i = s
                    }
                    i >>>= 22, t.words[o - 10] = i, 0 === i && t.length > 10 ? t.length -= 10 : t.length -= 9
                }, _.prototype.imulK = function(t) {
                    t.words[t.length] = 0, t.words[t.length + 1] = 0, t.length += 2;
                    for (var e = 0, n = 0; n < t.length; n++) {
                        var r = 0 | t.words[n];
                        e += 977 * r, t.words[n] = 67108863 & e, e = 64 * r + (e / 67108864 | 0)
                    }
                    return 0 === t.words[t.length - 1] && (t.length--, 0 === t.words[t.length - 1] && t.length--), t
                }, r(v, g), r(w, g), r(y, g), y.prototype.imulK = function(t) {
                    for (var e = 0, n = 0; n < t.length; n++) {
                        var r = 19 * (0 | t.words[n]) + e,
                            o = 67108863 & r;
                        r >>>= 26, t.words[n] = o, e = r
                    }
                    return 0 !== e && (t.words[t.length++] = e), t
                }, o._prime = function(t) {
                    if (m[t]) return m[t];
                    var e;
                    if ("k256" === t) e = new _;
                    else if ("p224" === t) e = new v;
                    else if ("p192" === t) e = new w;
                    else {
                        if ("p25519" !== t) throw new Error("Unknown prime " + t);
                        e = new y
                    }
                    return m[t] = e, e
                }, b.prototype._verify1 = function(t) {
                    n(0 === t.negative, "red works only with positives"), n(t.red, "red works only with red numbers")
                }, b.prototype._verify2 = function(t, e) {
                    n(0 == (t.negative | e.negative), "red works only with positives"), n(t.red && t.red === e.red, "red works only with red numbers")
                }, b.prototype.imod = function(t) {
                    return this.prime ? this.prime.ireduce(t)._forceRed(this) : t.umod(this.m)._forceRed(this)
                }, b.prototype.neg = function(t) {
                    return t.isZero() ? t.clone() : this.m.sub(t)._forceRed(this)
                }, b.prototype.add = function(t, e) {
                    this._verify2(t, e);
                    var n = t.add(e);
                    return n.cmp(this.m) >= 0 && n.isub(this.m), n._forceRed(this)
                }, b.prototype.iadd = function(t, e) {
                    this._verify2(t, e);
                    var n = t.iadd(e);
                    return n.cmp(this.m) >= 0 && n.isub(this.m), n
                }, b.prototype.sub = function(t, e) {
                    this._verify2(t, e);
                    var n = t.sub(e);
                    return n.cmpn(0) < 0 && n.iadd(this.m), n._forceRed(this)
                }, b.prototype.isub = function(t, e) {
                    this._verify2(t, e);
                    var n = t.isub(e);
                    return n.cmpn(0) < 0 && n.iadd(this.m), n
                }, b.prototype.shl = function(t, e) {
                    return this._verify1(t), this.imod(t.ushln(e))
                }, b.prototype.imul = function(t, e) {
                    return this._verify2(t, e), this.imod(t.imul(e))
                }, b.prototype.mul = function(t, e) {
                    return this._verify2(t, e), this.imod(t.mul(e))
                }, b.prototype.isqr = function(t) {
                    return this.imul(t, t.clone())
                }, b.prototype.sqr = function(t) {
                    return this.mul(t, t)
                }, b.prototype.sqrt = function(t) {
                    if (t.isZero()) return t.clone();
                    var e = this.m.andln(3);
                    if (n(e % 2 == 1), 3 === e) {
                        var r = this.m.add(new o(1)).iushrn(2);
                        return this.pow(t, r)
                    }
                    for (var i = this.m.subn(1), s = 0; !i.isZero() && 0 === i.andln(1);) s++, i.iushrn(1);
                    n(!i.isZero());
                    var a = new o(1).toRed(this),
                        l = a.redNeg(),
                        u = this.m.subn(1).iushrn(1),
                        c = this.m.bitLength();
                    for (c = new o(2 * c * c).toRed(this); 0 !== this.pow(c, u).cmp(l);) c.redIAdd(l);
                    for (var h = this.pow(c, i), d = this.pow(t, i.addn(1).iushrn(1)), f = this.pow(t, i), p = s; 0 !== f.cmp(a);) {
                        for (var m = f, g = 0; 0 !== m.cmp(a); g++) m = m.redSqr();
                        n(g < p);
                        var _ = this.pow(h, new o(1).iushln(p - g - 1));
                        d = d.redMul(_), h = _.redSqr(), f = f.redMul(h), p = g
                    }
                    return d
                }, b.prototype.invm = function(t) {
                    var e = t._invmp(this.m);
                    return 0 !== e.negative ? (e.negative = 0, this.imod(e).redNeg()) : this.imod(e)
                }, b.prototype.pow = function(t, e) {
                    if (e.isZero()) return new o(1).toRed(this);
                    if (0 === e.cmpn(1)) return t.clone();
                    var n = new Array(16);
                    n[0] = new o(1).toRed(this), n[1] = t;
                    for (var r = 2; r < n.length; r++) n[r] = this.mul(n[r - 1], t);
                    var i = n[0],
                        s = 0,
                        a = 0,
                        l = e.bitLength() % 26;
                    for (0 === l && (l = 26), r = e.length - 1; r >= 0; r--) {
                        for (var u = e.words[r], c = l - 1; c >= 0; c--) {
                            var h = u >> c & 1;
                            i !== n[0] && (i = this.sqr(i)), 0 !== h || 0 !== s ? (s <<= 1, s |= h, (4 == ++a || 0 === r && 0 === c) && (i = this.mul(i, n[s]), a = 0, s = 0)) : a = 0
                        }
                        l = 26
                    }
                    return i
                }, b.prototype.convertTo = function(t) {
                    var e = t.umod(this.m);
                    return e === t ? e.clone() : e
                }, b.prototype.convertFrom = function(t) {
                    var e = t.clone();
                    return e.red = null, e
                }, o.mont = function(t) {
                    return new M(t)
                }, r(M, b), M.prototype.convertTo = function(t) {
                    return this.imod(t.ushln(this.shift))
                }, M.prototype.convertFrom = function(t) {
                    var e = this.imod(t.mul(this.rinv));
                    return e.red = null, e
                }, M.prototype.imul = function(t, e) {
                    if (t.isZero() || e.isZero()) return t.words[0] = 0, t.length = 1, t;
                    var n = t.imul(e),
                        r = n.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m),
                        o = n.isub(r).iushrn(this.shift),
                        i = o;
                    return o.cmp(this.m) >= 0 ? i = o.isub(this.m) : o.cmpn(0) < 0 && (i = o.iadd(this.m)), i._forceRed(this)
                }, M.prototype.mul = function(t, e) {
                    if (t.isZero() || e.isZero()) return new o(0)._forceRed(this);
                    var n = t.mul(e),
                        r = n.maskn(this.shift).mul(this.minv).imaskn(this.shift).mul(this.m),
                        i = n.isub(r).iushrn(this.shift),
                        s = i;
                    return i.cmp(this.m) >= 0 ? s = i.isub(this.m) : i.cmpn(0) < 0 && (s = i.iadd(this.m)), s._forceRed(this)
                }, M.prototype.invm = function(t) {
                    return this.imod(t._invmp(this.m).mul(this.r2))._forceRed(this)
                }
            }(ft, e);
            var pt = ft.exports,
                mt = vt;
            vt.strict = wt, vt.loose = yt;
            var gt = Object.prototype.toString,
                _t = {
                    "[object Int8Array]": !0,
                    "[object Int16Array]": !0,
                    "[object Int32Array]": !0,
                    "[object Uint8Array]": !0,
                    "[object Uint8ClampedArray]": !0,
                    "[object Uint16Array]": !0,
                    "[object Uint32Array]": !0,
                    "[object Float32Array]": !0,
                    "[object Float64Array]": !0
                };

            function vt(t) {
                return wt(t) || yt(t)
            }

            function wt(t) {
                return t instanceof Int8Array || t instanceof Int16Array || t instanceof Int32Array || t instanceof Uint8Array || t instanceof Uint8ClampedArray || t instanceof Uint16Array || t instanceof Uint32Array || t instanceof Float32Array || t instanceof Float64Array
            }

            function yt(t) {
                return _t[gt.call(t)]
            }
            var bt = mt.strict;
            const Mt = "utf8",
                kt = "0";

            function xt(t) {
                return new Uint8Array(t)
            }

            function St(t, e = !1) {
                const n = t.toString("hex");
                return e ? Pt(n) : n
            }

            function Et(t) {
                return function(t) {
                    if (bt(t)) {
                        var e = Buffer.from(t.buffer);
                        return t.byteLength !== t.buffer.byteLength && (e = e.slice(t.byteOffset, t.byteOffset + t.byteLength)), e
                    }
                    return Buffer.from(t)
                }(t)
            }

            function Ct(t, e = !1) {
                return St(Et(t), e)
            }

            function At(t) {
                return Et(t).toString(Mt)
            }

            function It(t) {
                return xt(function(t) {
                    return Buffer.from(Bt(t), "hex")
                }(t))
            }

            function Rt(t) {
                return Buffer.from(t, Mt)
            }

            function Tt(t) {
                return xt(Rt(t))
            }

            function Ot(...t) {
                let e = [];
                return t.forEach((t => e = e.concat(Array.from(t)))), new Uint8Array([...e])
            }

            function Nt(t, e = 8, n = "0") {
                return function(t, e, n = "0") {
                    return function(t, e, n, r = "0") {
                        const o = e - t.length;
                        let i = t;
                        if (o > 0) {
                            const e = r.repeat(o);
                            i = n ? e + t : t + e
                        }
                        return i
                    }(t, e, !0, n)
                }(t, function(t, e = 8) {
                    const n = t % e;
                    return n ? (t - n) / e * e + e : t
                }(t.length, e), n)
            }

            function Bt(t) {
                return t.replace(/^0x/, "")
            }

            function Pt(t) {
                return t.startsWith("0x") ? t : `0x${t}`
            }

            function Lt(t) {
                return (t = Nt(t = Bt(t), 2)) && (t = Pt(t)), t
            }

            function qt(t) {
                return Et(new Uint8Array(t))
            }

            function Ut(t, e) {
                return function(t, e = !1) {
                    return St(Rt(t), e)
                }(t, !e)
            }

            function jt(t, e) {
                const n = Bt(Lt(new pt(t).toString(16)));
                return e ? n : Pt(n)
            }
            var Dt = {
                exports: {}
            };
            /**
             * [js-sha3]{@link https://github.com/emn178/js-sha3}
             *
             * @version 0.8.0
             * @author Chen, Yi-Cyuan [emn178@gmail.com]
             * @copyright Chen, Yi-Cyuan 2015-2018
             * @license MIT
             */
            ! function(t) {
                ! function() {
                    var n = "input is invalid type",
                        r = "object" == typeof window,
                        o = r ? window : {};
                    o.JS_SHA3_NO_WINDOW && (r = !1);
                    var i = !r && "object" == typeof self;
                    !o.JS_SHA3_NO_NODE_JS && "object" == typeof process && process.versions && process.versions.node ? o = e : i && (o = self);
                    var s = !o.JS_SHA3_NO_COMMON_JS && t.exports,
                        a = !o.JS_SHA3_NO_ARRAY_BUFFER && "undefined" != typeof ArrayBuffer,
                        l = "0123456789abcdef".split(""),
                        u = [4, 1024, 262144, 67108864],
                        c = [0, 8, 16, 24],
                        h = [1, 0, 32898, 0, 32906, 2147483648, 2147516416, 2147483648, 32907, 0, 2147483649, 0, 2147516545, 2147483648, 32777, 2147483648, 138, 0, 136, 0, 2147516425, 0, 2147483658, 0, 2147516555, 0, 139, 2147483648, 32905, 2147483648, 32771, 2147483648, 32770, 2147483648, 128, 2147483648, 32778, 0, 2147483658, 2147483648, 2147516545, 2147483648, 32896, 2147483648, 2147483649, 0, 2147516424, 2147483648],
                        d = [224, 256, 384, 512],
                        f = [128, 256],
                        p = ["hex", "buffer", "arrayBuffer", "array", "digest"],
                        m = {
                            128: 168,
                            256: 136
                        };
                    !o.JS_SHA3_NO_NODE_JS && Array.isArray || (Array.isArray = function(t) {
                        return "[object Array]" === Object.prototype.toString.call(t)
                    }), !a || !o.JS_SHA3_NO_ARRAY_BUFFER_IS_VIEW && ArrayBuffer.isView || (ArrayBuffer.isView = function(t) {
                        return "object" == typeof t && t.buffer && t.buffer.constructor === ArrayBuffer
                    });
                    for (var g = function(t, e, n) {
                            return function(r) {
                                return new T(t, e, t).update(r)[n]()
                            }
                        }, _ = function(t, e, n) {
                            return function(r, o) {
                                return new T(t, e, o).update(r)[n]()
                            }
                        }, v = function(t, e, n) {
                            return function(e, r, o, i) {
                                return k["cshake" + t].update(e, r, o, i)[n]()
                            }
                        }, w = function(t, e, n) {
                            return function(e, r, o, i) {
                                return k["kmac" + t].update(e, r, o, i)[n]()
                            }
                        }, y = function(t, e, n, r) {
                            for (var o = 0; o < p.length; ++o) {
                                var i = p[o];
                                t[i] = e(n, r, i)
                            }
                            return t
                        }, b = function(t, e) {
                            var n = g(t, e, "hex");
                            return n.create = function() {
                                return new T(t, e, t)
                            }, n.update = function(t) {
                                return n.create().update(t)
                            }, y(n, g, t, e)
                        }, M = [{
                            name: "keccak",
                            padding: [1, 256, 65536, 16777216],
                            bits: d,
                            createMethod: b
                        }, {
                            name: "sha3",
                            padding: [6, 1536, 393216, 100663296],
                            bits: d,
                            createMethod: b
                        }, {
                            name: "shake",
                            padding: [31, 7936, 2031616, 520093696],
                            bits: f,
                            createMethod: function(t, e) {
                                var n = _(t, e, "hex");
                                return n.create = function(n) {
                                    return new T(t, e, n)
                                }, n.update = function(t, e) {
                                    return n.create(e).update(t)
                                }, y(n, _, t, e)
                            }
                        }, {
                            name: "cshake",
                            padding: u,
                            bits: f,
                            createMethod: function(t, e) {
                                var n = m[t],
                                    r = v(t, 0, "hex");
                                return r.create = function(r, o, i) {
                                    return o || i ? new T(t, e, r).bytepad([o, i], n) : k["shake" + t].create(r)
                                }, r.update = function(t, e, n, o) {
                                    return r.create(e, n, o).update(t)
                                }, y(r, v, t, e)
                            }
                        }, {
                            name: "kmac",
                            padding: u,
                            bits: f,
                            createMethod: function(t, e) {
                                var n = m[t],
                                    r = w(t, 0, "hex");
                                return r.create = function(r, o, i) {
                                    return new O(t, e, o).bytepad(["KMAC", i], n).bytepad([r], n)
                                }, r.update = function(t, e, n, o) {
                                    return r.create(t, n, o).update(e)
                                }, y(r, w, t, e)
                            }
                        }], k = {}, x = [], S = 0; S < M.length; ++S)
                        for (var E = M[S], C = E.bits, A = 0; A < C.length; ++A) {
                            var I = E.name + "_" + C[A];
                            if (x.push(I), k[I] = E.createMethod(C[A], E.padding), "sha3" !== E.name) {
                                var R = E.name + C[A];
                                x.push(R), k[R] = k[I]
                            }
                        }

                    function T(t, e, n) {
                        this.blocks = [], this.s = [], this.padding = e, this.outputBits = n, this.reset = !0, this.finalized = !1, this.block = 0, this.start = 0, this.blockCount = 1600 - (t << 1) >> 5, this.byteCount = this.blockCount << 2, this.outputBlocks = n >> 5, this.extraBytes = (31 & n) >> 3;
                        for (var r = 0; r < 50; ++r) this.s[r] = 0
                    }

                    function O(t, e, n) {
                        T.call(this, t, e, n)
                    }
                    T.prototype.update = function(t) {
                        if (this.finalized) throw new Error("finalize already called");
                        var e, r = typeof t;
                        if ("string" !== r) {
                            if ("object" !== r) throw new Error(n);
                            if (null === t) throw new Error(n);
                            if (a && t.constructor === ArrayBuffer) t = new Uint8Array(t);
                            else if (!(Array.isArray(t) || a && ArrayBuffer.isView(t))) throw new Error(n);
                            e = !0
                        }
                        for (var o, i, s = this.blocks, l = this.byteCount, u = t.length, h = this.blockCount, d = 0, f = this.s; d < u;) {
                            if (this.reset)
                                for (this.reset = !1, s[0] = this.block, o = 1; o < h + 1; ++o) s[o] = 0;
                            if (e)
                                for (o = this.start; d < u && o < l; ++d) s[o >> 2] |= t[d] << c[3 & o++];
                            else
                                for (o = this.start; d < u && o < l; ++d)(i = t.charCodeAt(d)) < 128 ? s[o >> 2] |= i << c[3 & o++] : i < 2048 ? (s[o >> 2] |= (192 | i >> 6) << c[3 & o++], s[o >> 2] |= (128 | 63 & i) << c[3 & o++]) : i < 55296 || i >= 57344 ? (s[o >> 2] |= (224 | i >> 12) << c[3 & o++], s[o >> 2] |= (128 | i >> 6 & 63) << c[3 & o++], s[o >> 2] |= (128 | 63 & i) << c[3 & o++]) : (i = 65536 + ((1023 & i) << 10 | 1023 & t.charCodeAt(++d)), s[o >> 2] |= (240 | i >> 18) << c[3 & o++], s[o >> 2] |= (128 | i >> 12 & 63) << c[3 & o++], s[o >> 2] |= (128 | i >> 6 & 63) << c[3 & o++], s[o >> 2] |= (128 | 63 & i) << c[3 & o++]);
                            if (this.lastByteIndex = o, o >= l) {
                                for (this.start = o - l, this.block = s[h], o = 0; o < h; ++o) f[o] ^= s[o];
                                N(f), this.reset = !0
                            } else this.start = o
                        }
                        return this
                    }, T.prototype.encode = function(t, e) {
                        var n = 255 & t,
                            r = 1,
                            o = [n];
                        for (n = 255 & (t >>= 8); n > 0;) o.unshift(n), n = 255 & (t >>= 8), ++r;
                        return e ? o.push(r) : o.unshift(r), this.update(o), o.length
                    }, T.prototype.encodeString = function(t) {
                        var e, r = typeof t;
                        if ("string" !== r) {
                            if ("object" !== r) throw new Error(n);
                            if (null === t) throw new Error(n);
                            if (a && t.constructor === ArrayBuffer) t = new Uint8Array(t);
                            else if (!(Array.isArray(t) || a && ArrayBuffer.isView(t))) throw new Error(n);
                            e = !0
                        }
                        var o = 0,
                            i = t.length;
                        if (e) o = i;
                        else
                            for (var s = 0; s < t.length; ++s) {
                                var l = t.charCodeAt(s);
                                l < 128 ? o += 1 : l < 2048 ? o += 2 : l < 55296 || l >= 57344 ? o += 3 : (l = 65536 + ((1023 & l) << 10 | 1023 & t.charCodeAt(++s)), o += 4)
                            }
                        return o += this.encode(8 * o), this.update(t), o
                    }, T.prototype.bytepad = function(t, e) {
                        for (var n = this.encode(e), r = 0; r < t.length; ++r) n += this.encodeString(t[r]);
                        var o = e - n % e,
                            i = [];
                        return i.length = o, this.update(i), this
                    }, T.prototype.finalize = function() {
                        if (!this.finalized) {
                            this.finalized = !0;
                            var t = this.blocks,
                                e = this.lastByteIndex,
                                n = this.blockCount,
                                r = this.s;
                            if (t[e >> 2] |= this.padding[3 & e], this.lastByteIndex === this.byteCount)
                                for (t[0] = t[n], e = 1; e < n + 1; ++e) t[e] = 0;
                            for (t[n - 1] |= 2147483648, e = 0; e < n; ++e) r[e] ^= t[e];
                            N(r)
                        }
                    }, T.prototype.toString = T.prototype.hex = function() {
                        this.finalize();
                        for (var t, e = this.blockCount, n = this.s, r = this.outputBlocks, o = this.extraBytes, i = 0, s = 0, a = ""; s < r;) {
                            for (i = 0; i < e && s < r; ++i, ++s) t = n[i], a += l[t >> 4 & 15] + l[15 & t] + l[t >> 12 & 15] + l[t >> 8 & 15] + l[t >> 20 & 15] + l[t >> 16 & 15] + l[t >> 28 & 15] + l[t >> 24 & 15];
                            s % e == 0 && (N(n), i = 0)
                        }
                        return o && (t = n[i], a += l[t >> 4 & 15] + l[15 & t], o > 1 && (a += l[t >> 12 & 15] + l[t >> 8 & 15]), o > 2 && (a += l[t >> 20 & 15] + l[t >> 16 & 15])), a
                    }, T.prototype.arrayBuffer = function() {
                        this.finalize();
                        var t, e = this.blockCount,
                            n = this.s,
                            r = this.outputBlocks,
                            o = this.extraBytes,
                            i = 0,
                            s = 0,
                            a = this.outputBits >> 3;
                        t = o ? new ArrayBuffer(r + 1 << 2) : new ArrayBuffer(a);
                        for (var l = new Uint32Array(t); s < r;) {
                            for (i = 0; i < e && s < r; ++i, ++s) l[s] = n[i];
                            s % e == 0 && N(n)
                        }
                        return o && (l[i] = n[i], t = t.slice(0, a)), t
                    }, T.prototype.buffer = T.prototype.arrayBuffer, T.prototype.digest = T.prototype.array = function() {
                        this.finalize();
                        for (var t, e, n = this.blockCount, r = this.s, o = this.outputBlocks, i = this.extraBytes, s = 0, a = 0, l = []; a < o;) {
                            for (s = 0; s < n && a < o; ++s, ++a) t = a << 2, e = r[s], l[t] = 255 & e, l[t + 1] = e >> 8 & 255, l[t + 2] = e >> 16 & 255, l[t + 3] = e >> 24 & 255;
                            a % n == 0 && N(r)
                        }
                        return i && (t = a << 2, e = r[s], l[t] = 255 & e, i > 1 && (l[t + 1] = e >> 8 & 255), i > 2 && (l[t + 2] = e >> 16 & 255)), l
                    }, O.prototype = new T, O.prototype.finalize = function() {
                        return this.encode(this.outputBits, !0), T.prototype.finalize.call(this)
                    };
                    var N = function(t) {
                        var e, n, r, o, i, s, a, l, u, c, d, f, p, m, g, _, v, w, y, b, M, k, x, S, E, C, A, I, R, T, O, N, B, P, L, q, U, j, D, z, F, W, H, $, J, Y, V, K, Z, Q, X, G, tt, et, nt, rt, ot, it, st, at, lt, ut, ct;
                        for (r = 0; r < 48; r += 2) o = t[0] ^ t[10] ^ t[20] ^ t[30] ^ t[40], i = t[1] ^ t[11] ^ t[21] ^ t[31] ^ t[41], s = t[2] ^ t[12] ^ t[22] ^ t[32] ^ t[42], a = t[3] ^ t[13] ^ t[23] ^ t[33] ^ t[43], l = t[4] ^ t[14] ^ t[24] ^ t[34] ^ t[44], u = t[5] ^ t[15] ^ t[25] ^ t[35] ^ t[45], c = t[6] ^ t[16] ^ t[26] ^ t[36] ^ t[46], d = t[7] ^ t[17] ^ t[27] ^ t[37] ^ t[47], e = (f = t[8] ^ t[18] ^ t[28] ^ t[38] ^ t[48]) ^ (s << 1 | a >>> 31), n = (p = t[9] ^ t[19] ^ t[29] ^ t[39] ^ t[49]) ^ (a << 1 | s >>> 31), t[0] ^= e, t[1] ^= n, t[10] ^= e, t[11] ^= n, t[20] ^= e, t[21] ^= n, t[30] ^= e, t[31] ^= n, t[40] ^= e, t[41] ^= n, e = o ^ (l << 1 | u >>> 31), n = i ^ (u << 1 | l >>> 31), t[2] ^= e, t[3] ^= n, t[12] ^= e, t[13] ^= n, t[22] ^= e, t[23] ^= n, t[32] ^= e, t[33] ^= n, t[42] ^= e, t[43] ^= n, e = s ^ (c << 1 | d >>> 31), n = a ^ (d << 1 | c >>> 31), t[4] ^= e, t[5] ^= n, t[14] ^= e, t[15] ^= n, t[24] ^= e, t[25] ^= n, t[34] ^= e, t[35] ^= n, t[44] ^= e, t[45] ^= n, e = l ^ (f << 1 | p >>> 31), n = u ^ (p << 1 | f >>> 31), t[6] ^= e, t[7] ^= n, t[16] ^= e, t[17] ^= n, t[26] ^= e, t[27] ^= n, t[36] ^= e, t[37] ^= n, t[46] ^= e, t[47] ^= n, e = c ^ (o << 1 | i >>> 31), n = d ^ (i << 1 | o >>> 31), t[8] ^= e, t[9] ^= n, t[18] ^= e, t[19] ^= n, t[28] ^= e, t[29] ^= n, t[38] ^= e, t[39] ^= n, t[48] ^= e, t[49] ^= n, m = t[0], g = t[1], Y = t[11] << 4 | t[10] >>> 28, V = t[10] << 4 | t[11] >>> 28, I = t[20] << 3 | t[21] >>> 29, R = t[21] << 3 | t[20] >>> 29, at = t[31] << 9 | t[30] >>> 23, lt = t[30] << 9 | t[31] >>> 23, W = t[40] << 18 | t[41] >>> 14, H = t[41] << 18 | t[40] >>> 14, P = t[2] << 1 | t[3] >>> 31, L = t[3] << 1 | t[2] >>> 31, _ = t[13] << 12 | t[12] >>> 20, v = t[12] << 12 | t[13] >>> 20, K = t[22] << 10 | t[23] >>> 22, Z = t[23] << 10 | t[22] >>> 22, T = t[33] << 13 | t[32] >>> 19, O = t[32] << 13 | t[33] >>> 19, ut = t[42] << 2 | t[43] >>> 30, ct = t[43] << 2 | t[42] >>> 30, et = t[5] << 30 | t[4] >>> 2, nt = t[4] << 30 | t[5] >>> 2, q = t[14] << 6 | t[15] >>> 26, U = t[15] << 6 | t[14] >>> 26, w = t[25] << 11 | t[24] >>> 21, y = t[24] << 11 | t[25] >>> 21, Q = t[34] << 15 | t[35] >>> 17, X = t[35] << 15 | t[34] >>> 17, N = t[45] << 29 | t[44] >>> 3, B = t[44] << 29 | t[45] >>> 3, S = t[6] << 28 | t[7] >>> 4, E = t[7] << 28 | t[6] >>> 4, rt = t[17] << 23 | t[16] >>> 9, ot = t[16] << 23 | t[17] >>> 9, j = t[26] << 25 | t[27] >>> 7, D = t[27] << 25 | t[26] >>> 7, b = t[36] << 21 | t[37] >>> 11, M = t[37] << 21 | t[36] >>> 11, G = t[47] << 24 | t[46] >>> 8, tt = t[46] << 24 | t[47] >>> 8, $ = t[8] << 27 | t[9] >>> 5, J = t[9] << 27 | t[8] >>> 5, C = t[18] << 20 | t[19] >>> 12, A = t[19] << 20 | t[18] >>> 12, it = t[29] << 7 | t[28] >>> 25, st = t[28] << 7 | t[29] >>> 25, z = t[38] << 8 | t[39] >>> 24, F = t[39] << 8 | t[38] >>> 24, k = t[48] << 14 | t[49] >>> 18, x = t[49] << 14 | t[48] >>> 18, t[0] = m ^ ~_ & w, t[1] = g ^ ~v & y, t[10] = S ^ ~C & I, t[11] = E ^ ~A & R, t[20] = P ^ ~q & j, t[21] = L ^ ~U & D, t[30] = $ ^ ~Y & K, t[31] = J ^ ~V & Z, t[40] = et ^ ~rt & it, t[41] = nt ^ ~ot & st, t[2] = _ ^ ~w & b, t[3] = v ^ ~y & M, t[12] = C ^ ~I & T, t[13] = A ^ ~R & O, t[22] = q ^ ~j & z, t[23] = U ^ ~D & F, t[32] = Y ^ ~K & Q, t[33] = V ^ ~Z & X, t[42] = rt ^ ~it & at, t[43] = ot ^ ~st & lt, t[4] = w ^ ~b & k, t[5] = y ^ ~M & x, t[14] = I ^ ~T & N, t[15] = R ^ ~O & B, t[24] = j ^ ~z & W, t[25] = D ^ ~F & H, t[34] = K ^ ~Q & G, t[35] = Z ^ ~X & tt, t[44] = it ^ ~at & ut, t[45] = st ^ ~lt & ct, t[6] = b ^ ~k & m, t[7] = M ^ ~x & g, t[16] = T ^ ~N & S, t[17] = O ^ ~B & E, t[26] = z ^ ~W & P, t[27] = F ^ ~H & L, t[36] = Q ^ ~G & $, t[37] = X ^ ~tt & J, t[46] = at ^ ~ut & et, t[47] = lt ^ ~ct & nt, t[8] = k ^ ~m & _, t[9] = x ^ ~g & v, t[18] = N ^ ~S & C, t[19] = B ^ ~E & A, t[28] = W ^ ~P & q, t[29] = H ^ ~L & U, t[38] = G ^ ~$ & Y, t[39] = tt ^ ~J & V, t[48] = ut ^ ~et & rt, t[49] = ct ^ ~nt & ot, t[0] ^= h[r], t[1] ^= h[r + 1]
                    };
                    if (s) t.exports = k;
                    else
                        for (S = 0; S < x.length; ++S) o[x[S]] = k[x[S]]
                }()
            }(Dt);
            var zt = {},
                Ft = {};

            function Wt() {
                return (null == e ? void 0 : e.crypto) || (null == e ? void 0 : e.msCrypto) || {}
            }

            function Ht() {
                const t = Wt();
                return t.subtle || t.webkitSubtle
            }
            Object.defineProperty(Ft, "__esModule", {
                value: !0
            }), Ft.isBrowserCryptoAvailable = Ft.getSubtleCrypto = Ft.getBrowerCrypto = void 0, Ft.getBrowerCrypto = Wt, Ft.getSubtleCrypto = Ht, Ft.isBrowserCryptoAvailable = function() {
                return !!Wt() && !!Ht()
            };
            var $t = {};

            function Jt() {
                return "undefined" == typeof document && "undefined" != typeof navigator && "ReactNative" === navigator.product
            }

            function Yt() {
                return "undefined" != typeof process && void 0 !== process.versions && void 0 !== process.versions.node
            }

            function Vt(t) {
                return Lt(t)
            }

            function Kt(t) {
                return function(t) {
                    const e = t.startsWith("0x");
                    return t = (t = Bt(t)).startsWith(kt) ? t.substring(1) : t, e ? Pt(t) : t
                }(Pt(t))
            }
            Object.defineProperty($t, "__esModule", {
                    value: !0
                }), $t.isBrowser = $t.isNode = $t.isReactNative = void 0, $t.isReactNative = Jt, $t.isNode = Yt, $t.isBrowser = function() {
                    return !Jt() && !Yt()
                },
                function(t) {
                    var n = e && e.__createBinding || (Object.create ? function(t, e, n, r) {
                            void 0 === r && (r = n), Object.defineProperty(t, r, {
                                enumerable: !0,
                                get: function() {
                                    return e[n]
                                }
                            })
                        } : function(t, e, n, r) {
                            void 0 === r && (r = n), t[r] = e[n]
                        }),
                        r = e && e.__exportStar || function(t, e) {
                            for (var r in t) "default" === r || e.hasOwnProperty(r) || n(e, t, r)
                        };
                    Object.defineProperty(t, "__esModule", {
                        value: !0
                    }), r(Ft, t), r($t, t)
                }(zt);
            const Zt = function() {
                return Date.now() * Math.pow(10, 3) + Math.floor(Math.random() * Math.pow(10, 3))
            };

            function Qt() {
                const t = ((t, e) => {
                    for (e = t = ""; t++ < 36; e += 51 * t & 52 ? (15 ^ t ? 8 ^ Math.random() * (20 ^ t ? 16 : 4) : 4).toString(16) : "-");
                    return e
                })();
                return t
            }

            function Xt(t, e) {
                return function(t, e) {
                    return !("string" != typeof t || !t.match(/^0x[0-9A-Fa-f]*$/) || e && t.length !== 2 + 2 * e)
                }(t, e)
            }

            function Gt(t) {
                return void 0 !== t.result
            }

            function te(t) {
                return void 0 !== t.error
            }

            function ee(t) {
                return void 0 !== t.event
            }

            function ne(t) {
                t = Bt(t.toLowerCase());
                const e = Bt(Dt.exports.keccak_256(Rt(t)));
                let n = "";
                for (let r = 0; r < t.length; r++) parseInt(e[r], 16) > 7 ? n += t[r].toUpperCase() : n += t[r];
                return Pt(n)
            }

            function re(t) {
                var e;
                return (e = t) && e.length && !Xt(t[0]) && (t[0] = Ut(t[0])), t
            }

            function oe(t) {
                if (void 0 !== t.type && "0" !== t.type) return t;
                if (void 0 === t.from || !(e = t.from) || "0x" !== e.toLowerCase().substring(0, 2) || !/^(0x)?[0-9a-f]{40}$/i.test(e) || !/^(0x)?[0-9a-f]{40}$/.test(e) && !/^(0x)?[0-9A-F]{40}$/.test(e) && e !== ne(e)) throw new Error("Transaction object must include a valid 'from' value.");
                var e;

                function n(t) {
                    let e = t;
                    return ("number" == typeof t || "string" == typeof t && ! function(t) {
                        return "" === t || "string" == typeof t && "" === t.trim()
                    }(t)) && (Xt(t) ? "string" == typeof t && (e = Vt(t)) : e = jt(t)), "string" == typeof e && (e = Kt(e)), e
                }
                const r = {
                        from: Vt(t.from),
                        to: void 0 === t.to ? "" : Vt(t.to),
                        gasPrice: void 0 === t.gasPrice ? "" : n(t.gasPrice),
                        gas: void 0 === t.gas ? void 0 === t.gasLimit ? "" : n(t.gasLimit) : n(t.gas),
                        value: void 0 === t.value ? "" : n(t.value),
                        nonce: void 0 === t.nonce ? "" : n(t.nonce),
                        data: void 0 === t.data ? "" : Vt(t.data) || "0x"
                    },
                    o = ["gasPrice", "gas", "value", "nonce"];
                return Object.keys(r).forEach((t => {
                    !r[t].trim().length && o.includes(t) && delete r[t]
                })), r
            }
            var ie = {},
                se = t => encodeURIComponent(t).replace(/[!'()*]/g, (t => `%${t.charCodeAt(0).toString(16).toUpperCase()}`)),
                ae = "%[a-f0-9]{2}",
                le = new RegExp(ae, "gi"),
                ue = new RegExp("(" + ae + ")+", "gi");

            function ce(t, e) {
                try {
                    return decodeURIComponent(t.join(""))
                } catch (o) {}
                if (1 === t.length) return t;
                e = e || 1;
                var n = t.slice(0, e),
                    r = t.slice(e);
                return Array.prototype.concat.call([], ce(n), ce(r))
            }

            function he(t) {
                try {
                    return decodeURIComponent(t)
                } catch (r) {
                    for (var e = t.match(le), n = 1; n < e.length; n++) e = (t = ce(e, n).join("")).match(le);
                    return t
                }
            }
            var de = function(t) {
                    if ("string" != typeof t) throw new TypeError("Expected `encodedURI` to be of type `string`, got `" + typeof t + "`");
                    try {
                        return t = t.replace(/\+/g, " "), decodeURIComponent(t)
                    } catch (e) {
                        return function(t) {
                            for (var n = {
                                    "%FE%FF": "��",
                                    "%FF%FE": "��"
                                }, r = ue.exec(t); r;) {
                                try {
                                    n[r[0]] = decodeURIComponent(r[0])
                                } catch (e) {
                                    var o = he(r[0]);
                                    o !== r[0] && (n[r[0]] = o)
                                }
                                r = ue.exec(t)
                            }
                            n["%C2"] = "�";
                            for (var i = Object.keys(n), s = 0; s < i.length; s++) {
                                var a = i[s];
                                t = t.replace(new RegExp(a, "g"), n[a])
                            }
                            return t
                        }(t)
                    }
                },
                fe = (t, e) => {
                    if ("string" != typeof t || "string" != typeof e) throw new TypeError("Expected the arguments to be of type `string`");
                    if ("" === e) return [t];
                    const n = t.indexOf(e);
                    return -1 === n ? [t] : [t.slice(0, n), t.slice(n + e.length)]
                };

            function pe(t) {
                return ie.parse(t)
            }

            function me(t) {
                return ie.stringify(t)
            }! function(t) {
                const e = se,
                    n = de,
                    r = fe;

                function o(t) {
                    if ("string" != typeof t || 1 !== t.length) throw new TypeError("arrayFormatSeparator must be single character string")
                }

                function i(t, n) {
                    return n.encode ? n.strict ? e(t) : encodeURIComponent(t) : t
                }

                function s(t, e) {
                    return e.decode ? n(t) : t
                }

                function a(t) {
                    return Array.isArray(t) ? t.sort() : "object" == typeof t ? a(Object.keys(t)).sort(((t, e) => Number(t) - Number(e))).map((e => t[e])) : t
                }

                function l(t) {
                    const e = t.indexOf("#");
                    return -1 !== e && (t = t.slice(0, e)), t
                }

                function u(t) {
                    const e = (t = l(t)).indexOf("?");
                    return -1 === e ? "" : t.slice(e + 1)
                }

                function c(t, e) {
                    return e.parseNumbers && !Number.isNaN(Number(t)) && "string" == typeof t && "" !== t.trim() ? t = Number(t) : !e.parseBooleans || null === t || "true" !== t.toLowerCase() && "false" !== t.toLowerCase() || (t = "true" === t.toLowerCase()), t
                }

                function h(t, e) {
                    o((e = Object.assign({
                        decode: !0,
                        sort: !0,
                        arrayFormat: "none",
                        arrayFormatSeparator: ",",
                        parseNumbers: !1,
                        parseBooleans: !1
                    }, e)).arrayFormatSeparator);
                    const n = function(t) {
                            let e;
                            switch (t.arrayFormat) {
                                case "index":
                                    return (t, n, r) => {
                                        e = /\[(\d*)\]$/.exec(t), t = t.replace(/\[\d*\]$/, ""), e ? (void 0 === r[t] && (r[t] = {}), r[t][e[1]] = n) : r[t] = n
                                    };
                                case "bracket":
                                    return (t, n, r) => {
                                        e = /(\[\])$/.exec(t), t = t.replace(/\[\]$/, ""), e ? void 0 !== r[t] ? r[t] = [].concat(r[t], n) : r[t] = [n] : r[t] = n
                                    };
                                case "comma":
                                case "separator":
                                    return (e, n, r) => {
                                        const o = "string" == typeof n && n.split("").indexOf(t.arrayFormatSeparator) > -1 ? n.split(t.arrayFormatSeparator).map((e => s(e, t))) : null === n ? n : s(n, t);
                                        r[e] = o
                                    };
                                default:
                                    return (t, e, n) => {
                                        void 0 !== n[t] ? n[t] = [].concat(n[t], e) : n[t] = e
                                    }
                            }
                        }(e),
                        i = Object.create(null);
                    if ("string" != typeof t) return i;
                    if (!(t = t.trim().replace(/^[?#&]/, ""))) return i;
                    for (const o of t.split("&")) {
                        let [t, a] = r(e.decode ? o.replace(/\+/g, " ") : o, "=");
                        a = void 0 === a ? null : ["comma", "separator"].includes(e.arrayFormat) ? a : s(a, e), n(s(t, e), a, i)
                    }
                    for (const r of Object.keys(i)) {
                        const t = i[r];
                        if ("object" == typeof t && null !== t)
                            for (const n of Object.keys(t)) t[n] = c(t[n], e);
                        else i[r] = c(t, e)
                    }
                    return !1 === e.sort ? i : (!0 === e.sort ? Object.keys(i).sort() : Object.keys(i).sort(e.sort)).reduce(((t, e) => {
                        const n = i[e];
                        return Boolean(n) && "object" == typeof n && !Array.isArray(n) ? t[e] = a(n) : t[e] = n, t
                    }), Object.create(null))
                }
                t.extract = u, t.parse = h, t.stringify = (t, e) => {
                    if (!t) return "";
                    o((e = Object.assign({
                        encode: !0,
                        strict: !0,
                        arrayFormat: "none",
                        arrayFormatSeparator: ","
                    }, e)).arrayFormatSeparator);
                    const n = n => e.skipNull && null == t[n] || e.skipEmptyString && "" === t[n],
                        r = function(t) {
                            switch (t.arrayFormat) {
                                case "index":
                                    return e => (n, r) => {
                                        const o = n.length;
                                        return void 0 === r || t.skipNull && null === r || t.skipEmptyString && "" === r ? n : null === r ? [...n, [i(e, t), "[", o, "]"].join("")] : [...n, [i(e, t), "[", i(o, t), "]=", i(r, t)].join("")]
                                    };
                                case "bracket":
                                    return e => (n, r) => void 0 === r || t.skipNull && null === r || t.skipEmptyString && "" === r ? n : null === r ? [...n, [i(e, t), "[]"].join("")] : [...n, [i(e, t), "[]=", i(r, t)].join("")];
                                case "comma":
                                case "separator":
                                    return e => (n, r) => null == r || 0 === r.length ? n : 0 === n.length ? [
                                        [i(e, t), "=", i(r, t)].join("")
                                    ] : [
                                        [n, i(r, t)].join(t.arrayFormatSeparator)
                                    ];
                                default:
                                    return e => (n, r) => void 0 === r || t.skipNull && null === r || t.skipEmptyString && "" === r ? n : null === r ? [...n, i(e, t)] : [...n, [i(e, t), "=", i(r, t)].join("")]
                            }
                        }(e),
                        s = {};
                    for (const o of Object.keys(t)) n(o) || (s[o] = t[o]);
                    const a = Object.keys(s);
                    return !1 !== e.sort && a.sort(e.sort), a.map((n => {
                        const o = t[n];
                        return void 0 === o ? "" : null === o ? i(n, e) : Array.isArray(o) ? o.reduce(r(n), []).join("&") : i(n, e) + "=" + i(o, e)
                    })).filter((t => t.length > 0)).join("&")
                }, t.parseUrl = (t, e) => {
                    e = Object.assign({
                        decode: !0
                    }, e);
                    const [n, o] = r(t, "#");
                    return Object.assign({
                        url: n.split("?")[0] || "",
                        query: h(u(t), e)
                    }, e && e.parseFragmentIdentifier && o ? {
                        fragmentIdentifier: s(o, e)
                    } : {})
                }, t.stringifyUrl = (e, n) => {
                    n = Object.assign({
                        encode: !0,
                        strict: !0
                    }, n);
                    const r = l(e.url).split("?")[0] || "",
                        o = t.extract(e.url),
                        s = t.parse(o, {
                            sort: !1
                        }),
                        a = Object.assign(s, e.query);
                    let u = t.stringify(a, n);
                    u && (u = `?${u}`);
                    let c = function(t) {
                        let e = "";
                        const n = t.indexOf("#");
                        return -1 !== n && (e = t.slice(n)), e
                    }(e.url);
                    return e.fragmentIdentifier && (c = `#${i(e.fragmentIdentifier,n)}`), `${r}${u}${c}`
                }
            }(ie);
            class ge {
                constructor() {
                    this._eventEmitters = [], "undefined" != typeof window && void 0 !== window.addEventListener && (window.addEventListener("online", (() => this.trigger("online"))), window.addEventListener("offline", (() => this.trigger("offline"))))
                }
                on(t, e) {
                    this._eventEmitters.push({
                        event: t,
                        callback: e
                    })
                }
                trigger(t) {
                    let e = [];
                    t && (e = this._eventEmitters.filter((e => e.event === t))), e.forEach((t => {
                        t.callback()
                    }))
                }
            }
            const _e = void 0 !== global.WebSocket ? global.WebSocket : require("ws");
            class ve {
                constructor(t) {
                    if (this.opts = t, this._queue = [], this._events = [], this._subscriptions = [], this._protocol = t.protocol, this._version = t.version, this._url = "", this._netMonitor = null, this._socket = null, this._nextSocket = null, this._subscriptions = t.subscriptions || [], this._netMonitor = t.netMonitor || new ge, !t.url || "string" != typeof t.url) throw new Error("Missing or invalid WebSocket url");
                    this._url = t.url, this._netMonitor.on("online", (() => this._socketCreate()))
                }
                set readyState(t) {}
                get readyState() {
                    return this._socket ? this._socket.readyState : -1
                }
                set connecting(t) {}
                get connecting() {
                    return 0 === this.readyState
                }
                set connected(t) {}
                get connected() {
                    return 1 === this.readyState
                }
                set closing(t) {}
                get closing() {
                    return 2 === this.readyState
                }
                set closed(t) {}
                get closed() {
                    return 3 === this.readyState
                }
                open() {
                    this._socketCreate()
                }
                close() {
                    this._socketClose()
                }
                send(t, e, n) {
                    if (!e || "string" != typeof e) throw new Error("Missing or invalid topic field");
                    this._socketSend({
                        topic: e,
                        type: "pub",
                        payload: t,
                        silent: !!n
                    })
                }
                subscribe(t) {
                    this._socketSend({
                        topic: t,
                        type: "sub",
                        payload: "",
                        silent: !0
                    })
                }
                on(t, e) {
                    this._events.push({
                        event: t,
                        callback: e
                    })
                }
                _socketCreate() {
                    if (this._nextSocket) return;
                    const t = function(t, e, n) {
                        var r, o;
                        const i = (t.startsWith("https") ? t.replace("https", "wss") : t.startsWith("http") ? t.replace("http", "ws") : t).split("?"),
                            s = z() ? {
                                protocol: e,
                                version: n,
                                env: "browser",
                                host: (null === (r = K()) || void 0 === r ? void 0 : r.host) || ""
                            } : {
                                protocol: e,
                                version: n,
                                env: (null === (o = P()) || void 0 === o ? void 0 : o.name) || ""
                            },
                            a = function(t, e) {
                                let n = pe(t);
                                return n = Object.assign(Object.assign({}, n), e), me(n)
                            }(function(t) {
                                const e = -1 !== t.indexOf("?") ? t.indexOf("?") : void 0;
                                return void 0 !== e ? t.substr(e) : ""
                            }(i[1] || ""), s);
                        return i[0] + "?" + a
                    }(this._url, this._protocol, this._version);
                    if (this._nextSocket = new _e(t), !this._nextSocket) throw new Error("Failed to create socket");
                    this._nextSocket.onmessage = t => this._socketReceive(t), this._nextSocket.onopen = () => this._socketOpen(), this._nextSocket.onerror = t => this._socketError(t), this._nextSocket.onclose = () => {
                        setTimeout((() => {
                            this._nextSocket = null, this._socketCreate()
                        }), 1e3)
                    }
                }
                _socketOpen() {
                    this._socketClose(), this._socket = this._nextSocket, this._nextSocket = null, this._queueSubscriptions(), this._pushQueue()
                }
                _socketClose() {
                    this._socket && (this._socket.onclose = () => {}, this._socket.close())
                }
                _socketSend(t) {
                    const e = JSON.stringify(t);
                    this._socket && 1 === this._socket.readyState ? this._socket.send(e) : (this._setToQueue(t), this._socketCreate())
                }
                async _socketReceive(t) {
                    let e;
                    try {
                        e = JSON.parse(t.data)
                    } catch (n) {
                        return
                    }
                    if (this._socketSend({
                            topic: e.topic,
                            type: "ack",
                            payload: "",
                            silent: !0
                        }), this._socket && 1 === this._socket.readyState) {
                        const t = this._events.filter((t => "message" === t.event));
                        t && t.length && t.forEach((t => t.callback(e)))
                    }
                }
                _socketError(t) {
                    const e = this._events.filter((t => "error" === t.event));
                    e && e.length && e.forEach((e => e.callback(t)))
                }
                _queueSubscriptions() {
                    this._subscriptions.forEach((t => this._queue.push({
                        topic: t,
                        type: "sub",
                        payload: "",
                        silent: !0
                    }))), this._subscriptions = this.opts.subscriptions || []
                }
                _setToQueue(t) {
                    this._queue.push(t)
                }
                _pushQueue() {
                    this._queue.forEach((t => this._socketSend(t))), this._queue = []
                }
            }
            const we = "Session currently connected",
                ye = "Session currently disconnected",
                be = "JSON RPC response format is invalid",
                Me = "User close QRCode Modal";
            class ke {
                constructor() {
                    this._eventEmitters = []
                }
                subscribe(t) {
                    this._eventEmitters.push(t)
                }
                unsubscribe(t) {
                    this._eventEmitters = this._eventEmitters.filter((e => e.event !== t))
                }
                trigger(t) {
                    let e, n = [];
                    e = void 0 !== t.method ? t.method : Gt(t) || te(t) ? `response:${t.id}` : ee(t) ? t.event : "", e && (n = this._eventEmitters.filter((t => t.event === e))), n && n.length || function(t) {
                        return ht.includes(t) || t.startsWith("wc_")
                    }(e) || ee(e) || (n = this._eventEmitters.filter((t => "call_request" === t.event))), n.forEach((e => {
                        if (te(t)) {
                            const n = new Error(t.error.message);
                            e.callback(n, null)
                        } else e.callback(null, t)
                    }))
                }
            }
            class xe {
                constructor(t = "walletconnect") {
                    this.storageId = t
                }
                getSession() {
                    let t = null;
                    const e = ot(this.storageId);
                    return e && void 0 !== e.bridge && (t = e), t
                }
                setSession(t) {
                    return rt(this.storageId, t), t
                }
                removeSession() {
                    it(this.storageId)
                }
            }
            const Se = "abcdefghijklmnopqrstuvwxyz0123456789".split("").map((t => `https://${t}.bridge.walletconnect.org`));

            function Ee() {
                return Se[Math.floor(Math.random() * Se.length)]
            }
            const Ce = "AES-CBC",
                Ae = "HMAC";
            async function Ie(t, e = "AES-CBC") {
                return zt.getSubtleCrypto().importKey("raw", t, function(t) {
                    return t === Ce ? {
                        length: 256,
                        name: Ce
                    } : {
                        hash: {
                            name: "SHA-256"
                        },
                        name: Ae
                    }
                }(e), !0, function(t) {
                    return t === Ce ? ["encrypt", "decrypt"] : ["sign", "verify"]
                }(e))
            }

            function Re(t, e, n) {
                return async function(t, e, n) {
                    const r = zt.getSubtleCrypto(),
                        o = await Ie(e, Ce),
                        i = await r.encrypt({
                            iv: t,
                            name: Ce
                        }, o, n);
                    return new Uint8Array(i)
                }(t, e, n)
            }

            function Te(t, e, n) {
                return async function(t, e, n) {
                    const r = zt.getSubtleCrypto(),
                        o = await Ie(e, Ce),
                        i = await r.decrypt({
                            iv: t,
                            name: Ce
                        }, o, n);
                    return new Uint8Array(i)
                }(t, e, n)
            }
            async function Oe(t, e) {
                const n = await async function(t, e) {
                    const n = zt.getSubtleCrypto(),
                        r = await Ie(t, Ae),
                        o = await n.sign({
                            length: 256,
                            name: Ae
                        }, r, e);
                    return new Uint8Array(o)
                }(t, e);
                return n
            }
            async function Ne(t) {
                const e = function(t) {
                    return zt.getBrowerCrypto().getRandomValues(new Uint8Array(t))
                }((t || 256) / 8);
                return xt(Et(e)).buffer
            }
            async function Be(t, e) {
                const n = It(t.data),
                    r = It(t.iv),
                    o = Ct(It(t.hmac), !1),
                    i = Ot(n, r),
                    s = Ct(await Oe(e, i), !1);
                return Bt(o) === Bt(s)
            }
            var Pe = Object.freeze(Object.defineProperty({
                __proto__: null,
                generateKey: Ne,
                verifyHmac: Be,
                encrypt: async function(t, e, n) {
                    const r = xt(qt(e)),
                        o = xt(qt(n || await Ne(128))),
                        i = Ct(o, !1),
                        s = Tt(JSON.stringify(t)),
                        a = await Re(o, r, s),
                        l = Ct(a, !1),
                        u = Ot(a, o);
                    return {
                        data: l,
                        hmac: Ct(await Oe(r, u), !1),
                        iv: i
                    }
                },
                decrypt: async function(t, e) {
                    const n = xt(qt(e));
                    if (!n) throw new Error("Missing key: required for decryption");
                    if (!(await Be(t, n))) return null;
                    const r = It(t.data),
                        o = It(t.iv),
                        i = At(await Te(o, n, r));
                    let s;
                    try {
                        s = JSON.parse(i)
                    } catch (a) {
                        return null
                    }
                    return s
                }
            }, Symbol.toStringTag, {
                value: "Module"
            }));
            class Le extends class {
                constructor(t) {
                    if (this.protocol = "wc", this.version = 1, this._bridge = "", this._key = null, this._clientId = "", this._clientMeta = null, this._peerId = "", this._peerMeta = null, this._handshakeId = 0, this._handshakeTopic = "", this._connected = !1, this._accounts = [], this._chainId = 0, this._networkId = 0, this._rpcUrl = "", this._eventManager = new ke, this._clientMeta = tt() || t.connectorOpts.clientMeta || null, this._cryptoLib = t.cryptoLib, this._sessionStorage = t.sessionStorage || new xe(t.connectorOpts.storageId), this._qrcodeModal = t.connectorOpts.qrcodeModal, this._qrcodeModalOptions = t.connectorOpts.qrcodeModalOptions, this._signingMethods = [...dt, ...t.connectorOpts.signingMethods || []], !t.connectorOpts.bridge && !t.connectorOpts.uri && !t.connectorOpts.session) throw new Error("Missing one of the required parameters: bridge / uri / session");
                    var e;
                    t.connectorOpts.bridge && (this.bridge = function(t) {
                        return "walletconnect.org" === function(t) {
                            return function(t) {
                                let e = t.indexOf("//") > -1 ? t.split("/")[2] : t.split("/")[0];
                                return e = e.split(":")[0], e = e.split("?")[0], e
                            }(t).split(".").slice(-2).join(".")
                        }(t)
                    }(e = t.connectorOpts.bridge) ? Ee() : e), t.connectorOpts.uri && (this.uri = t.connectorOpts.uri);
                    const n = t.connectorOpts.session || this._getStorageSession();
                    n && (this.session = n), this.handshakeId && this._subscribeToSessionResponse(this.handshakeId, "Session request rejected"), this._transport = t.transport || new ve({
                        protocol: this.protocol,
                        version: this.version,
                        url: this.bridge,
                        subscriptions: [this.clientId]
                    }), this._subscribeToInternalEvents(), this._initTransport(), t.connectorOpts.uri && this._subscribeToSessionRequest(), t.pushServerOpts && this._registerPushServer(t.pushServerOpts)
                }
                set bridge(t) {
                    t && (this._bridge = t)
                }
                get bridge() {
                    return this._bridge
                }
                set key(t) {
                    if (!t) return;
                    const e = It(t).buffer;
                    this._key = e
                }
                get key() {
                    return this._key ? (t = this._key, e = !0, Ct(new Uint8Array(t), !e)) : "";
                    var t, e
                }
                set clientId(t) {
                    t && (this._clientId = t)
                }
                get clientId() {
                    let t = this._clientId;
                    return t || (t = this._clientId = Qt()), this._clientId
                }
                set peerId(t) {
                    t && (this._peerId = t)
                }
                get peerId() {
                    return this._peerId
                }
                set clientMeta(t) {}
                get clientMeta() {
                    let t = this._clientMeta;
                    return t || (t = this._clientMeta = tt()), t
                }
                set peerMeta(t) {
                    this._peerMeta = t
                }
                get peerMeta() {
                    return this._peerMeta
                }
                set handshakeTopic(t) {
                    t && (this._handshakeTopic = t)
                }
                get handshakeTopic() {
                    return this._handshakeTopic
                }
                set handshakeId(t) {
                    t && (this._handshakeId = t)
                }
                get handshakeId() {
                    return this._handshakeId
                }
                get uri() {
                    return this._formatUri()
                }
                set uri(t) {
                    if (!t) return;
                    const {
                        handshakeTopic: e,
                        bridge: n,
                        key: r
                    } = this._parseUri(t);
                    this.handshakeTopic = e, this.bridge = n, this.key = r
                }
                set chainId(t) {
                    this._chainId = t
                }
                get chainId() {
                    return this._chainId
                }
                set networkId(t) {
                    this._networkId = t
                }
                get networkId() {
                    return this._networkId
                }
                set accounts(t) {
                    this._accounts = t
                }
                get accounts() {
                    return this._accounts
                }
                set rpcUrl(t) {
                    this._rpcUrl = t
                }
                get rpcUrl() {
                    return this._rpcUrl
                }
                set connected(t) {}
                get connected() {
                    return this._connected
                }
                set pending(t) {}
                get pending() {
                    return !!this._handshakeTopic
                }
                get session() {
                    return {
                        connected: this.connected,
                        accounts: this.accounts,
                        chainId: this.chainId,
                        bridge: this.bridge,
                        key: this.key,
                        clientId: this.clientId,
                        clientMeta: this.clientMeta,
                        peerId: this.peerId,
                        peerMeta: this.peerMeta,
                        handshakeId: this.handshakeId,
                        handshakeTopic: this.handshakeTopic
                    }
                }
                set session(t) {
                    t && (this._connected = t.connected, this.accounts = t.accounts, this.chainId = t.chainId, this.bridge = t.bridge, this.key = t.key, this.clientId = t.clientId, this.clientMeta = t.clientMeta, this.peerId = t.peerId, this.peerMeta = t.peerMeta, this.handshakeId = t.handshakeId, this.handshakeTopic = t.handshakeTopic)
                }
                on(t, e) {
                    const n = {
                        event: t,
                        callback: e
                    };
                    this._eventManager.subscribe(n)
                }
                off(t) {
                    this._eventManager.unsubscribe(t)
                }
                async createInstantRequest(t) {
                    this._key = await this._generateKey();
                    const e = this._formatRequest({
                        method: "wc_instantRequest",
                        params: [{
                            peerId: this.clientId,
                            peerMeta: this.clientMeta,
                            request: this._formatRequest(t)
                        }]
                    });
                    this.handshakeId = e.id, this.handshakeTopic = Qt(), this._eventManager.trigger({
                        event: "display_uri",
                        params: [this.uri]
                    }), this.on("modal_closed", (() => {
                        throw new Error(Me)
                    }));
                    const n = () => {
                        this.killSession()
                    };
                    try {
                        const t = await this._sendCallRequest(e);
                        return t && n(), t
                    } catch (r) {
                        throw n(), r
                    }
                }
                async connect(t) {
                    if (!this._qrcodeModal) throw new Error("QRCode Modal not provided");
                    return this.connected ? {
                        chainId: this.chainId,
                        accounts: this.accounts
                    } : (await this.createSession(t), new Promise((async (t, e) => {
                        this.on("modal_closed", (() => e(new Error(Me)))), this.on("connect", ((n, r) => {
                            if (n) return e(n);
                            t(r.params[0])
                        }))
                    })))
                }
                async createSession(t) {
                    if (this._connected) throw new Error(we);
                    if (this.pending) return;
                    this._key = await this._generateKey();
                    const e = this._formatRequest({
                        method: "wc_sessionRequest",
                        params: [{
                            peerId: this.clientId,
                            peerMeta: this.clientMeta,
                            chainId: t && t.chainId ? t.chainId : null
                        }]
                    });
                    this.handshakeId = e.id, this.handshakeTopic = Qt(), this._sendSessionRequest(e, "Session update rejected", {
                        topic: this.handshakeTopic
                    }), this._eventManager.trigger({
                        event: "display_uri",
                        params: [this.uri]
                    })
                }
                approveSession(t) {
                    if (this._connected) throw new Error(we);
                    this.chainId = t.chainId, this.accounts = t.accounts, this.networkId = t.networkId || 0, this.rpcUrl = t.rpcUrl || "";
                    const e = {
                            approved: !0,
                            chainId: this.chainId,
                            networkId: this.networkId,
                            accounts: this.accounts,
                            rpcUrl: this.rpcUrl,
                            peerId: this.clientId,
                            peerMeta: this.clientMeta
                        },
                        n = {
                            id: this.handshakeId,
                            jsonrpc: "2.0",
                            result: e
                        };
                    this._sendResponse(n), this._connected = !0, this._setStorageSession(), this._eventManager.trigger({
                        event: "connect",
                        params: [{
                            peerId: this.peerId,
                            peerMeta: this.peerMeta,
                            chainId: this.chainId,
                            accounts: this.accounts
                        }]
                    })
                }
                rejectSession(t) {
                    if (this._connected) throw new Error(we);
                    const e = t && t.message ? t.message : "Session Rejected",
                        n = this._formatResponse({
                            id: this.handshakeId,
                            error: {
                                message: e
                            }
                        });
                    this._sendResponse(n), this._connected = !1, this._eventManager.trigger({
                        event: "disconnect",
                        params: [{
                            message: e
                        }]
                    }), this._removeStorageSession()
                }
                updateSession(t) {
                    if (!this._connected) throw new Error(ye);
                    this.chainId = t.chainId, this.accounts = t.accounts, this.networkId = t.networkId || 0, this.rpcUrl = t.rpcUrl || "";
                    const e = {
                            approved: !0,
                            chainId: this.chainId,
                            networkId: this.networkId,
                            accounts: this.accounts,
                            rpcUrl: this.rpcUrl
                        },
                        n = this._formatRequest({
                            method: "wc_sessionUpdate",
                            params: [e]
                        });
                    this._sendSessionRequest(n, "Session update rejected"), this._eventManager.trigger({
                        event: "session_update",
                        params: [{
                            chainId: this.chainId,
                            accounts: this.accounts
                        }]
                    }), this._manageStorageSession()
                }
                async killSession(t) {
                    const e = t ? t.message : "Session Disconnected",
                        n = this._formatRequest({
                            method: "wc_sessionUpdate",
                            params: [{
                                approved: !1,
                                chainId: null,
                                networkId: null,
                                accounts: null
                            }]
                        });
                    await this._sendRequest(n), this._handleSessionDisconnect(e)
                }
                async sendTransaction(t) {
                    if (!this._connected) throw new Error(ye);
                    const e = oe(t),
                        n = this._formatRequest({
                            method: "eth_sendTransaction",
                            params: [e]
                        });
                    return await this._sendCallRequest(n)
                }
                async signTransaction(t) {
                    if (!this._connected) throw new Error(ye);
                    const e = oe(t),
                        n = this._formatRequest({
                            method: "eth_signTransaction",
                            params: [e]
                        });
                    return await this._sendCallRequest(n)
                }
                async signMessage(t) {
                    if (!this._connected) throw new Error(ye);
                    const e = this._formatRequest({
                        method: "eth_sign",
                        params: t
                    });
                    return await this._sendCallRequest(e)
                }
                async signPersonalMessage(t) {
                    if (!this._connected) throw new Error(ye);
                    t = re(t);
                    const e = this._formatRequest({
                        method: "personal_sign",
                        params: t
                    });
                    return await this._sendCallRequest(e)
                }
                async signTypedData(t) {
                    if (!this._connected) throw new Error(ye);
                    const e = this._formatRequest({
                        method: "eth_signTypedData",
                        params: t
                    });
                    return await this._sendCallRequest(e)
                }
                async updateChain(t) {
                    if (!this._connected) throw new Error("Session currently disconnected");
                    const e = this._formatRequest({
                        method: "wallet_updateChain",
                        params: [t]
                    });
                    return await this._sendCallRequest(e)
                }
                unsafeSend(t, e) {
                    return this._sendRequest(t, e), this._eventManager.trigger({
                        event: "call_request_sent",
                        params: [{
                            request: t,
                            options: e
                        }]
                    }), new Promise(((e, n) => {
                        this._subscribeToResponse(t.id, ((t, r) => {
                            if (t) n(t);
                            else {
                                if (!r) throw new Error("Missing JSON RPC response");
                                e(r)
                            }
                        }))
                    }))
                }
                async sendCustomRequest(t, e) {
                    if (!this._connected) throw new Error(ye);
                    switch (t.method) {
                        case "eth_accounts":
                            return this.accounts;
                        case "eth_chainId":
                            return jt(this.chainId);
                        case "eth_sendTransaction":
                        case "eth_signTransaction":
                            t.params && (t.params[0] = oe(t.params[0]));
                            break;
                        case "personal_sign":
                            t.params && (t.params = re(t.params))
                    }
                    const n = this._formatRequest(t);
                    return await this._sendCallRequest(n, e)
                }
                approveRequest(t) {
                    if (!Gt(t)) throw new Error('JSON-RPC success response must include "result" field'); {
                        const e = this._formatResponse(t);
                        this._sendResponse(e)
                    }
                }
                rejectRequest(t) {
                    if (!te(t)) throw new Error('JSON-RPC error response must include "error" field'); {
                        const e = this._formatResponse(t);
                        this._sendResponse(e)
                    }
                }
                transportClose() {
                    this._transport.close()
                }
                async _sendRequest(t, e) {
                    const n = this._formatRequest(t),
                        r = await this._encrypt(n),
                        o = void 0 !== (null == e ? void 0 : e.topic) ? e.topic : this.peerId,
                        i = JSON.stringify(r),
                        s = void 0 !== (null == e ? void 0 : e.forcePushNotification) ? !e.forcePushNotification : function(t) {
                            return !!t.method.startsWith("wc_") || !dt.includes(t.method)
                        }(n);
                    this._transport.send(i, o, s)
                }
                async _sendResponse(t) {
                    const e = await this._encrypt(t),
                        n = this.peerId,
                        r = JSON.stringify(e);
                    this._transport.send(r, n, !0)
                }
                async _sendSessionRequest(t, e, n) {
                    this._sendRequest(t, n), this._subscribeToSessionResponse(t.id, e)
                }
                _sendCallRequest(t, e) {
                    return this._sendRequest(t, e), this._eventManager.trigger({
                        event: "call_request_sent",
                        params: [{
                            request: t,
                            options: e
                        }]
                    }), this._subscribeToCallResponse(t.id)
                }
                _formatRequest(t) {
                    if (void 0 === t.method) throw new Error('JSON RPC request must have valid "method" value');
                    return {
                        id: void 0 === t.id ? Zt() : t.id,
                        jsonrpc: "2.0",
                        method: t.method,
                        params: void 0 === t.params ? [] : t.params
                    }
                }
                _formatResponse(t) {
                    if (void 0 === t.id) throw new Error('JSON RPC request must have valid "id" value');
                    const e = {
                        id: t.id,
                        jsonrpc: "2.0"
                    };
                    if (te(t)) {
                        const n = function(t) {
                            const e = t.message || "Failed or Rejected Request";
                            let n = -32e3;
                            if (t && !t.code) switch (e) {
                                case "Parse error":
                                    n = -32700;
                                    break;
                                case "Invalid request":
                                    n = -32600;
                                    break;
                                case "Method not found":
                                    n = -32601;
                                    break;
                                case "Invalid params":
                                    n = -32602;
                                    break;
                                case "Internal error":
                                    n = -32603;
                                    break;
                                default:
                                    n = -32e3
                            }
                            return {
                                code: n,
                                message: e
                            }
                        }(t.error);
                        return Object.assign(Object.assign(Object.assign({}, e), t), {
                            error: n
                        })
                    }
                    if (Gt(t)) return Object.assign(Object.assign({}, e), t);
                    throw new Error(be)
                }
                _handleSessionDisconnect(t) {
                    const e = t || "Session Disconnected";
                    this._connected || (this._qrcodeModal && this._qrcodeModal.close(), it(st)), this._connected && (this._connected = !1), this._handshakeId && (this._handshakeId = 0), this._handshakeTopic && (this._handshakeTopic = ""), this._peerId && (this._peerId = ""), this._eventManager.trigger({
                        event: "disconnect",
                        params: [{
                            message: e
                        }]
                    }), this._removeStorageSession(), this.transportClose()
                }
                _handleSessionResponse(t, e) {
                    e && e.approved ? (this._connected ? (e.chainId && (this.chainId = e.chainId), e.accounts && (this.accounts = e.accounts), this._eventManager.trigger({
                        event: "session_update",
                        params: [{
                            chainId: this.chainId,
                            accounts: this.accounts
                        }]
                    })) : (this._connected = !0, e.chainId && (this.chainId = e.chainId), e.accounts && (this.accounts = e.accounts), e.peerId && !this.peerId && (this.peerId = e.peerId), e.peerMeta && !this.peerMeta && (this.peerMeta = e.peerMeta), this._eventManager.trigger({
                        event: "connect",
                        params: [{
                            peerId: this.peerId,
                            peerMeta: this.peerMeta,
                            chainId: this.chainId,
                            accounts: this.accounts
                        }]
                    })), this._manageStorageSession()) : this._handleSessionDisconnect(t)
                }
                async _handleIncomingMessages(t) {
                    if (![this.clientId, this.handshakeTopic].includes(t.topic)) return;
                    let e;
                    try {
                        e = JSON.parse(t.payload)
                    } catch (r) {
                        return
                    }
                    const n = await this._decrypt(e);
                    n && this._eventManager.trigger(n)
                }
                _subscribeToSessionRequest() {
                    this._transport.subscribe(this.handshakeTopic)
                }
                _subscribeToResponse(t, e) {
                    this.on(`response:${t}`, e)
                }
                _subscribeToSessionResponse(t, e) {
                    this._subscribeToResponse(t, ((t, n) => {
                        t ? this._handleSessionResponse(t.message) : n.result ? this._handleSessionResponse(e, n.result) : n.error && n.error.message ? this._handleSessionResponse(n.error.message) : this._handleSessionResponse(e)
                    }))
                }
                _subscribeToCallResponse(t) {
                    return new Promise(((e, n) => {
                        this._subscribeToResponse(t, ((t, r) => {
                            t ? n(t) : r.result ? e(r.result) : r.error && r.error.message ? n(new Error(r.error.message)) : n(new Error(be))
                        }))
                    }))
                }
                _subscribeToInternalEvents() {
                    this.on("display_uri", (() => {
                        this._qrcodeModal && this._qrcodeModal.open(this.uri, (() => {
                            this._eventManager.trigger({
                                event: "modal_closed",
                                params: []
                            })
                        }), this._qrcodeModalOptions)
                    })), this.on("connect", (() => {
                        this._qrcodeModal && this._qrcodeModal.close()
                    })), this.on("call_request_sent", ((t, e) => {
                        const {
                            request: n
                        } = e.params[0];
                        if (j() && this._signingMethods.includes(n.method)) {
                            const t = ot(st);
                            t && (window.location.href = t.href)
                        }
                    })), this.on("wc_sessionRequest", ((t, e) => {
                        t && this._eventManager.trigger({
                            event: "error",
                            params: [{
                                code: "SESSION_REQUEST_ERROR",
                                message: t.toString()
                            }]
                        }), this.handshakeId = e.id, this.peerId = e.params[0].peerId, this.peerMeta = e.params[0].peerMeta;
                        const n = Object.assign(Object.assign({}, e), {
                            method: "session_request"
                        });
                        this._eventManager.trigger(n)
                    })), this.on("wc_sessionUpdate", ((t, e) => {
                        t && this._handleSessionResponse(t.message), this._handleSessionResponse("Session disconnected", e.params[0])
                    }))
                }
                _initTransport() {
                    this._transport.on("message", (t => this._handleIncomingMessages(t))), this._transport.on("open", (() => this._eventManager.trigger({
                        event: "transport_open",
                        params: []
                    }))), this._transport.on("close", (() => this._eventManager.trigger({
                        event: "transport_close",
                        params: []
                    }))), this._transport.on("error", (() => this._eventManager.trigger({
                        event: "transport_error",
                        params: ["Websocket connection failed"]
                    }))), this._transport.open()
                }
                _formatUri() {
                    return `${this.protocol}:${this.handshakeTopic}@${this.version}?bridge=${encodeURIComponent(this.bridge)}&key=${this.key}`
                }
                _parseUri(t) {
                    const e = function(t) {
                        const e = t.indexOf(":"),
                            n = -1 !== t.indexOf("?") ? t.indexOf("?") : void 0,
                            r = t.substring(0, e),
                            o = function(t) {
                                const e = t.split("@");
                                return {
                                    handshakeTopic: e[0],
                                    version: parseInt(e[1], 10)
                                }
                            }(t.substring(e + 1, n)),
                            i = function(t) {
                                const e = pe(t);
                                return {
                                    key: e.key || "",
                                    bridge: e.bridge || ""
                                }
                            }(void 0 !== n ? t.substr(n) : "");
                        return Object.assign(Object.assign({
                            protocol: r
                        }, o), i)
                    }(t);
                    if (e.protocol === this.protocol) {
                        if (!e.handshakeTopic) throw Error("Invalid or missing handshakeTopic parameter value");
                        const t = e.handshakeTopic;
                        if (!e.bridge) throw Error("Invalid or missing bridge url parameter value");
                        const n = decodeURIComponent(e.bridge);
                        if (!e.key) throw Error("Invalid or missing key parameter value");
                        return {
                            handshakeTopic: t,
                            bridge: n,
                            key: e.key
                        }
                    }
                    throw new Error("URI format is invalid")
                }
                async _generateKey() {
                    return this._cryptoLib ? await this._cryptoLib.generateKey() : null
                }
                async _encrypt(t) {
                    const e = this._key;
                    return this._cryptoLib && e ? await this._cryptoLib.encrypt(t, e) : null
                }
                async _decrypt(t) {
                    const e = this._key;
                    return this._cryptoLib && e ? await this._cryptoLib.decrypt(t, e) : null
                }
                _getStorageSession() {
                    let t = null;
                    return this._sessionStorage && (t = this._sessionStorage.getSession()), t
                }
                _setStorageSession() {
                    this._sessionStorage && this._sessionStorage.setSession(this.session)
                }
                _removeStorageSession() {
                    this._sessionStorage && this._sessionStorage.removeSession()
                }
                _manageStorageSession() {
                    this._connected ? this._setStorageSession() : this._removeStorageSession()
                }
                _registerPushServer(t) {
                    if (!t.url || "string" != typeof t.url) throw Error("Invalid or missing pushServerOpts.url parameter value");
                    if (!t.type || "string" != typeof t.type) throw Error("Invalid or missing pushServerOpts.type parameter value");
                    if (!t.token || "string" != typeof t.token) throw Error("Invalid or missing pushServerOpts.token parameter value");
                    const e = {
                        bridge: this.bridge,
                        topic: this.clientId,
                        type: t.type,
                        token: t.token,
                        peerName: "",
                        language: t.language || ""
                    };
                    this.on("connect", (async (n, r) => {
                        if (n) throw n;
                        if (t.peerMeta) {
                            const t = r.params[0].peerMeta.name;
                            e.peerName = t
                        }
                        try {
                            const n = await fetch(`${t.url}/new`, {
                                method: "POST",
                                headers: {
                                    Accept: "application/json",
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(e)
                            });
                            if (!(await n.json()).success) throw Error("Failed to register in Push Server")
                        } catch (n) {
                            throw Error("Failed to register in Push Server")
                        }
                    }))
                }
            } {
                constructor(t, e) {
                    super({
                        cryptoLib: Pe,
                        connectorOpts: t,
                        pushServerOpts: e
                    })
                }
            }
            var qe = n(ct),
                Ue = {},
                je = {},
                De = {},
                ze = {}.toString,
                Fe = Array.isArray || function(t) {
                    return "[object Array]" == ze.call(t)
                },
                We = Fe;
            $e.TYPED_ARRAY_SUPPORT = function() {
                try {
                    var t = new Uint8Array(1);
                    return t.__proto__ = {
                        __proto__: Uint8Array.prototype,
                        foo: function() {
                            return 42
                        }
                    }, 42 === t.foo()
                } catch (Mo) {
                    return !1
                }
            }();
            var He = $e.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;

            function $e(t, e, n) {
                return $e.TYPED_ARRAY_SUPPORT || this instanceof $e ? "number" == typeof t ? Ve(this, t) : function(t, e, n, r) {
                    if ("number" == typeof e) throw new TypeError('"value" argument must not be a number');
                    return "undefined" != typeof ArrayBuffer && e instanceof ArrayBuffer ? function(t, e, n, r) {
                        if (n < 0 || e.byteLength < n) throw new RangeError("'offset' is out of bounds");
                        if (e.byteLength < n + (r || 0)) throw new RangeError("'length' is out of bounds");
                        var o;
                        return o = void 0 === n && void 0 === r ? new Uint8Array(e) : void 0 === r ? new Uint8Array(e, n) : new Uint8Array(e, n, r), $e.TYPED_ARRAY_SUPPORT ? o.__proto__ = $e.prototype : o = Ke(t, o), o
                    }(t, e, n, r) : "string" == typeof e ? function(t, e) {
                        var n = 0 | Qe(e),
                            r = Ye(t, n),
                            o = r.write(e);
                        return o !== n && (r = r.slice(0, o)), r
                    }(t, e) : function(t, e) {
                        if ($e.isBuffer(e)) {
                            var n = 0 | Je(e.length),
                                r = Ye(t, n);
                            return 0 === r.length || e.copy(r, 0, 0, n), r
                        }
                        if (e) {
                            if ("undefined" != typeof ArrayBuffer && e.buffer instanceof ArrayBuffer || "length" in e) return "number" != typeof e.length || (o = e.length) != o ? Ye(t, 0) : Ke(t, e);
                            if ("Buffer" === e.type && Array.isArray(e.data)) return Ke(t, e.data)
                        }
                        var o;
                        throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")
                    }(t, e)
                }(this, t, e, n) : new $e(t, e, n)
            }

            function Je(t) {
                if (t >= He) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + He.toString(16) + " bytes");
                return 0 | t
            }

            function Ye(t, e) {
                var n;
                return $e.TYPED_ARRAY_SUPPORT ? (n = new Uint8Array(e)).__proto__ = $e.prototype : (null === (n = t) && (n = new $e(e)), n.length = e), n
            }

            function Ve(t, e) {
                var n = Ye(t, e < 0 ? 0 : 0 | Je(e));
                if (!$e.TYPED_ARRAY_SUPPORT)
                    for (var r = 0; r < e; ++r) n[r] = 0;
                return n
            }

            function Ke(t, e) {
                for (var n = e.length < 0 ? 0 : 0 | Je(e.length), r = Ye(t, n), o = 0; o < n; o += 1) r[o] = 255 & e[o];
                return r
            }

            function Ze(t, e) {
                var n;
                e = e || 1 / 0;
                for (var r = t.length, o = null, i = [], s = 0; s < r; ++s) {
                    if ((n = t.charCodeAt(s)) > 55295 && n < 57344) {
                        if (!o) {
                            if (n > 56319) {
                                (e -= 3) > -1 && i.push(239, 191, 189);
                                continue
                            }
                            if (s + 1 === r) {
                                (e -= 3) > -1 && i.push(239, 191, 189);
                                continue
                            }
                            o = n;
                            continue
                        }
                        if (n < 56320) {
                            (e -= 3) > -1 && i.push(239, 191, 189), o = n;
                            continue
                        }
                        n = 65536 + (o - 55296 << 10 | n - 56320)
                    } else o && (e -= 3) > -1 && i.push(239, 191, 189);
                    if (o = null, n < 128) {
                        if ((e -= 1) < 0) break;
                        i.push(n)
                    } else if (n < 2048) {
                        if ((e -= 2) < 0) break;
                        i.push(n >> 6 | 192, 63 & n | 128)
                    } else if (n < 65536) {
                        if ((e -= 3) < 0) break;
                        i.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128)
                    } else {
                        if (!(n < 1114112)) throw new Error("Invalid code point");
                        if ((e -= 4) < 0) break;
                        i.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128)
                    }
                }
                return i
            }

            function Qe(t) {
                return $e.isBuffer(t) ? t.length : "undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(t) || t instanceof ArrayBuffer) ? t.byteLength : ("string" != typeof t && (t = "" + t), 0 === t.length ? 0 : Ze(t).length)
            }
            $e.TYPED_ARRAY_SUPPORT && ($e.prototype.__proto__ = Uint8Array.prototype, $e.__proto__ = Uint8Array, "undefined" != typeof Symbol && Symbol.species && $e[Symbol.species] === $e && Object.defineProperty($e, Symbol.species, {
                value: null,
                configurable: !0,
                enumerable: !1,
                writable: !1
            })), $e.prototype.write = function(t, e, n) {
                void 0 === e || void 0 === n && "string" == typeof e ? (n = this.length, e = 0) : isFinite(e) && (e |= 0, isFinite(n) ? n |= 0 : n = void 0);
                var r = this.length - e;
                if ((void 0 === n || n > r) && (n = r), t.length > 0 && (n < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
                return function(t, e, n, r) {
                    return function(t, e, n, r) {
                        for (var o = 0; o < r && !(o + n >= e.length || o >= t.length); ++o) e[o + n] = t[o];
                        return o
                    }(Ze(e, t.length - n), t, n, r)
                }(this, t, e, n)
            }, $e.prototype.slice = function(t, e) {
                var n, r = this.length;
                if ((t = ~~t) < 0 ? (t += r) < 0 && (t = 0) : t > r && (t = r), (e = void 0 === e ? r : ~~e) < 0 ? (e += r) < 0 && (e = 0) : e > r && (e = r), e < t && (e = t), $e.TYPED_ARRAY_SUPPORT)(n = this.subarray(t, e)).__proto__ = $e.prototype;
                else {
                    var o = e - t;
                    n = new $e(o, void 0);
                    for (var i = 0; i < o; ++i) n[i] = this[i + t]
                }
                return n
            }, $e.prototype.copy = function(t, e, n, r) {
                if (n || (n = 0), r || 0 === r || (r = this.length), e >= t.length && (e = t.length), e || (e = 0), r > 0 && r < n && (r = n), r === n) return 0;
                if (0 === t.length || 0 === this.length) return 0;
                if (e < 0) throw new RangeError("targetStart out of bounds");
                if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
                if (r < 0) throw new RangeError("sourceEnd out of bounds");
                r > this.length && (r = this.length), t.length - e < r - n && (r = t.length - e + n);
                var o, i = r - n;
                if (this === t && n < e && e < r)
                    for (o = i - 1; o >= 0; --o) t[o + e] = this[o + n];
                else if (i < 1e3 || !$e.TYPED_ARRAY_SUPPORT)
                    for (o = 0; o < i; ++o) t[o + e] = this[o + n];
                else Uint8Array.prototype.set.call(t, this.subarray(n, n + i), e);
                return i
            }, $e.prototype.fill = function(t, e, n) {
                if ("string" == typeof t) {
                    if ("string" == typeof e ? (e = 0, n = this.length) : "string" == typeof n && (n = this.length), 1 === t.length) {
                        var r = t.charCodeAt(0);
                        r < 256 && (t = r)
                    }
                } else "number" == typeof t && (t &= 255);
                if (e < 0 || this.length < e || this.length < n) throw new RangeError("Out of range index");
                if (n <= e) return this;
                var o;
                if (e >>>= 0, n = void 0 === n ? this.length : n >>> 0, t || (t = 0), "number" == typeof t)
                    for (o = e; o < n; ++o) this[o] = t;
                else {
                    var i = $e.isBuffer(t) ? t : new $e(t),
                        s = i.length;
                    for (o = 0; o < n - e; ++o) this[o + e] = i[o % s]
                }
                return this
            }, $e.concat = function(t, e) {
                if (!We(t)) throw new TypeError('"list" argument must be an Array of Buffers');
                if (0 === t.length) return Ye(null, 0);
                var n;
                if (void 0 === e)
                    for (e = 0, n = 0; n < t.length; ++n) e += t[n].length;
                var r = Ve(null, e),
                    o = 0;
                for (n = 0; n < t.length; ++n) {
                    var i = t[n];
                    if (!$e.isBuffer(i)) throw new TypeError('"list" argument must be an Array of Buffers');
                    i.copy(r, o), o += i.length
                }
                return r
            }, $e.byteLength = Qe, $e.prototype._isBuffer = !0, $e.isBuffer = function(t) {
                return !(null == t || !t._isBuffer)
            }, De.alloc = function(t) {
                var e = new $e(t);
                return e.fill(0), e
            }, De.from = function(t) {
                return new $e(t)
            };
            var Xe, Ge = {},
                tn = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706];
            Ge.getSymbolSize = function(t) {
                if (!t) throw new Error('"version" cannot be null or undefined');
                if (t < 1 || t > 40) throw new Error('"version" should be in range from 1 to 40');
                return 4 * t + 17
            }, Ge.getSymbolTotalCodewords = function(t) {
                return tn[t]
            }, Ge.getBCHDigit = function(t) {
                for (var e = 0; 0 !== t;) e++, t >>>= 1;
                return e
            }, Ge.setToSJISFunction = function(t) {
                if ("function" != typeof t) throw new Error('"toSJISFunc" is not a valid function.');
                Xe = t
            }, Ge.isKanjiModeEnabled = function() {
                return void 0 !== Xe
            }, Ge.toSJIS = function(t) {
                return Xe(t)
            };
            var en = {};

            function nn() {
                this.buffer = [], this.length = 0
            }! function(t) {
                t.L = {
                    bit: 1
                }, t.M = {
                    bit: 0
                }, t.Q = {
                    bit: 3
                }, t.H = {
                    bit: 2
                }, t.isValid = function(t) {
                    return t && void 0 !== t.bit && t.bit >= 0 && t.bit < 4
                }, t.from = function(e, n) {
                    if (t.isValid(e)) return e;
                    try {
                        return function(e) {
                            if ("string" != typeof e) throw new Error("Param is not a string");
                            switch (e.toLowerCase()) {
                                case "l":
                                case "low":
                                    return t.L;
                                case "m":
                                case "medium":
                                    return t.M;
                                case "q":
                                case "quartile":
                                    return t.Q;
                                case "h":
                                case "high":
                                    return t.H;
                                default:
                                    throw new Error("Unknown EC Level: " + e)
                            }
                        }(e)
                    } catch (Mo) {
                        return n
                    }
                }
            }(en), nn.prototype = {
                get: function(t) {
                    var e = Math.floor(t / 8);
                    return 1 == (this.buffer[e] >>> 7 - t % 8 & 1)
                },
                put: function(t, e) {
                    for (var n = 0; n < e; n++) this.putBit(1 == (t >>> e - n - 1 & 1))
                },
                getLengthInBits: function() {
                    return this.length
                },
                putBit: function(t) {
                    var e = Math.floor(this.length / 8);
                    this.buffer.length <= e && this.buffer.push(0), t && (this.buffer[e] |= 128 >>> this.length % 8), this.length++
                }
            };
            var rn = nn,
                on = De;

            function sn(t) {
                if (!t || t < 1) throw new Error("BitMatrix size must be defined and greater than 0");
                this.size = t, this.data = on.alloc(t * t), this.reservedBit = on.alloc(t * t)
            }
            sn.prototype.set = function(t, e, n, r) {
                var o = t * this.size + e;
                this.data[o] = n, r && (this.reservedBit[o] = !0)
            }, sn.prototype.get = function(t, e) {
                return this.data[t * this.size + e]
            }, sn.prototype.xor = function(t, e, n) {
                this.data[t * this.size + e] ^= n
            }, sn.prototype.isReserved = function(t, e) {
                return this.reservedBit[t * this.size + e]
            };
            var an = sn,
                ln = {};
            ! function(t) {
                var e = Ge.getSymbolSize;
                t.getRowColCoords = function(t) {
                    if (1 === t) return [];
                    for (var n = Math.floor(t / 7) + 2, r = e(t), o = 145 === r ? 26 : 2 * Math.ceil((r - 13) / (2 * n - 2)), i = [r - 7], s = 1; s < n - 1; s++) i[s] = i[s - 1] - o;
                    return i.push(6), i.reverse()
                }, t.getPositions = function(e) {
                    for (var n = [], r = t.getRowColCoords(e), o = r.length, i = 0; i < o; i++)
                        for (var s = 0; s < o; s++) 0 === i && 0 === s || 0 === i && s === o - 1 || i === o - 1 && 0 === s || n.push([r[i], r[s]]);
                    return n
                }
            }(ln);
            var un = {},
                cn = Ge.getSymbolSize;
            un.getPositions = function(t) {
                var e = cn(t);
                return [
                    [0, 0],
                    [e - 7, 0],
                    [0, e - 7]
                ]
            };
            var hn = {};
            ! function(t) {
                t.Patterns = {
                    PATTERN000: 0,
                    PATTERN001: 1,
                    PATTERN010: 2,
                    PATTERN011: 3,
                    PATTERN100: 4,
                    PATTERN101: 5,
                    PATTERN110: 6,
                    PATTERN111: 7
                };
                var e = 3,
                    n = 3,
                    r = 40,
                    o = 10;

                function i(e, n, r) {
                    switch (e) {
                        case t.Patterns.PATTERN000:
                            return (n + r) % 2 == 0;
                        case t.Patterns.PATTERN001:
                            return n % 2 == 0;
                        case t.Patterns.PATTERN010:
                            return r % 3 == 0;
                        case t.Patterns.PATTERN011:
                            return (n + r) % 3 == 0;
                        case t.Patterns.PATTERN100:
                            return (Math.floor(n / 2) + Math.floor(r / 3)) % 2 == 0;
                        case t.Patterns.PATTERN101:
                            return n * r % 2 + n * r % 3 == 0;
                        case t.Patterns.PATTERN110:
                            return (n * r % 2 + n * r % 3) % 2 == 0;
                        case t.Patterns.PATTERN111:
                            return (n * r % 3 + (n + r) % 2) % 2 == 0;
                        default:
                            throw new Error("bad maskPattern:" + e)
                    }
                }
                t.isValid = function(t) {
                    return null != t && "" !== t && !isNaN(t) && t >= 0 && t <= 7
                }, t.from = function(e) {
                    return t.isValid(e) ? parseInt(e, 10) : void 0
                }, t.getPenaltyN1 = function(t) {
                    for (var n = t.size, r = 0, o = 0, i = 0, s = null, a = null, l = 0; l < n; l++) {
                        o = i = 0, s = a = null;
                        for (var u = 0; u < n; u++) {
                            var c = t.get(l, u);
                            c === s ? o++ : (o >= 5 && (r += e + (o - 5)), s = c, o = 1), (c = t.get(u, l)) === a ? i++ : (i >= 5 && (r += e + (i - 5)), a = c, i = 1)
                        }
                        o >= 5 && (r += e + (o - 5)), i >= 5 && (r += e + (i - 5))
                    }
                    return r
                }, t.getPenaltyN2 = function(t) {
                    for (var e = t.size, r = 0, o = 0; o < e - 1; o++)
                        for (var i = 0; i < e - 1; i++) {
                            var s = t.get(o, i) + t.get(o, i + 1) + t.get(o + 1, i) + t.get(o + 1, i + 1);
                            4 !== s && 0 !== s || r++
                        }
                    return r * n
                }, t.getPenaltyN3 = function(t) {
                    for (var e = t.size, n = 0, o = 0, i = 0, s = 0; s < e; s++) {
                        o = i = 0;
                        for (var a = 0; a < e; a++) o = o << 1 & 2047 | t.get(s, a), a >= 10 && (1488 === o || 93 === o) && n++, i = i << 1 & 2047 | t.get(a, s), a >= 10 && (1488 === i || 93 === i) && n++
                    }
                    return n * r
                }, t.getPenaltyN4 = function(t) {
                    for (var e = 0, n = t.data.length, r = 0; r < n; r++) e += t.data[r];
                    return Math.abs(Math.ceil(100 * e / n / 5) - 10) * o
                }, t.applyMask = function(t, e) {
                    for (var n = e.size, r = 0; r < n; r++)
                        for (var o = 0; o < n; o++) e.isReserved(o, r) || e.xor(o, r, i(t, o, r))
                }, t.getBestMask = function(e, n) {
                    for (var r = Object.keys(t.Patterns).length, o = 0, i = 1 / 0, s = 0; s < r; s++) {
                        n(s), t.applyMask(s, e);
                        var a = t.getPenaltyN1(e) + t.getPenaltyN2(e) + t.getPenaltyN3(e) + t.getPenaltyN4(e);
                        t.applyMask(s, e), a < i && (i = a, o = s)
                    }
                    return o
                }
            }(hn);
            var dn = {},
                fn = en,
                pn = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 4, 2, 4, 6, 5, 2, 4, 6, 6, 2, 5, 8, 8, 4, 5, 8, 8, 4, 5, 8, 11, 4, 8, 10, 11, 4, 9, 12, 16, 4, 9, 16, 16, 6, 10, 12, 18, 6, 10, 17, 16, 6, 11, 16, 19, 6, 13, 18, 21, 7, 14, 21, 25, 8, 16, 20, 25, 8, 17, 23, 25, 9, 17, 23, 34, 9, 18, 25, 30, 10, 20, 27, 32, 12, 21, 29, 35, 12, 23, 34, 37, 12, 25, 34, 40, 13, 26, 35, 42, 14, 28, 38, 45, 15, 29, 40, 48, 16, 31, 43, 51, 17, 33, 45, 54, 18, 35, 48, 57, 19, 37, 51, 60, 19, 38, 53, 63, 20, 40, 56, 66, 21, 43, 59, 70, 22, 45, 62, 74, 24, 47, 65, 77, 25, 49, 68, 81],
                mn = [7, 10, 13, 17, 10, 16, 22, 28, 15, 26, 36, 44, 20, 36, 52, 64, 26, 48, 72, 88, 36, 64, 96, 112, 40, 72, 108, 130, 48, 88, 132, 156, 60, 110, 160, 192, 72, 130, 192, 224, 80, 150, 224, 264, 96, 176, 260, 308, 104, 198, 288, 352, 120, 216, 320, 384, 132, 240, 360, 432, 144, 280, 408, 480, 168, 308, 448, 532, 180, 338, 504, 588, 196, 364, 546, 650, 224, 416, 600, 700, 224, 442, 644, 750, 252, 476, 690, 816, 270, 504, 750, 900, 300, 560, 810, 960, 312, 588, 870, 1050, 336, 644, 952, 1110, 360, 700, 1020, 1200, 390, 728, 1050, 1260, 420, 784, 1140, 1350, 450, 812, 1200, 1440, 480, 868, 1290, 1530, 510, 924, 1350, 1620, 540, 980, 1440, 1710, 570, 1036, 1530, 1800, 570, 1064, 1590, 1890, 600, 1120, 1680, 1980, 630, 1204, 1770, 2100, 660, 1260, 1860, 2220, 720, 1316, 1950, 2310, 750, 1372, 2040, 2430];
            dn.getBlocksCount = function(t, e) {
                switch (e) {
                    case fn.L:
                        return pn[4 * (t - 1) + 0];
                    case fn.M:
                        return pn[4 * (t - 1) + 1];
                    case fn.Q:
                        return pn[4 * (t - 1) + 2];
                    case fn.H:
                        return pn[4 * (t - 1) + 3];
                    default:
                        return
                }
            }, dn.getTotalCodewordsCount = function(t, e) {
                switch (e) {
                    case fn.L:
                        return mn[4 * (t - 1) + 0];
                    case fn.M:
                        return mn[4 * (t - 1) + 1];
                    case fn.Q:
                        return mn[4 * (t - 1) + 2];
                    case fn.H:
                        return mn[4 * (t - 1) + 3];
                    default:
                        return
                }
            };
            var gn = {},
                _n = {},
                vn = De,
                wn = vn.alloc(512),
                yn = vn.alloc(256);
            ! function() {
                for (var t = 1, e = 0; e < 255; e++) wn[e] = t, yn[t] = e, 256 & (t <<= 1) && (t ^= 285);
                for (e = 255; e < 512; e++) wn[e] = wn[e - 255]
            }(), _n.log = function(t) {
                    if (t < 1) throw new Error("log(" + t + ")");
                    return yn[t]
                }, _n.exp = function(t) {
                    return wn[t]
                }, _n.mul = function(t, e) {
                    return 0 === t || 0 === e ? 0 : wn[yn[t] + yn[e]]
                },
                function(t) {
                    var e = De,
                        n = _n;
                    t.mul = function(t, r) {
                        for (var o = e.alloc(t.length + r.length - 1), i = 0; i < t.length; i++)
                            for (var s = 0; s < r.length; s++) o[i + s] ^= n.mul(t[i], r[s]);
                        return o
                    }, t.mod = function(t, r) {
                        for (var o = e.from(t); o.length - r.length >= 0;) {
                            for (var i = o[0], s = 0; s < r.length; s++) o[s] ^= n.mul(r[s], i);
                            for (var a = 0; a < o.length && 0 === o[a];) a++;
                            o = o.slice(a)
                        }
                        return o
                    }, t.generateECPolynomial = function(r) {
                        for (var o = e.from([1]), i = 0; i < r; i++) o = t.mul(o, [1, n.exp(i)]);
                        return o
                    }
                }(gn);
            var bn = De,
                Mn = gn,
                kn = o.Buffer;

            function xn(t) {
                this.genPoly = void 0, this.degree = t, this.degree && this.initialize(this.degree)
            }
            xn.prototype.initialize = function(t) {
                this.degree = t, this.genPoly = Mn.generateECPolynomial(this.degree)
            }, xn.prototype.encode = function(t) {
                if (!this.genPoly) throw new Error("Encoder not initialized");
                var e = bn.alloc(this.degree),
                    n = kn.concat([t, e], t.length + this.degree),
                    r = Mn.mod(n, this.genPoly),
                    o = this.degree - r.length;
                if (o > 0) {
                    var i = bn.alloc(this.degree);
                    return r.copy(i, o), i
                }
                return r
            };
            var Sn = xn,
                En = {},
                Cn = {},
                An = {
                    isValid: function(t) {
                        return !isNaN(t) && t >= 1 && t <= 40
                    }
                },
                In = {},
                Rn = "[0-9]+",
                Tn = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+",
                On = "(?:(?![A-Z0-9 $%*+\\-./:]|" + (Tn = Tn.replace(/u/g, "\\u")) + ")(?:.|[\r\n]))+";
            In.KANJI = new RegExp(Tn, "g"), In.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), In.BYTE = new RegExp(On, "g"), In.NUMERIC = new RegExp(Rn, "g"), In.ALPHANUMERIC = new RegExp("[A-Z $%*+\\-./:]+", "g");
            var Nn = new RegExp("^" + Tn + "$"),
                Bn = new RegExp("^[0-9]+$"),
                Pn = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
            In.testKanji = function(t) {
                    return Nn.test(t)
                }, In.testNumeric = function(t) {
                    return Bn.test(t)
                }, In.testAlphanumeric = function(t) {
                    return Pn.test(t)
                },
                function(t) {
                    var e = An,
                        n = In;
                    t.NUMERIC = {
                        id: "Numeric",
                        bit: 1,
                        ccBits: [10, 12, 14]
                    }, t.ALPHANUMERIC = {
                        id: "Alphanumeric",
                        bit: 2,
                        ccBits: [9, 11, 13]
                    }, t.BYTE = {
                        id: "Byte",
                        bit: 4,
                        ccBits: [8, 16, 16]
                    }, t.KANJI = {
                        id: "Kanji",
                        bit: 8,
                        ccBits: [8, 10, 12]
                    }, t.MIXED = {
                        bit: -1
                    }, t.getCharCountIndicator = function(t, n) {
                        if (!t.ccBits) throw new Error("Invalid mode: " + t);
                        if (!e.isValid(n)) throw new Error("Invalid version: " + n);
                        return n >= 1 && n < 10 ? t.ccBits[0] : n < 27 ? t.ccBits[1] : t.ccBits[2]
                    }, t.getBestModeForData = function(e) {
                        return n.testNumeric(e) ? t.NUMERIC : n.testAlphanumeric(e) ? t.ALPHANUMERIC : n.testKanji(e) ? t.KANJI : t.BYTE
                    }, t.toString = function(t) {
                        if (t && t.id) return t.id;
                        throw new Error("Invalid mode")
                    }, t.isValid = function(t) {
                        return t && t.bit && t.ccBits
                    }, t.from = function(e, n) {
                        if (t.isValid(e)) return e;
                        try {
                            return function(e) {
                                if ("string" != typeof e) throw new Error("Param is not a string");
                                switch (e.toLowerCase()) {
                                    case "numeric":
                                        return t.NUMERIC;
                                    case "alphanumeric":
                                        return t.ALPHANUMERIC;
                                    case "kanji":
                                        return t.KANJI;
                                    case "byte":
                                        return t.BYTE;
                                    default:
                                        throw new Error("Unknown mode: " + e)
                                }
                            }(e)
                        } catch (Mo) {
                            return n
                        }
                    }
                }(Cn),
                function(t) {
                    var e = Ge,
                        n = dn,
                        r = en,
                        o = Cn,
                        i = An,
                        s = Fe,
                        a = e.getBCHDigit(7973);

                    function l(t, e) {
                        return o.getCharCountIndicator(t, e) + 4
                    }

                    function u(t, e) {
                        var n = 0;
                        return t.forEach((function(t) {
                            var r = l(t.mode, e);
                            n += r + t.getBitsLength()
                        })), n
                    }
                    t.from = function(t, e) {
                        return i.isValid(t) ? parseInt(t, 10) : e
                    }, t.getCapacity = function(t, r, s) {
                        if (!i.isValid(t)) throw new Error("Invalid QR Code version");
                        void 0 === s && (s = o.BYTE);
                        var a = 8 * (e.getSymbolTotalCodewords(t) - n.getTotalCodewordsCount(t, r));
                        if (s === o.MIXED) return a;
                        var u = a - l(s, t);
                        switch (s) {
                            case o.NUMERIC:
                                return Math.floor(u / 10 * 3);
                            case o.ALPHANUMERIC:
                                return Math.floor(u / 11 * 2);
                            case o.KANJI:
                                return Math.floor(u / 13);
                            case o.BYTE:
                            default:
                                return Math.floor(u / 8)
                        }
                    }, t.getBestVersionForData = function(e, n) {
                        var i, a = r.from(n, r.M);
                        if (s(e)) {
                            if (e.length > 1) return function(e, n) {
                                for (var r = 1; r <= 40; r++)
                                    if (u(e, r) <= t.getCapacity(r, n, o.MIXED)) return r
                            }(e, a);
                            if (0 === e.length) return 1;
                            i = e[0]
                        } else i = e;
                        return function(e, n, r) {
                            for (var o = 1; o <= 40; o++)
                                if (n <= t.getCapacity(o, r, e)) return o
                        }(i.mode, i.getLength(), a)
                    }, t.getEncodedBits = function(t) {
                        if (!i.isValid(t) || t < 7) throw new Error("Invalid QR Code version");
                        for (var n = t << 12; e.getBCHDigit(n) - a >= 0;) n ^= 7973 << e.getBCHDigit(n) - a;
                        return t << 12 | n
                    }
                }(En);
            var Ln = {},
                qn = Ge,
                Un = qn.getBCHDigit(1335);
            Ln.getEncodedBits = function(t, e) {
                for (var n = t.bit << 3 | e, r = n << 10; qn.getBCHDigit(r) - Un >= 0;) r ^= 1335 << qn.getBCHDigit(r) - Un;
                return 21522 ^ (n << 10 | r)
            };
            var jn = {},
                Dn = Cn;

            function zn(t) {
                this.mode = Dn.NUMERIC, this.data = t.toString()
            }
            zn.getBitsLength = function(t) {
                return 10 * Math.floor(t / 3) + (t % 3 ? t % 3 * 3 + 1 : 0)
            }, zn.prototype.getLength = function() {
                return this.data.length
            }, zn.prototype.getBitsLength = function() {
                return zn.getBitsLength(this.data.length)
            }, zn.prototype.write = function(t) {
                var e, n, r;
                for (e = 0; e + 3 <= this.data.length; e += 3) n = this.data.substr(e, 3), r = parseInt(n, 10), t.put(r, 10);
                var o = this.data.length - e;
                o > 0 && (n = this.data.substr(e), r = parseInt(n, 10), t.put(r, 3 * o + 1))
            };
            var Fn = zn,
                Wn = Cn,
                Hn = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "$", "%", "*", "+", "-", ".", "/", ":"];

            function $n(t) {
                this.mode = Wn.ALPHANUMERIC, this.data = t
            }
            $n.getBitsLength = function(t) {
                return 11 * Math.floor(t / 2) + t % 2 * 6
            }, $n.prototype.getLength = function() {
                return this.data.length
            }, $n.prototype.getBitsLength = function() {
                return $n.getBitsLength(this.data.length)
            }, $n.prototype.write = function(t) {
                var e;
                for (e = 0; e + 2 <= this.data.length; e += 2) {
                    var n = 45 * Hn.indexOf(this.data[e]);
                    n += Hn.indexOf(this.data[e + 1]), t.put(n, 11)
                }
                this.data.length % 2 && t.put(Hn.indexOf(this.data[e]), 6)
            };
            var Jn = $n,
                Yn = De,
                Vn = Cn;

            function Kn(t) {
                this.mode = Vn.BYTE, this.data = Yn.from(t)
            }
            Kn.getBitsLength = function(t) {
                return 8 * t
            }, Kn.prototype.getLength = function() {
                return this.data.length
            }, Kn.prototype.getBitsLength = function() {
                return Kn.getBitsLength(this.data.length)
            }, Kn.prototype.write = function(t) {
                for (var e = 0, n = this.data.length; e < n; e++) t.put(this.data[e], 8)
            };
            var Zn = Kn,
                Qn = Cn,
                Xn = Ge;

            function Gn(t) {
                this.mode = Qn.KANJI, this.data = t
            }
            Gn.getBitsLength = function(t) {
                return 13 * t
            }, Gn.prototype.getLength = function() {
                return this.data.length
            }, Gn.prototype.getBitsLength = function() {
                return Gn.getBitsLength(this.data.length)
            }, Gn.prototype.write = function(t) {
                var e;
                for (e = 0; e < this.data.length; e++) {
                    var n = Xn.toSJIS(this.data[e]);
                    if (n >= 33088 && n <= 40956) n -= 33088;
                    else {
                        if (!(n >= 57408 && n <= 60351)) throw new Error("Invalid SJIS character: " + this.data[e] + "\nMake sure your charset is UTF-8");
                        n -= 49472
                    }
                    n = 192 * (n >>> 8 & 255) + (255 & n), t.put(n, 13)
                }
            };
            var tr = Gn;
            ! function(t) {
                var e = Cn,
                    n = Fn,
                    r = Jn,
                    o = Zn,
                    s = tr,
                    a = In,
                    l = Ge,
                    u = i.exports;

                function c(t) {
                    return unescape(encodeURIComponent(t)).length
                }

                function h(t, e, n) {
                    for (var r, o = []; null !== (r = t.exec(n));) o.push({
                        data: r[0],
                        index: r.index,
                        mode: e,
                        length: r[0].length
                    });
                    return o
                }

                function d(t) {
                    var n, r, o = h(a.NUMERIC, e.NUMERIC, t),
                        i = h(a.ALPHANUMERIC, e.ALPHANUMERIC, t);
                    return l.isKanjiModeEnabled() ? (n = h(a.BYTE, e.BYTE, t), r = h(a.KANJI, e.KANJI, t)) : (n = h(a.BYTE_KANJI, e.BYTE, t), r = []), o.concat(i, n, r).sort((function(t, e) {
                        return t.index - e.index
                    })).map((function(t) {
                        return {
                            data: t.data,
                            mode: t.mode,
                            length: t.length
                        }
                    }))
                }

                function f(t, i) {
                    switch (i) {
                        case e.NUMERIC:
                            return n.getBitsLength(t);
                        case e.ALPHANUMERIC:
                            return r.getBitsLength(t);
                        case e.KANJI:
                            return s.getBitsLength(t);
                        case e.BYTE:
                            return o.getBitsLength(t)
                    }
                }

                function p(t, i) {
                    var a, u = e.getBestModeForData(t);
                    if ((a = e.from(i, u)) !== e.BYTE && a.bit < u.bit) throw new Error('"' + t + '" cannot be encoded with mode ' + e.toString(a) + ".\n Suggested mode is: " + e.toString(u));
                    switch (a !== e.KANJI || l.isKanjiModeEnabled() || (a = e.BYTE), a) {
                        case e.NUMERIC:
                            return new n(t);
                        case e.ALPHANUMERIC:
                            return new r(t);
                        case e.KANJI:
                            return new s(t);
                        case e.BYTE:
                            return new o(t)
                    }
                }
                t.fromArray = function(t) {
                    return t.reduce((function(t, e) {
                        return "string" == typeof e ? t.push(p(e, null)) : e.data && t.push(p(e.data, e.mode)), t
                    }), [])
                }, t.fromString = function(n, r) {
                    for (var o = function(t) {
                            for (var n = [], r = 0; r < t.length; r++) {
                                var o = t[r];
                                switch (o.mode) {
                                    case e.NUMERIC:
                                        n.push([o, {
                                            data: o.data,
                                            mode: e.ALPHANUMERIC,
                                            length: o.length
                                        }, {
                                            data: o.data,
                                            mode: e.BYTE,
                                            length: o.length
                                        }]);
                                        break;
                                    case e.ALPHANUMERIC:
                                        n.push([o, {
                                            data: o.data,
                                            mode: e.BYTE,
                                            length: o.length
                                        }]);
                                        break;
                                    case e.KANJI:
                                        n.push([o, {
                                            data: o.data,
                                            mode: e.BYTE,
                                            length: c(o.data)
                                        }]);
                                        break;
                                    case e.BYTE:
                                        n.push([{
                                            data: o.data,
                                            mode: e.BYTE,
                                            length: c(o.data)
                                        }])
                                }
                            }
                            return n
                        }(d(n, l.isKanjiModeEnabled())), i = function(t, n) {
                            for (var r = {}, o = {
                                    start: {}
                                }, i = ["start"], s = 0; s < t.length; s++) {
                                for (var a = t[s], l = [], u = 0; u < a.length; u++) {
                                    var c = a[u],
                                        h = "" + s + u;
                                    l.push(h), r[h] = {
                                        node: c,
                                        lastCount: 0
                                    }, o[h] = {};
                                    for (var d = 0; d < i.length; d++) {
                                        var p = i[d];
                                        r[p] && r[p].node.mode === c.mode ? (o[p][h] = f(r[p].lastCount + c.length, c.mode) - f(r[p].lastCount, c.mode), r[p].lastCount += c.length) : (r[p] && (r[p].lastCount = c.length), o[p][h] = f(c.length, c.mode) + 4 + e.getCharCountIndicator(c.mode, n))
                                    }
                                }
                                i = l
                            }
                            for (d = 0; d < i.length; d++) o[i[d]].end = 0;
                            return {
                                map: o,
                                table: r
                            }
                        }(o, r), s = u.find_path(i.map, "start", "end"), a = [], h = 1; h < s.length - 1; h++) a.push(i.table[s[h]].node);
                    return t.fromArray(function(t) {
                        return t.reduce((function(t, e) {
                            var n = t.length - 1 >= 0 ? t[t.length - 1] : null;
                            return n && n.mode === e.mode ? (t[t.length - 1].data += e.data, t) : (t.push(e), t)
                        }), [])
                    }(a))
                }, t.rawSplit = function(e) {
                    return t.fromArray(d(e, l.isKanjiModeEnabled()))
                }
            }(jn);
            var er = De,
                nr = Ge,
                rr = en,
                or = rn,
                ir = an,
                sr = ln,
                ar = un,
                lr = hn,
                ur = dn,
                cr = Sn,
                hr = En,
                dr = Ln,
                fr = Cn,
                pr = jn,
                mr = Fe;

            function gr(t, e, n) {
                var r, o, i = t.size,
                    s = dr.getEncodedBits(e, n);
                for (r = 0; r < 15; r++) o = 1 == (s >> r & 1), r < 6 ? t.set(r, 8, o, !0) : r < 8 ? t.set(r + 1, 8, o, !0) : t.set(i - 15 + r, 8, o, !0), r < 8 ? t.set(8, i - r - 1, o, !0) : r < 9 ? t.set(8, 15 - r - 1 + 1, o, !0) : t.set(8, 15 - r - 1, o, !0);
                t.set(i - 8, 8, 1, !0)
            }

            function _r(t, e, n) {
                var r = new or;
                n.forEach((function(e) {
                    r.put(e.mode.bit, 4), r.put(e.getLength(), fr.getCharCountIndicator(e.mode, t)), e.write(r)
                }));
                var o = 8 * (nr.getSymbolTotalCodewords(t) - ur.getTotalCodewordsCount(t, e));
                for (r.getLengthInBits() + 4 <= o && r.put(0, 4); r.getLengthInBits() % 8 != 0;) r.putBit(0);
                for (var i = (o - r.getLengthInBits()) / 8, s = 0; s < i; s++) r.put(s % 2 ? 17 : 236, 8);
                return function(t, e, n) {
                    for (var r = nr.getSymbolTotalCodewords(e), o = ur.getTotalCodewordsCount(e, n), i = r - o, s = ur.getBlocksCount(e, n), a = s - r % s, l = Math.floor(r / s), u = Math.floor(i / s), c = u + 1, h = l - u, d = new cr(h), f = 0, p = new Array(s), m = new Array(s), g = 0, _ = er.from(t.buffer), v = 0; v < s; v++) {
                        var w = v < a ? u : c;
                        p[v] = _.slice(f, f + w), m[v] = d.encode(p[v]), f += w, g = Math.max(g, w)
                    }
                    var y, b, M = er.alloc(r),
                        k = 0;
                    for (y = 0; y < g; y++)
                        for (b = 0; b < s; b++) y < p[b].length && (M[k++] = p[b][y]);
                    for (y = 0; y < h; y++)
                        for (b = 0; b < s; b++) M[k++] = m[b][y];
                    return M
                }(r, t, e)
            }

            function vr(t, e, n, r) {
                var o;
                if (mr(t)) o = pr.fromArray(t);
                else {
                    if ("string" != typeof t) throw new Error("Invalid data");
                    var i = e;
                    if (!i) {
                        var s = pr.rawSplit(t);
                        i = hr.getBestVersionForData(s, n)
                    }
                    o = pr.fromString(t, i || 40)
                }
                var a = hr.getBestVersionForData(o, n);
                if (!a) throw new Error("The amount of data is too big to be stored in a QR Code");
                if (e) {
                    if (e < a) throw new Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + a + ".\n")
                } else e = a;
                var l = _r(e, n, o),
                    u = nr.getSymbolSize(e),
                    c = new ir(u);
                return function(t, e) {
                        for (var n = t.size, r = ar.getPositions(e), o = 0; o < r.length; o++)
                            for (var i = r[o][0], s = r[o][1], a = -1; a <= 7; a++)
                                if (!(i + a <= -1 || n <= i + a))
                                    for (var l = -1; l <= 7; l++) s + l <= -1 || n <= s + l || (a >= 0 && a <= 6 && (0 === l || 6 === l) || l >= 0 && l <= 6 && (0 === a || 6 === a) || a >= 2 && a <= 4 && l >= 2 && l <= 4 ? t.set(i + a, s + l, !0, !0) : t.set(i + a, s + l, !1, !0))
                    }(c, e),
                    function(t) {
                        for (var e = t.size, n = 8; n < e - 8; n++) {
                            var r = n % 2 == 0;
                            t.set(n, 6, r, !0), t.set(6, n, r, !0)
                        }
                    }(c),
                    function(t, e) {
                        for (var n = sr.getPositions(e), r = 0; r < n.length; r++)
                            for (var o = n[r][0], i = n[r][1], s = -2; s <= 2; s++)
                                for (var a = -2; a <= 2; a++) - 2 === s || 2 === s || -2 === a || 2 === a || 0 === s && 0 === a ? t.set(o + s, i + a, !0, !0) : t.set(o + s, i + a, !1, !0)
                    }(c, e), gr(c, n, 0), e >= 7 && function(t, e) {
                        for (var n, r, o, i = t.size, s = hr.getEncodedBits(e), a = 0; a < 18; a++) n = Math.floor(a / 3), r = a % 3 + i - 8 - 3, o = 1 == (s >> a & 1), t.set(n, r, o, !0), t.set(r, n, o, !0)
                    }(c, e),
                    function(t, e) {
                        for (var n = t.size, r = -1, o = n - 1, i = 7, s = 0, a = n - 1; a > 0; a -= 2)
                            for (6 === a && a--;;) {
                                for (var l = 0; l < 2; l++)
                                    if (!t.isReserved(o, a - l)) {
                                        var u = !1;
                                        s < e.length && (u = 1 == (e[s] >>> i & 1)), t.set(o, a - l, u), -1 == --i && (s++, i = 7)
                                    }
                                if ((o += r) < 0 || n <= o) {
                                    o -= r, r = -r;
                                    break
                                }
                            }
                    }(c, l), isNaN(r) && (r = lr.getBestMask(c, gr.bind(null, c, n))), lr.applyMask(r, c), gr(c, n, r), {
                        modules: c,
                        version: e,
                        errorCorrectionLevel: n,
                        maskPattern: r,
                        segments: o
                    }
            }
            je.create = function(t, e) {
                if (void 0 === t || "" === t) throw new Error("No input text");
                var n, r, o = rr.M;
                return void 0 !== e && (o = rr.from(e.errorCorrectionLevel, rr.M), n = hr.from(e.version), r = lr.from(e.maskPattern), e.toSJISFunc && nr.setToSJISFunction(e.toSJISFunc)), vr(t, n, o, r)
            };
            var wr = {},
                yr = {};
            ! function(t) {
                function e(t) {
                    if ("number" == typeof t && (t = t.toString()), "string" != typeof t) throw new Error("Color should be defined as hex string");
                    var e = t.slice().replace("#", "").split("");
                    if (e.length < 3 || 5 === e.length || e.length > 8) throw new Error("Invalid hex color: " + t);
                    3 !== e.length && 4 !== e.length || (e = Array.prototype.concat.apply([], e.map((function(t) {
                        return [t, t]
                    })))), 6 === e.length && e.push("F", "F");
                    var n = parseInt(e.join(""), 16);
                    return {
                        r: n >> 24 & 255,
                        g: n >> 16 & 255,
                        b: n >> 8 & 255,
                        a: 255 & n,
                        hex: "#" + e.slice(0, 6).join("")
                    }
                }
                t.getOptions = function(t) {
                    t || (t = {}), t.color || (t.color = {});
                    var n = void 0 === t.margin || null === t.margin || t.margin < 0 ? 4 : t.margin,
                        r = t.width && t.width >= 21 ? t.width : void 0,
                        o = t.scale || 4;
                    return {
                        width: r,
                        scale: r ? 4 : o,
                        margin: n,
                        color: {
                            dark: e(t.color.dark || "#000000ff"),
                            light: e(t.color.light || "#ffffffff")
                        },
                        type: t.type,
                        rendererOpts: t.rendererOpts || {}
                    }
                }, t.getScale = function(t, e) {
                    return e.width && e.width >= t + 2 * e.margin ? e.width / (t + 2 * e.margin) : e.scale
                }, t.getImageWidth = function(e, n) {
                    var r = t.getScale(e, n);
                    return Math.floor((e + 2 * n.margin) * r)
                }, t.qrToImageData = function(e, n, r) {
                    for (var o = n.modules.size, i = n.modules.data, s = t.getScale(o, r), a = Math.floor((o + 2 * r.margin) * s), l = r.margin * s, u = [r.color.light, r.color.dark], c = 0; c < a; c++)
                        for (var h = 0; h < a; h++) {
                            var d = 4 * (c * a + h),
                                f = r.color.light;
                            c >= l && h >= l && c < a - l && h < a - l && (f = u[i[Math.floor((c - l) / s) * o + Math.floor((h - l) / s)] ? 1 : 0]), e[d++] = f.r, e[d++] = f.g, e[d++] = f.b, e[d] = f.a
                        }
                }
            }(yr),
            function(t) {
                var e = yr;
                t.render = function(t, n, r) {
                    var o = r,
                        i = n;
                    void 0 !== o || n && n.getContext || (o = n, n = void 0), n || (i = function() {
                        try {
                            return document.createElement("canvas")
                        } catch (Mo) {
                            throw new Error("You need to specify a canvas element")
                        }
                    }()), o = e.getOptions(o);
                    var s = e.getImageWidth(t.modules.size, o),
                        a = i.getContext("2d"),
                        l = a.createImageData(s, s);
                    return e.qrToImageData(l.data, t, o),
                        function(t, e, n) {
                            t.clearRect(0, 0, e.width, e.height), e.style || (e.style = {}), e.height = n, e.width = n, e.style.height = n + "px", e.style.width = n + "px"
                        }(a, i, s), a.putImageData(l, 0, 0), i
                }, t.renderToDataURL = function(e, n, r) {
                    var o = r;
                    void 0 !== o || n && n.getContext || (o = n, n = void 0), o || (o = {});
                    var i = t.render(e, n, o),
                        s = o.type || "image/png",
                        a = o.rendererOpts || {};
                    return i.toDataURL(s, a.quality)
                }
            }(wr);
            var br = {},
                Mr = yr;

            function kr(t, e) {
                var n = t.a / 255,
                    r = e + '="' + t.hex + '"';
                return n < 1 ? r + " " + e + '-opacity="' + n.toFixed(2).slice(1) + '"' : r
            }

            function xr(t, e, n) {
                var r = t + e;
                return void 0 !== n && (r += " " + n), r
            }
            br.render = function(t, e, n) {
                var r = Mr.getOptions(e),
                    o = t.modules.size,
                    i = t.modules.data,
                    s = o + 2 * r.margin,
                    a = r.color.light.a ? "<path " + kr(r.color.light, "fill") + ' d="M0 0h' + s + "v" + s + 'H0z"/>' : "",
                    l = "<path " + kr(r.color.dark, "stroke") + ' d="' + function(t, e, n) {
                        for (var r = "", o = 0, i = !1, s = 0, a = 0; a < t.length; a++) {
                            var l = Math.floor(a % e),
                                u = Math.floor(a / e);
                            l || i || (i = !0), t[a] ? (s++, a > 0 && l > 0 && t[a - 1] || (r += i ? xr("M", l + n, .5 + u + n) : xr("m", o, 0), o = 0, i = !1), l + 1 < e && t[a + 1] || (r += xr("h", s), s = 0)) : o++
                        }
                        return r
                    }(i, o, r.margin) + '"/>',
                    u = 'viewBox="0 0 ' + s + " " + s + '"',
                    c = '<svg xmlns="http://www.w3.org/2000/svg" ' + (r.width ? 'width="' + r.width + '" height="' + r.width + '" ' : "") + u + ' shape-rendering="crispEdges">' + a + l + "</svg>\n";
                return "function" == typeof n && n(null, c), c
            };
            var Sr = function() {
                    return "function" == typeof Promise && Promise.prototype && Promise.prototype.then
                },
                Er = je,
                Cr = wr,
                Ar = br;

            function Ir(t, e, n, r, o) {
                var i = [].slice.call(arguments, 1),
                    s = i.length,
                    a = "function" == typeof i[s - 1];
                if (!a && !Sr()) throw new Error("Callback required as last argument");
                if (!a) {
                    if (s < 1) throw new Error("Too few arguments provided");
                    return 1 === s ? (n = e, e = r = void 0) : 2 !== s || e.getContext || (r = n, n = e, e = void 0), new Promise((function(o, i) {
                        try {
                            var s = Er.create(n, r);
                            o(t(s, e, r))
                        } catch (Mo) {
                            i(Mo)
                        }
                    }))
                }
                if (s < 2) throw new Error("Too few arguments provided");
                2 === s ? (o = n, n = e, e = r = void 0) : 3 === s && (e.getContext && void 0 === o ? (o = r, r = void 0) : (o = r, r = n, n = e, e = void 0));
                try {
                    var l = Er.create(n, r);
                    o(null, t(l, e, r))
                } catch (Mo) {
                    o(Mo)
                }
            }
            Ue.create = Er.create, Ue.toCanvas = Ir.bind(null, Cr.render), Ue.toDataURL = Ir.bind(null, Cr.renderToDataURL), Ue.toString = Ir.bind(null, (function(t, e, n) {
                return Ar.render(t, n)
            }));
            var Rr, Tr, Or, Nr, Br, Pr, Lr, qr = function() {
                    var t = document.getSelection();
                    if (!t.rangeCount) return function() {};
                    for (var e = document.activeElement, n = [], r = 0; r < t.rangeCount; r++) n.push(t.getRangeAt(r));
                    switch (e.tagName.toUpperCase()) {
                        case "INPUT":
                        case "TEXTAREA":
                            e.blur();
                            break;
                        default:
                            e = null
                    }
                    return t.removeAllRanges(),
                        function() {
                            "Caret" === t.type && t.removeAllRanges(), t.rangeCount || n.forEach((function(e) {
                                t.addRange(e)
                            })), e && e.focus()
                        }
                },
                Ur = {
                    "text/plain": "Text",
                    "text/html": "Url",
                    default: "Text"
                },
                jr = function(t, e) {
                    var n, r, o, i, s, a, l = !1;
                    e || (e = {}), n = e.debug || !1;
                    try {
                        if (o = qr(), i = document.createRange(), s = document.getSelection(), (a = document.createElement("span")).textContent = t, a.style.all = "unset", a.style.position = "fixed", a.style.top = 0, a.style.clip = "rect(0, 0, 0, 0)", a.style.whiteSpace = "pre", a.style.webkitUserSelect = "text", a.style.MozUserSelect = "text", a.style.msUserSelect = "text", a.style.userSelect = "text", a.addEventListener("copy", (function(r) {
                                if (r.stopPropagation(), e.format)
                                    if (r.preventDefault(), void 0 === r.clipboardData) {
                                        n && console.warn("unable to use e.clipboardData"), n && console.warn("trying IE specific stuff"), window.clipboardData.clearData();
                                        var o = Ur[e.format] || Ur.default;
                                        window.clipboardData.setData(o, t)
                                    } else r.clipboardData.clearData(), r.clipboardData.setData(e.format, t);
                                e.onCopy && (r.preventDefault(), e.onCopy(r.clipboardData))
                            })), document.body.appendChild(a), i.selectNodeContents(a), s.addRange(i), !document.execCommand("copy")) throw new Error("copy command was unsuccessful");
                        l = !0
                    } catch (u) {
                        n && console.error("unable to copy using execCommand: ", u), n && console.warn("trying IE specific stuff");
                        try {
                            window.clipboardData.setData(e.format || "text", t), e.onCopy && e.onCopy(window.clipboardData), l = !0
                        } catch (u) {
                            n && console.error("unable to copy using clipboardData: ", u), n && console.error("falling back to prompt"), r = function(t) {
                                var e = (/mac os x/i.test(navigator.userAgent) ? "⌘" : "Ctrl") + "+C";
                                return t.replace(/#{\s*key\s*}/g, e)
                            }("message" in e ? e.message : "Copy to clipboard: #{key}, Enter"), window.prompt(r, t)
                        }
                    } finally {
                        s && ("function" == typeof s.removeRange ? s.removeRange(i) : s.removeAllRanges()), a && document.body.removeChild(a), o()
                    }
                    return l
                },
                Dr = {},
                zr = [],
                Fr = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord/i;

            function Wr(t, e) {
                for (var n in e) t[n] = e[n];
                return t
            }

            function Hr(t) {
                var e = t.parentNode;
                e && e.removeChild(t)
            }

            function $r(t, e, n) {
                var r, o = arguments,
                    i = {};
                for (r in e) "key" !== r && "ref" !== r && (i[r] = e[r]);
                if (arguments.length > 3)
                    for (n = [n], r = 3; r < arguments.length; r++) n.push(o[r]);
                if (null != n && (i.children = n), "function" == typeof t && null != t.defaultProps)
                    for (r in t.defaultProps) void 0 === i[r] && (i[r] = t.defaultProps[r]);
                return Jr(t, i, e && e.key, e && e.ref, null)
            }

            function Jr(t, e, n, r, o) {
                var i = {
                    type: t,
                    props: e,
                    key: n,
                    ref: r,
                    __k: null,
                    __: null,
                    __b: 0,
                    __e: null,
                    __d: void 0,
                    __c: null,
                    constructor: void 0,
                    __v: o
                };
                return null == o && (i.__v = i), Rr.vnode && Rr.vnode(i), i
            }

            function Yr() {
                return {}
            }

            function Vr(t) {
                return t.children
            }

            function Kr(t, e) {
                this.props = t, this.context = e
            }

            function Zr(t, e) {
                if (null == e) return t.__ ? Zr(t.__, t.__.__k.indexOf(t) + 1) : null;
                for (var n; e < t.__k.length; e++)
                    if (null != (n = t.__k[e]) && null != n.__e) return n.__e;
                return "function" == typeof t.type ? Zr(t) : null
            }

            function Qr(t) {
                var e, n;
                if (null != (t = t.__) && null != t.__c) {
                    for (t.__e = t.__c.base = null, e = 0; e < t.__k.length; e++)
                        if (null != (n = t.__k[e]) && null != n.__e) {
                            t.__e = t.__c.base = n.__e;
                            break
                        }
                    return Qr(t)
                }
            }

            function Xr(t) {
                (!t.__d && (t.__d = !0) && Tr.push(t) && !Or++ || Br !== Rr.debounceRendering) && ((Br = Rr.debounceRendering) || Nr)(Gr)
            }

            function Gr() {
                for (var t; Or = Tr.length;) t = Tr.sort((function(t, e) {
                    return t.__v.__b - e.__v.__b
                })), Tr = [], t.some((function(t) {
                    var e, n, r, o, i, s, a;
                    t.__d && (s = (i = (e = t).__v).__e, (a = e.__P) && (n = [], (r = Wr({}, i)).__v = r, o = io(a, i, r, e.__n, void 0 !== a.ownerSVGElement, null, n, null == s ? Zr(i) : s), so(n, i), o != s && Qr(i)))
                }))
            }

            function to(t, e, n, r, o, i, s, a, l) {
                var u, c, h, d, f, p, m, g = n && n.__k || zr,
                    _ = g.length;
                if (a == Dr && (a = null != i ? i[0] : _ ? Zr(n, 0) : null), u = 0, e.__k = eo(e.__k, (function(n) {
                        if (null != n) {
                            if (n.__ = e, n.__b = e.__b + 1, null === (h = g[u]) || h && n.key == h.key && n.type === h.type) g[u] = void 0;
                            else
                                for (c = 0; c < _; c++) {
                                    if ((h = g[c]) && n.key == h.key && n.type === h.type) {
                                        g[c] = void 0;
                                        break
                                    }
                                    h = null
                                }
                            if (d = io(t, n, h = h || Dr, r, o, i, s, a, l), (c = n.ref) && h.ref != c && (m || (m = []), h.ref && m.push(h.ref, null, n), m.push(c, n.__c || d, n)), null != d) {
                                var v;
                                if (null == p && (p = d), void 0 !== n.__d) v = n.__d, n.__d = void 0;
                                else if (i == h || d != a || null == d.parentNode) {
                                    t: if (null == a || a.parentNode !== t) t.appendChild(d), v = null;
                                        else {
                                            for (f = a, c = 0;
                                                (f = f.nextSibling) && c < _; c += 2)
                                                if (f == d) break t;
                                            t.insertBefore(d, a), v = a
                                        }
                                    "option" == e.type && (t.value = "")
                                }
                                a = void 0 !== v ? v : d.nextSibling, "function" == typeof e.type && (e.__d = a)
                            } else a && h.__e == a && a.parentNode != t && (a = Zr(h))
                        }
                        return u++, n
                    })), e.__e = p, null != i && "function" != typeof e.type)
                    for (u = i.length; u--;) null != i[u] && Hr(i[u]);
                for (u = _; u--;) null != g[u] && lo(g[u], g[u]);
                if (m)
                    for (u = 0; u < m.length; u++) ao(m[u], m[++u], m[++u])
            }

            function eo(t, e, n) {
                if (null == n && (n = []), null == t || "boolean" == typeof t) e && n.push(e(null));
                else if (Array.isArray(t))
                    for (var r = 0; r < t.length; r++) eo(t[r], e, n);
                else n.push(e ? e("string" == typeof t || "number" == typeof t ? Jr(null, t, null, null, t) : null != t.__e || null != t.__c ? Jr(t.type, t.props, t.key, null, t.__v) : t) : t);
                return n
            }

            function no(t, e, n) {
                "-" === e[0] ? t.setProperty(e, n) : t[e] = "number" == typeof n && !1 === Fr.test(e) ? n + "px" : null == n ? "" : n
            }

            function ro(t, e, n, r, o) {
                var i, s, a, l, u;
                if (o ? "className" === e && (e = "class") : "class" === e && (e = "className"), "style" === e)
                    if (i = t.style, "string" == typeof n) i.cssText = n;
                    else {
                        if ("string" == typeof r && (i.cssText = "", r = null), r)
                            for (l in r) n && l in n || no(i, l, "");
                        if (n)
                            for (u in n) r && n[u] === r[u] || no(i, u, n[u])
                    }
                else "o" === e[0] && "n" === e[1] ? (s = e !== (e = e.replace(/Capture$/, "")), a = e.toLowerCase(), e = (a in t ? a : e).slice(2), n ? (r || t.addEventListener(e, oo, s), (t.l || (t.l = {}))[e] = n) : t.removeEventListener(e, oo, s)) : "list" !== e && "tagName" !== e && "form" !== e && "type" !== e && "size" !== e && !o && e in t ? t[e] = null == n ? "" : n : "function" != typeof n && "dangerouslySetInnerHTML" !== e && (e !== (e = e.replace(/^xlink:?/, "")) ? null == n || !1 === n ? t.removeAttributeNS("http://www.w3.org/1999/xlink", e.toLowerCase()) : t.setAttributeNS("http://www.w3.org/1999/xlink", e.toLowerCase(), n) : null == n || !1 === n && !/^ar/.test(e) ? t.removeAttribute(e) : t.setAttribute(e, n))
            }

            function oo(t) {
                this.l[t.type](Rr.event ? Rr.event(t) : t)
            }

            function io(t, e, n, r, o, i, s, a, l) {
                var u, c, h, d, f, p, m, g, _, v, w = e.type;
                if (void 0 !== e.constructor) return null;
                (u = Rr.__b) && u(e);
                try {
                    t: if ("function" == typeof w) {
                        if (g = e.props, _ = (u = w.contextType) && r[u.__c], v = u ? _ ? _.props.value : u.__ : r, n.__c ? m = (c = e.__c = n.__c).__ = c.__E : ("prototype" in w && w.prototype.render ? e.__c = c = new w(g, v) : (e.__c = c = new Kr(g, v), c.constructor = w, c.render = uo), _ && _.sub(c), c.props = g, c.state || (c.state = {}), c.context = v, c.__n = r, h = c.__d = !0, c.__h = []), null == c.__s && (c.__s = c.state), null != w.getDerivedStateFromProps && (c.__s == c.state && (c.__s = Wr({}, c.__s)), Wr(c.__s, w.getDerivedStateFromProps(g, c.__s))), d = c.props, f = c.state, h) null == w.getDerivedStateFromProps && null != c.componentWillMount && c.componentWillMount(), null != c.componentDidMount && c.__h.push(c.componentDidMount);
                        else {
                            if (null == w.getDerivedStateFromProps && g !== d && null != c.componentWillReceiveProps && c.componentWillReceiveProps(g, v), !c.__e && null != c.shouldComponentUpdate && !1 === c.shouldComponentUpdate(g, c.__s, v) || e.__v === n.__v && !c.__) {
                                for (c.props = g, c.state = c.__s, e.__v !== n.__v && (c.__d = !1), c.__v = e, e.__e = n.__e, e.__k = n.__k, c.__h.length && s.push(c), u = 0; u < e.__k.length; u++) e.__k[u] && (e.__k[u].__ = e);
                                break t
                            }
                            null != c.componentWillUpdate && c.componentWillUpdate(g, c.__s, v), null != c.componentDidUpdate && c.__h.push((function() {
                                c.componentDidUpdate(d, f, p)
                            }))
                        }
                        c.context = v, c.props = g, c.state = c.__s, (u = Rr.__r) && u(e), c.__d = !1, c.__v = e, c.__P = t, u = c.render(c.props, c.state, c.context), e.__k = null != u && u.type == Vr && null == u.key ? u.props.children : Array.isArray(u) ? u : [u], null != c.getChildContext && (r = Wr(Wr({}, r), c.getChildContext())), h || null == c.getSnapshotBeforeUpdate || (p = c.getSnapshotBeforeUpdate(d, f)), to(t, e, n, r, o, i, s, a, l), c.base = e.__e, c.__h.length && s.push(c), m && (c.__E = c.__ = null), c.__e = !1
                    } else null == i && e.__v === n.__v ? (e.__k = n.__k, e.__e = n.__e) : e.__e = function(t, e, n, r, o, i, s, a) {
                        var l, u, c, h, d, f = n.props,
                            p = e.props;
                        if (o = "svg" === e.type || o, null != i)
                            for (l = 0; l < i.length; l++)
                                if (null != (u = i[l]) && ((null === e.type ? 3 === u.nodeType : u.localName === e.type) || t == u)) {
                                    t = u, i[l] = null;
                                    break
                                }
                        if (null == t) {
                            if (null === e.type) return document.createTextNode(p);
                            t = o ? document.createElementNS("http://www.w3.org/2000/svg", e.type) : document.createElement(e.type, p.is && {
                                is: p.is
                            }), i = null, a = !1
                        }
                        if (null === e.type) f !== p && t.data != p && (t.data = p);
                        else {
                            if (null != i && (i = zr.slice.call(t.childNodes)), c = (f = n.props || Dr).dangerouslySetInnerHTML, h = p.dangerouslySetInnerHTML, !a) {
                                if (f === Dr)
                                    for (f = {}, d = 0; d < t.attributes.length; d++) f[t.attributes[d].name] = t.attributes[d].value;
                                (h || c) && (h && c && h.__html == c.__html || (t.innerHTML = h && h.__html || ""))
                            }(function(t, e, n, r, o) {
                                var i;
                                for (i in n) "children" === i || "key" === i || i in e || ro(t, i, null, n[i], r);
                                for (i in e) o && "function" != typeof e[i] || "children" === i || "key" === i || "value" === i || "checked" === i || n[i] === e[i] || ro(t, i, e[i], n[i], r)
                            })(t, p, f, o, a), h ? e.__k = [] : (e.__k = e.props.children, to(t, e, n, r, "foreignObject" !== e.type && o, i, s, Dr, a)), a || ("value" in p && void 0 !== (l = p.value) && l !== t.value && ro(t, "value", l, f.value, !1), "checked" in p && void 0 !== (l = p.checked) && l !== t.checked && ro(t, "checked", l, f.checked, !1))
                        }
                        return t
                    }(n.__e, e, n, r, o, i, s, l);
                    (u = Rr.diffed) && u(e)
                }
                catch (t) {
                    e.__v = null, Rr.__e(t, e, n)
                }
                return e.__e
            }

            function so(t, e) {
                Rr.__c && Rr.__c(e, t), t.some((function(e) {
                    try {
                        t = e.__h, e.__h = [], t.some((function(t) {
                            t.call(e)
                        }))
                    } catch (t) {
                        Rr.__e(t, e.__v)
                    }
                }))
            }

            function ao(t, e, n) {
                try {
                    "function" == typeof t ? t(e) : t.current = e
                } catch (t) {
                    Rr.__e(t, n)
                }
            }

            function lo(t, e, n) {
                var r, o, i;
                if (Rr.unmount && Rr.unmount(t), (r = t.ref) && (r.current && r.current !== t.__e || ao(r, null, e)), n || "function" == typeof t.type || (n = null != (o = t.__e)), t.__e = t.__d = void 0, null != (r = t.__c)) {
                    if (r.componentWillUnmount) try {
                        r.componentWillUnmount()
                    } catch (t) {
                        Rr.__e(t, e)
                    }
                    r.base = r.__P = null
                }
                if (r = t.__k)
                    for (i = 0; i < r.length; i++) r[i] && lo(r[i], e, n);
                null != o && Hr(o)
            }

            function uo(t, e, n) {
                return this.constructor(t, n)
            }

            function co(t, e, n) {
                var r, o, i;
                Rr.__ && Rr.__(t, e), o = (r = n === Pr) ? null : n && n.__k || e.__k, t = $r(Vr, null, [t]), i = [], io(e, (r ? e : n || e).__k = t, o || Dr, Dr, void 0 !== e.ownerSVGElement, n && !r ? [n] : o ? null : zr.slice.call(e.childNodes), i, n || Dr, r), so(i, t)
            }

            function ho(t, e) {
                co(t, e, Pr)
            }

            function fo(t, e) {
                var n, r;
                for (r in e = Wr(Wr({}, t.props), e), arguments.length > 2 && (e.children = zr.slice.call(arguments, 2)), n = {}, e) "key" !== r && "ref" !== r && (n[r] = e[r]);
                return Jr(t.type, n, e.key || t.key, e.ref || t.ref, null)
            }

            function po(t) {
                var e = {},
                    n = {
                        __c: "__cC" + Lr++,
                        __: t,
                        Consumer: function(t, e) {
                            return t.children(e)
                        },
                        Provider: function(t) {
                            var r, o = this;
                            return this.getChildContext || (r = [], this.getChildContext = function() {
                                return e[n.__c] = o, e
                            }, this.shouldComponentUpdate = function(t) {
                                o.props.value !== t.value && r.some((function(e) {
                                    e.context = t.value, Xr(e)
                                }))
                            }, this.sub = function(t) {
                                r.push(t);
                                var e = t.componentWillUnmount;
                                t.componentWillUnmount = function() {
                                    r.splice(r.indexOf(t), 1), e && e.call(t)
                                }
                            }), t.children
                        }
                    };
                return n.Consumer.contextType = n, n.Provider.__ = n, n
            }
            Rr = {
                __e: function(t, e) {
                    for (var n, r; e = e.__;)
                        if ((n = e.__c) && !n.__) try {
                            if (n.constructor && null != n.constructor.getDerivedStateFromError && (r = !0, n.setState(n.constructor.getDerivedStateFromError(t))), null != n.componentDidCatch && (r = !0, n.componentDidCatch(t)), r) return Xr(n.__E = n)
                        } catch (e) {
                            t = e
                        }
                    throw t
                }
            }, Kr.prototype.setState = function(t, e) {
                var n;
                n = this.__s !== this.state ? this.__s : this.__s = Wr({}, this.state), "function" == typeof t && (t = t(n, this.props)), t && Wr(n, t), null != t && this.__v && (e && this.__h.push(e), Xr(this))
            }, Kr.prototype.forceUpdate = function(t) {
                this.__v && (this.__e = !0, t && this.__h.push(t), Xr(this))
            }, Kr.prototype.render = Vr, Tr = [], Or = 0, Nr = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, Pr = Dr, Lr = 0;
            var mo, go, _o, vo = 0,
                wo = [],
                yo = Rr.__r,
                bo = Rr.diffed,
                Mo = Rr.__c,
                ko = Rr.unmount;

            function xo(t, e) {
                Rr.__h && Rr.__h(go, t, vo || e), vo = 0;
                var n = go.__H || (go.__H = {
                    __: [],
                    __h: []
                });
                return t >= n.__.length && n.__.push({}), n.__[t]
            }

            function So(t) {
                return vo = 1, Eo(jo, t)
            }

            function Eo(t, e, n) {
                var r = xo(mo++, 2);
                return r.__c || (r.__c = go, r.__ = [n ? n(e) : jo(void 0, e), function(e) {
                    var n = t(r.__[0], e);
                    r.__[0] !== n && (r.__[0] = n, r.__c.setState({}))
                }]), r.__
            }

            function Co(t, e) {
                var n = xo(mo++, 3);
                !Rr.__s && Uo(n.__H, e) && (n.__ = t, n.__H = e, go.__H.__h.push(n))
            }

            function Ao(t, e) {
                var n = xo(mo++, 4);
                !Rr.__s && Uo(n.__H, e) && (n.__ = t, n.__H = e, go.__h.push(n))
            }

            function Io(t) {
                return vo = 5, To((function() {
                    return {
                        current: t
                    }
                }), [])
            }

            function Ro(t, e, n) {
                vo = 6, Ao((function() {
                    "function" == typeof t ? t(e()) : t && (t.current = e())
                }), null == n ? n : n.concat(t))
            }

            function To(t, e) {
                var n = xo(mo++, 7);
                return Uo(n.__H, e) ? (n.__H = e, n.__h = t, n.__ = t()) : n.__
            }

            function Oo(t, e) {
                return vo = 8, To((function() {
                    return t
                }), e)
            }

            function No(t) {
                var e = go.context[t.__c],
                    n = xo(mo++, 9);
                return n.__c = t, e ? (null == n.__ && (n.__ = !0, e.sub(go)), e.props.value) : t.__
            }

            function Bo(t, e) {
                Rr.useDebugValue && Rr.useDebugValue(e ? e(t) : t)
            }

            function Po() {
                wo.some((function(t) {
                    if (t.__P) try {
                        t.__H.__h.forEach(Lo), t.__H.__h.forEach(qo), t.__H.__h = []
                    } catch (go) {
                        return t.__H.__h = [], Rr.__e(go, t.__v), !0
                    }
                })), wo = []
            }

            function Lo(t) {
                t.t && t.t()
            }

            function qo(t) {
                var e = t.__();
                "function" == typeof e && (t.t = e)
            }

            function Uo(t, e) {
                return !t || e.some((function(e, n) {
                    return e !== t[n]
                }))
            }

            function jo(t, e) {
                return "function" == typeof e ? e(t) : e
            }

            function Do(t, e) {
                for (var n in e) t[n] = e[n];
                return t
            }

            function zo(t, e) {
                for (var n in t)
                    if ("__source" !== n && !(n in e)) return !0;
                for (var r in e)
                    if ("__source" !== r && t[r] !== e[r]) return !0;
                return !1
            }
            Rr.__r = function(t) {
                yo && yo(t), mo = 0, (go = t.__c).__H && (go.__H.__h.forEach(Lo), go.__H.__h.forEach(qo), go.__H.__h = [])
            }, Rr.diffed = function(t) {
                bo && bo(t);
                var e = t.__c;
                if (e) {
                    var n = e.__H;
                    n && n.__h.length && (1 !== wo.push(e) && _o === Rr.requestAnimationFrame || ((_o = Rr.requestAnimationFrame) || function(t) {
                        var e, n = function() {
                                clearTimeout(r), cancelAnimationFrame(e), setTimeout(t)
                            },
                            r = setTimeout(n, 100);
                        "undefined" != typeof window && (e = requestAnimationFrame(n))
                    })(Po))
                }
            }, Rr.__c = function(t, e) {
                e.some((function(t) {
                    try {
                        t.__h.forEach(Lo), t.__h = t.__h.filter((function(t) {
                            return !t.__ || qo(t)
                        }))
                    } catch (_o) {
                        e.some((function(t) {
                            t.__h && (t.__h = [])
                        })), e = [], Rr.__e(_o, t.__v)
                    }
                })), Mo && Mo(t, e)
            }, Rr.unmount = function(t) {
                ko && ko(t);
                var e = t.__c;
                if (e) {
                    var n = e.__H;
                    if (n) try {
                        n.__.forEach((function(t) {
                            return t.t && t.t()
                        }))
                    } catch (t) {
                        Rr.__e(t, e.__v)
                    }
                }
            };
            var Fo = function(t) {
                var e, n;

                function r(e) {
                    var n;
                    return (n = t.call(this, e) || this).isPureReactComponent = !0, n
                }
                return n = t, (e = r).prototype = Object.create(n.prototype), e.prototype.constructor = e, e.__proto__ = n, r.prototype.shouldComponentUpdate = function(t, e) {
                    return zo(this.props, t) || zo(this.state, e)
                }, r
            }(Kr);

            function Wo(t, e) {
                function n(t) {
                    var n = this.props.ref,
                        r = n == t.ref;
                    return !r && n && (n.call ? n(null) : n.current = null), e ? !e(this.props, t) || !r : zo(this.props, t)
                }

                function r(e) {
                    return this.shouldComponentUpdate = n, $r(t, Do({}, e))
                }
                return r.prototype.isReactComponent = !0, r.displayName = "Memo(" + (t.displayName || t.name) + ")", r.t = !0, r
            }
            var Ho = Rr.__b;

            function $o(t) {
                function e(e) {
                    var n = Do({}, e);
                    return delete n.ref, t(n, e.ref)
                }
                return e.prototype.isReactComponent = e.t = !0, e.displayName = "ForwardRef(" + (t.displayName || t.name) + ")", e
            }
            Rr.__b = function(t) {
                t.type && t.type.t && t.ref && (t.props.ref = t.ref, t.ref = null), Ho && Ho(t)
            };
            var Jo = function(t, e) {
                    return t ? eo(t).reduce((function(t, n, r) {
                        return t.concat(e(n, r))
                    }), []) : null
                },
                Yo = {
                    map: Jo,
                    forEach: Jo,
                    count: function(t) {
                        return t ? eo(t).length : 0
                    },
                    only: function(t) {
                        if (1 !== (t = eo(t)).length) throw new Error("Children.only() expects only one child.");
                        return t[0]
                    },
                    toArray: eo
                },
                Vo = Rr.__e;

            function Ko(t) {
                return t && ((t = Do({}, t)).__c = null, t.__k = t.__k && t.__k.map(Ko)), t
            }

            function Zo() {
                this.__u = 0, this.o = null, this.__b = null
            }

            function Qo(t) {
                var e = t.__.__c;
                return e && e.u && e.u(t)
            }

            function Xo(t) {
                var e, n, r;

                function o(o) {
                    if (e || (e = t()).then((function(t) {
                            n = t.default || t
                        }), (function(t) {
                            r = t
                        })), r) throw r;
                    if (!n) throw e;
                    return $r(n, o)
                }
                return o.displayName = "Lazy", o.t = !0, o
            }

            function Go() {
                this.i = null, this.l = null
            }
            Rr.__e = function(t, e, n) {
                if (t.then)
                    for (var r, o = e; o = o.__;)
                        if ((r = o.__c) && r.__c) return r.__c(t, e.__c);
                Vo(t, e, n)
            }, (Zo.prototype = new Kr).__c = function(t, e) {
                var n = this;
                null == n.o && (n.o = []), n.o.push(e);
                var r = Qo(n.__v),
                    o = !1,
                    i = function() {
                        o || (o = !0, r ? r(s) : s())
                    };
                e.__c = e.componentWillUnmount, e.componentWillUnmount = function() {
                    i(), e.__c && e.__c()
                };
                var s = function() {
                    var t;
                    if (!--n.__u)
                        for (n.__v.__k[0] = n.state.u, n.setState({
                                u: n.__b = null
                            }); t = n.o.pop();) t.forceUpdate()
                };
                n.__u++ || n.setState({
                    u: n.__b = n.__v.__k[0]
                }), t.then(i, i)
            }, Zo.prototype.render = function(t, e) {
                return this.__b && (this.__v.__k[0] = Ko(this.__b), this.__b = null), [$r(Kr, null, e.u ? null : t.children), e.u && t.fallback]
            };
            var ti = function(t, e, n) {
                if (++n[1] === n[0] && t.l.delete(e), t.props.revealOrder && ("t" !== t.props.revealOrder[0] || !t.l.size))
                    for (n = t.i; n;) {
                        for (; n.length > 3;) n.pop()();
                        if (n[1] < n[0]) break;
                        t.i = n = n[2]
                    }
            };
            (Go.prototype = new Kr).u = function(t) {
                var e = this,
                    n = Qo(e.__v),
                    r = e.l.get(t);
                return r[0]++,
                    function(o) {
                        var i = function() {
                            e.props.revealOrder ? (r.push(o), ti(e, t, r)) : o()
                        };
                        n ? n(i) : i()
                    }
            }, Go.prototype.render = function(t) {
                this.i = null, this.l = new Map;
                var e = eo(t.children);
                t.revealOrder && "b" === t.revealOrder[0] && e.reverse();
                for (var n = e.length; n--;) this.l.set(e[n], this.i = [1, 0, this.i]);
                return t.children
            }, Go.prototype.componentDidUpdate = Go.prototype.componentDidMount = function() {
                var t = this;
                t.l.forEach((function(e, n) {
                    ti(t, n, e)
                }))
            };
            var ei = function() {
                function t() {}
                var e = t.prototype;
                return e.getChildContext = function() {
                    return this.props.context
                }, e.render = function(t) {
                    return t.children
                }, t
            }();

            function ni(t) {
                var e = this,
                    n = t.container,
                    r = $r(ei, {
                        context: e.context
                    }, t.vnode);
                return e.s && e.s !== n && (e.v.parentNode && e.s.removeChild(e.v), lo(e.h), e.p = !1), t.vnode ? e.p ? (n.__k = e.__k, co(r, n), e.__k = n.__k) : (e.v = document.createTextNode(""), ho("", n), n.appendChild(e.v), e.p = !0, e.s = n, co(r, n, e.v), e.__k = e.v.__k) : e.p && (e.v.parentNode && e.s.removeChild(e.v), lo(e.h)), e.h = r, e.componentWillUnmount = function() {
                    e.v.parentNode && e.s.removeChild(e.v), lo(e.h)
                }, null
            }

            function ri(t, e) {
                return $r(ni, {
                    vnode: t,
                    container: e
                })
            }
            var oi = /^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|fill|flood|font|glyph(?!R)|horiz|marker(?!H|W|U)|overline|paint|stop|strikethrough|stroke|text(?!L)|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/;
            Kr.prototype.isReactComponent = {};
            var ii = "undefined" != typeof Symbol && Symbol.for && Symbol.for("react.element") || 60103;

            function si(t, e, n) {
                if (null == e.__k)
                    for (; e.firstChild;) e.removeChild(e.firstChild);
                return co(t, e), "function" == typeof n && n(), t ? t.__c : null
            }
            var ai = Rr.event;

            function li(t, e) {
                t["UNSAFE_" + e] && !t[e] && Object.defineProperty(t, e, {
                    configurable: !1,
                    get: function() {
                        return this["UNSAFE_" + e]
                    },
                    set: function(t) {
                        this["UNSAFE_" + e] = t
                    }
                })
            }
            Rr.event = function(t) {
                ai && (t = ai(t)), t.persist = function() {};
                var e = !1,
                    n = !1,
                    r = t.stopPropagation;
                t.stopPropagation = function() {
                    r.call(t), e = !0
                };
                var o = t.preventDefault;
                return t.preventDefault = function() {
                    o.call(t), n = !0
                }, t.isPropagationStopped = function() {
                    return e
                }, t.isDefaultPrevented = function() {
                    return n
                }, t.nativeEvent = t
            };
            var ui = {
                    configurable: !0,
                    get: function() {
                        return this.class
                    }
                },
                ci = Rr.vnode;

            function hi(t) {
                return $r.bind(null, t)
            }

            function di(t) {
                return !!t && t.$$typeof === ii
            }

            function fi(t) {
                return di(t) ? fo.apply(null, arguments) : t
            }

            function pi(t) {
                return !!t.__k && (co(null, t), !0)
            }

            function mi(t) {
                return t && (t.base || 1 === t.nodeType && t) || null
            }
            Rr.vnode = function(t) {
                t.$$typeof = ii;
                var e = t.type,
                    n = t.props;
                if (e) {
                    if (n.class != n.className && (ui.enumerable = "className" in n, null != n.className && (n.class = n.className), Object.defineProperty(n, "className", ui)), "function" != typeof e) {
                        var r, o, i;
                        for (i in n.defaultValue && void 0 !== n.value && (n.value || 0 === n.value || (n.value = n.defaultValue), delete n.defaultValue), Array.isArray(n.value) && n.multiple && "select" === e && (eo(n.children).forEach((function(t) {
                                -1 != n.value.indexOf(t.props.value) && (t.props.selected = !0)
                            })), delete n.value), n)
                            if (r = oi.test(i)) break;
                        if (r)
                            for (i in o = t.props = {}, n) o[oi.test(i) ? i.replace(/[A-Z0-9]/, "-$&").toLowerCase() : i] = n[i]
                    }! function(e) {
                        var n = t.type,
                            r = t.props;
                        if (r && "string" == typeof n) {
                            var o = {};
                            for (var i in r) /^on(Ani|Tra|Tou)/.test(i) && (r[i.toLowerCase()] = r[i], delete r[i]), o[i.toLowerCase()] = i;
                            if (o.ondoubleclick && (r.ondblclick = r[o.ondoubleclick], delete r[o.ondoubleclick]), o.onbeforeinput && (r.onbeforeinput = r[o.onbeforeinput], delete r[o.onbeforeinput]), o.onchange && ("textarea" === n || "input" === n.toLowerCase() && !/^fil|che|ra/i.test(r.type))) {
                                var s = o.oninput || "oninput";
                                r[s] || (r[s] = r[o.onchange], delete r[o.onchange])
                            }
                        }
                    }(), "function" == typeof e && !e.m && e.prototype && (li(e.prototype, "componentWillMount"), li(e.prototype, "componentWillReceiveProps"), li(e.prototype, "componentWillUpdate"), e.m = !0)
                }
                ci && ci(t)
            };
            var gi = function(t, e) {
                    return t(e)
                },
                _i = {
                    useState: So,
                    useReducer: Eo,
                    useEffect: Co,
                    useLayoutEffect: Ao,
                    useRef: Io,
                    useImperativeHandle: Ro,
                    useMemo: To,
                    useCallback: Oo,
                    useContext: No,
                    useDebugValue: Bo,
                    version: "16.8.0",
                    Children: Yo,
                    render: si,
                    hydrate: si,
                    unmountComponentAtNode: pi,
                    createPortal: ri,
                    createElement: $r,
                    createContext: po,
                    createFactory: hi,
                    cloneElement: fi,
                    createRef: Yr,
                    Fragment: Vr,
                    isValidElement: di,
                    findDOMNode: mi,
                    Component: Kr,
                    PureComponent: Fo,
                    memo: Wo,
                    forwardRef: $o,
                    unstable_batchedUpdates: gi,
                    Suspense: Zo,
                    SuspenseList: Go,
                    lazy: Xo
                },
                vi = Object.freeze(Object.defineProperty({
                    __proto__: null,
                    default: _i,
                    version: "16.8.0",
                    Children: Yo,
                    render: si,
                    hydrate: function(t, e, n) {
                        return ho(t, e), "function" == typeof n && n(), t ? t.__c : null
                    },
                    unmountComponentAtNode: pi,
                    createPortal: ri,
                    createFactory: hi,
                    cloneElement: fi,
                    isValidElement: di,
                    findDOMNode: mi,
                    PureComponent: Fo,
                    memo: Wo,
                    forwardRef: $o,
                    unstable_batchedUpdates: gi,
                    Suspense: Zo,
                    SuspenseList: Go,
                    lazy: Xo,
                    createElement: $r,
                    createContext: po,
                    createRef: Yr,
                    Fragment: Vr,
                    Component: Kr,
                    useState: So,
                    useReducer: Eo,
                    useEffect: Co,
                    useLayoutEffect: Ao,
                    useRef: Io,
                    useImperativeHandle: Ro,
                    useMemo: To,
                    useCallback: Oo,
                    useContext: No,
                    useDebugValue: Bo,
                    useErrorBoundary: function(t) {
                        var e = xo(mo++, 10),
                            n = So();
                        return e.__ = t, go.componentDidCatch || (go.componentDidCatch = function(t) {
                            e.__ && e.__(t), n[1](t)
                        }), [n[0], function() {
                            n[1](void 0)
                        }]
                    }
                }, Symbol.toStringTag, {
                    value: "Module"
                })),
                wi = n(vi);

            function yi(t) {
                return t && "object" == typeof t && "default" in t ? t.default : t
            }
            var bi = qe,
                Mi = yi(Ue),
                ki = yi(jr),
                xi = wi;
            "undefined" == typeof Symbol || Symbol.iterator || (Symbol.iterator = Symbol("Symbol.iterator")), "undefined" == typeof Symbol || Symbol.asyncIterator || (Symbol.asyncIterator = Symbol("Symbol.asyncIterator"));
            var Si = "walletconnect-wrapper",
                Ei = "walletconnect-style-sheet",
                Ci = "walletconnect-qrcode-modal",
                Ai = "walletconnect-qrcode-text";

            function Ii(t) {
                return xi.createElement("div", {
                    className: "walletconnect-modal__header"
                }, xi.createElement("img", {
                    src: "data:image/svg+xml,%3Csvg height='185' viewBox='0 0 300 185' width='300' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='m61.4385429 36.2562612c48.9112241-47.8881663 128.2119871-47.8881663 177.1232091 0l5.886545 5.7634174c2.445561 2.3944081 2.445561 6.2765112 0 8.6709204l-20.136695 19.715503c-1.222781 1.1972051-3.2053 1.1972051-4.428081 0l-8.100584-7.9311479c-34.121692-33.4079817-89.443886-33.4079817-123.5655788 0l-8.6750562 8.4936051c-1.2227816 1.1972041-3.205301 1.1972041-4.4280806 0l-20.1366949-19.7155031c-2.4455612-2.3944092-2.4455612-6.2765122 0-8.6709204zm218.7677961 40.7737449 17.921697 17.546897c2.445549 2.3943969 2.445563 6.2764769.000031 8.6708899l-80.810171 79.121134c-2.445544 2.394426-6.410582 2.394453-8.85616.000062-.00001-.00001-.000022-.000022-.000032-.000032l-57.354143-56.154572c-.61139-.598602-1.60265-.598602-2.21404 0-.000004.000004-.000007.000008-.000011.000011l-57.3529212 56.154531c-2.4455368 2.394432-6.4105755 2.394472-8.8561612.000087-.0000143-.000014-.0000296-.000028-.0000449-.000044l-80.81241943-79.122185c-2.44556021-2.394408-2.44556021-6.2765115 0-8.6709197l17.92172963-17.5468673c2.4455602-2.3944082 6.4105989-2.3944082 8.8561602 0l57.3549775 56.155357c.6113908.598602 1.602649.598602 2.2140398 0 .0000092-.000009.0000174-.000017.0000265-.000024l57.3521031-56.155333c2.445505-2.3944633 6.410544-2.3945531 8.856161-.0002.000034.0000336.000068.0000673.000101.000101l57.354902 56.155432c.61139.598601 1.60265.598601 2.21404 0l57.353975-56.1543249c2.445561-2.3944092 6.410599-2.3944092 8.85616 0z' fill='%233b99fc'/%3E%3C/svg%3E",
                    className: "walletconnect-modal__headerLogo"
                }), xi.createElement("p", null, "WalletConnect"), xi.createElement("div", {
                    className: "walletconnect-modal__close__wrapper",
                    onClick: t.onClose
                }, xi.createElement("div", {
                    id: "walletconnect-qrcode-close",
                    className: "walletconnect-modal__close__icon"
                }, xi.createElement("div", {
                    className: "walletconnect-modal__close__line1"
                }), xi.createElement("div", {
                    className: "walletconnect-modal__close__line2"
                }))))
            }

            function Ri(t) {
                return xi.createElement("a", {
                    className: "walletconnect-connect__button",
                    href: t.href,
                    id: "walletconnect-connect-button-" + t.name,
                    onClick: t.onClick,
                    rel: "noopener noreferrer",
                    style: {
                        backgroundColor: t.color
                    },
                    target: "_blank"
                }, t.name)
            }

            function Ti(t) {
                var e = t.color,
                    n = t.href,
                    r = t.name,
                    o = t.logo,
                    i = t.onClick;
                return xi.createElement("a", {
                    className: "walletconnect-modal__base__row",
                    href: n,
                    onClick: i,
                    rel: "noopener noreferrer",
                    target: "_blank"
                }, xi.createElement("h3", {
                    className: "walletconnect-modal__base__row__h3"
                }, r), xi.createElement("div", {
                    className: "walletconnect-modal__base__row__right"
                }, xi.createElement("div", {
                    className: "walletconnect-modal__base__row__right__app-icon",
                    style: {
                        background: "url('" + o + "') " + e,
                        backgroundSize: "100%"
                    }
                }), xi.createElement("img", {
                    src: "data:image/svg+xml,%3Csvg fill='none' height='18' viewBox='0 0 8 18' width='8' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath clip-rule='evenodd' d='m.586301.213898c-.435947.33907-.5144813.967342-.175411 1.403292l4.87831 6.27212c.28087.36111.28087.86677 0 1.22788l-4.878311 6.27211c-.33907.436-.260536 1.0642.175412 1.4033.435949.3391 1.064219.2605 1.403289-.1754l4.87832-6.2721c.84259-1.08336.84259-2.60034 0-3.68367l-4.87832-6.27212c-.33907-.4359474-.96734-.514482-1.403289-.175412z' fill='%233c4252' fill-rule='evenodd'/%3E%3C/svg%3E",
                    className: "walletconnect-modal__base__row__right__caret"
                })))
            }

            function Oi(t) {
                var e = t.color,
                    n = t.href,
                    r = t.name,
                    o = t.logo,
                    i = t.onClick,
                    s = window.innerWidth < 768 ? (r.length > 8 ? 2.5 : 2.7) + "vw" : "inherit";
                return xi.createElement("a", {
                    className: "walletconnect-connect__button__icon_anchor",
                    href: n,
                    onClick: i,
                    rel: "noopener noreferrer",
                    target: "_blank"
                }, xi.createElement("div", {
                    className: "walletconnect-connect__button__icon",
                    style: {
                        background: "url('" + o + "') " + e,
                        backgroundSize: "100%"
                    }
                }), xi.createElement("div", {
                    style: {
                        fontSize: s
                    },
                    className: "walletconnect-connect__button__text"
                }, r))
            }

            function Ni(t) {
                var e = bi.isAndroid(),
                    n = xi.useState(""),
                    r = n[0],
                    o = n[1],
                    i = xi.useState(""),
                    s = i[0],
                    a = i[1],
                    l = xi.useState(1),
                    u = l[0],
                    c = l[1],
                    h = s ? t.links.filter((function(t) {
                        return t.name.toLowerCase().includes(s.toLowerCase())
                    })) : t.links,
                    d = t.errorMessage,
                    f = s || h.length > 5,
                    p = Math.ceil(h.length / 12),
                    m = [12 * (u - 1) + 1, 12 * u],
                    g = h.length ? h.filter((function(t, e) {
                        return e + 1 >= m[0] && e + 1 <= m[1]
                    })) : [],
                    _ = !(e || !(p > 1)),
                    v = void 0;
                return xi.createElement("div", null, xi.createElement("p", {
                    id: Ai,
                    className: "walletconnect-qrcode__text"
                }, e ? t.text.connect_mobile_wallet : t.text.choose_preferred_wallet), !e && xi.createElement("input", {
                    className: "walletconnect-search__input",
                    placeholder: "Search",
                    value: r,
                    onChange: function(t) {
                        o(t.target.value), clearTimeout(v), t.target.value ? v = setTimeout((function() {
                            a(t.target.value), c(1)
                        }), 1e3) : (o(""), a(""), c(1))
                    }
                }), xi.createElement("div", {
                    className: "walletconnect-connect__buttons__wrapper" + (e ? "__android" : f && h.length ? "__wrap" : "")
                }, e ? xi.createElement(Ri, {
                    name: t.text.connect,
                    color: "rgb(64, 153, 255)",
                    href: t.uri,
                    onClick: xi.useCallback((function() {
                        bi.saveMobileLinkInfo({
                            name: "Unknown",
                            href: t.uri
                        })
                    }), [])
                }) : g.length ? g.map((function(e) {
                    var n = e.color,
                        r = e.name,
                        o = e.shortName,
                        i = e.logo,
                        s = bi.formatIOSMobile(t.uri, e),
                        a = xi.useCallback((function() {
                            bi.saveMobileLinkInfo({
                                name: r,
                                href: s
                            })
                        }), [g]);
                    return f ? xi.createElement(Oi, {
                        color: n,
                        href: s,
                        name: o || r,
                        logo: i,
                        onClick: a
                    }) : xi.createElement(Ti, {
                        color: n,
                        href: s,
                        name: r,
                        logo: i,
                        onClick: a
                    })
                })) : xi.createElement(xi.Fragment, null, xi.createElement("p", null, d.length ? t.errorMessage : t.links.length && !h.length ? t.text.no_wallets_found : t.text.loading))), _ && xi.createElement("div", {
                    className: "walletconnect-modal__footer"
                }, Array(p).fill(0).map((function(t, e) {
                    var n = e + 1,
                        r = u === n;
                    return xi.createElement("a", {
                        style: {
                            margin: "auto 10px",
                            fontWeight: r ? "bold" : "normal"
                        },
                        onClick: function() {
                            return c(n)
                        }
                    }, n)
                }))))
            }

            function Bi(t) {
                var e = !!t.message.trim();
                return xi.createElement("div", {
                    className: "walletconnect-qrcode__notification" + (e ? " notification__show" : "")
                }, t.message)
            }

            function Pi(t) {
                var e = xi.useState(""),
                    n = e[0],
                    r = e[1],
                    o = xi.useState(""),
                    i = o[0],
                    s = o[1];
                return xi.useEffect((function() {
                    try {
                        return Promise.resolve(function(t) {
                            try {
                                var e = "";
                                return Promise.resolve(Mi.toString(t, {
                                    margin: 0,
                                    type: "svg"
                                })).then((function(t) {
                                    return "string" == typeof t && (e = t.replace("<svg", '<svg class="walletconnect-qrcode__image"')), e
                                }))
                            } catch (Mo) {
                                return Promise.reject(Mo)
                            }
                        }(t.uri)).then((function(t) {
                            s(t)
                        }))
                    } catch (Mo) {
                        Promise.reject(Mo)
                    }
                }), []), xi.createElement("div", null, xi.createElement("p", {
                    id: Ai,
                    className: "walletconnect-qrcode__text"
                }, t.text.scan_qrcode_with_wallet), xi.createElement("div", {
                    dangerouslySetInnerHTML: {
                        __html: i
                    }
                }), xi.createElement("div", {
                    className: "walletconnect-modal__footer"
                }, xi.createElement("a", {
                    onClick: function() {
                        ki(t.uri) ? (r(t.text.copied_to_clipboard), setInterval((function() {
                            return r("")
                        }), 1200)) : (r("Error"), setInterval((function() {
                            return r("")
                        }), 1200))
                    }
                }, t.text.copy_to_clipboard)), xi.createElement(Bi, {
                    message: n
                }))
            }

            function Li(t) {
                var e = bi.isAndroid(),
                    n = bi.isMobile(),
                    r = n ? t.qrcodeModalOptions && t.qrcodeModalOptions.mobileLinks ? t.qrcodeModalOptions.mobileLinks : void 0 : t.qrcodeModalOptions && t.qrcodeModalOptions.desktopLinks ? t.qrcodeModalOptions.desktopLinks : void 0,
                    o = xi.useState(!1),
                    i = o[0],
                    s = o[1],
                    a = xi.useState(!1),
                    l = a[0],
                    u = a[1],
                    c = xi.useState(!n),
                    h = c[0],
                    d = c[1],
                    f = {
                        mobile: n,
                        text: t.text,
                        uri: t.uri,
                        qrcodeModalOptions: t.qrcodeModalOptions
                    },
                    p = xi.useState(""),
                    m = p[0],
                    g = p[1],
                    _ = xi.useState(!1),
                    v = _[0],
                    w = _[1],
                    y = xi.useState([]),
                    b = y[0],
                    M = y[1],
                    k = xi.useState(""),
                    x = k[0],
                    S = k[1],
                    E = function() {
                        l || i || r && !r.length || b.length > 0 || xi.useEffect((function() {
                            ! function() {
                                try {
                                    if (e) return Promise.resolve();
                                    s(!0);
                                    var o = function(t, e) {
                                        try {
                                            var n = t()
                                        } catch (Mo) {
                                            return e(Mo)
                                        }
                                        return n && n.then ? n.then(void 0, e) : n
                                    }((function() {
                                        var e = t.qrcodeModalOptions && t.qrcodeModalOptions.registryUrl ? t.qrcodeModalOptions.registryUrl : bi.getWalletRegistryUrl();
                                        return Promise.resolve(fetch(e)).then((function(e) {
                                            return Promise.resolve(e.json()).then((function(e) {
                                                var o = e.listings,
                                                    i = n ? "mobile" : "desktop",
                                                    a = bi.getMobileLinkRegistry(bi.formatMobileRegistry(o, i), r);
                                                s(!1), u(!0), S(a.length ? "" : t.text.no_supported_wallets), M(a);
                                                var l = 1 === a.length;
                                                l && (g(bi.formatIOSMobile(t.uri, a[0])), d(!0)), w(l)
                                            }))
                                        }))
                                    }), (function(e) {
                                        s(!1), u(!0), S(t.text.something_went_wrong), console.error(e)
                                    }));
                                    Promise.resolve(o && o.then ? o.then((function() {})) : void 0)
                                } catch (Mo) {
                                    return Promise.reject(Mo)
                                }
                            }()
                        }))
                    };
                E();
                var C = n ? h : !h;
                return xi.createElement("div", {
                    id: Ci,
                    className: "walletconnect-qrcode__base animated fadeIn"
                }, xi.createElement("div", {
                    className: "walletconnect-modal__base"
                }, xi.createElement(Ii, {
                    onClose: t.onClose
                }), v && h ? xi.createElement("div", {
                    className: "walletconnect-modal__single_wallet"
                }, xi.createElement("a", {
                    onClick: function() {
                        return bi.saveMobileLinkInfo({
                            name: b[0].name,
                            href: m
                        })
                    },
                    href: m,
                    rel: "noopener noreferrer",
                    target: "_blank"
                }, t.text.connect_with + " " + (v ? b[0].name : "") + " ›")) : e || i || !i && b.length ? xi.createElement("div", {
                    className: "walletconnect-modal__mobile__toggle" + (C ? " right__selected" : "")
                }, xi.createElement("div", {
                    className: "walletconnect-modal__mobile__toggle_selector"
                }), n ? xi.createElement(xi.Fragment, null, xi.createElement("a", {
                    onClick: function() {
                        return d(!1), E()
                    }
                }, t.text.mobile), xi.createElement("a", {
                    onClick: function() {
                        return d(!0)
                    }
                }, t.text.qrcode)) : xi.createElement(xi.Fragment, null, xi.createElement("a", {
                    onClick: function() {
                        return d(!0)
                    }
                }, t.text.qrcode), xi.createElement("a", {
                    onClick: function() {
                        return d(!1), E()
                    }
                }, t.text.desktop))) : null, xi.createElement("div", null, h || !e && !i && !b.length ? xi.createElement(Pi, Object.assign({}, f)) : xi.createElement(Ni, Object.assign({}, f, {
                    links: b,
                    errorMessage: x
                })))))
            }
            var qi = {
                de: {
                    choose_preferred_wallet: "Wähle bevorzugte Wallet",
                    connect_mobile_wallet: "Verbinde mit Mobile Wallet",
                    scan_qrcode_with_wallet: "Scanne den QR-code mit einer WalletConnect kompatiblen Wallet",
                    connect: "Verbinden",
                    qrcode: "QR-Code",
                    mobile: "Mobile",
                    desktop: "Desktop",
                    copy_to_clipboard: "In die Zwischenablage kopieren",
                    copied_to_clipboard: "In die Zwischenablage kopiert!",
                    connect_with: "Verbinden mit Hilfe von",
                    loading: "Laden...",
                    something_went_wrong: "Etwas ist schief gelaufen",
                    no_supported_wallets: "Es gibt noch keine unterstützten Wallet",
                    no_wallets_found: "keine Wallet gefunden"
                },
                en: {
                    choose_preferred_wallet: "Choose your preferred wallet",
                    connect_mobile_wallet: "Connect to Mobile Wallet",
                    scan_qrcode_with_wallet: "Scan QR code with a WalletConnect-compatible wallet",
                    connect: "Connect",
                    qrcode: "QR Code",
                    mobile: "Mobile",
                    desktop: "Desktop",
                    copy_to_clipboard: "Copy to clipboard",
                    copied_to_clipboard: "Copied to clipboard!",
                    connect_with: "Connect with",
                    loading: "Loading...",
                    something_went_wrong: "Something went wrong",
                    no_supported_wallets: "There are no supported wallets yet",
                    no_wallets_found: "No wallets found"
                },
                es: {
                    choose_preferred_wallet: "Elige tu billetera preferida",
                    connect_mobile_wallet: "Conectar a billetera móvil",
                    scan_qrcode_with_wallet: "Escanea el código QR con una billetera compatible con WalletConnect",
                    connect: "Conectar",
                    qrcode: "Código QR",
                    mobile: "Móvil",
                    desktop: "Desktop",
                    copy_to_clipboard: "Copiar",
                    copied_to_clipboard: "Copiado!",
                    connect_with: "Conectar mediante",
                    loading: "Cargando...",
                    something_went_wrong: "Algo salió mal",
                    no_supported_wallets: "Todavía no hay billeteras compatibles",
                    no_wallets_found: "No se encontraron billeteras"
                },
                fr: {
                    choose_preferred_wallet: "Choisissez votre portefeuille préféré",
                    connect_mobile_wallet: "Se connecter au portefeuille mobile",
                    scan_qrcode_with_wallet: "Scannez le QR code avec un portefeuille compatible WalletConnect",
                    connect: "Se connecter",
                    qrcode: "QR Code",
                    mobile: "Mobile",
                    desktop: "Desktop",
                    copy_to_clipboard: "Copier",
                    copied_to_clipboard: "Copié!",
                    connect_with: "Connectez-vous à l'aide de",
                    loading: "Chargement...",
                    something_went_wrong: "Quelque chose a mal tourné",
                    no_supported_wallets: "Il n'y a pas encore de portefeuilles pris en charge",
                    no_wallets_found: "Aucun portefeuille trouvé"
                },
                ko: {
                    choose_preferred_wallet: "원하는 지갑을 선택하세요",
                    connect_mobile_wallet: "모바일 지갑과 연결",
                    scan_qrcode_with_wallet: "WalletConnect 지원 지갑에서 QR코드를 스캔하세요",
                    connect: "연결",
                    qrcode: "QR 코드",
                    mobile: "모바일",
                    desktop: "데스크탑",
                    copy_to_clipboard: "클립보드에 복사",
                    copied_to_clipboard: "클립보드에 복사되었습니다!",
                    connect_with: "와 연결하다",
                    loading: "로드 중...",
                    something_went_wrong: "문제가 발생했습니다.",
                    no_supported_wallets: "아직 지원되는 지갑이 없습니다",
                    no_wallets_found: "지갑을 찾을 수 없습니다"
                },
                pt: {
                    choose_preferred_wallet: "Escolha sua carteira preferida",
                    connect_mobile_wallet: "Conectar-se à carteira móvel",
                    scan_qrcode_with_wallet: "Ler o código QR com uma carteira compatível com WalletConnect",
                    connect: "Conectar",
                    qrcode: "Código QR",
                    mobile: "Móvel",
                    desktop: "Desktop",
                    copy_to_clipboard: "Copiar",
                    copied_to_clipboard: "Copiado!",
                    connect_with: "Ligar por meio de",
                    loading: "Carregamento...",
                    something_went_wrong: "Algo correu mal",
                    no_supported_wallets: "Ainda não há carteiras suportadas",
                    no_wallets_found: "Nenhuma carteira encontrada"
                },
                zh: {
                    choose_preferred_wallet: "选择你的钱包",
                    connect_mobile_wallet: "连接至移动端钱包",
                    scan_qrcode_with_wallet: "使用兼容 WalletConnect 的钱包扫描二维码",
                    connect: "连接",
                    qrcode: "二维码",
                    mobile: "移动",
                    desktop: "桌面",
                    copy_to_clipboard: "复制到剪贴板",
                    copied_to_clipboard: "复制到剪贴板成功！",
                    connect_with: "通过以下方式连接",
                    loading: "正在加载...",
                    something_went_wrong: "出了问题",
                    no_supported_wallets: "目前还没有支持的钱包",
                    no_wallets_found: "没有找到钱包"
                },
                fa: {
                    choose_preferred_wallet: "کیف پول مورد نظر خود را انتخاب کنید",
                    connect_mobile_wallet: "به کیف پول موبایل وصل شوید",
                    scan_qrcode_with_wallet: "کد QR را با یک کیف پول سازگار با WalletConnect اسکن کنید",
                    connect: "اتصال",
                    qrcode: "کد QR",
                    mobile: "سیار",
                    desktop: "دسکتاپ",
                    copy_to_clipboard: "کپی به کلیپ بورد",
                    copied_to_clipboard: "در کلیپ بورد کپی شد!",
                    connect_with: "ارتباط با",
                    loading: "...بارگذاری",
                    something_went_wrong: "مشکلی پیش آمد",
                    no_supported_wallets: "هنوز هیچ کیف پول پشتیبانی شده ای وجود ندارد",
                    no_wallets_found: "هیچ کیف پولی پیدا نشد"
                }
            };

            function Ui() {
                var t = bi.getDocumentOrThrow(),
                    e = t.getElementById(Ci);
                e && (e.className = e.className.replace("fadeIn", "fadeOut"), setTimeout((function() {
                    var e = t.getElementById(Si);
                    e && t.body.removeChild(e)
                }), 300))
            }

            function ji(t) {
                return function() {
                    Ui(), t && t()
                }
            }

            function Di(t, e, n) {
                ! function() {
                    var t = bi.getDocumentOrThrow(),
                        e = t.getElementById(Ei);
                    e && t.head.removeChild(e);
                    var n = t.createElement("style");
                    n.setAttribute("id", Ei), n.innerText = ':root {\n  --animation-duration: 300ms;\n}\n\n@keyframes fadeIn {\n  from {\n    opacity: 0;\n  }\n  to {\n    opacity: 1;\n  }\n}\n\n@keyframes fadeOut {\n  from {\n    opacity: 1;\n  }\n  to {\n    opacity: 0;\n  }\n}\n\n.animated {\n  animation-duration: var(--animation-duration);\n  animation-fill-mode: both;\n}\n\n.fadeIn {\n  animation-name: fadeIn;\n}\n\n.fadeOut {\n  animation-name: fadeOut;\n}\n\n#walletconnect-wrapper {\n  -webkit-user-select: none;\n  align-items: center;\n  display: flex;\n  height: 100%;\n  justify-content: center;\n  left: 0;\n  pointer-events: none;\n  position: fixed;\n  top: 0;\n  user-select: none;\n  width: 100%;\n  z-index: 99999999999999;\n}\n\n.walletconnect-modal__headerLogo {\n  height: 21px;\n}\n\n.walletconnect-modal__header p {\n  color: #ffffff;\n  font-size: 20px;\n  font-weight: 600;\n  margin: 0;\n  align-items: flex-start;\n  display: flex;\n  flex: 1;\n  margin-left: 5px;\n}\n\n.walletconnect-modal__close__wrapper {\n  position: absolute;\n  top: 0px;\n  right: 0px;\n  z-index: 10000;\n  background: white;\n  border-radius: 26px;\n  padding: 6px;\n  box-sizing: border-box;\n  width: 26px;\n  height: 26px;\n  cursor: pointer;\n}\n\n.walletconnect-modal__close__icon {\n  position: relative;\n  top: 7px;\n  right: 0;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  transform: rotate(45deg);\n}\n\n.walletconnect-modal__close__line1 {\n  position: absolute;\n  width: 100%;\n  border: 1px solid rgb(48, 52, 59);\n}\n\n.walletconnect-modal__close__line2 {\n  position: absolute;\n  width: 100%;\n  border: 1px solid rgb(48, 52, 59);\n  transform: rotate(90deg);\n}\n\n.walletconnect-qrcode__base {\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n  background: rgba(37, 41, 46, 0.95);\n  height: 100%;\n  left: 0;\n  pointer-events: auto;\n  position: fixed;\n  top: 0;\n  transition: 0.4s cubic-bezier(0.19, 1, 0.22, 1);\n  width: 100%;\n  will-change: opacity;\n  padding: 40px;\n  box-sizing: border-box;\n}\n\n.walletconnect-qrcode__text {\n  color: rgba(60, 66, 82, 0.6);\n  font-size: 16px;\n  font-weight: 600;\n  letter-spacing: 0;\n  line-height: 1.1875em;\n  margin: 10px 0 20px 0;\n  text-align: center;\n  width: 100%;\n}\n\n@media only screen and (max-width: 768px) {\n  .walletconnect-qrcode__text {\n    font-size: 4vw;\n  }\n}\n\n@media only screen and (max-width: 320px) {\n  .walletconnect-qrcode__text {\n    font-size: 14px;\n  }\n}\n\n.walletconnect-qrcode__image {\n  width: calc(100% - 30px);\n  box-sizing: border-box;\n  cursor: none;\n  margin: 0 auto;\n}\n\n.walletconnect-qrcode__notification {\n  position: absolute;\n  bottom: 0;\n  left: 0;\n  right: 0;\n  font-size: 16px;\n  padding: 16px 20px;\n  border-radius: 16px;\n  text-align: center;\n  transition: all 0.1s ease-in-out;\n  background: white;\n  color: black;\n  margin-bottom: -60px;\n  opacity: 0;\n}\n\n.walletconnect-qrcode__notification.notification__show {\n  opacity: 1;\n}\n\n@media only screen and (max-width: 768px) {\n  .walletconnect-modal__header {\n    height: 130px;\n  }\n  .walletconnect-modal__base {\n    overflow: auto;\n  }\n}\n\n@media only screen and (min-device-width: 415px) and (max-width: 768px) {\n  #content {\n    max-width: 768px;\n    box-sizing: border-box;\n  }\n}\n\n@media only screen and (min-width: 375px) and (max-width: 415px) {\n  #content {\n    max-width: 414px;\n    box-sizing: border-box;\n  }\n}\n\n@media only screen and (min-width: 320px) and (max-width: 375px) {\n  #content {\n    max-width: 375px;\n    box-sizing: border-box;\n  }\n}\n\n@media only screen and (max-width: 320px) {\n  #content {\n    max-width: 320px;\n    box-sizing: border-box;\n  }\n}\n\n.walletconnect-modal__base {\n  -webkit-font-smoothing: antialiased;\n  background: #ffffff;\n  border-radius: 24px;\n  box-shadow: 0 10px 50px 5px rgba(0, 0, 0, 0.4);\n  font-family: ui-rounded, "SF Pro Rounded", "SF Pro Text", medium-content-sans-serif-font,\n    -apple-system, BlinkMacSystemFont, ui-sans-serif, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell,\n    "Open Sans", "Helvetica Neue", sans-serif;\n  margin-top: 41px;\n  padding: 24px 24px 22px;\n  pointer-events: auto;\n  position: relative;\n  text-align: center;\n  transition: 0.4s cubic-bezier(0.19, 1, 0.22, 1);\n  will-change: transform;\n  overflow: visible;\n  transform: translateY(-50%);\n  top: 50%;\n  max-width: 500px;\n  margin: auto;\n}\n\n@media only screen and (max-width: 320px) {\n  .walletconnect-modal__base {\n    padding: 24px 12px;\n  }\n}\n\n.walletconnect-modal__base .hidden {\n  transform: translateY(150%);\n  transition: 0.125s cubic-bezier(0.4, 0, 1, 1);\n}\n\n.walletconnect-modal__header {\n  align-items: center;\n  display: flex;\n  height: 26px;\n  left: 0;\n  justify-content: space-between;\n  position: absolute;\n  top: -42px;\n  width: 100%;\n}\n\n.walletconnect-modal__base .wc-logo {\n  align-items: center;\n  display: flex;\n  height: 26px;\n  margin-top: 15px;\n  padding-bottom: 15px;\n  pointer-events: auto;\n}\n\n.walletconnect-modal__base .wc-logo div {\n  background-color: #3399ff;\n  height: 21px;\n  margin-right: 5px;\n  mask-image: url("images/wc-logo.svg") center no-repeat;\n  width: 32px;\n}\n\n.walletconnect-modal__base .wc-logo p {\n  color: #ffffff;\n  font-size: 20px;\n  font-weight: 600;\n  margin: 0;\n}\n\n.walletconnect-modal__base h2 {\n  color: rgba(60, 66, 82, 0.6);\n  font-size: 16px;\n  font-weight: 600;\n  letter-spacing: 0;\n  line-height: 1.1875em;\n  margin: 0 0 19px 0;\n  text-align: center;\n  width: 100%;\n}\n\n.walletconnect-modal__base__row {\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n  align-items: center;\n  border-radius: 20px;\n  cursor: pointer;\n  display: flex;\n  height: 56px;\n  justify-content: space-between;\n  padding: 0 15px;\n  position: relative;\n  margin: 0px 0px 8px;\n  text-align: left;\n  transition: 0.15s cubic-bezier(0.25, 0.46, 0.45, 0.94);\n  will-change: transform;\n  text-decoration: none;\n}\n\n.walletconnect-modal__base__row:hover {\n  background: rgba(60, 66, 82, 0.06);\n}\n\n.walletconnect-modal__base__row:active {\n  background: rgba(60, 66, 82, 0.06);\n  transform: scale(0.975);\n  transition: 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94);\n}\n\n.walletconnect-modal__base__row__h3 {\n  color: #25292e;\n  font-size: 20px;\n  font-weight: 700;\n  margin: 0;\n  padding-bottom: 3px;\n}\n\n.walletconnect-modal__base__row__right {\n  align-items: center;\n  display: flex;\n  justify-content: center;\n}\n\n.walletconnect-modal__base__row__right__app-icon {\n  border-radius: 8px;\n  height: 34px;\n  margin: 0 11px 2px 0;\n  width: 34px;\n  background-size: 100%;\n  box-shadow: 0 4px 12px 0 rgba(37, 41, 46, 0.25);\n}\n\n.walletconnect-modal__base__row__right__caret {\n  height: 18px;\n  opacity: 0.3;\n  transition: 0.1s cubic-bezier(0.25, 0.46, 0.45, 0.94);\n  width: 8px;\n  will-change: opacity;\n}\n\n.walletconnect-modal__base__row:hover .caret,\n.walletconnect-modal__base__row:active .caret {\n  opacity: 0.6;\n}\n\n.walletconnect-modal__mobile__toggle {\n  width: 80%;\n  display: flex;\n  margin: 0 auto;\n  position: relative;\n  overflow: hidden;\n  border-radius: 8px;\n  margin-bottom: 18px;\n  background: #d4d5d9;\n}\n\n.walletconnect-modal__single_wallet {\n  display: flex;\n  justify-content: center;\n  margin-top: 7px;\n  margin-bottom: 18px;\n}\n\n.walletconnect-modal__single_wallet a {\n  cursor: pointer;\n  color: rgb(64, 153, 255);\n  font-size: 21px;\n  font-weight: 800;\n  text-decoration: none !important;\n  margin: 0 auto;\n}\n\n.walletconnect-modal__mobile__toggle_selector {\n  width: calc(50% - 8px);\n  background: white;\n  position: absolute;\n  border-radius: 5px;\n  height: calc(100% - 8px);\n  top: 4px;\n  transition: all 0.2s ease-in-out;\n  transform: translate3d(4px, 0, 0);\n}\n\n.walletconnect-modal__mobile__toggle.right__selected .walletconnect-modal__mobile__toggle_selector {\n  transform: translate3d(calc(100% + 12px), 0, 0);\n}\n\n.walletconnect-modal__mobile__toggle a {\n  font-size: 12px;\n  width: 50%;\n  text-align: center;\n  padding: 8px;\n  margin: 0;\n  font-weight: 600;\n  z-index: 1;\n}\n\n.walletconnect-modal__footer {\n  display: flex;\n  justify-content: center;\n  margin-top: 20px;\n}\n\n@media only screen and (max-width: 768px) {\n  .walletconnect-modal__footer {\n    margin-top: 5vw;\n  }\n}\n\n.walletconnect-modal__footer a {\n  cursor: pointer;\n  color: #898d97;\n  font-size: 15px;\n  margin: 0 auto;\n}\n\n@media only screen and (max-width: 320px) {\n  .walletconnect-modal__footer a {\n    font-size: 14px;\n  }\n}\n\n.walletconnect-connect__buttons__wrapper {\n  max-height: 44vh;\n}\n\n.walletconnect-connect__buttons__wrapper__android {\n  margin: 50% 0;\n}\n\n.walletconnect-connect__buttons__wrapper__wrap {\n  display: grid;\n  grid-template-columns: repeat(4, 1fr);\n  margin: 10px 0;\n}\n\n@media only screen and (min-width: 768px) {\n  .walletconnect-connect__buttons__wrapper__wrap {\n    margin-top: 40px;\n  }\n}\n\n.walletconnect-connect__button {\n  background-color: rgb(64, 153, 255);\n  padding: 12px;\n  border-radius: 8px;\n  text-decoration: none;\n  color: rgb(255, 255, 255);\n  font-weight: 500;\n}\n\n.walletconnect-connect__button__icon_anchor {\n  cursor: pointer;\n  display: flex;\n  justify-content: flex-start;\n  align-items: center;\n  margin: 8px;\n  width: 42px;\n  justify-self: center;\n  flex-direction: column;\n  text-decoration: none !important;\n}\n\n@media only screen and (max-width: 320px) {\n  .walletconnect-connect__button__icon_anchor {\n    margin: 4px;\n  }\n}\n\n.walletconnect-connect__button__icon {\n  border-radius: 10px;\n  height: 42px;\n  margin: 0;\n  width: 42px;\n  background-size: cover !important;\n  box-shadow: 0 4px 12px 0 rgba(37, 41, 46, 0.25);\n}\n\n.walletconnect-connect__button__text {\n  color: #424952;\n  font-size: 2.7vw;\n  text-decoration: none !important;\n  padding: 0;\n  margin-top: 1.8vw;\n  font-weight: 600;\n}\n\n@media only screen and (min-width: 768px) {\n  .walletconnect-connect__button__text {\n    font-size: 16px;\n    margin-top: 12px;\n  }\n}\n\n.walletconnect-search__input {\n  border: none;\n  background: #d4d5d9;\n  border-style: none;\n  padding: 8px 16px;\n  outline: none;\n  font-style: normal;\n  font-stretch: normal;\n  font-size: 16px;\n  font-style: normal;\n  font-stretch: normal;\n  line-height: normal;\n  letter-spacing: normal;\n  text-align: left;\n  border-radius: 8px;\n  width: calc(100% - 16px);\n  margin: 0;\n  margin-bottom: 8px;\n}\n', t.head.appendChild(n)
                }();
                var r, o = function() {
                    var t = bi.getDocumentOrThrow(),
                        e = t.createElement("div");
                    return e.setAttribute("id", Si), t.body.appendChild(e), e
                }();
                xi.render(xi.createElement(Li, {
                    text: (r = bi.getNavigatorOrThrow().language.split("-")[0] || "en", qi[r] || qi.en),
                    uri: t,
                    onClose: ji(e),
                    qrcodeModalOptions: n
                }), o)
            }
            var zi = function() {
                    return "undefined" != typeof process && void 0 !== process.versions && void 0 !== process.versions.node
                },
                Fi = {
                    open: function(t, e, n) {
                        console.log(t), zi() ? function(t) {
                            Mi.toString(t, {
                                type: "terminal"
                            }).then(console.log)
                        }(t) : Di(t, e, n)
                    },
                    close: function() {
                        zi() || Ui()
                    }
                };
            let Wi = null;

            function Hi() {
                return new Promise(((t, e) => {
                    if (Wi) return t(Wi); {
                        const n = new Le({
                            bridge: "https://bridge.walletconnect.org",
                            qrcodeModal: Fi
                        });
                        window.conn = n, n.connected ? (Wi = n, t(n)) : n.createSession(), n.on("connect", (r => {
                            r ? e(r) : (Wi = n, t(Wi))
                        })), n.on("disconnect", (t => {
                            t || (Wi = null)
                        }))
                    }
                }))
            }
            const $i = Math.pow(10, 18);

            function Ji(t) {
                return new r(t).mul($i).toNumber()
            }
        }
    }
}));
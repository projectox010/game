var q = Object.defineProperty,
    Q = Object.defineProperties;
var U = Object.getOwnPropertyDescriptors;
var b = Object.getOwnPropertySymbols;
var Y = Object.prototype.hasOwnProperty,
    z = Object.prototype.propertyIsEnumerable;
var x = (a, t, s) => t in a ? q(a, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : a[t] = s,
    N = (a, t) => {
        for (var s in t || (t = {})) Y.call(t, s) && x(a, s, t[s]);
        if (b)
            for (var s of b(t)) z.call(t, s) && x(a, s, t[s]);
        return a
    },
    w = (a, t) => Q(a, U(t));
import {
    o as S,
    u as h,
    e as B,
    f as V,
    r as d,
    c as i,
    g as A,
    h as F,
    i as G,
    a as e,
    k as I,
    l as C,
    T as H,
    j as c,
    C as L,
    I as k,
    b as J,
    m as K,
    t as P,
    q as T,
    p as m,
    v as X
} from "./index.28e31dff.js";
import {
    D as Z
} from "./DepositBonus.c3043053.js";
const ee = S(function() {
        const t = h(),
            s = B(),
            r = V(3e4),
            o = window.localStorage.getItem("CLOSE_LIMIT") || "NO",
            [n, l] = d.exports.useState(o === "YES"),
            [E, y] = d.exports.useState(!1),
            g = d.exports.useRef(0),
            M = i.registerTime + 20 * 60 * 1e3;
        let p = 0,
            u = 0;
        const [O, f] = A(() => ({
            config: F.gentle,
            transform: "translate3d(0px, 0px, 0px)"
        }));
        d.exports.useEffect(() => {
            f.start({
                transform: `translate3d(${p}px, ${u}px, 0px)`
            })
        }, [p, u]);
        const _ = G(({
            lastOffset: [v, $],
            movement: [j, W]
        }) => {
            f.start({
                transform: `translate3d(${v+j+p}px, ${$+W+u}px, 0px)`,
                immediate: !0
            })
        });
        if (!i.isInited || i.rechargeValidNum === 4 || !(i.firstExpiredTime > 0) || E || !r) return null;
        const R = i.bonusItems ? i.bonusItems[0].bonusRatio : 1;
        return e(I.div, {
            className: C(te, n ? "small" : "common"),
            style: O,
            children: e("div", w(N({}, _()), {
                className: "dragpop-area",
                children: e(H, {
                    from: {
                        y: "100%",
                        opacity: 0
                    },
                    enter: {
                        y: "0%",
                        opacity: 1
                    },
                    children: c(I.div, {
                        className: "deposit-main",
                        children: [e(L, {
                            onClick: () => {
                                l(!n), window.localStorage.setItem("CLOSE_LIMIT", "YES")
                            }
                        }), c("div", {
                            className: "main",
                            onMouseDown: () => {
                                g.current = new Date().getTime()
                            },
                            onMouseUp: () => {
                                new Date().getTime() - g.current < 200 && s("/wallet")
                            },
                            children: [e("p", {
                                className: "title",
                                children: t(n ? "page.bcd.title.long" : "page.bcd.title.short")
                            }), e("p", {
                                className: "big-title",
                                children: e(k, {
                                    k: "page.bcd.title.big",
                                    children: c("span", {
                                        children: [Math.floor(R * 100), "%"]
                                    })
                                })
                            }), !n && e("p", {
                                className: "end-time",
                                children: t("page.bcd.end_time")
                            }), e(D, {
                                endTime: M,
                                close: n,
                                changeOver: y
                            }), !n && e(J, {
                                type: "conic",
                                onClick: () => s("/wallet"),
                                children: t("page.bcd.deposit_now")
                            })]
                        })]
                    })
                })
            }))
        })
    }),
    te = "lok4cf0",
    D = function({
        close: t,
        endTime: s,
        changeOver: r
    }) {
        const o = h();
        return e(K, {
            endTime: s,
            onEnd: () => {
                r(!0), i.init(!0)
            },
            children: ({
                minutes: n,
                seconds: l
            }) => c("div", {
                className: C(se, t ? "small" : "big"),
                children: [c("div", {
                    className: "time-area",
                    children: [e("span", {
                        children: o("page.bcd.minute")
                    }), e("p", {
                        children: n > 9 ? n : "0" + n
                    })]
                }), e("div", {
                    className: "time-split",
                    children: ":"
                }), c("div", {
                    className: "time-area",
                    children: [e("span", {
                        children: o("page.bcd.second")
                    }), e("p", {
                        children: l > 9 ? l : "0" + l
                    })]
                })]
            })
        })
    };
P({
    cl1: [T("#231610", .45), T("#000000", .4)]
});
const se = "bjhs3pt";
var le = ee;
const ae = S(function() {
        const t = h(),
            s = B(),
            r = i.firstExpiredTime,
            o = i.bonusItems,
            n = o ? o[0].bonusRatio : 1;
        return r > 0 ? c("div", {
            className: ne,
            children: [e(L, {
                onClick: () => m.close()
            }), e("p", {
                className: "title",
                children: e(k, {
                    k: "wallet.bcd.morepop.title",
                    children: e("span", {
                        children: o.length > 0 ? o[0].rechargeUsd : "60"
                    })
                })
            }), c("p", {
                className: "title-second",
                children: [c("span", {
                    children: [Number(n * 100), "%"]
                }), e("span", {
                    children: t("page.vip.dialog.table.head5")
                })]
            }), e(D, {
                close: !1,
                endTime: i.registerTime + 20 * 60 * 1e3,
                changeOver: () => m.close()
            }), e("p", {
                className: "more",
                onClick: () => {
                    m.close(), X.close(), setTimeout(() => {
                        s("/promotion")
                    }, 200)
                },
                children: t("wallet.bcd.more")
            })]
        }) : e(Z, {})
    }),
    ne = "sz8k9o";

function de() {
    m.push(e(ae, {}))
}
export {
    le as L, de as s
};
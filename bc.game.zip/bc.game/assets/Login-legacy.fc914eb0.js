! function() {
    var e = document.createElement("style");
    e.innerHTML = '.sw44aal{--35p5sb:#fff;--ivxsko:#e9eaf2;--1rzzxnd:#6b7180;background-color:var(--35p5sb);width:29rem}.darken .sw44aal{--35p5sb:#1e2024;--ivxsko:rgba(62,72,79,.3);--1rzzxnd:#31343c}@-webkit-keyframes fadeTopin-sw44aal{0%{opacity:0;top:-3.125rem}80%{opacity:0;top:-3.125rem}to{opacity:1;top:-2.1875rem}}@keyframes fadeTopin-sw44aal{0%{opacity:0;top:-3.125rem}80%{opacity:0;top:-3.125rem}to{opacity:1;top:-2.1875rem}}.sw44aal .box{padding:1.25rem}.sw44aal .box>.ui-input:first-of-type{margin-top:.25rem}.sw44aal hr{margin:0;height:1px;border:none;background-color:var(--ivxsko)}.sw44aal .casino-code{margin-top:1rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;cursor:pointer}.sw44aal .casino-code .icon{width:1rem;height:1rem;-webkit-transform:rotate(90deg);-ms-transform:rotate(90deg);transform:rotate(90deg)}.sw44aal .ui-button{-webkit-flex:1;-ms-flex:1;flex:1}.sw44aal .buttons{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;margin:0 1.25rem}.sw44aal .buttons .regist-btn-wrap{position:relative}.sw44aal .buttons .regist-btn-wrap .ui-button{width:15rem;-webkit-flex:none;-ms-flex:none;flex:none;margin-left:.625rem}.sw44aal .buttons .regist-btn-wrap .regist-bonus{position:absolute;background-color:#581ac4;color:#fff;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;height:1.75rem;border-radius:.875rem;padding:0 .625rem;top:-3.125rem;font-style:italic;left:1.25rem;font-weight:800;opacity:0;-webkit-animation:fadeTopin-sw44aal 1.2s linear both;animation:fadeTopin-sw44aal 1.2s linear both}.sw44aal .buttons .regist-btn-wrap .regist-bonus:after{content:"";display:block;position:absolute;border:.3125rem solid transparent;border-top-color:#581ac4;bottom:-.625rem;left:1.25rem}.sw44aal .buttons .regist-btn-wrap .regist-bonus .icon{fill:#fff;width:.9375rem;height:.9375rem;margin-right:.3125rem;margin-top:-.125rem}.sw44aal .argument-check{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;margin-bottom:1.25rem}.sw44aal .argument-check .ui-checkbox{margin-top:.25rem;margin-right:.375rem}.sw44aal .signin{color:#f5f6f7;background-color:var(--1rzzxnd)}.sw44aal .signin .icon{width:1rem;height:1rem;margin-right:.375rem;opacity:.6;-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1);fill:#f5f6f7}@media screen and (max-width:621px){.sw44aal{width:100%}}.s1x8lvhu{--35p5sb:#fff;--ivxsko:#e9eaf2;--1rzzxnd:#6b7180;background-color:var(--35p5sb)}.darken .s1x8lvhu{--35p5sb:#1e2024;--ivxsko:rgba(62,72,79,.3);--1rzzxnd:#31343c}.s1x8lvhu .box{padding:1.5rem 1.25rem}.s1x8lvhu .box>.ui-input:first-of-type{margin-top:.25rem}.s1x8lvhu hr{height:1px;margin:0;border:none;background-color:var(--ivxsko)}.s1x8lvhu .captcha .verify-img{height:2.875rem;border-radius:.875rem;margin-right:-.875rem}.s1x8lvhu .ui-button{-webkit-flex:1;-ms-flex:1;flex:1}.s1x8lvhu .buttons{padding:1.25rem 2.5rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex}.s1x8lvhu .buttons .ui-button:first-of-type{width:15rem;-webkit-flex:none;-ms-flex:none;flex:none;margin-right:.625rem}.s1x8lvhu .signup{color:#f5f6f7;background-color:var(--1rzzxnd)}.s1x8lvhu .signup .icon{width:1rem;height:1rem;margin-left:.375rem;opacity:.6;fill:#f5f6f7}.s1i8fy8p{--1hr07om:rgba(95,105,117,.6);--13teg8a:#fff;--1sye493:#e9eaf2;padding:1rem 2.5rem 1.25rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.darken .s1i8fy8p{--1hr07om:rgba(153,164,176,.6);--13teg8a:rgba(49,52,60,.5);--1sye493:#2d3137}.s1i8fy8p .box-title{text-align:center;width:100%;line-height:1;margin-bottom:.875rem;color:var(--1hr07om)}.s1i8fy8p .other-group{border-radius:1.75rem;background-color:var(--13teg8a);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}.s1i8fy8p .other-group .title{margin-top:.3125rem}.s1i8fy8p .other-group .line{width:1px;margin:.875rem 0;background-color:var(--1sye493)}.s1i8fy8p .other-group button{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;height:3.5rem;width:3.5rem;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;overflow:hidden;position:relative}.s1i8fy8p .other-group button img{width:2rem;height:2rem}.s1i8fy8p .other-group button iframe{position:absolute;top:0;left:2px;z-index:1;cursor:pointer;opacity:.01;margin-left:-50px}.s1i8fy8p .other-group svg{width:2.25rem;height:2.25rem}.l1oi4fhy{height:1.875rem;margin:1rem 0}.s1fxj4vq{background-color:var(--primary-color)!important}.s1fxj4vq .wrap-box{height:100%;position:relative;z-index:2}.s1fxj4vq .welcome{height:11.875rem;position:absolute;top:3.75rem;left:1.25rem;right:.3125rem;z-index:1;color:#f5f6f7}.s1fxj4vq .welcome .msg1{font-size:1.5rem;font-weight:700;width:14.375rem;line-height:1.2;margin-top:1.25rem}.s1fxj4vq .welcome img{height:13.75rem;position:absolute;right:0;top:-1.875rem}.s1fxj4vq.dialog-body{padding:0}.s1fxj4vq .dialog-back .icon,.s1fxj4vq .dialog-close .icon{fill:#fff}.s1fxj4vq .dialog-head{background-color:transparent;box-shadow:none}.s1fxj4vq #login{padding-top:0}.c1rg0pmn{--1y8z3v5:#f2f3f7;position:absolute;left:0;right:0;bottom:0;top:16.25rem;height:auto;border-top-left-radius:1.25rem;border-top-right-radius:1.25rem;background-color:var(--1y8z3v5)}.darken .c1rg0pmn{--1y8z3v5:#17181b}.wg23lqg{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column}.wg23lqg img{width:9.375rem;height:9.375rem}.wg23lqg .ui-button{width:80%;margin:1.25rem auto 8.125rem}\n', document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js", "./recaptcha-legacy.8aca4e99.js", "./CheckPassword-legacy.e05f723f.js", "./metamaskSupport-legacy.8f064903.js"], (function(e, t) {
        "use strict";
        var i, a, o, n, l, r, s, c, d, p, g, f, m, h, u, b, w, x, y, k, v, z, C, M, j, N, _, S, E, q, T, L, A, I, B, D, P, U, R, $, F, H;
        return {
            setters: [function(e) {
                i = e.o, a = e.u, o = e.r, n = e.e, l = e.cz, r = e.d, s = e.j, c = e.a, d = e.am, p = e.bf, g = e.I, f = e.b, m = e.A, h = e.t, u = e.q, b = e.G, w = e.p, x = e.v, y = e.cA, k = e.F, v = e.al, z = e.ar, C = e.cB, M = e.$, j = e.bn, N = e.aG, _ = e.P, S = e.s, E = e.at, q = e.a5, T = e.cC, L = e.ca, A = e.cD, I = e.D, B = e.ak, D = e.T, P = e.S, U = e.a3, R = e.br
            }, function(e) {
                $ = e.r
            }, function(e) {
                F = e.C
            }, function(e) {
                H = e.s
            }],
            execute: function() {
                const K = e => {
                        const [t, i] = o.exports.useState(!1), n = a();
                        return o.exports.useEffect((() => {
                            e.onSetSize(t ? 864 : 800)
                        }), [t]), t ? c(d, {
                            label: `${n("user.casino_code")} (${n("common.optional")})`,
                            autoComplete: "off",
                            tabIndex: 3,
                            value: e.code,
                            onChange: e.onChange,
                            placeholder: n("user.casino_code"),
                            onKeyDown: t => {
                                13 === t.keyCode && e.handleSubmit()
                            }
                        }) : s("div", {
                            className: "casino-code hover",
                            onClick: () => i(!0),
                            children: [`${n("user.casino_code")} (${n("common.optional")})`, c(m, {
                                name: "Arrow"
                            })]
                        })
                    },
                    O = i((e => {
                        const t = a(),
                            i = o.exports.useRef(null),
                            h = n(),
                            u = e.data;
                        o.exports.useEffect((() => {
                            l("retargeting")
                        }), []);
                        const [y, k] = o.exports.useState(r.currentInvitationCode || ""), [v, z] = o.exports.useState(!0), C = function() {
                            const e = i.current;
                            e && e.click()
                        };
                        return s("div", {
                            className: G,
                            id: "regist",
                            style: e.style,
                            children: [s("div", {
                                className: "box",
                                children: [c(d, {
                                    label: t("user.email_title"),
                                    tabIndex: 1,
                                    autoComplete: "off",
                                    value: u.email,
                                    onChange: e => u.email = e,
                                    placeholder: t("page.forget.email")
                                }), c(d, {
                                    label: t("page.settings.password"),
                                    tabIndex: 2,
                                    type: "password",
                                    autoComplete: "off",
                                    value: u.password,
                                    onChange: e => u.password = e,
                                    placeholder: t("page.settings.password"),
                                    onKeyDown: e => {
                                        13 === e.keyCode && C()
                                    },
                                    children: c(F, {
                                        str: u.password
                                    })
                                }), c(K, {
                                    code: y,
                                    onChange: k,
                                    handleSubmit: C,
                                    onSetSize: e.onSetSize
                                })]
                            }), c("hr", {}), s("div", {
                                className: "box",
                                children: [s("div", {
                                    className: "argument-check",
                                    onClick: () => z(!v),
                                    children: [c(p, {
                                        type: "checkbox",
                                        value: v
                                    }), c("div", {
                                        className: "label",
                                        children: c(g, {
                                            k: "page.login.check",
                                            children: c("a", {
                                                className: "argument",
                                                onClick: () => {
                                                    x.close(), h("/help/terms-service")
                                                },
                                                children: t("title.help_agreement").toLocaleLowerCase()
                                            })
                                        })
                                    })]
                                }), s("div", {
                                    className: "buttons",
                                    children: [s(f, {
                                        className: "signin",
                                        size: "big",
                                        type: "gray",
                                        onClick: () => h("/login", {
                                            replace: !0
                                        }),
                                        children: [c(m, {
                                            name: "Arrow"
                                        }), c("span", {
                                            children: t("title.login")
                                        })]
                                    }), s("div", {
                                        className: "regist-btn-wrap",
                                        children: [s("div", {
                                            className: "regist-bonus",
                                            children: [c(m, {
                                                name: "Reward"
                                            }), t("common.registbonus").toLocaleUpperCase()]
                                        }), c(f, {
                                            ref: i,
                                            type: "conic",
                                            size: "big",
                                            disabled: !v,
                                            onClick: async function() {
                                                if (!v) return b(new Error(t("page.login.agreement_tips"))), !1;
                                                if (!u.password || u.password.length < 6) return b(new Error(t("page.settings.reset_minlen"))), !1;
                                                const i = await $("login");
                                                try {
                                                    await r.handleRegist(u.email, u.password, y, i);
                                                    e.onEnd && e.onEnd()
                                                } catch (a) {
                                                    5801 === a.code ? await w.confirm("Looks like you've already registered, sign in now?") && (e.data.autoLogin = !0, h("/login", {
                                                        replace: !0
                                                    })) : a && b(a)
                                                }
                                            },
                                            children: t("title.regist")
                                        })]
                                    })]
                                })]
                            })]
                        })
                    }));
                h({
                    cl1: ["#1e2024", "#fff"],
                    cl2: [u("#3e484f", .3), "#e9eaf2"],
                    cl3: ["#31343c", "#6b7180"]
                });
                const G = "sw44aal";

                function V(e) {
                    return M.post("/user/google/2-step-auth/code-2verify/", {
                        code: e
                    })
                }
                const X = i((({
                    data: e,
                    onEnd: t
                }) => {
                    const i = a(),
                        l = n(),
                        [p, g] = o.exports.useState(!1),
                        [h, u] = o.exports.useState(!1),
                        [w, x] = o.exports.useState(""),
                        [M, j] = o.exports.useState(Date.now()),
                        N = async function() {
                            if (p || !e.email || !e.password) return !1;
                            g(!0);
                            try {
                                if ((await r.handleLogin(e.email, e.password, w)).google2StepAuth) {
                                    let e = !0;
                                    for (; e;) {
                                        const t = await C();
                                        if (!t) throw new Error("");
                                        try {
                                            await V(t), e = !1
                                        } catch (i) {
                                            if (i && 6005 === i.code) throw new Error("");
                                            b(i)
                                        }
                                    }
                                }
                                g(!1), await r.init(), t()
                            } catch (i) {
                                if (g(!1), !i) return;
                                j(Date.now()), x(""), b(i), 6004 === i.code && u(!0)
                            }
                        };
                    return o.exports.useEffect((() => {
                        e.autoLogin && e.email && e.password && (N(), e.autoLogin = !1)
                    }), []), s("div", {
                        className: J,
                        id: "login",
                        children: [s("div", {
                            className: "box",
                            children: [c(d, {
                                label: i("user.email_title"),
                                type: "text",
                                tabIndex: 1,
                                autoComplete: "off",
                                value: e.email,
                                onChange: t => e.email = t,
                                placeholder: i("page.settings.email")
                            }), c(y, {
                                label: s(k, {
                                    children: [c("div", {
                                        style: {
                                            flex: 1
                                        },
                                        children: i("page.settings.password")
                                    }), c(v, {
                                        className: "forget",
                                        to: "/forget",
                                        children: i("page.settings.forget_password")
                                    })]
                                }),
                                tabIndex: 2,
                                value: e.password,
                                onChange: t => e.password = t,
                                placeholder: i("page.settings.password"),
                                onKeyDown: e => {
                                    13 === e.keyCode && N()
                                }
                            }), h && c(d, {
                                label: i("page.login.captcha"),
                                tabIndex: 3,
                                className: "captcha",
                                placeholder: i("page.login.captcha"),
                                value: w,
                                onChange: x,
                                focus: !0,
                                onKeyDown: e => {
                                    13 === e.keyCode && N()
                                },
                                type: "text",
                                children: c("img", {
                                    className: "verify-img",
                                    src: (e => `${z.getApiURL("/user/verify/image/")}?t=${e}`)(M),
                                    onClick: () => j(Date.now())
                                })
                            })]
                        }), c("hr", {}), s("div", {
                            className: "buttons",
                            children: [c(f, {
                                loading: p,
                                size: "big",
                                onClick: N,
                                type: "conic2",
                                children: i("title.login")
                            }), s(f, {
                                className: "signup",
                                size: "big",
                                type: "gray",
                                onClick: () => l("/login/regist", {
                                    replace: !0
                                }),
                                children: [c("span", {
                                    children: i("title.regist")
                                }), c(m, {
                                    name: "Arrow"
                                })]
                            })]
                        })]
                    })
                }));
                h({
                    cl1: ["#1e2024", "#fff"],
                    cl2: [u("#3e484f", .3), "#e9eaf2"],
                    cl3: ["#31343c", "#6b7180"]
                });
                const J = "s1x8lvhu";
                let Q = j.isDev ? "2247726542166448" : "363146184450773";
                const W = async () => {
                        if (window.FB) return window.FB;
                        let e = await N("https://connect.facebook.net/en_US/sdk.js", "FB");
                        return e.init({
                            appId: Q,
                            cookie: !0,
                            xfbml: !0,
                            version: "v2.8"
                        }), e
                    },
                    Y = async () => {
                        let e = await N("https://apis.google.com/js/api:client.js", "gapi");
                        return await new Promise((t => {
                            e.load("auth2", (() => {
                                t(e.auth2.init({
                                    client_id: "36897522347-eotiq46nvilc5p10653s4mtbs8405sbn.apps.googleusercontent.com",
                                    cookiepolicy: "single_host_origin",
                                    scope: "profile email"
                                }))
                            }))
                        }))
                    },
                    Z = i((() => {
                        const e = _(),
                            t = o.exports.useRef(null),
                            i = o.exports.useRef(null),
                            a = e => {
                                let t = [];
                                for (let i in e) t.push(i + "=" + e[i]);
                                r.handleLoginOpen({
                                    fullName: e.first_name,
                                    idToken: t.join(","),
                                    openUserId: e.id,
                                    userType: "telegram"
                                }).then(x.close).catch(b)
                            };
                        return o.exports.useEffect((() => {
                            !async function() {
                                try {
                                    const i = await Y();
                                    if (!e()) return;
                                    i.attachClickHandler(t.current, {}, (e => {
                                        const t = i.currentUser.get().getBasicProfile(),
                                            {
                                                id_token: a
                                            } = e.getAuthResponse();
                                        r.handleLoginOpen({
                                            fullName: t.getName(),
                                            idToken: a,
                                            openUserId: t.getId(),
                                            userType: "google",
                                            picture: t.Paa
                                        }).then(x.close).catch(b)
                                    }), (e => {
                                        e instanceof Error && b(new Error(String(e)))
                                    }))
                                } catch (i) {}
                            }(), window.onTelegramAuth = a, (() => {
                                var e;
                                const t = document.createElement("script");
                                t.async = !0, t.src = "https://telegram.org/js/telegram-widget.js?5";
                                let a = "BC_GAME_Bot";
                                /8848/.test(location.href) && (a = "Bcg_Login_Bot"), t.setAttribute("data-telegram-login", a), t.setAttribute("data-size", "large"), t.setAttribute("data-onauth", "onTelegramAuth(user)"), t.setAttribute("data-request-access", "write"), null === (e = i.current) || void 0 === e || e.appendChild(t)
                            })(), W()
                        }), []), s("div", {
                            className: "other-group",
                            children: [c("button", {
                                id: "gg_login",
                                type: "button",
                                title: "google",
                                ref: t,
                                children: ae
                            }), c("button", {
                                id: "fb_login",
                                type: "button",
                                title: "facebook",
                                onClick: async function() {
                                    const e = await W();
                                    e.login((t => {
                                        if ("connected" === t.status) {
                                            const {
                                                accessToken: i,
                                                userID: a
                                            } = t.authResponse;
                                            e.api("/me", (function(e) {
                                                r.handleLoginOpen({
                                                    fullName: e.name,
                                                    idToken: i,
                                                    openUserId: a,
                                                    userType: "facebook"
                                                }).then(x.close).catch(b)
                                            }))
                                        }
                                    }))
                                },
                                children: oe
                            }), c("button", {
                                id: "tg_login",
                                type: "button",
                                title: "telegram",
                                ref: i,
                                children: ne
                            }), c("div", {
                                className: "line"
                            }), !S.isMobile && c("button", {
                                type: "button",
                                onClick: te,
                                children: le
                            }), c("button", {
                                type: "button",
                                onClick: ee,
                                children: ie
                            })]
                        })
                    })),
                    ee = async () => {
                        try {
                            let [e, i] = await Promise.all([r.getSignMsg(), E((() => t.import("./walletConnect-legacy.e30d1e08.js")), void 0)]), {
                                signature: a,
                                publicAddress: o
                            } = await i.signPersonalMessage(e);
                            await r.handleLoginSign({
                                signStr: a,
                                walletName: "metamask",
                                walletUnique: o
                            }), x.back()
                        } catch (e) {
                            b(e)
                        }
                    },
                    te = async function() {
                        try {
                            let e = await r.getSignMsg(),
                                {
                                    signature: t,
                                    publicAddress: i
                                } = await H(e);
                            await r.handleLoginSign({
                                signStr: t,
                                walletName: "metamask",
                                walletUnique: i
                            }), r.init(), x.back()
                        } catch (e) {
                            b(new Error(e.message.split("\n")[0]))
                        }
                    },
                    ie = s("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 32 32",
                        children: [c("path", {
                            fill: "#3d96fc",
                            d: "M32 16a16 16 0 11-32 0 16 16 0 0132 0z"
                        }), c("path", {
                            fill: "#fff",
                            d: "M16 14.4l5 5.2 5.1-5.1 2.2 2.1L21 24l-5-5.1-5.2 5.1-7.2-7.3 2.1-2.1 5.1 5 5.1-5zm7.9-2.4l.1.1-2.3 2.4c-4-3.8-7.5-3.9-11.5 0H10l-2.3-2.4c5.2-5 10.8-5 16-.1z"
                        })]
                    }),
                    ae = s("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 32 32",
                        children: [c("path", {
                            fill: "#fa455e",
                            d: "M16 0a16 16 0 110 32 16 16 0 010-32z"
                        }), c("path", {
                            fill: "#fff",
                            d: "M19.5 12.3c-.5-.5-1.1-.9-1.8-1a4.8 4.8 0 00-2-.2c-.9 0-1.7.4-2.3 1a5 5 0 00-2 4 5 5 0 004 4.8 5 5 0 001.6 0c.8 0 1.6-.3 2.2-.7.5-.4 1-.9 1.2-1.4l.3-.9v-.2h-4.4v-3.2h7.5l.2.1.1 1v1.2c0 .5 0 1-.2 1.6v-.1a7.4 7.4 0 01-1.4 3 7 7 0 01-3 2.4h-.1c-.6.2-1.2.4-1.9.4a8.8 8.8 0 01-1.9 0c-.8 0-1.5-.1-2.2-.4-.9-.4-1.6-.8-2.3-1.4-1-.8-1.9-2-2.4-3.2l-.5-1.9v-1.4-.1c0-.9.2-1.7.4-2.5.3-.7.7-1.4 1.2-2 1-1.4 2.5-2.5 4.3-3l1.5-.3a11.1 11.1 0 011.3 0 7.7 7.7 0 014.8 2l-.1.3-2 2h-.1z"
                        })]
                    }),
                    oe = s("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 32 32",
                        children: [c("path", {
                            fill: "#fff",
                            d: "M31.7 16.3a15.7 15.7 0 11-31.4 0 15.7 15.7 0 0131.4 0z"
                        }), c("path", {
                            fill: "#227aee",
                            d: "M0 16a16 16 0 0013.4 15.8V20.6h-4v-4.7h4v-4.4c0-2.7 2.3-5.7 6.5-5.6 1.5 0 3.4.5 3.4.5v4s-1.9-.2-3 0c-1.6.2-2 1.4-2 2v3.3h4.9l-1 4.9h-3.8v11.2A16 16 0 100 16z"
                        })]
                    }),
                    ne = s("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 32 32",
                        children: [c("path", {
                            fill: "#4bb2dd",
                            d: "M16 0a16 16 0 110 32 16 16 0 010-32z"
                        }), c("path", {
                            fill: "#fff",
                            d: "M15 20.6l3.5 2.6.9.5.3.1c.4 0 .7-.2.7-.6l.3-1.2 1.2-5.4 1.3-6.4V10a1 1 0 00-.3-.8.8.8 0 00-.9 0l-5.6 2.1-8.8 3.4-1.5.7a.5.5 0 00-.4.5c0 .3.3.4.5.4l4 1.2a.5.5 0 00.3 0l8-5 1.1-.7c.2-.1.4-.3.6 0l-.2.2-1.4 1.3q-3 2.6-5.8 5.3l-.2.3-.3 3.1v.9c.4 0 .7-.2 1-.5l1.8-1.8z"
                        })]
                    }),
                    le = s("svg", {
                        xmlns: "http://www.w3.org/2000/svg",
                        viewBox: "0 0 32 32",
                        children: [c("path", {
                            fill: "#f3f8fa",
                            d: "M16 0a16 16 0 110 32 16 16 0 010-32z"
                        }), c("path", {
                            fill: "#f6851b",
                            d: "M13.4 10.5l5.5.1 4.6 6.2 1.1 3.7-1.2 3.7-3.8-.8-2 2.2H15l-2.6-2-4 1-1.2-4 1.2-3.9z"
                        }), c("path", {
                            fill: "#e2761b",
                            d: "M13.5 10.5l-5.7-2-1 2.8.6 2.7-.3.4.5.5-.3.3.4.5-.2.3.8.9 3.6-1.1 2.8-2.2z"
                        }), c("path", {
                            fill: "#763d16",
                            d: "M7.8 8.5l-1 2.8.6 2.7-.3.4.5.5-.3.3.4.5-.2.3.8.9 3.6-1.1 2.8-2.2z"
                        }), c("path", {
                            fill: "#e4761b",
                            d: "M17.3 13.6l-.1 4.2v4.7l.4-2.6 2-.7 1.4-1.6-1.3-2z"
                        }), c("path", {
                            fill: "#e4751f",
                            d: "M19.5 19V21l1.6-3.3zM17.2 17.8v4.7l.5-3.5z"
                        }), c("path", {
                            fill: "#cd6116",
                            d: "M17.2 17.8l3.9-.2-1.6 1.6-2 .7z"
                        }), c("path", {
                            fill: "#233447",
                            d: "M17.6 19.9l.5-1.3 1.4.6z"
                        }), c("path", {
                            fill: "#e4761b",
                            d: "M19.4 20.9l5.2-.4-1.2 3.8-3.8-.9-1.9-.6z"
                        }), c("path", {
                            fill: "#cd6116",
                            d: "M19.4 20.9l.2 2.5 1.9-2.7z"
                        }), c("path", {
                            fill: "#e2761b",
                            d: "M18.2 10.6l6-2 .8 2.7-.7 2.8.4.3-.5.4.3.4-.4.5.2.2-.7 1-3.8-1.2-2.5-2.1z"
                        }), c("path", {
                            fill: "#763d16",
                            d: "M24.3 8.7l.7 2.6-.7 2.8.4.3-.5.4.3.4-.4.5.2.2-.7 1-3.8-1.2-2.5-2.1z"
                        }), c("path", {
                            fill: "#e4761b",
                            d: "M14.8 13.6v4.2l.2 4.6-.6-2.5-2-.7-1.4-1.6 1.3-2z"
                        }), c("path", {
                            fill: "#e4751f",
                            d: "M12.5 19l.1 1.9-1.6-3.3z"
                        }), c("path", {
                            fill: "#cd6116",
                            d: "M14.8 17.8l-3.8-.2 1.5 1.6 2 .7z"
                        }), c("path", {
                            fill: "#233447",
                            d: "M14.4 19.9l-.5-1.3-1.4.6z"
                        }), c("path", {
                            fill: "#e4761b",
                            d: "M12.6 20.9l-5.5-.2 1.2 3.9 4.1-1.2 1.9-.6z"
                        }), c("path", {
                            fill: "#cd6116",
                            d: "M12.6 20.9l-.2 2.5-1.9-2.6z"
                        }), c("path", {
                            fill: "#d7c1b3",
                            d: "M12.3 23.5l2.5-.8h2.8l2 .7-2 1.7h-3.1z"
                        }), c("path", {
                            fill: "#c1ae9f",
                            d: "M12.2 23.5l2.5 1.2v-.4h3v.4l2-1.3-2 2.2h-3z"
                        }), c("path", {
                            fill: "#233447",
                            d: "M15.2 22.5l2-.1.4.3.1 1.6h-3l.1-1.6z"
                        })]
                    });
                const re = q.memo((() => {
                    const e = a();
                    return s("div", {
                        className: se,
                        id: "other-login",
                        children: [s("div", {
                            className: "box-title",
                            children: [" ", e("page.user.other_login"), " "]
                        }), c(Z, {})]
                    })
                }));
                h({
                    cl1: [u("#99a4b0", .6), u("#5f6975", .6)],
                    cl2: [u("#31343c", .5), "#fff"],
                    cl3: ["#2d3137", "#e9eaf2"]
                });
                const se = "s1i8fy8p";
                const ce = {
                    logo: T.logo2,
                    ccpay: "/assets/ccpay.4a5b4ab6.png",
                    login_coco: L.login
                };
                const de = i((e => {
                        const {
                            path: t
                        } = e, i = a(), n = A((() => ({
                            email: "",
                            password: "",
                            autoLogin: !1,
                            height: 720
                        }))), l = o.exports.useCallback((e => {
                            n.height = e
                        }), []);
                        o.exports.useEffect((() => {
                            l("regist" == t ? 800 : 710)
                        }), [t]);
                        const r = o.exports.useMemo((() => "regist" === t ? c(O, {
                            data: n,
                            onSetSize: l,
                            onEnd: e.onEnd
                        }) : c(X, {
                            onEnd: e.onEnd,
                            data: n
                        })), [t]);
                        return c(I, {
                            className: fe,
                            nostyle: !0,
                            size: [464, n.height],
                            children: s(k, {
                                children: [c(B, {
                                    children: c("img", {
                                        className: ge,
                                        src: ce.logo
                                    })
                                }), s("div", {
                                    className: "welcome",
                                    children: [c("div", {
                                        className: "msg1",
                                        children: i("user.login_welcome")
                                    }), c("img", {
                                        src: ce.login_coco
                                    })]
                                }), c(D, {
                                    from: pe.from,
                                    enter: pe.to,
                                    children: s(P, {
                                        className: me,
                                        hideBar: !0,
                                        children: [r, c(re, {})]
                                    }, t)
                                })]
                            })
                        })
                    })),
                    pe = {
                        from: {
                            y: "100%"
                        },
                        to: {
                            y: "0%"
                        }
                    },
                    ge = "l1oi4fhy",
                    fe = "s1fxj4vq",
                    me = "c1rg0pmn";
                const he = i((e => {
                        const {
                            source: t
                        } = e, i = a(), [n, l] = o.exports.useState(!0), [d, p] = o.exports.useState({
                            sys_id: "",
                            access_token: "",
                            expire_at: ""
                        }), [g, m] = o.exports.useState({
                            nickname: "",
                            avatar: ""
                        }), h = {
                            resolve: () => {},
                            reject: () => {}
                        }, u = new Promise(((e, t) => {
                            h.resolve = e, h.reject = t
                        }));
                        o.exports.useEffect((() => {
                            "CCTIP" !== t && w()
                        }), []);
                        const w = async () => {
                                if (l(!0), !(await r.getPlatform()).find((e => e.openName === t))) return r.channel = "";
                                l(!1)
                            },
                            y = async () => {
                                try {
                                    await r.handleLoginOpen({
                                        openUserId: d.sys_id,
                                        fullName: g.nickname,
                                        email: "",
                                        userType: "CCTIP",
                                        idToken: d.access_token,
                                        picture: g.avatar
                                    }), x.close()
                                } catch (e) {
                                    b(e)
                                }
                            };
                        return c(I, {
                            title: i("title.login"),
                            children: s("div", {
                                className: `${ue} login__oauth`,
                                children: [!n && h.resolve(), c(U, {
                                    pms: u,
                                    children: () => s(k, {
                                        children: [c("img", {
                                            src: ce.ccpay
                                        }), c(f, {
                                            className: "button",
                                            type: "conic",
                                            onClick: y,
                                            children: i("page.login.auth_login")
                                        })]
                                    })
                                })]
                            })
                        })
                    })),
                    ue = "wg23lqg";
                e("default", i((({
                    path: e
                }) => {
                    const t = n(),
                        i = function() {
                            const [e] = R();
                            return o.exports.useMemo((() => e.get("redirect")), [])
                        }(),
                        a = () => {
                            setTimeout((() => {
                                S.settings.lastEmail = r.email
                            }), 3e3), i && (/http(s?)/.test(i) ? location.href = decodeURIComponent(i) : t(i, {
                                replace: !0
                            })), x.back()
                        };
                    return r.channel ? c(he, {
                        source: r.channel
                    }) : c(de, {
                        path: e,
                        onEnd: a
                    })
                })))
            }
        }
    }))
}();
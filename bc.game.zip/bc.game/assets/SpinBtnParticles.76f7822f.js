import {
    a5 as a,
    cX as i,
    a as e
} from "./index.28e31dff.js";
import {
    P as s,
    a as n
} from "./usePixiGsap.bf451f35.js";
var p = a.memo(function({
    color: t,
    className: r
}) {
    return i.bright_emitter.color = {
        start: t,
        end: t
    }, e("div", {
        className: r,
        children: e(s, {
            width: 90,
            height: 90,
            children: e(n, {
                textures: i.bright,
                config: i.bright_emitter
            }, t)
        })
    })
});
export {
    p as
    default
};
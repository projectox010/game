var k = Object.defineProperty;
var f = Object.getOwnPropertySymbols;
var R = Object.prototype.hasOwnProperty,
    x = Object.prototype.propertyIsEnumerable;
var v = (e, t, s) => t in e ? k(e, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: s
    }) : e[t] = s,
    B = (e, t) => {
        for (var s in t || (t = {})) R.call(t, s) && v(e, s, t[s]);
        if (f)
            for (var s of f(t)) x.call(t, s) && v(e, s, t[s]);
        return e
    };
import {
    b9 as O,
    N as T,
    a as n,
    fg as N,
    r,
    j as b,
    aO as l,
    aH as h,
    d as A,
    n as E,
    $ as U,
    G as d
} from "./index.28e31dff.js";
import {
    r as F
} from "./recaptcha.94966f3c.js";
var I = "/assets/topsplit-a.2d684169.png",
    P = "/assets/waterpipe-a.78a7d987.png",
    D = "/assets/waterpipe-b.fd774635.png",
    J = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAkCAMAAADW3miqAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAACoUExURUdwTPW0CPm9B/a2B//MBv7JBvm9CfOyBvvEDP/MBv/NB/CpBvCoB/CpBv/LBv/NBv/FT/CoB/i8Bu+oBvCsB++oB//OB//OB//NB/+9C//MM++oBv+qK/+zBv/MBv/////LBu+oBv7GBv+2B//ABv+5Bv/KBve7BvrCBv++K//kpv/Vdf/qu//otf+9Bv/FQP/13v/ah/+4F//flP/x0v/KU//DO//564N2FJwAAAAddFJOUwA7Ikbd7zP+FPeU6JWjwqUDYeb32L5sUIL4BXQGxzxp6QAAAcJJREFUOMt9VIlygyAQxXhEY0zNNEenrRyixkRjzrb//2dFFgwkTd8wjgOPt28XFoRu+HSThV/nOPK9ifuO/sIoGdcUV1iAUoz9l9EDJZyOa2wjmoQ2x4k3FD/AC0zO/HWD/0K0Njisxk8wsJybDs27kvOyywctFTGMx3qq4JkC1zQP3E+ZmqjKzECnMnmT9WFKqJIyfNuPHiWwol4qUUIUdHZkKwZoweaJOItXJVRAlD1pruQA/7DbQ8hlkFoF89sjETiCFIftwWAbhM4/5Nr+ELIzpd7QkskzxeCoIeQrOxDSZoarF7RgoJkp2+TStD0TEpRLMxQz01JLJPZnk+QhlVylcyO7k/hcM8O5dxfuIiOJDLdWuCWjhvFvodQIY+RsGU+sEvTp9bjYJZjbxRSu9kfSKEsQxEGhPt9Okw4t+Yb/Qi74KRqqCZcgO5z6YV4DccDD4eE8s8FhcyRba6kvXc5NTlkNN0Ug0K5w1d04hZrzVfN9sKERcnnLeVlUuhFc3S5Tq6Wo2aar20uRPGu8ldnCRkQD/tp+DNzFOL/nPL4r6Ty2aTMHpY8PVOpM402dC9vUn61C9BTpKHCCf9b/wS/bE3V5CjyCfQAAAABJRU5ErkJggg==",
    L = "/assets/activity_lighting.30aa378d.png",
    Q = "/assets/activity_waterpipe.521dc8c1.png",
    z = "/assets/leftspider.b78fd14c.png",
    j = "/assets/topsplit-b.35519dc4.png",
    K = "/assets/coomary.e14e3a40.png",
    M = "/assets/activity_coomary.7bfaadb5.png";
const p = {
    leftspider: z,
    topsplit_b: j,
    botcoomary: K,
    activity_coomary: M
};
const _ = {
        img_leftspider: p.leftspider,
        img_topsplit_a: I,
        img_topsplit_b: p.topsplit_b,
        img_botcoomary: p.botcoomary,
        img_botwaterpipe_b: D,
        img_botwaterpipe_a: P,
        img_activity_bitcoin: J,
        img_activity_coomary: p.activity_coomary,
        img_activity_lighting: L,
        img_activity_waterpipe: Q
    },
    C = O(async () => (await Promise.all(Object.values(_).map(e => N(e))), _));

function V(e) {
    let t = !1;
    return async s => {
        if (!t) {
            t = !0;
            try {
                await e(s), t = !1
            } catch (o) {
                throw t = !1, o
            }
        }
    }
}
C();

function u({
    onClose: e,
    currencyName: t,
    dataSign: s
}, o) {
    const [a, i] = r.exports.useState(!1), [c] = r.exports.useState(() => l.timeline({
        onReverseComplete: e
    }));
    r.exports.useEffect(o, []), r.exports.useEffect(() => {
        c.play(), setTimeout(() => {
            c.reverse()
        }, 6e4)
    }, []), r.exports.useEffect(() => {
        a && h(1300).then(() => i(!1))
    }, [a]);
    const g = V(async () => {
        if (!A.login) return E("/login");
        try {
            const m = await F("social"),
                w = await U.post("/game/support/bonus/crocodile/", {
                    currencyName: t,
                    dataSign: s,
                    token: m
                });
            c.reverse(), d(w)
        } catch (m) {
            A.login && c.reverse(), d(m)
        }
    });
    return {
        tl: c,
        active: a,
        onClick: () => {
            c.reversed() || (i(!0), h(1300).then(() => g()))
        }
    }
}
const W = e => {
        const t = r.exports.useRef(null),
            s = r.exports.useRef(null),
            o = r.exports.useRef(null),
            {
                tl: a,
                active: i,
                onClick: c
            } = u(e, () => (a.to(o.current, {
                duration: .5,
                height: 246
            }), a.to([t.current, s.current], {
                duration: 1.5,
                top: 0,
                ease: "Power1.easeIn"
            }), a.pause(), () => l.killTweensOf(a)));
        return b("div", {
            ref: o,
            className: `${Z} ${i?"active":""}`,
            onClick: c,
            children: [n("img", {
                className: "img_line",
                ref: t,
                src: e.imgs.img_topsplit_a
            }), n("img", {
                className: "img_coomary",
                ref: s,
                src: e.imgs.img_topsplit_b
            })]
        })
    },
    q = e => {
        const t = r.exports.useRef(null),
            s = r.exports.useRef(null),
            o = r.exports.useRef(null),
            a = r.exports.useRef(null),
            {
                tl: i,
                active: c,
                onClick: g
            } = u(e, () => (i.set(t.current, {
                height: 270
            }), i.to([o.current, a.current], {
                duration: 1,
                bottom: 0
            }), i.to(s.current, {
                duration: 1,
                bottom: 170
            }), i.pause(), () => l.killTweensOf(i)));
        return b("div", {
            ref: t,
            className: `${H} ${c?"active":""}`,
            onClick: g,
            children: [n("img", {
                className: "img_waterpipe",
                src: e.imgs.img_botwaterpipe_b,
                ref: o
            }), n("img", {
                className: "img_coomary",
                src: e.imgs.img_botcoomary,
                ref: s
            }), n("img", {
                className: "img_waterpipe",
                src: e.imgs.img_botwaterpipe_a,
                ref: a
            })]
        })
    },
    S = e => {
        const t = r.exports.useRef(null),
            s = r.exports.useRef(null),
            {
                tl: o,
                active: a,
                onClick: i
            } = u(e, () => (o.to(t.current, {
                duration: .2,
                height: 271
            }), o.to(s.current, {
                duration: 1.5,
                bottom: 143,
                ease: "easeOutBack"
            }), o.pause(), () => l.killTweensOf(o)));
        return n("div", {
            ref: t,
            className: `${Y} ${a?"active":""}`,
            onClick: i,
            children: n("img", {
                src: e.imgs.img_leftspider,
                ref: s
            })
        })
    },
    G = [W, q, S],
    y = [0, 1, 2],
    st = e => {
        const {
            data: t
        } = T(C);
        if (!t) return null;
        const s = Math.floor(Math.random() * y.length),
            o = G[y[s]];
        return n(o, B({
            imgs: t
        }, e))
    },
    Z = "rkzc85v",
    H = "lts2hnh",
    Y = "rmjf8ny";
export {
    st as
    default
};
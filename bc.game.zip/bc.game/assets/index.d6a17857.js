var S = Object.defineProperty,
    L = Object.defineProperties;
var _ = Object.getOwnPropertyDescriptors;
var f = Object.getOwnPropertySymbols;
var T = Object.prototype.hasOwnProperty,
    G = Object.prototype.propertyIsEnumerable;
var b = (t, a, r) => a in t ? S(t, a, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: r
    }) : t[a] = r,
    g = (t, a) => {
        for (var r in a || (a = {})) T.call(a, r) && b(t, r, a[r]);
        if (f)
            for (var r of f(a)) G.call(a, r) && b(t, r, a[r]);
        return t
    },
    v = (t, a) => L(t, _(a));
import {
    o as A,
    t as x,
    q as o,
    du as u,
    r as c,
    $ as D,
    a as e,
    a3 as H,
    j as s,
    F as j,
    ah as z,
    a4 as C,
    u as p,
    de as m,
    a5 as P,
    dD as V,
    eO as $,
    dJ as O,
    ba as W,
    bb as F,
    bc as M,
    s as y,
    df as U,
    A as h,
    am as w,
    b as N,
    dx as q
} from "./index.28e31dff.js";
import {
    S as B
} from "./SlotsILayout.a8936350.js";

function k(t) {
    return D.post("/roulette/game/history/", t)
}

function E(t) {
    return `https://bcgame-project.github.io/verify/roulette.html?hash=${t.hash}`
}

function J() {
    const t = u(),
        [a, r] = c.exports.useState({
            page: 1,
            pageSize: t.historyPageSize
        }),
        n = c.exports.useMemo(() => k(a), [a.page]);
    return e("div", {
        className: Z,
        children: e(H, {
            pms: n,
            children: i => i.list.length ? s(j, {
                children: [e(Q, {
                    list: i.list,
                    params: a
                }), e(z, {
                    page: i.page,
                    total: i.total,
                    limit: i.pageSize,
                    onChange: l => r(v(g({}, a), {
                        page: l
                    }))
                })]
            }) : e(C, {})
        })
    })
}
const Y = [32, 19, 21, 25, 34, 27, 36, 30, 23, 5, 16, 1, 14, 9, 18, 7, 12, 3];

function K(t) {
    let a = "ball";
    return t === 0 ? a += " cl-green" : Y.includes(t) ? a += " cl-black" : a += " cl-red", a
}

function Q(t) {
    const a = p(),
        r = u(),
        [n, i] = c.exports.useState(t.list);
    return c.exports.useEffect(() => {
        let l = !1,
            R = setInterval(() => {
                l || k(t.params).then(d => {
                    l || i(d.list)
                }).catch(d => {
                    console.error(d)
                })
            }, 2e4);
        return () => {
            l = !0, window.clearInterval(R)
        }
    }, []), s("div", {
        className: ee,
        children: [s("div", {
            className: "head flex",
            children: [e("div", {
                className: "col",
                children: a("common.game_number")
            }), e("div", {
                className: "col",
                children: a("common.result")
            }), e("div", {
                className: "col-2",
                children: a("common.hash")
            })]
        }), e("ul", {
            className: "list",
            children: n.map(l => s("li", {
                className: "item flex",
                children: [e("div", {
                    className: "col hover",
                    onClick: () => m.openAllPlayers({
                        gameName: r.name,
                        gameId: l.gameId
                    }),
                    children: l.gameId
                }), e("div", {
                    className: "col",
                    children: e("div", {
                        className: K(l.value),
                        children: l.value
                    })
                }), s("div", {
                    className: "seed-box col-2",
                    children: [e("input", {
                        type: "text",
                        className: "seed",
                        value: l.hash,
                        readOnly: !0
                    }), e("a", {
                        href: E(l),
                        target: "_blank",
                        className: "cl-primary",
                        children: a("common.verify")
                    })]
                })]
            }, l.gameId))
        })]
    })
}
var X = A(J);
x({
    cl1: [o("#2d3035", .6), o("#dadde6", .6)],
    cl2: [o("#2d3035", .4), o("#dadde6", .3)]
});
const Z = "h6om7t3";
x({
    cl1: ["#99a4b0", "#5f6975"],
    cl2: ["#2d3035", o("#e9eaf2", .6)],
    cl3: [o("#99a4b0", .6), "#5f6975"]
});
const ee = "l1re56bk",
    ae = P.memo(() => {
        const t = p(),
            a = u(),
            r = c.exports.useRef(null);
        return c.exports.useEffect(() => {
            const n = r.current;
            if (n) {
                const i = l => {
                    a.betRecent = l
                };
                return n.on("recent-result", i), () => {
                    n.off("recent-result", i)
                }
            }
        }, []), e(B, {
            ref: r,
            src: a.gameUrl,
            actions: [e(V, {}), e($, {})],
            banner: a.gameInfo.cover,
            tabs: [{
                label: t("common.my_bet"),
                value: m.Mybet
            }, {
                label: t("common.history"),
                value: X
            }]
        })
    });
class te extends O {
    constructor() {
        super({
            name: "roulette",
            namespace: "/g/unknown",
            fairLink: "/roulette_multiplayer_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/roulette.html"
        }, ae), this.disableAutoConnect = !0, this.historyPageSize = 20, this.betRecent = [], W(this, {
            betRecent: F,
            gameUrl: M
        })
    }
    get gameUrl() {
        return y.isDev ? "http://roulette.bc.com" : `//roulette.${y.domain}`
    }
}
const I = new te;
var oe = I;
window.rog = I;
const se = m.withMultipleDetail(t => {
    const a = p(),
        {
            gv: r,
            gb: n
        } = t,
        i = n.extend.value;
    return s("div", {
        className: re,
        children: [s(U, {
            className: "rt_items",
            children: [s("div", {
                className: "item-wrap",
                children: [s("div", {
                    className: "item-num",
                    children: [e(h, {
                        className: "result",
                        name: "Result"
                    }), e("span", {
                        children: a("common.result")
                    })]
                }), e("div", {
                    className: "item-desc",
                    children: i
                })]
            }), s("div", {
                className: "item-wrap",
                children: [s("div", {
                    className: "item-num",
                    children: [e(h, {
                        className: "bettype",
                        name: "Bet"
                    }), e("span", {
                        children: a("common.bet")
                    })]
                }), e("div", {
                    className: "item-desc",
                    children: e("span", {
                        className: "mthan",
                        children: r[0].bets[0].type
                    })
                })]
            }), s("div", {
                className: "item-wrap",
                children: [s("div", {
                    className: "item-num",
                    children: [e(h, {
                        className: "chance",
                        name: "Chance"
                    }), e("span", {
                        children: a("common.chance")
                    })]
                }), e("div", {
                    className: "item-desc",
                    children: "-"
                })]
            })]
        }), e(w, {
            label: a("common.game_number"),
            value: n.gameId,
            readOnly: !0
        }), e(w, {
            label: a("common.hash"),
            value: n.extend.hash,
            readOnly: !0
        }), s("div", {
            className: "flex btns",
            children: [s(N, {
                className: "all",
                type: "gray",
                onClick: () => m.openAllPlayers({
                    gameName: n.gameName,
                    gameId: n.gameId
                }),
                children: [e("span", {
                    children: a("common.all_players")
                }), e(h, {
                    name: "Arrow"
                })]
            }), e(N, {
                type: "conic",
                onClick: () => {
                    window.open(`https://bcgame-project.github.io/verify/roulette.html?hash=${n.extend.hash}`)
                },
                children: a("common.verify")
            })]
        })]
    })
});
var ce = se;
const re = "r19329cf";

function he({
    bodyLock: t
}) {
    return e(q, {
        bodyLock: t,
        children: s("div", {
            className: "item",
            children: [e("h2", {
                children: "What is a roulette?"
            }), e("p", {
                children: "Roulette is a common quiz game with a total of 37 numbers, including numbers 1 to 36 and 0; The numbers on the wheel are spaced in red and black, but the numbers are not in order."
            }), e("h2", {
                children: "How does the roulette work?"
            }), e("p", {
                children: "There is a preparation time of 10s before the start of each game. After the game starts, the wheel will rotate at high speed and stop slowly. The final position of the pointer is the result of the game."
            }), e("h2", {
                children: "How should I play? "
            }), e("p", {
                children: "Size: 1-18, 19-36: The bet number can be in the upper half (small) or the lower half (large), and the odds are 1:2."
            }), e("p", {
                children: "Number 0: Betting number 0, odds 1:36."
            }), e("h2", {
                children: "Game fairness?"
            }), s("p", {
                children: ["The game is based on a hash hash (", e("a", {
                    className: "h2-link cl-primary",
                    href: "https://dwz.cn/5f5VdLt/",
                    target: "_blank",
                    children: "https://dwz.cn/5f5VdLtp"
                }), "). The designer generated a total of 10 million hash hashes (generating chain verifiable), and each hash corresponds to a roulette result.The game releases the 10 million numbers in reverse to correspond to each draw in the game.So this game has 10 million periods.In other words, the number of roulette results for each issue of the game has long existed."]
            }), e("h2", {
                children: "How to verify fairness?"
            }), s("p", {
                children: ["The SHA256 of the hash from the game 23654 is: ", e("br", {}), " ", "33d8be75c9f6cb219a1763e77e307ac0a1107c85bd9fee53e81be0ec592ff4c5"]
            }), s("p", {
                children: ["The final hash of the game is sh256: ", e("br", {}), " ", "5bf9a3fae704667be2d3704ea8b6e703796defaa5f328e1a8d46b3a0fa12269f"]
            }), e("p", {
                children: "You can verify the shasha of the hash corresponding to any lottery period!"
            }), s("p", {
                children: ["Verify address:", e("a", {
                    className: "h2-link cl-primary",
                    href: "http://www.ttmd5.com/hash.php?type=9",
                    target: "_blank",
                    children: "http://www.ttmd5.com/hash.php?type=9"
                })]
            }), e("p", {
                children: "Verification result algorithm:"
            }), e("p", {
                children: "To generate a random number between 0 and 36, we take the first 3 characters of the hash and convert them to a decimal number from 0 to 4096 (16^3).If it is less than 3700, we divide it by 100 and round it up to use as a roulette result.Otherwise, we reuse the next 3 characters.We are able to repeat this process up to 62 times."
            }), e("p", {
                children: "In very rare cases, the probability of (64*2/(16^64)), none of the 62 trials is below 3700, we use the last character and convert them to your game result."
            }), e("p", {
                children: "For example: 5bf9a3fae704667be2d3704ea8b6e703796defaa5f328e1a8d46b3a0fa12269f Take the first 3 characters of the hash 5bf, convert to decimal equal to 880,880/100=8.8, after rounding, the game result is 8."
            })]
        })
    })
}
export {
    ce as Detail, he as Fairness, oe as Game
};
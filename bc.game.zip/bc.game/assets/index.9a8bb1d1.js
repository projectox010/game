var nt = Object.defineProperty,
    rt = Object.defineProperties;
var ot = Object.getOwnPropertyDescriptors;
var Se = Object.getOwnPropertySymbols;
var it = Object.prototype.hasOwnProperty,
    st = Object.prototype.propertyIsEnumerable;
var Ie = (n, t, e) => t in n ? nt(n, t, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: e
    }) : n[t] = e,
    B = (n, t) => {
        for (var e in t || (t = {})) it.call(t, e) && Ie(n, e, t[e]);
        if (Se)
            for (var e of Se(t)) st.call(t, e) && Ie(n, e, t[e]);
        return n
    },
    ke = (n, t) => rt(n, ot(t));
import {
    o as G,
    u as S,
    J as D,
    r as f,
    a as i,
    D as X,
    j as p,
    X as ct,
    Y as lt,
    Z as dt,
    b as U,
    _ as ut,
    $ as ie,
    G as C,
    v as H,
    a0 as pt,
    a1 as ht,
    a2 as Ue,
    e as se,
    d as w,
    a3 as Oe,
    S as ce,
    F as V,
    a4 as le,
    I as mt,
    a5 as x,
    t as O,
    q as v,
    a6 as Ee,
    a7 as k,
    A as y,
    K as Ne,
    a8 as ft,
    a9 as vt,
    aa as gt,
    ab as Fe,
    E as He,
    ac as yt,
    ad as de,
    ae as bt,
    af as wt,
    L as Ct,
    ag as Nt,
    M as _t,
    ah as xt,
    p as _e,
    l as xe,
    ai as St,
    s as oe,
    aj as It,
    ak as kt,
    al as Et,
    am as Mt,
    k as Pt,
    an as At,
    T as Lt,
    ao as Ze,
    ap as Rt,
    y as Tt,
    aq as Dt,
    C as Wt,
    ar as zt
} from "./index.28e31dff.js";
import {
    u as Ut,
    A as Ot,
    g as je,
    a as Ft
} from "./Achieve.65f39bc0.js";
const Ht = G(function() {
    const t = S(),
        e = B({}, D.dict),
        o = (() => {
            const b = [];
            return Object.keys(e).map(q => {
                e[q].rainLimit > 0 && b.push(e[q])
            }), b
        })().map(b => b.currencyName),
        c = o.indexOf("BTC") >= 0 ? "BTC" : o[0],
        s = o.indexOf(D.current) >= 0 ? D.current : c,
        d = o.map(b => D.dict[b]),
        [l, u] = f.exports.useState(s),
        [h, m] = f.exports.useState(50),
        [g, R] = f.exports.useState(""),
        [P, F] = f.exports.useState(!1);
    let A = e[l].rainLimit;
    const [T, Z] = f.exports.useState(e[s].rainLimit), J = async () => {
        try {
            const b = await ut();
            if (!b) return;
            const {
                code: q,
                timestamp: tt,
                verifyType: at
            } = b;
            F(!0), await ie.post("/game/support/bonus/rain/", {
                currencyName: l,
                amount: T,
                number: h,
                verifyType: at,
                code: q,
                remarks: g,
                timestamp: tt
            }), C(t("common.messages.rain_success")), H.back()
        } catch (b) {
            C(b), b && b.code === pt.TWOFA_ERROR && J()
        }
        F(!1)
    }, ue = async () => {
        const b = await ht(l, !1, d);
        u(b)
    }, j = D.dict[l].amount, M = D.getAlias(l);
    let [I, L] = D.getValideMaxMin(A, j, l);
    l === "BCL" && (h < 10 ? (I = 10, A = 10) : (I = h, A = h));
    const et = T < I || T > L || g.length > 20 || P;
    return i(X, {
        title: t("title.user_rain"),
        children: p("div", {
            className: Zt,
            children: [i(ct, {
                label: p("div", {
                    className: "amount-label",
                    children: [i("p", {
                        children: t("common.amount")
                    }), p("p", {
                        children: [t("common.balance"), ":", " ", p("span", {
                            children: [j, " ", M]
                        })]
                    })]
                }),
                className: "amount-input",
                value: T,
                currencyName: l,
                onChange: Z,
                onClick: ue,
                max: L,
                min: I,
                after: `Min: ${A} ${M}`
            }), i(lt, {
                className: "people-input",
                min: 1,
                max: 100,
                value: h,
                onChange: m,
                label: t("page.rain.person"),
                children: i("div", {
                    className: "dialog-gray",
                    children: "1~100"
                })
            }), i(dt, {
                className: "rain-textarea",
                label: t("page.tips.message") + t("page.tips.Optional"),
                value: g,
                onChange: R,
                children: p("div", {
                    className: g.length > 20 ? "rain-error rain-len " : "rain-len",
                    children: [g.length, "/20"]
                })
            }), i(U, {
                type: "conic",
                loading: P,
                onClick: J,
                disabled: et,
                children: t("page.rain.start")
            })]
        })
    })
});
var ln = Ht;
const Zt = "ropc9ja";

function jt() {
    const {
        userId: n
    } = Ue(), t = se(), e = S(), [a, r] = f.exports.useState([]), [o, c] = f.exports.useState(!0), s = Ut(), d = Number(w.userId) === Number(n);
    return f.exports.useEffect(() => {
        let l = !0;
        return ie.get("/game/support/achievement/" + n + "/", {
            cache: !0
        }).then(u => {
            l && (r((u || []).filter(h => h.type !== 9)), c(!1))
        }).catch(u => {
            l && (C(u), c(!1))
        }), () => {
            l = !1
        }
    }, []), i(X, {
        title: e("title.user_achieve"),
        children: o ? i(Oe, {}) : i(ce, {
            children: i("div", {
                className: Bt,
                children: a.length > 0 ? p(V, {
                    children: [i("div", {
                        className: "min-height",
                        children: i("div", {
                            className: "detail-list",
                            children: a.map((l, u) => i("div", {
                                className: "detail-item",
                                onClick: () => {
                                    H.push(i(Ot, {
                                        type: l.type,
                                        subType: l.subType,
                                        status: l.status,
                                        uid: n
                                    }))
                                },
                                children: p(V, {
                                    children: [i("img", {
                                        src: je(l.type, l.subType)
                                    }), l.type.toString() !== "17" ? i("div", {
                                        className: "tit",
                                        children: s["title_" + l.type]
                                    }) : p("div", {
                                        className: "tit",
                                        children: [l.subType, e("page.achieve.content.17.tit")]
                                    }), p("div", {
                                        className: "tit1",
                                        children: [new Date(l.createTime).toLocaleDateString(), " ", e("page.achieve.get")]
                                    })]
                                })
                            }, u))
                        })
                    }), p("button", {
                        className: "enter theme",
                        onClick: () => t("/achieve"),
                        children: ["BC ", e("title.achieve")]
                    })]
                }) : i(le, {
                    hideMsg: !0,
                    children: i("div", {
                        className: "tips",
                        children: d ? i(mt, {
                            k: "common.messages.no_achieve",
                            children: i("button", {
                                className: "theme",
                                onClick: () => t("/achieve"),
                                children: e("title.user_achieve")
                            })
                        }) : p("div", {
                            children: [e("common.messages.no_achieve_player"), p("button", {
                                className: "enter theme",
                                onClick: () => t("/achieve"),
                                children: ["BC ", e("title.achieve")]
                            })]
                        })
                    })
                })
            })
        })
    })
}
var dn = G(jt);
const Bt = "a7yjbtn";

function $t({
    onPreview: n
}) {
    const t = S(),
        e = Y(),
        a = se();
    let {
        userId: r,
        level: o,
        totalLikeNum: c,
        titles: s,
        titleDesc: d,
        allowOnlyFriendPrivate: l,
        name: u
    } = e.userInfo;
    const {
        isHidden: h
    } = e, m = Ee.isFirend(r), g = m || !l;
    typeof u == "string" && (u = u.trim());
    async function R() {
        try {
            await new Ee({
                userId: r,
                name: u
            }).friendRequest(), Fe.trackEvent("add_friends", {
                member_name: u,
                member_id: String(r),
                member_level: Number(o)
            })
        } catch (A) {
            C(A)
        }
    }

    function P() {
        r && (He(String(r)), C(t("common.messages.copy_success")))
    }

    function F() {
        yt({
            userId: r,
            name: u,
            level: o
        })
    }
    return i("div", {
        className: Gt,
        children: p("div", {
            className: "user-info",
            children: [i(k, {
                title: t("page.user.profile.likes"),
                children: p("button", {
                    className: "like button",
                    children: [i(y, {
                        name: "Like"
                    }), " ", c]
                })
            }), !e.isMyself && m && i("div", {
                className: "hello"
            }), e.isMyself && i(k, {
                title: t("common.actions.edit"),
                children: i("button", {
                    className: "button edit",
                    onClick: () => a("/user/edit_nickname"),
                    children: i(y, {
                        name: "Edit"
                    })
                })
            }), i("div", {
                onClick: n,
                className: "avatar-box",
                children: i(Ne, {
                    userId: r,
                    name: u,
                    tooltip: !0
                })
            }), p("div", {
                className: "name-box",
                children: [i(ft, {
                    className: "user-name",
                    userId: r,
                    name: u
                }), i(vt, {
                    code: s,
                    desc: d
                })]
            }), p("div", {
                className: "user-id",
                onClick: P,
                children: [t("common.user_id"), ":\xA0", r]
            }), !h && i(gt, {
                level: o,
                className: "user-level"
            }), !e.isMyself && p("div", {
                className: "actions",
                children: [i(k, {
                    title: t("title.user_sendtip"),
                    children: p("button", {
                        className: "tip button",
                        onClick: F,
                        children: [i(y, {
                            name: "Tip"
                        }), " ", t("title.user_sendtip")]
                    })
                }), g && i(k, {
                    title: t("title.user_chat"),
                    children: p("button", {
                        className: "chat button",
                        onClick: () => a(`/chat/${r}`),
                        children: [i(y, {
                            name: "Chat"
                        }), " ", t("page.user.profile.chat")]
                    })
                }), !m && i(k, {
                    title: t("common.friend_add"),
                    children: p("button", {
                        className: "button add",
                        onClick: R,
                        children: [i(y, {
                            name: "AddFirend"
                        }), " ", t("common.actions.add")]
                    })
                })]
            })]
        })
    })
}
var Vt = x.memo($t);
O({
    cl1: [v("#1e2024", .7), "#fff"],
    cl2: ["#fff", "#5f6975"],
    cl3: ["#1e2024", "#fff"],
    cl4: [v("#99a4b0", .6), v("#5f6975", .48)],
    cl5: ["#464646", "#dfdfdf"],
    cl6: ["#f5f6f7", "#31373d"],
    cl7: [v("#99a4b0", .6), v("#5f6975", .8)],
    cl8: [v("#99a4b0", .6), v("#5f6975", .6)]
});
const Gt = "b1gam0sf";

function Xt() {
    const n = S(),
        t = Y(),
        {
            isHidden: e,
            totalWins: a,
            totalBets: r,
            totalWagered: o
        } = t,
        {
            userId: c,
            level: s
        } = t.userInfo,
        d = t.userInfo.name;
    return p(de, {
        className: Jt,
        children: [p("div", {
            className: "module-name",
            children: [!e && i(y, {
                name: "Statistics",
                className: "icon-name"
            }), n("page.user.profile.statistics"), !e && p("button", {
                className: "hover",
                onClick: () => bt({
                    userId: c,
                    level: s,
                    userName: d
                }),
                children: [n("common.detail"), i(y, {
                    name: "Arrow",
                    className: "icon-right"
                })]
            })]
        }), i("div", {
            className: "content",
            children: e ? i("div", {
                className: "nothing",
                children: i(le, {
                    type: "privacy",
                    hideMsg: !0,
                    children: i("div", {
                        className: "darken",
                        children: n("page.user.profile.statistics_hidden")
                    })
                })
            }) : i(wt, {
                totalWins: a,
                totalBets: r,
                totalWagered: o
            })
        })]
    })
}
var Yt = x.memo(Xt);
const Jt = "s8euj6w";

function qt() {
    const n = S(),
        t = se(),
        r = Y().userInfo.favorite.filter(o => o.gameItem);
    return p(de, {
        className: Kt,
        children: [i("div", {
            className: "module-name",
            children: n("page.user.profile.favorite")
        }), r.length ? i("div", {
            className: "content",
            children: r.map((o, c) => {
                var s;
                return p("div", {
                    className: "content-item",
                    children: [i("div", {
                        className: "cover-box",
                        style: {
                            backgroundImage: `url(${(s=o.gameItem)==null?void 0:s.thumbnail})`
                        },
                        onClick: () => {
                            w.emit("game_click", "game_profile"), H.close(), t(o.gameItem.gameUrl)
                        }
                    }), p("div", {
                        className: "info",
                        children: [i("div", {
                            className: "game-name",
                            onClick: () => {
                                w.emit("game_click", "game_profile"), H.close(), t(o.gameItem.gameUrl)
                            },
                            children: o.gameItem.fullName
                        }), i(k, {
                            title: o.gameItem.summary,
                            forceWrap: !0,
                            children: i("div", {
                                className: "desc darken",
                                children: o.gameItem.summary
                            })
                        })]
                    }), p("div", {
                        className: "bets",
                        children: [i("div", {
                            className: "type darken",
                            children: n("common.wagered")
                        }), i("div", {
                            className: "value",
                            children: i(Ct, {
                                amount: o.betAmountUsd
                            })
                        })]
                    })]
                }, c)
            })
        }) : i(le, {})]
    })
}
O({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [v("#18191d", .6), "#31373d"],
    cl3: ["#ededed", "#31373d"]
});
const Kt = "f1af1f5a";

function Qt() {
    const n = S(),
        t = Y(),
        [e, a] = f.exports.useState({
            page: 1,
            total: t.userInfo.contest.length,
            limit: 5,
            list: t.userInfo.contest.slice(0, 5)
        });

    function r(o) {
        a(ke(B({}, e), {
            page: o,
            list: t.userInfo.contest.slice((o - 1) * 5, o * 5)
        }))
    }
    return p(de, {
        className: ta,
        children: [i("div", {
            className: "module-name",
            children: n("page.contest.title")
        }), e.total > 0 ? p(V, {
            children: [p("div", {
                className: "content",
                children: [p("div", {
                    className: "thead darken",
                    children: [i("div", {
                        className: "th",
                        children: n("page.user.profile.date")
                    }), i("div", {
                        className: "th",
                        children: n("page.user.profile.position")
                    }), i("div", {
                        className: "th",
                        children: n("common.prize")
                    })]
                }), i("div", {
                    className: "tbody",
                    children: e.list.map((o, c) => p("div", {
                        className: "tr",
                        children: [p("div", {
                            className: "td darken2 capitalize",
                            children: [new Date(o.createTime).toLocaleDateString(), " ", o.contestType]
                        }), i("div", {
                            className: "td",
                            children: Nt(o.rank)
                        }), i("div", {
                            className: "td",
                            children: i(_t, {
                                name: o.currencyName,
                                amount: +o.totalBonus,
                                icon: !0,
                                showName: !1
                            })
                        })]
                    }, c))
                })]
            }), i(xt, {
                page: e.page,
                total: e.total,
                limit: e.limit,
                type: "pageConic2",
                onChange: o => r(o)
            })]
        }) : i(le, {})]
    })
}
var ea = x.memo(Qt);
O({
    cl1: ["#f5f6f7", "#5f6975"],
    cl2: [v("#99a4b0", .6), v("#5f6975", 1)],
    cl3: [v("#2d3035", .6), v("#dadde6", .6)],
    cl4: [v("#2d3035", .4), v("#dadde6", .3)]
});
const ta = "c1tr2zbd";

function aa({
    state: n,
    setState: t
}) {
    const e = S(),
        [a, r] = f.exports.useState(n),
        o = a.userInfo.name;

    function c() {
        if (Fe.trackEvent("profile_like", {
                member_name: o,
                member_id: String(a.userInfo.userId),
                member_level: a.userInfo.level
            }), a.isMyself) return C(e("page.user.profile.like_tip"));
        if (a.userInfo.hasSelfHeadClick) return !1;
        ie.post("/game/support/system-like/like-event/", {
            likeItem: a.userInfo.userId,
            sceneType: 1
        }).then(s => {
            a.userInfo.totalLikeNum = a.userInfo.shareLikeNum + s.clickCount, a.userInfo.headLikeNum = s.clickCount, a.userInfo.hasSelfHeadClick = !0, t(B({}, a)), r(B({}, a))
        }).catch(C)
    }
    return p("div", {
        className: ra,
        children: [i("div", {
            className: "content",
            children: i("button", {
                className: "close flex-center",
                onClick: () => {
                    _e.close()
                },
                children: i(y, {
                    name: "Close"
                })
            })
        }), i(Ne, {
            size: "l",
            userId: a.userInfo.userId,
            name: o
        }), p("button", {
            className: `button ${a.userInfo.hasSelfHeadClick?"liked":""}`,
            onClick: c,
            children: [i(y, {
                name: "Like"
            }), a.userInfo.headLikeNum]
        })]
    })
}
var na = G(aa);
O({
    cl1: [v("#000000", .7), v("#979797", .6)],
    cl2: [v("#17181b", .7), v("#e9eaf2", .7)]
});
const ra = "p1l1ftkw";

function oa() {
    const n = S(),
        t = se(),
        e = Y(),
        {
            isHidden: a,
            isMyself: r
        } = e,
        {
            achievements: o,
            achievementType: c,
            userId: s
        } = e.userInfo,
        d = o.filter(u => u.status === "1").length;
    let l = Ft(o);
    return l.sort(function(u, h) {
        return Number(h.status) - Number(u.status)
    }), l = l.filter(u => u.type !== 9), a ? null : p(de, {
        className: xe(sa, r && "self"),
        children: [p("div", {
            className: "module-name",
            children: [i(y, {
                name: "Medal",
                className: "icon-name"
            }), " ", n("page.user.profile.medals"), i("div", {
                className: "total",
                children: d
            }), p("button", {
                className: "detail-button",
                onClick: () => t(`/user/achieve/${s}`),
                children: [n("common.detail"), i(y, {
                    name: "Arrow"
                })]
            })]
        }), i("div", {
            className: "content",
            children: i("div", {
                className: "scroll",
                onClick: () => t(`/user/achieve/${s}`),
                children: l.map((u, h) => i("div", {
                    className: `item ${u.type===c?"new":""}`,
                    children: i("img", {
                        src: je(u.type, u.subType),
                        className: `img ${u.status==="1"?"":"locked"}`
                    })
                }, h))
            })
        })]
    })
}
var ia = x.memo(oa);
O({
    cl1: [v("#99a4b0", .6), v("#5f6975", .6)],
    cl2: ["#74ad27", "#7bc514"]
});
const sa = "m6eslgk";
var ca = "/assets/hellofriend.20e3d9c9.svg",
    la = "/assets/vip_type1.9697d4e3.svg",
    da = "/assets/vip_type2.a63864a5.svg",
    ua = "/assets/vip_type3.3c6a40aa.svg",
    pa = "/assets/vip_type4.ccdc4ed1.svg",
    ha = "/assets/vip_type5.fdaeabbb.svg",
    $ = {
        hello: ca,
        vipType1: la,
        vipType2: da,
        vipType3: ua,
        vipType4: pa,
        vipType5: ha
    };

function ma(n) {
    const {
        isSvip: t,
        vipLevel: e
    } = w.getUserLevelInfo(n);
    return `${t?"S":"V"}${e}`
}

function fa(n) {
    const t = St(Math.max(1, n) - 1)[4];
    return Math.max(1, Number(t))
}

function va({
    className: n = "vip-level",
    level: t
}) {
    const a = ["", $.vipType1, $.vipType2, $.vipType3, $.vipType4, $.vipType5][fa(t)];
    return i("div", {
        className: xe(ya, n),
        children: i("div", {
            className: "vip-box",
            style: {
                backgroundImage: `url(${a})`
            },
            children: ma(t)
        })
    })
}
var ga = x.memo(va);
const ya = "vfdmolz";
const Be = f.exports.createContext({});

function Y() {
    return f.exports.useContext(Be)
}

function un() {
    const {
        userId: n
    } = Ue(), t = S(), e = Number(n), a = w.userId === e, [r, o] = f.exports.useState(null);
    return f.exports.useEffect(() => {
        oe.postParentMessage({
            type: "showProfile",
            userIdNum: e
        })
    }, [n]), f.exports.useEffect(() => {
        It(e).then(c => {
            o({
                isMyself: a,
                isHidden: !a && c.hideGameData,
                showPreview: !1,
                userInfo: c,
                totalWins: c.winNum,
                totalBets: c.betNum,
                totalWagered: c.betAmountUsd
            })
        }).catch(C)
    }, [n, w.userId]), i(Be.Provider, {
        value: r,
        children: i(X, {
            title: t("page.user.profile.title"),
            nostyle: !0,
            children: i(ce, {
                className: `${ba} user__profile`,
                children: r ? p(V, {
                    children: [i(kt, {
                        children: i(ga, {
                            level: r == null ? void 0 : r.userInfo.level
                        })
                    }), i(Vt, {
                        onPreview: () => _e.push(i(na, {
                            state: r,
                            setState: o
                        }), {
                            closeable: !1
                        })
                    }), i(ia, {}), i(Yt, {}), !r.isHidden && p(V, {
                        children: [i(qt, {}), i(ea, {})]
                    }), i("div", {
                        className: "joined",
                        children: p("div", {
                            children: [t("page.user.profile.joined"), "\xA0", new Date(r.userInfo.createTime).toLocaleDateString()]
                        })
                    })]
                }) : i(Oe, {})
            })
        })
    })
}
const ba = "p1ba8c29";
const wa = G(function() {
    const [t, e] = f.exports.useState(w.name), a = S(), r = () => t === w.name ? C(new Error(a("page.settings.same_nickname"))) : ie.post("/user/name/change/", {
        userName: t
    }).then(() => {
        w.name = t, C(a("common.messages.modify_success")), H.back()
    }).catch(C);
    return i(X, {
        title: a("title.settings_nickname"),
        children: i(ce, {
            className: Ca,
            children: p("div", {
                className: "flex-column full",
                children: [p(Et, {
                    to: "/user/edit_avatar",
                    className: "avatar-box",
                    children: [i(Ne, {
                        name: w.name,
                        userId: w.userId
                    }), i("button", {
                        children: a("user.edit_avatar")
                    })]
                }), p("div", {
                    className: "dialog-box",
                    children: [i(Mt, {
                        label: a("user.nick_new"),
                        value: t,
                        autoComplete: "off",
                        placeholder: a("page.settings.nick_field"),
                        onChange: e
                    }), i("div", {
                        className: "tip-warnning",
                        children: a("page.settings.nick_tip")
                    }), i(U, {
                        type: "conic",
                        onClick: r,
                        children: a("common.actions.modify")
                    })]
                })]
            })
        })
    })
});
var pn = wa;
O({
    cl1: ["#fff", "#31373d"],
    cl2: [v("#31343c", .6), v("#e9eaf2", .6)]
});
const Ca = "n3prx";
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
var pe = function(n, t) {
    return pe = Object.setPrototypeOf || {
        __proto__: []
    }
    instanceof Array && function(e, a) {
        e.__proto__ = a
    } || function(e, a) {
        for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r])
    }, pe(n, t)
};

function Na(n, t) {
    pe(n, t);

    function e() {
        this.constructor = n
    }
    n.prototype = t === null ? Object.create(t) : (e.prototype = t.prototype, new e)
}
var _ = function() {
        return _ = Object.assign || function(t) {
            for (var e, a = 1, r = arguments.length; a < r; a++) {
                e = arguments[a];
                for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o])
            }
            return t
        }, _.apply(this, arguments)
    },
    Me = !1,
    z, he, me, ae, ne, $e, re, fe, ve, ge, Ve, ye, be, Ge, Xe;

function N() {
    if (!Me) {
        Me = !0;
        var n = navigator.userAgent,
            t = /(?:MSIE.(\d+\.\d+))|(?:(?:Firefox|GranParadiso|Iceweasel).(\d+\.\d+))|(?:Opera(?:.+Version.|.)(\d+\.\d+))|(?:AppleWebKit.(\d+(?:\.\d+)?))|(?:Trident\/\d+\.\d+.*rv:(\d+\.\d+))/.exec(n),
            e = /(Mac OS X)|(Windows)|(Linux)/.exec(n);
        if (ye = /\b(iPhone|iP[ao]d)/.exec(n), be = /\b(iP[ao]d)/.exec(n), ge = /Android/i.exec(n), Ge = /FBAN\/\w+;/i.exec(n), Xe = /Mobile/i.exec(n), Ve = !!/Win64/.exec(n), t) {
            z = t[1] ? parseFloat(t[1]) : t[5] ? parseFloat(t[5]) : NaN, z && document && document.documentMode && (z = document.documentMode);
            var a = /(?:Trident\/(\d+.\d+))/.exec(n);
            $e = a ? parseFloat(a[1]) + 4 : z, he = t[2] ? parseFloat(t[2]) : NaN, me = t[3] ? parseFloat(t[3]) : NaN, ae = t[4] ? parseFloat(t[4]) : NaN, ae ? (t = /(?:Chrome\/(\d+\.\d+))/.exec(n), ne = t && t[1] ? parseFloat(t[1]) : NaN) : ne = NaN
        } else z = he = me = ne = ae = NaN;
        if (e) {
            if (e[1]) {
                var r = /(?:Mac OS X (\d+(?:[._]\d+)?))/.exec(n);
                re = r ? parseFloat(r[1].replace("_", ".")) : !0
            } else re = !1;
            fe = !!e[2], ve = !!e[3]
        } else re = fe = ve = !1
    }
}
var we = {
        ie: function() {
            return N() || z
        },
        ieCompatibilityMode: function() {
            return N() || $e > z
        },
        ie64: function() {
            return we.ie() && Ve
        },
        firefox: function() {
            return N() || he
        },
        opera: function() {
            return N() || me
        },
        webkit: function() {
            return N() || ae
        },
        safari: function() {
            return we.webkit()
        },
        chrome: function() {
            return N() || ne
        },
        windows: function() {
            return N() || fe
        },
        osx: function() {
            return N() || re
        },
        linux: function() {
            return N() || ve
        },
        iphone: function() {
            return N() || ye
        },
        mobile: function() {
            return N() || ye || be || ge || Xe
        },
        nativeApp: function() {
            return N() || Ge
        },
        android: function() {
            return N() || ge
        },
        ipad: function() {
            return N() || be
        }
    },
    _a = we,
    K = !!(typeof window < "u" && window.document && window.document.createElement),
    xa = {
        canUseDOM: K,
        canUseWorkers: typeof Worker < "u",
        canUseEventListeners: K && !!(window.addEventListener || window.attachEvent),
        canUseViewport: K && !!window.screen,
        isInWorker: !K
    },
    Sa = xa,
    Ye = Sa,
    Je;
Ye.canUseDOM && (Je = document.implementation && document.implementation.hasFeature && document.implementation.hasFeature("", "") !== !0);
/**
 * Checks if an event is supported in the current execution environment.
 *
 * NOTE: This will not work correctly for non-generic events such as `change`,
 * `reset`, `load`, `error`, and `select`.
 *
 * Borrows from Modernizr.
 *
 * @param {string} eventNameSuffix Event name, e.g. "click".
 * @param {?boolean} capture Check if the capture phase is supported.
 * @return {boolean} True if the event is supported.
 * @internal
 * @license Modernizr 3.0.0pre (Custom Build) | MIT
 */
function Ia(n, t) {
    if (!Ye.canUseDOM || t && !("addEventListener" in document)) return !1;
    var e = "on" + n,
        a = e in document;
    if (!a) {
        var r = document.createElement("div");
        r.setAttribute(e, "return;"), a = typeof r[e] == "function"
    }
    return !a && Je && n === "wheel" && (a = document.implementation.hasFeature("Events.wheel", "3.0")), a
}
var ka = Ia,
    Ea = _a,
    Ma = ka,
    Pe = 10,
    Ae = 40,
    Le = 800;

function qe(n) {
    var t = 0,
        e = 0,
        a = 0,
        r = 0;
    return "detail" in n && (e = n.detail), "wheelDelta" in n && (e = -n.wheelDelta / 120), "wheelDeltaY" in n && (e = -n.wheelDeltaY / 120), "wheelDeltaX" in n && (t = -n.wheelDeltaX / 120), "axis" in n && n.axis === n.HORIZONTAL_AXIS && (t = e, e = 0), a = t * Pe, r = e * Pe, "deltaY" in n && (r = n.deltaY), "deltaX" in n && (a = n.deltaX), (a || r) && n.deltaMode && (n.deltaMode == 1 ? (a *= Ae, r *= Ae) : (a *= Le, r *= Le)), a && !t && (t = a < 1 ? -1 : 1), r && !e && (e = r < 1 ? -1 : 1), {
        spinX: t,
        spinY: e,
        pixelX: a,
        pixelY: r
    }
}
qe.getEventType = function() {
    return Ea.firefox() ? "DOMMouseScroll" : Ma("wheel") ? "wheel" : "mousewheel"
};
var Pa = qe,
    Aa = Pa;

function La(n, t, e, a, r, o) {
    o === void 0 && (o = 0);
    var c = Ke(n, t, o),
        s = c.width,
        d = c.height,
        l = Math.min(s, e),
        u = Math.min(d, a);
    return l > u * r ? {
        width: u * r,
        height: u
    } : {
        width: l,
        height: l / r
    }
}

function Q(n, t, e, a, r) {
    r === void 0 && (r = 0);
    var o = Ke(t.width, t.height, r),
        c = o.width,
        s = o.height;
    return {
        x: Re(n.x, c, e.width, a),
        y: Re(n.y, s, e.height, a)
    }
}

function Re(n, t, e, a) {
    var r = t * a / 2 - e / 2;
    return Math.min(r, Math.max(n, -r))
}

function Te(n, t) {
    return Math.sqrt(Math.pow(n.y - t.y, 2) + Math.pow(n.x - t.x, 2))
}

function De(n, t) {
    return Math.atan2(t.y - n.y, t.x - n.x) * 180 / Math.PI
}

function Ra(n, t, e, a, r, o, c) {
    o === void 0 && (o = 0), c === void 0 && (c = !0);
    var s = c && o === 0 ? Ta : Da,
        d = {
            x: s(100, ((t.width - e.width / r) / 2 - n.x / r) / t.width * 100),
            y: s(100, ((t.height - e.height / r) / 2 - n.y / r) / t.height * 100),
            width: s(100, e.width / t.width * 100 / r),
            height: s(100, e.height / t.height * 100 / r)
        },
        l = Math.round(s(t.naturalWidth, d.width * t.naturalWidth / 100)),
        u = Math.round(s(t.naturalHeight, d.height * t.naturalHeight / 100)),
        h = t.naturalWidth >= t.naturalHeight * a,
        m = h ? {
            width: Math.round(u * a),
            height: u
        } : {
            width: l,
            height: Math.round(l / a)
        },
        g = _(_({}, m), {
            x: Math.round(s(t.naturalWidth - m.width, d.x * t.naturalWidth / 100)),
            y: Math.round(s(t.naturalHeight - m.height, d.y * t.naturalHeight / 100))
        });
    return {
        croppedAreaPercentages: d,
        croppedAreaPixels: g
    }
}

function Ta(n, t) {
    return Math.min(n, Math.max(0, t))
}

function Da(n, t) {
    return t
}

function Wa(n, t, e) {
    var a = t.width / t.naturalWidth;
    if (e) {
        var r = e.height > e.width;
        return r ? e.height / a / n.height : e.width / a / n.width
    }
    var o = n.width / n.height,
        c = t.naturalWidth >= t.naturalHeight * o;
    return c ? t.naturalHeight / n.height : t.naturalWidth / n.width
}

function za(n, t, e) {
    var a = t.width / t.naturalWidth,
        r = Wa(n, t, e),
        o = a * r,
        c = {
            x: ((t.naturalWidth - n.width) / 2 - n.x) * o,
            y: ((t.naturalHeight - n.height) / 2 - n.y) * o
        };
    return {
        crop: c,
        zoom: r
    }
}

function We(n, t) {
    return {
        x: (t.x + n.x) / 2,
        y: (t.y + n.y) / 2
    }
}

function ee(n, t, e, a, r) {
    var o = Math.cos,
        c = Math.sin,
        s = r * Math.PI / 180,
        d = (n - e) * o(s) - (t - a) * c(s) + e,
        l = (n - e) * c(s) + (t - a) * o(s) + a;
    return [d, l]
}

function Ke(n, t, e) {
    var a = n / 2,
        r = t / 2,
        o = [ee(0, 0, a, r, e), ee(n, 0, a, r, e), ee(n, t, a, r, e), ee(0, t, a, r, e)],
        c = Math.min.apply(Math, o.map(function(u) {
            return u[0]
        })),
        s = Math.max.apply(Math, o.map(function(u) {
            return u[0]
        })),
        d = Math.min.apply(Math, o.map(function(u) {
            return u[1]
        })),
        l = Math.max.apply(Math, o.map(function(u) {
            return u[1]
        }));
    return {
        width: s - c,
        height: l - d
    }
}

function te() {
    for (var n = [], t = 0; t < arguments.length; t++) n[t] = arguments[t];
    return n.filter(function(e) {
        return typeof e == "string" && e.length > 0
    }).join(" ").trim()
}
var Ua = `.reactEasyCrop_Container {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  overflow: hidden;
  user-select: none;
  touch-action: none;
  cursor: move;
  display: flex;
  justify-content: center;
  align-items: center;
}

.reactEasyCrop_Image,
.reactEasyCrop_Video {
  will-change: transform; /* this improves performances and prevent painting issues on iOS Chrome */
}

.reactEasyCrop_Contain {
  max-width: 100%;
  max-height: 100%;
  margin: auto;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
}
.reactEasyCrop_Cover_Horizontal {
  width: 100%;
  height: auto;
}
.reactEasyCrop_Cover_Vertical {
  width: auto;
  height: 100%;
}

.reactEasyCrop_CropArea {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  border: 1px solid rgba(255, 255, 255, 0.5);
  box-sizing: border-box;
  box-shadow: 0 0 0 9999em;
  color: rgba(0, 0, 0, 0.5);
  overflow: hidden;
}

.reactEasyCrop_CropAreaRound {
  border-radius: 50%;
}

.reactEasyCrop_CropAreaGrid::before {
  content: ' ';
  box-sizing: border-box;
  position: absolute;
  border: 1px solid rgba(255, 255, 255, 0.5);
  top: 0;
  bottom: 0;
  left: 33.33%;
  right: 33.33%;
  border-top: 0;
  border-bottom: 0;
}

.reactEasyCrop_CropAreaGrid::after {
  content: ' ';
  box-sizing: border-box;
  position: absolute;
  border: 1px solid rgba(255, 255, 255, 0.5);
  top: 33.33%;
  bottom: 33.33%;
  left: 0;
  right: 0;
  border-left: 0;
  border-right: 0;
}
`,
    Oa = 1,
    Fa = 3,
    Ha = function(n) {
        Na(t, n);

        function t() {
            var e = n !== null && n.apply(this, arguments) || this;
            return e.imageRef = null, e.videoRef = null, e.containerRef = null, e.styleRef = null, e.containerRect = null, e.mediaSize = {
                width: 0,
                height: 0,
                naturalWidth: 0,
                naturalHeight: 0
            }, e.dragStartPosition = {
                x: 0,
                y: 0
            }, e.dragStartCrop = {
                x: 0,
                y: 0
            }, e.lastPinchDistance = 0, e.lastPinchRotation = 0, e.rafDragTimeout = null, e.rafPinchTimeout = null, e.wheelTimer = null, e.state = {
                cropSize: null,
                hasWheelJustStarted: !1
            }, e.preventZoomSafari = function(a) {
                return a.preventDefault()
            }, e.cleanEvents = function() {
                document.removeEventListener("mousemove", e.onMouseMove), document.removeEventListener("mouseup", e.onDragStopped), document.removeEventListener("touchmove", e.onTouchMove), document.removeEventListener("touchend", e.onDragStopped)
            }, e.clearScrollEvent = function() {
                e.containerRef && e.containerRef.removeEventListener("wheel", e.onWheel), e.wheelTimer && clearTimeout(e.wheelTimer)
            }, e.onMediaLoad = function() {
                e.computeSizes(), e.emitCropData(), e.setInitialCrop(), e.props.onMediaLoaded && e.props.onMediaLoaded(e.mediaSize)
            }, e.setInitialCrop = function() {
                var a = e.props,
                    r = a.initialCroppedAreaPixels,
                    o = a.cropSize;
                if (!!r) {
                    var c = za(r, e.mediaSize, o),
                        s = c.crop,
                        d = c.zoom;
                    e.props.onCropChange(s), e.props.onZoomChange && e.props.onZoomChange(d)
                }
            }, e.computeSizes = function() {
                var a, r, o, c, s, d, l = e.imageRef || e.videoRef;
                if (l && e.containerRef) {
                    e.containerRect = e.containerRef.getBoundingClientRect(), e.mediaSize = {
                        width: l.offsetWidth,
                        height: l.offsetHeight,
                        naturalWidth: ((a = e.imageRef) === null || a === void 0 ? void 0 : a.naturalWidth) || ((r = e.videoRef) === null || r === void 0 ? void 0 : r.videoWidth) || 0,
                        naturalHeight: ((o = e.imageRef) === null || o === void 0 ? void 0 : o.naturalHeight) || ((c = e.videoRef) === null || c === void 0 ? void 0 : c.videoHeight) || 0
                    };
                    var u = e.props.cropSize ? e.props.cropSize : La(l.offsetWidth, l.offsetHeight, e.containerRect.width, e.containerRect.height, e.props.aspect, e.props.rotation);
                    (((s = e.state.cropSize) === null || s === void 0 ? void 0 : s.height) !== u.height || ((d = e.state.cropSize) === null || d === void 0 ? void 0 : d.width) !== u.width) && e.props.onCropSizeChange && e.props.onCropSizeChange(u), e.setState({
                        cropSize: u
                    }, e.recomputeCropPosition)
                }
            }, e.onMouseDown = function(a) {
                a.preventDefault(), document.addEventListener("mousemove", e.onMouseMove), document.addEventListener("mouseup", e.onDragStopped), e.onDragStart(t.getMousePoint(a))
            }, e.onMouseMove = function(a) {
                return e.onDrag(t.getMousePoint(a))
            }, e.onTouchStart = function(a) {
                document.addEventListener("touchmove", e.onTouchMove, {
                    passive: !1
                }), document.addEventListener("touchend", e.onDragStopped), a.touches.length === 2 ? e.onPinchStart(a) : a.touches.length === 1 && e.onDragStart(t.getTouchPoint(a.touches[0]))
            }, e.onTouchMove = function(a) {
                a.preventDefault(), a.touches.length === 2 ? e.onPinchMove(a) : a.touches.length === 1 && e.onDrag(t.getTouchPoint(a.touches[0]))
            }, e.onDragStart = function(a) {
                var r, o, c = a.x,
                    s = a.y;
                e.dragStartPosition = {
                    x: c,
                    y: s
                }, e.dragStartCrop = _({}, e.props.crop), (o = (r = e.props).onInteractionStart) === null || o === void 0 || o.call(r)
            }, e.onDrag = function(a) {
                var r = a.x,
                    o = a.y;
                e.rafDragTimeout && window.cancelAnimationFrame(e.rafDragTimeout), e.rafDragTimeout = window.requestAnimationFrame(function() {
                    if (!!e.state.cropSize && !(r === void 0 || o === void 0)) {
                        var c = r - e.dragStartPosition.x,
                            s = o - e.dragStartPosition.y,
                            d = {
                                x: e.dragStartCrop.x + c,
                                y: e.dragStartCrop.y + s
                            },
                            l = e.props.restrictPosition ? Q(d, e.mediaSize, e.state.cropSize, e.props.zoom, e.props.rotation) : d;
                        e.props.onCropChange(l)
                    }
                })
            }, e.onDragStopped = function() {
                var a, r;
                e.cleanEvents(), e.emitCropData(), (r = (a = e.props).onInteractionEnd) === null || r === void 0 || r.call(a)
            }, e.onWheel = function(a) {
                a.preventDefault();
                var r = t.getMousePoint(a),
                    o = Aa(a).pixelY,
                    c = e.props.zoom - o * e.props.zoomSpeed / 200;
                e.setNewZoom(c, r), e.state.hasWheelJustStarted || e.setState({
                    hasWheelJustStarted: !0
                }, function() {
                    var s, d;
                    return (d = (s = e.props).onInteractionStart) === null || d === void 0 ? void 0 : d.call(s)
                }), e.wheelTimer && clearTimeout(e.wheelTimer), e.wheelTimer = window.setTimeout(function() {
                    return e.setState({
                        hasWheelJustStarted: !1
                    }, function() {
                        var s, d;
                        return (d = (s = e.props).onInteractionEnd) === null || d === void 0 ? void 0 : d.call(s)
                    })
                }, 250)
            }, e.getPointOnContainer = function(a) {
                var r = a.x,
                    o = a.y;
                if (!e.containerRect) throw new Error("The Cropper is not mounted");
                return {
                    x: e.containerRect.width / 2 - (r - e.containerRect.left),
                    y: e.containerRect.height / 2 - (o - e.containerRect.top)
                }
            }, e.getPointOnMedia = function(a) {
                var r = a.x,
                    o = a.y,
                    c = e.props,
                    s = c.crop,
                    d = c.zoom;
                return {
                    x: (r + s.x) / d,
                    y: (o + s.y) / d
                }
            }, e.setNewZoom = function(a, r) {
                if (!(!e.state.cropSize || !e.props.onZoomChange)) {
                    var o = e.getPointOnContainer(r),
                        c = e.getPointOnMedia(o),
                        s = Math.min(e.props.maxZoom, Math.max(a, e.props.minZoom)),
                        d = {
                            x: c.x * s - o.x,
                            y: c.y * s - o.y
                        },
                        l = e.props.restrictPosition ? Q(d, e.mediaSize, e.state.cropSize, s, e.props.rotation) : d;
                    e.props.onCropChange(l), e.props.onZoomChange(s)
                }
            }, e.getCropData = function() {
                if (!e.state.cropSize) return null;
                var a = e.props.restrictPosition ? Q(e.props.crop, e.mediaSize, e.state.cropSize, e.props.zoom, e.props.rotation) : e.props.crop;
                return Ra(a, e.mediaSize, e.state.cropSize, e.getAspect(), e.props.zoom, e.props.rotation, e.props.restrictPosition)
            }, e.emitCropData = function() {
                var a = e.getCropData();
                if (!!a) {
                    var r = a.croppedAreaPercentages,
                        o = a.croppedAreaPixels;
                    e.props.onCropComplete && e.props.onCropComplete(r, o), e.props.onCropAreaChange && e.props.onCropAreaChange(r, o)
                }
            }, e.emitCropAreaChange = function() {
                var a = e.getCropData();
                if (!!a) {
                    var r = a.croppedAreaPercentages,
                        o = a.croppedAreaPixels;
                    e.props.onCropAreaChange && e.props.onCropAreaChange(r, o)
                }
            }, e.recomputeCropPosition = function() {
                if (!!e.state.cropSize) {
                    var a = e.props.restrictPosition ? Q(e.props.crop, e.mediaSize, e.state.cropSize, e.props.zoom, e.props.rotation) : e.props.crop;
                    e.props.onCropChange(a), e.emitCropData()
                }
            }, e
        }
        return t.prototype.componentDidMount = function() {
            window.addEventListener("resize", this.computeSizes), this.containerRef && (this.props.zoomWithScroll && this.containerRef.addEventListener("wheel", this.onWheel, {
                passive: !1
            }), this.containerRef.addEventListener("gesturestart", this.preventZoomSafari), this.containerRef.addEventListener("gesturechange", this.preventZoomSafari)), this.props.disableAutomaticStylesInjection || (this.styleRef = document.createElement("style"), this.styleRef.setAttribute("type", "text/css"), this.styleRef.innerHTML = Ua, document.head.appendChild(this.styleRef)), this.imageRef && this.imageRef.complete && this.onMediaLoad()
        }, t.prototype.componentWillUnmount = function() {
            var e;
            window.removeEventListener("resize", this.computeSizes), this.containerRef && (this.containerRef.removeEventListener("gesturestart", this.preventZoomSafari), this.containerRef.removeEventListener("gesturechange", this.preventZoomSafari)), this.styleRef && ((e = this.styleRef.parentNode) === null || e === void 0 || e.removeChild(this.styleRef)), this.cleanEvents(), this.props.zoomWithScroll && this.clearScrollEvent()
        }, t.prototype.componentDidUpdate = function(e) {
            var a, r, o, c, s, d, l, u, h;
            e.rotation !== this.props.rotation ? (this.computeSizes(), this.recomputeCropPosition()) : e.aspect !== this.props.aspect ? this.computeSizes() : e.zoom !== this.props.zoom ? this.recomputeCropPosition() : ((a = e.cropSize) === null || a === void 0 ? void 0 : a.height) !== ((r = this.props.cropSize) === null || r === void 0 ? void 0 : r.height) || ((o = e.cropSize) === null || o === void 0 ? void 0 : o.width) !== ((c = this.props.cropSize) === null || c === void 0 ? void 0 : c.width) ? this.computeSizes() : (((s = e.crop) === null || s === void 0 ? void 0 : s.x) !== ((d = this.props.crop) === null || d === void 0 ? void 0 : d.x) || ((l = e.crop) === null || l === void 0 ? void 0 : l.y) !== ((u = this.props.crop) === null || u === void 0 ? void 0 : u.y)) && this.emitCropAreaChange(), e.zoomWithScroll !== this.props.zoomWithScroll && this.containerRef && (this.props.zoomWithScroll ? this.containerRef.addEventListener("wheel", this.onWheel, {
                passive: !1
            }) : this.clearScrollEvent()), e.video !== this.props.video && ((h = this.videoRef) === null || h === void 0 || h.load())
        }, t.prototype.getAspect = function() {
            var e = this.props,
                a = e.cropSize,
                r = e.aspect;
            return a ? a.width / a.height : r
        }, t.prototype.onPinchStart = function(e) {
            var a = t.getTouchPoint(e.touches[0]),
                r = t.getTouchPoint(e.touches[1]);
            this.lastPinchDistance = Te(a, r), this.lastPinchRotation = De(a, r), this.onDragStart(We(a, r))
        }, t.prototype.onPinchMove = function(e) {
            var a = this,
                r = t.getTouchPoint(e.touches[0]),
                o = t.getTouchPoint(e.touches[1]),
                c = We(r, o);
            this.onDrag(c), this.rafPinchTimeout && window.cancelAnimationFrame(this.rafPinchTimeout), this.rafPinchTimeout = window.requestAnimationFrame(function() {
                var s = Te(r, o),
                    d = a.props.zoom * (s / a.lastPinchDistance);
                a.setNewZoom(d, c), a.lastPinchDistance = s;
                var l = De(r, o),
                    u = a.props.rotation + (l - a.lastPinchRotation);
                a.props.onRotationChange && a.props.onRotationChange(u), a.lastPinchRotation = l
            })
        }, t.prototype.render = function() {
            var e = this,
                a = this.props,
                r = a.image,
                o = a.video,
                c = a.mediaProps,
                s = a.transform,
                d = a.crop,
                l = d.x,
                u = d.y,
                h = a.rotation,
                m = a.zoom,
                g = a.cropShape,
                R = a.showGrid,
                P = a.style,
                F = P.containerStyle,
                A = P.cropAreaStyle,
                T = P.mediaStyle,
                Z = a.classes,
                J = Z.containerClassName,
                ue = Z.cropAreaClassName,
                j = Z.mediaClassName,
                M = a.objectFit;
            return x.createElement("div", {
                onMouseDown: this.onMouseDown,
                onTouchStart: this.onTouchStart,
                ref: function(L) {
                    return e.containerRef = L
                },
                "data-testid": "container",
                style: F,
                className: te("reactEasyCrop_Container", J)
            }, r ? x.createElement("img", _({
                alt: "",
                className: te("reactEasyCrop_Image", M === "contain" && "reactEasyCrop_Contain", M === "horizontal-cover" && "reactEasyCrop_Cover_Horizontal", M === "vertical-cover" && "reactEasyCrop_Cover_Vertical", j)
            }, c, {
                src: r,
                ref: function(L) {
                    return e.imageRef = L
                },
                style: _(_({}, T), {
                    transform: s || "translate(" + l + "px, " + u + "px) rotate(" + h + "deg) scale(" + m + ")"
                }),
                onLoad: this.onMediaLoad
            })) : o && x.createElement("video", _({
                autoPlay: !0,
                loop: !0,
                muted: !0,
                className: te("reactEasyCrop_Video", M === "contain" && "reactEasyCrop_Contain", M === "horizontal-cover" && "reactEasyCrop_Cover_Horizontal", M === "vertical-cover" && "reactEasyCrop_Cover_Vertical", j)
            }, c, {
                ref: function(L) {
                    return e.videoRef = L
                },
                onLoadedMetadata: this.onMediaLoad,
                style: _(_({}, T), {
                    transform: s || "translate(" + l + "px, " + u + "px) rotate(" + h + "deg) scale(" + m + ")"
                }),
                controls: !1
            }), (Array.isArray(o) ? o : [{
                src: o
            }]).map(function(I) {
                return x.createElement("source", _({
                    key: I.src
                }, I))
            })), this.state.cropSize && x.createElement("div", {
                style: _(_({}, A), {
                    width: this.state.cropSize.width,
                    height: this.state.cropSize.height
                }),
                "data-testid": "cropper",
                className: te("reactEasyCrop_CropArea", g === "round" && "reactEasyCrop_CropAreaRound", R && "reactEasyCrop_CropAreaGrid", ue)
            }))
        }, t.defaultProps = {
            zoom: 1,
            rotation: 0,
            aspect: 4 / 3,
            maxZoom: Fa,
            minZoom: Oa,
            cropShape: "rect",
            objectFit: "contain",
            showGrid: !0,
            style: {},
            classes: {},
            mediaProps: {},
            zoomSpeed: 1,
            restrictPosition: !0,
            zoomWithScroll: !0
        }, t.getMousePoint = function(e) {
            return {
                x: Number(e.clientX),
                y: Number(e.clientY)
            }
        }, t.getTouchPoint = function(e) {
            return {
                x: Number(e.clientX),
                y: Number(e.clientY)
            }
        }, t
    }(x.Component),
    Za = Ha;
const Ce = [1, 2, 3, 4, 5, 6].map(n => oe.createPath(`/avatar/head${n}.png`, "img2"));
var ja = x.memo(function({
    value: t,
    onChange: e,
    className: a
}) {
    const r = S();
    f.exports.useEffect(() => {
        t || setTimeout(() => {
            e(Ce[0])
        }, 0)
    }, []);
    const o = Ce.map(c => i(Pt.button, {
        className: t === c ? "active" : "",
        onClick: () => e(c),
        children: i("img", {
            src: c
        })
    }, c));
    return i(At, {
        className: xe(Ba, a),
        label: r("user.default_avatar_select"),
        children: i("div", {
            className: "buttons",
            children: i(Lt, {
                trail: 100,
                children: o
            })
        })
    })
});
const Ba = "sn2u6yo";

function $a(n) {
    var t, e = n.naturalHeight,
        a = document.createElement("canvas");
    a.width = 1, a.height = e;
    var r = a.getContext("2d");
    r.drawImage(n, 0, 0);
    try {
        t = r.getImageData(0, 0, 1, e).data
    } catch (u) {
        return console.log("Cannot check verticalSquash: CORS?"), 1
    }
    for (var o = 0, c = e, s = e; s > o;) {
        var d = t[(s - 1) * 4 + 3];
        d === 0 ? c = s : o = s, s = c + o >> 1
    }
    var l = s / e;
    return l === 0 ? 1 : l
}

function Qe(n) {
    for (var t = atob(n.split(",")[1]), e = new ArrayBuffer(t.length), a = new Uint8Array(e), r = 0; r < t.length; r++) a[r] = t.charCodeAt(r);
    return e
}

function Va(n) {
    var t = n.split(",")[0].split(":")[1].split(";")[0],
        e = Qe(n);
    return new Blob([e], {
        type: t
    })
}

function Ga(n) {
    var t = new DataView(n);
    if (t.getUint16(0, !1) != 65496) return -2;
    for (var e = t.byteLength, a = 2; a < e;) {
        var r = t.getUint16(a, !1);
        if (a += 2, r == 65505) {
            if (t.getUint32(a += 2, !1) != 1165519206) return -1;
            var o = t.getUint16(a += 6, !1) == 18761;
            a += t.getUint32(a + 4, o);
            var c = t.getUint16(a, o);
            a += 2;
            for (var s = 0; s < c; s++)
                if (t.getUint16(a + s * 12, o) == 274) return t.getUint16(a + s * 12 + 8, o)
        } else {
            if ((r & 65280) != 65280) break;
            a += t.getUint16(a, !1)
        }
    }
    return -1
}

function Xa(n, t, e) {
    const a = n.width,
        r = n.height;
    switch (e > 4 && (n.width = r, n.height = a), e) {
        case 2:
            t.translate(a, 0), t.scale(-1, 1);
            break;
        case 3:
            t.translate(a, r), t.rotate(Math.PI);
            break;
        case 4:
            t.translate(0, r), t.scale(1, -1);
            break;
        case 5:
            t.rotate(.5 * Math.PI), t.scale(1, -1);
            break;
        case 6:
            t.rotate(.5 * Math.PI), t.translate(0, -r);
            break;
        case 7:
            t.rotate(.5 * Math.PI), t.translate(a, -r), t.scale(-1, 1);
            break;
        case 8:
            t.rotate(-.5 * Math.PI), t.translate(-a, 0);
            break
    }
}

function Ya(n) {
    return new Promise((t, e) => {
        const a = new FileReader;
        a.onload = function(r) {
            const o = new Image;
            o.onload = function() {
                const c = $a(o),
                    s = Ga(Qe(o.src)),
                    d = document.createElement("canvas"),
                    l = d.getContext("2d");
                let u = o.width,
                    h = o.height,
                    m;
                d.width = u, d.height = h, s > 0 && Xa(d, l, s), l.drawImage(o, 0, 0, u, h / c), /image\/jpeg/.test(n.type) || /image\/jpg/.test(n.type) ? m = d.toDataURL("image/jpeg", 1) : m = d.toDataURL(n.type);
                let g = Va(m);
                t(URL.createObjectURL(g))
            }, o.onerror = function() {
                t(URL.createObjectURL(n))
            }, o.src = r.target.result
        }, a.onerror = function() {
            e(n)
        }, a.readAsDataURL(n)
    })
}

function hn() {
    const n = S(),
        [t, e] = Ze({
            image: w.avatar,
            crop: {
                x: 0,
                y: 0
            },
            rotation: 0,
            zoom: 1,
            zoomSpeed: 3,
            minZoom: 1,
            maxZoom: 3
        }),
        a = f.exports.useRef(null),
        r = Ce.indexOf(t.image) != -1,
        o = f.exports.useCallback(m => e({
            image: m
        }), []),
        c = f.exports.useCallback(m => e({
            zoom: m
        }), []),
        s = f.exports.useCallback(m => e({
            crop: m
        }), []),
        d = f.exports.useCallback((m, g) => {
            a.current = g
        }, []),
        l = 300,
        u = f.exports.useCallback(m => {
            const g = l / Math.min(m.width, m.height);
            e({
                minZoom: g,
                maxZoom: g * 3,
                rotation: 0,
                zoom: g,
                zoomSpeed: g * 3
            })
        }, []),
        h = async () => {
            if (!!a.current) {
                if (r) await w.updateUserInfo({
                    avatar: t.image
                });
                else {
                    const m = await Qa(t.image, a.current, t.rotation);
                    await w.updateUserInfo({
                        file: m
                    })
                }
                H.back()
            }
        };
    return i(X, {
        title: n("user.edit_avatar"),
        nostyle: !0,
        children: p(ce, {
            className: en,
            children: [p("div", {
                className: "crop-area",
                "aria-disabled": r,
                children: [i(Za, {
                    classes: Ja,
                    image: t.image,
                    crop: t.crop,
                    rotation: t.rotation,
                    zoom: t.zoom,
                    minZoom: t.minZoom,
                    maxZoom: t.maxZoom,
                    zoomSpeed: t.zoomSpeed,
                    aspect: 1,
                    initialCroppedAreaPixels: {
                        width: l,
                        height: l,
                        x: 0,
                        y: 0
                    },
                    cropSize: {
                        width: l,
                        height: l
                    },
                    onCropChange: s,
                    onCropComplete: d,
                    onZoomChange: c,
                    onMediaLoaded: u
                }), i(qa, {
                    onChange: o
                }), p("div", {
                    className: "pan-info flex-center",
                    children: [i(y, {
                        name: "Gesture"
                    }), i("div", {
                        children: n("user.edit_avatar_pan")
                    })]
                })]
            }), p("div", {
                className: "wrap-box",
                children: [p("div", {
                    className: "edit-tools",
                    "aria-disabled": r,
                    children: [i(k, {
                        title: "ZoomOut 5%",
                        children: i("button", {
                            className: "scale",
                            onClick: () => {
                                c(Math.max(t.minZoom, t.zoom - .05))
                            },
                            children: i(y, {
                                name: "ZoomOut"
                            })
                        })
                    }), i(Rt, {
                        value: t.zoom,
                        min: t.minZoom,
                        max: t.maxZoom,
                        onChange: c
                    }), i(k, {
                        title: "ZoomIn 5%",
                        children: i("button", {
                            className: "scale",
                            onClick: () => {
                                c(Math.min(t.maxZoom, t.zoom + .05))
                            },
                            children: i(y, {
                                className: "zoomin",
                                name: "ZoomIn"
                            })
                        })
                    }), i(k, {
                        title: "Left rotate 90 degress counterclockwise",
                        children: i("button", {
                            onClick: () => e({
                                rotation: t.rotation - 45
                            }),
                            className: "rotate",
                            children: i(y, {
                                name: "Rotate"
                            })
                        })
                    }), i(k, {
                        title: "Right rotate 90 degress counterclockwise",
                        children: i("button", {
                            onClick: () => e({
                                rotation: t.rotation + 45
                            }),
                            className: "rotate",
                            children: i(y, {
                                className: "flip-x",
                                name: "Rotate"
                            })
                        })
                    })]
                }), i(ja, {
                    className: "avatar-selecter",
                    value: t.image,
                    onChange: o
                }), i(U, {
                    type: "conic",
                    onClick: h,
                    children: n("common.submit")
                })]
            })]
        })
    })
}
const Ja = {
        cropAreaClassName: "croped-area"
    },
    qa = x.memo(({
        onChange: n
    }) => {
        const t = f.exports.useRef(null);
        return p("button", {
            className: "upload flex-center",
            children: [i(y, {
                name: "Camera"
            }), i("input", {
                type: "file",
                onChange: a => {
                    if (!a.target.files) return;
                    const r = a.target.files[0];
                    if (!/\.(gif|jpg|jpeg|png|bmp|GIF|JPG|PNG)$/.test(r.name)) return C(new Error("Please upload the correct image format(gif,jpeg,jpg,png,bmp"));
                    !r || Ya(r).then(o => {
                        n(o), a.target.value = ""
                    }).catch(() => {
                        n(URL.createObjectURL(r)), a.target.value = ""
                    })
                },
                ref: t
            })]
        })
    });

function Ka(n) {
    return new Promise((t, e) => {
        const a = new Image;
        a.addEventListener("load", () => t(a)), a.addEventListener("error", r => e(r)), a.setAttribute("crossOrigin", "anonymous"), a.src = n
    })
}
async function Qa(n, t, e = 0) {
    const a = await Ka(n),
        r = document.createElement("canvas"),
        o = r.getContext("2d"),
        c = 2048,
        s = Math.max(a.width, a.height),
        d = Math.min(s, c);
    let l = 1;
    s > c && (l = new Tt(c).div(s).toNumber());
    const u = {
        width: a.width * l,
        height: a.height * l
    };
    r.width = d, r.height = d, o.translate(d / 2, d / 2), o.rotate(e * Math.PI / 180), o.translate(-d / 2, -d / 2);
    const h = {
        x: d / 2 - u.width * .5,
        y: d / 2 - u.height * .5
    };
    o.drawImage(a, h.x, h.y, u.width, u.height);
    const m = o.getImageData(0, 0, d, d);
    return r.width = t.width * l, r.height = t.height * l, o.putImageData(m, Math.round(0 - h.x - l * t.x), Math.round(0 - h.y - l * t.y)), new Promise(g => {
        r.toBlob(R => {
            g(R)
        }, "image/jpeg", .8)
    })
}
O({
    cl1: ["#e3e3e3", "#5f6975"],
    cl2: ["#000c", "#fffc"],
    cl3: [v("#31343c", .4), "#fff"],
    cl4: ["#0003", v("#f5f6fa", .5)],
    cl5: ["transparent", "#5f6975"],
    cl6: ["#d8d8d8", "#5f6975"]
});
const en = "sipq8jq",
    ze = "Interface not implemented",
    W = {
        isIOS: !1,
        isAndroid: !1,
        isNative: !1,
        setTitle(n) {
            console.error(ze)
        },
        downloadFile(n, t) {
            console.error(ze)
        }
    };
let tn = navigator.userAgent.search("tgpro") !== -1;
const E = window;

function an(n) {
    if (E.WebViewJavascriptBridge) return n(E.WebViewJavascriptBridge);
    if (E.WVJBCallbacks) return E.WVJBCallbacks.push(n);
    E.WVJBCallbacks = [n];
    var t = document.createElement("iframe");
    t.style.display = "none", t.src = "https://__bridge_loaded__", document.documentElement.appendChild(t), setTimeout(function() {
        document.documentElement.removeChild(t)
    }, 0)
}
E.bc ? (W.isNative = !0, W.isAndroid = !0, Object.assign(W, {
    setTitle(n) {
        E.bc && E.bc.setTitle(n)
    },
    downloadFile(n, t) {
        E.bc && E.bc.downloadFile(n, t)
    }
})) : tn && (W.isNative = !0, W.isIOS = !0, an(n => {
    Object.assign(W, {
        setTitle(t) {
            n.callHandler("setTitle", t)
        },
        downloadFile(t, e) {
            n.callHandler("downloadFile", JSON.stringify({
                filename: t,
                data: e
            }))
        }
    })
}));
const nn = G(function() {
        const t = W.isNative,
            e = "invite.png",
            a = S(),
            [r, o] = Ze({
                url: "",
                blobURL: "",
                link: ""
            }),
            c = () => {
                try {
                    He(r.link), C(a("common.messages.copy_success"))
                } catch (l) {
                    C(l)
                }
            };
        f.exports.useEffect(() => {
            s();
            const l = oe.isDarken ? "?theme=b" : "?theme=w",
                u = zt.getApiURL("/game/support/invitation/task/" + l);
            d(u)
        }, []);
        const s = async () => {
                try {
                    const l = await w.getInviteUrl();
                    o({
                        link: l.invitationUrl
                    })
                } catch (l) {
                    C(l)
                }
            },
            d = async l => {
                const u = await Dt.get(l, {
                    withCredentials: !0,
                    responseType: "arraybuffer"
                });
                let h = new Blob([u.data], {
                        type: "image/png"
                    }),
                    m = URL.createObjectURL(h);
                o({
                    blobURL: m
                })
            };
        return p("div", {
            className: rn,
            children: [i("img", {
                alt: "invite",
                src: r.blobURL
            }), i(Wt, {
                onClick: () => _e.close()
            }), p("div", {
                className: "btn-wrap",
                children: [i(U, {
                    type: "conic2",
                    onClick: c,
                    children: a("page.user.copy_invite")
                }), t ? i(U, {
                    type: "conic",
                    children: a("page.user.down_invite")
                }) : oe.isIOS ? i(U, {
                    type: "conic",
                    children: a("page.user.down_invite")
                }) : i("a", {
                    href: r.blobURL,
                    download: e,
                    children: i(U, {
                        type: "conic",
                        children: a("page.user.down_invite")
                    })
                })]
            })]
        })
    }),
    rn = "i1blj8mm";
var mn = nn;
export {
    hn as EditAvatar, pn as EditNickName, mn as Invite, dn as UserAchieve, un as UserProfile, ln as UserRain
};
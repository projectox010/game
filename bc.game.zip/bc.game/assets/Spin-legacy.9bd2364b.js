! function() {
    var e = document.createElement("style");
    e.innerHTML = '.s1aophl7{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;height:4.375rem}@-webkit-keyframes aniBlink-s1aophl7{70%{margin-left:-200px}to{margin-left:200px}}@keyframes aniBlink-s1aophl7{70%{margin-left:-200px}to{margin-left:200px}}.s1aophl7 .tab-nav{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;width:12.625rem;height:100%;background-color:#151617;border-radius:.75rem;padding:.25rem}.s1aophl7 .tab-nav .ui-button{width:3.875rem;height:3.875rem;border-radius:.625rem}.s1aophl7 .tab-nav .ui-button img{width:3rem;height:3.4375rem;display:inline-block;vertical-align:top;margin:.3125rem .5625rem}.s1aophl7 .tag-wrap{background-color:#151617;height:100%;width:11.75rem;padding:.25rem;border-radius:.75rem}.s1aophl7 .tag-wrap .tag{width:11.25rem;height:3.875rem;border-radius:.625rem;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;padding:.5rem 0;position:relative;overflow:hidden}.s1aophl7 .tag-wrap .tag-img{width:8.75rem;height:1.875rem;margin:0 auto;position:relative;text-align:center;line-height:1.625rem;background:url(/assets/tag.757e5cbe.png) no-repeat;background-size:100% 100%;font-weight:800;font-size:1rem}.s1aophl7 .tag-wrap .tag .desc{color:#fff;width:100%;text-align:center;margin-top:-.1875rem;font-weight:800}.s1aophl7 .tag-wrap .tag.active:before{content:"";top:0;position:absolute;width:3.75rem;height:100%;margin-top:0;margin-left:-200px;z-index:6;overflow:hidden;background:-webkit-gradient(linear,left top,right top,color-stop(0%,rgba(255,255,255,0)),color-stop(50%,rgba(255,255,255,.2)),color-stop(100%,rgba(255,255,255,0)));-webkit-transform:skewX(-25deg);-ms-transform:skewX(-25deg);transform:skew(-25deg);-webkit-animation:aniBlink-s1aophl7 8.5s;animation:aniBlink-s1aophl7 8.5s}@media screen and (max-width:621px){.s1aophl7 .tag-wrap{width:10.875rem}.s1aophl7 .tag-wrap .tag{width:10.375rem}}.s3ew4v3{margin-top:1.6875rem;background-color:#151617;border-radius:1.25rem;padding:.625rem;height:5.8125rem;box-sizing:border-box}.s3ew4v3 .share-bottom{height:1.25rem;line-height:1.25rem;position:relative;text-align:center}.s3ew4v3 .share-bottom .word{display:inline-block;padding:0 .3125rem;background-color:#151617;position:relative;font-size:.75rem;z-index:11}.s3ew4v3 .share-cont{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;margin-top:1.0625rem}.s3ew4v3 .share-cont a{margin:0 .3125rem}.s3ew4v3 .share-cont a.disabled{opacity:.5}.s1w718k2{padding:0 .25rem;border-radius:1.25rem;background-image:linear-gradient(147deg,#ffa43b -78%,#191a1b 30%);box-sizing:border-box;position:relative;min-width:21.5625rem;min-height:29.6875rem;text-align:center}@-webkit-keyframes imgScale-s1w718k2{0%{-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0)}to{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}}@keyframes imgScale-s1w718k2{0%{-webkit-transform:scale(0);-ms-transform:scale(0);transform:scale(0)}to{-webkit-transform:scale(1);-ms-transform:scale(1);transform:scale(1)}}@-webkit-keyframes bounceIn-s1w718k2{0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;-webkit-transform:scale3d(.3,.3,.3);-ms-transform:scale3d(.3,.3,.3);transform:scale3d(.3,.3,.3)}20%{-webkit-transform:scale3d(1.1,1.1,1.1);-ms-transform:scale3d(1.1,1.1,1.1);transform:scale3d(1.1,1.1,1.1)}40%{-webkit-transform:scale3d(.9,.9,.9);-ms-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9)}60%{opacity:1;-webkit-transform:scale3d(1.03,1.03,1.03);-ms-transform:scale3d(1.03,1.03,1.03);transform:scale3d(1.03,1.03,1.03)}80%{-webkit-transform:scale3d(.97,.97,.97);-ms-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97)}to{opacity:1;-webkit-transform:scale3d(1,1,1);-ms-transform:scale3d(1,1,1);transform:scaleZ(1)}}@keyframes bounceIn-s1w718k2{0%,20%,40%,60%,80%,to{-webkit-animation-timing-function:cubic-bezier(.215,.61,.355,1);animation-timing-function:cubic-bezier(.215,.61,.355,1)}0%{opacity:0;-webkit-transform:scale3d(.3,.3,.3);-ms-transform:scale3d(.3,.3,.3);transform:scale3d(.3,.3,.3)}20%{-webkit-transform:scale3d(1.1,1.1,1.1);-ms-transform:scale3d(1.1,1.1,1.1);transform:scale3d(1.1,1.1,1.1)}40%{-webkit-transform:scale3d(.9,.9,.9);-ms-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9)}60%{opacity:1;-webkit-transform:scale3d(1.03,1.03,1.03);-ms-transform:scale3d(1.03,1.03,1.03);transform:scale3d(1.03,1.03,1.03)}80%{-webkit-transform:scale3d(.97,.97,.97);-ms-transform:scale3d(.97,.97,.97);transform:scale3d(.97,.97,.97)}to{opacity:1;-webkit-transform:scale3d(1,1,1);-ms-transform:scale3d(1,1,1);transform:scaleZ(1)}}.s1w718k2 .img-cont{width:14.375rem;height:14.375rem;position:relative;margin:0 auto}.s1w718k2 .img-cont .bg{position:absolute;width:14.375rem;left:0;top:0;-webkit-animation:imgScale-s1w718k2 .3s linear both;animation:imgScale-s1w718k2 .3s linear both}.s1w718k2 .img-cont .img{opacity:0;position:absolute;width:11.25rem;top:4.375rem;left:1.5625rem;-webkit-animation:bounceIn-s1w718k2 1s linear both;animation:bounceIn-s1w718k2 1s linear both;-webkit-animation-delay:.3s;animation-delay:.3s}.s1w718k2 .btn-wrap{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;width:15.875rem;margin:0 auto}.s1w718k2 .btn-wrap .collect{width:10.9375rem;height:3rem}.s1w718k2 .btn-wrap .share-local{width:4.6875rem;height:3rem;margin-left:.25rem;background-image:none;background-color:#6b7180}.s1w718k2 .btn-wrap .share-local .icon{fill:#fff}.s1w718k2 .cont{width:16.25rem;line-height:3rem;margin:0 auto 1.5rem;text-align:center;height:3rem;border-radius:.9375rem;background-color:rgba(15,16,17,.5);font-size:1.125rem;color:#5ddb1c;font-weight:800;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.s1w718k2 .cont .coin-icon{width:1.5rem;height:1.5rem;margin-right:.5rem}.s1w718k2 .cont .currency{color:#fff;margin-left:.5rem}.s1w718k2 .loading,.s1w718k2 .empty{display:none}@media screen and (max-width:621px){.s1w718k2{padding:0 .625rem .625rem}}.st4nmvc{position:absolute;width:21.75rem;height:21.75rem;left:0;top:0}@-webkit-keyframes lightRot-st4nmvc{0%{-webkit-transform:rotate(22.5deg);-ms-transform:rotate(22.5deg);transform:rotate(22.5deg)}50%{-webkit-transform:rotate(22.5deg);-ms-transform:rotate(22.5deg);transform:rotate(22.5deg)}50.1%{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0)}}@keyframes lightRot-st4nmvc{0%{-webkit-transform:rotate(22.5deg);-ms-transform:rotate(22.5deg);transform:rotate(22.5deg)}50%{-webkit-transform:rotate(22.5deg);-ms-transform:rotate(22.5deg);transform:rotate(22.5deg)}50.1%{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0)}to{-webkit-transform:rotate(0);-ms-transform:rotate(0);transform:rotate(0)}}.st4nmvc .spin-img{position:absolute;width:21.75rem;height:21.75rem;left:0;top:0}.st4nmvc .diamond-cont{position:absolute;width:21.75rem;height:21.75rem;left:0;top:0;z-index:4}.st4nmvc .spin-light{position:absolute;width:21.75rem;height:21.75rem;z-index:1;left:0;top:0}.st4nmvc .spin-light.active{-webkit-animation:lightRot-st4nmvc 2s none infinite;animation:lightRot-st4nmvc 2s none infinite}.st4nmvc .spin-item{position:absolute;height:1.5rem;width:5.5rem;top:50%;left:50%;line-height:1.5rem;margin-top:-.75rem;-webkit-transform-origin:-3.8125rem center;-ms-transform-origin:-3.8125rem center;transform-origin:-3.8125rem center;margin-left:3.875rem;color:#fff;font-size:.9375rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}.st4nmvc .spin-item .amount{-webkit-flex:auto;-ms-flex:auto;flex:auto}.st4nmvc .spin-item .icon{position:absolute;right:-.3125rem;top:-.3125rem;fill:#fff;opacity:.7;height:.6875rem;width:.6875rem;border-radius:.6875rem}.st4nmvc .spin-item .coin-icon{height:1.5rem;width:1.5rem}.s1zzacp{position:absolute;width:21.75rem;height:21.75rem;left:0;top:0}.s1zzacp .point-img{position:absolute;height:5.59375rem;right:-1.90625rem;top:8.0625rem;width:10rem;-webkit-transform-origin:left center;-ms-transform-origin:left center;transform-origin:left center}.s1zzacp .point-img .light-wrap{overflow:hidden;position:absolute;width:6.875rem;height:3.75rem;top:.9375rem}.s1zzacp .point-img .point-light{top:1.125rem;left:-1.875rem;position:absolute;width:.9375rem;height:1.25rem;z-index:6;overflow:hidden;background:-webkit-gradient(linear,left top,right top,color-stop(0%,rgba(255,255,255,0)),color-stop(50%,rgba(255,255,255,.2)),color-stop(100%,rgba(255,255,255,0)));-webkit-transform:skewX(-25deg);-ms-transform:skewX(-25deg);transform:skew(-25deg)}.s1zzacp .point-img img{width:100%;height:100%}.szbrnh5{width:21.75rem;height:28.4375rem;position:relative;margin:1.875rem auto 1.25rem;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none}@-webkit-keyframes pulse-szbrnh5{0%{-webkit-transform:rotate(-5deg) scale3d(1,1,1);-ms-transform:rotate(-5deg) scale3d(1,1,1);transform:rotate(-5deg) scaleZ(1)}50%{-webkit-transform:rotate(0deg) scale3d(1.1,1.1,1.1);-ms-transform:rotate(0deg) scale3d(1.1,1.1,1.1);transform:rotate(0) scale3d(1.1,1.1,1.1)}to{-webkit-transform:rotate(-5deg) scale3d(1,1,1);-ms-transform:rotate(-5deg) scale3d(1,1,1);transform:rotate(-5deg) scaleZ(1)}}@keyframes pulse-szbrnh5{0%{-webkit-transform:rotate(-5deg) scale3d(1,1,1);-ms-transform:rotate(-5deg) scale3d(1,1,1);transform:rotate(-5deg) scaleZ(1)}50%{-webkit-transform:rotate(0deg) scale3d(1.1,1.1,1.1);-ms-transform:rotate(0deg) scale3d(1.1,1.1,1.1);transform:rotate(0) scale3d(1.1,1.1,1.1)}to{-webkit-transform:rotate(-5deg) scale3d(1,1,1);-ms-transform:rotate(-5deg) scale3d(1,1,1);transform:rotate(-5deg) scaleZ(1)}}.szbrnh5 .btn-img{position:absolute;width:6.5rem;height:6.5rem;top:7.625rem;left:7.625rem;cursor:pointer}.szbrnh5 .btn-img .spin-particles{position:absolute;width:5.5rem;height:5.5rem;border-radius:2.75rem;overflow:hidden;top:0;left:.5rem}.szbrnh5 .btn-img .btn-txt{position:absolute;width:5.5rem;height:3.5rem;top:1.5625rem;left:.5rem}.szbrnh5 .btn-img:not(.loading) .btn-txt{-webkit-animation:pulse-szbrnh5 2s infinite linear;animation:pulse-szbrnh5 2s infinite linear}.szbrnh5 .btn-img img{width:100%;height:100%}.szbrnh5 .banner-img{position:absolute;height:5.3125rem;width:21.25rem;left:.25rem;top:19.625rem}.szbrnh5 .banner-img img{width:100%;height:100%;display:inline-block;vertical-align:top}.szbrnh5 .btn{position:absolute;width:15rem;left:3.75rem;bottom:0}.s8knv0f{text-align:center;width:26.5rem;height:43.75rem;position:absolute;z-index:1;top:50%;left:50%;margin-left:-13.25rem;margin-top:-21.875rem;border-radius:1.25rem;padding:.625rem;background-image:linear-gradient(to bottom,#17181b,#17181b);-webkit-transform:translate3d(50%,0,0);-ms-transform:translate3d(50%,0,0);transform:translate3d(50%,0,0);-webkit-transition:all .2s;transition:all .2s;opacity:0}.s8knv0f.enter{-webkit-transition:all .2s;transition:all .2s;-webkit-transform:translate3d(0,0,0);-ms-transform:translate3d(0,0,0);transform:translateZ(0);opacity:1}.s8knv0f p{margin:0}.s8knv0f .winlist-wrap{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;height:100%;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column}.s8knv0f .win-list{margin-top:1rem;margin-bottom:.125rem;-webkit-flex:1;-ms-flex:1;flex:1;border-radius:16px;background-color:#1e2024;overflow:hidden}.s8knv0f .win-list .td{width:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center}.s8knv0f .win-list .td p{width:30%;padding:.875rem .75rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;text-align:center}.s8knv0f .win-list .td p:first-of-type{text-align:left}.s8knv0f .win-list .td p:last-of-type{width:40%;text-align:right}.s8knv0f .pop-control{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}.s8knv0f .pop-control .back{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1);margin:.375rem}.s8knv0f .crown{width:2.9375rem}.s8knv0f .spin-bonus{height:1.375rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;font-size:1.125rem;font-weight:800;color:#fff}.s8knv0f .spin-bonus .tit{margin:0 .3125rem}.s8knv0f .spin-bonus img{height:100%}.s8knv0f .spin-bonus img.suf-img{-webkit-transform:scaleX(-1);-ms-transform:scaleX(-1);transform:scaleX(-1)}.s8knv0f .table-header{width:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex}.s8knv0f .table-header p{padding:.875rem .75rem}.s8knv0f .winlist-swiper{width:100%;height:100%}.s8knv0f .winlist-swiper .swiper-slide{height:2.125rem}.s8knv0f .winlist-swiper .swiper-slide .name{color:#fff;font-weight:800}.s8knv0f .winlist-swiper .swiper-slide .amount{color:#8ac934}.sydmigf{height:6.25rem;background-color:#151617;border-radius:.75rem;padding:.25rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;color:#767b81}.sydmigf .left-cont{background-color:#191a1b;border-radius:.625rem;width:10rem;-webkit-align-self:stretch;-ms-flex-item-align:stretch;align-self:stretch;text-align:center}.sydmigf .left-cont .tit{font-size:.75rem;line-height:.75rem;height:.75rem;margin-top:2rem}.sydmigf .left-cont .amount{color:#e9d317;font-size:1.1875rem;line-height:1.1875rem;height:1.1875rem;font-weight:800;margin-top:.3125rem}.sydmigf .right-cont{background-color:#191a1b;border-radius:.625rem;-webkit-flex:auto;-ms-flex:auto;flex:auto;margin-left:.25rem;-webkit-align-self:stretch;-ms-flex-item-align:stretch;align-self:stretch;position:relative;overflow:hidden;cursor:pointer}.sydmigf .right-cont .data-cont{padding:.625rem 1.5625rem 0 3.75rem;width:100%;height:5.75rem}.sydmigf .right-cont .data-cont .icon{height:1.25rem;position:absolute;top:2.25rem;right:.3125rem}.sydmigf .right-cont .data-cont .avatar{position:absolute;top:.9375rem;width:1.75rem;height:1.75rem;border-radius:.875rem;left:1rem}.sydmigf .right-cont .data-cont .cont .name{color:#94a3c8;font-size:.9375rem}.sydmigf .right-cont .data-cont .cont .win{white-space:nowrap}.sydmigf .right-cont .data-cont .cont .win .amount{color:#45cb1d}.sydmigf .right-cont .data-cont .cont .win .currency{color:#fff}.sydmigf .right-cont .data-cont .cont .type b{color:#f1905c}@media screen and (max-width:621px){.sydmigf .left-cont{width:9.375rem}}.sy6yjq0{position:relative;width:424px;height:43.75rem;border-radius:1.25rem;padding:.75rem;background-image:linear-gradient(8deg,#31343c -16%,#1e2025 -5%,#1e2025 6%,#1d2024 40%,#1e2025 74%,#1e2025 113%)}.sy6yjq0 .close{position:absolute;right:-1.25rem;top:-1.25rem;width:2.5rem;height:2.5rem;border-radius:1.25rem;z-index:10;background-color:#1d2024}.sy6yjq0 .bg-a{width:14.375rem;height:16.5625rem;opacity:.65;-webkit-filter:blur(26px);filter:blur(26px);background-image:radial-gradient(circle at 50% 50%,rgba(7,250,218,.35),rgba(0,0,0,0) 76%);position:absolute;top:4.375rem;right:0}.sy6yjq0 .bg-b{width:12.5rem;height:15rem;top:15.3125rem;left:0;opacity:.65;position:absolute;-webkit-filter:blur(26px);filter:blur(26px);background-image:radial-gradient(circle at 50% 50%,rgba(217,21,255,.6),rgba(0,0,0,0) 75%)}.sy6yjq0 .pre_btn{width:3.125rem;height:3.125rem;position:absolute;left:0;top:21.875rem;z-index:9}.sy6yjq0 .pre_btn .btn-wrap{width:1.375rem;height:1.375rem;border-radius:.6875rem;background-color:rgba(255,255,255,.05);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.sy6yjq0 .pre_btn .btn-wrap .icon{-webkit-transform:rotate(180deg);-ms-transform:rotate(180deg);transform:rotate(180deg);width:.75rem;fill:#fff}.sy6yjq0 .suff_btn{width:3.125rem;height:3.125rem;position:absolute;right:0;top:21.875rem;z-index:9}.sy6yjq0 .suff_btn .btn-wrap{width:1.375rem;height:1.375rem;border-radius:.6875rem;background-color:rgba(255,255,255,.05);display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center}.sy6yjq0 .suff_btn .btn-wrap .icon{width:.75rem;fill:#fff}@media screen and (max-width:621px){.sy6yjq0{width:25rem;padding:.625rem}}\n', document.head.appendChild(e), System.register(["./index-legacy.1416f96c.js"], (function(e, t) {
        "use strict";
        var i, r, n, a, s, o, l, c, m, d, f, p, g, b, h, u, w, k, y, x, v, N, z, j, S, _, T, C, B, I, L, E, A, q, M, R, X, P, U, F, Z, O, $, G, D, H, J, V, W, Y, K, Q, ee, te, ie, re;
        return {
            setters: [function(e) {
                i = e.a5, r = e.u, n = e.aY, a = e.cb, s = e.j, o = e.a, l = e.cX, c = e.b, m = e.cY, d = e.l, f = e.cZ, p = e.as, g = e.at, b = e.r, h = e.e, u = e.c_, w = e.z, k = e.bs, y = e.J, x = e.p, v = e.A, N = e.N, z = e.O, j = e.cU, S = e.$, _ = e.G, T = e.k, C = e.c$, B = e.d0, I = e.d1, L = e.d2, E = e.d3, A = e.d4, q = e.d5, M = e.d6, R = e.g, X = e.d7, P = e.aO, U = e.F, F = e.o, Z = e.ao, O = e.d, $ = e.m, G = e.b1, D = e.d8, H = e.bI, J = e.bJ, V = e.d9, W = e.da, Y = e.M, K = e.a4, Q = e.a3, ee = e.K, te = e.aV, ie = e.db, re = e.s
            }],
            execute: function() {
                e("default", (function() {
                    const [e, t] = b.exports.useState(!0);
                    return b.exports.useEffect((() => (n.initReq().then((() => t(!1))), () => {
                        n.reset()
                    })), []), s("div", {
                        className: Ce,
                        children: [o("button", {
                            onClick: () => x.back(),
                            className: "close flex-center",
                            children: o(v, {
                                name: "Close"
                            })
                        }), o("div", {
                            className: "bg-a"
                        }), o("div", {
                            className: "bg-b"
                        }), e && o(Q, {}), !e && o(Te, {})]
                    })
                }));
                const ne = i.memo((function({
                        tab: e,
                        onTab: t,
                        level: i,
                        updateFinished: p
                    }) {
                        const g = r(),
                            b = n.tabs,
                            h = a.find((t => t[4] === e)) || a[0],
                            u = e <= 1 && 0 === i ? 0 : h[0];
                        return s("div", {
                            className: ae,
                            children: [o("div", {
                                className: "tab-nav",
                                children: [{
                                    active: l.tbtn_luckspin_2,
                                    default: l.tbtn_luckspin_1,
                                    value: 0
                                }, {
                                    active: l.tbtn_superspin_2,
                                    default: l.tbtn_superspin_1,
                                    value: 1
                                }, {
                                    active: l.tbtn_megaspin_2,
                                    default: l.tbtn_megaspin_1,
                                    value: 2
                                }].map((i => s(c, {
                                    style: {
                                        backgroundColor: e === b[i.value] ? m(e) : "#191a1b"
                                    },
                                    onClick: () => t(b[i.value]),
                                    children: [e != b[i.value] && o("img", {
                                        src: i.default
                                    }), e === b[i.value] && o("img", {
                                        src: i.active
                                    })]
                                }, i.value)))
                            }), o("div", {
                                className: "tag-wrap",
                                children: s("div", {
                                    className: d("tag", p && "active"),
                                    style: {
                                        backgroundColor: m(e)
                                    },
                                    children: [o("div", {
                                        className: "tag-img",
                                        style: {
                                            color: m(e)
                                        },
                                        children: f(h[4])
                                    }), o("div", {
                                        className: "desc",
                                        children: g("page.spin.level_above", String(u))
                                    })]
                                })
                            })]
                        })
                    })),
                    ae = "s1aophl7";
                const se = p((() => g((() => t.import("./SpinResultParticles-legacy.d2bd023e.js")), void 0)));

                function oe() {
                    const e = Math.floor(3 * Math.random());
                    return 0 === e ? "I got free Crypto from BC.GAME free daily spin! Try your luck now! Free spin to get 5 BTC!" : 1 === e ? "Wow! I won free crypto from daily free spin at BC.GAME! Try your luck now! Free spin to get 5 BTC!" : "I got lucky at BC.GAME free Lucky Spin today! Try your luck now! Free spin to get 5 BTC!"
                }

                function le() {
                    const e = r(),
                        {
                            data: t
                        } = N((() => z({
                            title: "Spin",
                            content: oe()
                        })));
                    if (!t) return o("div", {
                        className: ce
                    });
                    const i = t.filter((e => e.src));
                    return s("div", {
                        className: ce,
                        children: [o("div", {
                            className: "share-bottom",
                            children: o("div", {
                                className: "word",
                                children: e("page.share.share_social")
                            })
                        }), o("div", {
                            className: "share-cont",
                            children: i.slice(0, 6).map(((e, t) => o("a", {
                                href: e.src,
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: d("share-item", t > 2 && "disabled"),
                                children: o("img", {
                                    className: "icon",
                                    src: e.icon
                                })
                            }, t)))
                        })]
                    })
                }
                const ce = "s3ew4v3";

                function me({
                    amount: e,
                    currencyName: t,
                    locked: i,
                    level: a,
                    trackId: m,
                    bigPrize: f
                }) {
                    const p = r(),
                        [g, N] = b.exports.useState(!1),
                        z = h();
                    return s("div", {
                        className: de,
                        children: [o(se, {
                            bigPrize: f
                        }), s("div", {
                            className: "img-cont",
                            children: [o("img", {
                                className: "bg",
                                src: l.bg_lottery,
                                alt: ""
                            }), o("img", {
                                className: "img",
                                src: u(n.getTab(a)),
                                alt: ""
                            })]
                        }), s("div", {
                            className: d("cont", i && "locked"),
                            children: [o(w, {
                                name: t
                            }), "+ ", k(e, 5), s("span", {
                                className: "currency",
                                children: [i && "Locked", " ", y.getAlias(t)]
                            })]
                        }), s("div", {
                            className: "btn-wrap",
                            children: [o(c, {
                                className: "collect",
                                type: "conic",
                                onClick: () => {
                                    i ? (x.close(), setTimeout((() => {
                                        z("/bonus_dashboard")
                                    }), 50)) : x.back(), n.soundSprites.play("Collect")
                                },
                                children: i ? p("common.actions.view_my", "BCD") : p("common.actions.collect_now")
                            }), o(c, {
                                onClick: async function() {
                                    const e = j.currentRoom.id,
                                        t = p("page.share.success");
                                    if (await x.confirm(p("page.share.room") + "?")) return S.post("/activity/lucky/spin/share/", {
                                        trackId: m,
                                        roomId: e
                                    }).then((() => {
                                        _(t), N(!0)
                                    }))
                                },
                                disabled: g,
                                className: "share-local",
                                children: o(v, {
                                    name: "Share"
                                })
                            })]
                        }), o(le, {})]
                    })
                }
                const de = "s1w718k2";
                p((async () => (await A(1e3), g((() => t.import("./SpinBtnParticles-legacy.b5589cf3.js")), void 0))));
                const fe = "st4nmvc";
                const pe = {
                        from: {
                            opacity: 0,
                            scale: .3,
                            rotate: -30
                        },
                        to: {
                            opacity: 1,
                            scale: 1,
                            rotate: 0
                        }
                    },
                    ge = {
                        from: {
                            y: -50,
                            opacity: 0,
                            scale: .3
                        },
                        to: {
                            y: 0,
                            opacity: 1,
                            scale: 1
                        }
                    };

                function be(e, t) {
                    let i = 360;
                    if (e > 0 && t.current) {
                        const r = t.current.style.transform.match(/\d+/),
                            n = r ? r[0] : 0;
                        i = 360 - 22.5 * e + 360 * (Math.ceil(Number(n) / 360) + 5)
                    }
                    return i
                }
                const he = i.memo((function({
                        level: e,
                        res: t,
                        loading: i,
                        update: r,
                        onSpin: a
                    }) {
                        const c = b.exports.useRef(null),
                            m = b.exports.useRef(null),
                            f = b.exports.useRef(null),
                            p = n.spinOptions[e],
                            [g, h] = R((() => pe)),
                            [u, y] = R((() => ge)),
                            {
                                spinPoint: x,
                                spinMain: N,
                                spinBtn: z,
                                spinBanner: j
                            } = function(e, t, i, r, a) {
                                const c = n.getTab(e),
                                    m = q(),
                                    f = M(a.length, {
                                        ref: m,
                                        config: {
                                            mass: 1,
                                            tension: 1e3,
                                            friction: 26
                                        },
                                        opacity: i ? 0 : 1,
                                        height: i ? 0 : 24,
                                        x: i ? 0 : 20,
                                        from: {
                                            opacity: 1,
                                            height: 24,
                                            x: 0
                                        }
                                    }),
                                    p = q(),
                                    g = R({
                                        ref: p,
                                        opacity: i ? 0 : 1,
                                        scale: i ? .3 : 1,
                                        rotate: i ? -30 : 0
                                    }),
                                    b = q(),
                                    h = R({
                                        ref: b,
                                        scale: i ? 2 : 1,
                                        opacity: i ? 0 : 1,
                                        onChange: e => {
                                            e.value.opacity < .01 && n.levelUpdateFinished()
                                        }
                                    }),
                                    u = q(),
                                    y = R({
                                        ref: u,
                                        opacity: i ? 0 : 1,
                                        y: i ? -100 : 0
                                    }),
                                    x = q(),
                                    N = R({
                                        ref: x,
                                        opacity: i ? 0 : 1,
                                        scale: i ? 1.5 : 1
                                    });
                                return X(i ? [m, x, p, u, b] : [b, p, m, x, u], i ? [0, .6, 1, 1.2, 1.4] : [0, .4, .6, 1, 1.4]), {
                                    spinPoint: o(T.img, {
                                        style: N,
                                        src: C(e),
                                        alt: ""
                                    }),
                                    spinMain: s(T.div, {
                                        className: fe,
                                        style: g,
                                        children: [o("img", {
                                            className: d("spin-light", !t && !i && "active"),
                                            src: l.spinLight3,
                                            alt: ""
                                        }), o("img", {
                                            className: "spin-img",
                                            src: B(e),
                                            alt: ""
                                        }), 5 === e && o("img", {
                                            className: "diamond-cont",
                                            src: l.spin_diamond_fuck,
                                            alt: ""
                                        }), f.map(((e, t) => s(T.div, {
                                            className: "spin-item",
                                            style: {
                                                opacity: e.opacity,
                                                height: e.height,
                                                transform: `rotate(${22.5*t}deg)`
                                            },
                                            children: [o("span", {
                                                className: "amount",
                                                children: k(a[t].amount, 5)
                                            }), o(w, {
                                                name: a[t].currencyName
                                            }), a[t].locked && o(v, {
                                                name: "Locked"
                                            })]
                                        }, t)))]
                                    }),
                                    spinBtn: s(T.div, {
                                        style: h,
                                        className: d(t && "loading", "btn-img"),
                                        onClick: r,
                                        children: [o("img", {
                                            src: I(e),
                                            alt: ""
                                        }), o("img", {
                                            className: "btn-txt",
                                            src: L(c),
                                            alt: ""
                                        })]
                                    }),
                                    spinBanner: o(T.img, {
                                        style: y,
                                        src: E(e)
                                    })
                                }
                            }(e, i, r, a, p);
                        return b.exports.useEffect((() => {
                            const e = P.timeline();
                            return t > 0 && c.current && f.current && m.current ? (e.to(c.current, {
                                rotate: be(t, c),
                                duration: 3.6
                            }), e.to(m.current, {
                                scale: 1.1,
                                duration: .3,
                                delay: .3
                            }), e.to(m.current, {
                                scale: 1,
                                duration: .2
                            }), e.set(f.current, {
                                x: -20,
                                scale: 1
                            }), e.to(f.current, {
                                x: 200,
                                skewX: -25,
                                scale: 3.4,
                                duration: .5,
                                delay: .3
                            }), e.to(m.current, {
                                scale: 1,
                                onComplete: () => {
                                    n.setSpinAnimateEnd()
                                }
                            })) : e.set(c.current, {
                                rotate: 0
                            }), () => {
                                P.killTweensOf(e)
                            }
                        }), [t]), b.exports.useEffect((() => () => n.setSpinAnimateEnd()), []), b.exports.useEffect((() => {
                            y.start(ge), h.start({
                                reset: !0
                            })
                        }), [e]), s(U, {
                            children: [s(T.div, {
                                className: ue,
                                style: g,
                                children: [o("div", {
                                    ref: c,
                                    className: ue,
                                    children: N
                                }), s("div", {
                                    className: "point-img",
                                    ref: m,
                                    children: [o("div", {
                                        className: "light-wrap",
                                        children: o("div", {
                                            ref: f,
                                            className: "point-light"
                                        })
                                    }), x]
                                })]
                            }), z, o(T.div, {
                                style: u,
                                className: "banner-img",
                                children: j
                            })]
                        })
                    })),
                    ue = "s1zzacp";
                const we = F((function({
                        level: e
                    }) {
                        const [t, i] = Z({
                            res: 0
                        }), a = r(), l = n.spinLoading, m = n.levelUpdated, d = h(), f = O.login, p = D(e), g = async function() {
                            if (n.soundSprites.play("Click"), !f) return x.close(), d("/login?redirect=/spin");
                            if (!l) {
                                if (0 === n.freeTimes) return _("Uh oh! Sorry but you don't have free spin yet!");
                                if (e != n.spinLevel) return _("Uh ho! Please try other Spin");
                                try {
                                    n.spinLoading = !0;
                                    const e = await n.handleSpin();
                                    n.soundSprites.play("SpinAndBonus"), n.freeTimes = e.leftTimes, i({
                                        res: e.hitSection - 1
                                    }), await n.spinAnimateEnd(), n.spinLoading = !1, x.push(o(me, {
                                        locked: e.locked,
                                        amount: e.amount,
                                        currencyName: e.currencyName,
                                        bigPrize: e.bigPrize,
                                        level: n.spinLevel,
                                        trackId: e.trackId
                                    })), 0 === e.leftTimes && n.setNextTime()
                                } catch (t) {
                                    _(t), n.spinLoading = !1
                                }
                            }
                        };
                        b.exports.useEffect((() => {
                            i({
                                res: 0
                            })
                        }), [e]);
                        const u = f ? `${a("page.spin.free")}: ${n.freeTimes}` : a("page.spin.free"),
                            w = O.login && (e != n.spinLevel || n.freeTimes <= 0);
                        return s("div", {
                            className: ke,
                            children: [o(he, {
                                level: e,
                                res: t.res,
                                update: m,
                                onSpin: g,
                                loading: n.spinLoading
                            }), o(c, {
                                onClick: g,
                                disabled: w,
                                style: {
                                    backgroundColor: p[0],
                                    backgroundImage: `conic-gradient(from 1turn, ${p[1]}, ${p[0]})`
                                },
                                type: "conic4",
                                className: "btn",
                                children: 0 === n.freeTimes && O.login ? s(U, {
                                    children: [s("span", {
                                        style: {
                                            marginRight: "5px"
                                        },
                                        children: [a("page.spin.next_free"), ":"]
                                    }), o($, {
                                        endTime: n.nextTime,
                                        onEnd: n.getUserInfo,
                                        children: ({
                                            days: e,
                                            hours: t,
                                            minutes: i,
                                            seconds: r
                                        }) => s("div", {
                                            className: "time-wrap",
                                            children: [o("b", {
                                                children: G(t)
                                            }), o("b", {
                                                className: "colon",
                                                children: ":"
                                            }), o("b", {
                                                children: G(i)
                                            }), o("b", {
                                                className: "colon",
                                                children: ":"
                                            }), o("b", {
                                                children: G(r)
                                            })]
                                        })
                                    })]
                                }) : u
                            })]
                        })
                    })),
                    ke = "szbrnh5";

                function ye({
                    list: e,
                    onBack: t
                }) {
                    const [i, a] = b.exports.useState(!1), c = r();
                    b.exports.useEffect((() => {
                        a(!0)
                    }), []);
                    return o("div", {
                        className: d(xe, i && "enter"),
                        children: s("div", {
                            className: "winlist-wrap",
                            children: [o("div", {
                                className: "pop-control",
                                children: o("button", {
                                    onClick: () => {
                                        a(!1), setTimeout((() => {
                                            t()
                                        }), 200)
                                    },
                                    className: "back",
                                    children: o(v, {
                                        name: "Arrow"
                                    })
                                })
                            }), s("div", {
                                className: "header",
                                children: [o("img", {
                                    src: l.crown,
                                    className: "crown",
                                    alt: ""
                                }), s("div", {
                                    className: "spin-bonus",
                                    children: [o("img", {
                                        className: "pre-img",
                                        src: l.laurel,
                                        alt: ""
                                    }), o("div", {
                                        className: "tit",
                                        children: "Spin Bonus"
                                    }), o("img", {
                                        className: "suf-img",
                                        src: l.laurel,
                                        alt: ""
                                    })]
                                })]
                            }), s("div", {
                                className: "win-list",
                                children: [s("div", {
                                    className: "table-header td",
                                    children: [o("p", {
                                        children: c("page.share.username_label")
                                    }), o("p", {
                                        children: c("page.spin.level")
                                    }), o("p", {
                                        children: c("common.prize")
                                    })]
                                }), e.length > 0 ? o(H, {
                                    slidesPerView: "auto",
                                    direction: "vertical",
                                    freeMode: !0,
                                    loop: !0,
                                    autoplay: {
                                        delay: 200,
                                        disableOnInteraction: !1
                                    },
                                    effect: "fade",
                                    slidesPerGroup: 1,
                                    className: "winlist-swiper swiper-no-swiping",
                                    children: e.map(((e, t) => s(J, {
                                        className: "td",
                                        children: [o("p", {
                                            className: "name",
                                            children: e.username
                                        }), o("p", {
                                            children: o("span", {
                                                style: {
                                                    color: V(n.getTab(e.level))
                                                },
                                                children: W(n.getTab(e.level))
                                            })
                                        }), o("p", {
                                            children: o(Y, {
                                                sign: !0,
                                                icon: !0,
                                                name: e.currencyName,
                                                amount: e.amount
                                            })
                                        })]
                                    }, "tr-" + t)))
                                }) : o(K, {})]
                            })]
                        })
                    })
                }
                const xe = "s8knv0f";

                function ve() {
                    return S.post("/activity/lucky/spin/news/", {
                        start: (new Date).getTime() - 864e5
                    })
                }

                function Ne({
                    num: e
                }) {
                    const t = {
                            val: n.totalBonus
                        },
                        i = b.exports.useRef(null),
                        a = r();
                    return b.exports.useEffect((() => {
                        const r = P.to(t, {
                            val: e,
                            duration: 3,
                            ease: ie.easeInOut,
                            onUpdate: () => {
                                i.current && (i.current.innerHTML = y.toLocaleCurrency(t.val, "USD"))
                            }
                        });
                        return n.totalBonus = e, () => P.killTweensOf(r)
                    }), [e]), s("div", {
                        className: "left-cont",
                        children: [o("div", {
                            className: "tit",
                            children: a("page.spin.totalbonus")
                        }), o("div", {
                            className: "amount",
                            ref: i,
                            children: y.toLocaleCurrency(t.val, "USD")
                        })]
                    })
                }
                const ze = i.memo((function({
                        spinLoading: e
                    }) {
                        const [t, i] = b.exports.useState(!1), {
                            data: r,
                            error: n
                        } = N(ve);
                        return r ? s(U, {
                            children: [t && o(ye, {
                                list: r.updates,
                                onBack: () => i(!1)
                            }), s("div", {
                                className: _e,
                                children: [o(Ne, {
                                    num: r.totalBonus
                                }), o("div", {
                                    className: "right-cont",
                                    onClick: () => {
                                        e || i(!t)
                                    },
                                    children: o(Se, {
                                        list: r.updates
                                    })
                                })]
                            })]
                        }) : o("div", {
                            className: _e,
                            children: o(Q, {})
                        })
                    })),
                    je = i.memo((({
                        data: e,
                        it: t
                    }) => s(T.div, {
                        className: "data-cont",
                        style: {
                            position: "absolute",
                            ...t
                        },
                        children: [o(ee, {
                            name: "",
                            userId: e.userId
                        }), s("div", {
                            className: "cont",
                            children: [o("div", {
                                className: "name",
                                children: e.username
                            }), s("div", {
                                className: "win",
                                children: ["Win: ", o("span", {
                                    className: "amount",
                                    children: e.amount
                                }), " ", o("span", {
                                    className: "currency",
                                    children: y.getAlias(e.currencyName)
                                }), " "]
                            }), s("div", {
                                className: "type",
                                children: ["in ", o("b", {
                                    style: {
                                        color: V(n.getTab(e.level))
                                    },
                                    children: W(n.getTab(e.level))
                                })]
                            })]
                        }), o(v, {
                            name: "Arrow"
                        })]
                    })));

                function Se({
                    list: e
                }) {
                    const [t, i] = b.exports.useState(0), r = e[t % e.length], n = te(r, {
                        from: {
                            y: "100%"
                        },
                        enter: {
                            y: "0%"
                        },
                        leave: {
                            y: "-100%"
                        }
                    });
                    return b.exports.useEffect((() => {
                        const e = window.setInterval((() => i((e => e + 1))), 5e3);
                        return () => {
                            clearInterval(e)
                        }
                    }), []), o("div", {
                        children: n(((e, t, i, r) => o(je, {
                            data: t,
                            it: e
                        }, r)))
                    })
                }
                const _e = "sydmigf";
                var Te = F((function() {
                    const e = n.spinLevel,
                        t = re.isMobile,
                        i = n.tabs,
                        r = O.vipLevel,
                        [a, l] = b.exports.useState({
                            tab: e
                        });

                    function m(e) {
                        n.spinLoading || l({
                            tab: e
                        })
                    }
                    return b.exports.useEffect((() => {
                        l({
                            tab: e
                        })
                    }), [e]), s(U, {
                        children: [o(ne, {
                            tab: a.tab,
                            level: r,
                            onTab: m,
                            updateFinished: n.updateFinished
                        }), o(we, {
                            level: a.tab
                        }), t && s(U, {
                            children: [o(c, {
                                disabled: a.tab === i[0],
                                className: "pre_btn",
                                onClick: function() {
                                    const e = i.findIndex((e => e === a.tab));
                                    m(i[e - 1])
                                },
                                children: o("div", {
                                    className: "btn-wrap",
                                    children: o(v, {
                                        name: "Arrow"
                                    })
                                })
                            }), o(c, {
                                disabled: a.tab === i[i.length - 1],
                                className: "suff_btn",
                                onClick: function() {
                                    const e = i.findIndex((e => e === a.tab));
                                    m(i[e + 1])
                                },
                                children: o("div", {
                                    className: "btn-wrap",
                                    children: o(v, {
                                        name: "Arrow"
                                    })
                                })
                            })]
                        }), o(ze, {
                            spinLoading: n.spinLoading
                        })]
                    })
                }));
                const Ce = "sy6yjq0"
            }
        }
    }))
}();
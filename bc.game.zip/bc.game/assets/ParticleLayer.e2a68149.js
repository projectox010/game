import {
    a5 as s,
    a as t
} from "./index.28e31dff.js";
import {
    P as i,
    a as c
} from "./usePixiGsap.bf451f35.js";
const n = {
        list: [{
            value: 0,
            time: 0
        }, {
            value: 1,
            time: .5
        }, {
            value: 0,
            time: 1
        }],
        isStepped: !1
    },
    o = {
        list: [{
            value: .05,
            time: 0
        }, {
            value: .3,
            time: 1
        }],
        isStepped: !1,
        minimumScaleMultiplier: 2
    },
    r = {
        start: "#3c5653",
        end: "#6dcaa4"
    },
    l = {
        start: 10,
        end: 20,
        minimumSpeedMultiplier: 1.3
    },
    p = {
        x: 0,
        y: 0
    },
    m = 0,
    d = {
        min: 0,
        max: 260
    },
    f = !1,
    u = {
        min: 0,
        max: 0
    },
    x = {
        min: 8,
        max: 12
    },
    y = "normal",
    v = .5,
    w = -1,
    S = 500,
    h = {
        x: 0,
        y: 0
    },
    P = !1,
    R = "rect",
    b = {
        x: 0,
        y: 0,
        w: 464,
        h: 300
    },
    g = !0,
    L = !0;
var M = {
        alpha: n,
        scale: o,
        color: r,
        speed: l,
        acceleration: p,
        maxSpeed: m,
        startRotation: d,
        noRotation: f,
        rotationSpeed: u,
        lifetime: x,
        blendMode: y,
        frequency: v,
        emitterLifetime: w,
        maxParticles: S,
        pos: h,
        addAtBack: P,
        spawnType: R,
        spawnRect: b,
        emit: g,
        autoUpdate: L
    },
    q = "/assets/circle.f7cb4038.png";

function A({
    config: a = {}
}) {
    const e = Object.assign(JSON.parse(JSON.stringify(M)), a);
    return t("div", {
        className: `${J} particle-layer`,
        children: t(i, {
            width: e.spawnRect.w,
            height: e.spawnRect.h,
            fps: 30,
            children: t(c, {
                textures: q,
                config: e
            })
        })
    })
}
var j = s.memo(A);
const J = "p1wqymdo";
export {
    j as P
};
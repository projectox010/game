import {
    ch as A,
    ci as f,
    bE as b
} from "./index.28e31dff.js";
var _ = 4294967295,
    h = _ >>> 1;

function l(e, n, o) {
    var s = 0,
        r = e == null ? s : e.length;
    if (typeof n == "number" && n === n && r <= h) {
        for (; s < r;) {
            var i = s + r >>> 1,
                t = e[i];
            t !== null && !A(t) && (o ? t <= n : t < n) ? s = i + 1 : r = i
        }
        return r
    }
    return f(e, n, b, o)
}

function R(e, n) {
    return l(e, n)
}
export {
    R as s
};
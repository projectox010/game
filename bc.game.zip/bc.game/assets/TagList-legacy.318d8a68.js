System.register(["./index-legacy.1416f96c.js", "./AggregateList-legacy.7a6fb47a.js"], (function(t) {
    "use strict";
    var e, n, a;
    return {
        setters: [function(t) {
            e = t.a2, n = t.a
        }, function(t) {
            a = t.F
        }],
        execute: function() {
            t("default", (function() {
                const t = e();
                return n(a, {
                    tagName: t.tagname || "",
                    isTag: !0
                })
            }))
        }
    }
}));
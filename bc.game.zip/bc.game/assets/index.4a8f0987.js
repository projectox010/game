import {
    o as p,
    u as c,
    d as s,
    a,
    a4 as u,
    ao as v,
    r as d,
    cy as w,
    s as G,
    $ as h,
    G as b,
    j as N,
    b as C,
    t as y,
    q as l
} from "./index.28e31dff.js";
import {
    G as x
} from "./GameGridList.b3c3af9c.js";

function L() {
    const e = c();
    return s.login ? a(j, {}) : a(u, {
        className: "full-abs",
        children: e("common.messages.login_first")
    })
}

function j() {
    const [e, t] = v({
        list: void 0,
        page: 1,
        loading: !1,
        more: !1
    }), o = c(), r = d.exports.useContext(w), m = s.areaCode ? s.areaCode : "IN", i = G.isMobile ? 1 : 2, n = r.lng;
    return d.exports.useEffect(() => {
        if (!e.loading) {
            t({
                loading: !0
            });
            const _ = e.page;
            h.post("/home/game/favoriteList/", {
                restriction: m,
                device: i,
                lang: n,
                page: e.page,
                pageSize: 20
            }).then(g => {
                let f;
                _ === 1 ? f = g.list : f = e.list.concat(g.list), t({
                    list: f,
                    loading: !1,
                    more: g.list === 20
                })
            }).catch(b)
        }
    }, [e.page]), N("div", {
        className: k,
        children: [a("div", {
            className: "tit",
            children: a("b", {
                children: o("common.my_favorite")
            })
        }), a(x, {
            className: $,
            list: e.list
        }), e.more && a(C, {
            type: "gray",
            className: "load-btn",
            loading: e.loading,
            onClick: () => t({
                page: e.page + 1
            }),
            children: o("common.load_more")
        })]
    })
}
const $ = "l14kmb3h";
y({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: ["#31343a", l("#6b7180", .6)],
    cl3: [l("#99a4b0", .6), "#f5f6f7"],
    cl4: ["rgba(49,52,60,0.5)", "#fff"]
});
const k = "v1lgwkxb";
var R = p(L);

function I() {
    const e = c();
    return s.login ? a(S, {}) : a(u, {
        className: "full-abs",
        children: e("common.messages.login_first")
    })
}

function S() {
    const [e, t] = v({
        list: void 0,
        page: 1,
        loading: !1,
        more: !1
    }), o = c(), r = s.areaCode ? s.areaCode : "IN";
    return d.exports.useEffect(() => {
        if (!e.loading) {
            t({
                loading: !0
            });
            const m = e.page;
            h.post("/home/game/recent/", {
                areaCode: r,
                page: e.page,
                pageSize: 20
            }).then(i => {
                let n;
                m === 1 ? n = i.list : n = e.list.concat(i.list), t({
                    list: n,
                    loading: !1,
                    more: i.list === 20
                })
            }).catch(b)
        }
    }, [e.page]), N("div", {
        className: z,
        children: [a("div", {
            className: "tit",
            children: a("b", {
                children: o("common.recent")
            })
        }), a(x, {
            className: E,
            list: e.list
        }), e.more && a(C, {
            type: "gray",
            className: "load-btn",
            loading: e.loading,
            onClick: () => t({
                page: e.page + 1
            }),
            children: o("common.load_more")
        })]
    })
}
const E = "l12jwdfe";
y({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: ["#31343a", l("#6b7180", .6)],
    cl3: [l("#99a4b0", .6), "#f5f6f7"],
    cl4: ["rgba(49,52,60,0.5)", "#fff"]
});
const z = "v19gdg7f";
var V = p(I);
export {
    R as Favorite, V as Recent
};
import {
    H as a
} from "./HelpPage.5a10ddbc.js";
import {
    a as i
} from "./index.28e31dff.js";
var n = `<section>
  <h2>Provider Availability Policy</h2>
  <div class="content">
    <ol>
      <li>
        <b
          >Absolute Restriction <br />
          NetEnt will not permit NetEnt Casino Games to be supplied to any
          entity that operates in any of the below jurisdictions (irrespective
          of whether or not NetEnt Casino Games are being supplied by the entity
          in that jurisdiction) without the appropriate licenses.</b
        >
        <div>
          Belgium, Bulgaria, Colombia, Croatia, Czech Republic, Denmark,
          Estonia, France, Italy, Latvia, Lithuania, Mexico, Portugal, Romania,
          Spain, Sweden, Switzerland, United Kingdom, United States of America.
        </div>
      </li>
      <li>
        <b
          >Blacklisted Territories <br />
          All NetEnt Casino Games may not be offered in the following
          territories:</b
        >
        <div>
          Afghanistan, Albania, Algeria, Angola, Australia, Bahamas, Botswana,
          Belgium, Bulgaria, Colombia, Croatia, Czech Republic, Denmark,
          Estonia, Ecuador, Ethiopia, France, Ghana, Guyana, Hong Kong, Italy,
          Iran, Iraq, Israel, Kuwait, Latvia, Lithuania, Mexico, Namibia,
          Nicaragua, North Korea, Pakistan, Panama, Philippines, Portugal,
          Romania, Singapore, Spain, Sweden, Switzerland, Sudan, Syria, Taiwan,
          Trinidad and Tobago, Tunisia, Uganda, United Kingdom, United States of
          America, Yemen, Zimbabwe
        </div>
      </li>
      <li>
        <b
          >Blacklisted Branded Games Territories <br />
          The followed NetEnt Braded Games have some further restrictions in
          addition to the Blacklisted Territories set out above:</b
        >
        <ol style="list-style-type: lower-roman">
          <li>
            <b
              >In addition to the jurisdictions set out in paragraph 2, Planet
              of the Apes Video Slot must not be offered in the following
              territories:</b
            >
            <div>
              Azerbaijan, China, India, Malaysia, Qatar, Russia, Thailand,
              Turkey, Ukraine.
            </div>
          </li>
          <li>
            <b
              >In addition to the jurisdictions set out in paragraph 2, Vikings
              Video Slot must not be offered in the following jurisdictions:</b
            >
            <div>
              Azerbaijan, Cambodia, Canada, China, France, India, Indonesia,
              Laos, Malaysia, Myanmar, Papua New Guinea, Qatar, Russia, South
              Korea, Thailand, Turkey, Ukraine, United States of America.
            </div>
          </li>
          <li>
            <b
              >In addition to the jurisdictions set out in paragraph 2, Narcos
              Video Slot must not be offered in the following territories:</b
            >
            <div>Indonesia, South Korea.</div>
          </li>
          <li>
            <b
              >In addition to the jurisdictions set out in paragraph 2, Street
              Fighter Video Slot must not be offered in the following
              territories:</b
            >
            <div>
              Anguilla, Antigua & Barbuda, Argentina, Aruba, Barbados, Bahamas,
              Belize, Bermuda, Bolivia, Bonaire, Brazil, British Virgin Islands,
              Canada, Cayman Islands, China, Chile, Clipperton Island, Columbia,
              Costa Rica, Cuba, Curacao, Dominica, Dominican Republic, El
              Salvador, Greenland, Grenada, Guadeloupe, Guatemala, Guyana,
              Haiti, Honduras, Jamaica, Japan, Martinique, Mexico, Montserrat,
              Navassa Island, Paraguay, Peru, Puerto Rico, Saba, Saint
              Barthelemy, Saint Eustatius, Saint Kitts and Nevis, Saint Lucia,
              Saint Maarten, Saint Martin, Saint Pierre and Miquelon, Saint
              Vincent and the Grenadines, South Korea, Suriname, Turks and
              Caicos Islands, United States of America, Uruguay, US Virgin
              Islands, Venezuela.
            </div>
          </li>
          <li>
            <b
              >In addition to the jurisdictions set out in paragraph 2, Fashion
              TV Video Slot must not be offered in the following territories:</b
            >
            <div>Cuba, Jordan, Turkey, Saudi Arabia.</div>
          </li>
        </ol>
      </li>
      <li>
        <b
          >Universal Monsters (Dracula, Creature from the Black Lagoon, Phantoms
          Curse and The Invisible Man) may only be played in the following
          territories:</b
        >
        <div>
          Andorra, Austria, Armenia, Azerbaijan, Belarus, Bosnia and
          Herzegovina, Cyprus, Finland, Georgia, Germany, Greece, Hungary,
          Iceland, Ireland, Liechtenstein, Luxembourg, Malta, Moldova, Monaco,
          Montenegro, Netherlands, North Macedonia, Norway, Poland, Russia, San
          Marino, Serbia, Slovakia, Slovenia, Turkey and Ukraine.
        </div>
      </li>
    </ol>
  </div>
</section>
`,
    e = `<section>\r
  <h2>Pol\xEDtica de Disponibilidade de Provedores</h2>\r
  <div class="content">\r
    <ol>\r
      <li>\r
        <b>Restri\xE7\xE3o Absoluta<br>\r
          A NetEnt n\xE3o permitir\xE1 que os Jogos de Cassino NetEnt sejam fornecidos a qualquer entidade que opere em qualquer uma das jurisdi\xE7\xF5es abaixo (independentemente de os Jogos de Cassino NetEnt estarem ou n\xE3o sendo fornecidos pela entidade nessa jurisdi\xE7\xE3o) sem as licen\xE7as apropriadas.</b>\r
        <div>\r
          B\xE9lgica, Bulg\xE1ria, Col\xF4mbia, Cro\xE1cia, Rep\xFAblica Checa, Dinamarca, Est\xF3nia, Fran\xE7a, It\xE1lia, Let\xF3nia, Litu\xE2nia, M\xE9xico, Portugal, Rom\xE9nia, Espanha, Su\xE9cia, Su\xED\xE7a, Reino Unido, Estados Unidos da Am\xE9rica.\r
        </div>\r
      </li>\r
      <li>\r
        <b>Territ\xF3rios na lista negra <br>\r
          Todos os Jogos de Cassino NetEnt n\xE3o podem ser oferecidos nos seguintes territ\xF3rios:</b>\r
        <div>\r
          Afeganist\xE3o, Alb\xE2nia, Arg\xE9lia, Angola, Austr\xE1lia, Bahamas, Botsuana, B\xE9lgica, Bulg\xE1ria, Col\xF4mbia, Cro\xE1cia, Rep\xFAblica Tcheca, Dinamarca, Est\xF4nia, Equador, Eti\xF3pia, Fran\xE7a, Gana, Guiana, Hong Kong, It\xE1lia, Ir\xE3, Iraque, Israel, Kuwait, Let\xF4nia, Litu\xE2nia, M\xE9xico, Nam\xEDbia, Nicar\xE1gua, Cor\xE9ia do Norte, Paquist\xE3o, Panam\xE1, Filipinas, Portugal, Rom\xEAnia, Cingapura, Espanha, Su\xE9cia, Su\xED\xE7a, Sud\xE3o, S\xEDria, Taiwan, Trinidad e Tobago, Tun\xEDsia, Uganda, Reino Unido, Estados Unidos da Am\xE9rica, I\xEAmen, Zimb\xE1bue\r
        </div>\r
      </li>\r
      <li>\r
        <b> Territ\xF3rios de jogos de marca na lista negra<br>\r
      Os seguintes jogos da marca NetEnt t\xEAm algumas restri\xE7\xF5es adicionais, al\xE9m dos territ\xF3rios da lista negra definidos acima:</b>\r
        <ol style="list-style-type: lower-roman">\r
          <li>\r
            <b>Al\xE9m das jurisdi\xE7\xF5es estabelecidas no par\xE1grafo 2, o slot de v\xEDdeo Planet of the Apes n\xE3o deve ser oferecido nos seguintes territ\xF3rios:</b>\r
            <div>\r
              Azerbaij\xE3o, China, \xCDndia, Mal\xE1sia, Qatar, R\xFAssia, Tail\xE2ndia, Turquia, Ucr\xE2nia.</div>\r
          </li>\r
          <li>\r
            <b>Al\xE9m das jurisdi\xE7\xF5es estabelecidas no par\xE1grafo 2, o Vikings Video Slot n\xE3o deve ser oferecido nas seguintes jurisdi\xE7\xF5es:</b>\r
            <div>\r
              Azerbaij\xE3o, Camboja, Canad\xE1, China, Fran\xE7a, \xCDndia, Indon\xE9sia, Laos, Mal\xE1sia, Mianmar, Papua Nova Guin\xE9, Qatar, R\xFAssia, Coreia do Sul, Tail\xE2ndia, Turquia, Ucr\xE2nia, Estados Unidos da Am\xE9rica.\r
            </div>\r
          </li>\r
          <li>\r
            <b>Al\xE9m das jurisdi\xE7\xF5es estabelecidas no par\xE1grafo 2, o Narcos Video Slot n\xE3o deve ser oferecido nos seguintes territ\xF3rios:</b>\r
            <div>Indon\xE9sia, Coreia do Sul.</div>\r
          </li>\r
          <li>\r
            <b>Al\xE9m das jurisdi\xE7\xF5es estabelecidas no par\xE1grafo 2, o Street Fighter Video Slot n\xE3o deve ser oferecido nos seguintes territ\xF3rios:</b>\r
            <div>\r
              Anguilla, Ant\xEDgua e Barbuda, Argentina, Aruba, Barbados, Bahamas, Belize, Bermudas, Bol\xEDvia, Bonaire, Brasil, Ilhas Virgens Brit\xE2nicas, Canad\xE1, Ilhas Cayman, China, Chile, Ilha Clipperton, Col\xF4mbia, Costa Rica, Cuba, Cura\xE7ao, Dominica , Rep\xFAblica Dominicana, El Salvador, Groenl\xE2ndia, Granada, Guadalupe, Guatemala, Guiana, Haiti, Honduras, Jamaica, Jap\xE3o, Martinica, M\xE9xico, Montserrat, Ilha Navassa, Paraguai, Peru, Porto Rico, Saba, S\xE3o Bartolomeu, S\xE3o Eust\xE1quio, S\xE3o Kitts e Nevis, Santa L\xFAcia, Saint Maarten, Saint Martin, Saint Pierre e Miquelon, S\xE3o Vicente e Granadinas, Coreia do Sul, Suriname, Ilhas Turks e Caicos, Estados Unidos da Am\xE9rica, Uruguai, Ilhas Virgens Americanas, Venezuela.</div>\r
          </li>\r
          <li>Al\xE9m das jurisdi\xE7\xF5es estabelecidas no par\xE1grafo 2, o Fashion TV Video Slot n\xE3o deve ser oferecido nos seguintes territ\xF3rios:\r
            <div>Cuba, Jordan, Turkey, Saudi Arabia.</div>\r
          </li>\r
        </ol>\r
      </li>\r
      <li>\r
        <b>Monstros Universais (Dracula, Creature from the Black Lagoon, Phantom's Curse e The Invisible Man) s\xF3 podem ser jogados nos seguintes territ\xF3rios:\r
        <div>\r
          Andorra, \xC1ustria, Arm\xEAnia, Azerbaij\xE3o, Bielorr\xFAssia, B\xF3snia e\r
           Herzegovina, Chipre, Finl\xE2ndia, Ge\xF3rgia, Alemanha, Gr\xE9cia, Hungria,\r
           Isl\xE2ndia, Irlanda, Liechtenstein, Luxemburgo, Malta, Mold\xE1via, M\xF4naco,\r
           Montenegro, Holanda, Maced\xF4nia do Norte, Noruega, Pol\xF4nia, R\xFAssia, San\r
           Marino, S\xE9rvia, Eslov\xE1quia, Eslov\xEAnia, Turquia e Ucr\xE2nia.\r
        </div>\r
      </b></li><b>\r
    </b></ol><b>\r
  </b></div><b>\r
</b></section>`,
    r = `<section>
  <h2>Kebijakan Ketersediaan Penyedia</h2>
   <div class="konten">
     <ol>
       <li>
         <b
           >Pembatasan Mutlak <br />
           NetEnt tidak akan mengizinkan Game Kasino NetEnt untuk dipasok ke entitas mana pun yang beroperasi di salah satu yurisdiksi di bawah ini (terlepas dari apakah Game Kasino NetEnt disediakan atau tidak oleh entitas di yurisdiksi tersebut) tanpa lisensi yang sesuai.</b
         >
         <div>
           Belgia, Bulgaria, Kolombia, Kroasia, Republik Ceko, Denmark,
           Estonia, Prancis, Italia, Latvia, Lituania, Meksiko, Portugal, Rumania,
           Spanyol, Swedia, Swiss, Inggris Raya, Amerika Serikat.
         </div>
       </li>
       <li>
         <b
           >Wilayah yang Masuk Daftar Hitam <br />
           Semua Game Kasino NetEnt mungkin tidak ditawarkan sebagai berikut:
           wilayah:</b
        >
        <div>
          Afghanistan, Albania, Algeria, Angola, Australia, Bahamas, Botswana,
          Belgium, Bulgaria, Colombia, Croatia, Czech Republic, Denmark,
          Estonia, Ecuador, Ethiopia, France, Ghana, Guyana, Hong Kong, Italy,
          Iran, Iraq, Israel, Kuwait, Latvia, Lithuania, Mexico, Namibia,
          Nicaragua, North Korea, Pakistan, Panama, Philippines, Portugal,
          Romania, Singapore, Spain, Sweden, Switzerland, Sudan, Syria, Taiwan,
          Trinidad and Tobago, Tunisia, Uganda, United Kingdom, United States of
          America, Yemen, Zimbabwe
        </div>
      </li>
      <li>
        <b
          >Wilayah Game Bermerek yang Masuk Daftar Hitam <br />
          Game Bermerek NetEnt yang diikuti memiliki beberapa batasan lebih lanjut selain Wilayah Daftar Hitam yang ditetapkan di atas:</b
        >
        <ol style="list-style-type: lower-roman">
          <li>
            <b
              >Selain yurisdiksi yang ditetapkan dalam paragraf 2, Video Planet
              of the Apes Slot tidak boleh ditawarkan di wilayah berikut:</b
            >
            <div>
              Azerbaijan, China, India, Malaysia, Qatar, Russia, Thailand,
              Turkey, Ukraine.
            </div>
          </li>
          <li>
            <b
              >Selain yurisdiksi yang ditetapkan dalam paragraf 2, Video Vikings
              Slot tidak boleh ditawarkan di wilayah berikut:</b
            >
            <div>
              Azerbaijan, Cambodia, Canada, China, France, India, Indonesia,
              Laos, Malaysia, Myanmar, Papua New Guinea, Qatar, Russia, South
              Korea, Thailand, Turkey, Ukraine, United States of America.
            </div>
          </li>
          <li>
            <b
              >Selain yurisdiksi yang ditetapkan dalam paragraf 2, Video Narcos
              Slot tidak boleh ditawarkan di wilayah berikut:</b
            >
            <div>Indonesia, South Korea.</div>
          </li>
          <li>
            <b
              >Selain yurisdiksi yang ditetapkan dalam paragraf 2, Video Street
              Fighter Slot tidak boleh ditawarkan di wilayah berikut:</b
            >
            <div>
              Anguilla, Antigua & Barbuda, Argentina, Aruba, Barbados, Bahamas,
              Belize, Bermuda, Bolivia, Bonaire, Brazil, British Virgin Islands,
              Canada, Cayman Islands, China, Chile, Clipperton Island, Columbia,
              Costa Rica, Cuba, Curacao, Dominica, Dominican Republic, El
              Salvador, Greenland, Grenada, Guadeloupe, Guatemala, Guyana,
              Haiti, Honduras, Jamaica, Japan, Martinique, Mexico, Montserrat,
              Navassa Island, Paraguay, Peru, Puerto Rico, Saba, Saint
              Barthelemy, Saint Eustatius, Saint Kitts and Nevis, Saint Lucia,
              Saint Maarten, Saint Martin, Saint Pierre and Miquelon, Saint
              Vincent and the Grenadines, South Korea, Suriname, Turks and
              Caicos Islands, United States of America, Uruguay, US Virgin
              Islands, Venezuela.
            </div>
          </li>
          <li>
            <b
              >Selain yurisdiksi yang ditetapkan dalam paragraf 2, Video Fashion
              TV Slot tidak boleh ditawarkan di wilayah berikut:</b
            >
            <div>Cuba, Jordan, Turkey, Saudi Arabia.</div>
          </li>
        </ol>
      </li>
      <li>
        <b
          >Universal Monsters (Dracula, Creature from the Black Lagoon, Phantoms
          Curse and The Invisible Man) hanya dapat dimainkan di wilayah berikut:</b
        >
        <div>
          Andorra, Austria, Armenia, Azerbaijan, Belarus, Bosnia and
          Herzegovina, Cyprus, Finland, Georgia, Germany, Greece, Hungary,
          Iceland, Ireland, Liechtenstein, Luxembourg, Malta, Moldova, Monaco,
          Montenegro, Netherlands, North Macedonia, Norway, Poland, Russia, San
          Marino, Serbia, Slovakia, Slovenia, Turkey and Ukraine.
        </div>
      </li>
    </ol>
  </div>
</section>
`;

function s() {
    return i(a, {
        br: e,
        en: n,
        id: r
    })
}
export {
    s as
    default
};
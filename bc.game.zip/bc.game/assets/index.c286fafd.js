var W = Object.defineProperty,
    U = Object.defineProperties;
var H = Object.getOwnPropertyDescriptors;
var C = Object.getOwnPropertySymbols;
var K = Object.prototype.hasOwnProperty,
    q = Object.prototype.propertyIsEnumerable;
var G = (a, l, n) => l in a ? W(a, l, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: n
    }) : a[l] = n,
    F = (a, l) => {
        for (var n in l || (l = {})) K.call(l, n) && G(a, n, l[n]);
        if (C)
            for (var n of C(l)) q.call(l, n) && G(a, n, l[n]);
        return a
    },
    L = (a, l) => U(a, H(l));
import {
    eY as N,
    eZ as B,
    e_ as Q,
    e$ as V,
    cf as J,
    a5 as I,
    u as f,
    a as e,
    D,
    dx as j,
    j as s,
    o as T,
    du as S,
    r as u,
    s as k,
    F as x,
    f0 as Y,
    bM as Z,
    M as _,
    t as y,
    q as p,
    a3 as M,
    $ as A,
    a4 as P,
    ah as X,
    dD as ee,
    eO as ae,
    dE as le,
    de as $,
    dJ as ne,
    ba as se,
    bb as te,
    bc as ce,
    l as re,
    am as v,
    an as ie,
    b as de
} from "./index.28e31dff.js";
import {
    S as he
} from "./SlotsILayout.a8936350.js";

function oe() {}

function me(a, l, n, t) {
    for (var c = a.length, i = n + (t ? 1 : -1); t ? i-- : ++i < c;)
        if (l(a[i], i, a)) return i;
    return -1
}

function pe(a) {
    return a !== a
}

function ue(a, l, n) {
    for (var t = n - 1, c = a.length; ++t < c;)
        if (a[t] === l) return t;
    return -1
}

function fe(a, l, n) {
    return l === l ? ue(a, l, n) : me(a, pe, n)
}

function ge(a, l) {
    var n = a == null ? 0 : a.length;
    return !!n && fe(a, l, 0) > -1
}

function be(a, l, n) {
    for (var t = -1, c = a == null ? 0 : a.length; ++t < c;)
        if (n(l, a[t])) return !0;
    return !1
}
var ve = 1 / 0,
    ke = N && 1 / B(new N([, -0]))[1] == ve ? function(a) {
        return new N(a)
    } : oe,
    ye = ke,
    Ne = 200;

function we(a, l, n) {
    var t = -1,
        c = ge,
        i = a.length,
        r = !0,
        m = [],
        d = m;
    if (n) r = !1, c = be;
    else if (i >= Ne) {
        var g = l ? null : ye(a);
        if (g) return B(g);
        r = !1, c = V, d = new Q
    } else d = l ? [] : m;
    e: for (; ++t < i;) {
        var h = a[t],
            o = l ? l(h) : h;
        if (h = n || h !== 0 ? h : 0, r && o === o) {
            for (var b = d.length; b--;)
                if (d[b] === o) continue e;
            l && d.push(o), m.push(h)
        } else c(d, o, n) || (d !== m && d.push(o), m.push(h))
    }
    return m
}

function xe(a, l) {
    return a && a.length ? we(a, J(l)) : []
}
const Ie = I.memo(() => {
        const a = f();
        return e(D, {
            title: a("common.game_intro"),
            children: e(j, {
                children: s("div", {
                    className: "item",
                    children: [e("h2", {
                        children: "Game Intro"
                    }), e("div", {
                        className: "help-content",
                        children: e("p", {
                            children: "Blackjack, also known as Twenty-One, is a comparing card game between few players and the dealer. In game each players are dealt two cards at the beginning and in turn competing against the dealer with their final score no bigger than 21."
                        })
                    }), e("h2", {
                        children: "Game Table"
                    }), e("div", {
                        className: "help-content",
                        children: s("ol", {
                            children: [e("li", {
                                children: "Each players are dealt two cards (face up). The dealer is also dealt two cards, one up (exposed) and one down (hidden)"
                            }), e("li", {
                                children: "Players are allowed to draw additional cards (HIT) or not draw (Stand) when the sum of the cards values is not exceeding 21."
                            }), e("li", {
                                children: "Once all the players have completed their hands, the dealer then reveals the hidden card and must hit until the cards total 17 or more points."
                            })]
                        })
                    }), e("h2", {
                        children: "Points Calculation"
                    }), e("div", {
                        className: "help-content",
                        children: s("ol", {
                            children: [e("li", {
                                children: "Ace means 1 or 11 points"
                            }), e("li", {
                                children: "King, Queen, Jack are all worth ten"
                            }), e("li", {
                                children: "Other cards is their pip value (2 through 10)"
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Blackjack"
                                    })
                                }), e("p", {
                                    children: "Get 21 points on the player\u2019s first two card (called a \u201Cblackjack\u201D), then players receive 1.5x of the bet. (If you get Blackjack by splitting, you will only get 1 times bet.)"
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Bust"
                                    })
                                }), e("p", {
                                    children: "When player\u2019s hand exceeds 21 points, the player loses his bet."
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Push"
                                    })
                                }), e("p", {
                                    children: "If the player and dealer have the same total, it\u2019s called a push."
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Stand"
                                    })
                                }), e("p", {
                                    children: "Take no more cards. For example, when player or dealer\u2019s hand is more than 17 points, they may choose to stay."
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Hit"
                                    })
                                }), e("p", {
                                    children: "Take another card from the dealer."
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Surrender"
                                    })
                                }), e("p", {
                                    children: "When the player surrenders, the house takes half the player's bet and returns the other half to the player (only available as first decision of a hand)"
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Insurance"
                                    })
                                }), e("p", {
                                    children: "If the dealer\u2019s upcard is an ace, the player is offered the option of taking \u201Cinsurance\u201D, the amount of which is half the size of player\u2019s original bet."
                                }), s("ol", {
                                    children: [e("li", {
                                        children: "When the dealer has blackjack, it pays 2:1 (meaning that the player receives two dollars for every dollar bet)\xA0"
                                    }), e("li", {
                                        children: "When the dealer does not have blackjack, the player loses the insurance bet."
                                    })]
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Even Money"
                                    })
                                }), e("p", {
                                    children: "When dealer\u2019s upcard is an ace, before player buying an insurance, Even Money is offered to a player with blackjack. In case the dealer has a blackjack, the player will push on the original bet and get a 2 to 1 payout on the even money side bet. In case the player does not choose Even Money, and the dealer has a blackjack, it\u2019s a push."
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Double Down"
                                    })
                                }), e("p", {
                                    children: "The player is allowed to increase the initial bet by up to 100% in exchange for committing to stand after receiving exactly one more card.\xA0If the player has a black jack, double down is not allowed."
                                })]
                            }), s("li", {
                                children: [e("p", {
                                    children: e("span", {
                                        className: "cl-primary",
                                        children: "Split"
                                    })
                                }), e("p", {
                                    children: "The player is allowed to increase the initial bet by up to 100% in exchange for committing to stand after receiving exactly one more card.\xA0"
                                })]
                            })]
                        })
                    })]
                })
            })
        })
    }),
    je = I.memo(() => {
        const a = f();
        return e(D, {
            title: a("title.blackjack_help_seed"),
            children: e(j, {
                children: e("div", {
                    className: "item",
                    children: s("div", {
                        className: "help-content",
                        children: [e("p", {
                            children: "The game uses asymmetric encryption RSASSA-PKCS1-v1_5 mode."
                        }), s("p", {
                            children: ["The server has the [", e("span", {
                                className: "cl-primary",
                                children: "Privatekey"
                            }), "] and announce the [", e("span", {
                                className: "cl-primary",
                                children: "Publickey"
                            }), "]."]
                        }), e("br", {}), s("ol", {
                            children: [s("li", {
                                children: ["Encrypt the [", e("span", {
                                    className: "cl-primary",
                                    children: "Issue"
                                }), "] and [", e("span", {
                                    className: "cl-primary",
                                    children: "Salt"
                                }), "] with HmacSHA256 to get [", e("span", {
                                    className: "cl-primary",
                                    children: "Hash"
                                }), "]."]
                            }), s("li", {
                                children: ["Sign [", e("span", {
                                    className: "cl-primary",
                                    children: "Hash"
                                }), "] with the [", e("span", {
                                    className: "cl-primary",
                                    children: "Privatekey"
                                }), "] to get the [", e("span", {
                                    className: "cl-primary",
                                    children: "Seed"
                                }), "]."]
                            }), s("li", {
                                children: ["Using the [", e("span", {
                                    className: "cl-primary",
                                    children: "Seed"
                                }), "] to shuffle cards."]
                            }), s("li", {
                                children: ["[", e("span", {
                                    className: "cl-primary",
                                    children: "Seed"
                                }), "] is announced after the end of game."]
                            }), s("li", {
                                children: ["The client can use the [", e("span", {
                                    className: "cl-primary",
                                    children: "Publickey"
                                }), "] to verify the signature."]
                            })]
                        }), e("br", {}), e("p", {
                            children: "We offer a single/multiplayer mode. Single player mode is the default. In multiplayer games, we recommend that you sit in the first player position because there is a risk that the robot sitting there and interfere you to get a good hand (we won't do this, swear by coco's teeth). I suggest you leave the room if the there are full of weid frogs instead of your friends."
                        }), e("p", {
                            children: "Good luck."
                        })]
                    })
                })
            })
        })
    });

function Se() {
    return A.get("/blackjack/game/recent/")
}

function Ae() {
    return e("div", {
        className: Ge,
        children: e(M, {
            pms: Se(),
            children: a => a.length ? e(Ce, {
                list: a
            }) : e(P, {})
        })
    })
}
const Ce = T(function(l) {
        const n = f(),
            t = S(),
            [c, i] = u.exports.useState(l.list.slice(0, t.allBetsLength));
        return u.exports.useEffect(() => {
            const {
                betRecent: r
            } = t;
            if (r.length) {
                const m = xe([...r, ...c], d => d.gameId).slice(0, t.allBetsLength);
                i(m)
            }
        }, [t.betRecent]), s("div", {
            className: Fe,
            children: [s("div", {
                className: "head flex",
                children: [e("div", {
                    className: "col-5 text-left",
                    children: n("common.game_number")
                }), e("div", {
                    className: "col",
                    children: n("common.player")
                }), !k.isMobile && s(x, {
                    children: [e("div", {
                        className: "col",
                        children: n("common.result")
                    }), s("div", {
                        className: "col",
                        children: [n("common.result"), "(" + n("game.blackjack.banker") + ")"]
                    }), e("div", {
                        className: "col fixed",
                        children: n("common.bet")
                    })]
                }), e("div", {
                    className: "col fixed text-right",
                    children: n("common.profit")
                })]
            }), e("ul", {
                className: "list",
                children: c.map((r, m) => s("li", {
                    className: "item flex",
                    onClick: () => Y({
                        gameName: "blackjack",
                        gameId: r.gameId
                    }),
                    children: [e("div", {
                        className: "col-5 text-left hover",
                        children: r.gameId
                    }), e("div", {
                        className: "col",
                        children: e(Z, {
                            avatar: !1,
                            userId: r.userId,
                            name: r.nickname
                        })
                    }), !k.isMobile && s(x, {
                        children: [e("div", {
                            className: "col",
                            children: r.myValue.map((d, g) => e("span", {
                                className: `point ${d>21?"error":""}`,
                                children: d
                            }, g))
                        }), e("div", {
                            className: "col",
                            children: e("span", {
                                className: `point ${r.bankerValue>21?"cl-error":""}`,
                                children: r.bankerValue
                            })
                        }), e("div", {
                            className: "col text-left fixed",
                            children: e(_, {
                                icon: !0,
                                name: r.currencyName,
                                amount: +r.betAmount
                            })
                        })]
                    }), e("div", {
                        className: "col fixed text-right",
                        children: e(_, {
                            className: +r.winAmount < 0 ? "is-lose" : "is-win",
                            icon: !0,
                            sign: !0,
                            name: r.currencyName,
                            amount: +r.winAmount
                        })
                    })]
                }, m))
            })]
        })
    }),
    Ge = "a1wk3jcx";
y({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: ["#f5f6f7", "#31373d"],
    cl3: [p("#99a4b0", .6), "#5f6975"],
    cl4: ["#99a4b0", "#5f6975"],
    cl5: ["#2d3035", p("#e9eaf2", .6)]
});
const Fe = "l1041ek8";

function Le(a) {
    return A.get("/blackjack/cards/history/", {
        params: a
    })
}

function _e(a) {
    return `https://bcgame-project.github.io/verify/blackjack.html?s=${encodeURIComponent(a.seed)}&i=${a.cardId}`
}

function Be() {
    const a = S(),
        [l, n] = u.exports.useState({
            page: 1,
            pageSize: a.historyPageSize
        }),
        t = u.exports.useMemo(() => Le(l), [l.page]);
    return e("div", {
        className: Me,
        children: e(M, {
            pms: t,
            children: c => c.list.length ? s(x, {
                children: [e(De, {
                    list: c.list
                }), e(X, {
                    page: c.page,
                    total: c.total,
                    limit: c.pageSize,
                    onChange: i => n(L(F({}, l), {
                        page: i
                    }))
                })]
            }) : e(P, {})
        })
    })
}

function De(a) {
    const l = f(),
        {
            list: n
        } = a;
    return s("div", {
        className: Pe,
        children: [s("div", {
            className: "head flex",
            children: [e("div", {
                className: "col-4",
                children: l("game.blackjack.cardId")
            }), e("div", {
                className: "col-4 ellipsis",
                children: l("game.blackjack.roomNum")
            }), s("div", {
                className: "col flex",
                children: [e("div", {
                    className: "flex-shirk",
                    children: l("common.seed")
                }), s("div", {
                    className: "tips-down",
                    children: [e("span", {
                        className: "cl-primary",
                        children: "Why delay showing Seed?"
                    }), e("div", {
                        className: "tips-down-box",
                        children: "Because showing Seed in advance will leak the order of the entire deck. To avoid that, Seed will be shown at the end of each deck, and after that a new deck will be generated. If there is no operation at the table for over 15 minutes, Seed will also be shown and a new deck will be generated."
                    })]
                })]
            })]
        }), e("ul", {
            className: "list",
            children: n.map(t => s("li", {
                className: "item flex",
                children: [e("div", {
                    className: "col-4",
                    children: t.cardId
                }), e("div", {
                    className: "col-4",
                    children: t.roomNum
                }), t.status === 1 ? s("div", {
                    className: "seed-box col",
                    children: [e("input", {
                        type: "text",
                        className: "seed",
                        value: t.seed,
                        readOnly: !0
                    }), e("a", {
                        href: _e(t),
                        target: "_blank",
                        className: "cl-primary",
                        children: l("common.verify")
                    })]
                }) : e("div", {
                    className: "col",
                    children: l("game.blackjack.waitGameOver")
                })]
            }, t.cardId))
        })]
    })
}
var Te = T(Be);
y({
    cl1: [p("#2d3035", .6), p("#dadde6", .6)],
    cl2: [p("#2d3035", .4), p("#dadde6", .3)]
});
const Me = "h1xvjz2l";
y({
    cl1: ["#99a4b0", "#5f6975"],
    cl2: ["#2d3035", p("#e9eaf2", .6)],
    cl3: [p("#99a4b0", .6), "#5f6975"]
});
const Pe = "lquvgxd",
    $e = I.memo(() => {
        const a = f(),
            l = S(),
            n = u.exports.useRef(null);
        u.exports.useEffect(() => {
            const c = n.current;
            if (c) {
                const i = r => {
                    l.betRecent = r
                };
                return c.on("recent-result", i), () => {
                    c.off("recent-result", i)
                }
            }
        }, []);
        const t = [{
            title: a("common.game_intro"),
            node: e(Ie, {})
        }, {
            title: a("common.fairness"),
            node: "/blackjack_help/fairness"
        }, {
            title: a("title.blackjack_help_seed"),
            node: e(je, {})
        }];
        return e(he, {
            src: l.gameUrl,
            ref: n,
            banner: l.gameInfo.cover,
            actions: [e(ee, {}), e(ae, {}), e(le, {
                list: t
            })],
            tabs: [{
                label: a("common.all_bet"),
                value: Ae
            }, {
                label: a("common.my_bet"),
                value: $.Mybet
            }, {
                label: a("common.history"),
                value: Te
            }]
        })
    });
class Re extends ne {
    constructor() {
        var l;
        super({
            name: "blackjack",
            namespace: "/g/bj",
            fairLink: "/blackjack_help/fairness",
            validateLink: "https://bcgame-project.github.io/verify/blackjack.html"
        }, $e), this.disableAutoConnect = !0, this.allBetsLength = 20, this.historyPageSize = 20, this.roomId = (l = location.search.match(/roomId=([^&])/)) == null ? void 0 : l[1], this.betRecent = [], se(this, {
            betRecent: te,
            gameUrl: ce
        })
    }
    get gameUrl() {
        return k.isDev ? `http://blackjack.bc.com?${this.roomId?"roomId="+this.roomId+"&":""}` : `//blackjack.${k.domain}?${this.roomId?"roomId="+this.roomId+"&":""}`
    }
}
const R = new Re;
var aa = R;
window.blg = R;
var ze = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path d="M19.6 32.3c.2-.2.4-.2.6 0l5.8 5.4v.3l-12.4-.1c-.2 0-.2-.2 0-.3 2.3-2.2 5-4.4 6-5.3zm0-31c.5-.4 1-.4 1.5 0 3.2 3.2 10.2 11 13.3 15 3.5 4.6 3.5 9.9-.2 13.5-3.8 3.7-10.5 3.7-13.3-.2-.3-.3-.5-.7-.6-1.2h-.8c0 .4-.3.8-.6 1.2-3 3.3-9.8 3.5-13.4-.2-3.6-3.8-3-9.4.2-13.5 2.8-3.4 10-11 13.9-14.6z"/></svg>',
    Ee = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path d="M20.8 36.5c3.1-2.8 11-11.1 14.1-14.9 3.4-4 4.5-10.4.7-14.4S24.7 3 21.1 7.4c-.4.4-.6.8-.6 1.2h-.9c0-.4-.3-.8-.5-1.2C15.8 3 8.8 3 4.9 6.8c-4 3.7-3.7 9.5-.2 14.2 3.1 4.2 10.7 12.6 13.8 15.5.6.6 1.8.5 2.3 0z"/></svg>',
    Oe = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path d="M20 32.8c.2-.2.4-.2.6 0 1 .8 3.5 2.7 6.1 5 .2 0 0 .2-.1.2l-12.9-.1c-.2 0-.2-.2 0-.3l6.3-4.8zM20.2 2c5.4 0 9.8 4 9.8 9.1 0 1.4-.4 2.7-1 3.8 0 .2.2.5.3.5 5 .6 8.7 4.4 8.7 9 0 5.1-4.4 9.2-9.8 9.2a10 10 0 01-7.8-3.6c-.1-.2-.7-.1-.8 0a10 10 0 01-7.8 3.6c-5.4 0-9.8-4-9.8-9.1 0-4.8 4-8.7 9-9 .1-.1.3-.4.2-.6a8.6 8.6 0 01-.8-3.8c0-5 4.3-9.1 9.8-9.1z"/></svg>',
    We = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40"><path d="M21.7 2.2c.8.7 9.1 8.5 16 16.2.7.8.9 1.8-.2 3.2-.7.8-6.3 7.4-16.2 16.4-.8.7-1.5.7-2.6 0-.6-.6-6.6-6-16.6-16.6-1-1-1-1.9-.2-2.8A216 216 0 0118.4 2.2c1.3-1 2-1 3.3 0z"/></svg>';
const Ue = [ze, Ee, Oe, We],
    w = ({
        cardId: a
    }) => {
        const l = " ,A,2,3,4,5,6,7,8,9,10,J,Q,K".split(","),
            n = (a & 240) / 16 - 10,
            t = l[a % 16],
            c = n % 2 === 0 ? "black-style" : "red-style";
        return s("div", {
            className: re(He, c),
            children: [e("div", {
                className: "point",
                children: t
            }), e("div", {
                className: "flower",
                dangerouslySetInnerHTML: {
                    __html: Ue[n]
                }
            })]
        })
    },
    He = "c17nsyhm";

function Ke(a) {
    return A.get(`/blackjack/game/${a}/cards/`)
}

function qe(a, l, n, t) {
    return `https://bcgame-project.github.io/verify/blackjack.html?s=${encodeURIComponent(a)}&i=${l}&range=${n},${n+t.length}`
}

function Qe(a) {
    const l = /(\[[^\]]+\])/g;
    let n = a.match(l),
        t = [];
    return n && n.forEach(c => {
        t.push(JSON.parse(c))
    }), t
}

function Ve(a) {
    return a.map(l => {
        let {
            position: n,
            cards: t
        } = l.bets[0].extend;
        return {
            userName: l.userName,
            userId: l.userId,
            gameId: l.gameId,
            position: n,
            cardList: Qe(t)
        }
    })
}
const Je = $.withMultipleDetail(a => {
    const l = f(),
        {
            gameId: n
        } = a.gb,
        {
            cardsBeginIndex: t,
            cardId: c
        } = a.gb.extend,
        i = JSON.parse(a.gb.extend.cards || "[]"),
        r = JSON.parse(a.gb.extend.bankerCards || "[]"),
        m = Ve(a.gv),
        [d, g] = u.exports.useState();
    return u.exports.useEffect(() => {
        Ke(c).then(h => {
            const {
                seed: o
            } = h;
            o && g(o)
        })
    }, []), s("div", {
        className: Ye,
        children: [s("div", {
            className: "item",
            children: [e("div", {
                className: "label",
                children: l("game.blackjack.cardsList")
            }), e("div", {
                className: "content",
                children: e("div", {
                    className: "card-list",
                    children: i.map((h, o) => e(w, {
                        cardId: h
                    }, o))
                })
            })]
        }), s("div", {
            className: "item",
            children: [e("div", {
                className: "label",
                children: l("game.blackjack.banker")
            }), e("div", {
                className: "content",
                children: e("div", {
                    className: "card-list",
                    children: r.map((h, o) => e(w, {
                        cardId: h
                    }, o))
                })
            })]
        }), m.map((h, o) => s("div", {
            className: "item",
            children: [e("div", {
                className: "label",
                children: l("common.player") + h.position
            }), e("div", {
                className: "content",
                children: h.cardList.map((b, z) => e("div", {
                    className: "card-list",
                    children: b.map((E, O) => e(w, {
                        cardId: E
                    }, O))
                }, z))
            })]
        }, o)), s("div", {
            className: "item",
            children: [e("div", {
                className: "label",
                children: "Github"
            }), e("div", {
                className: "content",
                children: e("a", {
                    href: "https://bcgame-project.github.io/verify/blackjack.html",
                    target: "_blank",
                    children: "github.com"
                })
            })]
        }), s("div", {
            className: "item",
            children: [e("div", {
                className: "label",
                children: "Bitcointalk"
            }), e("div", {
                className: "content",
                children: e("a", {
                    href: "https://bitcointalk.org/index.php?topic=5088875.msg52316926#msg52316926",
                    target: "_blank",
                    children: "bitcointalk.org"
                })
            })]
        }), s("div", {
            className: "flex-row",
            children: [e(v, {
                label: l("common.game_number"),
                value: n,
                readOnly: !0
            }), e(v, {
                label: l("game.blackjack.beginIndex"),
                value: t,
                readOnly: !0
            })]
        }), e(v, {
            label: l("common.seed"),
            value: d || l("game.blackjack.waitGameOver"),
            readOnly: !0
        }), e(v, {
            label: l("common.salt"),
            value: String("00000000000000000009e93621499e5a63d79a6293609ce52e95e93dd49cb1be"),
            readOnly: !0
        }), e(ie, {
            label: l("common.publickey"),
            children: e("pre", {
                children: `-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDE9QKpw5CHZyf+OfcrT5MCeiCRCLVZjDVUSPGzwXdoGAcRi/r9y7T8t4/byXNTLky0h9dUGKBowwN7bt7fgMKvWAtz0Xf4ztfpsEoRHrzRs2r8khPUjihjrz0N+oPQ+ktAh7M95ZnQfgt/hNWFevGRd+SVsGsWhO8VFrBYb7nS8wIDAQAB
-----END PUBLIC KEY-----`
            })
        }), d && e(de, {
            type: "conic",
            onClick: () => window.open(qe(d, c, t, i)),
            children: l("common.verify")
        })]
    })
});
var la = Je;
y({
    cl1: ["#f5f6f7", "#31373d"],
    cl2: [p("#2d3035", .5), "#f5f6fa"]
});
const Ye = "b1on39s4";

function na({
    bodyLock: a
}) {
    return f(), e(j, {
        bodyLock: a,
        children: s("div", {
            className: "item",
            children: [e("h2", {
                children: "The card sequence verification"
            }), s("div", {
                className: "help-content",
                children: [e("p", {
                    children: "1.The random seed from server side generates hash1 first, hash1 is the card sequence;"
                }), e("p", {
                    children: "2.Use hash1 to generate hash2 and hash2 is public;"
                }), s("p", {
                    children: ["3.", e("span", {
                        className: "cl-primary",
                        children: "After the round is finished"
                    }), ", the hash1 and the card sequence of the round will be public;"]
                })]
            }), e("h2", {
                children: "The single deck shuffling logic"
            }), s("div", {
                className: "help-content",
                children: [e("p", {
                    children: "Use seed for shuffling"
                }), e("p", {
                    children: "The shuffling steps are as follows:"
                }), s("ol", {
                    children: [e("li", {
                        children: "Create a deck of cards named \xDF, the card is sequenced as spade A-K\uFF0Cheart A-K\uFF0C club A-K and diamond A-K."
                    }), e("li", {
                        children: "Hash256 the seed to get the hash value, which will be used as the weight of the first card (spade A) in the card \xDF"
                    }), e("li", {
                        children: "Delete the first bit of the hash value and add it back as the last character of the hash value\uFF08for example 54321 to 43215\uFF09\uFF0C the new hash value will be used as the weight of the second card of \xDF (Spades 2)"
                    }), e("li", {
                        children: "Repeat step 2 to calculate the weight for all the card in \xDF"
                    }), e("li", {
                        children: "Finally, shuffle \xDF according to the corresponding weights of the cards, from small to large. The reordered cards is the shuffled \xDF."
                    })]
                })]
            }), e("h2", {
                children: "The shuffling logic for multiple decks "
            }), s("div", {
                className: "help-content",
                children: [e("p", {
                    children: "When multiple decks need to be shuffled:"
                }), s("ol", {
                    children: [s("li", {
                        children: ["First shuffle the first deck and perform the single deck shuffle steps 2-4.", " "]
                    }), e("li", {
                        children: "Use the hash value of the first deck as the seed for the second deck, then shuffle the second deck by the performing the single deck shuffle steps 2-4."
                    }), e("li", {
                        children: "Use the hash value of the second deck as the seed for the third deck, then shuffle the second deck by the performing the single deck shuffle steps 2-4."
                    }), e("li", {
                        children: "By analogy, all the cards from the decks will have their weight, and finally put all cards together and perform the fourth step of the single deck shuffling logic for sorting."
                    })]
                })]
            })]
        })
    })
}
export {
    la as Detail, na as Fairness, aa as Game
};